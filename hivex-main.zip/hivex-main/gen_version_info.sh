#!/bin/sh

# Post-build script to rename the openhive binary with version and git commit info.
# Usage: gen_version_info.sh <mode> <build_dir>
#   mode     - unused, kept for compatibility with CMakeLists.txt invocation
#   build_dir - CMake build directory (e.g. ${CMAKE_CURRENT_BINARY_DIR})

SHDIR=$(dirname "$(readlink -f "$0")")

# Binary name prefix
name="openhive_"

# Get git short commit hash
gitversion=$(git rev-parse --short HEAD)

# Extract version string from utils/version.cpp (LINUX_COMPATIBLE constant)
version=$(sed -n "/static const std::string LINUX_COMPATIBLE = /p" "${SHDIR}/utils/version.cpp" \
    | awk -F '["]' '{print $2}')

# Build final name: openhive_v<version>
finalname="${name}v${version}"

# Append git hash if available
if [ ${#gitversion} -eq 0 ]; then
    echo "there is no git in your shell"
    exit
else
    finalname="${finalname}_${gitversion}"
fi

finalversion="${finalname}"
echo "${finalversion}"

# Rename the binary to the versioned name
if [ -f "$2/bin/openhive" ]; then
    mv "$2/bin/openhive" "$2/bin/${finalversion}"
else
    echo "openhive not exist"
fi

# sed -i "s/build_commit_hash.*;/build_commit_hash = \"${gitversion}\";/g" ./ca/global.cpp
