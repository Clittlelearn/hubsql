﻿#include "main.h"
#include "menu.h"

#include <cstdint>
#include <regex>
#include <iostream>
#include <string>

#include "commondata.h"
#include "include/logging.h"
#include "rlp.h"
#include "utils/time_util.h"
#include "net/api.h"
#include "ca/ca.h"
#include "ca/global.h"
#include "utils/hex_code.h"
#include "ca/advanced_menu.h"
#include "ca/algorithm.h"
#include "utils/magic_singleton.h"
#include "utils/pretty_print.h"
#include "interface.pb.h"
#include "ca/interface.h"
#include "utils/account_manager.h"
#include "ca/block_http_callback.h"
#include "ca/block_stroage.h"
#include "net/httplib.h"
#include "common/genesis.h"
#include "utils/genesis_block.h"
#include "ca/address_status_cache.h"
#include "utils/init.h"
#include "remote_log/remote_log_bridge.h"
#include "net/ip_port.h"




bool Init()
{
	// Initialize the random number seed
	srand(MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp());

	// Initialize configuration

	if(!InitConfig())
	{
		ERRORLOG("Failed to initialize log!");
		std::cout << "Failed to initialize log!" << std::endl;
		return false;
	}

	if (!InitGenesis())
	{
		ERRORLOG("Failed to initialize genesis config!");
		std::cout << "Failed to initialize genesis! config" << std::endl;
		return false;
	}

	// Initialize log
	if (!InitLog())
	{
		ERRORLOG("Failed to initialize log!");
		std::cout << "Failed to initialize log!" << std::endl;
		return false;
	}

	// Initialize remote log (独立模块，后台运行)
	if (!InitRemoteLogModule())
	{
		std::cout << "Warning: Remote log module init failed, continuing..." << std::endl;
		// 远程日志失败不阻止主流程
	}

	// Initialize account
    if(!InitAccount())
	{
		ERRORLOG("Failed to initialize certification!");
		std::cout << "Failed to initialize certification!" << std::endl;
		return false;
	}

	// Initialize database
	if(InitRocksDb()!=0)
	{
		ERRORLOG("Failed to initialize database!");
		std::cout << "Failed to initialize database!" << std::endl;
		return false;
	}

	// Account loading happens before RocksDB is available, so its initial
	// default is only a deterministic fallback. Once balances can be queried,
	// prefer the local account holding the largest confirmed OHI amount.
	const int selectDefaultRet =
		MagicSingleton<AccountManager>::GetInstance()->SelectDefaultAccountByOhiBalance();
	if (selectDefaultRet != 0)
	{
		WARNLOG("Failed to select default account by OHI balance, ret:{}; keeping existing default",
				selectDefaultRet);
	}

	// Check if exit signal is received during initialization
	if (GetExitRequested())
	{
		std::cout << std::endl << "Received exit signal during initialization, cleaning up..." << std::endl;
		return false;
	}

	return  CaInit() && NetInit();
}

bool InitConfig()
{
	bool flag = false;
	MagicSingleton<Config>::GetInstance(flag);
	return flag;
}

bool InitGenesis()
{
	MagicSingleton<Genesis>::GetInstance();
	return true;
}

bool InitLog()
{
	Config::Log log = {};
	MagicSingleton<Config>::GetInstance()->GetLog(log);
	if(!MagicSingleton<Log>::GetInstance()->LogInit(log.path, log.console, log.level))
	{
		return false;
	}
	return true;
}

bool InitRemoteLogModule()
{
	// 获取本机IP
	std::string node_ip;
	IpPort::GetLocalHostIp(node_ip);
	
	// 生成节点ID（优先用IP）
	std::string node_id = node_ip.empty() ? "unknown" : node_ip;

	return remote_log::InitRemoteLog(node_id, node_ip);
}

bool InitAccount()
{
	try {
		auto accountManager = MagicSingleton<AccountManager>::GetInstance();
		auto result = accountManager->Initialize();
		
		if (result.status != accountInitResult::Status::SUCCESS) {
			std::cout << "Account initialization issue: " << result.message << std::endl;
			
			if (result.status == accountInitResult::Status::EMPTY_KEYSTORE) {
				std::cout << "No existing accounts found. Creating a new account..." << std::endl;
				result = accountManager->CreateInitialAccount();
				if (result.status != accountInitResult::Status::SUCCESS) {
					std::cout << "Failed to create account: " << result.message << std::endl;
					return false;
				}
				std::cout << "Account created successfully." << std::endl;
				return true;
			} 
			else if (result.status == accountInitResult::Status::kAccountsNotInitialized) {
				std::cout << "Would you like to create a new account? (y/n): ";
				std::string response;
				std::getline(std::cin, response);
				
				if (response == "y" || response == "Y") {
					result = accountManager->CreateInitialAccount();
					if (result.status != accountInitResult::Status::SUCCESS) {
						std::cout << "Failed to create account: " << result.message << std::endl;
						return false;
					}
					std::cout << "Account created successfully." << std::endl;
					return true;
				} else {
					std::cout << "Cannot run program without valid accounts." << std::endl;
					return false;
				}
			}
			else {
				// Other serious errors, simply return failure.
				return false;
			}
		}
		
		return true;
	}
	catch (const std::exception& e) {
		std::cout << "Exception during account initialization: " << e.what() << std::endl;
		return false;
	}
}

int InitRocksDb()
{
    if (!DBInit("./data.db"))
    {
        return -1;
    }

    DBReadWriter dbReadWriter;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbReadWriter.getBlockTop(top))
    {
        // Initialize Block 0 using the dynamic genesis block generator
        // GenesisConfig::GenesisBlockGenerator& generator = GenesisConfig::GenesisBlockGenerator::GetInstance();
        
        CBlock block;
        if (!GenesisBlock::GenerateGenesisBlock(block))
        {
            ERRORLOG("Failed to generate genesis block");
            return -2;
        }
        
        if (block.txs_size() == 0)
        {
            return -3;
        }
        
        CTransaction tx = block.txs(0);
        if(tx.utxos_size() == 0)
        {
            return -4;
        }

        // Obtain the initial account address for dynamic configuration
		const auto genesisInstance = MagicSingleton<Genesis>::GetInstance();
		const std::string & initAccountAddr = genesisInstance->GetInitAccountAddr();



        dbReadWriter.setBlockHeightByBlockHash(block.hash(), block.height());
        dbReadWriter.setBlockHashByBlockHeight(block.height(), block.hash(), true);
        dbReadWriter.setBlockByBlockHash(block.hash(), block.SerializeAsString());
        dbReadWriter.setBlockTop(0);
		
		for(auto& utxo : tx.utxos())
		{
			for(int i = 0; i < utxo.vout_size(); ++i)
			{
				if(!isValidAddress(utxo.vout(i).addr()))
				{
					continue;
				}
				dbReadWriter.setUtxoHashesByAddr(utxo.vout(i).addr(),utxo.assettype(),tx.hash());
				if(utxo.vout(i).addr() == initAccountAddr)
				{
					// TODO 这句和后面一句处理相同？
					dbReadWriter.setUtxoValueByUtxoHashes(tx.hash(), utxo.vout(i).addr(), utxo.assettype(), std::to_string(utxo.vout(i).value()));
					dbReadWriter.setBalanceByAddr(utxo.vout(i).addr(), utxo.assettype(), utxo.vout(i).value());
				}
				else
				{
					dbReadWriter.setUtxoValueByUtxoHashes(tx.hash(), utxo.vout(i).addr(), utxo.assettype(), std::to_string(utxo.vout(i).value()));
					dbReadWriter.setBalanceByAddr(utxo.vout(i).addr(),  utxo.assettype(), utxo.vout(i).value());
				}
			}
			dbReadWriter.setBalanceByAddr(utxo.owner().at(0), utxo.assettype(), utxo.vout(0).value());
		}

        dbReadWriter.setTransactionByHash(tx.hash(), tx.SerializeAsString());
        dbReadWriter.setBlockHashByTransactionHash(tx.hash(), block.hash());
    }
	dbReadWriter.setInitVer(ohi::GetVersion());
	if (DBStatus::DB_SUCCESS != dbReadWriter.transactionCommit())
    {
        ERRORLOG("(rocksdb init) transactionCommit failed !");
        return -8;
    }

    return 0;
}


bool Check()
{
	DBReader dbReader;
    uint64_t top = 0;
	std::string hash;
	std::string blockRaw;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockHashByBlockHeight(top,hash))
    {
		ERRORLOG("Get Block Hash error.");
		return false;
	}

	if (DBStatus::DB_SUCCESS != dbReader.getBlockByBlockHash(hash,blockRaw))
    {
		ERRORLOG("Get Block Raw error.");
		return false;
	}

	CBlock dbBlock;
    dbBlock.ParseFromString(blockRaw);

	// Verify using the dynamic genesis block generator
	CBlock expectedBlock;
	if (!GenesisBlock::GenerateGenesisBlock(expectedBlock))
	{
		ERRORLOG("Failed to generate expected genesis block for verification");
		return false;
	}

	if(expectedBlock.hash() != hash)
	{
		std::cout << "The current version data is inconsistent with the new version !" << std::endl;
		return false;
	}

	// Check if exit signal is received during check
	if (GetExitRequested())
	{
		std::cout << std::endl << "Received exit signal during check, cleaning up..." << std::endl;
		return false;
	}

	return true;
}

bool CleanUp()
{
	CaCleanup();
	return true;
}

int init_check()
{
	bool initFail = false;
	if (!Init())
	{
		initFail = true;
	}

	// Check if exit signal is received during initialization
	if (GetExitRequested())
	{
		std::cout << std::endl << "Received exit signal during initialization, cleaning up..." << std::endl;
		initFail = true;
	}

	if (!Check())
	{
		initFail = true;
	}

	// Check if exit signal is received during check
	if (GetExitRequested())
	{
		std::cout << std::endl << "Received exit signal during check, cleaning up..." << std::endl;
		initFail = true;
	}

	if (initFail)
	{
		CleanUp();
		return -1;
	}
	return 0;
}
