﻿#include "menu.h"

#include <cstdint>
#include <regex>
#include <iostream>
#include <string>

#include "commondata.h"
#include "include/logging.h"
#include "rlp.h"
#include "ca/ca.h"
#include "ca/global.h"
#include "ca/advanced_menu.h"
#include "ca/algorithm.h"
#include "utils/magic_singleton.h"
#include "net/peer_node.h"
#include "utils/version.h"
#include "utils/account_manager.h"
#include "utils/console.h"
#include "utils/init.h"

void PrintBasicInfo()
{
    using namespace std;
    std::string version = ohi::GetVersion();
    std::string addr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

    std::string assetType;
    int ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
    if(ret != 0){
        ERRORLOG("Get Can BeRevoke AssetType fail!");
    }

    int64_t balanceX = 0;
    int64_t balanceA = 0;
    int64_t balanceB = 0;
    DBReader dbReader;
    dbReader.getBalanceByAddr(addr, global::ca::ASSET_TYPE_OHI, balanceX);
    double b = balanceX / double(100000000);
    dbReader.getBalanceByAddr(addr, assetType, balanceA);
    double c = balanceA / double(100000000);

    uint64_t blockHeight = 0;
    dbReader.getBlockTop(blockHeight);

    std::string ownID = MagicSingleton<PeerNode>::GetInstance()->GetSelfId();

    CaConsole infoColor(CONSOLE_COLOR_GREEN, CONSOLE_COLOR_BLACK, true);

    std::vector<std::pair<std::string, bool>> vecAddrType;
    ca_algorithm::GetAddrType(addr, vecAddrType);

    cout << "*********************************************************************************" << endl;
    cout << "Version: " << version << endl;
    cout << "Block top: " << blockHeight << endl;
    cout << "Address: " << addHexPrefix(addr) << endl;
    cout << "Balance: " << global::ca::ASSET_TYPE_OHI << ": " << setiosflags(ios::fixed) << setprecision(8) << b << endl;
    for(const auto& type: vecAddrType)
    {
        std::cout << type.first << ": ";
        type.second ? std::cout << "yes\n" : std::cout << "no\n";
    }
    cout << "*********************************************************************************" << endl;

}

void Menu()
{
	PrintBasicInfo();
	while (true)
	{
		// 检查是否收到退出信号
		if (GetExitRequested())
		{
			std::cout << std::endl << "Received exit signal, cleaning up..." << std::endl;
			CaCleanup();
			DEBUGLOG("*** Program exits normally *** ");
			quick_exit(0);
			return;
		}
		
		std::cout << std::endl << std::endl;
		std::cout << "1.Transaction" << std::endl;
		std::cout << "2.Staking" << std::endl;
		std::cout << "3.Unstaking" << std::endl;
		std::cout << "4.Delegating" << std::endl;
		std::cout << "5.Undelegating" << std::endl;
		std::cout << "6.Get Bonus"  << std::endl;
        std::cout << "7.Print Account Info" << std::endl;
		std::cout << "8.Deploy contract"  << std::endl;
		std::cout << "9.Call contract"  << std::endl;
		std::cout << "10.Lock" << std::endl;
		std::cout << "11.UnLock" << std::endl;
		std::cout << "12.Proposal" << std::endl;
		std::cout << "13.Revoke proposal" << std::endl;
		std::cout << "14.Vote" << std::endl;
		std::cout << "15.Fund" << std::endl;
		std::cout << "16.Account Manager" << std::endl;
		std::cout << "99.Advanced Menu" << std::endl;
		std::cout << "0.Exit" << std::endl;

		std::string strKey;
		std::cout << "Please input your choice: "<< std::endl;
		std::cin >> strKey;
		std::regex pattern("^[0-9]|(1[0-7])|(99)|(100)$");
		if(!std::regex_match(strKey, pattern))
        {
            std::cout << "Invalid input." << std::endl;
            continue;
        }
        int key = std::stoi(strKey);
		switch (key)
		{
			case 0:
				std::cout << "Exiting, bye!" << std::endl;
				CaCleanup();
				DEBUGLOG("*** Program exits normally *** ");
				quick_exit(0);
				return;
			case 1:
				HandleTransaction();
				break;
			case 2:
				HandleStake();
				break;
			case 3:
				HandleUnstake();
				break;
			case 4:
				handleDelegating();
                break;
			case 5:
				HandleUndelegating();
                break;
			case 6:
				HandleBonus();
                break;
			case 7:
				PrintBasicInfo();
				ca_algorithm::GetAllMappedAssets();
				break;
			case 8:
				DeployContract();
				break;
			case 9:
				CallContract();
				break;
			case 10:
				HandleLock();
				break;
			case 11:
				HandleUnLock();
				break;
			case 12:
				HandleProposal();
				break;
			case 13:
				revokeProposalRequest();
				break;
			case 14:
				HandleVote();
				break;
			case 15:
				HandleTresury();
				break;
			case 16:
				handleAccountManager();
				break;
			case 17:
				break;
			case 99:
				MenuAdvanced();
				break;
			case 100:{
				dev::RLPStream rlpStream;
				rlpStream.appendList(3);
				rlpStream.append(1234);
				rlpStream.append(1);
				rlpStream.append("Transaction Processed Successfully");
				// std::cout << rlpStream.out() << std::endl;

				dev::bytesConstRef rlpBytes(rlpStream.out().data(), rlpStream.out().size());

				dev::bytes response = dev::handleEthSendRawTransaction(rlpBytes);
				std::cout << "Response: " << dev::toHex(response) << std::endl;

				std::string str = dev::toHex(response);
				dev::bytes _responseStr = dev::fromHex(str);

				dev::bytesConstRef _rlpBytes(_responseStr.data(), _responseStr.size());
				dev::bytes _response = dev::handleEthSendRawTransaction(_rlpBytes);
				std::cout << "_Response: " << dev::toHex(_response) << std::endl;
			}
				break;
			default:
                std::cout << "Invalid input." << std::endl;
                continue;
		}
		sleep(1);
	}
}
