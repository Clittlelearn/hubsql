#ifndef _MENU_H
#define _MENU_H

// 主菜单界面，用于显示菜单选项并处理用户输入
void Menu();

// 打印并显示系统基本介绍信息
void PrintBasicInfo();

#endif // _MENU_H
