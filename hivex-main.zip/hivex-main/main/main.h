#ifndef MAIN_H
#define MAIN_H

 
void Menu();
bool Init();
bool InitConfig();
bool InitGenesis();
bool InitLog();
bool InitRemoteLogModule();
bool InitAccount();
int  InitRocksDb();

/*********Check Consistency*********/

bool Check();
bool CleanUp();

int init_check();

#endif
