/**
 * *****************************************************************************
 * @file        remote_log_bridge.h
 * @brief       连接 logging.h 宏与 remote_log 模块的桥接层
 * @author      mm
 * @date        2025-06-24
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef _REMOTE_LOG_BRIDGE_H_
#define _REMOTE_LOG_BRIDGE_H_

#include <memory>
#include <string>
#include <iostream>

#include "remote_log.h"
#include "remote_log_config.h"
#include "../include/logging.h"

namespace remote_log {

/**
 * @brief 全局远程日志实例（单例）
 */
inline std::shared_ptr<RemoteLog>& GetRemoteLogInstance()
{
    static std::shared_ptr<RemoteLog> instance;
    return instance;
}

/**
 * @brief 将 spdlog 级别映射到 remote_log::Level
 */
inline remote_log::Level SpdlogLevelToRemoteLevel(int spdlog_level)
{
    // spdlog levels: trace=0, debug=1, info=2, warn=3, err=4, critical=5, off=6
    switch (spdlog_level)
    {
        case 0:  return remote_log::Level::TRACE;
        case 1:  return remote_log::Level::DEBUG;
        case 2:  return remote_log::Level::INFO;
        case 3:  return remote_log::Level::WARN;
        case 4:  return remote_log::Level::ERROR;
        case 5:  return remote_log::Level::FATAL;
        default: return remote_log::Level::INFO;
    }
}

/**
 * @brief 初始化远程日志模块
 * 
 * 从 remote_log_config.json 读取配置，
 * 初始化 RemoteLog 实例（服务端 + 客户端），
 * 并注册全局日志钩子，使所有 ERRORLOG/DEBUGLOG 等宏自动推送到远程。
 * 
 * @param node_id  本节点ID（可选，默认取IP）
 * @param node_ip  本节点IP
 * @return true 成功
 */
inline bool InitRemoteLog(const std::string& node_id = "", const std::string& node_ip = "")
{
    // 1. 加载独立配置文件
    auto cfg = RemoteLogConfigLoader::Load();

    if (!cfg.enable)
    {
        std::cout << "[RemoteLogBridge] Remote log is disabled in config." << std::endl;
        return true; // 不算失败
    }

    // 2. 创建并初始化 RemoteLog 实例
    auto rl = std::make_shared<RemoteLog>();
    if (!rl->Init(cfg, node_id, node_ip))
    {
        std::cerr << "[RemoteLogBridge] Failed to init RemoteLog module." << std::endl;
        return false;
    }
    GetRemoteLogInstance() = rl;

    // 3. 注册全局日志钩子 —— 此后所有 LOG 宏都会自动推送远程日志
    int min_level = cfg.report_level; // 最低上报级别，低于此级别的日志不上报

    SetRemoteLogHook([rl, min_level](int spdlog_level, const std::string& module, const std::string& file, int line, const std::string& message) {
        if (spdlog_level < min_level)
        {
            return;
        }
        auto remote_level = SpdlogLevelToRemoteLevel(spdlog_level);
        rl->Log(module, remote_level, file, line, message);
    });

    std::cout << "[RemoteLogBridge] Hook registered. All LOG macros now also report to remote. "
              << "Min level: " << min_level << std::endl;
    return true;
}

/**
 * @brief 停止远程日志模块
 */
inline void ShutdownRemoteLog()
{
    auto& rl = GetRemoteLogInstance();
    if (rl)
    {
        rl->Shutdown();
        rl.reset();
    }

    // 清除钩子
    SetRemoteLogHook(nullptr);

    std::cout << "[RemoteLogBridge] Shutdown." << std::endl;
}

} // namespace remote_log

#endif // _REMOTE_LOG_BRIDGE_H_
