/**
 * *****************************************************************************
 * @file        remote_log_server.cpp
 * @brief       远程日志HTTP服务端实现 - 接收各节点日志，按IP分开存储
 * @author      mm
 * @date        2025-06-24
 * @copyright   mm
 * *****************************************************************************
 */
#include "remote_log_server.h"

#include <iostream>
#include <sstream>
#include <ctime>
#include <iomanip>
#include <filesystem>
#include <sys/stat.h>

#include "../net/httplib.h"

using namespace httplib;

namespace remote_log {

// ============================================================================
// 生命周期
// ============================================================================

RemoteLogServer::~RemoteLogServer()
{
    Stop();
}

// ============================================================================
// 公开接口
// ============================================================================

bool RemoteLogServer::Start(uint16_t port,
                             const std::string& storage_path,
                             bool console_echo)
{
    if (_running.load())
    {
        return true; // 已经运行
    }

    _storage_path = storage_path;
    _console_echo = console_echo;

    // 确保存储目录存在
    try
    {
        std::filesystem::create_directories(_storage_path);
    }
    catch (const std::exception& e)
    {
        std::cerr << "[RemoteLogServer] Failed to create storage dir: " 
                  << _storage_path << " - " << e.what() << std::endl;
        return false;
    }

    _running.store(true);
    _worker = std::thread(&RemoteLogServer::_WorkerThread, this, port);

    std::cout << "[RemoteLogServer] Started on port " << port 
              << ", storage: " << _storage_path << std::endl;
    return true;
}

void RemoteLogServer::Stop()
{
    if (!_running.load())
    {
        return;
    }

    _running.store(false);

    // httplib Server stop 需要通过其自身机制；
    // 我们向自身发一个请求来触发 svr.stop()
    // 但为了简洁起见，这里直接 detach，让进程退出时自然回收。
    if (_worker.joinable())
    {
        _worker.detach();  // httplib Server::listen 会阻塞，detach 后随进程结束
    }

    std::cout << "[RemoteLogServer] Stopped." << std::endl;
}

void RemoteLogServer::RegisterCallback(LogCallback cb)
{
    std::lock_guard<std::mutex> lock(_cb_mutex);
    _callbacks.push_back(std::move(cb));
}

// ============================================================================
// 工作线程
// ============================================================================

void RemoteLogServer::_WorkerThread(uint16_t port)
{
    Server svr;

    // 超时设置
    svr.set_read_timeout(10, 0);
    svr.set_write_timeout(10, 0);

    // 健康检查接口
    svr.Get("/log/health", [](const Request& req, Response& res) {
        nlohmann::json j;
        j["status"] = "ok";
        j["service"] = "remote_log_server";
        res.set_content(j.dump(), "application/json");
    });

    // 日志上报接口
    svr.Post("/log/report", [this](const Request& req, Response& res) {
        try
        {
            auto body = nlohmann::json::parse(req.body);
            LogBatch batch = LogBatch::from_json(body);

            // 始终打印批次摘要
            // std::cout << "[RemoteLogServer] <<< Received batch: "
            //           << batch.entries.size() << " entries"
            //           << " from node=" << batch.node_id
            //           << " remote=" << req.remote_addr << std::endl;

            if (batch.entries.empty())
            {
                nlohmann::json rsp;
                rsp["code"] = 0;
                rsp["msg"]  = "empty batch";
                res.set_content(rsp.dump(), "application/json");
                return;
            }

            // 写入每条日志
            for (auto& entry : batch.entries)
            {
                // 如果上报者没有填 node_ip，用 batch 级别的 node_id 或请求 IP
                if (entry.node_ip.empty())
                {
                    entry.node_ip = batch.node_id;
                }

                _WriteToFile(entry);

                // 触发回调
                {
                    std::lock_guard<std::mutex> lock(_cb_mutex);
                    for (auto& cb : _callbacks)
                    {
                        if (cb) cb(entry);
                    }
                }

                // 控制台回显每条日志
                if (_console_echo)
                {
                    auto now = std::chrono::system_clock::now();
                    auto t = std::chrono::system_clock::to_time_t(now);
                    std::tm tm_buf{};
                    localtime_r(&t, &tm_buf);

                    char time_buf[32];
                    strftime(time_buf, sizeof(time_buf), "%Y-%m-%d %H:%M:%S", &tm_buf);

                    // std::cout << "  [" << time_buf << "]"
                    //           << "[" << level_to_string(entry.level) << "]"
                    //           << "[" << entry.node_ip << "]"
                    //           << "[" << entry.module << "]"
                    //           << "[" << entry.file << ":" << entry.line << "] "
                    //           << entry.message << std::endl;
                }
            }

            // std::cout << "[RemoteLogServer] >>> Batch processed: "
            //           << batch.entries.size() << " entries saved." << std::endl;

            nlohmann::json rsp;
            rsp["code"]    = 0;
            rsp["msg"]     = "ok";
            rsp["count"]   = batch.entries.size();
            res.set_content(rsp.dump(), "application/json");
        }
        catch (const std::exception& e)
        {
            std::cerr << "[RemoteLogServer] Parse error: " << e.what() << std::endl;
            nlohmann::json rsp;
            rsp["code"] = -1;
            rsp["msg"]  = std::string("parse error: ") + e.what();
            res.status = 400;
            res.set_content(rsp.dump(), "application/json");
        }
    });

    std::cout << "[RemoteLogServer] Listening on 0.0.0.0:" << port << " ..." << std::endl;

    // 阻塞监听
    svr.listen("0.0.0.0", port);
}

// ============================================================================
// 文件写入（每个IP单独文件）
// ============================================================================

std::string RemoteLogServer::_GetLogFilePath(const std::string& node_ip) const
{
    // 获取当天日期
    auto now = std::chrono::system_clock::now();
    auto t = std::chrono::system_clock::to_time_t(now);
    std::tm tm_buf{};
    localtime_r(&t, &tm_buf);

    char date_buf[16];
    strftime(date_buf, sizeof(date_buf), "%Y-%m-%d", &tm_buf);

    // 文件名格式: {storage_path}/{node_ip}_{YYYY-MM-DD}.log
    // 例如: ./remote_logs/192.168.1.100_2025-06-24.log
    std::ostringstream oss;
    oss << _storage_path << "/" << node_ip << "_" << date_buf << ".log";
    return oss.str();
}

void RemoteLogServer::_WriteToFile(const LogEntry& entry)
{
    if (entry.node_ip.empty())
    {
        return;
    }

    std::string path = _GetLogFilePath(entry.node_ip);

    // 格式化时间
    auto ms = entry.timestamp_ms;
    auto sec = ms / 1000;
    auto msec = ms % 1000;
    std::time_t t = static_cast<std::time_t>(sec);
    std::tm tm_buf{};
    localtime_r(&t, &tm_buf);

    char time_buf[32];
    strftime(time_buf, sizeof(time_buf), "%Y-%m-%d %H:%M:%S", &tm_buf);

    // 构建单行日志：包含 file:line
    std::ostringstream line;
    line << "[" << time_buf << "." << std::setfill('0') << std::setw(3) << msec << "]"
         << "[" << level_to_string(entry.level) << "]"
         << "[" << entry.module << "]"
         << "[" << entry.file << ":" << entry.line << "] "
         << entry.message << "\n";

    // 线程安全地写入文件
    std::lock_guard<std::mutex> lock(_file_mutex);
    std::ofstream ofs(path, std::ios::app);
    if (ofs.is_open())
    {
        ofs << line.str();
        ofs.flush();
    }
}

} // namespace remote_log
