/**
 * *****************************************************************************
 * @file        remote_log_common.h
 * @brief       远程日志模块 - 公共数据结构和类型定义
 * @author      mm
 * @date        2025-06-24
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef _REMOTE_LOG_COMMON_H_
#define _REMOTE_LOG_COMMON_H_

#include <string>
#include <vector>
#include <chrono>
#include <nlohmann/json.hpp>

namespace remote_log {

/**
 * @brief 远程日志级别
 */
enum class Level
{
    TRACE = 0,
    DEBUG = 1,
    INFO  = 2,
    WARN  = 3,
    ERROR = 4,
    FATAL = 5
};

/**
 * @brief 单条远程日志条目
 */
struct LogEntry
{
    std::string node_id;          // 节点标识
    std::string node_ip;          // 节点IP
    std::string module;           // 来源模块名
    Level       level;            // 日志级别
    std::string file;             // 源文件名
    int         line = 0;         // 行号
    std::string message;          // 日志内容
    int64_t     timestamp_ms;     // 毫秒时间戳

    nlohmann::json to_json() const
    {
        nlohmann::json j;
        j["node_id"]    = node_id;
        j["node_ip"]    = node_ip;
        j["module"]     = module;
        j["level"]      = static_cast<int>(level);
        j["file"]       = file;
        j["line"]       = line;
        j["message"]    = message;
        j["timestamp"]  = timestamp_ms;
        return j;
    }

    static LogEntry from_json(const nlohmann::json& j)
    {
        LogEntry e;
        e.node_id      = j.value("node_id", "");
        e.node_ip      = j.value("node_ip", "");
        e.module       = j.value("module", "");
        e.level        = static_cast<Level>(j.value("level", 0));
        e.file         = j.value("file", "");
        e.line         = j.value("line", 0);
        e.message      = j.value("message", "");
        e.timestamp_ms = j.value("timestamp", 0);
        return e;
    }
};

/**
 * @brief 批量日志上报请求体
 */
struct LogBatch
{
    std::string           node_id;
    std::vector<LogEntry> entries;

    nlohmann::json to_json() const
    {
        nlohmann::json j;
        j["node_id"] = node_id;
        nlohmann::json arr = nlohmann::json::array();
        for (const auto& e : entries)
        {
            arr.push_back(e.to_json());
        }
        j["entries"] = arr;
        return j;
    }

    static LogBatch from_json(const nlohmann::json& j)
    {
        LogBatch b;
        b.node_id = j.value("node_id", "");
        if (j.contains("entries") && j["entries"].is_array())
        {
            for (const auto& item : j["entries"])
            {
                b.entries.push_back(LogEntry::from_json(item));
            }
        }
        return b;
    }
};

/**
 * @brief 将日志级别转为字符串
 */
inline const char* level_to_string(Level lv)
{
    switch (lv)
    {
        case Level::TRACE: return "TRACE";
        case Level::DEBUG: return "DEBUG";
        case Level::INFO:  return "INFO";
        case Level::WARN:  return "WARN";
        case Level::ERROR: return "ERROR";
        case Level::FATAL: return "FATAL";
        default:           return "UNKNOWN";
    }
}

/**
 * @brief 配置结构体
 */
struct RemoteLogConfig
{
    bool        enable       = false;
    uint16_t    server_port  = 13135;            // 本机作为服务端监听端口
    std::string report_url;                       // 作为客户端上报目标URL，如 http://ip:port/log/report
    int         report_interval_sec = 10;         // 上报间隔（秒）
    size_t      max_batch_size      = 1000;       // 单次最大批量条数
    std::string storage_path       = "./remote_logs"; // 服务端日志存储路径
    bool        console_echo       = false;       // 服务端是否回显到控制台
    int         report_level       = 4;           // 最低上报级别（>=此级别的日志才上报）TRACE=0..FATAL=5
};

} // namespace remote_log

#endif // _REMOTE_LOG_COMMON_H_
