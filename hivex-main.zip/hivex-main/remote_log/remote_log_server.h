/**
 * *****************************************************************************
 * @file        remote_log_server.h
 * @brief       远程日志HTTP服务端 - 接收其他节点上报的日志
 * @author      mm
 * @date        2025-06-24
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef _REMOTE_LOG_SERVER_H_
#define _REMOTE_LOG_SERVER_H_

#include <string>
#include <thread>
#include <atomic>
#include <mutex>
#include <fstream>
#include <memory>

#include "remote_log_common.h"

namespace remote_log {

/**
 * @class RemoteLogServer
 * @brief 接收远程日志的HTTP服务端
 * 
 * 在后台线程中启动一个HTTP服务器，监听指定端口，
 * 接收来自各节点的批量日志上报请求。
 * 日志可以写入本地文件，也可以回调给上层处理。
 */
class RemoteLogServer
{
public:
    using LogCallback = std::function<void(const LogEntry&)>;

    RemoteLogServer() = default;
    ~RemoteLogServer();

    RemoteLogServer(const RemoteLogServer&) = delete;
    RemoteLogServer& operator=(const RemoteLogServer&) = delete;

    /**
     * @brief 启动日志接收服务
     * @param port         监听端口
     * @param storage_path 日志存储目录
     * @param console_echo 是否回显到控制台
     * @return true 启动成功 / false 启动失败
     */
    bool Start(uint16_t port, 
               const std::string& storage_path = "./remote_logs",
               bool console_echo = false);

    /**
     * @brief 停止服务
     */
    void Stop();

    /**
     * @brief 是否正在运行
     */
    bool IsRunning() const { return _running.load(); }

    /**
     * @brief 注册自定义日志处理回调
     */
    void RegisterCallback(LogCallback cb);

private:
    /**
     * @brief 服务器工作线程主函数
     */
    void _WorkerThread(uint16_t port);

    /**
     * @brief 写入一条日志到对应节点的本地文件（每个IP单独存储）
     */
    void _WriteToFile(const LogEntry& entry);

    /**
     * @brief 获取指定节点当天的日志文件路径
     * @param node_ip 节点IP地址
     * @return 文件路径: {storage_path}/{node_ip}_{YYYY-MM-DD}.log
     */
    std::string _GetLogFilePath(const std::string& node_ip) const;

    std::atomic<bool>    _running{false};
    std::thread          _worker;
    std::mutex           _file_mutex;
    std::mutex           _cb_mutex;
    std::string          _storage_path;
    bool                 _console_echo = false;
    std::vector<LogCallback> _callbacks;
};

} // namespace remote_log

#endif // _REMOTE_LOG_SERVER_H_
