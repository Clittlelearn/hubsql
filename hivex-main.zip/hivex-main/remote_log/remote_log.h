/**
 * *****************************************************************************
 * @file        remote_log.h
 * @brief       远程日志模块 - 统一入口，管理服务端和客户端
 * @author      mm
 * @date        2025-06-24
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef _REMOTE_LOG_H_
#define _REMOTE_LOG_H_

#include <string>
#include <memory>

#include "remote_log_common.h"
#include "remote_log_server.h"
#include "remote_log_client.h"

namespace remote_log {

/**
 * @class RemoteLog
 * @brief 远程日志模块统一管理类
 * 
 * 每个节点根据配置可以同时运行服务端（接收日志）和客户端（上报日志）。
 * 典型场景：
 *   - 日志中心节点：仅启动服务端，接收所有节点的日志
 *   - 普通节点：仅启动客户端，定时向中心上报日志
 *   - 也可同时启动两者，用于级联场景
 */
class RemoteLog
{
public:
    RemoteLog() = default;
    ~RemoteLog();

    RemoteLog(const RemoteLog&) = delete;
    RemoteLog& operator=(const RemoteLog&) = delete;

    /**
     * @brief 根据配置初始化并启动远程日志模块
     * @param cfg 远程日志配置
     * @param node_id 本节点ID
     * @param node_ip 本节点IP
     * @return true 成功 / false 失败
     */
    bool Init(const RemoteLogConfig& cfg,
              const std::string& node_id,
              const std::string& node_ip);

    /**
     * @brief 停止所有服务
     */
    void Shutdown();

    /**
     * @brief 推送一条远程日志（仅在客户端启动时有效）
     */
    void Log(const std::string& module, Level level, const std::string& file, int line, const std::string& message);

    /**
     * @brief 获取服务端实例
     */
    RemoteLogServer* GetServer() { return _server.get(); }

    /**
     * @brief 获取客户端实例
     */
    RemoteLogClient* GetClient() { return _client.get(); }

    /**
     * @brief 是否已初始化
     */
    bool IsInitialized() const { return _initialized; }

private:
    bool                              _initialized = false;
    RemoteLogConfig                   _config;
    std::unique_ptr<RemoteLogServer>  _server;
    std::unique_ptr<RemoteLogClient>  _client;
};

} // namespace remote_log

#endif // _REMOTE_LOG_H_
