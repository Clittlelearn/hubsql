/**
 * *****************************************************************************
 * @file        remote_log.cpp
 * @brief       远程日志模块统一入口实现
 * @author      mm
 * @date        2025-06-24
 * @copyright   mm
 * *****************************************************************************
 */
#include "remote_log.h"

#include <iostream>

namespace remote_log {

// ============================================================================
// 生命周期
// ============================================================================

RemoteLog::~RemoteLog()
{
    Shutdown();
}

// ============================================================================
// 公开接口
// ============================================================================

bool RemoteLog::Init(const RemoteLogConfig& cfg,
                      const std::string& node_id,
                      const std::string& node_ip)
{
    if (_initialized)
    {
        std::cerr << "[RemoteLog] Already initialized." << std::endl;
        return true;
    }

    if (!cfg.enable)
    {
        std::cout << "[RemoteLog] Disabled by config." << std::endl;
        return false;
    }

    _config = cfg;

    // ---- 启动服务端（接收日志） ----
    if (_config.server_port > 0)
    {
        _server = std::make_unique<RemoteLogServer>();
        if (!_server->Start(_config.server_port,
                            _config.storage_path,
                            _config.console_echo))
        {
            std::cerr << "[RemoteLog] FAILED to start server on port "
                      << _config.server_port << std::endl;
        }
    }
    else
    {
        std::cout << "[RemoteLog] Server NOT started (server_port=0 in config)."
                  << " This node will NOT receive remote logs." << std::endl;
    }

    // ---- 启动客户端（上报日志） ----
    if (!_config.report_url.empty())
    {
        _client = std::make_unique<RemoteLogClient>();
        if (!_client->Start(_config.report_url,
                            node_id,
                            node_ip,
                            _config.report_interval_sec,
                            _config.max_batch_size))
        {
            std::cerr << "[RemoteLog] FAILED to start client, target: "
                      << _config.report_url << std::endl;
        }
    }
    else
    {
        std::cout << "[RemoteLog] Client NOT started (report_url empty)."
                  << " This node will NOT send logs to remote." << std::endl;
    }

    _initialized = true;
    std::cout << "[RemoteLog] ===== Module ready ====="
              << " server=" << (_server ? "ON:" + std::to_string(_config.server_port) : "OFF")
              << " client=" << (_client ? "ON->" + _config.report_url : "OFF")
              << " report_level>=" << _config.report_level
              << std::endl;
    return true;
}

void RemoteLog::Shutdown()
{
    if (!_initialized)
    {
        return;
    }

    if (_client)
    {
        _client->Stop();
        _client.reset();
    }

    if (_server)
    {
        _server->Stop();
        _server.reset();
    }

    _initialized = false;
    std::cout << "[RemoteLog] Module shutdown." << std::endl;
}

void RemoteLog::Log(const std::string& module, Level level, const std::string& file, int line, const std::string& message)
{
    if (_client)
    {
        _client->PushLog(module, level, file, line, message);
    }
}

} // namespace remote_log
