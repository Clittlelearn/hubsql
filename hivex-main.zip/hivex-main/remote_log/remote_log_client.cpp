/**
 * *****************************************************************************
 * @file        remote_log_client.cpp
 * @brief       远程日志HTTP客户端实现 - 定时向目标服务器批量上报日志
 * @author      mm
 * @date        2025-06-24
 * @copyright   mm
 * *****************************************************************************
 */
#include "remote_log_client.h"

#include <iostream>
#include <chrono>

#include "../net/httplib.h"

using namespace httplib;

namespace remote_log {

// ============================================================================
// 生命周期
// ============================================================================

RemoteLogClient::~RemoteLogClient()
{
    Stop();
}

// ============================================================================
// 公开接口
// ============================================================================

bool RemoteLogClient::Start(const std::string& report_url,
                             const std::string& node_id,
                             const std::string& node_ip,
                             int interval_sec,
                             size_t max_batch_size)
{
    if (_running.load())
    {
        return true;
    }

    if (report_url.empty())
    {
        std::cerr << "[RemoteLogClient] report_url is empty, cannot start." << std::endl;
        return false;
    }

    _report_url     = report_url;
    _node_id        = node_id;
    _node_ip        = node_ip;
    _interval_sec   = interval_sec;
    _max_batch_size = max_batch_size;

    _running.store(true);
    _worker = std::thread(&RemoteLogClient::_WorkerThread, this);

    std::cout << "[RemoteLogClient] Started, reporting to " << _report_url
              << " every " << _interval_sec << "s" << std::endl;
    return true;
}

void RemoteLogClient::Stop()
{
    if (!_running.load())
    {
        return;
    }

    _running.store(false);
    _queue_cv.notify_all();

    if (_worker.joinable())
    {
        _worker.join();
    }

    // 最后一次强制刷新
    _FlushBatch();

    std::cout << "[RemoteLogClient] Stopped." << std::endl;
}

void RemoteLogClient::PushLog(const std::string& module, Level level, const std::string& file, int line, const std::string& message)
{
    if (!_running.load())
    {
        return;
    }

    LogEntry entry;
    entry.node_id      = _node_id;
    entry.node_ip      = _node_ip;
    entry.module       = module;
    entry.level        = level;
    entry.file         = file;
    entry.line         = line;
    entry.message      = message;
    entry.timestamp_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();

    {
        std::lock_guard<std::mutex> lock(_queue_mutex);
        _log_queue.push(std::move(entry));
        _total_queued++;

        if (!_first_log_printed)
        {
            _first_log_printed = true;
            std::cout << "[RemoteLogClient] *** First log queued! ["
                      << level_to_string(level) << "] <" << module << "> "
                      << file << ":" << line << " " << message << std::endl;
        }
    }
    _queue_cv.notify_one();
}

void RemoteLogClient::PushLog(const char* module, Level level, const char* file, int line, const char* message)
{
    PushLog(std::string(module), level, std::string(file), line, std::string(message));
}

// ============================================================================
// 工作线程
// ============================================================================

void RemoteLogClient::_WorkerThread()
{
    int cycle = 0;
    std::cout << "[RemoteLogClient] Worker thread started, interval="
              << _interval_sec << "s" << std::endl;

    while (_running.load())
    {
        // 等待指定间隔或被停止信号唤醒
        {
            std::unique_lock<std::mutex> lock(_queue_mutex);
            _queue_cv.wait_for(lock, std::chrono::seconds(_interval_sec), [this]() {
                return !_running.load();
            });
        }

        if (!_running.load())
        {
            break;
        }

        ++cycle;

        // 获取当前队列大小
        size_t qsize = 0;
        {
            std::lock_guard<std::mutex> lock(_queue_mutex);
            qsize = _log_queue.size();
        }

        // 执行批量上报
        bool ok = _FlushBatch();

        // 首轮 + 每 5 轮打印心跳
        if (cycle == 1 || cycle % 5 == 0)
        {
            // std::cout << "[RemoteLogClient] Heartbeat #" << cycle
            //           << " | total_queued=" << _total_queued
            //           << " | pending=" << qsize
            //           << " | target=" << _report_url
            //           << " | flush=" << (ok ? "OK" : "FAIL") << std::endl;
        }
    }

    //std::cout << "[RemoteLogClient] Worker thread exiting after " << cycle << " cycles." << std::endl;
}

// ============================================================================
// 批量上报
// ============================================================================

bool RemoteLogClient::_FlushBatch()
{
    auto batch_entries = _DequeueBatch(_max_batch_size);
    if (batch_entries.empty())
    {
        return true;
    }

    LogBatch batch;
    batch.node_id = _node_id;
    batch.entries = std::move(batch_entries);

    std::string body = batch.to_json().dump();

    try
    {
        // 从 report_url 中提取 host 和 port
        // 兼容格式: http://ip:port, http://ip:port/path, ip:port
        std::string host;
        int port = 80;

        std::string url = _report_url;

        // 去掉协议前缀
        size_t scheme_pos = url.find("://");
        if (scheme_pos != std::string::npos)
        {
            url = url.substr(scheme_pos + 3);
        }

        // 去掉路径
        size_t path_pos = url.find('/');
        if (path_pos != std::string::npos)
        {
            url = url.substr(0, path_pos);
        }

        // 分离 host:port
        size_t colon_pos = url.find(':');
        if (colon_pos != std::string::npos)
        {
            host = url.substr(0, colon_pos);
            port = std::stoi(url.substr(colon_pos + 1));
        }
        else
        {
            host = url;
        }

       

        Client cli(host.c_str(), port);
        cli.set_connection_timeout(5, 0);
        cli.set_read_timeout(10, 0);
        cli.set_write_timeout(10, 0);

        auto res = cli.Post("/log/report", body, "application/json");

        if (res && res->status == 200)
        {
           
            return true;
        }
        else
        {
            // std::cerr << "[RemoteLogClient] Flush " << batch.entries.size()
            //           << " logs FAILED: "
            //           << (res ? "HTTP " + std::to_string(res->status) : "connection error")
            //           << " -> " << _report_url << std::endl;
            return false;
        }
    }
    catch (const std::exception& e)
    {
        std::cerr << "[RemoteLogClient] Report exception: " << e.what() << std::endl;
        return false;
    }
}

std::vector<LogEntry> RemoteLogClient::_DequeueBatch(size_t max_count)
{
    std::vector<LogEntry> result;
    std::lock_guard<std::mutex> lock(_queue_mutex);

    while (!_log_queue.empty() && result.size() < max_count)
    {
        result.push_back(std::move(_log_queue.front()));
        _log_queue.pop();
    }

    return result;
}

} // namespace remote_log
