/**
 * *****************************************************************************
 * @file        remote_log_config.h
 * @brief       远程日志独立配置文件加载（从 remote_log_config.json 读取）
 * @author      mm
 * @date        2025-06-24
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef _REMOTE_LOG_CONFIG_H_
#define _REMOTE_LOG_CONFIG_H_

#include <string>
#include <fstream>
#include <filesystem>
#include <iostream>

#include <nlohmann/json.hpp>

#include "remote_log_common.h"

namespace remote_log {

/**
 * @class RemoteLogConfigLoader
 * @brief 从独立的 remote_log_config.json 文件加载远程日志配置
 */
class RemoteLogConfigLoader
{
public:
    static constexpr const char* kDefaultConfigFile = "remote_log_config.json";

    /**
     * @brief 默认配置 JSON 模板（文件不存在时自动生成）
     */
    static std::string GetDefaultConfigJson()
    {
        nlohmann::json j;
        j["enable"]              = false;
        j["server_port"]         = 13135;
        j["report_url"]          = "";
        j["report_interval_sec"] = 10;
        j["max_batch_size"]      = 500;
        j["storage_path"]        = "./remote_logs";
        j["console_echo"]        = true;    // 默认回显，方便调试
        j["report_level"]        = 1;      // DEBUG 及以上 (TRACE=0..FATAL=5)
        return j.dump(2);
    }

    /**
     * @brief 从文件加载配置
     * @param config_file 配置文件路径（默认 "remote_log_config.json"）
     * @return RemoteLogConfig 配置结构体
     */
    static RemoteLogConfig Load(const std::string& config_file = kDefaultConfigFile)
    {
        RemoteLogConfig cfg;

        // 确保文件存在
        if (!std::filesystem::exists(config_file))
        {
            std::ofstream ofs(config_file);
            if (ofs.is_open())
            {
                ofs << GetDefaultConfigJson();
                ofs.close();
                std::cout << "[RemoteLogConfig] Created default config: " 
                          << std::filesystem::absolute(config_file).string() << std::endl;
            }
        }

        std::ifstream ifs(config_file);
        if (!ifs.is_open())
        {
            std::cerr << "[RemoteLogConfig] Cannot open config file: " << config_file << std::endl;
            return cfg;
        }

        try
        {
            std::string content((std::istreambuf_iterator<char>(ifs)),
                                std::istreambuf_iterator<char>());
            ifs.close();

            auto j = nlohmann::json::parse(content);

            cfg.enable              = j.value("enable", false);
            cfg.server_port         = j.value("server_port", 13135);
            cfg.report_url          = j.value("report_url", "");
            cfg.report_interval_sec = j.value("report_interval_sec", 10);
            cfg.max_batch_size      = j.value("max_batch_size", 500);
            cfg.storage_path        = j.value("storage_path", "./remote_logs");
            cfg.console_echo        = j.value("console_echo", true);
            cfg.report_level        = j.value("report_level", 1);     // 默认 DEBUG 及以上

            std::cout << "[RemoteLogConfig] Loaded from: " 
                      << std::filesystem::absolute(config_file).string() << std::endl;
        }
        catch (const std::exception& e)
        {
            std::cerr << "[RemoteLogConfig] Parse error: " << e.what() << std::endl;
        }

        return cfg;
    }

    /**
     * @brief 保存配置到文件
     */
    static bool Save(const RemoteLogConfig& cfg, 
                     const std::string& config_file = kDefaultConfigFile)
    {
        nlohmann::json j;
        j["enable"]              = cfg.enable;
        j["server_port"]         = cfg.server_port;
        j["report_url"]          = cfg.report_url;
        j["report_interval_sec"] = cfg.report_interval_sec;
        j["max_batch_size"]      = cfg.max_batch_size;
        j["storage_path"]        = cfg.storage_path;
        j["console_echo"]        = cfg.console_echo;
        j["report_level"]        = cfg.report_level;

        std::ofstream ofs(config_file);
        if (!ofs.is_open())
        {
            return false;
        }
        ofs << j.dump(2);
        ofs.close();
        return true;
    }
};

} // namespace remote_log

#endif // _REMOTE_LOG_CONFIG_H_
