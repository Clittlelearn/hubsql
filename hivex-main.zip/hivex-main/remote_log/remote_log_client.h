/**
 * *****************************************************************************
 * @file        remote_log_client.h
 * @brief       远程日志HTTP客户端 - 定时向目标节点上报日志
 * @author      mm
 * @date        2025-06-24
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef _REMOTE_LOG_CLIENT_H_
#define _REMOTE_LOG_CLIENT_H_

#include <string>
#include <thread>
#include <atomic>
#include <mutex>
#include <queue>
#include <condition_variable>

#include "remote_log_common.h"

namespace remote_log {

/**
 * @class RemoteLogClient
 * @brief 远程日志上报客户端
 * 
 * 运行在普通节点上，收集本地产生的日志，
 * 定时通过HTTP POST将日志批量发送到远程日志服务器。
 */
class RemoteLogClient
{
public:
    RemoteLogClient() = default;
    ~RemoteLogClient();

    RemoteLogClient(const RemoteLogClient&) = delete;
    RemoteLogClient& operator=(const RemoteLogClient&) = delete;

    /**
     * @brief 启动客户端
     * @param report_url      上报目标URL
     * @param node_id         本节点ID
     * @param node_ip         本节点IP
     * @param interval_sec    上报间隔（秒）
     * @param max_batch_size  单次最大批量条数
     * @return true 启动成功
     */
    bool Start(const std::string& report_url,
               const std::string& node_id,
               const std::string& node_ip,
               int interval_sec = 10,
               size_t max_batch_size = 1000);

    /**
     * @brief 停止客户端
     */
    void Stop();

    /**
     * @brief 是否正在运行
     */
    bool IsRunning() const { return _running.load(); }

    /**
     * @brief 提交一条日志到发送队列（线程安全）
     * @param module  来源模块名
     * @param level   日志级别
     * @param message 日志内容
     */
    void PushLog(const std::string& module, Level level, const std::string& file, int line, const std::string& message);

    /**
     * @brief 提交一条日志（C风格字符串版本）
     */
    void PushLog(const char* module, Level level, const char* file, int line, const char* message);

private:
    /**
     * @brief 客户端工作线程主函数
     */
    void _WorkerThread();

    /**
     * @brief 执行批量上报
     */
    bool _FlushBatch();

    /**
     * @brief 从队列中取出最多 max_count 条日志
     */
    std::vector<LogEntry> _DequeueBatch(size_t max_count);

    std::atomic<bool>     _running{false};
    std::thread           _worker;

    std::string           _report_url;
    std::string           _node_id;
    std::string           _node_ip;
    int                   _interval_sec = 10;
    size_t                _max_batch_size = 1000;

    std::mutex            _queue_mutex;
    std::condition_variable _queue_cv;
    std::queue<LogEntry>  _log_queue;

    // 调试统计
    size_t                _total_queued = 0;
    bool                  _first_log_printed = false;
};

} // namespace remote_log

#endif // _REMOTE_LOG_CLIENT_H_
