# JSON 配置发交易测试框架

这个框架用于按 JSON 配置批量发送 raw ETH 交易，调用流程模拟 MetaMask：

1. 构造 raw ETH transaction
2. 本地签名
3. 调用 `eth_sendRawTransaction`
4. 轮询 `eth_getTransactionReceipt`
5. 轮询 `eth_getTransactionByHash`
6. 输出 JSON 报告

## 文件

```text
eth_test/
├── tx_config_runner.mjs       # 配置驱动测试执行器
├── tx_config.example.json     # 示例配置
├── tx_config.fun_eth_all_types.example.json # fun_eth_sendRawTransaction 全业务类型模板
└── tx_config_runner_README.md # 使用说明
```

## 运行

```bash
cd /home/wbl/openhive/eth_test
node tx_config_runner.mjs --config ./tx_config.example.json
```

如果 WSL 里的 Node 版本太低，可以用 Windows Node 执行同一个脚本：

```powershell
$p = wsl -e bash -lc "wslpath -w /home/wbl/openhive/eth_test/tx_config_runner.mjs"
node $p --config \\wsl.localhost\wsl-mm\home\wbl\openhive\eth_test\tx_config.example.json
```

只签名不发送：

```bash
node tx_config_runner.mjs --config ./tx_config.example.json --dry-run
```

全业务类型模板：

```bash
node tx_config_runner.mjs --config ./tx_config.fun_eth_all_types.example.json
```

该模板默认只启用普通 JSON 转账，其它需要真实 UTXO/hash/资格的交易默认 `enabled:false`。填好参数后把对应交易改成 `enabled:true` 即可。

## 顶层配置

```json
{
  "rpcUrl": "http://127.0.0.1:13134",
  "rpcTimeoutMs": 2000,
  "chainId": 12315,
  "dryRunStartNonce": 0,
  "privateKey": "0x...",
  "from": "0x...",
  "reportFile": "./tx_config_report.json",
  "defaults": {
    "gasLimit": "3000000",
    "maxFeePerGasGwei": "1",
    "maxPriorityFeePerGasGwei": "0.5",
    "pollIntervalMs": 3000,
    "receiptTimeoutMs": 120000,
    "stripTransferJsonAmount": true
  },
  "transactions": []
}
```

`stripTransferJsonAmount=true` 会在 `type=tx` / `type=transaction` 时自动去掉 JSON 里的 `amount`，保证和当前 `fun_eth_sendRawTransaction` 规则一致：普通转账金额统一使用 raw ETH tx 的 `value`。

`--dry-run` 模式下如果 RPC 不通，脚本会自动进入离线 dry-run，并使用 `dryRunStartNonce` 作为起始 nonce；真正发送交易时 RPC 不通仍会直接失败。

## 交易配置字段

每笔交易都放在 `transactions` 数组中。

通用字段：

| 字段 | 说明 |
| --- | --- |
| `name` | 交易名称，日志和报告里展示 |
| `saveAs` | 保存本笔交易结果，供后续交易引用 |
| `to` | raw ETH tx 的 `to`；部署合约填 `null` |
| `valueWei` | raw ETH tx 的 value，单位 wei |
| `valueEth` / `valueOhi` | raw ETH tx 的 value，按 18 位精度转换 |
| `gasLimit` | 覆盖默认 gasLimit |
| `maxFeePerGasGwei` | 覆盖默认 maxFeePerGas |
| `maxPriorityFeePerGasGwei` | 覆盖默认 maxPriorityFeePerGas |
| `data` | 直接指定 hex data |
| `dataFile` | 从文件读取 hex data |
| `bytecodeFile` | 从文件读取部署合约 bytecode |
| `jsonData` | 指定自定义 JSON，脚本会自动 UTF-8 转 hex |
| `jsonDataFile` | 从文件读取自定义 JSON |
| `enabled` | `false` 时跳过该用例 |
| `skip` | `true` 时跳过该用例 |
| `reason` | 跳过原因 |
| `expectFailure` | `true` 时，发送失败/查询超时会作为预期失败记录 |

## 支持的 fun_eth_sendRawTransaction JSON 类型

| type | 说明 | 关键字段 |
| --- | --- | --- |
| `tx` | 普通自定义资产转账 | `asset_type`，金额来自 raw tx `value` |
| `transaction` | 普通自定义资产转账别名 | `asset_type`，金额来自 raw tx `value` |
| `stake` | 质押 | `asset_type`, `amount`, `reward_rank` |
| `unstake` | 解除质押 | `asset_type`, `stake_utxo_hash` |
| `delegating` | 委托 | `asset_type`, `amount`, `delegate_type`，目标地址来自 raw tx `to` |
| `delegate` | 委托别名 | 同 `delegating` |
| `undelegating` | 撤销委托 | `asset_type`, `utxo_hash` |
| `undelegate` | 撤销委托别名 | 同 `undelegating` |
| `bonus` | 领取奖励 | `asset_type`, `first_choose` |
| `lock` | 锁仓 | `lock_amount`, `lock_type` |
| `unlock` | 解锁 | `utxo_hash` |
| `vote` | 投票 | `vote_hash`, `vote` |
| `proposal` | 提案投票包装 | `vote_hash` 或 `proposal_hash` |
| `revoke_proposal` | 撤销提案包装 | `vote_hash` 或 `proposal_hash` |
| `revokeProposal` | 撤销提案别名 | 同 `revoke_proposal` |
| `fund` | 国库奖励 | `is_find_utxo`, `encoded_info` |
| `treasury` | 国库奖励别名 | 同 `fund` |

## JSON 自定义转账示例

```json
{
  "name": "json OHI transfer",
  "to": "0x000000000000000000000000000000000000dEaD",
  "valueEth": "0.00000001",
  "jsonData": {
    "type": "tx",
    "asset_type": "OHI",
    "is_find_utxo": false,
    "sponsor_gas": false,
    "encoded_info": "config runner json OHI transfer"
  }
}
```

注意：普通转账不要在 `jsonData` 里写 `amount`，金额写到 raw ETH tx 的 `valueEth` / `valueWei`。

## 合约部署示例

```json
{
  "name": "deploy contract",
  "saveAs": "deployStoreContract",
  "to": null,
  "valueWei": "0",
  "bytecodeFile": "./contract/contract.txt"
}
```

## 引用前面交易结果

如果某笔交易设置了：

```json
{
  "saveAs": "deployStoreContract"
}
```

后续交易可以这样引用合约地址：

```json
{
  "to": "$results.deployStoreContract.contractAddress"
}
```

也可以在字符串中插值：

```json
{
  "name": "call ${results.deployStoreContract.contractAddress}"
}
```

## 输出报告

执行完成后会写入 `reportFile`，默认可以在配置里设置：

```json
{
  "reportFile": "./tx_config_report.json"
}
```

报告里会包含每笔交易的：

- `localHash`
- `rpcHash`
- `receipt`
- `tx`
- `status`
- `blockNumber`
- `contractAddress`
