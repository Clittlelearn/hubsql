#!/usr/bin/env node
import { parseArgs, sendJsonRawTx } from "./raw_tx_test_utils.mjs";

function usage() {
  console.log(`
Usage:
  PRIVATE_KEY=<hex> node test_unstake_once.mjs --stake-utxo-hash <hash>

Options:
  --asset-type <asset>        Default: OHI
  --stake-utxo-hash <hash>    Required unless STAKE_UTXO_HASH is set
  --find-utxo                 Set is_find_utxo=true
  --sponsor-gas               Set sponsor_gas=true
  --encoded-info <text>       Default: fun_eth unstake
  --nonce <nonce>             Use explicit nonce; useful with --dry-run
  --dry-run                   Sign only, do not send
`);
}

const args = parseArgs(process.argv.slice(2));
if (args.help) {
  usage();
  process.exit(0);
}

const stakeUtxoHash = args.stakeUtxoHash || process.env.STAKE_UTXO_HASH;
if (!stakeUtxoHash && !args.dryRun) throw new Error("Missing --stake-utxo-hash <hash>");

const payload = {
  type: "unstake",
  asset_type: args.assetType || process.env.ASSET_TYPE || "OHI",
  stake_utxo_hash: stakeUtxoHash || "0xCHANGE_ME_STAKE_UTXO_HASH",
  is_find_utxo: args.isFindUtxo === true,
  sponsor_gas: args.sponsorGas === true,
  encoded_info: args.encodedInfo || process.env.ENCODED_INFO || "fun_eth unstake",
};

sendJsonRawTx("unstake", payload, args).catch((err) => {
  console.error(`FAILED: ${err.stack || err.message}`);
  process.exitCode = 1;
});
