# fun_eth_sendRawTransaction 单交易测试脚本

这些脚本用于按 MetaMask/raw ETH tx 流程测试 `fun_eth_sendRawTransaction`：

1. 组装业务 JSON 到 raw ETH tx 的 `data` 字段。
2. 使用私钥签名 raw ETH tx。
3. 调用 `eth_sendRawTransaction`。
4. 持续轮询 `eth_getTransactionReceipt` 和 `eth_getTransactionByHash`。

## 准备

```bash
cd /home/wbl/openhive/eth_test
node -v
```

需要 Node.js 18+。当前项目中已使用 ethers v6。

不要把真实私钥写入脚本。建议使用环境变量：

```bash
export PRIVATE_KEY=<hex_private_key>
```

公共参数：

```text
--rpc <url>                 默认 http://127.0.0.1:13134
--chain-id <id>             默认 12315
--to <address>              raw ETH tx 的 to 地址
--json-to <address>         写入 data JSON 的业务 to 地址
--value-wei <wei>           raw ETH tx 的 Value
--nonce <nonce>             指定 nonce，常用于离线 dry-run
--gas-limit <gas>           默认 3000000
--max-fee-gwei <gwei>       默认 1
--priority-fee-gwei <gwei>  默认 0.5
--timeout-ms <ms>           receipt/byHash 轮询超时，默认 180000
--poll-ms <ms>              轮询间隔，默认 3000
--dry-run                   只签名，不发送
```

离线检查脚本是否能生成非空 data：

```bash
PRIVATE_KEY=0000000000000000000000000000000000000000000000000000000000000001 \
node test_fund_once.mjs --dry-run --nonce 0
```

## 脚本列表

### 普通转账 tx

`data.type = "tx"`，转账金额统一使用 raw ETH tx 的 `value`。

当业务收款地址需要等于发起人 `from` 时，raw ETH tx 的 `--to` 使用一个占位地址，真实业务收款地址放到 `--json-to`。

```bash
PRIVATE_KEY=<hex> node test_tx_once.mjs \
  --to 0x000000000000000000000000000000000000dEaD \
  --json-to 0x<business_receiver> \
  --value-wei 10000000000 \
  --asset-type OHI
```

### stake

```bash
PRIVATE_KEY=<hex> node test_stake_once.mjs \
  --amount 1000000 \
  --reward-rank 10 \
  --asset-type OHI
```

### unstake

```bash
PRIVATE_KEY=<hex> node test_unstake_once.mjs \
  --stake-utxo-hash 0x<stake_utxo_hash> \
  --asset-type OHI
```

### delegating

业务被委托节点地址放在 JSON `to`，raw ETH tx 的 `to` 可以使用占位地址。

```bash
PRIVATE_KEY=<hex> node test_delegating_once.mjs \
  --to 0x000000000000000000000000000000000000dEaD \
  --json-to 0x<validator_address> \
  --amount 1000000 \
  --delegate-type 1 \
  --asset-type OHI
```

### undelegating

```bash
PRIVATE_KEY=<hex> node test_undelegating_once.mjs \
  --to 0x000000000000000000000000000000000000dEaD \
  --json-to 0x<validator_address> \
  --utxo-hash 0x<delegating_utxo_hash> \
  --asset-type OHI
```

### bonus

```bash
PRIVATE_KEY=<hex> node test_bonus_once.mjs \
  --asset-type OHI
```

可选：

```bash
--first-choose
--find-utxo
--sponsor-gas
```

### lock

```bash
PRIVATE_KEY=<hex> node test_lock_once.mjs \
  --lock-amount 1000000 \
  --lock-type 1
```

### unlock

```bash
PRIVATE_KEY=<hex> node test_unlock_once.mjs \
  --utxo-hash 0x<lock_utxo_hash>
```

### vote

```bash
PRIVATE_KEY=<hex> node test_vote_once.mjs \
  --vote-hash 0x<vote_or_proposal_hash> \
  --vote 1
```

### proposal

```bash
PRIVATE_KEY=<hex> node test_proposal_once.mjs \
  --vote-hash 0x<proposal_hash>
```

### revoke_proposal

```bash
PRIVATE_KEY=<hex> node test_revoke_proposal_once.mjs \
  --vote-hash 0x<proposal_hash>
```

也可以使用：

```bash
--proposal-hash 0x<proposal_hash>
```

### fund

一个账户只能 fund 一次。测试时每次换新私钥。

```bash
PRIVATE_KEY=<hex> node test_fund_once.mjs
```

## 类型别名

RPC 分发中还支持这些别名：

```text
transaction -> tx
delegate -> delegating
undelegate -> undelegating
revokeProposal -> revoke_proposal
treasury -> fund
```

当前单独脚本默认使用主类型。如果需要专门测别名，可以复制对应脚本，把 payload 里的 `type` 改成别名。

## JSON to 与 raw ETH to

自定义 JSON 交易中，业务 `to` 地址使用 data JSON 内的 `to` 字段。raw ETH 标准 `to` 地址只作为旧请求兼容 fallback。

这样可以绕开 MetaMask 不允许 `to == from` 的限制：

```bash
PRIVATE_KEY=<hex> node test_tx_once.mjs \
  --to 0x000000000000000000000000000000000000dEaD \
  --json-to 0x<same_as_from> \
  --value-wei 10000000000
```

## 输出说明

成功发送后会打印：

```text
localHash: raw ETH tx hash
rpcHash: 节点返回的内部 hash
eth_getTransactionReceipt: ok
eth_getTransactionByHash: ok
receiptStatus
receiptBlockNumber
byHashBlockNumber
```

如果 receipt/byHash 长时间为 `null`，看 `build/bin/remote_logs` 中对应 `rpcHash` 的错误。
