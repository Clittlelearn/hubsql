#!/usr/bin/env node
import { parseArgs, sendJsonRawTx } from "./raw_tx_test_utils.mjs";

function usage() {
  console.log(`
Usage:
  PRIVATE_KEY=<hex> node test_undelegating_once.mjs --json-to <validator> --utxo-hash <hash>

Options:
  --json-to <address>         Business validator address written into JSON data
  --asset-type <asset>        Default: OHI
  --utxo-hash <hash>          Required unless UTXO_HASH is set
  --find-utxo                 Set is_find_utxo=true
  --sponsor-gas               Set sponsor_gas=true
  --encoded-info <text>       Default: fun_eth undelegating
  --nonce <nonce>             Use explicit nonce; useful with --dry-run
  --dry-run                   Sign only, do not send
`);
}

const args = parseArgs(process.argv.slice(2));
if (args.help) {
  usage();
  process.exit(0);
}

const utxoHash = args.utxoHash || process.env.UTXO_HASH;
if (!utxoHash && !args.dryRun) throw new Error("Missing --utxo-hash <hash>");

const payload = {
  type: "undelegating",
  to: args.jsonTo || process.env.JSON_TO || args.to,
  asset_type: args.assetType || process.env.ASSET_TYPE || "OHI",
  utxo_hash: utxoHash || "0xCHANGE_ME_DELEGATING_UTXO_HASH",
  is_find_utxo: args.isFindUtxo === true,
  sponsor_gas: args.sponsorGas === true,
  encoded_info: args.encodedInfo || process.env.ENCODED_INFO || "fun_eth undelegating",
};

sendJsonRawTx("undelegating", payload, args).catch((err) => {
  console.error(`FAILED: ${err.stack || err.message}`);
  process.exitCode = 1;
});
