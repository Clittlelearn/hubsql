#!/usr/bin/env node
import { parseArgs, sendJsonRawTx } from "./raw_tx_test_utils.mjs";

function usage() {
  console.log(`
Usage:
  PRIVATE_KEY=<hex> node test_stake_once.mjs --amount <amount>

Options:
  --asset-type <asset>        Default: OHI
  --amount <amount>           Stake amount, default 1000000
  --reward-rank <rank>        Default: 10
  --find-utxo                 Set is_find_utxo=true
  --sponsor-gas               Set sponsor_gas=true
  --encoded-info <text>       Default: fun_eth stake
  --nonce <nonce>             Use explicit nonce; useful with --dry-run
  --dry-run                   Sign only, do not send
`);
}

const args = parseArgs(process.argv.slice(2));
if (args.help) {
  usage();
  process.exit(0);
}

const payload = {
  type: "stake",
  asset_type: args.assetType || process.env.ASSET_TYPE || "OHI",
  amount: args.amount || process.env.AMOUNT || "1000000",
  reward_rank: args.rewardRank || process.env.REWARD_RANK || "10",
  is_find_utxo: args.isFindUtxo === true,
  sponsor_gas: args.sponsorGas === true,
  encoded_info: args.encodedInfo || process.env.ENCODED_INFO || "fun_eth stake",
};

sendJsonRawTx("stake", payload, args).catch((err) => {
  console.error(`FAILED: ${err.stack || err.message}`);
  process.exitCode = 1;
});
