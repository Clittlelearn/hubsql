#!/usr/bin/env node
import { parseArgs, sendJsonRawTx } from "./raw_tx_test_utils.mjs";

function usage() {
  console.log(`
Usage:
  PRIVATE_KEY=<hex> node test_fund_once.mjs
  node test_fund_once.mjs --private-key <hex> [options]

Options:
  --rpc <url>                 Default: http://127.0.0.1:13134
  --chain-id <id>             Default: 12315
  --find-utxo                 Set is_find_utxo=true
  --encoded-info <text>       Default: fun_eth fund
  --to <address>              Raw ETH tx to address, default dead address
  --nonce <nonce>             Use explicit nonce; useful with --dry-run
  --value-wei <wei>           Raw ETH tx value, default 0
  --dry-run                   Sign only, do not send
`);
}

const args = parseArgs(process.argv.slice(2));
if (args.help) {
  usage();
  process.exit(0);
}

const payload = {
  type: "fund",
  is_find_utxo: args.isFindUtxo === true,
  encoded_info: args.encodedInfo || process.env.ENCODED_INFO || "fun_eth fund",
};

sendJsonRawTx("fund", payload, args).catch((err) => {
  console.error(`FAILED: ${err.stack || err.message}`);
  process.exitCode = 1;
});
