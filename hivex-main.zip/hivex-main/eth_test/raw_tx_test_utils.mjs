import { ethers } from "ethers";

export function parseArgs(argv) {
  const args = {};
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") args.help = true;
    else if (arg === "--rpc") args.rpcUrl = argv[++i];
    else if (arg === "--private-key" || arg === "--prikey") args.privateKey = argv[++i];
    else if (arg === "--chain-id") args.chainId = argv[++i];
    else if (arg === "--to") args.to = argv[++i];
    else if (arg === "--json-to") args.jsonTo = argv[++i];
    else if (arg === "--nonce") args.nonce = argv[++i];
    else if (arg === "--value-wei") args.valueWei = argv[++i];
    else if (arg === "--gas-limit") args.gasLimit = argv[++i];
    else if (arg === "--max-fee-gwei") args.maxFeePerGasGwei = argv[++i];
    else if (arg === "--priority-fee-gwei") args.maxPriorityFeePerGasGwei = argv[++i];
    else if (arg === "--timeout-ms") args.receiptTimeoutMs = argv[++i];
    else if (arg === "--poll-ms") args.pollIntervalMs = argv[++i];
    else if (arg === "--encoded-info") args.encodedInfo = argv[++i];
    else if (arg === "--asset-type") args.assetType = argv[++i];
    else if (arg === "--amount") args.amount = argv[++i];
    else if (arg === "--reward-rank") args.rewardRank = argv[++i];
    else if (arg === "--delegate-type") args.delegateType = argv[++i];
    else if (arg === "--utxo-hash") args.utxoHash = argv[++i];
    else if (arg === "--stake-utxo-hash") args.stakeUtxoHash = argv[++i];
    else if (arg === "--lock-amount") args.lockAmount = argv[++i];
    else if (arg === "--lock-type") args.lockType = argv[++i];
    else if (arg === "--vote-hash") args.voteHash = argv[++i];
    else if (arg === "--proposal-hash") args.proposalHash = argv[++i];
    else if (arg === "--vote") args.vote = argv[++i];
    else if (arg === "--first-choose") args.firstChoose = true;
    else if (arg === "--find-utxo") args.isFindUtxo = true;
    else if (arg === "--sponsor-gas") args.sponsorGas = true;
    else if (arg === "--dry-run") args.dryRun = true;
    else throw new Error(`Unknown argument: ${arg}`);
  }
  return args;
}

export function normalize0x(value) {
  if (!value) return value;
  return value.startsWith("0x") ? value : `0x${value}`;
}

export function jsonToData(payload) {
  return `0x${Buffer.from(JSON.stringify(payload), "utf8").toString("hex")}`;
}

export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export class RpcClient {
  constructor(url, timeoutMs = 15000) {
    this.url = url;
    this.timeoutMs = timeoutMs;
    this.id = 0;
  }

  async call(method, params = []) {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), this.timeoutMs);
    try {
      const resp = await fetch(this.url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", method, params, id: ++this.id }),
        signal: ac.signal,
      });
      const json = await resp.json();
      if (json.error) {
        const err = new Error(`${method}: ${json.error.message || JSON.stringify(json.error)}`);
        err.rpc = json;
        throw err;
      }
      return json.result;
    } finally {
      clearTimeout(timer);
    }
  }
}

export async function waitForMetaMaskQueries(rpc, label, localHash, rpcHash, options) {
  const hashes = [...new Set([localHash, rpcHash].filter(Boolean))];
  const startedAt = Date.now();
  let receipt = null;
  let tx = null;
  let lastError = "";

  while (Date.now() - startedAt <= options.receiptTimeoutMs) {
    for (const hash of hashes) {
      try {
        if (!receipt) receipt = await rpc.call("eth_getTransactionReceipt", [hash]);
        if (!tx) tx = await rpc.call("eth_getTransactionByHash", [hash]);
        if (receipt && tx) {
          console.log(`eth_getTransactionReceipt: ok`);
          console.log(`eth_getTransactionByHash: ok`);
          return { receipt, tx };
        }
      } catch (err) {
        lastError = err.message;
      }
    }

    console.log(`polling ${label}: receipt=${receipt ? "yes" : "null"} tx=${tx ? "yes" : "null"}`);
    await sleep(options.pollIntervalMs);
  }

  throw new Error(
    `Timeout waiting for ${label}: receipt=${receipt ? "yes" : "null"} tx=${
      tx ? "yes" : "null"
    } lastError=${lastError}`,
  );
}

export async function sendJsonRawTx(label, payload, args) {
  const privateKey = args.privateKey || process.env.PRIVATE_KEY;
  if (!privateKey) throw new Error("Missing private key. Use --private-key <hex> or PRIVATE_KEY=<hex>.");

  const rpcUrl = args.rpcUrl || process.env.RPC_URL || "http://192.168.1.106:13134";
  const chainId = BigInt(args.chainId || process.env.CHAIN_ID || "12315");
  const rpcTimeoutMs = Number(process.env.RPC_TIMEOUT_MS || "15000");
  const receiptTimeoutMs = Number(args.receiptTimeoutMs || process.env.RECEIPT_TIMEOUT_MS || "180000");
  const pollIntervalMs = Number(args.pollIntervalMs || process.env.POLL_INTERVAL_MS || "3000");
  const to = args.to || process.env.TX_TO || "0x000000000000000000000000000000000000dEaD";
  const valueWei = BigInt(args.valueWei || process.env.VALUE_WEI || "0");
  const gasLimit = BigInt(args.gasLimit || process.env.GAS_LIMIT || "3000000");
  const maxFeePerGasGwei = args.maxFeePerGasGwei || process.env.MAX_FEE_GWEI || "1";
  const maxPriorityFeePerGasGwei = args.maxPriorityFeePerGasGwei || process.env.PRIORITY_FEE_GWEI || "0.5";

  const rpc = new RpcClient(rpcUrl, rpcTimeoutMs);
  const wallet = new ethers.Wallet(normalize0x(privateKey));
  const from = wallet.address;
  const nonce =
    args.nonce != null
      ? Number(BigInt(args.nonce))
      : Number(BigInt(await rpc.call("eth_getTransactionCount", [from, "latest"])));
  const data = jsonToData(payload);

  const request = {
    type: 2,
    chainId,
    nonce,
    to,
    value: valueWei,
    data,
    gasLimit,
    maxFeePerGas: ethers.parseUnits(String(maxFeePerGasGwei), "gwei"),
    maxPriorityFeePerGas: ethers.parseUnits(String(maxPriorityFeePerGasGwei), "gwei"),
  };

  const rawTx = await wallet.signTransaction(request);
  const parsed = ethers.Transaction.from(rawTx);

  console.log(`rpcUrl: ${rpcUrl}`);
  console.log(`from: ${from}`);
  console.log(`nonce: ${nonce}`);
  console.log(`type: ${payload.type}`);
  console.log(`dataBytes: ${(data.length - 2) / 2}`);
  console.log(`localHash: ${parsed.hash}`);

  if (args.dryRun) {
    console.log(`dryRun: true`);
    console.log(`rawTx: ${rawTx}`);
    return { localHash: parsed.hash, rawTx };
  }

  const rpcHash = await rpc.call("eth_sendRawTransaction", [rawTx]);
  console.log(`rpcHash: ${rpcHash}`);

  const queried = await waitForMetaMaskQueries(rpc, label, parsed.hash, rpcHash, {
    receiptTimeoutMs,
    pollIntervalMs,
  });

  console.log(`receiptStatus: ${queried.receipt?.status ?? null}`);
  console.log(`receiptBlockNumber: ${queried.receipt?.blockNumber ?? null}`);
  console.log(`byHashBlockNumber: ${queried.tx?.blockNumber ?? null}`);
  return { localHash: parsed.hash, rpcHash, ...queried };
}
