#!/usr/bin/env node
import { ethers } from "ethers";

const rpcUrl = process.env.RPC_URL || "http://127.0.0.1:13134";
const chainId = 12315n;
const privateKey = "0x8fc570d5311a0ac6b72e7996a6f0cf473b1765518fe7b8a76612782c062507fa";
const from = "0x755Ccf704E17570b64E247f0794314e4C8E542CA";
const to = "0x45d786f7159368ceE858402794CF6B4c9daF38E4";
const data = "0x6e27d889000000000000000000000000000000000000000000000000000000003b9aca00";

let id = 0;

async function rpc(method, params = []) {
  const resp = await fetch(rpcUrl, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", method, params, id: ++id }),
  });
  const json = await resp.json();
  if (json.error) {
    const extra = json.error.data ? ` data=${json.error.data}` : "";
    throw new Error(`${method}: ${json.error.message}${extra}`);
  }
  return json.result;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function pollHash(label, hash) {
  for (let i = 0; i < 60; i += 1) {
    const receipt = await rpc("eth_getTransactionReceipt", [hash]);
    const tx = await rpc("eth_getTransactionByHash", [hash]);
    console.log(`${label} poll=${i} receipt=${receipt ? "yes" : "null"} tx=${tx ? "yes" : "null"}`);
    if (receipt || tx) {
      console.log(`${label} receiptJson=${JSON.stringify(receipt)}`);
      console.log(`${label} txJson=${JSON.stringify(tx)}`);
      return { receipt, tx };
    }
    await sleep(3000);
  }
  return { receipt: null, tx: null };
}

async function main() {
  const [rpcChainId, blockNumber, code, nonceHex] = await Promise.all([
    rpc("eth_chainId"),
    rpc("eth_blockNumber"),
    rpc("eth_getCode", [to, "latest"]),
    rpc("eth_getTransactionCount", [from, "latest"]),
  ]);

  console.log(`rpcUrl=${rpcUrl}`);
  console.log(`chainId=${rpcChainId}`);
  console.log(`blockNumber=${blockNumber}`);
  console.log(`contractCodeBytes=${(code.length - 2) / 2}`);

  if (!code || code === "0x") {
    throw new Error(`contract code is empty at ${to}`);
  }

  const nonce = Number(BigInt(nonceHex));
  const raw = await new ethers.Wallet(privateKey).signTransaction({
    type: 2,
    chainId,
    nonce,
    to,
    value: 0n,
    data,
    gasLimit: 3000000n,
    maxFeePerGas: ethers.parseUnits("1", "gwei"),
    maxPriorityFeePerGas: ethers.parseUnits("0.5", "gwei"),
  });

  const localHash = ethers.Transaction.from(raw).hash;
  console.log(`nonce=${nonce}`);
  console.log(`localHash=${localHash}`);
  const rpcHash = await rpc("eth_sendRawTransaction", [raw]);
  console.log(`rpcHash=${rpcHash}`);

  const hashes = [...new Set([localHash, rpcHash].filter(Boolean))];
  for (const hash of hashes) {
    await pollHash(hash === localHash ? "localHash" : "rpcHash", hash);
  }
}

main().catch((err) => {
  console.error(`FAILED: ${err.stack || err.message}`);
  process.exitCode = 1;
});
