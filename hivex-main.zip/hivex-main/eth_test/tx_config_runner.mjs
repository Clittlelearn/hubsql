#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
let ethers;

function usage() {
  console.log(`
Usage:
  node tx_config_runner.mjs --config ./tx_config.example.json

Options:
  --config <file>      JSON config file
  --dry-run            Build and sign transactions, but do not send
  --help               Show help
`);
}

function parseArgs(argv) {
  const args = { dryRun: false };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--config" || arg === "-c") args.config = argv[++i];
    else if (arg === "--dry-run") args.dryRun = true;
    else if (arg === "--help" || arg === "-h") args.help = true;
    else throw new Error(`Unknown argument: ${arg}`);
  }
  return args;
}

async function loadEthers() {
  const major = Number(process.versions.node.split(".")[0]);
  if (major < 18) {
    throw new Error(
      `Node.js ${process.versions.node} is too old for ethers@6. Please run with Node.js >= 18.`,
    );
  }
  const mod = await import("ethers");
  ethers = mod.ethers;
}

class RpcClient {
  constructor(url, timeoutMs = 15000) {
    this.url = url;
    this.timeoutMs = timeoutMs;
    this.id = 0;
  }

  async call(method, params = []) {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), this.timeoutMs);
    try {
      const resp = await fetch(this.url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", method, params, id: ++this.id }),
        signal: ac.signal,
      });
      const json = await resp.json();
      if (json.error) {
        const err = new Error(`${method}: ${json.error.message || JSON.stringify(json.error)}`);
        err.rpc = json;
        throw err;
      }
      return json.result;
    } finally {
      clearTimeout(timer);
    }
  }
}

function normalize0x(value) {
  if (!value) return value;
  return value.startsWith("0x") ? value : `0x${value}`;
}

function strip0x(value) {
  return value && value.startsWith("0x") ? value.slice(2) : value;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function readHexFile(file) {
  const text = fs.readFileSync(file, "utf8").trim();
  return normalize0x(text);
}

function jsonToData(payload) {
  return `0x${Buffer.from(JSON.stringify(payload), "utf8").toString("hex")}`;
}

function hasNonEmptyData(value) {
  return value != null && String(value).trim() !== "";
}

function parseBigNumberish(value, fieldName) {
  if (value == null || value === "") return 0n;
  if (typeof value === "bigint") return value;
  if (typeof value === "number") return BigInt(value);
  if (typeof value === "string") return BigInt(value);
  throw new Error(`${fieldName} must be a number/string/bigint`);
}

function parseValue(tx) {
  if (tx.valueWei != null) return parseBigNumberish(tx.valueWei, "valueWei");
  if (tx.valueEth != null) return ethers.parseUnits(String(tx.valueEth), 18);
  if (tx.valueOhi != null) return ethers.parseUnits(String(tx.valueOhi), 18);
  return 0n;
}

function parseGas(value, fallback, fieldName) {
  if (value == null) return fallback;
  return parseBigNumberish(value, fieldName);
}

function unique(values) {
  return [...new Set(values.filter(Boolean))];
}

function setDeep(target, key, value) {
  target[key] = value;
  return target;
}

function getDeep(target, expr) {
  return expr.split(".").reduce((cur, part) => {
    if (cur == null) return undefined;
    return cur[part];
  }, target);
}

function resolveRefs(value, context) {
  if (Array.isArray(value)) return value.map((item) => resolveRefs(item, context));
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [key, resolveRefs(item, context)]),
    );
  }
  if (typeof value !== "string") return value;

  const direct = value.match(/^\$([A-Za-z0-9_.-]+)$/);
  if (direct) {
    const found = getDeep(context, direct[1]);
    if (found === undefined) throw new Error(`Cannot resolve config reference: ${value}`);
    return found;
  }

  return value.replace(/\$\{([A-Za-z0-9_.-]+)\}/g, (_, expr) => {
    const found = getDeep(context, expr);
    if (found === undefined) throw new Error(`Cannot resolve config reference: \${${expr}}`);
    return String(found);
  });
}

function removeEmptyGasAsset(payload) {
  if (!payload || typeof payload !== "object") return payload;
  if (payload.gas_asset && typeof payload.gas_asset === "object") {
    const gasAsset = Object.fromEntries(
      Object.entries(payload.gas_asset).filter(([, value]) => value != null && value !== ""),
    );
    if (Object.keys(gasAsset).length) payload.gas_asset = gasAsset;
    else delete payload.gas_asset;
  }
  return payload;
}

function normalizeBusinessJson(payload, stripTransferAmount) {
  const normalized = {
    ...payload,
    is_find_utxo: payload.is_find_utxo == null ? false : payload.is_find_utxo,
    sponsor_gas: payload.sponsor_gas == null ? false : payload.sponsor_gas,
    encoded_info: payload.encoded_info == null ? "" : payload.encoded_info,
  };
  removeEmptyGasAsset(normalized);
  if (
    stripTransferAmount &&
    (normalized.type === "tx" || normalized.type === "transaction") &&
    Object.prototype.hasOwnProperty.call(normalized, "amount")
  ) {
    delete normalized.amount;
  }
  return normalized;
}

class ConfigRunner {
  constructor(config, configFile, dryRun) {
    this.config = config;
    this.configFile = configFile;
    this.configDir = path.dirname(configFile);
    this.dryRun = dryRun;
    this.rpc = new RpcClient(config.rpcUrl || "http://127.0.0.1:13134", config.rpcTimeoutMs);
    this.wallet = new ethers.Wallet(normalize0x(config.privateKey));
    this.from = config.from || this.wallet.address;
    const defaults = config.defaults || {};
    this.chainId = BigInt(config.chainId == null ? 12315 : config.chainId);
    this.defaults = {
      gasLimit: parseBigNumberish(defaults.gasLimit == null ? "3000000" : defaults.gasLimit, "defaults.gasLimit"),
      maxFeePerGas: ethers.parseUnits(String(defaults.maxFeePerGasGwei == null ? "1" : defaults.maxFeePerGasGwei), "gwei"),
      maxPriorityFeePerGas: ethers.parseUnits(
        String(defaults.maxPriorityFeePerGasGwei == null ? "0.5" : defaults.maxPriorityFeePerGasGwei),
        "gwei",
      ),
      pollIntervalMs: Number(defaults.pollIntervalMs == null ? 3000 : defaults.pollIntervalMs),
      receiptTimeoutMs: Number(defaults.receiptTimeoutMs == null ? 120000 : defaults.receiptTimeoutMs),
      stripTransferJsonAmount: defaults.stripTransferJsonAmount == null ? true : defaults.stripTransferJsonAmount,
      continueOnError: defaults.continueOnError == null ? false : defaults.continueOnError,
    };
    this.nextNonce = null;
    this.context = { config: this.config, results: {} };
    this.report = {
      startedAt: new Date().toISOString(),
      rpcUrl: this.rpc.url,
      chainId: String(this.chainId),
      from: this.from,
      dryRun: this.dryRun,
      transactions: [],
    };
  }

  resolveFile(file) {
    if (path.isAbsolute(file)) return file;
    return path.resolve(this.configDir, file);
  }

  async init() {
    let rpcChainId = null;
    try {
      rpcChainId = await this.rpc.call("eth_chainId");
      this.nextNonce = Number(BigInt(await this.rpc.call("eth_getTransactionCount", [this.from, "latest"])));
    } catch (err) {
      if (!this.dryRun) throw err;
      this.nextNonce = Number(this.config.dryRunStartNonce == null ? 0 : this.config.dryRunStartNonce);
      this.report.offlineDryRun = true;
      this.report.rpcInitError = err.message;
      console.log(`RPC init failed in dry-run mode, using dryRunStartNonce=${this.nextNonce}`);
    }
    this.report.rpcChainId = rpcChainId;
    this.report.startNonce = this.nextNonce;
    console.log(`RPC: ${this.rpc.url}`);
    console.log(`chainId: ${rpcChainId ? `${BigInt(rpcChainId)} (${rpcChainId})` : `${this.chainId} (config)`}`);
    console.log(`from: ${this.from}`);
    console.log(`start nonce: ${this.nextNonce}`);
  }

  buildData(tx) {
    if (hasNonEmptyData(tx.data)) return normalize0x(tx.data);
    if (tx.dataFile) return readHexFile(this.resolveFile(tx.dataFile));
    if (tx.bytecodeFile) return readHexFile(this.resolveFile(tx.bytecodeFile));

    if (tx.jsonData || tx.jsonDataFile) {
      const payload = tx.jsonDataFile ? readJson(this.resolveFile(tx.jsonDataFile)) : tx.jsonData;
      const normalized = normalizeBusinessJson(payload, this.defaults.stripTransferJsonAmount);
      return jsonToData(normalized);
    }

    return "0x";
  }

  async sign(tx, index) {
    const resolved = resolveRefs(tx, this.context);
    const nonce = resolved.nonce == null ? this.nextNonce++ : Number(resolved.nonce);
    const request = {
      type: resolved.eip1559 === false ? 0 : 2,
      chainId: BigInt(resolved.chainId == null ? this.chainId : resolved.chainId),
      nonce,
      to: resolved.to === null ? undefined : resolved.to,
      value: parseValue(resolved),
      data: this.buildData(resolved),
      gasLimit: parseGas(resolved.gasLimit, this.defaults.gasLimit, `transactions[${index}].gasLimit`),
    };
    if ((resolved.jsonData || resolved.jsonDataFile) && (!request.data || request.data === "0x")) {
      throw new Error(`transactions[${index}] has jsonData/jsonDataFile but generated empty data`);
    }

    if (request.type === 2) {
      request.maxFeePerGas = resolved.maxFeePerGasGwei
        ? ethers.parseUnits(String(resolved.maxFeePerGasGwei), "gwei")
        : this.defaults.maxFeePerGas;
      request.maxPriorityFeePerGas = resolved.maxPriorityFeePerGasGwei
        ? ethers.parseUnits(String(resolved.maxPriorityFeePerGasGwei), "gwei")
        : this.defaults.maxPriorityFeePerGas;
    } else {
      request.gasPrice = resolved.gasPriceGwei
        ? ethers.parseUnits(String(resolved.gasPriceGwei), "gwei")
        : this.defaults.maxFeePerGas;
    }

    const rawTx = await this.wallet.signTransaction(request);
    const parsed = ethers.Transaction.from(rawTx);
    return { resolved, request, rawTx, localHash: parsed.hash, nonce };
  }

  async waitForMetaMaskQueries(label, localHash, rpcHash) {
    const hashes = unique([localHash, rpcHash]);
    const startedAt = Date.now();
    let receipt = null;
    let tx = null;
    let lastError = "";

    while (Date.now() - startedAt <= this.defaults.receiptTimeoutMs) {
      for (const hash of hashes) {
        try {
          if (!receipt) receipt = await this.rpc.call("eth_getTransactionReceipt", [hash]);
          if (!tx) tx = await this.rpc.call("eth_getTransactionByHash", [hash]);
          if (receipt && tx) {
            console.log(`  eth_getTransactionReceipt: ok`);
            console.log(`  eth_getTransactionByHash: ok`);
            return { receipt, tx };
          }
        } catch (err) {
          lastError = err.message;
        }
      }
      console.log(`  polling ${label}: receipt=${receipt ? "yes" : "null"} tx=${tx ? "yes" : "null"}`);
      await sleep(this.defaults.pollIntervalMs);
    }

    throw new Error(
      `Timeout waiting for ${label}: receipt=${receipt ? "yes" : "null"} tx=${
        tx ? "yes" : "null"
      } lastError=${lastError}`,
    );
  }

  async runOne(tx, index) {
    const label = tx.name || `tx-${index + 1}`;
    if (tx.enabled === false || tx.skip === true) {
      const item = {
        name: label,
        skipped: true,
        reason: tx.reason || "disabled by config",
      };
      console.log(`\n=== ${label} ===`);
      console.log(`  skipped: ${item.reason}`);
      if (tx.saveAs) setDeep(this.context.results, tx.saveAs, item);
      this.report.transactions.push(item);
      return;
    }

    console.log(`\n=== ${label} ===`);
    let item = { name: label };
    try {
      const signed = await this.sign(tx, index);
      console.log(`  nonce: ${signed.nonce}`);
      console.log(`  localHash: ${signed.localHash}`);

      item = {
        ...item,
        nonce: signed.nonce,
        localHash: signed.localHash,
        to: signed.request.to || null,
        valueWei: signed.request.value.toString(),
        dataBytes: Math.max(0, (signed.request.data.length - 2) / 2),
        jsonType: signed.resolved.jsonData && signed.resolved.jsonData.type ? signed.resolved.jsonData.type : null,
      };

      if (this.dryRun || signed.resolved.dryRun) {
        item.dryRun = true;
        item.rawTx = signed.rawTx;
        console.log("  dry-run: not sent");
      } else {
        item.rpcHash = await this.rpc.call("eth_sendRawTransaction", [signed.rawTx]);
        console.log(`  rpcHash: ${item.rpcHash}`);
        const queried = await this.waitForMetaMaskQueries(label, signed.localHash, item.rpcHash);
        item.receipt = queried.receipt;
        item.tx = queried.tx;
        item.status = queried.receipt && queried.receipt.status != null ? queried.receipt.status : null;
        item.blockNumber = queried.receipt && queried.receipt.blockNumber != null ? queried.receipt.blockNumber : null;
        item.contractAddress = queried.receipt && queried.receipt.contractAddress != null ? queried.receipt.contractAddress : null;
        console.log(`  status: ${item.status}`);
        console.log(`  blockNumber: ${item.blockNumber}`);
        if (item.contractAddress) console.log(`  contractAddress: ${item.contractAddress}`);
      }

      if (tx.expectFailure) {
        item.unexpectedSuccess = true;
        throw new Error(`${label} succeeded but expectFailure=true`);
      }
    } catch (err) {
      item.error = err.message;
      if (tx.expectFailure && !item.unexpectedSuccess) {
        item.expectedFailure = true;
        console.log(`  expected failure: ${err.message}`);
      } else {
        this.report.transactions.push(item);
        if (tx.saveAs) setDeep(this.context.results, tx.saveAs, item);
        throw err;
      }
    }

    if (tx.saveAs) setDeep(this.context.results, tx.saveAs, item);
    this.report.transactions.push(item);
  }

  async run() {
    await this.init();
    if (!Array.isArray(this.config.transactions) || this.config.transactions.length === 0) {
      throw new Error("Config must include a non-empty transactions array");
    }
    for (let i = 0; i < this.config.transactions.length; i += 1) {
      try {
        await this.runOne(this.config.transactions[i], i);
      } catch (err) {
        if (!this.defaults.continueOnError) throw err;
        console.error(`  failed, continueOnError=true: ${err.message}`);
      }
    }
    this.report.finishedAt = new Date().toISOString();
    const reportFile = this.config.reportFile
      ? this.resolveFile(this.config.reportFile)
      : path.resolve(this.configDir, `tx_config_report_${Date.now()}.json`);
    fs.writeFileSync(reportFile, JSON.stringify(this.report, null, 2));
    console.log(`\nReport saved: ${reportFile}`);
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    usage();
    return;
  }
  if (!args.config) throw new Error("Missing --config <file>");

  await loadEthers();
  const configFile = path.resolve(process.cwd(), args.config);
  const config = readJson(configFile);
  const runner = new ConfigRunner(config, configFile, args.dryRun);
  await runner.run();
}

main().catch((err) => {
  console.error(`FAILED: ${err.stack || err.message}`);
  process.exitCode = 1;
});
