#!/usr/bin/env node
import { parseArgs, sendJsonRawTx } from "./raw_tx_test_utils.mjs";

function usage() {
  console.log(`
Usage:
  PRIVATE_KEY=<hex> node test_delegating_once.mjs --json-to <validator> --amount <amount>

Options:
  --json-to <address>         Business validator address written into JSON data
  --asset-type <asset>        Default: OHI
  --amount <amount>           Delegate amount, default 1000000
  --delegate-type <type>      Default: 1
  --find-utxo                 Set is_find_utxo=true
  --sponsor-gas               Set sponsor_gas=true
  --encoded-info <text>       Default: fun_eth delegating
  --nonce <nonce>             Use explicit nonce; useful with --dry-run
  --dry-run                   Sign only, do not send
`);
}

const args = parseArgs(process.argv.slice(2));
if (args.help) {
  usage();
  process.exit(0);
}

const payload = {
  type: "delegating",
  to: args.jsonTo || process.env.JSON_TO || args.to,
  asset_type: args.assetType || process.env.ASSET_TYPE || "OHI",
  amount: args.amount || process.env.AMOUNT || "1000000",
  delegate_type: args.delegateType || process.env.DELEGATE_TYPE || "1",
  is_find_utxo: args.isFindUtxo === true,
  sponsor_gas: args.sponsorGas === true,
  encoded_info: args.encodedInfo || process.env.ENCODED_INFO || "fun_eth delegating",
};

sendJsonRawTx("delegating", payload, args).catch((err) => {
  console.error(`FAILED: ${err.stack || err.message}`);
  process.exitCode = 1;
});
