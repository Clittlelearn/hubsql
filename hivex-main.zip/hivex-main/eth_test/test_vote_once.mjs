#!/usr/bin/env node
import { parseArgs, sendJsonRawTx } from "./raw_tx_test_utils.mjs";

function usage() {
  console.log(`
Usage:
  PRIVATE_KEY=<hex> node test_vote_once.mjs --vote-hash <hash> --vote <1|0>

Options:
  --vote-hash <hash>          Required unless VOTE_HASH is set
  --vote <value>              Default: 1
  --find-utxo                 Set is_find_utxo=true
  --sponsor-gas               Set sponsor_gas=true
  --encoded-info <text>       Default: fun_eth vote
  --nonce <nonce>             Use explicit nonce; useful with --dry-run
  --dry-run                   Sign only, do not send
`);
}

const args = parseArgs(process.argv.slice(2));
if (args.help) {
  usage();
  process.exit(0);
}

const voteHash = args.voteHash || process.env.VOTE_HASH;
if (!voteHash && !args.dryRun) throw new Error("Missing --vote-hash <hash>");

const payload = {
  type: "vote",
  vote_hash: voteHash || "0xCHANGE_ME_VOTE_OR_PROPOSAL_HASH",
  vote: args.vote || process.env.VOTE || "1",
  is_find_utxo: args.isFindUtxo === true,
  sponsor_gas: args.sponsorGas === true,
  encoded_info: args.encodedInfo || process.env.ENCODED_INFO || "fun_eth vote",
};

sendJsonRawTx("vote", payload, args).catch((err) => {
  console.error(`FAILED: ${err.stack || err.message}`);
  process.exitCode = 1;
});
