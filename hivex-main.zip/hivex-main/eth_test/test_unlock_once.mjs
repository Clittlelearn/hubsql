#!/usr/bin/env node
import { parseArgs, sendJsonRawTx } from "./raw_tx_test_utils.mjs";

function usage() {
  console.log(`
Usage:
  PRIVATE_KEY=<hex> node test_unlock_once.mjs --utxo-hash <hash>

Options:
  --utxo-hash <hash>          Required unless UTXO_HASH is set
  --find-utxo                 Set is_find_utxo=true
  --sponsor-gas               Set sponsor_gas=true
  --encoded-info <text>       Default: fun_eth unlock
  --nonce <nonce>             Use explicit nonce; useful with --dry-run
  --dry-run                   Sign only, do not send
`);
}

const args = parseArgs(process.argv.slice(2));
if (args.help) {
  usage();
  process.exit(0);
}

const utxoHash = args.utxoHash || process.env.UTXO_HASH;
if (!utxoHash && !args.dryRun) throw new Error("Missing --utxo-hash <hash>");

const payload = {
  type: "unlock",
  utxo_hash: utxoHash || "0xCHANGE_ME_LOCK_UTXO_HASH",
  is_find_utxo: args.isFindUtxo === true,
  sponsor_gas: args.sponsorGas === true,
  encoded_info: args.encodedInfo || process.env.ENCODED_INFO || "fun_eth unlock",
};

sendJsonRawTx("unlock", payload, args).catch((err) => {
  console.error(`FAILED: ${err.stack || err.message}`);
  process.exitCode = 1;
});
