#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
let ethers;

const DEFAULTS = {
  rpcUrl: "http://127.0.0.1:13134",
  chainId: 12315n,
  privateKey: "0x8fc570d5311a0ac6b72e7996a6f0cf473b1765518fe7b8a76612782c062507fa",
  from: "0x755Ccf704E17570b64E247f0794314e4C8E542CA",
  to: "0x000000000000000000000000000000000000dEaD",
  customAssetType:
    "0xe5c3e46ef84357c6363a721c7d12792ae087e946ac50d29f320bb09159258e77",
  gasLimit: 3_000_000n,
  maxFeePerGasGwei: "1",
  maxPriorityFeePerGasGwei: "0.5",
  pollIntervalMs: 3000,
  receiptTimeoutMs: 120000,
  logDir: path.resolve(__dirname, "../build/bin/remote_logs"),
};

class RpcClient {
  constructor(url) {
    this.url = url;
    this.id = 0;
  }

  async call(method, params = []) {
    const body = { jsonrpc: "2.0", method, params, id: ++this.id };
    const resp = await fetch(this.url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const json = await resp.json();
    if (json.error) {
      const msg = json.error.message || JSON.stringify(json.error);
      const err = new Error(`${method} failed: ${msg}`);
      err.rpc = json;
      throw err;
    }
    return json.result;
  }

  getTransactionCount(address) {
    return this.call("eth_getTransactionCount", [address, "latest"]).then((v) =>
      Number(BigInt(v || "0x0")),
    );
  }

  sendRawTransaction(rawTx) {
    return this.call("eth_sendRawTransaction", [rawTx]);
  }

  getTransactionReceipt(hash) {
    return this.call("eth_getTransactionReceipt", [hash]);
  }

  getTransactionByHash(hash) {
    return this.call("eth_getTransactionByHash", [hash]);
  }

  getCode(address) {
    return this.call("eth_getCode", [address, "latest"]);
  }
}

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 1) {
    const key = argv[i];
    const next = () => argv[++i];
    if (key === "--rpc-url") out.rpcUrl = next();
    else if (key === "--chain-id") out.chainId = BigInt(next());
    else if (key === "--private-key") out.privateKey = normalize0x(next());
    else if (key === "--from") out.from = next();
    else if (key === "--to") out.to = next();
    else if (key === "--asset-type") out.customAssetType = next();
    else if (key === "--timeout-ms") out.receiptTimeoutMs = Number(next());
    else if (key === "--poll-ms") out.pollIntervalMs = Number(next());
    else if (key === "--log-dir") out.logDir = next();
    else if (key === "--help" || key === "-h") out.help = true;
  }
  return out;
}

function printHelp() {
  console.log(`
Usage:
  node test_fun_eth_sendRawTransaction_flow.mjs [options]

Options:
  --rpc-url <url>       JSON-RPC URL, default http://127.0.0.1:13134
  --chain-id <id>       Chain id, default 12315
  --private-key <hex>   Sender private key
  --from <address>      Sender address
  --to <address>        Transfer recipient, default sender itself
  --asset-type <hash>   Custom asset type used by JSON data transfer
  --timeout-ms <ms>     Receipt polling timeout, default 120000
  --poll-ms <ms>        Poll interval, default 3000
`);
}

async function loadEthers() {
  const major = Number(process.versions.node.split(".")[0]);
  if (major < 18) {
    throw new Error(
      `Node.js ${process.versions.node} is too old for ethers@6. Please run with Node.js >= 18.`,
    );
  }
  const mod = await import("ethers");
  ethers = mod.ethers;
}

function normalize0x(value) {
  if (!value) return value;
  return value.startsWith("0x") ? value : `0x${value}`;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function jsonData(payload) {
  return `0x${Buffer.from(JSON.stringify(payload), "utf8").toString("hex")}`;
}

function loadContractHex(name) {
  const file = path.resolve(__dirname, "contract", name);
  return fs.readFileSync(file, "utf8").trim();
}

function latestRemoteLogTail(logDir, lines = 80) {
  try {
    const files = fs
      .readdirSync(logDir)
      .filter((f) => f.endsWith(".log"))
      .map((f) => {
        const full = path.join(logDir, f);
        return { full, mtimeMs: fs.statSync(full).mtimeMs };
      })
      .sort((a, b) => b.mtimeMs - a.mtimeMs);
    if (!files.length) return "";
    const text = fs.readFileSync(files[0].full, "utf8");
    return `\n[remote log tail: ${files[0].full}]\n${text.split(/\r?\n/).slice(-lines).join("\n")}`;
  } catch {
    return "";
  }
}

class TxRunner {
  constructor(cfg) {
    this.cfg = cfg;
    this.rpc = new RpcClient(cfg.rpcUrl);
    this.wallet = new ethers.Wallet(cfg.privateKey);
    this.nextNonce = null;
  }

  async initNonce() {
    this.nextNonce = await this.rpc.getTransactionCount(this.cfg.from);
  }

  async sign({ to, value = 0n, data = "0x", gasLimit = this.cfg.gasLimit }) {
    if (this.nextNonce == null) await this.initNonce();
    const nonce = this.nextNonce++;
    const tx = {
      type: 2,
      chainId: this.cfg.chainId,
      nonce,
      to: to || undefined,
      value,
      data,
      gasLimit,
      maxFeePerGas: this.cfg.maxFeePerGas,
      maxPriorityFeePerGas: this.cfg.maxPriorityFeePerGas,
    };
    const rawTx = await this.wallet.signTransaction(tx);
    const parsed = ethers.Transaction.from(rawTx);
    return { rawTx, metamaskHash: parsed.hash, nonce };
  }

  async sendAndWait(label, txRequest) {
    console.log(`\n=== ${label} ===`);
    const signed = await this.sign(txRequest);
    console.log(`nonce: ${signed.nonce}`);
    console.log(`MetaMask/local tx hash: ${signed.metamaskHash}`);

    const rpcHash = await this.rpc.sendRawTransaction(signed.rawTx);
    console.log(`eth_sendRawTransaction result: ${rpcHash}`);

    const receipt = await this.waitMetaMaskStyle(label, signed.metamaskHash, rpcHash);
    const tx = await this.getTxMetaMaskStyle(label, signed.metamaskHash, rpcHash);
    console.log(`receipt.status: ${receipt && receipt.status ? receipt.status : "<null>"}`);
    console.log(
      `receipt.contractAddress: ${
        receipt && receipt.contractAddress ? receipt.contractAddress : "<null>"
      }`,
    );
    console.log(`tx.hash: ${tx && tx.hash ? tx.hash : "<null>"}`);
    console.log(`tx.to: ${tx && tx.to ? tx.to : "<null>"}`);
    return { ...signed, rpcHash, receipt, tx };
  }

  async waitMetaMaskStyle(label, metamaskHash, rpcHash) {
    const started = Date.now();
    let lastError = "";
    while (Date.now() - started < this.cfg.receiptTimeoutMs) {
      for (const hash of unique([metamaskHash, rpcHash])) {
        try {
          const receipt = await this.rpc.getTransactionReceipt(hash);
          if (receipt) {
            console.log(`eth_getTransactionReceipt(${hash}) ok`);
            return receipt;
          }
        } catch (err) {
          lastError = err.message;
        }
      }
      await sleep(this.cfg.pollIntervalMs);
    }
    throw new Error(
      `Timed out waiting receipt for ${label}. Last error: ${lastError}${latestRemoteLogTail(
        this.cfg.logDir,
      )}`,
    );
  }

  async getTxMetaMaskStyle(label, metamaskHash, rpcHash) {
    let lastError = "";
    for (const hash of unique([metamaskHash, rpcHash])) {
      try {
        const tx = await this.rpc.getTransactionByHash(hash);
        if (tx) {
          console.log(`eth_getTransactionByHash(${hash}) ok`);
          return tx;
        }
      } catch (err) {
        lastError = err.message;
      }
    }
    throw new Error(
      `eth_getTransactionByHash returned no transaction for ${label}. Last error: ${lastError}`,
    );
  }
}

function unique(values) {
  return [...new Set(values.filter(Boolean))];
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    printHelp();
    return;
  }

  await loadEthers();
  const cfg = { ...DEFAULTS, ...args };
  cfg.maxFeePerGas = ethers.parseUnits(cfg.maxFeePerGasGwei, "gwei");
  cfg.maxPriorityFeePerGas = ethers.parseUnits(cfg.maxPriorityFeePerGasGwei, "gwei");
  const runner = new TxRunner(cfg);
  const chainId = await runner.rpc.call("eth_chainId");
  console.log(`RPC: ${cfg.rpcUrl}`);
  console.log(`chainId: ${BigInt(chainId)} (${chainId})`);
  console.log(`from: ${cfg.from}`);
  console.log(`to: ${cfg.to}`);
  console.log(`custom asset: ${cfg.customAssetType}`);
  console.log(
    "Note: current fun_eth_sendRawTransaction uses default OHI for raw EVM deploy/call; JSON asset_type is supported by the business tx branch.",
  );

  const bytecode = loadContractHex("contract.txt");
  const setStore = loadContractHex("contract_call_set_store.txt");
  const getStore = loadContractHex("contract_call_get_store.txt");

  const deploy = await runner.sendAndWait("non-json/default OHI: deploy contract", {
    to: null,
    data: bytecode,
  });
  const contractAddress = deploy.receipt && deploy.receipt.contractAddress;
  if (!contractAddress) {
    throw new Error("Deploy receipt did not include contractAddress");
  }

  const code = await runner.rpc.getCode(contractAddress);
  console.log(`eth_getCode(${contractAddress}): ${code.length > 10 ? `${code.slice(0, 18)}...` : code}`);

  await runner.sendAndWait("non-json/default OHI: call contract store(uint256)", {
    to: contractAddress,
    data: setStore,
  });

  const callResult = await runner.rpc.call("eth_call", [
    { from: cfg.from, to: contractAddress, data: getStore },
    "latest",
  ]);
  console.log(`eth_call retrieve(): ${callResult}`);

  await runner.sendAndWait("non-json/default OHI: normal transfer", {
    to: cfg.to,
    value: ethers.parseUnits("0.00000001", 18),
    data: "0x",
  });

  const customPayload = {
    type: "tx",
    asset_type: cfg.customAssetType,
    amount: "1",
    is_find_utxo: false,
    sponsor_gas: false,
    encoded_info: "fun_eth_sendRawTransaction custom asset transfer",
  };

  await runner.sendAndWait("json/custom asset: normal transfer", {
    to: cfg.to,
    value: 0n,
    data: jsonData(customPayload),
  });

  console.log("\nAll requested executable checks finished.");
  console.log(
    "Custom asset deploy/call cannot be represented as JSON data with this handler because deploy is selected before JSON parsing and call treats JSON data as business-menu input, not EVM bytecode/input.",
  );
}

main().catch((err) => {
  console.error(`\nFAILED: ${err.message}`);
  process.exitCode = 1;
});
