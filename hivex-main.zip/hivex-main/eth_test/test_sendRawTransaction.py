#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eth_sendRawTransaction 业务接口测试脚本

模拟 MetaMask 的 eth_sendRawTransaction 调用流程：
  1. 构造 JSON 业务数据
  2. JSON → hex 编码 → 填入交易 data 字段
  3. RLP 编码 + 签名 (EIP-1559)
  4. 通过 JSON-RPC 发送 eth_sendRawTransaction

用法:
    python3 test_sendRawTransaction.py              # 运行全部测试
    python3 test_sendRawTransaction.py --type stake # 运行单个测试
    python3 test_sendRawTransaction.py --list       # 列出所有测试类型
"""

import json
import sys
import os
import argparse
import requests
from typing import Dict, Optional, Tuple

from eth_account import Account
from eth_account.signers.local import LocalAccount
from eth_account.datastructures import SignedTransaction
from web3 import Web3
from web3.types import TxParams
from hexbytes import HexBytes


# ============================================================================
# 配置 —— 根据实际环境修改
# ============================================================================

CONFIG = {
    "rpc_url": "http://127.0.0.1:13134",     # 节点 JSON-RPC 地址
    "chain_id": 12315,                         # 链 ID
    "private_key": "0xYOUR_PRIVATE_KEY",       # 测试账户私钥 (64 hex)
    "from_address": "0xYOUR_ADDRESS",          # 测试账户地址
    "to_address": "0xRECIPIENT_ADDRESS",       # 测试收款/委托目标地址
    "gas_limit": 300000,                       # gas 限制
    "max_fee_per_gas": Web3.to_wei(1, "gwei"),
    "max_priority_fee_per_gas": Web3.to_wei(0.5, "gwei"),
}

# ============================================================================
# JSON-RPC 客户端
# ============================================================================

class EthRpcClient:
    """以太坊 JSON-RPC 客户端"""

    def __init__(self, url: str):
        self.url = url
        self._id = 0

    def _next_id(self) -> int:
        self._id += 1
        return self._id

    def call(self, method: str, params: list) -> dict:
        """发起 JSON-RPC 调用"""
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": self._next_id(),
        }
        resp = requests.post(self.url, json=payload, timeout=30)
        resp.raise_for_status()
        return resp.json()

    def get_transaction_count(self, address: str) -> int:
        """获取 nonce"""
        result = self.call("eth_getTransactionCount", [address, "latest"])
        if "result" in result:
            return int(result["result"], 16)
        return 0

    def send_raw_transaction(self, raw_tx_hex: str) -> dict:
        """发送原始交易"""
        return self.call("eth_sendRawTransaction", [raw_tx_hex])


# ============================================================================
# 交易构造器 —— 模拟 MetaMask 签名流程
# ============================================================================

class TxBuilder:
    """模拟 MetaMask 构造并签名 EIP-1559 交易"""

    def __init__(self, config: dict):
        self.cfg = config
        self.w3 = Web3()
        self.account: LocalAccount = Account.from_key(config["private_key"])
        self.rpc = EthRpcClient(config["rpc_url"])

    def _get_nonce(self) -> int:
        try:
            return self.rpc.get_transaction_count(self.cfg["from_address"])
        except Exception:
            return 0

    def build_and_sign(self, data_hex: str, to_addr: str = "") -> Tuple[str, str]:
        """
        构造 EIP-1559 交易并签名。

        Args:
            data_hex: data 字段 (0x 前缀的 hex 字符串)
            to_addr:  接收地址 (空 = 部署合约)

        Returns:
            (raw_tx_hex, tx_hash_hex)
        """
        nonce = self._get_nonce()

        tx: TxParams = {
            "chainId": self.cfg["chain_id"],
            "nonce": nonce,
            "maxPriorityFeePerGas": self.cfg["max_priority_fee_per_gas"],
            "maxFeePerGas": self.cfg["max_fee_per_gas"],
            "gas": self.cfg["gas_limit"],
            "to": to_addr if to_addr else "",
            "value": 0,
            "data": data_hex,
            "type": 2,  # EIP-1559
        }

        signed: SignedTransaction = self.account.sign_transaction(tx)
        return signed.rawTransaction.hex(), signed.hash.hex()


# ============================================================================
# 辅助函数
# ============================================================================

def json_to_hex(data: dict) -> str:
    """将 JSON 对象编码为 0x 前缀的 hex 字符串"""
    json_str = json.dumps(data, separators=(",", ":"))
    return "0x" + json_str.encode("utf-8").hex()


def make_gas_asset(addr: str, asset_type: str) -> dict:
    """构造 gas_asset 对象"""
    return {"addr": addr, "asset_type": asset_type}


def common_fields(sponsor_gas: bool = False, is_find_utxo: bool = False,
                  encoded_info: str = "", gas_asset: dict = None) -> dict:
    """生成业务 JSON 的公共字段"""
    fields = {
        "is_find_utxo": is_find_utxo,
        "sponsor_gas": sponsor_gas,
        "encoded_info": encoded_info,
    }
    if gas_asset:
        fields["gas_asset"] = gas_asset
    return fields


# ============================================================================
# 各业务测试函数
# ============================================================================

def test_transaction(builder: TxBuilder):
    """测试: HandleTransaction —— 普通转账"""
    print("\n" + "=" * 60)
    print("[TEST] HandleTransaction — 普通转账 (type=tx)")
    print("=" * 60)

    payload = {
        "type": "tx",
        "asset_type": builder.cfg["from_address"],
        "amount": "1000000",
        **common_fields(),
    }

    data_hex = json_to_hex(payload)
    raw_tx, tx_hash = builder.build_and_sign(data_hex, builder.cfg["to_address"])

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  data hex: {data_hex}")
    print(f"  signed tx hash: 0x{tx_hash}")
    print(f"  raw tx len: {len(raw_tx)} chars")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_stake(builder: TxBuilder):
    """测试: HandleStake —— 质押"""
    print("\n" + "=" * 60)
    print("[TEST] HandleStake — 质押 (type=stake)")
    print("=" * 60)

    payload = {
        "type": "stake",
        "asset_type": builder.cfg["from_address"],
        "amount": "100000000",
        "reward_rank": "10",
        **common_fields(
            sponsor_gas=True,
            gas_asset=make_gas_asset(builder.cfg["from_address"], builder.cfg["from_address"]),
        ),
    }

    data_hex = json_to_hex(payload)
    raw_tx, tx_hash = builder.build_and_sign(data_hex)

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_unstake(builder: TxBuilder):
    """测试: HandleUnstake —— 解除质押"""
    print("\n" + "=" * 60)
    print("[TEST] HandleUnstake — 解除质押 (type=unstake)")
    print("=" * 60)

    payload = {
        "type": "unstake",
        "asset_type": builder.cfg["from_address"],
        "stake_utxo_hash": "0x" + "a" * 64,
        **common_fields(),
    }

    data_hex = json_to_hex(payload)
    raw_tx, tx_hash = builder.build_and_sign(data_hex)

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_delegating(builder: TxBuilder):
    """测试: handleDelegating —— 委托"""
    print("\n" + "=" * 60)
    print("[TEST] handleDelegating — 委托 (type=delegating)")
    print("=" * 60)

    payload = {
        "type": "delegating",
        "asset_type": builder.cfg["from_address"],
        "amount": "50000000",
        "delegate_type": "1",
        **common_fields(),
    }

    data_hex = json_to_hex(payload)
    # 被委托地址 = ethTx.to
    raw_tx, tx_hash = builder.build_and_sign(data_hex, builder.cfg["to_address"])

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  to (delegate target): {builder.cfg['to_address']}")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_undelegating(builder: TxBuilder):
    """测试: HandleUndelegating —— 撤销委托"""
    print("\n" + "=" * 60)
    print("[TEST] HandleUndelegating — 撤销委托 (type=undelegating)")
    print("=" * 60)

    payload = {
        "type": "undelegating",
        "asset_type": builder.cfg["from_address"],
        "utxo_hash": "0x" + "b" * 64,
        **common_fields(),
    }

    data_hex = json_to_hex(payload)
    raw_tx, tx_hash = builder.build_and_sign(data_hex, builder.cfg["to_address"])

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  to (undelegate target): {builder.cfg['to_address']}")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_bonus(builder: TxBuilder):
    """测试: HandleBonus —— 领取奖励"""
    print("\n" + "=" * 60)
    print("[TEST] HandleBonus — 领取奖励 (type=bonus)")
    print("=" * 60)

    payload = {
        "type": "bonus",
        "asset_type": builder.cfg["from_address"],
        "first_choose": False,
        **common_fields(),
    }

    data_hex = json_to_hex(payload)
    raw_tx, tx_hash = builder.build_and_sign(data_hex)

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_lock(builder: TxBuilder):
    """测试: HandleLock —— 锁定（投票质押）"""
    print("\n" + "=" * 60)
    print("[TEST] HandleLock — 锁定 (type=lock)")
    print("=" * 60)

    payload = {
        "type": "lock",
        "lock_amount": "100000000",
        "lock_type": "1",
        **common_fields(),
    }

    data_hex = json_to_hex(payload)
    raw_tx, tx_hash = builder.build_and_sign(data_hex)

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_unlock(builder: TxBuilder):
    """测试: HandleUnLock —— 解除锁定"""
    print("\n" + "=" * 60)
    print("[TEST] HandleUnLock — 解除锁定 (type=unlock)")
    print("=" * 60)

    payload = {
        "type": "unlock",
        "utxo_hash": "0x" + "c" * 64,
        **common_fields(),
    }

    data_hex = json_to_hex(payload)
    raw_tx, tx_hash = builder.build_and_sign(data_hex)

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_vote(builder: TxBuilder):
    """测试: HandleVote —— 投票"""
    print("\n" + "=" * 60)
    print("[TEST] HandleVote — 投票 (type=vote)")
    print("=" * 60)

    payload = {
        "type": "vote",
        "vote_hash": "0x" + "d" * 64,
        "vote": "1",
        **common_fields(),
    }

    data_hex = json_to_hex(payload)
    raw_tx, tx_hash = builder.build_and_sign(data_hex)

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_proposal(builder: TxBuilder):
    """测试: HandleProposal —— 发起提案"""
    print("\n" + "=" * 60)
    print("[TEST] HandleProposal — 发起提案 (type=proposal)")
    print("=" * 60)

    payload = {
        "type": "proposal",
        "vote_hash": "0x" + "e" * 64,
        **common_fields(),
    }

    data_hex = json_to_hex(payload)
    raw_tx, tx_hash = builder.build_and_sign(data_hex)

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_revoke_proposal(builder: TxBuilder):
    """测试: revokeProposalRequest —— 撤销提案"""
    print("\n" + "=" * 60)
    print("[TEST] revokeProposalRequest — 撤销提案 (type=revoke_proposal)")
    print("=" * 60)

    payload = {
        "type": "revoke_proposal",
        "vote_hash": "0x" + "f" * 64,
        **common_fields(),
    }

    data_hex = json_to_hex(payload)
    raw_tx, tx_hash = builder.build_and_sign(data_hex)

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_treasury(builder: TxBuilder):
    """测试: HandleTresury —— 申领国库奖励"""
    print("\n" + "=" * 60)
    print("[TEST] HandleTresury — 申领国库奖励 (type=fund)")
    print("=" * 60)

    payload = {
        "type": "fund",
        "is_find_utxo": False,
        "encoded_info": "",
    }

    data_hex = json_to_hex(payload)
    raw_tx, tx_hash = builder.build_and_sign(data_hex)

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_deploy_contract(builder: TxBuilder):
    """测试: 部署合约 (to 为空)"""
    print("\n" + "=" * 60)
    print("[TEST] DeployContract — 部署合约 (to=empty)")
    print("=" * 60)

    # 部署合约: to 留空, data 为合约字节码
    contract_bytecode = "0x6080604052348015600f57600080fd5b50603f80601d6000396000f3fe"

    raw_tx, tx_hash = builder.build_and_sign(contract_bytecode, to_addr="")

    print(f"  bytecode: {contract_bytecode}")
    print(f"  to: (empty → deploy)")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


def test_bonus_first_choose(builder: TxBuilder):
    """测试: HandleBonus —— 领取奖励 (first_choose=true)"""
    print("\n" + "=" * 60)
    print("[TEST] HandleBonus — 领取奖励 first_choose=true (type=bonus)")
    print("=" * 60)

    payload = {
        "type": "bonus",
        "asset_type": builder.cfg["from_address"],
        "first_choose": True,
        **common_fields(),
    }

    data_hex = json_to_hex(payload)
    raw_tx, tx_hash = builder.build_and_sign(data_hex)

    print(f"  JSON payload: {json.dumps(payload)}")
    print(f"  signed tx hash: 0x{tx_hash}")

    result = builder.rpc.send_raw_transaction("0x" + raw_tx)
    print(f"  RPC result: {json.dumps(result, indent=2)}")
    return result


# ============================================================================
# 测试注册表 & 入口
# ============================================================================

TEST_REGISTRY = {
    "transaction":     ("HandleTransaction",       test_transaction),
    "stake":           ("HandleStake",             test_stake),
    "unstake":         ("HandleUnstake",           test_unstake),
    "delegating":      ("handleDelegating",        test_delegating),
    "undelegating":    ("HandleUndelegating",      test_undelegating),
    "bonus":           ("HandleBonus",             test_bonus),
    "bonus_first":     ("HandleBonus(first)",      test_bonus_first_choose),
    "lock":            ("HandleLock",              test_lock),
    "unlock":          ("HandleUnLock",            test_unlock),
    "vote":            ("HandleVote",              test_vote),
    "proposal":        ("HandleProposal",          test_proposal),
    "revoke_proposal": ("revokeProposalRequest",   test_revoke_proposal),
    "treasury":        ("HandleTresury",           test_treasury),
    "deploy":          ("DeployContract",          test_deploy_contract),
}


def validate_config(config: dict):
    """验证配置是否有效"""
    errors = []
    if config["private_key"] == "0xYOUR_PRIVATE_KEY":
        errors.append("请设置 CONFIG['private_key']")
    if config["from_address"] == "0xYOUR_ADDRESS":
        errors.append("请设置 CONFIG['from_address']")
    if config["to_address"] == "0xRECIPIENT_ADDRESS":
        errors.append("请设置 CONFIG['to_address']")
    return errors


def main():
    parser = argparse.ArgumentParser(
        description="eth_sendRawTransaction 业务接口测试")
    parser.add_argument("--type", "-t", choices=list(TEST_REGISTRY.keys()),
                        help="运行指定类型的测试")
    parser.add_argument("--list", "-l", action="store_true",
                        help="列出所有测试类型")
    parser.add_argument("--rpc-url", default=CONFIG["rpc_url"],
                        help="JSON-RPC 地址")
    parser.add_argument("--chain-id", type=int, default=CONFIG["chain_id"],
                        help="链 ID")
    parser.add_argument("--private-key", default=CONFIG["private_key"],
                        help="私钥 (0x 前缀)")
    parser.add_argument("--from", dest="from_addr", default=CONFIG["from_address"],
                        help="发送地址")
    parser.add_argument("--to", dest="to_addr", default=CONFIG["to_address"],
                        help="接收/目标地址")
    args = parser.parse_args()

    # 更新配置
    config = dict(CONFIG)
    config["rpc_url"] = args.rpc_url
    config["chain_id"] = args.chain_id
    config["private_key"] = args.private_key
    config["from_address"] = args.from_addr
    config["to_address"] = args.to_addr

    if args.list:
        print("\n可用的测试类型:")
        print("-" * 45)
        for key, (name, _) in TEST_REGISTRY.items():
            print(f"  {key:<20} → {name}")
        print()
        return

    # 验证配置
    errors = validate_config(config)
    if errors:
        print("\n❌ 配置错误:")
        for e in errors:
            print(f"  - {e}")
        print("\n请编辑脚本中的 CONFIG 或通过命令行参数指定。")
        print("示例:")
        print('  python3 test_sendRawTransaction.py \\')
        print('    --private-key 0xYOUR_KEY \\')
        print('    --from 0xYOUR_ADDR \\')
        print('    --to 0xRECIPIENT_ADDR \\')
        print('    --type stake')
        sys.exit(1)

    builder = TxBuilder(config)

    # 检查节点连接
    print(f"\n🔗 连接节点: {config['rpc_url']}")
    try:
        resp = builder.rpc.call("eth_chainId", [])
        node_chain = int(resp.get("result", "0x0"), 16)
        print(f"  节点 chainId: {node_chain}")
        if node_chain != config["chain_id"]:
            print(f"  ⚠️  警告: 节点 chainId ({node_chain}) != 本地配置 ({config['chain_id']})")
    except Exception as ex:
        print(f"  ❌ 无法连接节点: {ex}")
        sys.exit(1)

    print(f"  from:  {config['from_address']}")
    print(f"  to:    {config['to_address']}")

    # 运行测试
    if args.type:
        name, func = TEST_REGISTRY[args.type]
        print(f"\n🎯 运行单个测试: {name}")
        try:
            func(builder)
        except Exception as ex:
            print(f"\n❌ 测试失败: {ex}")
            import traceback
            traceback.print_exc()
    else:
        print("\n🧪 运行全部测试...")
        results = {}
        for key, (name, func) in TEST_REGISTRY.items():
            try:
                func(builder)
                results[key] = "✅"
            except Exception as ex:
                results[key] = f"❌ {ex}"
                print(f"  !!! 异常: {ex}")

        print("\n" + "=" * 60)
        print("📊 测试汇总")
        print("=" * 60)
        for key, (name, _) in TEST_REGISTRY.items():
            status = results.get(key, "⏭️")
            print(f"  {status}  {key:<20} {name}")


if __name__ == "__main__":
    main()
