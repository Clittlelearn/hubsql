#!/usr/bin/env node
import { ethers } from "ethers";

const rpcUrl = "http://127.0.0.1:13134";
const chainId = 12315n;
const privateKey = "0x8fc570d5311a0ac6b72e7996a6f0cf473b1765518fe7b8a76612782c062507fa";
const from = "0x755Ccf704E17570b64E247f0794314e4C8E542CA";
const to = "0x000000000000000000000000000000000000dEaD";
const assetType = process.argv[2] || "0xe5c3e46ef84357c6363a721c7d12792ae087e946ac50d29f320bb09159258e77";

let id = 0;
async function rpc(method, params = []) {
  const resp = await fetch(rpcUrl, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", method, params, id: ++id }),
  });
  const json = await resp.json();
  if (json.error) throw new Error(`${method}: ${json.error.message}`);
  return json.result;
}

function jsonData(obj) {
  return "0x" + Buffer.from(JSON.stringify(obj), "utf8").toString("hex");
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function main() {
  const nonce = Number(BigInt(await rpc("eth_getTransactionCount", [from, "latest"])));
  const payload = {
    type: "tx",
    asset_type: assetType,
    is_find_utxo: false,
    sponsor_gas: false,
    encoded_info: "custom asset receipt/log test",
  };
  const raw = await new ethers.Wallet(privateKey).signTransaction({
    type: 2,
    chainId,
    nonce,
    to,
    value: assetType.toLowerCase() === "0xohi" || assetType.toLowerCase() === "ohi"
      ? ethers.parseUnits("0.00000001", 18)
      : 0n,
    data: jsonData(payload),
    gasLimit: 3000000n,
    maxFeePerGas: ethers.parseUnits("1", "gwei"),
    maxPriorityFeePerGas: ethers.parseUnits("0.5", "gwei"),
  });
  const localHash = ethers.Transaction.from(raw).hash;
  console.log(`nonce=${nonce}`);
  console.log(`localHash=${localHash}`);
  const rpcHash = await rpc("eth_sendRawTransaction", [raw]);
  console.log(`rpcHash=${rpcHash}`);
  for (let i = 0; i < 30; i += 1) {
    const receipt = await rpc("eth_getTransactionReceipt", [localHash]);
    const tx = await rpc("eth_getTransactionByHash", [localHash]);
    console.log(`poll=${i} receipt=${receipt ? "yes" : "null"} tx=${tx ? "yes" : "null"}`);
    if (receipt && tx) {
      console.log(`receiptJson=${JSON.stringify(receipt)}`);
      console.log(`txJson=${JSON.stringify(tx)}`);
      return;
    }
    await sleep(3000);
  }
}

main().catch((err) => {
  console.error(`FAILED: ${err.message}`);
  process.exitCode = 1;
});
