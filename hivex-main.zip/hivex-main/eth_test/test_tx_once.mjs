#!/usr/bin/env node
import { parseArgs, sendJsonRawTx } from "./raw_tx_test_utils.mjs";

function usage() {
  console.log(`
Usage:
  PRIVATE_KEY=<hex> node test_tx_once.mjs --json-to <receiver> --value-wei <amount>

Options:
  --rpc <url>                 Default: http://127.0.0.1:13134
  --chain-id <id>             Default: 12315
  --json-to <address>         Business to address written into JSON data
  --asset-type <asset>        Default: OHI
  --find-utxo                 Set is_find_utxo=true
  --sponsor-gas               Set sponsor_gas=true
  --encoded-info <text>       Default: fun_eth tx
  --nonce <nonce>             Use explicit nonce; useful with --dry-run
  --dry-run                   Sign only, do not send
`);
}

const args = parseArgs(process.argv.slice(2));
if (args.help) {
  usage();
  process.exit(0);
}

const payload = {
  type: "tx",
  to: args.jsonTo || process.env.JSON_TO || args.to,
  asset_type: args.assetType || process.env.ASSET_TYPE || "OHI",
  is_find_utxo: args.isFindUtxo === true,
  sponsor_gas: args.sponsorGas === true,
  encoded_info: args.encodedInfo || process.env.ENCODED_INFO || "fun_eth tx",
};

sendJsonRawTx("tx", payload, args).catch((err) => {
  console.error(`FAILED: ${err.stack || err.message}`);
  process.exitCode = 1;
});
