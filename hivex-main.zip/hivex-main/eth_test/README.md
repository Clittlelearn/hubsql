# eth_sendRawTransaction 业务接口测试

模拟 MetaMask 的 `eth_sendRawTransaction` 调用流程的测试脚本集。

## 目录结构

```
eth_test/
├── test_sendRawTransaction.py   # Python 测试脚本 (推荐)
├── test_sendRawTransaction.mjs  # Node.js 测试脚本
├── requirements.txt             # Python 依赖
└── README.md                    # 本文件
```

## 环境准备

### Python 版本

```bash
cd eth_test
pip install -r requirements.txt
```

### Node.js 版本

```bash
cd eth_test
npm install ethers@6
```

---

## 配置

编辑脚本中的 `CONFIG` 部分，或通过命令行参数传入：

| 参数 | 说明 | 示例 |
|------|------|------|
| `--rpc-url` | 节点 JSON-RPC 地址 | `http://127.0.0.1:13134` |
| `--chain-id` | 链 ID | `12315` |
| `--private-key` | 测试账户私钥 | `0x...` |
| `--from` | 发送地址 | `0x...` |
| `--to` | 接收/目标地址 | `0x...` |

---

## 使用方法

### 列出所有测试类型

```bash
python3 test_sendRawTransaction.py --list
```

### 运行全部测试

```bash
python3 test_sendRawTransaction.py \
    --private-key 0xYOUR_KEY \
    --from 0xYOUR_ADDR \
    --to 0xRECIPIENT_ADDR
```

### 运行单个测试

```bash
python3 test_sendRawTransaction.py \
    --private-key 0xYOUR_KEY \
    --from 0xYOUR_ADDR \
    --to 0xRECIPIENT_ADDR \
    --type stake
```

### 测试类型速查

| `--type` 值 | 对应菜单 | 说明 |
|-------------|----------|------|
| `transaction` | HandleTransaction | 普通转账 |
| `stake` | HandleStake | 质押 |
| `unstake` | HandleUnstake | 解除质押 |
| `delegating` | handleDelegating | 委托 |
| `undelegating` | HandleUndelegating | 撤销委托 |
| `bonus` | HandleBonus | 领取奖励 |
| `bonus_first` | HandleBonus(first) | 领取奖励(首次) |
| `lock` | HandleLock | 锁定(投票质押) |
| `unlock` | HandleUnLock | 解除锁定 |
| `vote` | HandleVote | 投票 |
| `proposal` | HandleProposal | 发起提案 |
| `revoke_proposal` | revokeProposalRequest | 撤销提案 |
| `treasury` | HandleTresury | 申领国库奖励 |
| `deploy` | DeployContract | 部署合约 |

---

## 调用流程图

```mermaid
sequenceDiagram
    participant Test as 测试脚本
    participant Sign as eth_account (签名)
    participant Node as 节点 (13134)
    participant Handler as fun_eth_sendRawTransaction

    Test->>Test: 1. 构造 JSON 业务数据
    Test->>Test: 2. JSON → hex 编码
    Test->>Sign: 3. 构造 EIP-1559 交易
    Sign-->>Test: 签名后的 rawTransaction
    Test->>Node: 4. eth_sendRawTransaction(rawTx)
    Node->>Handler: 5. RLP 解码 + 签名恢复
    Handler->>Handler: 6. data 解码为字符串
    alt data 是合法 JSON
        Handler->>Handler: 7. dispatch_by_type()
        Handler->>Handler: 8. 对应 handler (trans/sign/broadcast)
    else data 不是 JSON
        Handler->>Handler: 7. 合约调用 / 普通转账
    end
    Handler-->>Node: tx_hash
    Node-->>Test: {"result": "0x<hash>"}
```

---

## 注意事项

1. **私钥安全**: 请使用测试账户，不要在生产环境使用包含真实资产的私钥。
2. **Gas 费用**: 脚本默认使用 1 gwei 的 maxFeePerGas，可根据链上情况调整。
3. **Nonce 管理**: 脚本自动通过 `eth_getTransactionCount` 获取 nonce。
4. **交易 data 编码**: JSON 字符串通过 UTF-8 编码后转为 hex，填入交易的 data 字段。
