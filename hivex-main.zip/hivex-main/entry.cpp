#include "utils/init.h"
#include "utils/cmdline.h"
#include "include/logging.h"

/**
 * @brief Main entry point for the application.
 *
 * Initializes signal handlers, parses command-line arguments,
 * and performs clean exit.
 *
 * @param argc Number of command-line arguments
 * @param argv Array of command-line argument strings
 * @return Exit status (0 for success, -1 for initialization failure)
 */
int main(int argc, char* argv[])
{
  DEBUGLOG("*** Program startup ***");

  // Initialize signal handlers for graceful shutdown
  if (init_signal_handlers() != 0)
  {
    return -1;
  }

  // Parse command-line arguments
  parse_cmdline_args(argc, argv);

  // Perform quick exit
  quick_exit(0);
  return 0;
}