#include "./config.h"


#include <cstdint>
#include <iostream>
#include <fstream>
#include <string>
#include <regex>
#include <filesystem>
#include <vector>
#include <algorithm>


#include <sstream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <net/if.h>

#include "../utils/console.h"
#include "../net/peer_node.h"
#include "../net/node.hpp"
#include "../net/ip_port.h"
#include "../include/logging.h"
#include "../net/peer_node.h"
#include "common/genesis.h"
#include "node.h"

namespace
{
constexpr uint32_t kDefaultEndpointPort = 13133;

uint32_t endpointFamily(const std::string& addr)
{
    if (addr.empty()) return 0;
    return isValidIPv6(addr) ? 6 : 4;
}

bool parseEndpointItem(const nlohmann::json& item, uint32_t defaultPort, Config::Endpoint& endpoint)
{
    endpoint = Config::Endpoint{};
    if (item.is_string())
    {
        endpoint.addr = item.get<std::string>();
        endpoint.port = defaultPort;
    }
    else if (item.is_object())
    {
        endpoint.addr = item.value("addr", "");
        endpoint.port = item.value("port", defaultPort);
        endpoint.priority = item.value("priority", 0u);
        if (item.contains("family"))
        {
            if (item["family"].is_number_unsigned())
            {
                endpoint.family = item["family"].get<uint32_t>();
            }
            else if (item["family"].is_string())
            {
                const auto family = item["family"].get<std::string>();
                endpoint.family = family == "ipv6" ? 6 : (family == "ipv4" ? 4 : 0);
            }
        }
    }

    if (endpoint.addr.empty()) return false;
    if (endpoint.port == 0) endpoint.port = defaultPort;
    if (endpoint.family == 0) endpoint.family = endpointFamily(endpoint.addr);
    return true;
}

std::vector<Config::Endpoint> parseEndpointArray(const nlohmann::json& json, const std::string& key, uint32_t defaultPort)
{
    std::vector<Config::Endpoint> endpoints;
    if (!json.contains(key) || !json[key].is_array())
    {
        return endpoints;
    }

    for (const auto& item : json[key])
    {
        Config::Endpoint endpoint;
        if (parseEndpointItem(item, defaultPort, endpoint))
        {
            endpoints.push_back(endpoint);
        }
    }
    return endpoints;
}

std::vector<Config::EndpointGroup> parseEndpointGroups(const nlohmann::json& json, const std::string& key, uint32_t defaultPort)
{
    std::vector<Config::EndpointGroup> groups;
    if (!json.contains(key) || !json[key].is_array())
    {
        return groups;
    }

    for (const auto& item : json[key])
    {
        Config::EndpointGroup group;
        if (item.is_object() && item.contains("endpoints") && item["endpoints"].is_array())
        {
            group.id = item.value("id", item.value("node", std::string()));
            for (const auto& endpointJson : item["endpoints"])
            {
                Config::Endpoint endpoint;
                if (parseEndpointItem(endpointJson, defaultPort, endpoint))
                {
                    group.endpoints.push_back(endpoint);
                }
            }
        }
        else
        {
            Config::Endpoint endpoint;
            if (parseEndpointItem(item, defaultPort, endpoint))
            {
                group.endpoints.push_back(endpoint);
            }
        }

        if (!group.endpoints.empty())
        {
            groups.push_back(group);
        }
    }
    return groups;
}

nlohmann::json endpointToJson(const Config::Endpoint& endpoint)
{
    nlohmann::json item;
    item["addr"] = endpoint.addr;
    item["port"] = endpoint.port;
    item["family"] = endpoint.family;
    item["priority"] = endpoint.priority;
    return item;
}

std::vector<Config::Endpoint> discoverLocalEndpoints(uint32_t defaultPort)
{
    std::vector<Config::Endpoint> endpoints;
    struct ifaddrs* ifaddr = nullptr;
    if (getifaddrs(&ifaddr) == -1)
    {
        return endpoints;
    }

    for (auto ifa = ifaddr; ifa != nullptr; ifa = ifa->ifa_next)
    {
        if (ifa->ifa_addr == nullptr || (ifa->ifa_flags & IFF_LOOPBACK) != 0)
        {
            continue;
        }

        char host[INET6_ADDRSTRLEN] = {0};
        if (ifa->ifa_addr->sa_family == AF_INET)
        {
            auto* addr = reinterpret_cast<struct sockaddr_in*>(ifa->ifa_addr);
            if (inet_ntop(AF_INET, &addr->sin_addr, host, sizeof(host)) != nullptr)
            {
                endpoints.push_back({host, defaultPort, 4, static_cast<uint32_t>(endpoints.size())});
            }
        }
        else if (ifa->ifa_addr->sa_family == AF_INET6)
        {
            auto* addr = reinterpret_cast<struct sockaddr_in6*>(ifa->ifa_addr);
            if (IN6_IS_ADDR_LOOPBACK(&addr->sin6_addr) || IN6_IS_ADDR_LINKLOCAL(&addr->sin6_addr))
            {
                continue;
            }
            if (inet_ntop(AF_INET6, &addr->sin6_addr, host, sizeof(host)) != nullptr)
            {
                endpoints.push_back({host, defaultPort, 6, static_cast<uint32_t>(endpoints.size())});
            }
        }
    }
    freeifaddrs(ifaddr);
    return endpoints;
}
}

static const std::string kConfigJson = "{\"http_callback\":{\"ip\":\"\",\"path\":\"\",\"port\":0},\"rpc\":true,\"http_port\":13134,\"enable_https\":false,\"https_port\":443,\"ssl_cert_path\":\"\",\"ssl_key_path\":\"\",\"ssl_ca_bundle\":\"\",\"enable_mtls\":false,\"enable_block_rate_probe\":false,\"info\":{\"logo\":\"\",\"name\":\"\"},\"endpoints\":[],\"log\":{\"console\":false,\"level\":\"OFF\",\"path\":\"./logs\"},\"server_endpoints\":[],\"version\":\"1.0.0\"}";

nlohmann::json BuildDefaultConfigJson()
{
    auto json = nlohmann::json::parse(kConfigJson);
    auto endpoints = discoverLocalEndpoints(kDefaultEndpointPort);
    json["endpoints"] = nlohmann::json::array();
    for (const auto& endpoint : endpoints)
    {
        json["endpoints"].push_back(endpointToJson(endpoint));
    }
    json["server_endpoints"] = nlohmann::json::array();
    return json;
}


int Config::InitFile()
{
 
    try
    {
        std::filesystem::path cfg = std::filesystem::absolute(kConfigFilename);
        _configPath = cfg.string();
        _configDir = cfg.parent_path().string();
    }
    catch (const std::exception&)
    {
        _configPath = kConfigFilename;
        _configDir.clear();
    }

    std::ifstream f(kConfigFilename);

    if(f.good())
    {
        std::string str((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
        tmpJson = nlohmann::json::parse(str);
        if(_Parse(tmpJson, false) != 0)
        {
            return -1;
        }
    }
    f.close();

    std::ifstream configFile(Config::kConfigFilename);

    if (!configFile)
    {
        std::lock_guard<std::mutex> lock(_cfgMutex);
        tmpJson = BuildDefaultConfigJson();

        if(_Parse(tmpJson, false) != 0)
        {
            return -2;
        }
        _WriteFileAtomic(tmpJson);

    }
    configFile.close();

    if(_Filter() != 0 || _Verify() != 0)
    {
        std::lock_guard<std::mutex> lock(_cfgMutex);
        auto json = BuildDefaultConfigJson();
        _WriteFileAtomic(json);
      return 0;
    }

    return 0;
}


int Config::_WriteFileAtomic(const nlohmann::json& json)
{
    std::filesystem::path cfg = std::filesystem::absolute(kConfigFilename);
    std::string tmpFilename = cfg.parent_path().string() + "/.config.tmp.json";
    
    std::ofstream tmpFile(tmpFilename);
    if (!tmpFile) {
        return -1;
    }
    tmpFile << json.dump(4);
    tmpFile.close();
    
    if (std::rename(tmpFilename.c_str(), kConfigFilename.c_str()) != 0) {
        return -2;
    }
    
    return 0;
}

int Config::_Parse(nlohmann::json json, bool update_file)
{

        if (json.is_null())
        {
        return -1;
        }

        try 
        {
        _endpoints.clear();
        _serverEndpoints.clear();
        _serverEndpointGroups.clear();
        _httpCallback.ip = json[HTTP_CONFIG_CALLBACK][kHttpCallbackIp].get<std::string>();
        _httpCallback.port = json[HTTP_CONFIG_CALLBACK][CFG_HTTP_CALLBACK_PORT].get<uint32_t>();
        _httpCallback.path = json[HTTP_CONFIG_CALLBACK][CFG_HTTP_CALLBACK_PATH].get<std::string>();
        _httpCallback.path = json[HTTP_CONFIG_CALLBACK][CFG_HTTP_CALLBACK_PATH].get<std::string>();
        _httpPort = json[CFG_HTTP_PORT].get<uint32_t>();
        _rpc = json[KRpcApi].get<bool>();
        if (json.contains(CFG_ENABLE_HTTPS)) {
            _enableHttps = json[CFG_ENABLE_HTTPS].get<bool>();
        } else {
            _enableHttps = false;
        }
        if (json.contains(CFG_HTTPS_PORT)) {
            _httpsPort = json[CFG_HTTPS_PORT].get<uint32_t>();
        } else {
            _httpsPort = 443;
        }
        if (json.contains(CFG_SSL_CERT_PATH)) {
            _sslCertPath = json[CFG_SSL_CERT_PATH].get<std::string>();
        }
        if (json.contains(CFG_SSL_KEY_PATH)) {
            _sslKeyPath = json[CFG_SSL_KEY_PATH].get<std::string>();
        }
        if (json.contains(CFG_SSL_CA_BUNDLE)) {
            _sslCaBundle = json[CFG_SSL_CA_BUNDLE].get<std::string>();
        }
        if (json.contains(CFG_ENABLE_MTLS)) {
            _enableMtls = json[CFG_ENABLE_MTLS].get<bool>();
        } else {
            _enableMtls = false;
        }
        if (json.contains(CFG_ENABLE_BLOCK_RATE_PROBE)) {
            _enableBlockRateProbe = json[CFG_ENABLE_BLOCK_RATE_PROBE].get<bool>();
        } else {
            _enableBlockRateProbe = false;
        }

        auto resolve_path = [this](const std::string& p) -> std::string {
            if (p.empty()) return std::string();
            std::filesystem::path pp(p);
            if (pp.is_absolute()) return pp.lexically_normal().string();
            if (_configDir.empty()) return pp.lexically_normal().string();
            return (std::filesystem::path(_configDir) / pp).lexically_normal().string();
        };

        _sslCertPath = resolve_path(_sslCertPath);
        _sslKeyPath = resolve_path(_sslKeyPath);
        _sslCaBundle = resolve_path(_sslCaBundle);

        auto file_exists = [](const std::string& p) -> bool {
            if (p.empty()) return false;
            return std::filesystem::exists(p) && std::filesystem::is_regular_file(p);
        };

        if (_enableHttps && (!file_exists(_sslCertPath) || !file_exists(_sslKeyPath)))
        {
            auto find_file = [](const std::filesystem::path& dir, const std::vector<std::string>& names) -> std::string {
                for (const auto& name : names)
                {
                    const auto p = dir / name;
                    if (std::filesystem::exists(p) && std::filesystem::is_regular_file(p))
                    {
                        return p.string();
                    }
                }
                return std::string();
            };

            std::vector<std::filesystem::path> candidate_dirs;
            if (!_configDir.empty())
            {
                const std::filesystem::path cfg_dir(_configDir);
                candidate_dirs.emplace_back(cfg_dir / "certs");
                candidate_dirs.emplace_back(cfg_dir / "build/bin/certs");
            }
            else
            {
                candidate_dirs.emplace_back("./certs");
                candidate_dirs.emplace_back("./build/bin/certs");
            }

            for (const auto& dir : candidate_dirs)
            {
                if (!std::filesystem::exists(dir) || !std::filesystem::is_directory(dir))
                {
                    continue;
                }

                if (!file_exists(_sslCertPath))
                {
                    _sslCertPath = find_file(dir, {"fullchain.pem", "cert.pem"});
                    _sslCertPath = resolve_path(_sslCertPath);
                }
                if (!file_exists(_sslKeyPath))
                {
                    _sslKeyPath = find_file(dir, {"privkey.pem"});
                    _sslKeyPath = resolve_path(_sslKeyPath);
                }
                if (!_sslCertPath.empty() && !_sslKeyPath.empty())
                {
                    break;
                }
            }
        }

         _info.logo = json[kCfgInfo][CFG_INFO_LOGO].get<std::string>();
         _info.name = json[kCfgInfo][kConfigInfoName].get<std::string>();
         _log.console = json[k_config_log][kConfigLogToConsole].get<bool>();
         _log.level = json[k_config_log][CFG_LOG_LEVEL].get<std::string>();
         _log.path = json[k_config_log][CONFIG_LOG_PATH].get<std::string>();
         _serverPort = kDefaultEndpointPort;
         _endpoints = parseEndpointArray(json, kCfgEndpoints, kDefaultEndpointPort);
         if (!_endpoints.empty())
         {
             _serverPort = _endpoints.front().port;
         }
         _serverEndpointGroups = parseEndpointGroups(json, kCfgServerEndpoints, kDefaultEndpointPort);
         _serverEndpoints.clear();
         for (const auto& group : _serverEndpointGroups)
         {
             _serverEndpoints.insert(_serverEndpoints.end(), group.endpoints.begin(), group.endpoints.end());
         }


       _version = json[CONFIG_KEY_VERSION].get<std::string>();

        }

        catch(const std::exception& e)
        {
         std::cout << e.what() << std::endl;
        }

       return 0;
        }


    //_Check whether the nickname is legal
#define Dverify(Info,param,minnum,maxnum,ip,regex_var)  \
    if(Info.param.length() >= minnum && Info.param.length() <= maxnum )  \
    {   \
        if(!Info.param.empty() && !std::regex_match(Info.param,std::regex(regex_var)))  \
        {   \
            std::cout << RED << "Config error in " << #param << " _Verify " ; \
            if(ip)  std::cout << " ip: " << IpPort::IpSz(ip);    \
            std::cout << RESET << std::endl;    \
            return -1;  \
        }   \
    }   \
    else    \
    {   \
        std::cout << RED << "Config error in "<< #param << " length! " << #param << " : " <<  Info.param  \
        << " length is: " << Info.param.length() << " The range should be:" << minnum << " - " << maxnum ;  \
        if(ip)  std::cout << " ip: " << IpPort::IpSz(ip);    \
        std::cout << RESET << std::endl;    \
        return -2;  \
    }   \


int Config::_Verify(const Node& node)
{
  Dverify(node, name, 0, 45, node.publicIp, "^[\u4E00-\u9FA5\x20-\x7E]+$");
  Dverify(
      node, logo, 0, 512, node.publicIp,
      "^(http|https|ftp)\\://"
      "([a-zA-Z0-9\\.\\-]+(\\:[a-zA-Z0-9\\.&%\\$\\-]+)*@)?((25[0-5]|2[0-4][0-9]"
      "|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\\.(25[0-5]|2[0-4][0-9]|[0-1]{"
      "1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-"
      "9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|"
      "[1-9]{1}[0-9]{1}|[0-9])|([a-zA-Z0-9\\-]+\\.)*[a-zA-Z0-9\\-]+\\.[a-zA-Z]{"
      "2,4})(\\:[0-9]+)?(/[^/][a-zA-Z0-9\\.\\,\?\'\\/\\+&%\\$#\\=~_\\-@]*)*$");
  return 0;
}

int Config::_Verify()
{
  Dverify(_info, name, 0, 45, 0, "^[\u4E00-\u9FA5\x20-\x7E]+$");
  Dverify(
      _info, logo, 0, 512, 0,
      "^(http|https|ftp)\\://"
      "([a-zA-Z0-9\\.\\-]+(\\:[a-zA-Z0-9\\.&%\\$\\-]+)*@)?((25[0-5]|2[0-4][0-9]"
      "|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\\.(25[0-5]|2[0-4][0-9]|[0-1]{"
      "1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-"
      "9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|"
      "[1-9]{1}[0-9]{1}|[0-9])|([a-zA-Z0-9\\-]+\\.)*[a-zA-Z0-9\\-]+\\.[a-zA-Z]{"
      "2,4})(\\:[0-9]+)?(/[^/][a-zA-Z0-9\\.\\,\?\'\\/\\+&%\\$#\\=~_\\-@]*)*$");
  return 0;
}

int Config::_Filter()
{
    if(FILTER_SERVER_PORT(_serverPort) != 0)
    {
        return -2;
    }

    if(filter_http_port(_httpPort) != 0)
    {
        return -3;
    }
    if (_enableHttps) {
        if(FILTER_SERVER_PORT(_httpsPort) != 0)
        {
            return -7;
        }
    }

    for(auto & endpoint : _endpoints)
    {
        if(filter_server_ip(endpoint.addr) != 0 || FILTER_SERVER_PORT(endpoint.port) != 0)
        {
            return -8;
        }
        if(endpoint.port != _serverPort)
        {
            return -10;
        }
    }
    for(auto & endpoint : _serverEndpoints)
    {
        if(filter_server_ip(endpoint.addr) != 0 || FILTER_SERVER_PORT(endpoint.port) != 0)
        {
            return -9;
        }
    }
 
    if(FilterLog(_log) != 0)
    {
        return -5;
    }

    if(handleFilterHttpCallback(_httpCallback) != 0)
    {
        return -6;
    }
    return 0;
}

int Config::GetServerPort()
{
    return _serverPort;
}

int Config::GetHttpPort()
{
    
    return _httpPort;
}

int Config::GetHttpsPort()
{
    return _httpsPort;
}

bool Config::GetRpc()
{
    if(_rpc == false)
    return false;
    else
    return true;
}

bool Config::GetEnableHttps()
{
    return _enableHttps;
}

bool Config::GetEnableMtls()
{
    return _enableMtls;
}

bool Config::GetEnableBlockRateProbe()
{
    return _enableBlockRateProbe;
}

std::string Config::GetSslCertPath()
{
    return _sslCertPath;
}

std::string Config::GetSslKeyPath()
{
    return _sslKeyPath;
}

std::string Config::GetSslCaBundle()
{
    return _sslCaBundle;
}

int Config::GetInfo(Config::Info & info)
{
    info = _info;
    return 0;
}

int Config::SetRPC(bool enable)
{
    std::ifstream configFile(Config::kConfigFilename);
    if (!configFile.good())
    {
        return -1;
    }
    tmpJson["rpc"] = enable;
    
    std::ofstream outFile(Config::kConfigFilename);
    if (outFile.fail())
    {
        return -2;
    }
    outFile << tmpJson.dump(4);
    outFile.close();
    _rpc = enable;
    
    return 0;
}


int Config::UpdateServerEndpoint(const std::string& action, const std::string& nodeId, const std::string& addr)
{
    if (action != "add" && action != "remove")
    {
        return -1;
    }
    if (nodeId.empty())
    {
        return -2;
    }
    if (!isValidIP(addr))
    {
        return -3;
    }

    std::lock_guard<std::mutex> lock(_cfgMutex);
    if (!tmpJson.contains(kCfgServerEndpoints) || !tmpJson[kCfgServerEndpoints].is_array())
    {
        tmpJson[kCfgServerEndpoints] = nlohmann::json::array();
    }

    auto groups = parseEndpointGroups(tmpJson, kCfgServerEndpoints, kDefaultEndpointPort);
    for (auto& group : groups)
    {
        std::stable_sort(group.endpoints.begin(), group.endpoints.end(), [](const Endpoint& left, const Endpoint& right) {
            return left.priority < right.priority;
        });
    }

    auto groupIt = std::find_if(groups.begin(), groups.end(), [&](const EndpointGroup& group) {
        return group.id == nodeId;
    });

    const Endpoint endpoint{addr, kDefaultEndpointPort, endpointFamily(addr), 0};
    bool changed = false;

    if (action == "add")
    {
        if (groupIt == groups.end())
        {
            EndpointGroup group;
            group.id = nodeId;
            group.endpoints.push_back(endpoint);
            groups.push_back(group);
            changed = true;
        }
        else
        {
            auto& endpoints = groupIt->endpoints;
            endpoints.erase(std::remove_if(endpoints.begin(), endpoints.end(), [&](const Endpoint& item) {
                return item.addr == addr && item.port == kDefaultEndpointPort;
            }), endpoints.end());
            endpoints.insert(endpoints.begin(), endpoint);
            changed = true;
        }
    }
    else
    {
        if (groupIt == groups.end())
        {
            return -4;
        }

        auto& endpoints = groupIt->endpoints;
        const auto oldSize = endpoints.size();
        endpoints.erase(std::remove_if(endpoints.begin(), endpoints.end(), [&](const Endpoint& item) {
            return item.addr == addr && item.port == kDefaultEndpointPort;
        }), endpoints.end());
        if (endpoints.size() == oldSize)
        {
            return -5;
        }
        changed = true;
    }

    if (!changed)
    {
        return 0;
    }

    tmpJson[kCfgServerEndpoints] = nlohmann::json::array();
    _serverEndpointGroups.clear();
    _serverEndpoints.clear();

    for (auto& group : groups)
    {
        if (group.endpoints.empty())
        {
            continue;
        }

        nlohmann::json groupJson;
        groupJson["id"] = group.id;
        groupJson["endpoints"] = nlohmann::json::array();
        for (size_t i = 0; i < group.endpoints.size(); ++i)
        {
            group.endpoints[i].priority = static_cast<uint32_t>(i);
            groupJson["endpoints"].push_back(endpointToJson(group.endpoints[i]));
        }

        tmpJson[kCfgServerEndpoints].push_back(groupJson);
        _serverEndpointGroups.push_back(group);
        _serverEndpoints.insert(_serverEndpoints.end(), group.endpoints.begin(), group.endpoints.end());
    }

    return _WriteFileAtomic(tmpJson);
}

std::vector<Config::Endpoint> Config::GetEndpoints()
{
    return _endpoints;
}

std::vector<Config::Endpoint> Config::GetServerEndpoints()
{
    return _serverEndpoints;
}

std::vector<Config::EndpointGroup> Config::GetServerEndpointGroups()
{
    return _serverEndpointGroups;
}

std::string Config::GetVersion(){
    return _version;
}

int Config::GetLog(Config::Log & log)
{
    log = _log;

    return 0;
}

int Config::GetHttpCallback(Config::HttpCallback & httpCallback)
{
    httpCallback = _httpCallback;
    return 0;
}
template <typename T> 
int Config::filter_http_port(T & t)
{
    std::regex userPortPatternMatch("^([1-9][0-9]{1,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])$");
    std::string portStr = std::to_string(t);
   
    if (std::regex_match(portStr, userPortPatternMatch) || portStr.empty())
    {
        return 0;
    }
    else 
    {
        std::cerr << RED << "http port format error" <<  RESET << std::endl;
        return -1;
    }
    
}

template <typename T> 
int Config::FILTER_SERVER_PORT(T & t)
{
    std::regex userPortPatternMatch("^([1-9][0-9]{1,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])$");
    std::string portStr = std::to_string(t);
   
    if (std::regex_match(portStr, userPortPatternMatch) || portStr.empty() || portStr == "0")
    {
        return 0;
    }
    else 
    {
        std::cerr << RED << "server port format error" <<  RESET << std::endl;
        return -1;
    }
    
}


template <typename T>
int Config::FilterIp(T & t)
{
    std::string ip = t;

    // NET-016: Support both IPv4 and IPv6
    if (ip.empty() || isValidIP(ip))
    {
        return 0;
    }
    else
    {
        std::cerr << RED <<"ip address format error and has set default" << RESET << std::endl ;
        return -1;
    }
}

template <typename T>
int Config::filter_server_ip(T & t)
{
    std::string ip = t;

    // NET-016: Support both IPv4 and IPv6
    if (ip.empty() || isValidIP(ip))
    {
        return 0;
    }
    else
    {
        std::cerr << RED <<"server ip address format error and has set default" << RESET << std::endl ;
        return -1;
    }
}

int Config::FilterLog(Log &log)
{    
    std::string level = tmpJson["log"]["level"];
    std::regex regex_level("(debug|info|warn|error|trace|critical|off)", std::regex::icase);
    if (!std::regex_match(level, regex_level)) 
    {
        std::cerr << RED <<"log level input error " << RESET <<std::endl;
        return -1;
    }

    std::string path = tmpJson["log"]["path"];
    std::regex regex_path("^\\./logs$");
    if(!std::regex_match(path,regex_path))
    {
        std::cerr << RED <<"log path input error " << RESET << std::endl;
        return -2;
    }

    if(!FilterBool(log.console))
    {
        std::cerr << RED <<"log console is not bool type" << RESET << std::endl;
        return -3;
    }
    return 0;
  
}
int Config::handleFilterHttpCallback(HttpCallback &httpcallback)
{
    if(FilterIp(httpcallback.ip) != 0 )
    {
        return -1;
    }
    if(FILTER_SERVER_PORT(httpcallback.port) != 0)
    {
        return -2;
    }
    return 0;
}
template <typename T>
bool Config::FilterBool(T  &t)
{
    if(std::is_same<bool, T>::value)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void Config::GetAllServerAddress()
{
    std::vector<Node> nodeList = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    tmpJson["server_endpoints"] = nlohmann::json::array();

    for (auto node : nodeList)
    {
        std::vector<Config::Endpoint> endpoints;
        if (!node.endpoints.empty())
        {
            for (const auto& nodeEndpoint : node.endpoints)
            {
                if (!nodeEndpoint.isValid()) continue;
                endpoints.push_back({nodeEndpoint.addr, nodeEndpoint.port, static_cast<uint32_t>(nodeEndpoint.family), nodeEndpoint.priority});
            }
        }
        else
        {
            std::string addr = node.getPublicAddrStr();
            uint32_t port = node.listenPort != 0 ? node.listenPort : node.publicPort;
            if (!addr.empty() && port != 0)
            {
                endpoints.push_back({addr, port, endpointFamily(addr), 0});
            }
        }

        if (endpoints.empty())
        {
            continue;
        }

        nlohmann::json group;
        group["id"] = node.address;
        group["endpoints"] = nlohmann::json::array();
        for (const auto& endpoint : endpoints)
        {
            group["endpoints"].push_back(endpointToJson(endpoint));
        }
        tmpJson["server_endpoints"].push_back(group);
    }

    std::ifstream f(kConfigFilename);
    if(f.good())
    {
        _WriteFileAtomic(tmpJson);
    }
}

void Config::_Check() 
{
    while(!_exitThread)  
    {
        for(int i=0; i <= 1800 && !_exitThread ; i++){
            std::this_thread::sleep_for(std::chrono::seconds(2));
        }
        
        if(!_exitThread){
            GetAllServerAddress(); 
        }
    }
    return ;
}

bool isValidIPv4(const std::string& ip) {
    struct in_addr addr;
    return inet_pton(AF_INET, ip.c_str(), &addr) == 1;
}

// NET-016: IPv6 support
bool isValidIPv6(const std::string& ip) {
    struct in6_addr addr;
    return inet_pton(AF_INET6, ip.c_str(), &addr) == 1;
}

bool isValidIP(const std::string& ip) {
    return isValidIPv4(ip) || isValidIPv6(ip);
}
