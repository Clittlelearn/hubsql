#ifndef _GENESIS_HELPER_H_
#define _GENESIS_HELPER_H_

#include <cstdint>
#include <string>

// 获得创世时间
uint64_t GetGenesisTime();

// 获得创世地址
std::string GetInitAccountAddr();

#endif // _GENESIS_HELPER_H_