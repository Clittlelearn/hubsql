#include "common/global_data.h"
#include <chrono>
#include "utils/sha256.h"
#include "include/logging.h"
#include <atomic>
#include <set>
struct GlobalData
{
    std::string msgId;
    std::uint32_t retNum;
    std::uint32_t timeOutSec;
    std::mutex mutex;
    std::condition_variable condition;
    std::vector<std::string> data;
    std::set<std::string> res_ids;
    bool cancelled{false};
    ~GlobalData()
    {
        data.clear();
        res_ids.clear();
    }
};

bool GlobalDataManager::CreateWait(uint32_t timeOutSec, uint32_t retNum, std::string &outMsgId)
{
    static std::atomic<uint64_t> sequence{0};
    outMsgId = Getsha256Hash(std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()) +
                            ":" + std::to_string(sequence.fetch_add(1)));
    std::shared_ptr<GlobalData> dataPtr = std::make_shared<GlobalData>();
    dataPtr->msgId = outMsgId;
    dataPtr->timeOutSec = timeOutSec;
    dataPtr->retNum = retNum;
    {
        std::lock_guard lock(data_mutex);
        _globalData.insert(std::make_pair(dataPtr->msgId, dataPtr));
    }

    return true;
}

bool GlobalDataManager::AddResNode(const std::string &msgId, const std::string &resId)
{
    std::shared_ptr<GlobalData> dataPtr;
    {
        std::lock_guard lock(data_mutex);
        auto it = _globalData.find(msgId);
        if (_globalData.end() == it)
        {
            return false;
        }
        dataPtr = it->second;
    }
    {
        std::lock_guard lock(dataPtr->mutex);
        dataPtr->res_ids.insert(resId);
    }
    return true;
}

bool GlobalDataManager::SetExpectedResponses(const std::string &msgId, uint32_t retNum)
{
    std::shared_ptr<GlobalData> dataPtr;
    {
        std::lock_guard lock(data_mutex);
        auto it = _globalData.find(msgId);
        if (it == _globalData.end()) return false;
        dataPtr = it->second;
    }
    {
        std::lock_guard lock(dataPtr->mutex);
        if (retNum > dataPtr->res_ids.size() + dataPtr->data.size()) return false;
        dataPtr->retNum = retNum;
        if (dataPtr->data.size() >= dataPtr->retNum) dataPtr->condition.notify_all();
    }
    return true;
}

void GlobalDataManager::CancelWait(const std::string &msgId)
{
    std::shared_ptr<GlobalData> dataPtr;
    {
        std::lock_guard lock(data_mutex);
        auto it = _globalData.find(msgId);
        if (it == _globalData.end()) return;
        dataPtr = it->second;
        _globalData.erase(it);
    }
    {
        std::lock_guard lock(dataPtr->mutex);
        dataPtr->cancelled = true;
    }
    dataPtr->condition.notify_all();
}

bool GlobalDataManager::waitDataToAdd(const std::string &msgId, const std::string &resId, const std::string &data)
{
    std::shared_ptr<GlobalData> dataPtr;
    {
        std::lock_guard lock(data_mutex);
        auto it = _globalData.find(msgId);
        if (_globalData.end() == it)
        {
            return false;
        }
        dataPtr = it->second;
    }
    {
        std::lock_guard lock(dataPtr->mutex);
        auto found = dataPtr->res_ids.find(resId);
        if(found == dataPtr->res_ids.end())
        {
            ERRORLOG("not found msg_id:{}, res_id:{}",msgId, resId);
            return false;
        }
        dataPtr->res_ids.erase(found);
        dataPtr->data.push_back(data);
        if (dataPtr->data.size() >= dataPtr->retNum)
        {
            dataPtr->condition.notify_all();
        }
    }
    return true;
}

bool GlobalDataManager::WaitData(const std::string &msgId, std::vector<std::string> &retData)
{
    std::shared_ptr<GlobalData> dataPtr;
    {
        std::lock_guard lock(data_mutex);
        auto it = _globalData.find(msgId);
        if (_globalData.end() == it)
        {
            return false;
        }
        dataPtr = it->second;
    }
    std::unique_lock<std::mutex> lock(dataPtr->mutex);
    bool flag = true;
    if (dataPtr->data.size() < dataPtr->retNum)
    {
        dataPtr->condition.wait_for(lock, std::chrono::seconds(dataPtr->timeOutSec), [&]() {
            return dataPtr->cancelled || dataPtr->data.size() >= dataPtr->retNum;
        });
    }

    {
        retData = dataPtr->data;
    }

    if (dataPtr->cancelled || retData.size() < dataPtr->retNum)
    {
        flag = false;
    }

    // Only unlock data_ptr->mutex after all operations on it are complete.
    lock.unlock();

    {
        std::lock_guard lock(data_mutex);
        auto it = _globalData.find(msgId);
        if (_globalData.end() != it)
        {
            _globalData.erase(it);
        }
    }

    return flag;
}

GlobalDataManager &GlobalDataManager::get_global_data_manager()
{
    static GlobalDataManager dataManager;
    return dataManager;
}

