#include "genesis_helper.h"
#include "common/genesis.h"
#include "trie.h"
#include "utils/magic_singleton.h"
#include <cmath>

uint64_t GetGenesisTime()
{
    const auto & genesisInstance = MagicSingleton<Genesis>::GetInstance();
    return genesisInstance->GetGenesisTime();
}

std::string GetInitAccountAddr()
{
    const auto & genesisInstance = MagicSingleton<Genesis>::GetInstance();
    return genesisInstance->GetInitAccountAddr();
}
