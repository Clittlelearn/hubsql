﻿#ifndef _GENESIS_H
#define _GENESIS_H

#include <string>
#include <vector>
#include <unordered_set>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

/**
 * @brief Genesis配置文件管理类
 * 负责读写 genesis.json 文件，并维护 network.type 与 network.name 的一致性
 */
class Genesis {
public:
    // 支持的网络类型
    enum class NetworkType {
        Dev,
        Test,
        Primary
    };

    // 默认构造函数 - 创建一个内存中的默认配置（不写入文件）
    Genesis();

    // 从文件加载配置
    explicit Genesis(const std::string& filepath);

    // 保存到文件（覆盖式写入）
    bool Save(const std::string& filepath) const;

    // 保存到当前加载的文件路径（如果之前是通过文件构造的）
    bool Save() const;

    // 生成默认配置文件（静态方法）
    static bool GenerateDefaultFile(const std::string& filepath, NetworkType type = NetworkType::Dev);

    // Getter / Setter
    std::string GetChainName() const;
    void SetChainName(const std::string& name);

    std::string GetChainType() const;
    void SetChainType(const std::string& type);

    uint64_t GetGenesisTime() const;
    void SetGenesisTime(uint64_t timestamp);

    std::string GetInitAccountAddr() const;
    void SetInitAccountAddr(const std::string& addr);

    uint64_t GetInitialBalanceOHI() const;
    void SetInitialBalanceOHI(uint64_t value);

    std::unordered_set<std::string> GetVRFWhitelist() const;

    NetworkType GetNetworkType() const;
    std::string GetNetworkName() const;

    // 设置网络类型，会同时修改 name 保持一致
    void SetNetworkType(NetworkType type);

    // 直接设置网络名称（不推荐直接调用，会强制同步 type）
    void SetNetworkName(const std::string& name);

    const std::string GetCurrentFilePath() const;

    // 将枚举转换为字符串
    static std::string NetworkTypeToString(NetworkType type);
    static NetworkType StringToNetworkType(const std::string& typeStr);

private:

    static json CreateDefaultData();
    static json CreateDefaultData(NetworkType type);

    // 尝试从文件加载，并做基本结构校验
    bool TryLoadFromFile(const std::string& path, json& out_data);

private:
    // 内部更新 name 与 type 的一致性
    void SyncNetworkNameAndType();

    // 当前文件路径（用于 Save() 无参版本）
    static constexpr const char* DEFAULT_PATH = "genesis.json";
    std::string current_filepath_;
    // JSON 数据本体
    json data_;

};

#endif // _GENESIS_H