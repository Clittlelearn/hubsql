/**
 * *****************************************************************************
 * @file        config.h
 * @brief       
 * @author  ()
 * @date        2023-09-28
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef _CONFIG_H_
#define _CONFIG_H_

#include <string>
#include <set>
#include <type_traits>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <utility>
#include <chrono>
#include <boost/asio/deadline_timer.hpp>
#include <thread>
#include <functional>
#include <vector>
#include <cstdint>

#include "../utils/timer.hpp"
#include <nlohmann/json.hpp>
#include "../utils/magic_singleton.h"
#define kServerMainPort (MagicSingleton<Config>::GetInstance()->GetServerPort())

bool isValidIPv4(const std::string &ip);
// NET-016: IPv6 support
bool isValidIPv6(const std::string &ip);
bool isValidIP(const std::string &ip);  // Supports both IPv4 and IPv6
class Node;
class Config
{
public:
    struct Info
    {
        std::string logo;
        std::string name;
    };

    struct Log
    {
        bool console;
        std::string level;
        std::string path;
    };

    struct HttpCallback
    {
        std::string ip;
        std::string path;
        uint32_t port;
    };

    struct Endpoint
    {
        std::string addr;
        uint32_t port{0};
        uint32_t family{0};
        uint32_t priority{0};
    };

    struct EndpointGroup
    {
        std::string id;
        std::vector<Endpoint> endpoints;
    };

    const std::string kConfigFilename = "config.json";
    const std::string HTTP_CONFIG_CALLBACK = "http_callback";
    const std::string kHttpCallbackIp = "ip";
    const std::string CFG_HTTP_CALLBACK_PORT = "port";
    const std::string CFG_HTTP_CALLBACK_PATH = "path";
    const std::string CFG_HTTP_PORT = "http_port";
    const std::string KRpcApi = "rpc";
    const std::string kCfgInfo = "info";
    const std::string CFG_INFO_LOGO = "logo";
    const std::string kConfigInfoName = "name";
    const std::string k_config_log = "log";
    const std::string CFG_LOG_LEVEL = "level";
    const std::string CONFIG_LOG_PATH = "path";
    const std::string kConfigLogToConsole = "console";
    const std::string kCfgEndpoints = "endpoints";
    const std::string kCfgServerEndpoints = "server_endpoints";
    const std::string kCfgEndpointAddr = "addr";
    const std::string kCfgEndpointPort = "port";
    const std::string kCfgEndpointFamily = "family";
    const std::string kCfgEndpointPriority = "priority";
    const std::string CONFIG_KEY_VERSION = "version";
    const std::string CFG_ENABLE_HTTPS = "enable_https";
    const std::string CFG_HTTPS_PORT = "https_port";
    const std::string CFG_SSL_CERT_PATH = "ssl_cert_path";
    const std::string CFG_SSL_KEY_PATH = "ssl_key_path";
    const std::string CFG_SSL_CA_BUNDLE = "ssl_ca_bundle";
    const std::string CFG_ENABLE_MTLS = "enable_mtls";
    const std::string CFG_ENABLE_BLOCK_RATE_PROBE = "enable_block_rate_probe";

    nlohmann::json tmpJson ;
    int count = 0;

public:
    Config()
    {
        InitFile();
        _thread = std::thread(std::bind(&Config::_Check, this));
    };

    Config(bool & flag)
    {
        int ret = InitFile();
        if ( ret == 0 ) flag = true;
        _thread = std::thread(std::bind(&Config::_Check, this));
    };
    
    ~Config()
    {  
        _exitThread = true;
        if (_thread.joinable())
        {
            _thread.join();
        }
    };

    /**
     * @brief       
     * 
     * @return      int 
     */
    int InitFile();

    /**
     * @brief       
     * 
     * @param       _node 
     * @return      int 
     */
    int _Verify(const Node& _node);

    /**
     * @brief       Get the P2P listen port derived from local endpoints
     * 
     * @return      int 
     */
    int GetServerPort();

    /**
     * @brief       Get the Http Port object
     * 
     * @return      int 
     */
    int GetHttpPort();
    int GetHttpsPort();

    /**
     * @brief       Get the Info object
     * 
     * @param       info 
     * @return      int 
     */
    int GetInfo(Config::Info & info);

    /**
     * @brief       Get the Log object
     * 
     * @param       log 
     * @return      int 
     */
    int GetLog(Config::Log & log);

    /**
     * @brief       Get the Http Callback object
     * 
     * @param       httpCallback 
     * @return      int 
     */
    int GetHttpCallback(Config::HttpCallback & httpCallback);

    /**
     * @brief       Get the Rpc object
     * 
     * @return      true 
     * @return      false 
     */
    bool GetRpc();
    bool GetEnableHttps();
    bool GetEnableMtls();
    bool GetEnableBlockRateProbe();

    std::string GetSslCertPath();
    std::string GetSslKeyPath();
    std::string GetSslCaBundle();
    
    int SetRPC(bool enable);
    int UpdateServerEndpoint(const std::string& action, const std::string& nodeId, const std::string& addr);

    std::vector<Endpoint> GetEndpoints();
    std::vector<Endpoint> GetServerEndpoints();
    std::vector<EndpointGroup> GetServerEndpointGroups();

    std::string GetVersion();

    /**
     * @brief       
     * 
     * @tparam T 
     * @param       t 
     * @return      int 
     */
    template <typename T>
    int FILTER_SERVER_PORT(T &t);

    /**
     * @brief       
     * 
     * @tparam T 
     * @param       t 
     * @return      int 
     */
    template <typename T>
    int filter_http_port(T &t);

    /**
     * @brief       
     * 
     * @tparam T 
     * @param       t 
     * @return      int 
     */
    template <typename T> 
    int FilterIp(T &t);

    /**
     * @brief       
     * 
     * @tparam T 
     * @param       t 
     * @return      int 
     */
    template <typename T> 
    int filter_server_ip(T & t);

    /**
     * @brief       
     * 
     * @tparam T 
     * @param       t 
     * @return      true 
     * @return      false 
     */
    template <typename T>
    bool FilterBool(T  &t);

    /**
     * @brief       
     * 
     * @param       log 
     * @return      int 
     */
    int FilterLog(Log &log);

    /**
     * @brief       
     * 
     * @param       httpcallback 
     * @return      int 
     */
    int handleFilterHttpCallback(HttpCallback &httpcallback);

    /**
     * @brief       Get the All Server Address object
     * 
     */
    void GetAllServerAddress();

private:
    /**
     * @brief
     *
     * @param       json
     * @param       update_file  是否更新配置文件
     * @return      int
     */
    int _Parse(nlohmann::json json, bool update_file = true);

    /**
     * @brief       
     * 
     * @return      int 
     */
    int _Verify();

    /**
     * @brief       
     * 
     * @return      int 
     */
    int _Filter();

    /**
     * @brief       
     * 
     */
    void _Check();

private:

    Info _info;
    Log _log;
    bool _rpc;
    HttpCallback _httpCallback;
    uint32_t _httpPort;
    uint32_t _httpsPort;
    bool _enableHttps{false};
    bool _enableMtls{false};
    bool _enableBlockRateProbe{false};
    std::string _sslCertPath;
    std::string _sslKeyPath;
    std::string _sslCaBundle;
    std::vector<Endpoint> _endpoints;
    std::vector<Endpoint> _serverEndpoints;
    std::vector<EndpointGroup> _serverEndpointGroups;
    uint32_t _serverPort = 13133;
    std::string _version;
    std::thread _thread;
    std::atomic<bool> _exitThread{false};

    std::string _configPath;
    std::string _configDir;

    mutable std::mutex _cfgMutex;

    int _WriteFileAtomic(const nlohmann::json& json);
};

#endif
