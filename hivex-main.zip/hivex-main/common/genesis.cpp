﻿#include "genesis.h"

#include <fstream>
#include <stdexcept>

Genesis::Genesis(): current_filepath_(DEFAULT_PATH)
{
    json temp;
    if (TryLoadFromFile(current_filepath_, temp)) 
    {
        data_ = std::move(temp);
    }
    else
    {
        // 加载失败 → 使用默认值，并尝试写入
        data_ = CreateDefaultData();
        Save();  // 静默尝试覆盖/创建文件
    }
}

    // 指定路径构造
Genesis::Genesis(const std::string& filepath) : current_filepath_(filepath)
{
    json temp;
    if (TryLoadFromFile(current_filepath_, temp)) 
    {
        data_ = std::move(temp);
    }
    else
    {
        // 加载失败 → 使用默认值，并尝试写入到指定路径
        data_ = CreateDefaultData();
        Save();  // 静默尝试
    }
}

// 保存到当前绑定的路径（无参版本）
bool Genesis::Save() const 
{
    return Save(current_filepath_);
}

    // 保存到指定路径（覆盖写入）
bool Genesis::Save(const std::string& path) const 
{
    std::ofstream ofs(path);
    if (!ofs.is_open()) 
    {
        return false;
    }

    try 
    {
        ofs << data_.dump(4);  // 4空格缩进
        ofs.flush();
        return true;
    }
    catch (...) 
    {
        return false;
    }
}

// 示例：获取当前绑定的文件路径（调试/日志用）
const std::string Genesis::GetCurrentFilePath() const 
{
    return current_filepath_;
}

bool Genesis::GenerateDefaultFile(const std::string& filepath, NetworkType type) {
    Genesis config;
    config.SetNetworkType(type);
    return config.Save(filepath);
}

// Getter & Setter 实现
std::string Genesis::GetChainName() const {
    return data_["genesis"]["blockData"]["Name"].get<std::string>();
}

void Genesis::SetChainName(const std::string& name) {
    data_["genesis"]["blockData"]["Name"] = name;
}

std::string Genesis::GetChainType() const
{
    return data_["genesis"]["blockData"]["Type"].get<std::string>();
}

void Genesis::SetChainType(const std::string& type)
{
    data_["genesis"]["blockData"]["Type"] = type;
}

uint64_t Genesis::GetGenesisTime() const {
    return data_["genesis"]["genesisTime"].get<uint64_t>();
}

void Genesis::SetGenesisTime(uint64_t timestamp) {
    data_["genesis"]["genesisTime"] = timestamp;
}

std::string Genesis::GetInitAccountAddr() const {
    return data_["genesis"]["initAccountAddr"].get<std::string>();
}

void Genesis::SetInitAccountAddr(const std::string& addr) {
    data_["genesis"]["initAccountAddr"] = addr;
}

uint64_t Genesis::GetInitialBalanceOHI() const {
    const auto& ib = data_["genesis"]["initialBalance"];
    if (ib.contains("OHI")) {
        return ib["OHI"].get<uint64_t>();
    }
    return 0;
}

void Genesis::SetInitialBalanceOHI(uint64_t value) {
    data_["genesis"]["initialBalance"]["OHI"] = value;
}

Genesis::NetworkType Genesis::GetNetworkType() const {
    return StringToNetworkType(data_["network"]["type"].get<std::string>());
}

std::string Genesis::GetNetworkName() const {
    return data_["network"]["name"].get<std::string>();
}

void Genesis::SetNetworkType(NetworkType type) {
    std::string type_str = NetworkTypeToString(type);
    std::string name_str;

    switch (type) {
        case NetworkType::Dev:     name_str = "devnet"; break;
        case NetworkType::Test:    name_str = "testnet"; break;
        case NetworkType::Primary: name_str = "primarynet"; break;
    }

    data_["network"]["type"] = type_str;
    data_["network"]["name"] = name_str;
}

void Genesis::SetNetworkName(const std::string& name) {
    data_["network"]["name"] = name;
    SyncNetworkNameAndType();  // 强制同步
}

std::unordered_set<std::string> Genesis::GetVRFWhitelist() const {
    std::unordered_set<std::string> result;
    if (data_["genesis"].contains("vrfWhitelist") && data_["genesis"]["vrfWhitelist"].is_array()) {
        for (const auto& addr : data_["genesis"]["vrfWhitelist"]) {
            result.insert(addr.get<std::string>());
        }
    }
    return result;
}

void Genesis::SyncNetworkNameAndType() {
    std::string name = data_["network"]["name"].get<std::string>();
    std::string type;

    if (name == "devnet")      type = "dev";
    else if (name == "testnet") type = "test";
    else if (name == "primarynet") type = "primary";
    else {
        // 未知名称，使用默认 dev
        type = "dev";
        data_["network"]["name"] = "devnet";
    }

    data_["network"]["type"] = type;
}

// 辅助函数
std::string Genesis::NetworkTypeToString(NetworkType type) {
    switch (type) {
        case NetworkType::Dev:     return "dev";
        case NetworkType::Test:    return "test";
        case NetworkType::Primary: return "primary";
        default: return "dev";
    }
}

Genesis::NetworkType Genesis::StringToNetworkType(const std::string& typeStr) {
    if (typeStr == "dev")     return NetworkType::Dev;
    if (typeStr == "test")    return NetworkType::Test;
    if (typeStr == "primary") return NetworkType::Primary;
    return NetworkType::Dev;  // 默认
}

json Genesis::CreateDefaultData()
{
    return CreateDefaultData(Genesis::NetworkType::Dev);
}
json Genesis::CreateDefaultData(NetworkType type)
{
    json dev_genesis = {
        {"genesis", {
            {"blockData", {
                {"Name", "DevChain"},
                {"Type", "Genesis"}
            }},
            {"genesisTime", 1769736708175000},
            {"initAccountAddr", "755Ccf704E17570b64E247f0794314e4C8E542CA"},
            {"initialBalance", {
                {"OHI",   0}
            }},
            {"vrfWhitelist", json::array()}
        }},
        {"network", {
            {"name", "devnet"},
            {"type", "dev"}
        }},
        {"version", "1.0.0"}
    };

    json test_genesis = {
        {"genesis", {
            {"blockData", {
                {"Name", "TestChain"},
                {"Type", "Genesis"}
            }},
            {"genesisTime", 1769736708175000},
            {"initAccountAddr", "755Ccf704E17570b64E247f0794314e4C8E542CA"},
            {"initialBalance", {
                {"OHI",   0}
            }},
            {"vrfWhitelist", json::array()}
        }},
        {"network", {
            {"name", "testnet"},
            {"type", "test"}
        }},
        {"version", "1.0.0"}
    };

    json primary_genesis = {
        {"genesis", {
            {"blockData", {
                {"Name", "PrimaryChain"},
                {"Type", "Genesis"}
            }},
            {"genesisTime", 1692662400000000},
            {"initAccountAddr", "De8AB34f772f21940DE50583A8d2756bFD0e4FD7"},
            {"initialBalance", {
                {"OHI",   0}
            }},
            {"vrfWhitelist", json::array()}
        }},
        {"network", {
            {"name", "primarynet"},
            {"type", "primary"}
        }},
        {"version", "1.0.0"}
    };
    
    if (type == Genesis::NetworkType::Dev) 
    {
        return dev_genesis;
    }
    else if (type == Genesis::NetworkType::Test)
    {
        return test_genesis;
    }
    else 
    {
        return dev_genesis;
    }
}

bool Genesis::TryLoadFromFile(const std::string& path, json& out_data)
{
    std::ifstream ifs(path);
    if (!ifs.is_open()) {
        return false;
    }

    try 
    {
        ifs >> out_data;
    }
    catch (const json::parse_error&) 
    {
        return false;
    }

    // 最小结构校验
    if (!out_data.contains("genesis") ||
        !out_data.contains("network") ||
        !out_data["network"].contains("type") ||
        !out_data["network"].contains("name")) 
    {
        return false;
    }

    return true;
}