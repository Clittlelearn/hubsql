#ifndef DATABASE_DB_API_HEADER
#define DATABASE_DB_API_HEADER

#include "db/rocksdb_read.h"
#include "db/rocksdb_read_write.h"
#include "pb/block.pb.h"
#include <string>
#include <vector>

bool DBInit(const std::string &path);

enum DBStatus
{
    DB_SUCCESS = 0,                  // Operation successful
    DB_ERROR = 1,                    // General error
    DB_PARAM_NULL = 2,               // Parameter is null
    DB_NOT_FOUND = 3,                // Data not found
    DB_IS_EXIST = 4,                 // Data already exists
    DB_DESERIALIZATION_FAILED = 5    // Deserialization failed
};

class DBReader
{
public:
    DBReader();
    ~DBReader() = default;
    DBReader(DBReader &&) = delete;
    DBReader(const DBReader &) = delete;
    DBReader &operator=(DBReader &&) = delete;
    DBReader &operator=(const DBReader &) = delete;
    


    /**
     * @brief 获取总循环供应量
     * 
     * @param totalCirculation 用于存储总循环供应量
     * @return DBStatus 操作结果状态码
     */
    /**
    * @brief Get total circulation supply
    * 
    * @param totalCirculation Variable to store total circulation supply
    * @return DBStatus Operation result status code
    */
    DBStatus getTotalCirculation(uint64_t &totalCirculation);


    /**
     * @brief 根据区块高度范围获取区块哈希列表
     * 
     * @param startHeight 起始区块高度
     * @param endHeight 结束区块高度
     * @param blockHashes 用于存储区块哈希的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get block hash list by block height range
     * 
     * @param startHeight Start block height
     * @param endHeight End block height
     * @param blockHashes String vector to store block hashes
     * @return DBStatus Operation result status code
     */
    DBStatus getBlockHashesByBlockHeight(uint64_t startHeight, uint64_t endHeight, std::vector<std::string> &blockHashes);

    /**
     * @brief 根据区块哈希列表获取区块内容
     * 
     * @param blockHashes 区块哈希数组
     * @param blocks 用于存储区块内容的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get block contents by block hash list
     * 
     * @param blockHashes Vector of block hashes
     * @param blocks String vector to store block contents
     * @return DBStatus Operation result status code
     */
    DBStatus getBlocksByBlockHash(const std::vector<std::string> &blockHashes, std::vector<std::string> &blocks);

    /**
     * @brief 根据区块哈希获取区块高度
     * 
     * @param blockHash 区块哈希
     * @param blockHeight 用于存储区块高度
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get block height by block hash
     * 
     * @param blockHash Block hash
     * @param blockHeight Variable to store block height
     * @return DBStatus Operation result status code
     */
    DBStatus getBlockHeightByBlockHash(const std::string &blockHash, unsigned int &blockHeight);

    /**
     * @brief 根据区块高度获取区块哈希
     * 
     * @param blockHeight 区块高度
     * @param hash 用于存储区块哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get block hash by block height
     * 
     * @param blockHeight Block height
     * @param hash Variable to store block hash
     * @return DBStatus Operation result status code
     */
    DBStatus getBlockHashByBlockHeight(uint64_t blockHeight, std::string &hash);

    /**
     * @brief 根据区块高度获取所有区块哈希（可能存在分叉）
     * 
     * @param blockHeight 区块高度
     * @param hashes 用于存储区块哈希的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get all block hashes by block height (may have forks)
     * 
     * @param blockHeight Block height
     * @param hashes String vector to store block hashes
     * @return DBStatus Operation result status code
     */
    DBStatus getBlockHashsByBlockHeight(uint64_t blockHeight, std::vector<std::string> &hashes);

    /**
     * @brief 根据区块哈希获取区块内容
     * 
     * @param blockHash 区块哈希
     * @param block 用于存储区块内容
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get block content by block hash
     * 
     * @param blockHash Block hash
     * @param block Variable to store block content
     * @return DBStatus Operation result status code
     */
    DBStatus getBlockByBlockHash(const std::string &blockHash, std::string &block);

    /**
     * @brief 根据区块高度获取汇总哈希
     * 
     * @param height 区块高度
     * @param sumHash 用于存储汇总哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get summary hash by block height
     * 
     * @param height Block height
     * @param sumHash Variable to store summary hash
     * @return DBStatus Operation result status code
     */
    DBStatus getSumHashByHeight(uint64_t height, std::string& sumHash);

    /**
     * @brief 根据区块高度获取校验区块哈希
     * 
     * @param blockHeight 区块高度
     * @param sumHash 用于存储校验哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get check block hash by block height
     * 
     * @param blockHeight Block height
     * @param sumHash Variable to store check hash
     * @return DBStatus Operation result status code
     */
    DBStatus getThousandSumHashByBlockHeight(const uint64_t &blockHeight, std::string &sumHash);

    /**
     * @brief 获取前一千个区块的汇总哈希
     * 
     * @param thousandNum 用于存储区块数量
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the summary hash of the top thousand blocks
     * 
     * @param thousandNum Variable to store the number of blocks
     * @return DBStatus Operation result status code
     */
    DBStatus getThousandSumHashTop(uint64_t &thousandNum);

    /**
     * @brief 获取当前区块链的最高区块高度
     * 
     * @param blockHeight 用于存储最高区块高度
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the top block height of the current blockchain
     * 
     * @param blockHeight Variable to store the top block height
     * @return DBStatus Operation result status code
     */
    DBStatus getBlockTop(uint64_t &blockHeight);

    /**
     * @brief 根据地址和资产类型获取该地址下所有UTXO哈希
     * 
     * @param address 地址
     * @param assetType 资产类型
     * @param utxoHashesList 用于存储UTXO哈希的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get all UTXO hashes for a given address and asset type
     * 
     * @param address Address
     * @param assetType Asset type
     * @param utxoHashesList String vector to store UTXO hashes
     * @return DBStatus Operation result status code
     */
    DBStatus getUtxoHashsByAddress(const std::string &address, const std::string& assetType, std::vector<std::string> &utxoHashesList);

    /**
     * @brief 根据UTXO哈希、地址和资产类型获取余额
     * 
     * @param utxoHash UTXO哈希
     * @param address 地址
     * @param assetType 资产类型
     * @param balance 用于存储余额
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get balance by UTXO hash, address and asset type
     * 
     * @param utxoHash UTXO hash
     * @param address Address
     * @param assetType Asset type
     * @param balance Variable to store balance
     * @return DBStatus Operation result status code
     */
    DBStatus getUtxoValueByUtxoHashes(const std::string &utxoHash, const std::string &address, const std::string &assetType, std::string &balance);

    /**
     * @brief 根据交易哈希获取交易原始数据
     * 
     * @param txHash 交易哈希
     * @param txRaw 用于存储交易原始数据
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get transaction raw data by transaction hash
     * 
     * @param txHash Transaction hash
     * @param txRaw Variable to store transaction raw data
     * @return DBStatus Operation result status code
     */
    DBStatus getTransactionByHash(const std::string &txHash, std::string &txRaw);

    /**
     * @brief 根据交易哈希获取所在区块哈希
     * 
     * @param txHash 交易哈希
     * @param blockHash 用于存储区块哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get block hash by transaction hash
     * 
     * @param txHash Transaction hash
     * @param blockHash Variable to store block hash
     * @return DBStatus Operation result status code
     */
    DBStatus getBlockHashByTransactionHash(const std::string &txHash, std::string &blockHash);

    /**
     * @brief 获取指定地址和资产类型的余额
     * 
     * @param address 地址
     * @param assetType 资产类型
     * @param balance 用于存储余额
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the balance for a given address and asset type
     * 
     * @param address Address
     * @param assetType Asset type
     * @param balance Variable to store the balance
     * @return DBStatus Operation result status code
     */
    DBStatus getBalanceByAddr(const std::string &address, const std::string& assetType, int64_t &balance);

    /**
     * @brief 获取指定地址的nonce值
     * 
     * @param address 地址
     * @param nonce 用于存储nonce值
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the nonce for a given address
     * 
     * @param address Address
     * @param nonce Variable to store the nonce
     * @return DBStatus Operation result status code
     */
    DBStatus getNonceByAddr(const std::string &address, uint64_t &nonce);
    DBStatus getPendingTransactionReservations(std::string &reservations);
    DBStatus getContractWaitingBatches(std::string &batches);

    /**
     * @brief 获取所有质押地址列表
     * 
     * @param addresses 用于存储质押地址的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the list of all stake addresses
     * 
     * @param addresses String vector to store stake addresses
     * @return DBStatus Operation result status code
     */
    DBStatus getStakeAddr(std::vector<std::string> &addresses);

    /**
     * @brief 获取指定地址和资产类型的质押UTXO列表
     * 
     * @param address 质押地址
     * @param assetType 资产类型
     * @param utxos 用于存储UTXO的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the list of stake UTXOs for a given address and asset type
     * 
     * @param address Stake address
     * @param assetType Asset type
     * @param utxos String vector to store UTXOs
     * @return DBStatus Operation result status code
     */
    DBStatus getStakeUtxoByAddr(const std::string &address, const std::string& assetType, std::vector<std::string> &utxos);

    /**
     * @brief 根据分红地址获取委托地址及其相关信息（多重映射）
     * 
     * @param bonusAddr 分红地址
     * @param delegatingAddr 用于存储委托地址及其相关信息的多重映射
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the delegating addresses and related info by bonus address (multimap)
     * 
     * @param bonusAddr Bonus address
     * @param delegatingAddr Multimap to store delegating addresses and related info
     * @return DBStatus Operation result status code
     */
    DBStatus getDelegatingAddrAndAssetTypeByBonusAddr(const std::string &bonusAddr, std::multimap<std::string, std::string> &delegatingAddr);

    /**
     * @brief 根据委托地址获取分红节点地址及资产类型
     * 
     * @param address 委托地址
     * @param nodes 用于存储分红节点地址及资产类型的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the bonus node addresses and asset types by delegating address
     * 
     * @param address Delegating address
     * @param nodes String vector to store bonus node addresses and asset types
     * @return DBStatus Operation result status code
     */
    DBStatus getBonusAddrAndAssetTypeByDelegatingAddr(const std::string &address, std::multimap<std::string, std::string> & bonusAddr_assetType);

    /**
     * @brief 根据分红地址、委托地址和资产类型获取对应的UTXO列表
     * 
     * @param bonusAddr 分红地址
     * @param delegatingAddr 委托地址
     * @param assetType 资产类型
     * @param utxos 用于存储UTXO的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the UTXO list by bonus address, delegating address and asset type
     * 
     * @param bonusAddr Bonus address
     * @param delegatingAddr Delegating address
     * @param assetType Asset type
     * @param utxos String vector to store UTXOs
     * @return DBStatus Operation result status code
     */
    DBStatus getDelegatingAddrUtxoByBonusAddr(const std::string &bonusAddr, const std::string &delegatingAddr,  const std::string assetType, std::vector<std::string> &utxos);

    /**
     * @brief 根据周期获取分红UTXO列表
     * 
     * @param period 周期
     * @param utxos 用于存储UTXO的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the bonus UTXO list by period
     * 
     * @param period Period
     * @param utxos String vector to store UTXOs
     * @return DBStatus Operation result status code
     */
    DBStatus getBonusUtxoByPeriod(const uint64_t &period, std::vector<std::string> &utxos);

    /**
     * @brief 根据周期获取基金UTXO列表
     * 
     * @param period 周期
     * @param utxos 用于存储UTXO的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the fund UTXO list by period
     * 
     * @param period Period
     * @param utxos String vector to store UTXOs
     * @return DBStatus Operation result status code
     */
    DBStatus getFundUtxoByPeriod(const uint64_t &period, std::vector<std::string> &utxos);

    /**
     * @brief 根据周期获取委托UTXO列表
     * 
     * @param period 周期
     * @param utxos 用于存储UTXO的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the delegating UTXO list by period
     * 
     * @param period Period
     * @param utxos String vector to store UTXOs
     * @return DBStatus Operation result status code
     */
    DBStatus getDelegatingUtxoByPeriod(const uint64_t &period, std::vector<std::string> &utxos);

    /**
     * @brief 根据周期和地址获取签名数
     * 
     * @param period 周期
     * @param address 地址
     * @param signNumber 用于存储签名数
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the number of signatures by period and address
     * 
     * @param period Period
     * @param address Address
     * @param signNumber Variable to store the number of signatures
     * @return DBStatus Operation result status code
     */
    DBStatus getSignCountByPeriod(const uint64_t &period, const std::string &address, uint64_t &signNumber);

    /**
     * @brief 根据周期获取区块数
     * 
     * @param period 周期
     * @param blockNumber 用于存储区块数
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the number of blocks by period
     * 
     * @param period Period
     * @param blockNumber Variable to store the number of blocks
     * @return DBStatus Operation result status code
     */
    DBStatus getBlockNumberByPeriod(const uint64_t &period, uint64_t &blockNumber);

    /**
     * @brief 根据周期获取签名地址列表
     * 
     * @param period 周期
     * @param signAddresses 用于存储签名地址的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the list of sign addresses by period
     * 
     * @param period Period
     * @param signAddresses String vector to store sign addresses
     * @return DBStatus Operation result status code
     */
    DBStatus getSignAddrByPeriod(const uint64_t &period, std::vector<std::string> &signAddresses);

    /**
     * @brief 根据周期获取销毁数量
     * 
     * @param period 周期
     * @param burnAmount 用于存储销毁数量
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the burn amount by period
     * 
     * @param period Period
     * @param burnAmount Variable to store the burn amount
     * @return DBStatus Operation result status code
     */
    DBStatus getBurnAmountByPeriod(const uint64_t &period, uint64_t &burnAmount);

    /**
     * @brief 获取总委托数量
     * 
     * @param Total 用于存储总委托数量
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the total delegate amount
     * 
     * @param Total Variable to store the total delegate amount
     * @return DBStatus Operation result status code
     */
    DBStatus getTotalDelegatingAmount(uint64_t &Total);

    /**
     * @brief 获取总销毁数量
     * 
     * @param totalBurn 用于存储总销毁数量
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the total burn amount
     * 
     * @param totalBurn Variable to store the total burn amount
     * @return DBStatus Operation result status code
     */
    DBStatus getTotalBurnAmount(uint64_t &totalBurn);

    /**
     * @brief 获取所有EVM合约部署者地址
     * 
     * @param deployerAddr 用于存储部署者地址的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get all EVM contract deployer addresses
     * 
     * @param deployerAddr String vector to store deployer addresses
     * @return DBStatus Operation result status code
     */
    DBStatus getEvmDeployerAddr(std::vector<std::string> &deployerAddr);

    /**
     * @brief 根据部署者地址获取合约地址列表
     * 
     * @param deployerAddr 部署者地址
     * @param contractAddr 用于存储合约地址的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get contract addresses by deployer address
     * 
     * @param deployerAddr Deployer address
     * @param contractAddr String vector to store contract addresses
     * @return DBStatus Operation result status code
     */
    DBStatus getContractAddrByDeployerAddr(const std::string &deployerAddr, std::vector<std::string> &contractAddr);

    /**
     * @brief 根据合约地址获取合约代码
     * 
     * @param contractAddr 合约地址
     * @param contractCode 用于存储合约代码
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get contract code by contract address
     * 
     * @param contractAddr Contract address
     * @param contractCode Variable to store contract code
     * @return DBStatus Operation result status code
     */
    DBStatus getContractCodeByContractAddr(const std::string &contractAddr, std::string &contractCode);

    /**
     * @brief 根据合约地址获取合约部署UTXO
     * 
     * @param contractAddr 合约地址
     * @param contractDeploymentUtxo 用于存储合约部署UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get contract deployment UTXO by contract address
     * 
     * @param contractAddr Contract address
     * @param contractDeploymentUtxo Variable to store contract deployment UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus getContractDeployUtxoByContractAddr(const std::string &contractAddr, std::string &contractDeploymentUtxo);

    /**
     * @brief 根据合约地址获取最新UTXO
     * 
     * @param contractAddr 合约地址
     * @param Utxo 用于存储最新UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the latest UTXO by contract address
     * 
     * @param contractAddr Contract address
     * @param Utxo Variable to store the latest UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus getLatestUtxoByContractAddr(const std::string &contractAddr, std::string &Utxo);

    /**
     * @brief 根据MPT键获取MPT值
     * 
     * @param mptKey MPT键
     * @param mptValue 用于存储MPT值
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the MPT value by MPT key
     * 
     * @param mptKey MPT key
     * @param mptValue Variable to store MPT value
     * @return DBStatus Operation result status code
     */
    DBStatus getMptValueByMptKey(const std::string &mptKey, std::string &mptValue);


    /**
     * @brief 获取所有资产类型
     * 
     * @param assetTypes 用于存储所有资产类型的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get all asset types
     * 
     * @param assetTypes String vector to store all asset types
     * @return DBStatus Operation result status code
     */
    DBStatus getAssetType(std::vector<std::string> &assetTypes);

    /**
     * @brief 根据资产类型获取撤销交易哈希列表
     * 
     * @param assetType 资产类型
     * @param revokeTxHashs 用于存储撤销交易哈希的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get revoke transaction hashes by asset type
     * 
     * @param assetType Asset type
     * @param revokeTxHashs String vector to store revoke transaction hashes
     * @return DBStatus Operation result status code
     */
    DBStatus getRevokeTxHashByAssetType(const std::string &assetType, std::vector<std::string> &revokeTxHashs);

    /**
     * @brief 根据资产哈希获取同意地址集合
     * 
     * @param assetType 资产哈希
     * @param addrs 用于存储同意地址的集合
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get approve addresses by asset hash
     * 
     * @param assetType Asset hash
     * @param addrs Set to store approve addresses
     * @return DBStatus Operation result status code
     */
    DBStatus getApproveAddrsByAssetType(const std::string &assetType, std::set<std::string> &addrs);

    /**
     * @brief 根据资产哈希获取反对地址集合
     * 
     * @param assetType 资产哈希
     * @param addrs 用于存储反对地址的集合
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get against addresses by asset hash
     * 
     * @param assetType Asset hash
     * @param addrs Set to store against addresses
     * @return DBStatus Operation result status code
     */
    DBStatus getAgainstAddrsByAssetType(const std::string &assetType, std::set<std::string> &addrs);

    /**
     * @brief 根据资产哈希获取投票交易哈希列表
     * 
     * @param assetType 资产哈希
     * @param txHashs 用于存储投票交易哈希的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get vote transaction hashes by asset hash
     * 
     * @param assetType Asset hash
     * @param txHashs String vector to store vote transaction hashes
     * @return DBStatus Operation result status code
     */
    DBStatus getVoteTxHashByAssetType(const std::string &assetType, std::vector<std::string> &txHashs);

    /**
     * @brief 根据资产类型获取资产信息
     * 
     * @param assetType 资产类型
     * @param info 用于存储资产信息的字符串
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get asset information by asset type
     * 
     * @param assetType Asset type
     * @param info String to store asset information
     * @return DBStatus Operation result status code
     */
    DBStatus getProposalInfoByAssetType(const std::string &assetType, std::string& info);

    /**
     * @brief 根据交易哈希获取撤销提案信息
     * 
     * @param TxHash 交易哈希
     * @param info 用于存储撤销提案信息的字符串
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get revoke proposal information by transaction hash
     * 
     * @param TxHash Transaction hash
     * @param info String to store revoke proposal information
     * @return DBStatus Operation result status code
     */
    DBStatus getRevokeProposalInfoByAssetType(const std::string & assetType, std::string& info);

    /**
     * @brief 根据资产哈希获取投票数量信息
     * 
     * @param assetType 资产哈希
     * @param info 用于存储投票数量信息的字符串
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get vote number information by asset hash
     * 
     * @param assetType Asset hash
     * @param info String to store vote number information
     * @return DBStatus Operation result status code
     */
    DBStatus getVoteCountByAssetType(const std::string &assetType, uint64_t & approve, uint64_t & against);

    /**
     * @brief 根据地址和资产类型获取投票数量
     * 
     * @param addr 地址
     * @param assetType 资产类型
     * @param num 用于存储投票数量
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get vote number by address and asset type
     * 
     * @param addr Address
     * @param assetType Asset type
     * @param num Variable to store vote number
     * @return DBStatus Operation result status code
     */
    DBStatus getVoteCountByAddr(const std::string &addr, const std::string &assetType, uint64_t& num);

    /**
     * @brief 根据资产哈希获取投票者总数
     * 
     * @param assetType 资产哈希
     * @param num 用于存储投票者总数
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get total number of voters by asset hash
     * 
     * @param assetType Asset hash
     * @param num Variable to store total number of voters
     * @return DBStatus Operation result status code
     */
    DBStatus getTotalCountByAssetType(const std::string &assetType, uint64_t& num);

    /**
     * @brief 获取所有锁定地址
     * 
     * @param addresses 用于存储锁定地址的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get all lock addresses
     * 
     * @param addresses String vector to store lock addresses
     * @return DBStatus Operation result status code
     */
    DBStatus getLockAddr(std::vector<std::string> &addresses);
    
    /**
     * @brief 根据锁定地址和资产类型获取UTXO列表
     * 
     * @param address 锁定地址
     * @param assetType 资产类型
     * @param utxos 用于存储UTXO的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get UTXO list by lock address and asset type
     * 
     * @param address Lock address
     * @param assetType Asset type
     * @param utxos String vector to store UTXOs
     * @return DBStatus Operation result status code
     */
    DBStatus getLockAddrUtxo(const std::string &address, const std::string &assetType, std::vector<std::string> &utxos);

    /**
     * @brief 根据地址获取资产类型列表
     * 
     * @param addr 地址
     * @param assetType 用于存储资产类型的字符串数组
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get asset types by address
     * 
     * @param addr Address
     * @param assetType String vector to store asset types
     * @return DBStatus Operation result status code
     */
    DBStatus getAssetTypeByAddr(const std::string& addr, std::vector<std::string> &assetType);

    /**
     * @brief 根据合约地址获取资产类型
     * 
     * @param contractAddr 合约地址
     * @param assetType 用于存储资产类型的字符串
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get asset type by contract address
     * 
     * @param contractAddr Contract address
     * @param assetType String to store asset type
     * @return DBStatus Operation result status code
     */
    DBStatus getAssetTypeByContractAddr(const std::string& contractAddr, std::string &assetType);

    /**
     * @brief 根据周期和类型获取Gas消耗量
     * 
     * @param period 周期
     * @param type 类型
     * @param gasAmount 用于存储Gas消耗量
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get gas amount by period and type
     * 
     * @param period Period
     * @param type Type
     * @param gasAmount Variable to store gas amount
     * @return DBStatus Operation result status code
     */
    DBStatus getGasAmountByPeriod(const uint64_t &period, const std::string &type,uint64_t &gasAmount);

    /**
     * @brief 根据周期和地址获取打包者打包次数
     * 
     * @param period 周期
     * @param address 地址
     * @param times 用于存储打包次数
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get packager times by period and address
     * 
     * @param period Period
     * @param address Address
     * @param times Variable to store packager times
     * @return DBStatus Operation result status code
     */
    DBStatus getPackagerCountByPeriod(const uint64_t& period, const std::string& address, uint64_t& count);

    /**
     * @brief 获取总锁定金额
     * 
     * @param TotalLockedAmount 用于存储总锁定金额
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get total locked amount
     * 
     * @param TotalLockedAmount Variable to store total locked amount
     * @return DBStatus Operation result status code
     */
    DBStatus getTotalLockedAmonut(uint64_t& TotalLockedAmount);



    /**
     * @brief 获取某一天总锁定金额
     * 
     * @param period 周期
     * @param LockedAmount 用于存储总锁定金额  
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get total locked amount by day
     * 
     * @param period Period
     * @param LockedAmount Variable to store total locked amount
     * @return DBStatus Operation result status code
     */
    DBStatus getTotalLockedAmountByPeriod(const uint64_t& period, uint64_t& LockedAmount);


    /**
     * @brief 获取数据库初始化版本号
     * 
     * @param version 用于存储版本号
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Get the database initialization version
     * 
     * @param version Variable to store the version
     * @return DBStatus Operation result status code
     */
    DBStatus getInitVer(std::string &version);



    /**
     * @brief 批量读取多个键值
     * 
     * @param keys 需要读取的键集合
     * @param values 用于存储读取到的值的集合
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Batch read multiple key-value pairs
     * 
     * @param keys The collection of keys to read
     * @param values The collection to store the read values
     * @return DBStatus Operation result status code
     */
    virtual DBStatus multiReadData(const std::vector<std::string> &keys, std::vector<std::string> &values);

    /**
     * @brief 读取单个键值
     * 
     * @param key 需要读取的键
     * @param value 用于存储读取到的值
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Read a single key-value pair
     * 
     * @param key The key to read
     * @param value The variable to store the read value
     * @return DBStatus Operation result status code
     */
    virtual DBStatus readData(const std::string &key, std::string &value);

    DBStatus getInternalHashByRlpHash(const std::string &rlpHash, std::string &internalHash);

    // === Slashing read interfaces ===

    // evidence_hash -> target_addr,violation_type. Used for EVIDENCE idempotency.
    DBStatus hasEvidenceOnChain(const std::string &evidenceHash);
    DBStatus getEvidenceOnChain(const std::string &evidenceHash, std::string &targetAddr, std::string &violationType);
    // addr,type -> current unpunished evidence count.
    DBStatus getEvidenceCount(const std::string &addr, const std::string &type, int64_t &count);
    // Threshold list stores addresses that reached the punishment threshold.
    DBStatus getThresholdExceededEntries(std::vector<std::string> &addresses);
    // addr -> level,violation_type,evidence_refs.
    DBStatus getThresholdDetail(const std::string &addr, std::string &level, std::string &violationType, std::string &evidenceRefs);
    // punishment_id -> target_addr,period,level,tx_hash.
    DBStatus hasPunishmentHistory(const std::string &punishmentId);
    DBStatus getPunishmentHistory(const std::string &punishmentId, std::string &targetAddr, std::string &period, uint32_t &level, std::string &txHash);
    // addr -> punishment_id list for RPC lookup only.
    DBStatus getPunishmentHistoryByAddr(const std::string &addr, std::vector<std::string> &punishmentIds);
    DBStatus getTombstonedAddrs(std::vector<std::string> &addresses);
    DBStatus isTombstoned(const std::string &addr);
    DBStatus isJailed(const std::string &addr);

private:
    RocksDBDataReader db_reader_;
};

class DBReadWriter : public DBReader
{
public:
    DBReadWriter(const std::string &txn_name = std::string());
    virtual ~DBReadWriter();
    DBReadWriter(DBReadWriter &&) = delete;
    DBReadWriter(const DBReadWriter &) = delete;
    DBReadWriter &operator=(DBReadWriter &&) = delete;
    DBReadWriter &operator=(const DBReadWriter &) = delete;
    
    /**
     * @brief 重新初始化事务
     * 
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Re-initialize the transaction
     * 
     * @return DBStatus Operation result status code
     */
    DBStatus reInitTransaction();

    /**
     * @brief 提交当前事务
     * 
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Commit the current transaction
     * 
     * @return DBStatus Operation result status code
     */
    DBStatus transactionCommit();

    /**
     * @brief 设置指定地址的nonce值
     * 
     * @param address 地址
     * @param nonce nonce值
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set the nonce for a given address
     * 
     * @param address Address
     * @param nonce Nonce value
     * @return DBStatus Operation result status code
     */
    DBStatus setNonceByAddr(const std::string &address, uint64_t nonce);
    DBStatus setPendingTransactionReservations(const std::string &reservations);
    DBStatus setContractWaitingBatches(const std::string &batches);

    /**
     * @brief 设置总循环供应量
     * 
     * @param totalCirculation 总循环供应量
     * @return DBStatus 操作结果状态码
     */
    DBStatus setTotalCirculation(uint64_t totalCirculation);


    /**
     * @brief 删除总循环供应量
     * 
     * @return DBStatus 操作结果状态码
     */
    DBStatus removeTotalCirculation();


    /**
     * @brief 通过区块哈希设置区块高度
     * 
     * @param blockHash 区块哈希
     * @param blockHeight 区块高度
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set block height by block hash
     * 
     * @param blockHash Block hash
     * @param blockHeight Block height
     * @return DBStatus Operation result status code
     */
    DBStatus setBlockHeightByBlockHash(const std::string &blockHash, const unsigned int blockHeight);

    /**
     * @brief 通过区块哈希删除区块高度
     * 
     * @param blockHash 区块哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Delete block height by block hash
     * 
     * @param blockHash Block hash
     * @return DBStatus Operation result status code
     */
    DBStatus removeBlockHeightByBlockHash(const std::string &blockHash);

    /**
     * @brief 通过区块高度设置区块哈希
     * 
     * @param blockHeight 区块高度
     * @param blockHash 区块哈希
     * @param isMainBlock 是否为主区块，默认为false
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set block hash by block height
     * 
     * @param blockHeight Block height
     * @param blockHash Block hash
     * @param isMainBlock Whether it is the main block, default is false
     * @return DBStatus Operation result status code
     */
    DBStatus setBlockHashByBlockHeight(const unsigned int blockHeight, const std::string &blockHash, bool isMainBlock = false);

    /**
     * @brief 通过区块高度移除区块哈希
     * 
     * @param blockHeight 区块高度
     * @param blockHash 区块哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove block hash by block height
     * 
     * @param blockHeight Block height
     * @param blockHash Block hash
     * @return DBStatus Operation result status code
     */
    DBStatus removeBlockHashByBlockHeight(const unsigned int blockHeight, const std::string &blockHash);

    /**
     * @brief 通过区块哈希设置区块内容
     * 
     * @param blockHash 区块哈希
     * @param block 区块内容
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set block content by block hash
     * 
     * @param blockHash Block hash
     * @param block Block content
     * @return DBStatus Operation result status code
     */
    DBStatus setBlockByBlockHash(const std::string &blockHash, const std::string &block);

    /**
     * @brief 通过区块哈希删除区块内容
     * 
     * @param blockHash 区块哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Delete block content by block hash
     * 
     * @param blockHash Block hash
     * @return DBStatus Operation result status code
     */
    DBStatus removeBlockByBlockHash(const std::string &blockHash);

    /**
     * @brief 通过高度设置汇总哈希
     * 
     * @param height 区块高度
     * @param sumHash 汇总哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set sum hash by height
     * 
     * @param height Block height
     * @param sumHash Sum hash
     * @return DBStatus Operation result status code
     */
    DBStatus setSumHashByHeight(uint64_t height, const std::string& sumHash);

    /**
     * @brief 通过高度移除汇总哈希
     * 
     * @param height 区块高度
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove sum hash by height
     * 
     * @param height Block height
     * @return DBStatus Operation result status code
     */
    DBStatus removeSumHashByHeight(uint64_t height);   

    /**
     * @brief 通过区块高度设置校验区块哈希
     * 
     * @param blockHeight 区块高度
     * @param sumHash 校验哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set check block hashes by block height
     * 
     * @param blockHeight Block height
     * @param sumHash Check hash
     * @return DBStatus Operation result status code
     */
    DBStatus setThousandSumHashByBlockHeight(const uint64_t &blockHeight ,const std::string &sumHash);

    /**
     * @brief 通过区块高度移除校验区块哈希
     * 
     * @param blockHeight 区块高度
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove thousand sum hashes by block height
     * 
     * @param blockHeight Block height
     * @return DBStatus Operation result status code
     */
    DBStatus removeThousandSumHashByBlockHeight(const uint64_t &blockHeight);

    /**
     * @brief 设置千区块汇总哈希
     * 
     * @param thousandNum 千区块编号
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set top thousand sum hash
     * 
     * @param thousandNum Thousand block number
     * @return DBStatus Operation result status code
     */
    DBStatus setThousandSumHashTop(const uint64_t &thousandNum);

    /**
     * @brief 移除千区块汇总哈希
     * 
     * @param thousandNum 千区块编号
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove top thousand sum hash
     * 
     * @param thousandNum Thousand block number
     * @return DBStatus Operation result status code
     */
    DBStatus removeThousandSumHashTop(const uint64_t &thousandNum);   

    /**
     * @brief 设置区块链最高高度
     * 
     * @param blockHeight 区块高度
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set blockchain top height
     * 
     * @param blockHeight Block height
     * @return DBStatus Operation result status code
     */
    DBStatus setBlockTop(const unsigned int blockHeight);

    /**
     * @brief 设置地址下某资产类型的UTXO哈希
     * 
     * @param address 地址
     * @param assetType 资产类型
     * @param utxoHash UTXO哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set UTXO hash for address and asset type
     * 
     * @param address Address
     * @param assetType Asset type
     * @param utxoHash UTXO hash
     * @return DBStatus Operation result status code
     */
    DBStatus setUtxoHashesByAddr(const std::string &address, const std::string &assetType, const std::string &utxoHash);

    /**
     * @brief 移除地址下某资产类型的UTXO哈希
     * 
     * @param address 地址
     * @param assetType 资产类型
     * @param utxoHash UTXO哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove UTXO hash for address and asset type
     * 
     * @param address Address
     * @param assetType Asset type
     * @param utxoHash UTXO hash
     * @return DBStatus Operation result status code
     */
    DBStatus removeUtxoHashesByAddr(const std::string &address, const std::string &assetType, const std::string &utxoHash);

    /**
     * @brief 设置UTXO哈希对应的余额信息
     * 
     * @param utxoHash UTXO哈希
     * @param address 地址
     * @param assetType 资产类型
     * @param balance 余额
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set balance information for UTXO hash
     * 
     * @param utxoHash UTXO hash
     * @param address Address
     * @param assetType Asset type
     * @param balance Balance
     * @return DBStatus Operation result status code
     */
    DBStatus setUtxoValueByUtxoHashes(const std::string &utxoHash, const std::string &address, const std::string &assetType, const std::string &balance);

    /**
     * @brief 移除UTXO哈希对应的余额信息
     * 
     * @param utxoHash UTXO哈希
     * @param address 地址
     * @param assetType 资产类型
     * @param balance 余额
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove balance information for UTXO hash
     * 
     * @param utxoHash UTXO hash
     * @param address Address
     * @param assetType Asset type
     * @param balance Balance
     * @return DBStatus Operation result status code
     */
    DBStatus removeUtxoValueByUtxoHashes(const std::string &utxoHash, const std::string &address, const std::string &assetType, const std::string &balance);

    /**
     * @brief 通过交易哈希设置交易内容
     * 
     * @param txHash 交易哈希
     * @param txRaw 交易原始内容
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set transaction content by transaction hash
     * 
     * @param txHash Transaction hash
     * @param txRaw Transaction raw content
     * @return DBStatus Operation result status code
     */
    DBStatus setTransactionByHash(const std::string &txHash, const std::string &txRaw);

    /**
     * @brief 通过交易哈希删除交易内容
     * 
     * @param txHash 交易哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Delete transaction content by transaction hash
     * 
     * @param txHash Transaction hash
     * @return DBStatus Operation result status code
     */
    DBStatus removeTransactionByHash(const std::string &txHash);

    /**
     * @brief 通过交易哈希设置区块哈希
     * 
     * @param txHash 交易哈希
     * @param blockHash 区块哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set block hash by transaction hash
     * 
     * @param txHash Transaction hash
     * @param blockHash Block hash
     * @return DBStatus Operation result status code
     */
    DBStatus setBlockHashByTransactionHash(const std::string &txHash, const std::string &blockHash);

    /**
     * @brief 通过交易哈希删除区块哈希
     * 
     * @param txHash 交易哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Delete block hash by transaction hash
     * 
     * @param txHash Transaction hash
     * @return DBStatus Operation result status code
     */
    DBStatus removeBlockHashByTransactionHash(const std::string &txHash);

    /**
     * @brief 设置指定地址和资产类型的余额
     * 
     * @param address 地址
     * @param assetType 资产类型
     * @param balance 余额
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set the balance for a specific address and asset type
     * 
     * @param address Address
     * @param assetType Asset type
     * @param balance Balance
     * @return DBStatus Operation result status code
     */
    DBStatus setBalanceByAddr(const std::string &address, const std::string& assetType, int64_t balance);

    /**
     * @brief 删除指定地址和资产类型的余额
     * 
     * @param address 地址
     * @param assetType 资产类型
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Delete the balance for a specific address and asset type
     * 
     * @param address Address
     * @param assetType Asset type
     * @return DBStatus Operation result status code
     */
    DBStatus removeBalanceByAddr(const std::string &address, const std::string &assetType);

    /**
     * @brief 设置质押地址
     * 
     * @param address 质押地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set a stake address
     * 
     * @param address Stake address
     * @return DBStatus Operation result status code
     */
    DBStatus setStakeAddr(const std::string &address);

    /**
     * @brief 移除质押地址
     * 
     * @param address 质押地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove a stake address
     * 
     * @param address Stake address
     * @return DBStatus Operation result status code
     */
    DBStatus removeStakeAddr(const std::string &address);

    /**
     * @brief 通过分红地址设置委托地址和资产类型
     * 
     * @param bonusAddr 分红地址
     * @param delegatingAddr 委托地址
     * @param assetType 资产类型
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set delegating address and asset type by bonus address
     * 
     * @param bonusAddr Bonus address
     * @param delegatingAddr Delegating address
     * @param assetType Asset type
     * @return DBStatus Operation result status code
     */
    DBStatus setDelegatingAddrAndAssetTypeByBonusAddr(const std::string &bonusAddr, const std::string& delegatingAddr, const std::string assetType);

    /**
     * @brief 通过分红地址移除委托地址和资产类型
     * 
     * @param bonusAddr 分红地址
     * @param delegatingAddr 委托地址
     * @param assetType 资产类型
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove delegating address and asset type by bonus address
     * 
     * @param bonusAddr Bonus address
     * @param delegatingAddr Delegating address
     * @param assetType Asset type
     * @return DBStatus Operation result status code
     */
    DBStatus removeDelegatingAddrAndAssetTypeByBonusAddr(const std::string &bonusAddr, const std::string& delegatingAddr, const std::string assetType);

    /**
     * @brief 通过委托地址和资产类型设置分红地址
     * 
     * @param delegatingAddr 委托地址
     * @param assetType 资产类型
     * @param bonusAddr 分红地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set bonus address by delegating address and asset type
     * 
     * @param delegatingAddr Delegating address
     * @param assetType Asset type
     * @param bonusAddr Bonus address
     * @return DBStatus Operation result status code
     */
    DBStatus setBonusAddrAndAssetTypeByDelegatingAddr(const std::string &delegatingAddr, const std::string& bonusAddr, const std::string &assetType);

    /**
     * @brief 通过委托地址和资产类型移除分红地址
     * 
     * @param delegatingAddr 委托地址
     * @param assetType 资产类型
     * @param bonusAddr 分红地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove bonus address by delegating address and asset type
     * 
     * @param delegatingAddr Delegating address
     * @param assetType Asset type
     * @param bonusAddr Bonus address
     * @return DBStatus Operation result status code
     */
    DBStatus removeBonusAddrAndAssetTypeByDelegatingAddr(const std::string &delegatingAddr, const std::string& bonusAddr, const std::string &assetType);

    /**
     * @brief 通过分红地址设置分红地址、委托地址、资产类型和UTXO
     * 
     * @param bonusAddr 分红地址
     * @param delegatingAddr 委托地址
     * @param assetType 资产类型
     * @param utxo UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set bonus address, delegating address, asset type and UTXO by bonus address
     * 
     * @param bonusAddr Bonus address
     * @param delegatingAddr Delegating address
     * @param assetType Asset type
     * @param utxo UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus setDelegatingAddrUtxoByBonusAddr(const std::string &bonusAddr, const std::string &delegatingAddr, const std::string assetType, const std::string &utxo);

    /**
     * @brief 通过分红地址移除分红地址、委托地址、资产类型和UTXO
     * 
     * @param bonusAddr 分红地址
     * @param delegatingAddr 委托地址
     * @param assetType 资产类型
     * @param utxo UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove bonus address, delegating address, asset type and UTXO by bonus address
     * 
     * @param bonusAddr Bonus address
     * @param delegatingAddr Delegating address
     * @param assetType Asset type
     * @param utxo UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus removeDelegatingAddrUtxoByBonusAddr(const std::string &bonusAddr, const std::string &delegatingAddr, const std::string assetType, const std::string &utxo);

    /**
     * @brief 设置总销毁数量
     * 
     * @param totalBurn 总销毁数量
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set the total burn amount
     * 
     * @param totalBurn Total burn amount
     * @return DBStatus Operation result status code
     */
    DBStatus setTotalBurnAmount(uint64_t &totalBurn);

    /**
     * @brief 设置总委托数量
     * 
     * @param delegatingCount 总委托数量
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set the total delegating amount
     * 
     * @param delegatingCount Total delegating amount
     * @return DBStatus Operation result status code
     */
    DBStatus setTotalDelegatingAmount(uint64_t &delegatingCount);

    /**
     * @brief 设置质押地址的UTXO
     * 
     * @param stakeAddr 质押地址
     * @param assetType 资产类型
     * @param utxo UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set UTXO for a stake address
     * 
     * @param stakeAddr Stake address
     * @param assetType Asset type
     * @param utxo UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus setStakeUtxoByAddr(const std::string &stakeAddr, const std::string& assetType, const std::string &utxo);

    /**
     * @brief 移除质押地址的UTXO
     * 
     * @param stakeAddr 质押地址
     * @param assetType 资产类型
     * @param utxo UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove UTXO for a stake address
     * 
     * @param stakeAddr Stake address
     * @param assetType Asset type
     * @param utxo UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus removeStakeUtxoByAddr(const std::string &stakeAddr, const std::string& assetType, const std::string &utxo);

    /**
     * @brief 按周期设置分红UTXO
     * 
     * @param period 周期
     * @param utxo UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set bonus UTXO by period
     * 
     * @param period Period
     * @param utxo UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus setBonusUtxoByPeriod(const uint64_t &period, const std::string &utxo);

    /**
     * @brief 按周期设置基金UTXO
     * 
     * @param period 周期
     * @param utxo UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set fund UTXO by period
     * 
     * @param period Period
     * @param utxo UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus setFundUtxoByPeriod(const uint64_t &period, const std::string &utxo);

    /**
     * @brief 按周期移除分红UTXO
     * 
     * @param period 周期
     * @param utxo UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove bonus UTXO by period
     * 
     * @param period Period
     * @param utxo UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus removeBonusUtxoByPeriod(const uint64_t &period, const std::string &utxo);

    /**
     * @brief 按周期移除基金UTXO
     * 
     * @param period 周期
     * @param utxo UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove fund UTXO by period
     * 
     * @param period Period
     * @param utxo UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus removeFundUtxoByPeriod(const uint64_t &period, const std::string &utxo);

    /**
     * @brief 按周期设置委托UTXO
     * 
     * @param period 周期
     * @param utxo UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set delegating UTXO by period
     * 
     * @param period Period
     * @param utxo UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus setDelegatingUtxoByPeriod(const uint64_t &period, const std::string &utxo);

    /**
     * @brief 按周期移除委托UTXO
     * 
     * @param period 周期
     * @param utxo UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove delegating UTXO by period
     * 
     * @param period Period
     * @param utxo UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus removeDelegatingUtxoByPeriod(const uint64_t &period, const std::string &utxo);

    /**
     * @brief 按周期设置签名数
     * 
     * @param period 周期
     * @param address 地址
     * @param signNumber 签名数
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set sign number by period
     * 
     * @param period Period
     * @param address Address
     * @param signNumber Sign number
     * @return DBStatus Operation result status code
     */
    DBStatus setSignCountByPeriod(const uint64_t &period, const std::string &address, const uint64_t &signNumber);

    /**
     * @brief 按周期移除签名数
     * 
     * @param period 周期
     * @param address 地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove sign number by period
     * 
     * @param period Period
     * @param address Address
     * @return DBStatus Operation result status code
     */
    DBStatus removeSignCountByPeriod(const uint64_t &period, const std::string &address);

    /**
     * @brief 按周期设置区块数
     * 
     * @param period 周期
     * @param blockNumber 区块数
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set block number by period
     * 
     * @param period Period
     * @param blockNumber Block number
     * @return DBStatus Operation result status code
     */
    DBStatus setBlockNumberByPeriod(const uint64_t &period, const uint64_t &blockNumber);

    /**
     * @brief 按周期移除区块数
     * 
     * @param period 周期
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove block number by period
     * 
     * @param period Period
     * @return DBStatus Operation result status code
     */
    DBStatus removeBlockNumberByPeriod(const uint64_t &period);

    /**
     * @brief 按周期设置签名地址
     * 
     * @param period 周期
     * @param addr 签名地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set sign address by period
     * 
     * @param period Period
     * @param addr Sign address
     * @return DBStatus Operation result status code
     */
    DBStatus setSignAddrByPeriod(const uint64_t &period, const std::string &addr);

    /**
     * @brief 按周期移除签名地址
     * 
     * @param period 周期
     * @param addr 签名地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove sign address by period
     * 
     * @param period Period
     * @param addr Sign address
     * @return DBStatus Operation result status code
     */
    DBStatus removeSignAddrByPeriod(const uint64_t &period, const std::string &addr);

    /**
     * @brief 按周期设置销毁数量
     * 
     * @param period 周期
     * @param burnAmount 销毁数量
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set burn amount by period
     * 
     * @param period Period
     * @param burnAmount Burn amount
     * @return DBStatus Operation result status code
     */
    DBStatus setBurnAmountByPeriod(const uint64_t &period, const uint64_t &burnAmount);

    /**
     * @brief 按周期移除销毁数量
     * 
     * @param period 周期
     * @param burnAmount 销毁数量
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove burn amount by period
     * 
     * @param period Period
     * @param burnAmount Burn amount
     * @return DBStatus Operation result status code
     */
    DBStatus removeBurnAmountByPeriod(const uint64_t &period, const uint64_t &burnAmount);

    /**
     * @brief 设置EVM合约部署者地址
     * 
     * @param deployerAddr 部署者地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set EVM contract deployer address
     * 
     * @param deployerAddr Deployer address
     * @return DBStatus Operation result status code
     */
    DBStatus setEvmDeployerAddr(const std::string &deployerAddr);

    /**
     * @brief 移除EVM合约部署者地址
     * 
     * @param deployerAddr 部署者地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove EVM contract deployer address
     * 
     * @param deployerAddr Deployer address
     * @return DBStatus Operation result status code
     */
    DBStatus removeEvmDeployerAddr(const std::string &deployerAddr);

    /**
     * @brief 通过部署者地址设置合约地址
     * 
     * @param deployerAddr 部署者地址
     * @param contractAddr 合约地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set contract address by deployer address
     * 
     * @param deployerAddr Deployer address
     * @param contractAddr Contract address
     * @return DBStatus Operation result status code
     */
    DBStatus setContractAddrByDeployerAddr(const std::string &deployerAddr, const std::string &contractAddr);

    /**
     * @brief 通过部署者地址移除合约地址
     * 
     * @param deployerAddr 部署者地址
     * @param contractAddr 合约地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove contract address by deployer address
     * 
     * @param deployerAddr Deployer address
     * @param contractAddr Contract address
     * @return DBStatus Operation result status code
     */
    DBStatus removeContractAddrByDeployerAddr(const std::string &deployerAddr, const std::string &contractAddr);

    /**
     * @brief 通过合约地址设置合约代码
     * 
     * @param contractAddr 合约地址
     * @param contractCode 合约代码
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set contract code by contract address
     * 
     * @param contractAddr Contract address
     * @param contractCode Contract code
     * @return DBStatus Operation result status code
     */
    DBStatus setContractCodeByContractAddr(const std::string &contractAddr, const std::string &contractCode);

    /**
     * @brief 通过合约地址移除合约代码
     * 
     * @param contractAddr 合约地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove contract code by contract address
     * 
     * @param contractAddr Contract address
     * @return DBStatus Operation result status code
     */
    DBStatus removeContractCodeByContractAddr(const std::string &contractAddr);

    /**
     * @brief 通过合约地址设置合约部署UTXO
     * 
     * @param contractAddr 合约地址
     * @param contractDeploymentUtxo 合约部署UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set contract deployment UTXO by contract address
     * 
     * @param contractAddr Contract address
     * @param contractDeploymentUtxo Contract deployment UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus setContractDeployUtxoByContractAddr(const std::string &contractAddr, const std::string &contractDeploymentUtxo);

    /**
     * @brief 通过合约地址移除合约部署UTXO
     * 
     * @param contractAddr 合约地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove contract deployment UTXO by contract address
     * 
     * @param contractAddr Contract address
     * @return DBStatus Operation result status code
     */
    DBStatus removeContractDeployUtxoByContractAddr(const std::string &contractAddr);

    /**
     * @brief 通过合约地址设置最新UTXO
     * 
     * @param contractAddr 合约地址
     * @param utxo 最新UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set latest UTXO by contract address
     * 
     * @param contractAddr Contract address
     * @param utxo Latest UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus setLatestUtxoByContractAddr(const std::string &contractAddr, const std::string &utxo);

    /**
     * @brief 通过合约地址移除最新UTXO
     * 
     * @param contractAddr 合约地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove latest UTXO by contract address
     * 
     * @param contractAddr Contract address
     * @return DBStatus Operation result status code
     */
    DBStatus removeLatestUtxoByContractAddr(const std::string &contractAddr);

    /**
     * @brief 通过MPT键设置MPT值
     * 
     * @param mptKey MPT键
     * @param mptValue MPT值
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set MPT value by MPT key
     * 
     * @param mptKey MPT key
     * @param mptValue MPT value
     * @return DBStatus Operation result status code
     */
    DBStatus setMptValueByMptKey(const std::string &mptKey, const std::string &mptValue);

    /**
     * @brief 通过MPT键移除MPT值
     * 
     * @param mptKey MPT键
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove MPT value by MPT key
     * 
     * @param mptKey MPT key
     * @return DBStatus Operation result status code
     */
    DBStatus removeMptValueByMptKey(const std::string &mptKey);


    /**
     * @brief 设置资产类型
     * 
     * @param assetType 资产类型
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set asset type
     * 
     * @param assetType Asset type
     * @return DBStatus Operation result status code
     */
    DBStatus setAssetType(const std::string &assetType);

    /**
     * @brief 移除资产类型
     * 
     * @param assetType 资产类型
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove asset type
     * 
     * @param assetType Asset type
     * @return DBStatus Operation result status code
     */
    DBStatus removeAssetType(const std::string &assetType);

    /**
     * @brief 根据资产类型设置撤销交易哈希
     * 
     * @param assetType 资产类型
     * @param revokeTransactionHashValue 撤销交易哈希值
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set revoke transaction hash by asset type
     * 
     * @param assetType Asset type
     * @param revokeTransactionHashValue Revoke transaction hash value
     * @return DBStatus Operation result status code
     */
    DBStatus setRevokeTxHashByAssetType(const std::string &assetType, const std::string revokeTransactionHashValue);

    /**
     * @brief 根据资产类型移除撤销交易哈希
     * 
     * @param assetType 资产类型
     * @param revokeTransactionHashValue 撤销交易哈希值
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove revoke transaction hash by asset type
     * 
     * @param assetType Asset type
     * @param revokeTransactionHashValue Revoke transaction hash value
     * @return DBStatus Operation result status code
     */
    DBStatus removeRevokeTxHashByAssetType(const std::string &assetType, const std::string revokeTransactionHashValue);

    /**
     * @brief 根据资产哈希设置同意投票地址
     * 
     * @param assetType 资产类型
     * @param addr 地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set approve vote address by asset hash
     * 
     * @param assetType Asset type
     * @param addr Address
     * @return DBStatus Operation result status code
     */
    DBStatus setApproveAddrsByAssetType(const std::string &assetType, const std::string &addr);

    /**
     * @brief 根据资产哈希移除同意投票地址
     * 
     * @param assetType 资产类型
     * @param addr 地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove approve vote address by asset hash
     * 
     * @param assetType Asset type
     * @param addr Address
     * @return DBStatus Operation result status code
     */
    DBStatus removeApproveAddrsByAssetType(const std::string &assetType, const std::string &addr);

    /**
     * @brief 根据资产哈希设置反对投票地址
     * 
     * @param assetType 资产类型
     * @param addr 地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set against vote address by asset hash
     * 
     * @param assetType Asset type
     * @param addr Address
     * @return DBStatus Operation result status code
     */
    DBStatus setAgainstAddrsByAssetType(const std::string &assetType, const std::string &addr);

    /**
     * @brief 根据资产哈希移除反对投票地址
     * 
     * @param assetType 资产类型
     * @param addr 地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove against vote address by asset hash
     * 
     * @param assetType Asset type
     * @param addr Address
     * @return DBStatus Operation result status code
     */
    DBStatus removeAgainstAddrsByAssetType(const std::string &assetType, const std::string &addr);

    /**
     * @brief 根据资产哈希设置投票交易哈希
     * 
     * @param assetType 资产类型
     * @param voteTxHash 投票交易哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set vote transaction hash by asset hash
     * 
     * @param assetType Asset type
     * @param voteTxHash Vote transaction hash
     * @return DBStatus Operation result status code
     */
    DBStatus setVoteTxHashByAssetType(const std::string &assetType, const std::string &voteTxHash);

    /**
     * @brief 根据资产哈希移除投票交易哈希
     * 
     * @param assetType 资产类型
     * @param voteTxHash 投票交易哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove vote transaction hash by asset hash
     * 
     * @param assetType Asset type
     * @param voteTxHash Vote transaction hash
     * @return DBStatus Operation result status code
     */
    DBStatus removeVoteTxHashByAssetType(const std::string &assetType, const std::string &voteTxHash);

    /**
     * @brief 根据资产类型设置资产信息
     * 
     * @param assetType 资产类型
     * @param info 资产信息
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set asset info by asset type
     * 
     * @param assetType Asset type
     * @param info Asset info
     * @return DBStatus Operation result status code
     */
    DBStatus setProposalInfoByAssetType(const std::string &assetType, const std::string info);

    /**
     * @brief 根据资产类型移除资产信息
     * 
     * @param assetType 资产类型
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove asset info by asset type
     * 
     * @param assetType Asset type
     * @return DBStatus Operation result status code
     */
    DBStatus removeProposalInfoByAssetType(const std::string &assetType);

    /**
     * @brief 根据交易哈希设置撤销提案信息
     * 
     * @param TxHash 交易哈希
     * @param info 撤销提案信息
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set revoke proposal info by transaction hash
     * 
     * @param TxHash Transaction hash
     * @param info Revoke proposal info
     * @return DBStatus Operation result status code
     */
    DBStatus setRevokeProposalInfoByAssetType(const std::string & assetType, const std::string info);

    /**
     * @brief 根据交易哈希移除撤销提案信息
     * 
     * @param TxHash 交易哈希
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove revoke proposal info by transaction hash
     * 
     * @param TxHash Transaction hash
     * @return DBStatus Operation result status code
     */
    DBStatus removeRevokeProposalInfoByAssetType(const std::string & assetType);

    /**
     * @brief 根据资产哈希设置投票数
     * 
     * @param assetType 资产类型
     * @param info 投票数信息
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set vote number by asset hash
     * 
     * @param assetType Asset type
     * @param info Vote number info
     * @return DBStatus Operation result status code
     */
    DBStatus setVoteCountByAssetType(const std::string & assetType, const uint64_t & approve, const uint64_t & against);

    /**
     * @brief 根据资产哈希删除投票数
     * 
     * @param assetType 资产类型
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Delete vote number by asset hash
     * 
     * @param assetType Asset type
     * @return DBStatus Operation result status code
     */
    DBStatus removeVoteCountByAssetType(const std::string &assetType);

    /**
     * @brief 根据地址和资产类型设置投票数
     * 
     * @param addr 地址
     * @param assetType 资产类型
     * @param voteNum 投票数
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set vote number by address and asset type
     * 
     * @param addr Address
     * @param assetType Asset type
     * @param voteNum Vote number
     * @return DBStatus Operation result status code
     */
    DBStatus setVoteCountByAddr(const std::string &addr, const std::string& assetType, const uint64_t& voteNum);

    /**
     * @brief 根据地址和资产类型查询投票数
     * 
     * @param addr 地址
     * @param assetType 资产类型
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief delete vote number by address and asset type
     * 
     * @param addr Address
     * @param assetType Asset type
     * @return DBStatus Operation result status code
     */
    DBStatus removeVoteCountByAddr(const std::string &addr, const std::string& assetType);

    /**
     * @brief 根据资产哈希设置总投票人数
     * 
     * @param assetType 资产类型
     * @param voteNum 投票人数
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set total number of voters by asset hash
     * 
     * @param assetType Asset type
     * @param voteNum Number of voters
     * @return DBStatus Operation result status code
     */
    DBStatus setTotalCountByAssetType(const std::string& assetType, const uint64_t& voteNum);

    /**
     * @brief 根据资产哈希删除总投票人数
     * 
     * @param assetType 资产类型
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Delete total number of voters by asset hash
     * 
     * @param assetType Asset type
     * @return DBStatus Operation result status code
     */
    DBStatus removeTotalNumberOfVotersByAssetHash(const std::string& assetType);

    /**
     * @brief 设置锁定地址
     * 
     * @param address 锁定地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set lock address
     * 
     * @param address Lock address
     * @return DBStatus Operation result status code
     */
    DBStatus setLockAddr(const std::string &address);

    /**
     * @brief 移除锁定地址
     * 
     * @param address 锁定地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove lock address
     * 
     * @param address Lock address
     * @return DBStatus Operation result status code
     */
    DBStatus removeLockAddr(const std::string &address);

    /**
     * @brief 设置锁定地址的UTXO
     * 
     * @param LockAddr 锁定地址
     * @param assetType 资产类型
     * @param utxo UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set UTXO for lock address
     * 
     * @param LockAddr Lock address
     * @param assetType Asset type
     * @param utxo UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus setLockAddrUtxo(const std::string &LockAddr, const std::string& assetType ,const std::string &utxo);

    /**
     * @brief 移除锁定地址的UTXO
     * 
     * @param LockAddr 锁定地址
     * @param assetType 资产类型
     * @param utxo UTXO
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove UTXO for lock address
     * 
     * @param LockAddr Lock address
     * @param assetType Asset type
     * @param utxo UTXO
     * @return DBStatus Operation result status code
     */
    DBStatus removeLockAddrUtxo(const std::string &LockAddr, const std::string& assetType , const std::string &utxo);

    /**
     * @brief 设置总锁定金额
     * 
     * @param TotalLockedAmount 总锁定金额
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set total locked amount
     * 
     * @param TotalLockedAmount Total locked amount
     * @return DBStatus Operation result status code
     */
    DBStatus setTotalLockedAmonut(const uint64_t& TotalLockedAmount);


    /**
     * @brief 设置某一周期的总锁定金额
     * 
     * @param period 周期
     * @param LockedAmount 锁定金额
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set total locked amount by period
     * 
     * @param period Period
     * @param LockedAmount Locked amount
     * @return DBStatus Operation result status code
     */
    DBStatus setTotalLockedAmonutByPeriod(const uint64_t& period, const uint64_t& LockedAmount);



    /**
     * @brief 根据周期移除总锁定金额
     * 
     * @param period 周期
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove total locked amount by period
     * 
     * @param period Period
     * @return DBStatus Operation result status code
     */
    DBStatus removeTotalLockedAmonutByPeriod(const uint64_t& period);

    /**
     * @brief 根据地址设置资产类型
     * 
     * @param addr 地址
     * @param assetType 资产类型
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set asset type by address
     * 
     * @param addr Address
     * @param assetType Asset type
     * @return DBStatus Operation result status code
     */
    DBStatus setAssetTypeByAddr(const std::string& addr, const std::string &assetType);

    /**
     * @brief 根据地址移除资产类型
     * 
     * @param addr 地址
     * @param assetType 资产类型
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove asset type by address
     * 
     * @param addr Address
     * @param assetType Asset type
     * @return DBStatus Operation result status code
     */
    DBStatus removeAssetTypeByAddr(const std::string& addr, const std::string &assetType);

    /**
     * @brief 根据合约地址设置资产类型
     * 
     * @param contractAddr 合约地址
     * @param assetType 资产类型
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set asset type by contract address
     * 
     * @param contractAddr Contract address
     * @param assetType Asset type
     * @return DBStatus Operation result status code
     */
    DBStatus setAssetTypeByContractAddr(const std::string& contractAddr, const std::string &assetType);

    /**
     * @brief 根据合约地址移除资产类型
     * 
     * @param contractAddr 合约地址
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove asset type by contract address
     * 
     * @param contractAddr Contract address
     * @return DBStatus Operation result status code
     */
    DBStatus removeAssetTypeByContractAddr(const std::string& contractAddr);

    /**
     * @brief 根据周期设置Gas消耗量
     * 
     * @param period 周期
     * @param type 类型
     * @param gasAmount Gas消耗量
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set gas amount by period
     * 
     * @param period Period
     * @param type Type
     * @param gasAmount Gas amount
     * @return DBStatus Operation result status code
     */
    DBStatus setGasAmountByPeriod(const uint64_t &period, const std::string &type,const uint64_t &gasAmount);

    /**
     * @brief 根据周期和地址设置打包次数
     * 
     * @param period 周期
     * @param address 地址
     * @param times 打包次数
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set packager times by period and address
     * 
     * @param period Period
     * @param address Address
     * @param count Packager count
     * @return DBStatus Operation result status code
     */
    DBStatus setPackagerCountByPeriod(const uint64_t& period, const std::string& address, const uint64_t& count);


    DBStatus setRollbackBlockNum(const uint64_t& blockNumber,bool AddOrRemove);

    DBStatus getRollbackBlockNum(std::vector<uint64_t>& blockNumbers);

    DBStatus saveRollBackBlock(const uint64_t& blockNumber, const std::string& blocks);

    DBStatus getRollBackBlock(const uint64_t& blockNumber, std::vector<std::string>& blocks);

    DBStatus removeRollBackBlock(const uint64_t& blockNumber,const std::string & block,bool isDeleteKey);



    DBStatus get30DayLockData(const std::string & addr,const std::string & utxo_hash,const std::string & asset_type,uint64_t & time);
    DBStatus set30DayLockData(const std::string & addr,const std::string & utxo_hash,const std::string & asset_type,const uint64_t & time,const bool deletekey);
    DBStatus getAll30DayLock(const std::string & addr,std::vector<std::string> & lockdatas); 
    DBStatus addOneLockData(const std::string & addr,const std::string & data);
    DBStatus removeOneLockData(const std::string & addr,const std::string & data);
    /**
     * @brief 设置初始版本号
     * 
     * @param version 版本号
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Set initial version
     * 
     * @param version Version
     * @return DBStatus Operation result status code
     */
    DBStatus setInitVer(const std::string &version);

    DBStatus setInternalHashByRlpHash(const std::string &rlpHash, const std::string &internalHash);
    DBStatus removeInternalHashByRlpHash(const std::string &rlpHash);

    // === Slashing write interfaces ===

    // Mark an EVIDENCE tx on chain: evidence_hash -> target_addr,violation_type.
    DBStatus setEvidenceOnChain(const std::string &evidenceHash, const std::string &targetAddr, const std::string &violationType);
    DBStatus removeEvidenceOnChain(const std::string &evidenceHash);
    DBStatus setEvidenceCount(const std::string &addr, const std::string &type, int64_t count);
    DBStatus removeEvidenceCount(const std::string &addr, const std::string &type);
    // addr -> level,violation_type,evidence_refs, plus a global threshold address list.
    DBStatus addToThresholdExceeded(const std::string &addr, const std::string &level, const std::string &violationType, const std::string &evidenceRefs);
    DBStatus removeFromThresholdExceeded(const std::string &addr);
    // punishment_id is the consensus idempotency key; target addr index is for RPC only.
    DBStatus setPunishmentHistory(const std::string &punishmentId, const std::string &targetAddr, const std::string &period, uint32_t level, const std::string &txHash);
    DBStatus removePunishmentHistory(const std::string &punishmentId, const std::string &targetAddr);
    // JSON rollback snapshot for L4 delegation refunds.
    DBStatus setPunishmentDelegationRefunds(const std::string &punishmentId, const std::string &refundSnapshot);
    DBStatus getPunishmentDelegationRefunds(const std::string &punishmentId, std::string &refundSnapshot);
    DBStatus removePunishmentDelegationRefunds(const std::string &punishmentId);
    DBStatus setJailed(const std::string &addr, const std::string &startPeriod, const std::string &reason, uint32_t level);
    DBStatus removeJailed(const std::string &addr);
    DBStatus setTombstoned(const std::string &addr, const std::string &reason, const std::string &period, const std::string &evidenceHash);
    DBStatus removeTombstoned(const std::string &addr);
    DBStatus recordVRFFail(const std::string &addr, uint64_t period);
    DBStatus removeVRFFail(const std::string &addr, uint64_t period);
    DBStatus setDisconnectCount(const std::string &addr, uint64_t hour, uint32_t count);
    DBStatus getDisconnectCount(const std::string &addr, uint64_t hour, uint32_t &count);
    DBStatus recordBlockSign(uint64_t height, const std::string &addr, const std::string &blockHash);
    DBStatus getBlockSign(uint64_t height, const std::string &addr, std::string &blockHash);
    DBStatus writePendingSlashingEvidence(const std::string &key, const std::string &jsonData);
    DBStatus setLastActivePeriod(const std::string &addr, uint64_t period);
    DBStatus getLastActivePeriod(const std::string &addr, uint64_t &period);
    DBStatus setConsecutiveNormal(const std::string &addr, uint32_t count);
    DBStatus getConsecutiveNormal(const std::string &addr, uint32_t &count);
    DBStatus setL3SlashCount(const std::string &addr, uint32_t count);
    DBStatus removeL3SlashCount(const std::string &addr);
    DBStatus getL3SlashCount(const std::string &addr, uint32_t &count);

    // P3: Generic read/delete for slashing cleanup
    DBStatus readSlashingData(const std::string &key, std::string &value);
    DBStatus deleteSlashingData(const std::string &key);

private:
    
    /**
     * @brief 事务回滚
     * 
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Transaction rollback
     * 
     * @return DBStatus Operation result status code
     */
    DBStatus transactionRollBack();

    /**
     * @brief 批量读取数据
     * 
     * @param keys 需要读取的键列表
     * @param values 用于存储读取结果的值列表
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Batch read data
     * 
     * @param keys List of keys to read
     * @param values List to store the read values
     * @return DBStatus Operation result status code
     */
    virtual DBStatus multiReadData(const std::vector<std::string> &keys, std::vector<std::string> &values);

    /**
     * @brief 读取单条数据
     * 
     * @param key 需要读取的键
     * @param value 用于存储读取结果的值
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Read single data
     * 
     * @param key Key to read
     * @param value Value to store the read result
     * @return DBStatus Operation result status code
     */
    virtual DBStatus readData(const std::string &key, std::string &value);

    /**
     * @brief 合并写入数据
     * 
     * @param key 需要合并的键
     * @param value 需要合并的值
     * @param firstOrLast 是否为首/尾合并，默认为false
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Merge and write data
     * 
     * @param key Key to merge
     * @param value Value to merge
     * @param firstOrLast Whether to merge at the beginning or end, default is false
     * @return DBStatus Operation result status code
     */
    DBStatus mergeValue(const std::string &key, const std::string &value, bool firstOrLast = false,const std::string& Delimiter="_");


    DBStatus getMergeValue(const std::string &key, std::vector<std::string> &values,const std::string& Delimiter="_");

    /**
     * @brief 移除合并值
     * 
     * @param key 需要移除的键
     * @param value 需要移除的值
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Remove merged value
     * 
     * @param key Key to remove
     * @param value Value to remove
     * @return DBStatus Operation result status code
     */
    DBStatus removeMergeValue(const std::string &key, const std::string &value,const std::string& Delimiter="_");

    /**
     * @brief 写入数据
     * 
     * @param key 需要写入的键
     * @param value 需要写入的值
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Write data
     * 
     * @param key Key to write
     * @param value Value to write
     * @return DBStatus Operation result status code
     */
    DBStatus writeData(const std::string &key, const std::string &value);

    /**
     * @brief 删除数据
     * 
     * @param key 需要删除的键
     * @return DBStatus 操作结果状态码
     */
    /**
     * @brief Delete data
     * 
     * @param key Key to delete
     * @return DBStatus Operation result status code
     */
    DBStatus deleteData(const std::string &key);

    std::set<std::string> delete_keys_;
    RocksDBReadWriter dbReaderWriter;
    bool autoOperationTrans;
};

#endif
