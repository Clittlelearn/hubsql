#ifndef ROCKSDB_HEADER_INCLUDED
#define ROCKSDB_HEADER_INCLUDED

#include "rocksdb/db.h"
#include "rocksdb/options.h"
#include "rocksdb/slice.h"
#include "rocksdb/status.h"
#include "rocksdb/utilities/transaction.h"
#include "rocksdb/utilities/transaction_db.h"
#include <mutex>

class BackgroundErrorListener : public rocksdb::EventListener
{
public:
    // 当后台发生错误时的回调函数
    // Callback function when a background error occurs
    void OnBackgroundError(rocksdb::BackgroundErrorReason reason, rocksdb::Status* errorStatus) override;
};

class RocksDBDataReader;
class RocksDBReadWriter;
class RocksDB
{
public:
    RocksDB();
    ~RocksDB();
    RocksDB(RocksDB &&) = delete;
    RocksDB(const RocksDB &) = delete;
    RocksDB &operator=(RocksDB &&) = delete;
    RocksDB &operator=(const RocksDB &) = delete;

    /**
     * 设置数据库路径
     * @param dbPath 数据库文件路径
     */
    /**
     * Set the database path
     * @param dbPath The file path of the database
     */
    void setDBPath(const std::string &dbPath);

    /**
     * 初始化数据库
     * @param retStatus 返回的状态信息
     * @return 初始化是否成功
     */
    /**
     * Initialize the database
     * @param retStatus Returned status information
     * @return Whether initialization is successful
     */
    bool initDB(rocksdb::Status &retStatus);

    /**
     * 销毁数据库
     */
    /**
     * Destroy the database
     */
    void sestoryDB();

    /**
     * 判断数据库是否初始化成功
     * @return 是否初始化成功
     */
    /**
     * Check if the database was initialized successfully
     * @return Whether initialization was successful
     */
    bool isInitSuccess();

    /**
     * 获取数据库内存使用信息
     * @param info 用于存储内存使用信息的字符串
     */
    /**
     * Get database memory usage information
     * @param info String to store memory usage information
     */
    void getDBMemoryUsage(std::string& info);

private:
    friend class BackgroundErrorListener;
    friend class RocksDBDataReader;
    friend class RocksDBReadWriter;
    std::string db_path_;
    rocksdb::TransactionDB *db_;
    std::mutex initSuccessMutex;
    bool isInitialized;
};



#endif
