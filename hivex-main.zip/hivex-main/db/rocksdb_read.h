/*
 * @Author: memechaintech memechaintech@outlook.com
 * @Date: 2025-07-15 17:49:15
 * @LastEditors: memechaintech memechaintech@outlook.com
 * @LastEditTime: 2025-07-16 13:41:09
 * @FilePath: /mm/db/rocksdb_read.h
 * @Description: 
 */
#ifndef ROCKSDB_READ_HEADER
#define ROCKSDB_READ_HEADER

#include "db/rocksdb.h"
#include <memory>
#include <string>
#include <vector>

class RocksDBDataReader
{
public:
    RocksDBDataReader(std::shared_ptr<RocksDB> rocksdb);
    ~RocksDBDataReader() = default;
    RocksDBDataReader(RocksDBDataReader &&) = delete;
    RocksDBDataReader(const RocksDBDataReader &) = delete;
    RocksDBDataReader &operator=(RocksDBDataReader &&) = delete;
    RocksDBDataReader &operator=(const RocksDBDataReader &) = delete;

    /**
     * @brief 批量读取数据库中的多个键值
     * 
     * @param keys 需要读取的键集合
     * @param values 用于存储读取到的值的集合
     * @param retStatus 用于存储每个键读取结果的状态集合
     * @return 是否读取成功
     */
    /**
     * @brief Batch read multiple key-value pairs from the database
     * 
     * @param keys The collection of keys to read
     * @param values The collection to store the read values
     * @param retStatus The collection to store the status of each key read
     * @return Whether the read was successful
     */
    bool multiReadData(const std::vector<rocksdb::Slice> &keys, std::vector<std::string> &values, std::vector<rocksdb::Status> &retStatus);

    /**
     * @brief 读取数据库中的单个键值
     * 
     * @param key 需要读取的键
     * @param value 用于存储读取到的值
     * @param retStatus 用于存储读取操作的状态
     * @return 是否读取成功
     */
    /**
     * @brief Read a single key-value pair from the database
     * 
     * @param key The key to read
     * @param value The variable to store the read value
     * @param retStatus The variable to store the status of the read operation
     * @return Whether the read was successful
     */
    bool readData(const std::string &key, std::string &value, rocksdb::Status &retStatus);

private:
    rocksdb::ReadOptions read_options_;
    std::shared_ptr<RocksDB> rocksdb_;
};

#endif
