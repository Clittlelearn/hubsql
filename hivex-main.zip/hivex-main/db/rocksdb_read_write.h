#ifndef ROCKSDB_READ_WRITE_H_INCLUDED
#define ROCKSDB_READ_WRITE_H_INCLUDED

#include "db/rocksdb.h"
#include <memory>
#include <string>
#include <vector>

class RocksDBReadWriter
{
public:
    RocksDBReadWriter(std::shared_ptr<RocksDB> db, const std::string &txn_name);
    ~RocksDBReadWriter();
    RocksDBReadWriter(RocksDBReadWriter &&) = delete;
    RocksDBReadWriter(const RocksDBReadWriter &) = delete;
    RocksDBReadWriter &operator=(RocksDBReadWriter &&) = delete;
    RocksDBReadWriter &operator=(const RocksDBReadWriter &) = delete;
    
    /**
     * @brief 初始化事务
     * 
     * @return 是否初始化成功
     */
    /**
     * @brief Initialize the transaction
     * 
     * @return Whether initialization is successful
     */
    bool transactionInit();

    /**
     * @brief 提交事务
     * 
     * @param retStatus 用于存储提交操作的状态
     * @return 是否提交成功
     */
    /**
     * @brief Commit the transaction
     * 
     * @param retStatus Used to store the status of the commit operation
     * @return Whether the commit was successful
     */
    bool transactionCommit(rocksdb::Status &retStatus);

    /**
     * @brief 回滚事务
     * 
     * @param retStatus 用于存储回滚操作的状态
     * @return 是否回滚成功
     */
    /**
     * @brief Roll back the transaction
     * 
     * @param retStatus Used to store the status of the rollback operation
     * @return Whether the rollback was successful
     */
    bool transactionRollBack(rocksdb::Status &retStatus);

    /**
     * @brief 批量读取多个键值
     * 
     * @param keys 需要读取的键集合
     * @param values 用于存储读取到的值的集合
     * @param retStatus 用于存储每个键读取结果的状态集合
     * @return 是否读取成功
     */
    /**
     * @brief Batch read multiple key-value pairs
     * 
     * @param keys The collection of keys to read
     * @param values The collection to store the read values
     * @param retStatus The collection to store the status of each key read
     * @return Whether the read was successful
     */
    bool multiReadData(const std::vector<rocksdb::Slice> &keys, std::vector<std::string> &values, std::vector<rocksdb::Status> &retStatus);

    /**
     * @brief 合并写入键值
     * 
     * @param key 需要合并的键
     * @param value 需要合并的值
     * @param retStatus 用于存储合并操作的状态
     * @param firstOrLast 是否为首尾合并，默认为false
     * @return 是否合并成功
     */
    /**
     * @brief Merge value into the key
     * 
     * @param key The key to merge
     * @param value The value to merge
     * @param retStatus Used to store the status of the merge operation
     * @param firstOrLast Whether to merge at the beginning or end, default is false
     * @return Whether the merge was successful
     */
    bool mergeValue(const std::string &key, const std::string &value, rocksdb::Status &retStatus, bool firstOrLast = false,const std::string & Delimiter="_");

    /**
     * @brief 移除合并的键值
     * 
     * @param key 需要移除的键
     * @param value 需要移除的值
     * @param retStatus 用于存储移除操作的状态
     * @return 是否移除成功
     */
    /**
     * @brief Remove merged value from the key
     * 
     * @param key The key to remove
     * @param value The value to remove
     * @param retStatus Used to store the status of the remove operation
     * @return Whether the removal was successful
     */
    bool removeMergeValue(const std::string &key, const std::string &value, rocksdb::Status &retStatus,const std::string & Delimiter="_");


    bool getMergeValue(const std::string &key, std::vector<std::string> &values, rocksdb::Status &retStatus,const std::string & Delimiter="_");

    /**
     * @brief 读取单个键值
     * 
     * @param key 需要读取的键
     * @param value 用于存储读取到的值
     * @param retStatus 用于存储读取操作的状态
     * @return 是否读取成功
     */
    /**
     * @brief Read a single key-value pair
     * 
     * @param key The key to read
     * @param value The variable to store the read value
     * @param retStatus Used to store the status of the read operation
     * @return Whether the read was successful
     */
    bool readData(const std::string &key, std::string &value, rocksdb::Status &retStatus);

    /**
     * @brief 写入单个键值
     * 
     * @param key 需要写入的键
     * @param value 需要写入的值
     * @param retStatus 用于存储写入操作的状态
     * @return 是否写入成功
     */
    /**
     * @brief Write a single key-value pair
     * 
     * @param key The key to write
     * @param value The value to write
     * @param retStatus Used to store the status of the write operation
     * @return Whether the write was successful
     */
    bool writeData(const std::string &key, const std::string &value, rocksdb::Status &retStatus);

    /**
     * @brief 删除单个键值
     * 
     * @param key 需要删除的键
     * @param retStatus 用于存储删除操作的状态
     * @return 是否删除成功
     */
    /**
     * @brief Delete a single key-value pair
     * 
     * @param key The key to delete
     * @param retStatus Used to store the status of the delete operation
     * @return Whether the deletion was successful
     */
    bool deleteData(const std::string &key, rocksdb::Status &retStatus);

private:

    /**
     * @brief 读取并为更新加锁的单个键值
     * 
     * @param key 需要读取并加锁的键
     * @param value 用于存储读取到的值
     * @param retStatus 用于存储读取操作的状态
     * @return 是否读取并加锁成功
     */
    /**
     * @brief Read a single key-value pair and lock it for update
     * 
     * @param key The key to read and lock for update
     * @param value The variable to store the read value
     * @param retStatus Used to store the status of the read operation
     * @return Whether the read and lock for update was successful
     */
    bool readForUpdate(const std::string &key, std::string &value, rocksdb::Status &retStatus);

    std::string txn_name_;
    std::shared_ptr<RocksDB> rocksdb_;
    rocksdb::Transaction *txn_;
    rocksdb::WriteOptions write_options_;
    rocksdb::ReadOptions read_options_;
};
#endif
