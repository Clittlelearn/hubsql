#include "db/db_api.h"
#include "db_api.h"
#include "utils/magic_singleton.h"
#include "include/logging.h"
#include "utils/string_util.h"
#include "ca/global.h"
#include <cstdint>

// todo 校对key值
namespace DatabaseKeys {
    // Voting-related keys
    const std::string ASSET_TYPE = "assettype_";
    const std::string ASSET_TYPE_TO_REVOKE_TX_HASH = "assettype2revoketxhash_";
    const std::string ASSET_TYPE_TO_APPROVE_VOTE_ADDRESS = "assettype2approvevoteaddr_";
    const std::string ASSET_TYPE_TO_AGAINST_VOTE_ADDRESS = "assettype2againstvoteaddr_";
    const std::string ASSET_TYPE_TO_VOTE_TX_HASH = "assettype2votetxhash_";
    const std::string LOCK_ADDRESS = "lockaddr_";
    const std::string ASSET_TYPE_TO_LOCK_UTXOS = "assettype2lockutxos_";
    const std::string ASSET_TYPE_TO_PROPOSAL_INFO = "assettype2proposalinfo_";
    const std::string ASSET_TYPE_TO_REVOKE_PROPOSAL_INFO = "assettype2revokeproposalinfo_";
    const std::string ASSET_TYPE_TO_PROPOSAL_VOTE_COUNT = "assettype2proposalvotescount_";
    const std::string ADDRESS_TO_ASSET_TYPE = "addr2Assettype_";
    const std::string CONTRACT_ADDRESS_TO_ASSET_TYPE = "contractaddr2assettype_";
    const std::string ADDRESS_TO_VOTE_COUNT = "addr2votecount_";
    const std::string ASSET_TYPE_TO_TOTAL_VOTE_COUNT = "assettype2totalvotecount_";

    // Block-related keys
    const std::string BLOCK_HASH_TO_BLOCK_HEIGHT = "blkhs2blkht_";
    const std::string BLOCK_HEIGHT_TO_BLOCK_HASH = "blkht2blkhs_";
    const std::string BLOCK_HEIGHT_TO_SUM_HASH = "blkht2sumhs_";
    const std::string THOUSAND_SUM_HASH_TOP = "thousandsumhstop_";
    const std::string BLOCK_HEIGHT_TO_THOUSAND_SUM_HASH = "ht2thousandsumhs_";
    const std::string BLOCK_HASH_TO_BLOCK_RAW = "blkhs2blkraw_";
    const std::string BLOCK_TOP = "blktop_";
    const std::string ADDRESS_TO_UTXOS = "addr2utxo_";
    const std::string UTXO_HASH_TO_UTXO_VALUE = "utxohash2utxovalue_";
    const std::string TRANSACTION_HASH_TO_TRANSACTION_RAW = "txhs2txraw_";
    const std::string TRANSACTION_HASH_TO_BLOCK_HASH = "txhs2blkhs_";
    const std::string ROLLBACKBLOCKS="rollbackblocks_";
    const std::string ROLLBLOCKNUM="rollblocknum_";

    // Transaction inquiry-related keys
    const std::string PERIOD_TO_GAS_AMOUNT = "period2gasamount_";
    const std::string PERIOD_TO_PACKAGER_COUNT = "period2packagercount_";
    
    // Balance and staking-related keys
    const std::string ADDRESS_TO_BALANCE = "addr2bal_";
    const std::string ADDRESS_TO_NONCE = "addr2nonce_";
    const std::string STAKE_ADDRESS = "stakeaddr_";
    const std::string ADDRESS_TO_STAKE_UTXOS = "addr2stakeutxos_";
    const std::string PEROID_TO_BONUS_UTXOS = "period2bonusutxos_";
    const std::string PEROID_TO_FOND_UTXOS = "period2fundutxos_";
    const std::string BONUS_ADDRESS_TO_DELEGATING_ADDRESS_UTXO = "bonusaddr2delegatingaddrutxos_";
    const std::string PEROID_TO_DELEGATING_UTXOS = "period2delegatingutxo_";
    const std::string BONUS_ADDRESS_TO_DELEGATING_ADDRESS_AND_ASSET_TYPE = "bonusaddr2delegatingaddrandassettype_";
    const std::string DELEGATING_ADDRESS_TO_BONUS_ADDRESS_AND_ASSET_TYPE = "delegatingaddr2bonusaddrandassettype_";

    // Deflationary mechanism and miscellaneous keys
    const std::string TOTAL_CIRCULATION = "totalcirculation_";
    const std::string TOTAL_BURN_AMOUNT = "totalburnamount_";
    const std::string TOTAL_DELEGATE_AMOUNT = "totaldelegateAmount_";
    const std::string TOTAL_LOCKED_AMOUNT = "totallockedamount_";
    const std::string PERIOD_TO_TOTAL_LOCKED_AMOUNT = "period2totallockedamount_";
    const std::string INITIALIZATION_VERSION = "initver_";
    const std::string PEROID_2_SIGN_COUNT = "peroid2signcount_";
    const std::string PEROID_2_BLOCK_COUNT = "peroid2blockcount_";
    const std::string PEROID_2_SIGN_ADDRESS = "peroid2signaddr_";
    const std::string PEROID_2_BURN_AMOUNT = "peroid2burnamount_";
    
    // ETH RLP hash to internal hash mapping
    const std::string RLP_HASH_TO_INTERNAL_HASH = "rlphash2txhash_";

    // EVM and contract-related keys
    const std::string EVM_DEPLOYER_ADDRESS = "evmdeployeraddr_";
    const std::string DEPLOYER_ADDRESS_TO_CONTRACT_ADDRESS = "deployeraddr2contractaddr_";
    const std::string CONTRACT_ADDRESS_TO_CONTRACT_CODE = "contractaddr2contractcode_";
    const std::string CONTRACT_ADDRESS_TO_DEPLOY_UTXO = "contractaddr2deployutxo_";
    const std::string CONTRACT_ADDRESS_TO_LATEST_UTXO = "contractaddr2latestutxo_";
    const std::string MPT_KEY_TO_MPT_VALUE = "mptkey2mptvalue_";

    // Slashing-related keys
    const std::string EVIDENCE_ON_CHAIN = "evidence_on_chain_";
    const std::string EVIDENCE_COUNT = "evidence_count_";
    const std::string EVIDENCE_THRESHOLD_LIST = "evidence_threshold_list_";
    const std::string EVIDENCE_THRESHOLD = "evidence_threshold_";
    const std::string PUNISHMENT_HISTORY = "punishment_history_"; // punishment_id -> target,period,level,tx_hash
    const std::string PUNISHMENT_HISTORY_BY_ADDR = "punishment_history_by_addr_"; // target -> punishment_id list
    const std::string PUNISHMENT_DELEGATION_REFUNDS = "punishment_delegation_refunds_"; // punishment_id -> refund rollback snapshot
    const std::string SLASH_TOMBSTONE_LIST = "slash_tombstone_list_"; // tombstoned address list for RPC
    const std::string SLASH_JAIL = "slash_jail_";
    const std::string SLASH_TOMBSTONE = "slash_tombstone_";
    const std::string SLASH_VRF_FAIL = "slash_vrf_fail_";
    const std::string SLASH_INVALID_BLOCK = "slash_invalid_block_";
    const std::string SLASH_DISCONNECT = "slash_disconnect_";
    const std::string SLASH_OFFLINE_NOTICE = "slash_offline_notice_";
    const std::string SLASH_BLOCK_SIGN = "slash_blocksign_";  // height:addr → blockHash (double-sign detection)
    const std::string SLASH_LAST_ACTIVE = "slash_lastactive_"; // addr → last signing period
    const std::string SLASH_CONSECUTIVE_NORMAL = "slash_consecnormal_"; // addr → consecutive normal signing count
    const std::string SLASH_L3_COUNT = "slash_l3count_"; // addr → number of L3 slashes (for递增 rate)

} // namespace DatabaseKeys

bool DBInit(const std::string &db_path)
{
    MagicSingleton<RocksDB>::GetInstance()->setDBPath(db_path);
    rocksdb::Status ret_status;
    if (!MagicSingleton<RocksDB>::GetInstance()->initDB(ret_status))
    {
        ERRORLOG("rocksdb init fail {}", ret_status.ToString());
        return false;
    }
    return true;
}

DBReader::DBReader() : db_reader_(MagicSingleton<RocksDB>::GetInstance())
{
}

DBStatus DBReader::getTotalCirculation(uint64_t &totalCirculation)
{
    std::string value;
    auto ret = readData(DatabaseKeys::TOTAL_CIRCULATION, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        totalCirculation = std::stoull(value);
    }
    return ret;
}

DBStatus DBReader::getBlockHashesByBlockHeight(uint64_t startHeight, uint64_t endHeight, std::vector<std::string> &blockHashes)
{
    std::vector<std::string> keys;
    std::vector<std::string> values;
    std::vector<std::string> hashes;
    for (uint64_t index_height = startHeight; index_height <= endHeight; ++index_height)
    {
        keys.push_back(DatabaseKeys::BLOCK_HEIGHT_TO_BLOCK_HASH + std::to_string(index_height));
    }
    auto ret = multiReadData(keys, values);
    if (values.empty() && DBStatus::DB_SUCCESS != ret)
    {
        return ret;
    }
    blockHashes.clear();
    for (auto &value : values)
    {
        hashes.clear();
        StringUtil::SplitString(value, "_", hashes);
        blockHashes.insert(blockHashes.end(), hashes.begin(), hashes.end());
    }
    return ret;
}
DBStatus DBReader::getBlocksByBlockHash(const std::vector<std::string> &blockHashes, std::vector<std::string> &blocks)
{
    std::vector<std::string> keys;
    for (auto &hash : blockHashes)
    {
        keys.push_back(DatabaseKeys::BLOCK_HASH_TO_BLOCK_RAW + hash);
    }
    return multiReadData(keys, blocks);
}

// Gets the height of the data block by the block hash
DBStatus DBReader::getBlockHeightByBlockHash(const std::string &blockHash, unsigned int &blockHeight)
{
    if (blockHash.empty())
    {
        return DBStatus::DB_PARAM_NULL;
    }
    std::string db_key = DatabaseKeys::BLOCK_HASH_TO_BLOCK_HEIGHT + blockHash;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        blockHeight = std::stoul(value);
    }
    return ret;
}


DBStatus DBReader::getBlockHashByBlockHeight(uint64_t blockHeight, std::string &hash)
{
    std::vector<std::string> hashes;
    auto ret = getBlockHashsByBlockHeight(blockHeight, hashes);
    if (DBStatus::DB_SUCCESS == ret && (!hashes.empty()))
    {
        hash = hashes.at(0);
    }
    return ret;
}


// Multiple block hashes are obtained by the height of the data block
DBStatus DBReader::getBlockHashsByBlockHeight(uint64_t blockHeight, std::vector<std::string> &hashes)
{
    std::string db_key = DatabaseKeys::BLOCK_HEIGHT_TO_BLOCK_HASH + std::to_string(blockHeight);
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", hashes);
    }
    return ret;
}


// The block information is obtained through the block hash
DBStatus DBReader::getBlockByBlockHash(const std::string &blockHash, std::string &block)
{
    if (blockHash.empty())
    {
        return DBStatus::DB_PARAM_NULL;
    }
    std::string db_key = DatabaseKeys::BLOCK_HASH_TO_BLOCK_RAW + blockHash;
    return readData(db_key, block);
}

// Get Sum hash per 100 heights
DBStatus DBReader::getSumHashByHeight(uint64_t height, std::string& sumHash)
{
    if (height % 100 != 0 || height == 0)
    {
        return DBStatus::DB_PARAM_NULL;
    }

    std::string db_key = DatabaseKeys::BLOCK_HEIGHT_TO_SUM_HASH + std::to_string(height);
    return readData(db_key, sumHash); 
}


DBStatus DBReader::getThousandSumHashByBlockHeight(const uint64_t &blockHeight, std::string &sumHash)
{
    if (blockHeight % 1000 != 0 || blockHeight == 0)
    {
        return DBStatus::DB_PARAM_NULL;
    }

    std::string db_key = DatabaseKeys::BLOCK_HEIGHT_TO_THOUSAND_SUM_HASH + std::to_string(blockHeight);
    return readData(db_key, sumHash); 
}


DBStatus DBReader::getThousandSumHashTop(uint64_t &thousandNum)
{
    std::string value;
    auto ret = readData(DatabaseKeys::THOUSAND_SUM_HASH_TOP, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        thousandNum = std::stoul(value);
    }
    return ret;
}

DBStatus DBReader::getBlockTop(uint64_t &blockHeight)
{
    std::string value;
    auto ret = readData(DatabaseKeys::BLOCK_TOP, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        blockHeight = std::stoul(value);
    }
    return ret;
}

DBStatus DBReader::getUtxoHashsByAddress(const std::string &address, const std::string& assetType, std::vector<std::string> &utxoHashesList)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_UTXOS + address + assetType;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", utxoHashesList);
    }
    return ret;
}

DBStatus DBReader::getUtxoValueByUtxoHashes(const std::string &utxoHash, const std::string &address, const std::string &assetType, std::string &balance)
{
    std::string db_key = DatabaseKeys::UTXO_HASH_TO_UTXO_VALUE + address + "_" + utxoHash + "_" + assetType;
    return readData(db_key, balance);
}

// Obtain the transaction raw data by the transaction hash
DBStatus DBReader::getTransactionByHash(const std::string &txHash, std::string &txRaw)
{
    std::string db_key = DatabaseKeys::TRANSACTION_HASH_TO_TRANSACTION_RAW + txHash;
    return readData(db_key, txRaw);
}

// Get the block hash by transaction hash
DBStatus DBReader::getBlockHashByTransactionHash(const std::string &txHash, std::string &blockHash)
{
    std::string db_key = DatabaseKeys::TRANSACTION_HASH_TO_BLOCK_HASH + txHash;
    return readData(db_key, blockHash);
}

// Get the account balance by the transaction address
DBStatus DBReader::getBalanceByAddr(const std::string &address, const std::string & assetType, int64_t &balance)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_BALANCE + address + assetType;
    std::string value="0";
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        balance = std::stol(value);
    }
    if(DBStatus::DB_NOT_FOUND == ret) // DB_NOT_FOUND means balance is 0, which is not an error
    {
       balance = 0;
    }
    return ret;
}

DBStatus DBReader::getNonceByAddr(const std::string &address, uint64_t &nonce)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_NONCE + address;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        nonce = std::stoull(value);
    }
    return ret;
}

DBStatus DBReader::getPendingTransactionReservations(std::string &reservations)
{
    return readData("pending_tx_reservations", reservations);
}

DBStatus DBReader::getContractWaitingBatches(std::string &batches)
{
    return readData("contract_waiting_batches", batches);
}

// Get the staking address
DBStatus DBReader::getStakeAddr(std::vector<std::string> &addresses)
{
    std::string value;
    auto ret = readData(DatabaseKeys::STAKE_ADDRESS, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", addresses);
    }
    return ret;
}

// Get the UTXO of the staking address
DBStatus DBReader::getStakeUtxoByAddr(const std::string &address, const std::string& assetType, std::vector<std::string> &utxos)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_STAKE_UTXOS + address + assetType;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", utxos);
    }
    return ret;
}

DBStatus DBReader::getDelegatingAddrAndAssetTypeByBonusAddr(const std::string &bonusAddr, std::multimap<std::string, std::string> &addresses_assetType)
{
    std::string db_key = DatabaseKeys::BONUS_ADDRESS_TO_DELEGATING_ADDRESS_AND_ASSET_TYPE + bonusAddr;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", addresses_assetType);
    }

    return ret;
}

DBStatus DBReader::getBonusAddrAndAssetTypeByDelegatingAddr(const std::string &address, std::multimap<std::string, std::string> & bonusAddr_assetType)
{
    std::string db_key = DatabaseKeys::DELEGATING_ADDRESS_TO_BONUS_ADDRESS_AND_ASSET_TYPE + address;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", bonusAddr_assetType);
    }
    return ret;
}

DBStatus DBReader::getDelegatingAddrUtxoByBonusAddr(const std::string &bonusAddr, const std::string &delegatingAddr,  const std::string assetType, std::vector<std::string> &utxos)
{
    std::string db_key = DatabaseKeys::BONUS_ADDRESS_TO_DELEGATING_ADDRESS_UTXO + bonusAddr + "_" + delegatingAddr + "_" + assetType;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", utxos);
    }
    return ret;
}

DBStatus DBReader::getBonusUtxoByPeriod(const uint64_t &period, std::vector<std::string> &utxos)
{
    std::string value;
    auto ret = readData(DatabaseKeys::PEROID_TO_BONUS_UTXOS + std::to_string(period), value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", utxos);
    }
    return ret;
}


DBStatus DBReader::getFundUtxoByPeriod(const uint64_t &period, std::vector<std::string> &utxos)
{
    std::string value;
    auto ret = readData(DatabaseKeys::PEROID_TO_FOND_UTXOS + std::to_string(period), value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", utxos);
    }
    return ret;
}

DBStatus DBReader::getDelegatingUtxoByPeriod(const uint64_t &period, std::vector<std::string> &utxos)
{
    std::string value;
    auto ret = readData(DatabaseKeys::PEROID_TO_DELEGATING_UTXOS + std::to_string(period), value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", utxos);
    }
    return ret;
}

//  Get Number of signatures By period
DBStatus DBReader::getSignCountByPeriod(const uint64_t &period, const std::string &address, uint64_t &SignNumber)
{
    std::string value;
    auto ret = readData(DatabaseKeys::PEROID_2_SIGN_COUNT + std::to_string(period) + address, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        SignNumber = std::stoull(value);
    }
    return ret;
}

//  Get Number of blocks By period
DBStatus DBReader::getBlockNumberByPeriod(const uint64_t &period, uint64_t &BlockNumber)
{
    std::string value;
    auto ret = readData(DatabaseKeys::PEROID_2_BLOCK_COUNT + std::to_string(period), value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        BlockNumber = std::stoull(value);
    }
    return ret;
}

//  Set Addr of signatures By period
DBStatus DBReader::getSignAddrByPeriod(const uint64_t &period, std::vector<std::string> &signAddresses)
{
    std::string value;
    auto ret = readData(DatabaseKeys::PEROID_2_SIGN_ADDRESS + std::to_string(period), value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", signAddresses);
    }
    return ret;
}

DBStatus DBReader::getBurnAmountByPeriod(const uint64_t &period, uint64_t &burnAmount)
{
    std::string value;
    auto ret = readData(DatabaseKeys::PEROID_2_BURN_AMOUNT + std::to_string(period), value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        burnAmount = std::stoull(value);
    }
    return ret;
}

DBStatus DBReader::getTotalBurnAmount(uint64_t &totalBurn)
{
    std::string value;
    auto ret = readData(DatabaseKeys::TOTAL_BURN_AMOUNT, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        totalBurn = std::stoull(value);
    }
    return ret;
}

// Get the total amount of stake
DBStatus DBReader::getTotalDelegatingAmount(uint64_t &Total)
{
    std::string value;
    auto ret = readData(DatabaseKeys::TOTAL_DELEGATE_AMOUNT, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        Total = std::stoull(value);
    }
    return ret;
}

DBStatus DBReader::getEvmDeployerAddr(std::vector<std::string> &deployerAddr)
{
    std::string value;
    auto ret = readData(DatabaseKeys::EVM_DEPLOYER_ADDRESS, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value,  "_", deployerAddr);
    }
    return ret;
}


DBStatus DBReader::getContractAddrByDeployerAddr(const std::string &deployerAddr, std::vector<std::string> &contractAddr)
{
    std::string db_key = DatabaseKeys::DEPLOYER_ADDRESS_TO_CONTRACT_ADDRESS + deployerAddr;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", contractAddr);
    }
    return ret;
}

DBStatus DBReader::getContractCodeByContractAddr(const std::string &contractAddr, std::string &contractCode)
{
    std::string db_key = DatabaseKeys::CONTRACT_ADDRESS_TO_CONTRACT_CODE + contractAddr;
    return readData(db_key, contractCode);
}
DBStatus DBReader::getContractDeployUtxoByContractAddr(const std::string &contractAddr, std::string &contractDeploymentUtxo)
{
    std::string db_key = DatabaseKeys::CONTRACT_ADDRESS_TO_DEPLOY_UTXO + contractAddr;
    return readData(db_key, contractDeploymentUtxo);
}

DBStatus DBReader::getLatestUtxoByContractAddr(const std::string &contractAddr, std::string &Utxo)
{
    std::string db_key = DatabaseKeys::CONTRACT_ADDRESS_TO_LATEST_UTXO + contractAddr;
    return readData(db_key, Utxo);
}

DBStatus DBReader::getMptValueByMptKey(const std::string &mptKey, std::string &MptValue)
{
    std::string db_key = DatabaseKeys::MPT_KEY_TO_MPT_VALUE + mptKey;
    return readData(db_key, MptValue);
}
DBStatus DBReader::getAssetType(std::vector<std::string> &assetTypes)
{
    std::string value;
    auto ret = readData(DatabaseKeys::ASSET_TYPE, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", assetTypes);
    }
    return ret;
}

//根据交易类型hash 获取撤销交易类型hash
DBStatus DBReader::getRevokeTxHashByAssetType(const std::string &assetType, std::vector<std::string> &revokeTxHashs)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_REVOKE_TX_HASH + assetType;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", revokeTxHashs);
    }
    return ret;
}

//获取投赞成票 ID
DBStatus DBReader::getApproveAddrsByAssetType(const std::string &assetType, std::set<std::string> &addrs)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_APPROVE_VOTE_ADDRESS + assetType;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitStringToSet(value, "_", addrs);
    }
    return ret;
}

//获取投反对票 ID
DBStatus DBReader::getAgainstAddrsByAssetType(const std::string &assetType, std::set<std::string> &addrs)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_AGAINST_VOTE_ADDRESS + assetType;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitStringToSet(value, "_", addrs);
    }
    return ret;
}

DBStatus DBReader::getVoteTxHashByAssetType(const std::string &assetType, std::vector<std::string> &txHashs)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_VOTE_TX_HASH + assetType;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", txHashs);
    }
    return ret;
}


//获取资产类型对应的info
DBStatus DBReader::getProposalInfoByAssetType(const std::string &assetType, std::string& info)
{
    return readData(DatabaseKeys::ASSET_TYPE_TO_PROPOSAL_INFO + assetType, info);
}

DBStatus DBReader::getRevokeProposalInfoByAssetType(const std::string & assetType, std::string& info)
{
    return readData(DatabaseKeys::ASSET_TYPE_TO_REVOKE_PROPOSAL_INFO + assetType, info);
}

DBStatus DBReader::getVoteCountByAssetType(const std::string &assetType, uint64_t & approve, uint64_t & against)
{
    std::string value;
    auto ret = readData(DatabaseKeys::ASSET_TYPE_TO_PROPOSAL_VOTE_COUNT + assetType, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        std::vector<std::string> vote_count;
        StringUtil::SplitString(value, "_", vote_count);
        if (vote_count.size() != 2)
        {
            return DBStatus::DB_NOT_FOUND;
        }

        approve = std::stoull(vote_count.at(0));
        against = std::stoull(vote_count.at(1));
    }
    return ret;
}

DBStatus DBReader::getVoteCountByAddr(const std::string &addr, const std::string &assetType, uint64_t& num)
{
    std::string value;
    auto ret = readData(DatabaseKeys::ADDRESS_TO_VOTE_COUNT + assetType + addr, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        num = std::stoull(value);
    }
    return ret;
}

DBStatus DBReader::getTotalCountByAssetType(const std::string &assetType, uint64_t& num)
{
    std::string value;
    auto ret = readData(DatabaseKeys::ASSET_TYPE_TO_TOTAL_VOTE_COUNT + assetType, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        num = std::stoull(value);
    }
    return ret;
}

//获取所有投票质押地址
DBStatus DBReader::getLockAddr(std::vector<std::string> &addresses)
{
    std::string value;
    
    auto ret = readData(DatabaseKeys::LOCK_ADDRESS, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", addresses);
    }
    return ret;
}

//根据投票质押地址获取uixo
DBStatus DBReader::getLockAddrUtxo(const std::string &address, const std::string &assetType, std::vector<std::string> & utxos)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_LOCK_UTXOS + address + assetType;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", utxos);
    }
    return ret;
}

//根据地址获取资产类型
/// TODO 需要在交易转账，申领等操作中增加此类函数的作用
DBStatus DBReader::getAssetTypeByAddr(const std::string& addr, std::vector<std::string> &assetType)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_ASSET_TYPE + addr;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", assetType);
    }
    return ret;
}

DBStatus DBReader::getAssetTypeByContractAddr(const std::string& contractAddr, std::string &assetType)
{
    return readData(DatabaseKeys::CONTRACT_ADDRESS_TO_ASSET_TYPE + contractAddr, assetType);
}

DBStatus DBReader::getGasAmountByPeriod(const uint64_t &period, const std::string &type,uint64_t &gasAmount)
{
    std::string value;
    
    std::string db_key = DatabaseKeys::PERIOD_TO_GAS_AMOUNT + std::to_string(period) + "_" + type;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        gasAmount = std::stoull(value);
    }
    return ret;
}

DBStatus DBReader::getPackagerCountByPeriod(const uint64_t& period, const std::string& address, uint64_t& count)
{
    std::string value;
    
    std::string db_key = DatabaseKeys::PERIOD_TO_PACKAGER_COUNT + std::to_string(period) + "_" + address;
    auto ret = readData(db_key,value);
    if(DBStatus::DB_SUCCESS ==  ret)
    {
        count = std::stoull(value);
    }
    return ret;
}


DBStatus DBReader::getTotalLockedAmonut(uint64_t& TotalLockedAmount)
{
    std::string value;
    auto ret = readData(DatabaseKeys::TOTAL_LOCKED_AMOUNT, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        TotalLockedAmount = std::stoull(value);
    }
    return ret;
}

DBStatus DBReader::getTotalLockedAmountByPeriod(const uint64_t& period, uint64_t& LockedAmount)
{
    std::string value;
    auto ret = readData(DatabaseKeys::PERIOD_TO_TOTAL_LOCKED_AMOUNT + std::to_string(period), value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        LockedAmount = std::stoull(value);
    }
    return ret;
}

DBStatus DBReader::getInitVer(std::string &version)
{
    std::string tmpversion;
    auto ret = readData(DatabaseKeys::INITIALIZATION_VERSION, tmpversion);
    if (DBStatus::DB_SUCCESS == ret)
    {
        version = tmpversion;
    }
    return ret;
}

DBStatus DBReader::multiReadData(const std::vector<std::string> &keys, std::vector<std::string> &values)
{
    if (keys.empty())
    {
        return DBStatus::DB_PARAM_NULL;
    }

    std::vector<std::string> cache_values;
    std::vector<std::string> db_keys_str;
    std::vector<rocksdb::Slice> db_keys;

    db_keys_str.reserve(keys.size());
    db_keys.reserve(keys.size());

    for (const auto &key : keys)
    {
        db_keys_str.push_back(key);
        db_keys.push_back(rocksdb::Slice(db_keys_str.back()));
    }

    std::string value;
    std::vector<rocksdb::Status> ret_status;
    if (db_reader_.multiReadData(db_keys, values, ret_status))
    {
        if (db_keys.size() != values.size())
        {
            return DBStatus::DB_ERROR;
        }
        values.insert(values.end(), cache_values.begin(), cache_values.end());
        return DBStatus::DB_SUCCESS;
    }
    else
    {
        for (auto status : ret_status)
        {
            if (status.IsNotFound())
            {
                return DBStatus::DB_NOT_FOUND;
            }
        }
    }
    return DBStatus::DB_ERROR;
}

DBStatus DBReader::readData(const std::string &key, std::string &value)
{
    if (key.empty())
    {
        return DBStatus::DB_PARAM_NULL;
    }

    rocksdb::Status ret_status;
    if (db_reader_.readData(key, value, ret_status))
    {
        return DBStatus::DB_SUCCESS;
    }
    else if (ret_status.IsNotFound())
    {
        value.clear();
        return DBStatus::DB_NOT_FOUND;
    }
    return DBStatus::DB_ERROR;
}

DBReadWriter::DBReadWriter(const std::string &txn_name) : dbReaderWriter(MagicSingleton<RocksDB>::GetInstance(), txn_name)
{
    autoOperationTrans = false;
    reInitTransaction();
}

DBReadWriter::~DBReadWriter()
{
    transactionRollBack();
}
DBStatus DBReadWriter::reInitTransaction()
{
    auto ret = transactionRollBack();
    if (DBStatus::DB_SUCCESS != ret)
    {
        return ret;
    }
    autoOperationTrans = true;
    if (!dbReaderWriter.transactionInit())
    {
        ERRORLOG("transction init error");
        return DBStatus::DB_ERROR;
    }
    return DBStatus::DB_SUCCESS;
}

DBStatus DBReadWriter::transactionCommit()
{
    rocksdb::Status ret_status;
    if (dbReaderWriter.transactionCommit(ret_status))
    {
        autoOperationTrans = false;
        return DBStatus::DB_SUCCESS;
    }
    ERRORLOG("transactionCommit faild:{}:{}", ret_status.code(), ret_status.ToString());
    return DBStatus::DB_ERROR;
}

DBStatus DBReadWriter::setNonceByAddr(const std::string &address, uint64_t nonce)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_NONCE + address;
    return writeData(db_key, std::to_string(nonce));
}

DBStatus DBReadWriter::setPendingTransactionReservations(const std::string &reservations)
{
    return writeData("pending_tx_reservations", reservations);
}

DBStatus DBReadWriter::setContractWaitingBatches(const std::string &batches)
{
    return writeData("contract_waiting_batches", batches);
}

DBStatus DBReadWriter::setTotalCirculation(uint64_t totalCirculation)
{
    return writeData(DatabaseKeys::TOTAL_CIRCULATION, std::to_string(totalCirculation));
}

DBStatus DBReadWriter::removeTotalCirculation()
{
    return deleteData(DatabaseKeys::TOTAL_CIRCULATION);
}

DBStatus DBReader::getInternalHashByRlpHash(const std::string &rlpHash, std::string &internalHash)
{
    std::string db_key = DatabaseKeys::RLP_HASH_TO_INTERNAL_HASH + rlpHash;
    return readData(db_key, internalHash);
}

DBStatus DBReadWriter::setInternalHashByRlpHash(const std::string &rlpHash, const std::string &internalHash)
{
    std::string db_key = DatabaseKeys::RLP_HASH_TO_INTERNAL_HASH + rlpHash;
    return writeData(db_key, internalHash);
}

DBStatus DBReadWriter::removeInternalHashByRlpHash(const std::string &rlpHash)
{
    std::string db_key = DatabaseKeys::RLP_HASH_TO_INTERNAL_HASH + rlpHash;
    return deleteData(db_key);
}

// Sets the height of the data block by block hash
DBStatus DBReadWriter::setBlockHeightByBlockHash(const std::string &blockHash, const unsigned int blockHeight)
{
    std::string db_key = DatabaseKeys::BLOCK_HASH_TO_BLOCK_HEIGHT + blockHash;
    return writeData(db_key, std::to_string(blockHeight));
}


// Removes the block height from the database by block hashing
DBStatus DBReadWriter::removeBlockHeightByBlockHash(const std::string &blockHash)
{
    std::string db_key = DatabaseKeys::BLOCK_HASH_TO_BLOCK_HEIGHT + blockHash;
    return deleteData(db_key);
}

// Hash data blocks by block height (multiple block hashes at the same height at the same time of concurrency)
DBStatus DBReadWriter::setBlockHashByBlockHeight(const unsigned int blockHeight, const std::string &blockHash, bool isMainBlock)
{
    std::string db_key = DatabaseKeys::BLOCK_HEIGHT_TO_BLOCK_HASH + std::to_string(blockHeight);
    return mergeValue(db_key, blockHash, isMainBlock);
}


// Remove the hash of a block in the database by block height
DBStatus DBReadWriter::removeBlockHashByBlockHeight(const unsigned int blockHeight, const std::string &blockHash)
{
    std::string db_key = DatabaseKeys::BLOCK_HEIGHT_TO_BLOCK_HASH + std::to_string(blockHeight);
    return removeMergeValue(db_key, blockHash);
}


// Set blocks by block hash
DBStatus DBReadWriter::setBlockByBlockHash(const std::string &blockHash, const std::string &block)
{
    std::string db_key = DatabaseKeys::BLOCK_HASH_TO_BLOCK_RAW + blockHash;
    return writeData(db_key, block);
}


// Remove blocks inside a data block by block hashing
DBStatus DBReadWriter::removeBlockByBlockHash(const std::string &blockHash)
{
    std::string db_key = DatabaseKeys::BLOCK_HASH_TO_BLOCK_RAW + blockHash;
    return deleteData(db_key);
}


// Set Sum hash per 100 heights
DBStatus DBReadWriter::setSumHashByHeight(uint64_t height, const std::string& sumHash)
{
    std::string db_key = DatabaseKeys::BLOCK_HEIGHT_TO_SUM_HASH + std::to_string(height);
    return writeData(db_key, sumHash);
}

// Remove Sum hash per 100 heights
DBStatus DBReadWriter::removeSumHashByHeight(uint64_t height)
{
    std::string db_key = DatabaseKeys::BLOCK_HEIGHT_TO_SUM_HASH + std::to_string(height);
    return deleteData(db_key);
}


//Set  Sum hash per 1000 heights
DBStatus DBReadWriter::setThousandSumHashByBlockHeight(const uint64_t &blockHeight ,const std::string &sumHash)
{
    std::string db_key = DatabaseKeys::BLOCK_HEIGHT_TO_THOUSAND_SUM_HASH + std::to_string(blockHeight);
    return writeData(db_key, sumHash);
}

//Set  Sum hash per 1000 heights
DBStatus DBReadWriter::removeThousandSumHashByBlockHeight(const uint64_t &blockHeight)
{
    std::string db_key = DatabaseKeys::BLOCK_HEIGHT_TO_THOUSAND_SUM_HASH + std::to_string(blockHeight);
    return deleteData(db_key);
}


DBStatus DBReadWriter::setThousandSumHashTop(const uint64_t &thousandNum)
{
    return writeData(DatabaseKeys::THOUSAND_SUM_HASH_TOP, std::to_string(thousandNum));
}

DBStatus DBReadWriter::removeThousandSumHashTop(const uint64_t &thousandNum)
{
    return deleteData(DatabaseKeys::THOUSAND_SUM_HASH_TOP);
}

// Set the highest block
DBStatus DBReadWriter::setBlockTop(const unsigned int blockHeight)
{
    return writeData(DatabaseKeys::BLOCK_TOP, std::to_string(blockHeight));
}


DBStatus DBReadWriter::setUtxoHashesByAddr(const std::string &address, const std::string &assetType, const std::string &utxoHash)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_UTXOS + address + assetType;
    return mergeValue(db_key, utxoHash);
}

// Remove the Utoucho hash by address
DBStatus DBReadWriter::removeUtxoHashesByAddr(const std::string &address, const std::string &assetType, const std::string &utxoHash)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_UTXOS + address + assetType;
    return removeMergeValue(db_key, utxoHash);
}

DBStatus DBReadWriter::setUtxoValueByUtxoHashes(const std::string &utxoHash, const std::string &address, const std::string &assetType, const std::string &balance)
{
    std::string db_key = DatabaseKeys::UTXO_HASH_TO_UTXO_VALUE + address + "_" + utxoHash + "_" + assetType;
    return writeData(db_key, balance);
}

DBStatus DBReadWriter::removeUtxoValueByUtxoHashes(const std::string &utxoHash, const std::string &address, const std::string &assetType, const std::string &balance)
{
    std::string db_key = DatabaseKeys::UTXO_HASH_TO_UTXO_VALUE + address + "_" + utxoHash + "_" + assetType;
    return deleteData(db_key);
}

// Set the transaction raw data by transaction hash
DBStatus DBReadWriter::setTransactionByHash(const std::string &txHash, const std::string &txRaw)
{
    std::string db_key = DatabaseKeys::TRANSACTION_HASH_TO_TRANSACTION_RAW + txHash;
    return writeData(db_key, txRaw);
}

// Remove the transaction raw data from the database by transaction hash
DBStatus DBReadWriter::removeTransactionByHash(const std::string &txHash)
{
    std::string db_key = DatabaseKeys::TRANSACTION_HASH_TO_TRANSACTION_RAW + txHash;
    return deleteData(db_key);
}


// Set the block hash by transaction hash
DBStatus DBReadWriter::setBlockHashByTransactionHash(const std::string &txHash, const std::string &blockHash)
{
    std::string db_key = DatabaseKeys::TRANSACTION_HASH_TO_BLOCK_HASH + txHash;
    return writeData(db_key, blockHash);
}

// Remove the block hash from the database by transaction hashing
DBStatus DBReadWriter::removeBlockHashByTransactionHash(const std::string &txHash)
{
    std::string db_key = DatabaseKeys::TRANSACTION_HASH_TO_BLOCK_HASH + txHash;
    return deleteData(db_key);
}

// Set the account balance by the transaction address
DBStatus DBReadWriter::setBalanceByAddr(const std::string &address, const std::string &assetType, int64_t balance)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_BALANCE + address + assetType;
    return writeData(db_key, std::to_string(balance));
}

DBStatus DBReadWriter::removeBalanceByAddr(const std::string &address, const std::string &assetType)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_BALANCE + address + assetType;
    return deleteData(db_key);
}

// Set the staking address
DBStatus DBReadWriter::setStakeAddr(const std::string &address)
{
    return mergeValue(DatabaseKeys::STAKE_ADDRESS, address);
}

// Remove the staking address from the database
DBStatus DBReadWriter::removeStakeAddr(const std::string &address)
{
    return removeMergeValue(DatabaseKeys::STAKE_ADDRESS, address);
}

// Set up UTXO for the Holddown Asset Account
DBStatus DBReadWriter::setStakeUtxoByAddr(const std::string &stakeAddr, const std::string& assetType, const std::string &utxo)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_STAKE_UTXOS + stakeAddr + assetType;
    return mergeValue(db_key, utxo);
}

// Remove the UTXO from the data
DBStatus DBReadWriter::removeStakeUtxoByAddr(const std::string &stakeAddr, const std::string& assetType, const std::string &utxo)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_STAKE_UTXOS + stakeAddr + assetType;
    return removeMergeValue(db_key, utxo);
}

// Set the delegated staking address Delegating_A:X_Y_Z
DBStatus DBReadWriter::setDelegatingAddrAndAssetTypeByBonusAddr(const std::string &bonusAddr, const std::string& delegatingAddr, const std::string assetType)
{
    DEBUGLOG("setDelegatingAddrAndAssetTypeByBonusAddr : bonusAddr: {} , delegatingAddr : {} , assetType: {}", bonusAddr, delegatingAddr, assetType);
    std::string db_key = DatabaseKeys::BONUS_ADDRESS_TO_DELEGATING_ADDRESS_AND_ASSET_TYPE + bonusAddr;
    std::string value = delegatingAddr + "-" + assetType;
    return mergeValue(db_key, value);
}

// Remove the delegated staking address from the database
DBStatus DBReadWriter::removeDelegatingAddrAndAssetTypeByBonusAddr(const std::string &bonusAddr, const std::string& delegatingAddr, const std::string assetType)
{
    std::string db_key = DatabaseKeys::BONUS_ADDRESS_TO_DELEGATING_ADDRESS_AND_ASSET_TYPE + bonusAddr;
    std::string value = delegatingAddr + "-" + assetType;
    return removeMergeValue(db_key, value);
}

DBStatus DBReadWriter::setBonusAddrAndAssetTypeByDelegatingAddr(const std::string &delegatingAddr, const std::string& bonusAddr, const std::string &assetType)
{
    std::string db_key = DatabaseKeys::DELEGATING_ADDRESS_TO_BONUS_ADDRESS_AND_ASSET_TYPE + delegatingAddr;
    std::string value = bonusAddr + "-" + assetType;
    return mergeValue(db_key, value);
}

DBStatus DBReadWriter::removeBonusAddrAndAssetTypeByDelegatingAddr(const std::string &delegatingAddr, const std::string& bonusAddr, const std::string &assetType)
{
    std::string db_key = DatabaseKeys::DELEGATING_ADDRESS_TO_BONUS_ADDRESS_AND_ASSET_TYPE + delegatingAddr;
    std::string value = bonusAddr + "-" + assetType;
    return removeMergeValue(db_key, value);
}

// Set the UTXO Delegating_A_X:u1_u2_u3 corresponding to the node where you delegating in yourself
DBStatus DBReadWriter::setDelegatingAddrUtxoByBonusAddr(const std::string &bonusAddr, const std::string &delegatingAddr, const std::string assetType, const std::string &utxo)
{
    std::string db_key = DatabaseKeys::BONUS_ADDRESS_TO_DELEGATING_ADDRESS_UTXO + bonusAddr + "_" + delegatingAddr + "_" + assetType;
    return mergeValue(db_key, utxo);
}


// Remove the UTXO corresponding to the node where you delegatinged in it
DBStatus DBReadWriter::removeDelegatingAddrUtxoByBonusAddr(const std::string &bonusAddr, const std::string &delegatingAddr, const std::string assetType, const std::string &utxo)
{
    std::string db_key = DatabaseKeys::BONUS_ADDRESS_TO_DELEGATING_ADDRESS_UTXO + bonusAddr + "_" + delegatingAddr + "_" + assetType;
    return removeMergeValue(db_key, utxo);
}

// Set up a bonus transaction
DBStatus DBReadWriter::setBonusUtxoByPeriod(const uint64_t &period, const std::string &utxo)
{
    return mergeValue(DatabaseKeys::PEROID_TO_BONUS_UTXOS + std::to_string(period), utxo);
}
// Remove a bonus transaction
DBStatus DBReadWriter::removeBonusUtxoByPeriod(const uint64_t &period, const std::string &utxo)
{
    return removeMergeValue(DatabaseKeys::PEROID_TO_BONUS_UTXOS + std::to_string(period), utxo);
}


// Set up a bonus transaction
DBStatus DBReadWriter::setFundUtxoByPeriod(const uint64_t &period, const std::string &utxo)
{
    return mergeValue(DatabaseKeys::PEROID_TO_FOND_UTXOS + std::to_string(period), utxo);
}
// Remove a bonus transaction
DBStatus DBReadWriter::removeFundUtxoByPeriod(const uint64_t &period, const std::string &utxo)
{
    return removeMergeValue(DatabaseKeys::PEROID_TO_FOND_UTXOS + std::to_string(period), utxo);
}

// Set up an Delegating transaction
DBStatus DBReadWriter::setDelegatingUtxoByPeriod(const uint64_t &period, const std::string &utxo)
{
    return mergeValue(DatabaseKeys::PEROID_TO_DELEGATING_UTXOS + std::to_string(period), utxo);
}
// Remove an Delegating transaction
DBStatus DBReadWriter::removeDelegatingUtxoByPeriod(const uint64_t &period, const std::string &utxo)
{
    return removeMergeValue(DatabaseKeys::PEROID_TO_DELEGATING_UTXOS + std::to_string(period),utxo);
}

DBStatus DBReadWriter::setEvmDeployerAddr(const std::string &deployerAddr)
{
    return mergeValue(DatabaseKeys::EVM_DEPLOYER_ADDRESS, deployerAddr);
}
DBStatus DBReadWriter::removeEvmDeployerAddr(const std::string &deployerAddr)
{
    return removeMergeValue(DatabaseKeys::EVM_DEPLOYER_ADDRESS, deployerAddr);
}
DBStatus DBReadWriter::saveRollBackBlock(const uint64_t& blockNumber, const std::string& blocks)
{
    const std::string db_key=DatabaseKeys::ROLLBACKBLOCKS+std::to_string(blockNumber);
    return mergeValue(db_key,blocks , false,"_rollbackblock_");
}

DBStatus DBReadWriter::getRollBackBlock(const uint64_t& blockNumber, std::vector<std::string>& blocks){
    const std::string db_key=DatabaseKeys::ROLLBACKBLOCKS+std::to_string(blockNumber);
    return getMergeValue(db_key,blocks ,"_rollbackblock_");
    
}

DBStatus DBReadWriter::removeRollBackBlock(const uint64_t& blockNumber,const std::string & block,bool isDeleteKey){
    const std::string db_key=DatabaseKeys::ROLLBACKBLOCKS+std::to_string(blockNumber);
    if(isDeleteKey){
        
        return deleteData(db_key);
    }
    //const std::string db_key=DatabaseKeys::ROLLBACKBLOCKS+std::to_string(blockNumber);
    return removeMergeValue(db_key,block,"_rollbackblock_");
}

DBStatus DBReadWriter::setRollbackBlockNum(const uint64_t& blockNumber,bool AddOrRemove){
    const std::string db_key=DatabaseKeys::ROLLBLOCKNUM+"blocknum";
    if(AddOrRemove){
        return mergeValue(db_key,std::to_string(blockNumber),false);
    }else{
        return removeMergeValue(db_key,std::to_string(blockNumber));
    }

}
 DBStatus DBReadWriter::getRollbackBlockNum(std::vector<uint64_t>& blockNumbers){
    const std::string db_key=DatabaseKeys::ROLLBLOCKNUM+"blocknum";
    std::vector<std::string> blockNumStrs;
    auto ret = getMergeValue(db_key, blockNumStrs);
    if (DBStatus::DB_SUCCESS == ret)
    {
        for (const auto& blockNumStr : blockNumStrs)
        {
            blockNumbers.push_back(std::stoull(blockNumStr));
        }
    }
    return ret;
 }

   DBStatus DBReadWriter::getAll30DayLock(const std::string & addr,std::vector<std::string> & lockdatas){
        const std::string db_key=addr;

        auto ret = getMergeValue(db_key, lockdatas,"_All30day_");
        return ret;
}

DBStatus DBReadWriter::addOneLockData(const std::string & addr,const std::string & data){
     const std::string db_key=addr;
     auto ret=mergeValue(db_key,data,false,"_All30day_");
    return ret;
}
DBStatus DBReadWriter::removeOneLockData(const std::string & addr,const std::string & data){
    const std::string db_key=addr;  
    return removeMergeValue(db_key,data,"_All30day_");
}




 DBStatus DBReadWriter::get30DayLockData(const std::string & addr,const std::string & utxo_hash,const std::string & asset_type,uint64_t & time){
    const std::string db_key=addr+utxo_hash+asset_type;
    // StringUtil::SplitString();
    std::vector<std::string> values;
     auto ret = getMergeValue(db_key, values);
    if (DBStatus::DB_SUCCESS == ret && !values.empty())
    {
        std::string v=values[0];

        time = std::stoull(values[0]);

    } else {
      return DBStatus::DB_NOT_FOUND;
    }
    return ret;
 }
    DBStatus DBReadWriter::set30DayLockData(const std::string & addr,const std::string & utxo_hash,const std::string & asset_type,const uint64_t & time,const bool deletekey){
        const std::string db_key=addr+utxo_hash+asset_type;
        std::string value=std::to_string(time);
        if(!deletekey){
            return mergeValue(db_key,value,false);
        }else{
            return deleteData(db_key);
        }
    }


DBStatus DBReadWriter::setContractAddrByDeployerAddr(const std::string &deployerAddr, const std::string &contractAddr)
{
    std::string db_key = DatabaseKeys::DEPLOYER_ADDRESS_TO_CONTRACT_ADDRESS + deployerAddr;
    return mergeValue(db_key, contractAddr);
}

DBStatus DBReadWriter::removeContractAddrByDeployerAddr(const std::string &deployerAddr, const std::string &contractAddr)
{
    std::string db_key = DatabaseKeys::DEPLOYER_ADDRESS_TO_CONTRACT_ADDRESS + deployerAddr;
    return removeMergeValue(db_key, contractAddr);
}

DBStatus DBReadWriter::setContractCodeByContractAddr(const std::string &contractAddr, const std::string &contractCode)
{
    std::string db_key = DatabaseKeys::CONTRACT_ADDRESS_TO_CONTRACT_CODE + contractAddr;
    return writeData(db_key, contractCode);
}

DBStatus DBReadWriter::removeContractCodeByContractAddr(const std::string &contractAddr)
{
    std::string db_key = DatabaseKeys::CONTRACT_ADDRESS_TO_CONTRACT_CODE + contractAddr;
    return deleteData(db_key);
}

DBStatus DBReadWriter::setContractDeployUtxoByContractAddr(const std::string &contractAddr, const std::string &contractDeploymentUtxo)
{
    std::string db_key = DatabaseKeys::CONTRACT_ADDRESS_TO_DEPLOY_UTXO + contractAddr;
    return writeData(db_key, contractDeploymentUtxo);
}

DBStatus DBReadWriter::removeContractDeployUtxoByContractAddr(const std::string &contractAddr)
{
    std::string db_key = DatabaseKeys::CONTRACT_ADDRESS_TO_DEPLOY_UTXO + contractAddr;
    return deleteData(db_key);
}

DBStatus DBReadWriter::setLatestUtxoByContractAddr(const std::string &contractAddr, const std::string &utxo)
{
    std::string db_key = DatabaseKeys::CONTRACT_ADDRESS_TO_LATEST_UTXO + contractAddr;
    return writeData(db_key, utxo);
}

DBStatus DBReadWriter::removeLatestUtxoByContractAddr(const std::string &contractAddr)
{
    std::string db_key = DatabaseKeys::CONTRACT_ADDRESS_TO_LATEST_UTXO + contractAddr;
    return deleteData(db_key);
}

DBStatus DBReadWriter::setMptValueByMptKey(const std::string &mptKey, const std::string &MptValue)
{
    std::string db_key = DatabaseKeys::MPT_KEY_TO_MPT_VALUE + mptKey;
    return writeData(db_key, MptValue);
}
DBStatus DBReadWriter::removeMptValueByMptKey(const std::string &mptKey)
{
    std::string db_key = DatabaseKeys::MPT_KEY_TO_MPT_VALUE + mptKey;
    return deleteData(db_key);
}
//  Set Number of signatures By period
DBStatus DBReadWriter::setSignCountByPeriod(const uint64_t &period, const std::string &address, const uint64_t &SignNumber)
{
    std::string db_key = DatabaseKeys::PEROID_2_SIGN_COUNT + std::to_string(period) + address;
    return writeData(db_key, std::to_string(SignNumber));
}

//  Remove Number of signatures By period
DBStatus DBReadWriter::removeSignCountByPeriod(const uint64_t &period, const std::string &address)
{
    std::string db_key = DatabaseKeys::PEROID_2_SIGN_COUNT + std::to_string(period) + address;
    return deleteData(db_key);
}

//  Set Number of blocks By period
DBStatus DBReadWriter::setBlockNumberByPeriod(const uint64_t &period, const uint64_t &BlockNumber)
{
    std::string db_key = DatabaseKeys::PEROID_2_BLOCK_COUNT + std::to_string(period);
    return writeData(db_key, std::to_string(BlockNumber));
}


//  Remove Number of blocks By period
DBStatus DBReadWriter::removeBlockNumberByPeriod(const uint64_t &period)
{
    std::string db_key = DatabaseKeys::PEROID_2_BLOCK_COUNT + std::to_string(period);
    return deleteData(db_key);
}

//  Set Addr of signatures By period
DBStatus DBReadWriter::setSignAddrByPeriod(const uint64_t &period, const std::string &addr)
{
    return mergeValue(DatabaseKeys::PEROID_2_SIGN_ADDRESS + std::to_string(period), addr);
}

//  Remove Addr of signatures By period
DBStatus DBReadWriter::removeSignAddrByPeriod(const uint64_t &period, const std::string &addr)
{
    return removeMergeValue(DatabaseKeys::PEROID_2_SIGN_ADDRESS + std::to_string(period), addr);
}

DBStatus DBReadWriter::setBurnAmountByPeriod(const uint64_t &period, const uint64_t &burnAmount)
{
    return writeData(DatabaseKeys::PEROID_2_BURN_AMOUNT + std::to_string(period), std::to_string(burnAmount));
}
DBStatus DBReadWriter::removeBurnAmountByPeriod(const uint64_t &period, const uint64_t &burnAmount)
{
    return deleteData(DatabaseKeys::PEROID_2_BURN_AMOUNT + std::to_string(period));
}

DBStatus DBReadWriter::setTotalBurnAmount(uint64_t &totalBurn)
{
    return writeData(DatabaseKeys::TOTAL_BURN_AMOUNT, std::to_string(totalBurn));
}

// Set the total amount of stake
DBStatus DBReadWriter::setTotalDelegatingAmount(uint64_t &delegatingCount)
{
    return writeData(DatabaseKeys::TOTAL_DELEGATE_AMOUNT, std::to_string(delegatingCount));
}

// Record the version of the program that initialized the database
DBStatus DBReadWriter::setInitVer(const std::string &version)
{
    return writeData(DatabaseKeys::INITIALIZATION_VERSION, version);
}

DBStatus DBReadWriter::setAssetType(const std::string &assetType)
{
    return mergeValue(DatabaseKeys::ASSET_TYPE, assetType);
}

DBStatus DBReadWriter::removeAssetType(const std::string &assetType)
{
    return removeMergeValue(DatabaseKeys::ASSET_TYPE, assetType);
}

//根据交易类型hash添加 撤销交易类型hash KRevokeTxHash
DBStatus DBReadWriter::setRevokeTxHashByAssetType(const std::string &assetType, const std::string revokeTransactionHashValue)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_REVOKE_TX_HASH + assetType;
    return mergeValue(db_key, revokeTransactionHashValue);
}
//根据交易类型hash删除 撤销交易类型hash KRevokeTxHash
DBStatus DBReadWriter::removeRevokeTxHashByAssetType(const std::string &assetType, const std::string revokeTransactionHashValue)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_REVOKE_TX_HASH + assetType;
    return removeMergeValue(db_key, revokeTransactionHashValue);
}

//根据资产类型添加投赞成票的ID
DBStatus DBReadWriter::setApproveAddrsByAssetType(const std::string &assetType, const std::string &addr)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_APPROVE_VOTE_ADDRESS + assetType;
    return mergeValue(db_key, addr);
}

//删除对应资产投赞成票的ID
DBStatus DBReadWriter::removeApproveAddrsByAssetType(const std::string &assetType, const std::string &addr)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_APPROVE_VOTE_ADDRESS + assetType;
    return removeMergeValue(db_key, addr);
}

//根据资产类型添加投反对票的ID
DBStatus DBReadWriter::setAgainstAddrsByAssetType(const std::string &assetType, const std::string &addr)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_AGAINST_VOTE_ADDRESS + assetType;
    return mergeValue(db_key, addr);
}

//删除对应资产投反对票的ID
DBStatus DBReadWriter::removeAgainstAddrsByAssetType(const std::string &assetType, const std::string &addr)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_AGAINST_VOTE_ADDRESS + assetType;
    return removeMergeValue(db_key, addr);
}

DBStatus DBReadWriter::setVoteTxHashByAssetType(const std::string &assetType, const std::string &voteTxHash)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_VOTE_TX_HASH + assetType;
    return mergeValue(db_key, voteTxHash);
}

DBStatus DBReadWriter::removeVoteTxHashByAssetType(const std::string &assetType, const std::string &voteTxHash)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_VOTE_TX_HASH + assetType;
    return removeMergeValue(db_key, voteTxHash);
}

DBStatus DBReadWriter::setProposalInfoByAssetType(const std::string &assetType, const std::string info)
{
    return writeData(DatabaseKeys::ASSET_TYPE_TO_PROPOSAL_INFO + assetType, info);
}
DBStatus DBReadWriter::removeProposalInfoByAssetType(const std::string &assetType)
{
    return deleteData(DatabaseKeys::ASSET_TYPE_TO_PROPOSAL_INFO + assetType);
}

//设置撤销提案类型对应的info  info：提案hash - 投票开始时间 - 投票结束时间
DBStatus DBReadWriter::setRevokeProposalInfoByAssetType(const std::string & assetType, const std::string info)
{
    return writeData(DatabaseKeys::ASSET_TYPE_TO_REVOKE_PROPOSAL_INFO + assetType, info);
}
//删除撤销提案类型对应的info  
DBStatus DBReadWriter::removeRevokeProposalInfoByAssetType(const std::string &assetType)
{
    return deleteData(DatabaseKeys::ASSET_TYPE_TO_REVOKE_PROPOSAL_INFO + assetType);
}

//设置投票信息  赞成票数-反对票数
DBStatus DBReadWriter::setVoteCountByAssetType(const std::string & assetType, const uint64_t & approve, const uint64_t & against)
{
    std::string value = std::to_string(approve) + "_" + std::to_string(against);
    return writeData(DatabaseKeys::ASSET_TYPE_TO_PROPOSAL_VOTE_COUNT + assetType, value);
}

DBStatus DBReadWriter::removeVoteCountByAssetType(const std::string &assetType)
{
    return deleteData(DatabaseKeys::ASSET_TYPE_TO_PROPOSAL_VOTE_COUNT + assetType);
}

DBStatus DBReadWriter::setVoteCountByAddr(const std::string &addr, const std::string& assetType, const uint64_t& voteNum)
{
    return writeData(DatabaseKeys::ADDRESS_TO_VOTE_COUNT + assetType + addr, std::to_string(voteNum));
}

DBStatus DBReadWriter::removeVoteCountByAddr(const std::string &addr, const std::string& assetType)
{
    return deleteData(DatabaseKeys::ADDRESS_TO_VOTE_COUNT + assetType + addr);
}

DBStatus DBReadWriter::setTotalCountByAssetType(const std::string& assetType, const uint64_t& voteNum)
{
    return writeData(DatabaseKeys::ASSET_TYPE_TO_TOTAL_VOTE_COUNT + assetType, std::to_string(voteNum));
}

DBStatus DBReadWriter::removeTotalNumberOfVotersByAssetHash(const std::string& assetType)
{
    return deleteData(DatabaseKeys::ASSET_TYPE_TO_TOTAL_VOTE_COUNT + assetType);
}

DBStatus DBReadWriter::setLockAddr(const std::string &address)
{
    return mergeValue(DatabaseKeys::LOCK_ADDRESS, address);
}

DBStatus DBReadWriter::removeLockAddr(const std::string &address)
{
    return removeMergeValue(DatabaseKeys::LOCK_ADDRESS, address);
}

DBStatus DBReadWriter::setLockAddrUtxo(const std::string &LockAddr,const std::string& assetType ,const std::string &utxo)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_LOCK_UTXOS + LockAddr + assetType;
    return mergeValue(db_key, utxo);
}

DBStatus DBReadWriter::removeLockAddrUtxo(const std::string &LockAddr, const std::string& assetType ,const std::string &utxo)
{
    std::string db_key = DatabaseKeys::ASSET_TYPE_TO_LOCK_UTXOS + LockAddr + assetType;
    return removeMergeValue(db_key, utxo);
}

DBStatus DBReadWriter::setTotalLockedAmonut(const uint64_t& TotalLockedAmount)
{
    return writeData(DatabaseKeys::TOTAL_LOCKED_AMOUNT, std::to_string(TotalLockedAmount));
}

DBStatus DBReadWriter::setTotalLockedAmonutByPeriod(const uint64_t& period, const uint64_t& LockedAmount)
{
    return writeData(DatabaseKeys::PERIOD_TO_TOTAL_LOCKED_AMOUNT + std::to_string(period), std::to_string(LockedAmount));
}

DBStatus DBReadWriter::removeTotalLockedAmonutByPeriod(const uint64_t& period)
{
    return deleteData(DatabaseKeys::PERIOD_TO_TOTAL_LOCKED_AMOUNT + std::to_string(period));
}

//根据地址添加资产类型
DBStatus DBReadWriter::setAssetTypeByAddr(const std::string& addr, const std::string &assetType)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_ASSET_TYPE + addr;
    return mergeValue(db_key, assetType);
}

//根据地址删除资产类型
DBStatus DBReadWriter::removeAssetTypeByAddr(const std::string& addr, const std::string &assetType)
{
    std::string db_key = DatabaseKeys::ADDRESS_TO_ASSET_TYPE + addr;
    return removeMergeValue(db_key, assetType);
}


DBStatus DBReadWriter::setAssetTypeByContractAddr(const std::string& contractAddr, const std::string &assetType)
{
    return writeData(DatabaseKeys::CONTRACT_ADDRESS_TO_ASSET_TYPE + contractAddr, assetType);
}

DBStatus DBReadWriter::removeAssetTypeByContractAddr(const std::string& contractAddr)
{
    return deleteData(DatabaseKeys::CONTRACT_ADDRESS_TO_ASSET_TYPE + contractAddr);
}


DBStatus DBReadWriter::setGasAmountByPeriod(const uint64_t &period, const std::string &type,const uint64_t &gasAmount)
{
    std::string db_key = DatabaseKeys::PERIOD_TO_GAS_AMOUNT + std::to_string(period) + "_" + type;
    return writeData(db_key,std::to_string(gasAmount));
}

DBStatus DBReadWriter::setPackagerCountByPeriod(const uint64_t& period, const std::string& address, const uint64_t& count){
    std::string db_key = DatabaseKeys::PERIOD_TO_PACKAGER_COUNT + std::to_string(period)  + "_" + address;
    return writeData(db_key,std::to_string(count));
}

DBStatus DBReadWriter::transactionRollBack()
{
    if (autoOperationTrans)
    {
        rocksdb::Status ret_status;
        if (!dbReaderWriter.transactionRollBack(ret_status))
        {
            ERRORLOG("transction rollback code:{} info:{}", ret_status.code(), ret_status.ToString());
            return DBStatus::DB_ERROR;
        }
    }
    return DBStatus::DB_SUCCESS;
}

DBStatus DBReadWriter::multiReadData(const std::vector<std::string> &keys, std::vector<std::string> &values)
{
    if (keys.empty())
    {
        return DBStatus::DB_PARAM_NULL;
    }
    std::vector<rocksdb::Slice> db_keys;
    std::vector<std::string> str;
    for(auto t : keys)
    {
        str.push_back(t);
    }

    std::vector<std::string> db_keys_str;
    for (auto key : keys)
    {
        db_keys_str.push_back(key);
        db_keys.push_back(db_keys_str.back());
    }
    std::vector<rocksdb::Status> ret_status;
    if (dbReaderWriter.multiReadData(db_keys, values, ret_status))
    {
        if (db_keys.size() != values.size())
        {
            return DBStatus::DB_ERROR;
        }
        return DBStatus::DB_SUCCESS;
    }
    else
    {
        for (auto status : ret_status)
        {
            if (status.IsNotFound())
            {
                return DBStatus::DB_NOT_FOUND;
            }
        }
    }
    return DBStatus::DB_ERROR;
}

DBStatus DBReadWriter::readData(const std::string &key, std::string &value)
{
    if (key.empty())
    {
        return DBStatus::DB_PARAM_NULL;
    }
    rocksdb::Status ret_status;
    if (dbReaderWriter.readData(key, value, ret_status))
    {
        return DBStatus::DB_SUCCESS;
    }
    else if (ret_status.IsNotFound())
    {
        value.clear();
        return DBStatus::DB_NOT_FOUND;
    }
    return DBStatus::DB_ERROR;
}
DBStatus DBReadWriter::mergeValue(const std::string &key, const std::string &value, bool firstOrLast,const std::string & Delimiter)
{
    rocksdb::Status ret_status;
    if (dbReaderWriter.mergeValue(key, value, ret_status, firstOrLast, Delimiter))
    {
        return DBStatus::DB_SUCCESS;
    }
    return DBStatus::DB_ERROR;
}

DBStatus DBReadWriter::getMergeValue(const std::string &key, std::vector<std::string> &values, const std::string & Delimiter)
{
    rocksdb::Status ret_status;
    if (dbReaderWriter.getMergeValue(key, values, ret_status, Delimiter))
    {
        return DBStatus::DB_SUCCESS;
    }
    return DBStatus::DB_ERROR;
}
DBStatus DBReadWriter::removeMergeValue(const std::string &key, const std::string &value, const std::string & Delimiter)
{
    rocksdb::Status ret_status;
    if (dbReaderWriter.removeMergeValue(key, value, ret_status, Delimiter))
    {
        return DBStatus::DB_SUCCESS;
    }
    return DBStatus::DB_ERROR;
}
DBStatus DBReadWriter::writeData(const std::string &key, const std::string &value)
{
    rocksdb::Status ret_status;
    if (dbReaderWriter.writeData(key, value, ret_status))
    {
        return DBStatus::DB_SUCCESS;
    }
    return DBStatus::DB_ERROR;
}
DBStatus DBReadWriter::deleteData(const std::string &key)
{
    rocksdb::Status ret_status;
    if (dbReaderWriter.deleteData(key, ret_status))
    {
        return DBStatus::DB_SUCCESS;
    }
    return DBStatus::DB_ERROR;
}

// === Slashing read interfaces ===

DBStatus DBReader::hasEvidenceOnChain(const std::string &evidenceHash)
{
    std::string value;
    return readData(DatabaseKeys::EVIDENCE_ON_CHAIN + evidenceHash, value);
}

DBStatus DBReader::getEvidenceOnChain(const std::string &evidenceHash, std::string &targetAddr, std::string &violationType)
{
    std::string value;
    auto ret = readData(DatabaseKeys::EVIDENCE_ON_CHAIN + evidenceHash, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        auto pos = value.find(',');
        if (pos != std::string::npos)
        {
            targetAddr = value.substr(0, pos);
            violationType = value.substr(pos + 1);
        }
        else
        {
            return DBStatus::DB_DESERIALIZATION_FAILED;
        }
    }
    return ret;
}

DBStatus DBReader::getEvidenceCount(const std::string &addr, const std::string &type, int64_t &count)
{
    std::string db_key = DatabaseKeys::EVIDENCE_COUNT + addr + ":" + type;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        try { count = std::stoll(value); }
        catch (...) { return DBStatus::DB_DESERIALIZATION_FAILED; }
    }
    return ret;
}

DBStatus DBReader::getThresholdExceededEntries(std::vector<std::string> &addresses)
{
    std::string value;
    auto ret = readData(DatabaseKeys::EVIDENCE_THRESHOLD_LIST, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", addresses);
    }
    return ret;
}

DBStatus DBReader::getThresholdDetail(const std::string &addr, std::string &level, std::string &violationType, std::string &evidenceRefs)
{
    std::string db_key = DatabaseKeys::EVIDENCE_THRESHOLD + addr;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        std::vector<std::string> fields;
        StringUtil::SplitString(value, ",", fields);
        if (fields.size() >= 3)
        {
            level = fields[0];
            violationType = fields[1];
            evidenceRefs = fields[2];
        }
        else
        {
            return DBStatus::DB_DESERIALIZATION_FAILED;
        }
    }
    return ret;
}

DBStatus DBReader::hasPunishmentHistory(const std::string &punishmentId)
{
    std::string value;
    return readData(DatabaseKeys::PUNISHMENT_HISTORY + punishmentId, value);
}

DBStatus DBReader::getPunishmentHistory(const std::string &punishmentId, std::string &targetAddr, std::string &period, uint32_t &level, std::string &txHash)
{
    std::string value;
    auto ret = readData(DatabaseKeys::PUNISHMENT_HISTORY + punishmentId, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        std::vector<std::string> fields;
        StringUtil::SplitString(value, ",", fields);
        if (fields.size() < 3)
        {
            return DBStatus::DB_DESERIALIZATION_FAILED;
        }
        targetAddr = fields[0];
        period = fields[1];
        try { level = static_cast<uint32_t>(std::stoul(fields[2])); }
        catch (...) { return DBStatus::DB_DESERIALIZATION_FAILED; }
        txHash = fields.size() >= 4 ? fields[3] : "";
    }
    return ret;
}

DBStatus DBReader::getPunishmentHistoryByAddr(const std::string &addr, std::vector<std::string> &punishmentIds)
{
    std::string value;
    auto ret = readData(DatabaseKeys::PUNISHMENT_HISTORY_BY_ADDR + addr, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", punishmentIds);
    }
    return ret;
}

DBStatus DBReader::isTombstoned(const std::string &addr)
{
    std::string value;
    return readData(DatabaseKeys::SLASH_TOMBSTONE + addr, value);
}

DBStatus DBReader::isJailed(const std::string &addr)
{
    std::string value;
    return readData(DatabaseKeys::SLASH_JAIL + addr, value);
}

// === Slashing write interfaces ===

DBStatus DBReadWriter::setEvidenceOnChain(const std::string &evidenceHash, const std::string &targetAddr, const std::string &violationType)
{
    std::string db_key = DatabaseKeys::EVIDENCE_ON_CHAIN + evidenceHash;
    std::string value = targetAddr + "," + violationType;
    return writeData(db_key, value);
}

DBStatus DBReadWriter::removeEvidenceOnChain(const std::string &evidenceHash)
{
    return deleteData(DatabaseKeys::EVIDENCE_ON_CHAIN + evidenceHash);
}

DBStatus DBReadWriter::setEvidenceCount(const std::string &addr, const std::string &type, int64_t count)
{
    std::string db_key = DatabaseKeys::EVIDENCE_COUNT + addr + ":" + type;
    return writeData(db_key, std::to_string(count));
}

DBStatus DBReadWriter::removeEvidenceCount(const std::string &addr, const std::string &type)
{
    std::string db_key = DatabaseKeys::EVIDENCE_COUNT + addr + ":" + type;
    return deleteData(db_key);
}

DBStatus DBReadWriter::addToThresholdExceeded(const std::string &addr, const std::string &level, const std::string &violationType, const std::string &evidenceRefs)
{
    mergeValue(DatabaseKeys::EVIDENCE_THRESHOLD_LIST, addr);
    std::string db_key = DatabaseKeys::EVIDENCE_THRESHOLD + addr;
    std::string value = level + "," + violationType + "," + evidenceRefs;
    return writeData(db_key, value);
}

DBStatus DBReadWriter::removeFromThresholdExceeded(const std::string &addr)
{
    removeMergeValue(DatabaseKeys::EVIDENCE_THRESHOLD_LIST, addr);
    return deleteData(DatabaseKeys::EVIDENCE_THRESHOLD + addr);
}

DBStatus DBReadWriter::setPunishmentHistory(const std::string &punishmentId, const std::string &targetAddr, const std::string &period, uint32_t level, const std::string &txHash)
{
    std::string db_key = DatabaseKeys::PUNISHMENT_HISTORY + punishmentId;
    std::string value = targetAddr + "," + period + "," + std::to_string(level) + "," + txHash;
    auto ret = writeData(db_key, value);
    if (DBStatus::DB_SUCCESS != ret)
    {
        return ret;
    }
    return mergeValue(DatabaseKeys::PUNISHMENT_HISTORY_BY_ADDR + targetAddr, punishmentId);
}

DBStatus DBReadWriter::removePunishmentHistory(const std::string &punishmentId, const std::string &targetAddr)
{
    auto ret = deleteData(DatabaseKeys::PUNISHMENT_HISTORY + punishmentId);
    auto indexRet = removeMergeValue(DatabaseKeys::PUNISHMENT_HISTORY_BY_ADDR + targetAddr, punishmentId);
    return DBStatus::DB_SUCCESS == ret ? indexRet : ret;
}

DBStatus DBReadWriter::setPunishmentDelegationRefunds(const std::string &punishmentId, const std::string &refundSnapshot)
{
    return writeData(DatabaseKeys::PUNISHMENT_DELEGATION_REFUNDS + punishmentId, refundSnapshot);
}

DBStatus DBReadWriter::getPunishmentDelegationRefunds(const std::string &punishmentId, std::string &refundSnapshot)
{
    return readData(DatabaseKeys::PUNISHMENT_DELEGATION_REFUNDS + punishmentId, refundSnapshot);
}

DBStatus DBReadWriter::removePunishmentDelegationRefunds(const std::string &punishmentId)
{
    return deleteData(DatabaseKeys::PUNISHMENT_DELEGATION_REFUNDS + punishmentId);
}

DBStatus DBReadWriter::setJailed(const std::string &addr, const std::string &startPeriod, const std::string &reason, uint32_t level)
{
    std::string db_key = DatabaseKeys::SLASH_JAIL + addr;
    std::string value = startPeriod + "," + reason + "," + std::to_string(level);
    return writeData(db_key, value);
}

DBStatus DBReadWriter::removeJailed(const std::string &addr)
{
    return deleteData(DatabaseKeys::SLASH_JAIL + addr);
}

DBStatus DBReader::getTombstonedAddrs(std::vector<std::string> &addresses)
{
    std::string value;
    auto ret = readData(DatabaseKeys::SLASH_TOMBSTONE_LIST, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        StringUtil::SplitString(value, "_", addresses);
    }
    return ret;
}

DBStatus DBReadWriter::setTombstoned(const std::string &addr, const std::string &reason, const std::string &period, const std::string &evidenceHash)
{
    std::string db_key = DatabaseKeys::SLASH_TOMBSTONE + addr;
    std::string value = reason + "," + period + "," + evidenceHash;
    auto ret = writeData(db_key, value);
    if (DBStatus::DB_SUCCESS != ret)
    {
        return ret;
    }
    return mergeValue(DatabaseKeys::SLASH_TOMBSTONE_LIST, addr);
}

DBStatus DBReadWriter::removeTombstoned(const std::string &addr)
{
    auto ret = deleteData(DatabaseKeys::SLASH_TOMBSTONE + addr);
    auto indexRet = removeMergeValue(DatabaseKeys::SLASH_TOMBSTONE_LIST, addr);
    return DBStatus::DB_SUCCESS == ret ? indexRet : ret;
}

DBStatus DBReadWriter::recordVRFFail(const std::string &addr, uint64_t period)
{
    std::string db_key = DatabaseKeys::SLASH_VRF_FAIL + addr + ":" + std::to_string(period);
    return writeData(db_key, "1");
}

DBStatus DBReadWriter::removeVRFFail(const std::string &addr, uint64_t period)
{
    std::string db_key = DatabaseKeys::SLASH_VRF_FAIL + addr + ":" + std::to_string(period);
    return deleteData(db_key);
}

DBStatus DBReadWriter::setDisconnectCount(const std::string &addr, uint64_t hour, uint32_t count)
{
    std::string db_key = DatabaseKeys::SLASH_DISCONNECT + addr + ":" + std::to_string(hour);
    return writeData(db_key, std::to_string(count));
}

DBStatus DBReadWriter::getDisconnectCount(const std::string &addr, uint64_t hour, uint32_t &count)
{
    std::string db_key = DatabaseKeys::SLASH_DISCONNECT + addr + ":" + std::to_string(hour);
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        try { count = std::stoul(value); }
        catch (...) { return DBStatus::DB_DESERIALIZATION_FAILED; }
    }
    return ret;
}

DBStatus DBReadWriter::recordBlockSign(uint64_t height, const std::string &addr, const std::string &blockHash)
{
    std::string db_key = DatabaseKeys::SLASH_BLOCK_SIGN + std::to_string(height) + ":" + addr;
    return writeData(db_key, blockHash);
}

DBStatus DBReadWriter::getBlockSign(uint64_t height, const std::string &addr, std::string &blockHash)
{
    std::string db_key = DatabaseKeys::SLASH_BLOCK_SIGN + std::to_string(height) + ":" + addr;
    return readData(db_key, blockHash);
}

DBStatus DBReadWriter::writePendingSlashingEvidence(const std::string &key, const std::string &jsonData)
{
    return writeData(key, jsonData);
}

DBStatus DBReadWriter::setLastActivePeriod(const std::string &addr, uint64_t period)
{
    std::string db_key = DatabaseKeys::SLASH_LAST_ACTIVE + addr;
    return writeData(db_key, std::to_string(period));
}

DBStatus DBReadWriter::getLastActivePeriod(const std::string &addr, uint64_t &period)
{
    std::string db_key = DatabaseKeys::SLASH_LAST_ACTIVE + addr;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        try { period = std::stoull(value); }
        catch (...) { return DBStatus::DB_DESERIALIZATION_FAILED; }
    }
    return ret;
}

DBStatus DBReadWriter::setConsecutiveNormal(const std::string &addr, uint32_t count)
{
    std::string db_key = DatabaseKeys::SLASH_CONSECUTIVE_NORMAL + addr;
    return writeData(db_key, std::to_string(count));
}

DBStatus DBReadWriter::getConsecutiveNormal(const std::string &addr, uint32_t &count)
{
    std::string db_key = DatabaseKeys::SLASH_CONSECUTIVE_NORMAL + addr;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        try { count = std::stoul(value); }
        catch (...) { return DBStatus::DB_DESERIALIZATION_FAILED; }
    }
    return ret;
}

DBStatus DBReadWriter::setL3SlashCount(const std::string &addr, uint32_t count)
{
    std::string db_key = DatabaseKeys::SLASH_L3_COUNT + addr;
    return writeData(db_key, std::to_string(count));
}

DBStatus DBReadWriter::removeL3SlashCount(const std::string &addr)
{
    return deleteData(DatabaseKeys::SLASH_L3_COUNT + addr);
}

DBStatus DBReadWriter::getL3SlashCount(const std::string &addr, uint32_t &count)
{
    std::string db_key = DatabaseKeys::SLASH_L3_COUNT + addr;
    std::string value;
    auto ret = readData(db_key, value);
    if (DBStatus::DB_SUCCESS == ret)
    {
        try { count = std::stoul(value); }
        catch (...) { return DBStatus::DB_DESERIALIZATION_FAILED; }
    }
    return ret;
}

DBStatus DBReadWriter::readSlashingData(const std::string &key, std::string &value)
{
    return readData(key, value);
}

DBStatus DBReadWriter::deleteSlashingData(const std::string &key)
{
    return deleteData(key);
}
