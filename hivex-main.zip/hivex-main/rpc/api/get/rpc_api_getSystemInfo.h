﻿#ifndef RPC_API_GETSYSTEMINFO_H
#define RPC_API_GETSYSTEMINFO_H

#include "net/httplib.h"

namespace ohi { namespace rpc{

    void getSystemInfo(const httplib::Request &, httplib::Response &);
    struct NetStat
    {
        unsigned long long bytesReceived;
        unsigned long long bytesSent;
    };
    struct CPUStat
    {
        unsigned long long user;
        unsigned long long nice;
        unsigned long long system;
        unsigned long long idle;
        unsigned long long iowait;
        unsigned long long irq;
        unsigned long long softirq;
    };
    int GetFileLine();
    void GetMemOccupy(int lenNum, std::string &strMem);
    void GetDiskType(std::string &strMem);
    static std::vector<ohi::rpc::CPUStat> GetCpuStats();
    static std::string ConvertDoubleToStringWithPrecision(double value, int precision);
    std::string getCpuInfo();
    static std::string formatSpeed(double speed);
    static std::string GetMacAddress(const std::string &interface);
    static std::string retrieveNetworkModelInfo(const std::string &interface);
    std::string GetNetRate();
    static std::string GetOsVersion();
    std::string Exec(const char *cmd);
    std::string ApiGetSystemInfo();
    std::string ApiTime();
    std::string GetProcessInfo();
    }
}

#endif // RPC_API_GETSYSTEMINFO_H