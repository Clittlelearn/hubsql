﻿#include "rpc_api_getAccount.h"
#include "ca/global.h"
#include "db/db_api.h"

#include "rpc_html.h"
#include "ca/algorithm.h"
#include "include/logging.h"
#include "utils/account_manager.h"
#include "utils/pretty_print.h"

void ohi::rpc::getAccount(const httplib::Request &request, httplib::Response &response)
{
    std::string str = html::begin("Account Information");

    // Account Section
    str += "<div class='main-title'>Account</div>\n";
    str += "<div class='divider'></div>\n";
    
    // The variable used for calculating the total asset amount
    uint64_t totalVoteAssets = 0;
    uint64_t totalOHI = 0;
    
    // Account information statistics
    str += "<div class='task-grid-title'>Account Information</div>\n";
    str += "<table class='data-table'>\n";
    str += "<thead>\n";
    str += "<tr><th>Account Address</th><th>Assets</th></tr>\n";
    str += "</thead>\n<tbody>\n";
    
    std::vector<std::string> baseList;
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(baseList);
    
    if (baseList.empty()) {
        // If there is no account, display a prompt message.
        str += "<tr><td colspan='2' style='text-align:center;'>No account data available</td></tr>\n";
    } else {
        // Display all account information
        for (auto &i : baseList) {
            int64_t voteAmount = 0;
            int64_t ohiAmount = 0;
            
            std::string assetType;
            int ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
            if(ret != 0){
                ERRORLOG("Get Can BeRevoke AssetType fail!");
            }

            DBReader dbReader;
            dbReader.getBalanceByAddr(i, global::ca::ASSET_TYPE_OHI, voteAmount);
            double v = voteAmount / double(100000000);
            dbReader.getBalanceByAddr(i, assetType, ohiAmount);
            double m = ohiAmount / double(100000000);

            uint64_t blockHeight = 0;
            dbReader.getBlockTop(blockHeight);

            totalVoteAssets += voteAmount;
            totalOHI += ohiAmount;

             
            str += "<tr>";
            str += "<td><span style='font-family:monospace;'>0x" + i + "</span></td>";
            str += "<td>\n";
            str += "  <div style='display:flex; flex-direction:column; gap:8px;'>\n";
            str += "    <div><span style='color:#00C853; font-weight:500;'>Vote Assets:</span> " + std::to_string(v) + "</div>\n";
            str += "    <div><span style='color:#00C853; font-weight:500;'>OHI Balance:</span> " + std::to_string(m) + "</div>\n";
            // More asset types can be added here.
            // str += "    <div><span style='color:#00C853; font-weight:500;'>Asset Type X:</span> value</div>\n";
            // str += "    <div><span style='color:#00C853; font-weight:500;'>Asset Type Y:</span> value</div>\n";
            str += "  </div>\n";
            str += "</td>";
            str += "</tr>\n";
        }
    }
    
    str += "</tbody></table>\n";
    
    // Account statistics information
    str += "<div class='system-info' style='margin-top: 15px;'>\n";
    str += "  <div class='info-row'>\n";
    str += "    <div class='info-label'>Total Accounts:</div>\n";
    str += "    <div class='info-value'>" + std::to_string(baseList.size()) + "</div>\n";
    str += "  </div>\n";
    str += "</div>\n";
    
    str += html::end();
    response.set_content(str, "text/html; charset=utf-8");
}
