﻿#ifndef RPC_API_GETBLOCKREQUEST_H
#define RPC_API_GETBLOCKREQUEST_H

#include "net/httplib.h"

namespace ohi { namespace rpc{
        void getBlockRequest(const httplib::Request &request, httplib::Response &response);
}}

#endif // RPC_API_GETBLOCKREQUEST_H