﻿#include "rpc_api_getNode.h"
#include "net/node.hpp"
#include "utils/magic_singleton.h"
#include "net/peer_node.h"
#include "rpc_html.h"
void ohi::rpc::getNode(const httplib::Request &request, httplib::Response &response)
{
    std::vector<Node> pubNodeList_ = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    std::string str = html::begin("Node List");
    str += "<div class='divider'></div>\n";
    str += "<div style='margin-left:60px;margin-top:10px;font-size:16px;'>Public PeerNode size is:" + std::to_string(pubNodeList_.size()) + "</div>\n";
    str += "<table class='node-table'>\n<thead><tr>";
    str += "<th>Addr</th><th>Ip</th><th>Height</th><th>Port</th><th>Kind</th><th>Fd</th><th>Pulse</th><th>Version</th>";
    str += "</tr></thead>\n<tbody>\n";
    for (const auto &node : pubNodeList_)
    {
        str += "<tr>";
        str += "<td class='addr'>0x" + node.address + "</td>";
        str += "<td>" + std::string(IpPort::IpSz(node.publicIp)) + "</td>";
        str += "<td>" + std::to_string(node.height) + "</td>";
        str += "<td>" + std::to_string(node.publicPort) + "</td>";
        str += "<td>" + std::to_string(node.connKind) + "</td>";
        str += "<td>" + std::to_string(node.fd) + "</td>";
        str += "<td>" + std::to_string(node.pulse) + "</td>";
        str += "<td>" + node.ver + "</td>";
        str += "</tr>\n";
    }
    str += "</tbody></table>\n";
    str += html::end();
    response.set_content(str, "text/html; charset=utf-8");
}