﻿#ifndef RPC_API_GETACCOUNT_H
#define RPC_API_GETACCOUNT_H

#include "net/httplib.h"

namespace ohi { namespace rpc{

    void getAccount(const httplib::Request &, httplib::Response &);

}}

#endif // RPC_API_GETACCOUNT_H