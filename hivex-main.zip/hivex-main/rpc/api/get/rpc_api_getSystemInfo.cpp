﻿#include "rpc_api_getSystemInfo.h"
#include <iomanip>
#include <sys/ioctl.h>
#include <net/if.h>
#include <bits/ioctls.h>
#include <sys/utsname.h>
int ohi::rpc::GetFileLine()
{
    FILE *fp;
    int flag = 0, count = 0;
    if ((fp = fopen("/proc/meminfo", "r")) == NULL)
        return -1;
    while (!feof(fp))
    {
        flag = fgetc(fp);
        if (flag == '\n')
            count++;
    }
    fclose(fp);
    return count;
}

void ohi::rpc::GetMemOccupy(int lenNum, std::string &strMem)
{
    strMem = "";
    FILE *memInfo = fopen("/proc/meminfo", "r");
    if (NULL == memInfo)
    {
        strMem = "-1 meminfo fopen error";
     
       return;
    }

    int i = 0;
    int value = 0;
    char name[512];
    char line[512];
    int fieldNumber = 2;
    int total = 0;
    int available = 0;
    while (fgets(line, sizeof(line) - 1, memInfo))
    {
        if (sscanf(line, "%s%u", name, &value) != fieldNumber)
        {
            continue;
        }
        if (0 == strcmp(name, "MemTotal:"))
        {
            total = value;
            strMem += "MemTotal:\t" + std::to_string(value) + '\n';
        }
        else if (0 == strcmp(name, "MemFree:"))
        {
            strMem += "MemFree:\t" + std::to_string(value) + '\n';
        }
        else if (0 == strcmp(name, "MemAvailable:"))
        {
            available = value;
            strMem += "MemAvailable:\t" + std::to_string(value) + '\n';
        }
        else if (0 == strcmp(name, "Buffers:"))
        {
            strMem += "MemBuffers:\t" + std::to_string(value) + '\n';
        }
        else if (0 == strcmp(name, "Cached:"))
        {
            strMem += "MemCached:\t" + std::to_string(value) + '\n';
        }
        else if (0 == strcmp(name, "SwapCached:"))
        {
            strMem += "SwapCached:\t" + std::to_string(value) + '\n';
        }
        else if (0 == strcmp(name, "SwapTotal:"))
        {
            strMem += "SwapTotal:\t" + std::to_string(value) + '\n';
        }
        else if (0 == strcmp(name, "SwapFree:"))
        {
            strMem += "SwapFree:\t" + std::to_string(value) + '\n';
        }

        if (++i == lenNum)
        {
            break;
        }
    }
    strMem += "Memory usage:\t" +
              std::to_string(100.0 * (total - available) / total) + "%\n";
    fclose(memInfo);
}

void ohi::rpc::GetDiskType(std::string &strMem)
{
    std::ifstream rotational("/sys/block/sda/queue/rotational");
    if (rotational.is_open())
    {
        int isRotational;
        rotational >> isRotational;
        strMem += "Disk type:\t";
        strMem += (isRotational ? "HDD" : "SSD");
        rotational.close();
    }
    else
    {
        strMem += "-1 Disk rotational open error";
    }
}

static std::vector<ohi::rpc::CPUStat> ohi::rpc::GetCpuStats()
{
    std::vector<ohi::rpc::CPUStat> cpuStats;
    std::ifstream statFile("/proc/stat");

    std::string line;
    while (std::getline(statFile, line))
    {
        if (line.compare(0, 3, "cpu") == 0)
        {
            std::istringstream ss(line);

            std::string cpuLabel;
            ohi::rpc::CPUStat stat;
            ss >> cpuLabel >> stat.user >> stat.nice >> stat.system >>
                stat.idle >> stat.iowait >> stat.irq >> stat.softirq;

            cpuStats.push_back(stat);
        }
    }

    return cpuStats;
}

static double CalculateCpuUsage(const ohi::rpc::CPUStat &prev, const ohi::rpc::CPUStat &curr)
{
    auto prevTotal = prev.user + prev.nice + prev.system + prev.idle +
                     prev.iowait + prev.irq + prev.softirq;
    auto currTotal = curr.user + curr.nice + curr.system + curr.idle +
                     curr.iowait + curr.irq + curr.softirq;

    auto totalDiff = currTotal - prevTotal;
    auto idleDiff = curr.idle - prev.idle;

    return (totalDiff - idleDiff) * 100.0 / totalDiff;
}

static std::string ohi::rpc::ConvertDoubleToStringWithPrecision(double value, int precision)
{
    std::ostringstream out;
    out << std::fixed << std::setprecision(precision) << value;
    return out.str();
}

std::string ohi::rpc::getCpuInfo()
{
    std::string sum;
    sum =
        "======================================================================"
        "=========";
    sum += "\n";
    sum += "get_cpu_info";
    sum += "\n";
    std::ifstream cpuinfoFile("/proc/cpuinfo");
    std::string line;
    int cpuCores = 0;
    std::string cpuModel;
    double cpuFrequency = 0;

    while (std::getline(cpuinfoFile, line))
    {
        if (line.compare(0, 9, "processor") == 0)
        {
            cpuCores++;
        }
        else if (line.compare(0, 10, "model name") == 0)
        {
            cpuModel = line.substr(line.find(":") + 2);
        }
        else if (line.compare(0, 7, "cpu MHz") == 0)
        {
            cpuFrequency = std::stod(line.substr(line.find(":") + 2)) / 1000;
        }
    }

    auto prevStats = GetCpuStats();

    std::this_thread::sleep_for(std::chrono::seconds(1));
    auto currStats = GetCpuStats();

    double totalUsage = 0;
    for (size_t i = 1; i < prevStats.size(); ++i)
    {
        totalUsage += CalculateCpuUsage(prevStats[i], currStats[i]);
    }

    double avgUsage = totalUsage / (prevStats.size() - 1);
    sum +=
        "CPU Usage: " + ConvertDoubleToStringWithPrecision(avgUsage, 1) + "%" + "\n";
    sum += "CPU Frequency: " + ConvertDoubleToStringWithPrecision(cpuFrequency, 3) +
           " GHZ" + "\n";
    sum += "CPU Model: " + cpuModel + "\n";
    sum += "CPU Cores: " + std::to_string(cpuCores);
    return sum;
}

static ohi::rpc::NetStat GetNetStat(const std::string &interface)
{
    ohi::rpc::NetStat netStat = {0, 0};
    std::ifstream netDevFile("/proc/net/dev");
    std::string line;

    while (std::getline(netDevFile, line))
    {
        if (line.find(interface) != std::string::npos)
        {
            std::istringstream ss(line);
            std::string iface;
            ss >> iface >> netStat.bytesReceived;

            for (int i = 0; i < 7; ++i)
            {
                unsigned long long tmp;
                ss >> tmp;
            }

            ss >> netStat.bytesSent;
            break;
        }
    }

    return netStat;
}

static std::string ohi::rpc::formatSpeed(double speed)
{
    std::stringstream ss;
    ss << std::fixed << std::setprecision(2) << speed << " Mbps";
    return ss.str();
}

static std::string ohi::rpc::GetMacAddress(const std::string &interface)
{
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0)
    {
        return "";
    }

    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, interface.c_str(), IFNAMSIZ - 1);

    if (ioctl(sock, SIOCGIFHWADDR, &ifr) < 0)
    {
        close(sock);
        return "";
    }

    close(sock);
    char macAddress[18];
    snprintf(macAddress, sizeof(macAddress), "%02x:%02x:%02x:%02x:%02x:%02x",
             static_cast<unsigned char>(ifr.ifr_hwaddr.sa_data[0]),
             static_cast<unsigned char>(ifr.ifr_hwaddr.sa_data[1]),
             static_cast<unsigned char>(ifr.ifr_hwaddr.sa_data[2]),
             static_cast<unsigned char>(ifr.ifr_hwaddr.sa_data[3]),
             static_cast<unsigned char>(ifr.ifr_hwaddr.sa_data[4]),
             static_cast<unsigned char>(ifr.ifr_hwaddr.sa_data[5]));

    return macAddress;
}


static std::string ohi::rpc::retrieveNetworkModelInfo(const std::string &interface)
{
    std::string modelPath = "/sys/class/net/" + interface + "/device/modalias";
    std::ifstream modelFile(modelPath);
    if (!modelFile.is_open())
    {
        return "";
    }

    std::string modelInfo;
    std::getline(modelFile, modelInfo);
    modelFile.close();

    return modelInfo;
}

std::string ohi::rpc::GetNetRate()
{
    std::string interface = "eth0";
    auto prevStat = GetNetStat(interface);
    std::string str;
    str =
        "======================================================================"
        "=========";
    str += "\n";
    str += "GetNetRate";
    str += "\n";
    std::this_thread::sleep_for(std::chrono::seconds(1));
    auto currStat = GetNetStat(interface);

    double downloadSpeed =
        (currStat.bytesReceived - prevStat.bytesReceived) * 8 / 1000.0 /
        1000.0;
    double uploadSpeed =
        (currStat.bytesSent - prevStat.bytesSent) * 8 / 1000.0 / 1000.0;

    std::string downloadSpeedStr = ohi::rpc::formatSpeed(downloadSpeed);
    std::string uploadSpeedStr = ohi::rpc::formatSpeed(uploadSpeed);

    str += "Download speed: " + downloadSpeedStr + "\n";
    str += "Upload speed: " + uploadSpeedStr + "\n";
    str += "Interface: " + interface + "\n";
    str += "MAC Address: " + ohi::rpc::GetMacAddress(interface);
    str += "Model Info: " + ohi::rpc::retrieveNetworkModelInfo(interface);
    prevStat = currStat;
    return str;
}

std::string ohi::rpc::Exec(const char *cmd)
{
    char buffer[128];
    std::string result = "";
    FILE *pipe = popen(cmd, "r");
    if (!pipe)
        throw std::runtime_error("popen() failed!");
    try
    {
        while (fgets(buffer, sizeof(buffer), pipe) != NULL)
        {
            result += buffer;
        }
    }
    catch (...)
    {
        pclose(pipe);
        throw;
    }
    pclose(pipe);
    return result;
}
static std::string ohi::rpc::GetOsVersion()
{
    struct utsname buffer;
    std::string osRelease = Exec("cat /etc/os-release");
    std::string str;
    if (uname(&buffer) != 0)
    {
        return "Error getting OS version";
    }
    str = std::string(buffer.sysname) + " " + std::string(buffer.release) +
          " " + std::string(buffer.version);
    str += osRelease;
    return str;
}

std::string ohi::rpc::ApiGetSystemInfo()
{
    std::string str;
    str =
        "======================================================================"
        "=========";
    str += "\n";
    str += "ApiGetSystemInfo";
    str += "\n";
    str += "OS Version: " + ohi::rpc::GetOsVersion() + "\n";
    return str;
}

std::string ohi::rpc::ApiTime()
{
    std::string str;
    auto now = std::time(0);
    str += std::ctime(&now);
    auto now1 = std::chrono::system_clock::now();
    auto nowUs = std::chrono::duration_cast<std::chrono::microseconds>(now1.time_since_epoch()).count();
    auto stamp = std::to_string(nowUs);
    str += stamp + "\n";

    addrinfo hints;
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_flags = AI_PASSIVE;

    addrinfo *result;
    getaddrinfo(NULL, "0", &hints, &result);

    auto timeMs = std::chrono::duration_cast<std::chrono::microseconds>(
                      std::chrono::system_clock::now().time_since_epoch())
                      .count();
    std::string netTime = std::to_string(timeMs);
    str += netTime + "\n";

    if (timeMs > 1000 + nowUs)
    {
        std::string cache = std::to_string(timeMs - nowUs);
        str += cache + "microsecond" + "slow" + "\n";
    }

    if (nowUs > 1000 + timeMs)
    {
        std::string cache = std::to_string(timeMs - nowUs);
        str += cache + "microsecond" + "fast" + "\n";
    }
    else
    {
        str += "normal";
        str += "\n";
    }
    str += "time check======================";
    str += "\n";
    return str;
}

std::string ohi::rpc::GetProcessInfo()
{
    const int BUFFER_SIZE = 1024;

    std::string str;
    str =
        "======================================================================"
        "=========";
    str += "\n";
    str += "GetProcessInfo";
    str += "\n";

    FILE *pipe = popen("ps -ef", "r");
    if (!pipe)
    {

        return "-1";
    }

    char buffer[BUFFER_SIZE];
    while (fgets(buffer, BUFFER_SIZE, pipe))
    {

        str += buffer;
        str += "\n";
    }
    pclose(pipe);
    return str;
}

void ohi::rpc::getSystemInfo(const httplib::Request &request, httplib::Response &response)
{
    std::string outPut;
    std::string MemStr;
    int lenNum = GetFileLine();
    GetMemOccupy(lenNum, MemStr);
    GetDiskType(MemStr);
    outPut =
        "=================================================================="
        "=============";
    outPut += "\n";
    outPut += "GetMemOccupy";
    outPut += MemStr;
    outPut += "\n";

    outPut += ohi::rpc::getCpuInfo() + "\n";
    outPut += ohi::rpc::GetNetRate() + "\n";
    outPut += ohi::rpc::ApiGetSystemInfo() + "\n";
    outPut += ohi::rpc::ApiTime() + "\n";
    outPut += ohi::rpc::GetProcessInfo() + "\n";

    response.set_content(outPut, "text/plain");
    
}

