﻿#include "rpc_api_getBlockRateProbeResults.h"

#include <sstream>
#include "ca/block_rate_probe.h"
#include "utils/magic_singleton.h"
#include "utils/time_util.h"

void ohi::rpc::getBlockRateProbeResults(const httplib::Request &request, httplib::Response &response)
{
    std::ostringstream oss;
    oss << "=== Block Rate Probe Results ===" << std::endl;
    oss << "Time: " << MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp() << std::endl;

    std::vector<ProbeResult> results;
    MagicSingleton<BlockRateProbe>::GetInstance()->GetAllResults(results);

    oss << "Total records: " << results.size() << std::endl;
    oss << "----------------------------------------" << std::endl;

    if (results.empty())
    {
        oss << "(no probe records)" << std::endl;
    }
    else
    {
        for (size_t idx = 0; idx < results.size(); ++idx)
        {
            const auto& r = results[idx];
            oss << "[" << (idx + 1) << "] Hash: " << r.hash << std::endl;
            oss << "    Create Time: " << r.create_time << std::endl;
            oss << "    Confirmed: " << (r.confirmed ? "YES" : "NO") << std::endl;
            oss << "    Probe Count: " << r.probe_count << std::endl;
            oss << "    Rates: ";
            for (size_t i = 0; i < r.rates.size(); ++i)
            {
                if (i > 0) oss << " -> ";
                char buf[32];
                snprintf(buf, sizeof(buf), "%.1f%%", r.rates[i] * 100.0);
                oss << buf;
            }
            if (r.rates.empty())
            {
                oss << "(pending)";
            }
            oss << std::endl;
            oss << "----------------------------------------" << std::endl;
        }
    }

    response.set_content(oss.str(), "text/plain; charset=utf-8");
}
