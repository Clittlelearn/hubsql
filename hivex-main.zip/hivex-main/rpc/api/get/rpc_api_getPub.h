﻿#ifndef RPC_API_GETPUB_H
#define RPC_API_GETPUB_H

#include "net/httplib.h"

namespace ohi { namespace rpc{

        void getPub(const httplib::Request &request, httplib::Response &response);
}}

#endif // RPC_API_GETPUB_H