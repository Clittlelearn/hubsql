﻿#ifndef RPC_API_GETASSETTYPE_H
#define RPC_API_GETASSETTYPE_H

#include "net/httplib.h"

namespace ohi { namespace rpc{

    void getAssetType(const httplib::Request &, httplib::Response &);

}}

#endif // RPC_API_GETASSETTYPE_H