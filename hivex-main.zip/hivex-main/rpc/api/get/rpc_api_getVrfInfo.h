﻿#ifndef RPC_API_GETVRFINFO_H
#define RPC_API_GETVRFINFO_H

#include "net/httplib.h"

namespace ohi { namespace rpc{

    void getVrfInfo(const httplib::Request &, httplib::Response &);

}}
    
#endif // RPC_API_GETVRFINFO_H