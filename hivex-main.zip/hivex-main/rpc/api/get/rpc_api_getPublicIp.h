﻿#ifndef RPC_API_GETPUBLICIP_H
#define RPC_API_GETPUBLICIP_H

#include "net/httplib.h"

namespace ohi { namespace rpc{

    void getPublicIp(const httplib::Request &, httplib::Response &);

}}

#endif // RPC_API_GETPUBLICIP_H