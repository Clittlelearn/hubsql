﻿#include "rpc_api_getNewVrfInfo.h"
#include "ca/vrf_consensus.h"
void ohi::rpc::getNewVrfInfo(const httplib::Request &request, httplib::Response &response)
{
    std::string content = MagicSingleton<VRFConsensusNode>::GetInstance()->printfNewValidatedVRfs();

    response.set_content(content, "text/plain");
}