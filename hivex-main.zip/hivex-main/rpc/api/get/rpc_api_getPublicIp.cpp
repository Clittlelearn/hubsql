﻿#include "rpc_api_getPublicIp.h"

void ohi::rpc::getPublicIp(const httplib::Request &request, httplib::Response &response)
{   
    //add in parse
    std::ostringstream oss;
    std::string ip = request.remote_addr;
    oss << ip;
    response.set_content(oss.str(), "application/json");
}
