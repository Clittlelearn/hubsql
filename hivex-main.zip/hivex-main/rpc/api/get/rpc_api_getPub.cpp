﻿#include "rpc_api_getPub.h"
#include "rpc_html.h"
#include "net/global.h"
#include "utils/magic_singleton.h"
#include "net/dispatcher.h"
void ohi::rpc::getPub(const httplib::Request &request, httplib::Response &response)
{
    std::string str;
    str = html::begin("Thread and Request Statistics");

    // Thread Section
    str += "<div class='main-title'>Thread</div>\n";
    str += "<div class='divider'></div>\n";

    // Get file information
    const int MaxInformationSize = 256;
    char buff[MaxInformationSize] = {};
    std::string fileName = "Unknown";
    FILE *f = fopen("/proc/self/cmdline", "r");
    if (f != NULL)
    {
        char readc;
        int i = 0;
        while (((readc = fgetc(f)) != EOF))
        {
            if (readc == '\0')
            {
                buff[i++] = ' ';
            }
            else
            {
                buff[i++] = readc;
            }
        }
        fclose(f);
        fileName = strtok(buff, "\n");
    }

    // Show program information card
    str += "<div class='system-info'>\n";
    str += "  <div class='info-row'>\n";
    str += "    <div class='info-label'>Program Name:</div>\n";
    str += "    <div class='info-value'>" + fileName + "</div>\n";
    str += "  </div>\n";
    str += "</div>\n";

    // Obtain thread task information
    std::ostringstream taskOss;
    MagicSingleton<ProtobufDispatcher>::GetInstance()->TaskInfo(taskOss);
    std::string taskInfo = taskOss.str();

    // Handle queue information
    std::vector<std::pair<std::string, size_t>> queueInfos = {
        {"Read Queue", global::queueReader.msgQueue.size()},
        {"Work Queue", global::queue_work.msgQueue.size()},
        {"Write Queue", global::queue_write_counter.msgQueue.size()}};

    // Create a task card grid
    str += "<div class='task-grid-title'>Thread Task Statistics</div>\n";
    str += "<div class='task-grid'>\n";

    // Store data of different task categories
    std::map<std::string, std::vector<std::pair<std::string, std::string>>> taskGroups;

    // Analyze the task information and group them accordingly
    std::istringstream taskStream(taskInfo);
    std::string line;
    std::string currentCategory = "";

    while (std::getline(taskStream, line))
    {
        if (line.empty() || line.find("===") != std::string::npos)
        {
            continue; // Remove delimiters and blank lines
        }

        // Extract the task name and value from the row.
        size_t colonPos = line.find(":");
        if (colonPos != std::string::npos)
        {
            std::string taskName = line.substr(0, colonPos);
            std::string taskValue = line.substr(colonPos + 1);

            // Extract the task category (such as ca, net, broadcast, etc.)
            size_t underscorePos = taskName.find("_");
            if (underscorePos != std::string::npos)
            {
                std::string category = taskName.substr(0, underscorePos);

                // Determine the task type (active or pending)
                std::string taskType;
                if (taskName.find("active") != std::string::npos)
                {
                    taskType = "Active Tasks";
                }
                else if (taskName.find("pending") != std::string::npos)
                {
                    taskType = "Pending Tasks";
                }
                else
                {
                    taskType = "Other";
                }

                // Add the task to the corresponding group
                taskGroups[category].push_back({taskType, taskValue});
            }
        }
    }

    // Generate module task cards
    for (const auto &group : taskGroups)
    {
        str += "<div class='task-card'>\n";
        str += "  <div class='task-title'>" + group.first + " Module</div>\n";

        for (const auto &task : group.second)
        {
            str += "  <div class='task-value'>";
            str += task.first + ": ";
            if (task.second == "0")
            {
                str += "<span class='task-zero'>" + task.second + "</span>";
            }
            else
            {
                str += "<strong>" + task.second + "</strong>";
            }
            str += "</div>\n";
        }

        str += "</div>\n";
    }

    // Add queue status card
    str += "<div class='task-card'>\n";
    str += "  <div class='task-title'>Queue Status</div>\n";

    for (const auto &queue : queueInfos)
    {
        str += "  <div class='task-value'>";
        str += queue.first + ": ";
        if (queue.second == 0)
        {
            str += "<span class='task-zero'>" + std::to_string(queue.second) + "</span>";
        }
        else
        {
            str += "<strong>" + std::to_string(queue.second) + "</strong>";
        }
        str += "</div>\n";
    }

    str += "</div>\n";
    str += "</div>\n"; // close task-grid

    // Request section
    str += "<div class='main-title'>Request</div>\n";
    str += "<div class='divider'></div>\n";

    // Add table titles and headers
    str += "<div class='task-grid-title'>Request Statistics</div>\n";
    str += "<table class='data-table'>\n";
    str += "<thead>\n";
    str += "<tr><th>Request Type</th><th>Count</th><th>Data Size</th></tr>\n";
    str += "</thead>\n<tbody>\n";

    double total = .0f;
    uint64_t n64Count = 0;

    for (auto &item : global::requestCountMap)
    {
        total += (double)item.second.second; // data size
        str += "<tr>";
        str += "<td>" + item.first + "</td>";
        str += "<td>" + std::to_string(item.second.first) + "</td>";

        std::ostringstream sizeStream;
        sizeStream.precision(3);
        sizeStream << (double)item.second.second / 1024 / 1024 << " MB";
        str += "<td>" + sizeStream.str() + "</td>";
        str += "</tr>\n";

        n64Count += item.second.first;
    }
    str += "</tbody></table>\n";

    // Display total information
    str += "<div class='system-info' style='margin-top: 15px;'>\n";
    str += "  <div class='info-row'>\n";
    str += "    <div class='info-label'>Total Requests:</div>\n";
    str += "    <div class='info-value'>" + std::to_string(n64Count) + "</div>\n";
    str += "  </div>\n";
    str += "  <div class='info-row'>\n";
    str += "    <div class='info-label'>Total Data Size:</div>\n";

    std::ostringstream totalSizeStream;
    totalSizeStream.precision(3);
    totalSizeStream << (double)total / 1024 / 1024 << " MB";

    str += "    <div class='info-value'>" + totalSizeStream.str() + "</div>\n";
    str += "  </div>\n";
    str += "</div>\n";

    str += html::end();
    response.set_content(str, "text/html; charset=utf-8");
}