﻿#include "rpc_api_getVrfInfo.h"
#include "ca/vrf_consensus.h"
void ohi::rpc::getVrfInfo(const httplib::Request &request , httplib::Response &response)
{
    std::string content = MagicSingleton<VRFConsensusNode>::GetInstance()->printfValidatedVRfs();

    response.set_content(content, "text/plain");
}