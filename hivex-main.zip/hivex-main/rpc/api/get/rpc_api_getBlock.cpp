﻿#include "rpc_api_getBlock.h"
#include "ca/global.h"
#include "db/db_api.h"
#include "rpc_html.h"
#include "utils/pretty_print.h"

void ohi::rpc::getBlock(const httplib::Request &request, httplib::Response &response)
{
    int num = 100;
    if (request.has_param("num"))
    {
        num = atol(request.get_param_value("num").c_str());
    }
    int startNum = 0;
    if (request.has_param("height"))
    {
        startNum = atol(request.get_param_value("height").c_str());
    }
    int hash = 0;
    if (request.has_param("hash"))
    {
        hash = atol(request.get_param_value("hash").c_str());
    }

    std::string str;
    bool html_format = request.has_param("html") && request.get_param_value("html") == "true";

    if (html_format)
    {
        str = html::begin("Block List");
        str += "<table class='block-table'>\n<thead><tr><th style='width:120px;'>Height</th><th></th><th>Block Hash</th></tr></thead>\n<tbody>\n";

        DBReader dbReader;
        uint64_t top = 0;
        if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
        {
            str += "<tr><td colspan='3'>Get block height failed</td></tr>\n";
        }
        else
        {
            int count = 0;
            for (uint64_t i = top; i > 0 && count < num; i--)
            {
                std::vector<std::string> blockHashs;
                if (dbReader.getBlockHashsByBlockHeight(i, blockHashs) != DBStatus::DB_SUCCESS)
                {
                    continue;
                }
                if (blockHashs.empty())
                {
                    continue;
                }
                str += "<tr>";
                str += "<td class='height'>" + std::to_string(i) + "</td>";
                str += "<td><span class='vline'></span></td>";
                str += "<td>";
                for (size_t j = 0; j < blockHashs.size(); ++j)
                {
                    std::string strHeader;
                    if (dbReader.getBlockByBlockHash(blockHashs[j], strHeader) != DBStatus::DB_SUCCESS)
                    {
                        continue;
                    }
                    CBlock block;
                    if (!block.ParseFromString(strHeader))
                    {
                        continue;
                    }
                    // Determine if contract block
                    bool isContractualBlock = false;
                    for (const auto &tx : block.txs())
                    {
                        if ((global::ca::TxType)tx.type() == global::ca::TxType::DEPLOY ||
                            (global::ca::TxType)tx.type() == global::ca::TxType::CALL)
                        {
                            isContractualBlock = true;
                            break;
                        }
                    }
                    std::string colorClass = isContractualBlock ? "blue" : "green";
                    str += "<span class='blockhash " + colorClass + "'>" + blockHashs[j].substr(0, 8) + "</span> ";
                }
                str += "</td></tr>\n";
                count++;
                if (count >= num)
                {
                    break;
                }
            }
        }
        str += "</tbody></table>\n";
        str += html::end();
        response.set_content(str, "text/html; charset=utf-8");
        return;
    }

    DBReader dbReader;

    if (hash)
    {
        if (html_format)
        {
            // print_blocks_hash's HTML version
            uint64_t top = 0;
            if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
            {
                str += "<tr><td colspan='2' class='error'>Get block height failed</td></tr>\n";
            }
            else
            {
                int count = 0;
                for (uint64_t i = top; i > 0 && count < num; i--)
                {
                    std::vector<std::string> blockHashs;
                    if (dbReader.getBlockHashsByBlockHeight(i, blockHashs) != DBStatus::DB_SUCCESS)
                    {
                        continue;
                    }

                    if (blockHashs.empty())
                    {
                        continue;
                    }

                    // Add height cell when displaying the first block hash of each height
                    str += "<tr>\n";
                    str += "<td class='height-cell'>" + std::to_string(i) + "</td>\n";
                    str += "<td><div class='hash-container'>";

                    for (const auto &blockHash : blockHashs)
                    {
                        std::string strHeader;
                        bool isContractualBlock = false;

                        if (dbReader.getBlockByBlockHash(blockHash, strHeader) == DBStatus::DB_SUCCESS)
                        {
                            CBlock block;
                            if (block.ParseFromString(strHeader))
                            {
                                for (const auto &tx : block.txs())
                                {
                                    if ((global::ca::TxType)tx.type() == global::ca::TxType::DEPLOY ||
                                        (global::ca::TxType)tx.type() == global::ca::TxType::CALL)
                                    {
                                        isContractualBlock = true;
                                        break;
                                    }
                                }

                                str += "<span class='hash-cell ";
                                str += (isContractualBlock ? "contract-block" : "normal-block");
                                str += "'>" + blockHash.substr(0, 8) + "</span>";

                                if (request.has_param("pre_hash_flag"))
                                {
                                    str += "<span class='hash-cell'>(" + block.prevhash().substr(0, 8) + ")</span>";
                                }
                            }
                        }
                    }

                    str += "</div></td>\n";
                    str += "</tr>\n";

                    count++;
                    if (count >= num)
                    {
                        break;
                    }
                }
            }

            str += "</tbody>\n</table>\n</div>\n</body>\n</html>";
            response.set_content(str, "text/html; charset=utf-8");
        }
        else
        {
            str = print_blocks_hash(num, request.has_param("pre_hash_flag"));
            response.set_content(str, "text/plain");
        }
        return;
    }

    if (startNum == 0)
    {
        if (html_format)
        {
            // DisplayContractSections's HTML version
            uint64_t top = 0;
            if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
            {
                str += "<tr><td colspan='2' class='error'>Get block height failed</td></tr>\n";
            }
            else
            {
                int count = 0;
                for (uint64_t i = top; i > 0 && count < num; i--)
                {
                    std::vector<std::string> blockHashs;
                    if (dbReader.getBlockHashsByBlockHeight(i, blockHashs) != DBStatus::DB_SUCCESS)
                    {
                        continue;
                    }

                    if (blockHashs.empty())
                    {
                        continue;
                    }

                    // Add height cell when displaying the first block hash of each height
                    str += "<tr>\n";
                    str += "<td class='height-cell'>" + std::to_string(i) + "</td>\n";
                    str += "<td><div class='hash-container'>";

                    for (const auto &blockHash : blockHashs)
                    {
                        std::string strHeader;
                        if (dbReader.getBlockByBlockHash(blockHash, strHeader) != DBStatus::DB_SUCCESS)
                        {
                            continue;
                        }

                        CBlock block;
                        if (!block.ParseFromString(strHeader))
                        {
                            continue;
                        }

                        bool isContractualBlock = false;
                        for (const auto &tx : block.txs())
                        {
                            if ((global::ca::TxType)tx.type() == global::ca::TxType::DEPLOY ||
                                (global::ca::TxType)tx.type() == global::ca::TxType::CALL)
                            {
                                isContractualBlock = true;
                                break;
                            }
                        }

                        str += "<span class='hash-cell ";
                        str += (isContractualBlock ? "contract-block" : "normal-block");
                        str += "'>" + blockHash.substr(0, 8) + "</span>";

                        if (request.has_param("pre_hash_flag"))
                        {
                            str += "<span class='hash-cell'>(" + block.prevhash().substr(0, 8) + ")</span>";
                        }
                    }

                    str += "</div></td>\n";
                    str += "</tr>\n";

                    count++;
                    if (count >= num)
                    {
                        break;
                    }
                }
            }

            str += "</tbody>\n</table>\n</div>\n</body>\n</html>";
            response.set_content(str, "text/html; charset=utf-8");
        }
        else
        {
            str = DisplayContractSections(num, request.has_param("pre_hash_flag"));
            response.set_content(str, "text/plain");
        }
    }
    else
    {
        if (html_format)
        {
            // print_range_contract_blocks's HTML version
            uint64_t top = 0;
            if (startNum <= 0)
            {
                str += "<tr><td colspan='2' class='error'>The starting block height must be greater than 0</td></tr>\n";
            }
            else if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
            {
                str += "<tr><td colspan='2' class='error'>Get block height failed</td></tr>\n";
            }
            else if (startNum > top)
            {
                str += "<tr><td colspan='2' class='error'>The starting block height exceeds the current highest block</td></tr>\n";
            }
            else
            {
                int count = 0;
                for (uint64_t i = startNum; i <= top && count < num; i++)
                {
                    std::vector<std::string> blockHashs;
                    if (dbReader.getBlockHashsByBlockHeight(i, blockHashs) != DBStatus::DB_SUCCESS)
                    {
                        continue;
                    }

                    if (blockHashs.empty())
                    {
                        continue;
                    }

                    // Add height cell when displaying the first block hash of each height
                    str += "<tr>\n";
                    str += "<td class='height-cell'>" + std::to_string(i) + "</td>\n";
                    str += "<td><div class='hash-container'>";

                    for (const auto &blockHash : blockHashs)
                    {
                        std::string strHeader;
                        if (dbReader.getBlockByBlockHash(blockHash, strHeader) != DBStatus::DB_SUCCESS)
                        {
                            continue;
                        }

                        CBlock block;
                        if (!block.ParseFromString(strHeader))
                        {
                            continue;
                        }

                        bool isContractualBlock = false;
                        for (const auto &tx : block.txs())
                        {
                            if ((global::ca::TxType)tx.type() == global::ca::TxType::DEPLOY ||
                                (global::ca::TxType)tx.type() == global::ca::TxType::CALL)
                            {
                                isContractualBlock = true;
                                break;
                            }
                        }

                        str += "<span class='hash-cell ";
                        str += (isContractualBlock ? "contract-block" : "normal-block");
                        str += "'>" + blockHash.substr(0, 8) + "</span>";

                        if (request.has_param("pre_hash_flag"))
                        {
                            str += "<span class='hash-cell'>(" + block.prevhash().substr(0, 8) + ")</span>";
                        }
                    }

                    str += "</div></td>\n";
                    str += "</tr>\n";

                    count++;
                    if (count >= num)
                    {
                        break;
                    }
                }
            }

            str += "</tbody>\n</table>\n</div>\n</body>\n</html>";
            response.set_content(str, "text/html; charset=utf-8");
        }
        else
        {
            str = print_range_contract_blocks(startNum, num, request.has_param("pre_hash_flag"));
            response.set_content(str, "text/plain");
        }
    }
}
