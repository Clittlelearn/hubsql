﻿#ifndef RPC_API_GETBLOCK_H
#define RPC_API_GETBLOCK_H

#include "net/httplib.h"

namespace ohi { namespace rpc{

    void getBlock(const httplib::Request &, httplib::Response &);

}}

#endif // RPC_API_GETBLOCK_H