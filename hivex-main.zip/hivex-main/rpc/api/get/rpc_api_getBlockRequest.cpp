﻿#include "rpc_api_getBlockRequest.h"
#include "ca/global.h"
#include "db/db_api.h"

#include "include/logging.h"
#include "utils/json_output.h"

void ohi::rpc::getBlockRequest(const httplib::Request &request, httplib::Response &response)
{
    nlohmann::json block;
    nlohmann::json blocks;

    int top = 0;
    if (request.has_param("top")) {
        top = atol(request.get_param_value("top").c_str());
    }
    int num = 0;
    if (request.has_param("num")) {
        num = atol(request.get_param_value("num").c_str());
    }

    num = num > 500 ? 500 : num;

    if (top < 0 || num < 0) {
        ERRORLOG("getBlockRequest top < 0||num < 0");
        return;
    }

    DBReader dbReader;
    uint64_t myTop = 0;
    dbReader.getBlockTop(myTop);
    if (top > (int)myTop) {
        ERRORLOG("getBlockRequest begin > myTop");
        return;
    }
    int k = 0;
    uint64_t countNum = top + num;
    if (countNum > myTop) {
        countNum = myTop;
    }
    for (auto i = top; i <= countNum; i++) {
        std::vector<std::string> blockHashs;

        if (dbReader.getBlockHashsByBlockHeight(i, blockHashs) !=
            DBStatus::DB_SUCCESS) 
        {
            return;
        }

        for (auto hash : blockHashs) 
        {
            std::string strHeader;
            if (dbReader.getBlockByBlockHash(hash, strHeader) !=
                DBStatus::DB_SUCCESS) 
            {
                return;
            }
            block = ohi::json::block2Json(strHeader);
            //BlockInvert(strHeader,block);
            blocks[k++] = block;
        }
    }
    std::string str = blocks.dump();
    response.set_content(str, "application/json");
}