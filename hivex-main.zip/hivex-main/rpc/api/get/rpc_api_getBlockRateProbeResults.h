﻿#ifndef RPC_API_GETBLOCKRATEPROBERESULTS_H
#define RPC_API_GETBLOCKRATEPROBERESULTS_H

#include "net/httplib.h"

namespace ohi { namespace rpc{

    void getBlockRateProbeResults(const httplib::Request &, httplib::Response &);

}}


#endif // RPC_API_GETBLOCKRATEPROBERESULTS_H
