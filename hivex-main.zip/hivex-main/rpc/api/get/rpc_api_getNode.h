﻿#ifndef RPC_API_GETNODE_H
#define RPC_API_GETNODE_H

#include "net/httplib.h"

namespace ohi { namespace rpc{

        void getNode(const httplib::Request &request, httplib::Response &response);
}}

#endif // RPC_API_GETNODE_H