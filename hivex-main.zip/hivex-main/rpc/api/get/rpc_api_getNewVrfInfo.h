﻿#ifndef RPC_API_GETNEWVRFINFO_H
#define RPC_API_GETNEWVRFINFO_H

#include "net/httplib.h"

namespace ohi { namespace rpc{

    void getNewVrfInfo(const httplib::Request &, httplib::Response &);

}}

#endif // RPC_API_GETNEWVRFINFO_H