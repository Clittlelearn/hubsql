﻿#include "rpc_api_getAssetType.h"
#include "ca/algorithm.h"
#include "utils/hex_string.h"

void ohi::rpc::getAssetType(const httplib::Request &request, httplib::Response &response){
    std::string contractAddr;
    if (request.has_param("contractAddr"))
    {
        contractAddr = request.get_param_value("contractAddr").c_str();
    }
    if (contractAddr.empty())
    {
        response.set_content("get contractAddr error", "text/plain");
        return;
    }
    contractAddr = ohi::hex::remove0xPrefix(contractAddr);
    std::string assetType;
    int ret = ca_algorithm::GetAsseTypeByContractAddr(contractAddr, assetType);
    if (ret == 0)
    {
        response.set_content(assetType, "text/plain");
    }
    else
    {
        std::ostringstream oss;
        oss << "GetContractAddrByAsseType error, error num: " << ret;
        response.set_content(oss.str(), "text/plain");
    }

    return;
}