﻿#include <cstdint>
#include <future>
#include <atomic>
#include <chrono>
#include <limits>
#include <ostream>
#include <evmc/hex.hpp>
#include <evmone/evmone.h>

#include "block.pb.h"
#include "ca/global.h"
#include "ca/contract.h"
#include "ca/contract_input_policy.h"
#include "ca/algorithm.h"
#include "ca/transaction.h"
#include "ca/transaction_cache.h"
#include "errorn/error_module.h"

#include <nlohmann/json.hpp>
#include "transaction.pb.h"
#include "utils/console.h"
#include "utils/contract_utils.h"
#include "utils/hex_code.h"

#include "mpt/trie.h"
#include "include/logging.h"

#include "db/db_api.h"
#include "ca/evm/evmEnvironment.h"
#include "ca/evm/evm_host.h"

#include "utils/contract_utils.h"
#include "ca/evm/evm_manager.h"
#include "common/global_data.h"
#include "common/genesis_helper.h"
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/multiprecision/cpp_dec_float.hpp>
#include <string>
#include <vector>

#include "ca/fee_calculator.h"
#include "ca/pending_transaction_reservations.h"
#include "ca/pending_transaction_store.h"
#include "ca/pending_transaction_draft.h"
#include "utils/magic_singleton.h"

namespace
{
constexpr const char *kInitialContractBaseFee = "10";
std::atomic<uint64_t> g_pendingDraftSequence{0};
}

namespace Evmone
{
    std::map<evmc_status_code, std::string> error_descriptions = 
    {
        {EVMC_SUCCESS, "Execution successful."},
        {EVMC_FAILURE, "Generic execution failure."},
        {EVMC_REVERT, "Execution terminated with REVERT opcode."},
        {EVMC_OUT_OF_GAS, "Execution ran out of gas."},
        {EVMC_INVALID_INSTRUCTION, "INVALID instruction hit."},
        {EVMC_UNDEFINED_INSTRUCTION, "Undefined instruction encountered."},
        {EVMC_STACK_OVERFLOW, "Stack overflow."},
        {EVMC_STACK_UNDERFLOW, "Stack underflow."},
        {EVMC_BAD_JUMP_DESTINATION, "Bad jump destination."},
        {EVMC_INVALID_MEMORY_ACCESS, "Read outside memory bounds."},
        {EVMC_CALL_DEPTH_EXCEEDED, "Call depth exceeded."},
        {EVMC_STATIC_MODE_VIOLATION, "Static mode violation."},
        {EVMC_PRECOMPILE_FAILURE, "Precompile failure."},
        {EVMC_CONTRACT_VALIDATION_FAILURE, "Contract validation failed."},
        {EVMC_ARGUMENT_OUT_OF_RANGE, "Argument out of range."},
        {EVMC_WASM_UNREACHABLE_INSTRUCTION, "Unreachable WASM instruction."},
        {EVMC_WASM_TRAP, "WASM trap hit."},
        {EVMC_INSUFFICIENT_BALANCE, "Insufficient balance."},
        {EVMC_INTERNAL_ERROR, "Internal error."},
        {EVMC_REJECTED, "Execution rejected."},
        {EVMC_OUT_OF_MEMORY, "Out of memory."}
    };
}



int execute_by_evmone(const evmc_message &msg, EvmHost &host,std::string &output= soutput)
{
    struct evmc_vm* pvm = evmc_create_evmone();
    if (!pvm)
    {
        ERRORLOG("Create pvm Failed");
        return -1;
    }
    if (!evmc_is_abi_compatible(pvm))
    {
        ERRORLOG("pvm is not compatible");
        return -2;
    }
    evmc::VM vm{pvm};

    host.usedInfo.input_size+=host.code.size()+msg.input_size;

    auto async_execute = [&vm](EvmHost& host, evmc_revision rev, const evmc_message& msg, const uint8_t* code, size_t code_size)
    {
        return vm.execute(host, rev, msg, code, code_size);
    };

    std::future<evmc::Result> futureResult = std::async(std::launch::async, async_execute, std::ref(host), EVMC_MAX_REVISION, std::ref(msg), host.code.data(), host.code.size());

    std::future_status status = futureResult.wait_for(std::chrono::seconds(10));
    if (status == std::future_status::timeout)
    {
        ERRORLOG(RED "Evmone execution failed timeout!" RESET);
        std::cout<< RED << "contract execution failed timeout!" << RESET << std::endl;
        return -3;
    }

    evmc::Result result = futureResult.get();
    DEBUGLOG("Evmone execution Result: {}", Evmone::error_descriptions[result.status_code]);

	host.output = evmc::hex({result.output_data, result.output_size});
    if (result.status_code != EVMC_SUCCESS)
	{ 
        ERRORLOG(RED "Evmone execution failed! gas_left:{}, Output: {}" RESET, result.gas_left, std::string_view(reinterpret_cast<const char *>(result.output_data), result.output_size));  
        std::string output;
        output = host.output  + "output: " + Evmone::error_descriptions[result.status_code];
        host.outputError = output;
		std::cout<< RED << "contract execution failed! Result:" << Evmone::error_descriptions[result.status_code] 
        << "gas_left:" << result.gas_left<< RESET << std::endl;
        ERRORLOG("contract execution failed! Result:{}, gas_left:{}", Evmone::error_descriptions[result.status_code], result.gas_left);
        return -4;
	}
   
    host.gas_cost = msg.gas - result.gas_left;
     host.usedInfo.gas_used=host.gas_cost;
    DEBUGLOG("output size: {}", result.output_size);
    DEBUGLOG("gas left: {}", result.gas_left);
    DEBUGLOG("msg.gas:{} ,result.gas_left:{},host.gas_cost:{}",host.gas_cost,msg.gas,result.gas_left);

    
	DEBUGLOG("Output: {}", host.output);
    output = host.output;

    std::cout << "used info:\n" << host.usedInfo.toString() << std::endl;
    return 0;    
}

int Evmone::DeployContract(const std::string &from, EvmHost &host, evmc_message &message, const std::string &to,
                           int64_t blockTimestamp, int64_t blockPrevRandao,int64_t blockNumber,const std::string &gasType)
{
    int ret = evmEnvironment::make_deploy_host(from, to, host, blockTimestamp, blockPrevRandao, blockNumber,0);
    if(ret != 0)
    {
        ERRORLOG("failed to make deploy host! The error code is:{}", ret);
        return ret - 10;
    }

    ret = evmEnvironment::createDeploymentMessageRequest(host.tx_context.tx_origin, evm_utils::convertStringToEvmAddress(to), gasType, message);
    if (ret != 0)
    {
        ERRORLOG("fail to make deploy evm message")
        return ret - 20;
    }

    ret = execute_by_evmone(message, host);
    if(ret != 0)
    {
        ERRORLOG("evm execute ret: {}", ret);
        return ret - 30;
    }
    if (host.output.empty())
    {
        DEBUGLOG("deploy runtimecode is empty");
        return -5;
    }
    if(GetInitAccountAddr() == from)
    {
        host.gas_cost = 0;
    }
    return 0;
}

int Evmone::CallContract(const std::string &from, const std::string &strInput, EvmHost &host,
                         const uint64_t &contractTransfer,
                         const std::string &to, evmc_message &message, int64_t blockTimestamp, int64_t blockPrevRandao,
                         int64_t blockNumber, const std::string &gasType)
{

    int ret = evmEnvironment::makeCallHostRequest(from, to, contractTransfer, host.code, host, blockTimestamp,
                                  blockPrevRandao, blockNumber);
    if (ret != 0)
    {
        ERRORLOG("fail to make call host, ret: {}", ret);
        return ret - 10;
    }
    

    evmc::bytes input = evm_utils::StringTobytes(strInput);
    if (input.empty())
    {
        ERRORLOG("fail to convert contract input to hex format");
        return -1;
    }

    int res = evmEnvironment::MakeCallMessage(evm_utils::convertStringToEvmAddress(from), evm_utils::convertStringToEvmAddress(to), input, contractTransfer, gasType,message);
    if (res != 0)
    {
        ERRORLOG("fail to make call evm message");
        return res - 20;
    }

    res = execute_by_evmone(message, host);
    DEBUGLOG("evm execute ret: {}", res);
    if(res != 0)
    {
        return res - 30;
    }

    if(GetInitAccountAddr() == from)
    {
        host.gas_cost = 0;
    }
    return res;
}

int Evmone::callContractRpcRequest(const std::string &from, const std::string &strInput, EvmHost &host,
                             const uint64_t &contractTransfer,
                             const std::string &to, evmc_message &message, int64_t blockTimestamp, int64_t blockPrevRandao,
                             int64_t blockNumber, const std::string &gasType)
{
	int ret = evmEnvironment::makeCallHostRequest(from, to, contractTransfer, host.code, host, blockTimestamp,
                                  blockPrevRandao, blockNumber);
    if (ret != 0)
    {
        ERRORLOG("fail to make call host, ret: {}", ret);
        return ret - 10;
    }
    

    evmc::bytes input = evm_utils::StringTobytes(strInput);
    if (input.empty())
    {
        ERRORLOG("fail to convert contract input to hex format");
        return -1;
    }

    int res = evmEnvironment::rpcCallMessage(evm_utils::convertStringToEvmAddress(from), evm_utils::convertStringToEvmAddress(to), input, contractTransfer, message);
    if (res != 0)
    {
        ERRORLOG("fail to make call evm message");
        return res - 20;
    }
	
    res = execute_by_evmone(message, host);
    DEBUGLOG("evm execute ret: {}", res);
    if(res != 0)
    {
        return res - 30;
    }
    if(GetInitAccountAddr() == from)
    {
        host.gas_cost = 0;
    }
    return res;
}


void Evmone::GetStorage(const EvmHost &host, nlohmann::json &jStorage, std::set<evmc::address> &dirtyContract)
{
    std::map<std::string, std::string> storages;
    for(const auto &account : host.accounts)
    {
        std::pair<std::string, std::string> rootHash;
        std::map<std::string, std::string> dirtyhash;
        std::shared_ptr<Trie> root = account.second.storageRoot;
        root->Save();
        root->GetBlockStorage(rootHash, dirtyhash);

        if(!dirtyhash.empty())
        {
            dirtyContract.insert(account.first);
        }

        if(rootHash.first.empty())
        {
            continue;
        }

        std::string contractAddr = root->contractAddr;
        storages[contractAddr + "_" + "rootHash"] = rootHash.first;
        if (!rootHash.second.empty())
        {
            dirtyContract.insert(account.first);
            fillStorageMap(rootHash, storages, contractAddr);
        }

        for(const auto& it : dirtyhash)
        {
            fillStorageMap(it, storages, contractAddr);
        }
    }

    for (const auto& [key, value] : storages)
    {
        jStorage[key] = value;
    }
}

void
Evmone::fillStorageMap(const std::pair<std::string, std::string> &item, std::map<std::string, std::string> &storages,
                       const std::string &contractAddr)
{
    DBReader dbReader;
    std::string storageKey = contractAddr + "_" + item.first;
    std::string storageValue = item.second;
    std::string oldStorageValue;
    if(dbReader.getMptValueByMptKey(storageKey, oldStorageValue) == DB_SUCCESS && storageValue == oldStorageValue)
    {
        INFOLOG("storage exist key: {}, value: {}", storageKey, storageValue);
        return;
    }

    storages[storageKey] = storageValue;
}

void Evmone::invokedContract(const EvmHost& host, std::vector<std::string>& calledContract)
{
    for(const auto &account : host.accounts)
    {
        calledContract.push_back(evm_utils::evm_addr_to_string(account.first));
    }
}

int Evmone::ContractInfoAdd(const EvmHost &host, const std::string &txHash, global::ca::TxType TxType,
                            uint32_t transactionVersion,
                            nlohmann::json &txInfoJson, std::map<std::string, std::string> &contractPreHashCache_, bool checkContractPreHashEnabled)
{
    nlohmann::json jStorage;
    std::set<evmc::address> dirtyContract;
    GetStorage(host, jStorage, dirtyContract);
    txInfoJson[Evmone::storageKeyForContract] = jStorage;

    DBReader data_reader;
    std::map<std::string,std::string> items;
    std::set<std::string> createdContracts;
    std::map<std::string,std::string> creationItems;
    for (const auto& [contractAddress, RuntimeCode] : host.createdContract)
    {
        creationItems[contractAddress] = RuntimeCode;
        createdContracts.insert(contractAddress);
    }
    txInfoJson[Evmone::contractCreationKeyLabel] = creationItems;

    for(auto &account : host.accounts)
    {
        if(TxType == global::ca::TxType::DEPLOY)
        {
            continue;
        }

        if(dirtyContract.find(account.first) == dirtyContract.end())
        {
            continue;
        }

        std::string callAddress = account.second.storageRoot->contractAddr;
        if (createdContracts.find(callAddress) != createdContracts.end())
        {
            continue;
        }
        if (callAddress.empty())
        {
            ERRORLOG("callAddress is empty")
            return -2;
        }
        std::string prevTxHash;

        prevTxHash = MagicSingleton<TransactionCache>::GetInstance()->get_and_update_contract_pre_hash(
                callAddress, txHash, contractPreHashCache_);

        if (prevTxHash.empty())
        {
            ERRORLOG("prevTxHash is empty")
            return -3;
        }
        items[callAddress] = prevTxHash;
    }
    txInfoJson[Evmone::contractPreHashKey] = items;

    for(auto &it : host.recorded_logs)
    {
        nlohmann::json logmap;
        logmap["creator"] = evm_utils::evm_addr_to_string(it.creator);
        logmap["data"] = evmc::hex({it.data.data(), it.data.size()});
        for(auto& topic : it.topics)
        {
            logmap["topics"].push_back(evmc::hex({topic.bytes, sizeof(topic.bytes)}));
        }
        txInfoJson[Evmone::contract_log_key_name].push_back(logmap);
    }

    std::map<std::string,std::string> destructItems;
    for(auto &it : host.recorded_selfdestructs)
    {
        std::string contractAddress = evm_utils::evm_addr_to_string(it.selfdestructed);
        std::string contractCode;
        if(data_reader.getContractCodeByContractAddr(contractAddress, contractCode) != DBStatus::DB_SUCCESS)
        {
            DEBUGLOG("getContractDeployUtxoByContractAddr failed!, Addr:{}", contractAddress);
            return -1;
        }
        destructItems[contractAddress] = contractCode;

    }
    txInfoJson[Evmone::contractDestructionKey] = destructItems;
    return 0;
}

int ContractCommonInterfaceHandler::GenVin(const std::pair<std::string, std::string>& addressCurrencyMapping, const uint64_t& expend, const uint64_t& tempGas, CTxUtxos * txUtxo, 
            std::vector<std::string>& utxoHashesList, uint64_t& total, bool isFindUtxo, bool isSign,const std::string& sender)
{
    // Find utxo
    std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;

    auto ret = TxHelper::FindUtxo(std::make_pair(addressCurrencyMapping.first, addressCurrencyMapping.second), TxHelper::MAX_VIN_SIZE, expend, total, tempGas, outputUtxosSet, isFindUtxo,sender);
    if (ret != 0)
    {
        ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
        if (ret == TxHelper::kWaitingPendingUtxo) return ret;
        return -1;
    }
    if (outputUtxosSet.empty())
    {
        ERRORLOG(RED "Utxo is empty!" RESET);
        return -2;
    }
    std::set<std::string> setTxOwners;
    // Fill Vin
    for (auto & utxo : outputUtxosSet)
    {
        setTxOwners.insert(utxo.addr);
    }
    if (setTxOwners.empty())
    {
        ERRORLOG(RED "Tx owner is empty!" RESET);
        return -3;
    }
    uint32_t n = txUtxo->vin_size();
    for (auto & owner : setTxOwners)
    {
        txUtxo->add_owner(owner);
        
        CTxInput * vin = txUtxo->add_vin();
        for (auto & utxo : outputUtxosSet)
        {
            if (owner == utxo.addr)
            {
                CTxPrevOutput * prevOutput = vin->add_prevout();
                prevOutput->set_hash(utxo.hash);
                prevOutput->set_n(utxo.n);
                DEBUGLOG("----- utxo.hash:{}, utxo.n:{} owner:{}", utxo.hash, utxo.n, owner);
                if(sender.empty()) 
                    utxoHashesList.push_back(utxo.hash);
            }
        }
        vin->set_sequence(n++);

        if(!isSign)
        {
            vin->set_contractaddr(owner);
        }

        txUtxo->set_assettype(addressCurrencyMapping.second);
    }
    return 0;
}

static int
fillOutputTransmissionRequest(const std::string &fromAddr, const std::string &toAddr, global::ca::TxType txType,
          const std::vector<TransferInfo> &transferrings, const std::pair<std::string, std::string> &gasTrade, const nlohmann::json &txInfoJson,
          int64_t gasCost, CTransaction &outTx, TxHelper::vrfAgentType &type, const std::string &encodedInfo, bool isFindUtxo)
{
    if(toAddr.empty())
    {
        return -2;
    }

  //  outTx.set_type(global::ca::kTxSign);
    nlohmann::json data;
    data["txInfo"] = txInfoJson;
    std::string s = data.dump();
    outTx.set_data(s);
    outTx.set_note(encodedInfo);
    
    bool isFlowInTx = false;
    bool isFlowOutTx = false;
    ca_algorithm::FlowTxType flowTxType = ca_algorithm::GetFlowTxType(txInfoJson);

    if (flowTxType == ca_algorithm::FlowTxType::FlowInTx)
    {
        isFlowInTx = true;
    }
    
    if (flowTxType == ca_algorithm::FlowTxType::FlowOutTx)
    {
        isFlowOutTx = true;
    }

    std::vector<std::string> utxoHashesList;
    int ret = Evmone::generateCallOutMessage(fromAddr, toAddr, txType, transferrings, gasTrade,gasCost, outTx, utxoHashesList, isFindUtxo,true,isFlowInTx,isFlowOutTx);
    if(ret < 0)
    {
        ERRORLOG("generateCallOutMessage fail !!! ret:{}", ret);
        if (ret == TxHelper::kWaitingPendingUtxo) return ret;
        return ret - 100;
    }

    ret = ContractCommonInterfaceHandler::transactionFillings(fromAddr, txType, outTx, type);
    if(ret != 0)
    {
        ERRORLOG("transactionFillings fail !!! ret:{}", ret);
        return ret - 200;
    }

    return 0;
}

int Evmone::generateCallOutMessage(const std::string &fromAddr, const std::string &toAddr, global::ca::TxType txType,
                         const std::vector<TransferInfo> &transferrings, const std::pair<std::string, std::string> &gasTrade,int64_t gasCost,
                         CTransaction &outTx, std::vector<std::string> &utxoHashesList, bool isFindUtxo,bool shouldGenerateSignature, bool isFlowInTx, bool isFlowOutTx,
                         const CTransaction* exactInputSource)

{
    std::map<std::string,std::map<std::string,uint64_t>> transfersMap;
    for(const auto& iter : transferrings)
    {
        DEBUGLOG("from:{}, to:{}, amount:{}", iter.from, iter.to, iter.amount); 
        if(iter.amount == 0) continue;
        transfersMap[iter.from][iter.to] += iter.amount;
    }

    int retValue = ContractCommonInterfaceHandler::transactionFillings(fromAddr, toAddr, txType, transfersMap, gasTrade,gasCost, outTx, utxoHashesList, isFindUtxo, shouldGenerateSignature, isFlowInTx,isFlowOutTx, exactInputSource);
    if(retValue != 0)
    {
        ERRORLOG("transactionFillings error : {} ", retValue);
        if (retValue == TxHelper::kWaitingPendingUtxo) return retValue;
        return retValue - 10;
    }

    return 0;
}

int Evmone::VerifyUtxo(const std::string& sender, const CTransaction& tx, const CTransaction& callOutRequest, int mapping)
{
    if(tx.utxos_size() != callOutRequest.utxos_size())
    {
        ERRORLOG("The utxos size is not equal!");
        return -1;
    }


    bool flag = false;
    if(!tx.data().empty())
    {
        nlohmann::json dataJson = nlohmann::json::parse(tx.data());
        if(dataJson.contains("txInfo"))
        {
            nlohmann::json txInfoJson = dataJson["txInfo"].get<nlohmann::json>();
            ca_algorithm::FlowTxType flowTxType = ca_algorithm::GetFlowTxType(txInfoJson);
            for (const auto &utxo : tx.utxos())
            {
                //越入
                if (flowTxType == ca_algorithm::FlowTxType::FlowInTx && utxo.vout_size() == 2 && utxo.vin_size() == 0 && tx.utxos_size() == 1)
                {
                    flag = true;
                }
            }
        }
    }

    if(flag == false){
        if(!checkUtxoOwnership(tx))
        {
            ERRORLOG("The owner does not match!");
            return -2;
        }
    }
    
    auto txType = (global::ca::TxType)tx.type();
    for (int i = 0; i < tx.utxos_size(); ++i)
    {
        auto txUtxo = tx.utxos(i);
        auto callOutTxUtxo = callOutRequest.utxos(i);

        if(txUtxo.assettype() != callOutTxUtxo.assettype())
        {
            ERRORLOG("The asset type does not match");
            return -3;
        }
        
        uint64_t sourceBurn = 0, srcBalance = 0;
        uint64_t txVoutSum = 0 , transactionBurnGasRequest = 0;
        for(const auto& vout : txUtxo.vout())
        {
            if(txType == global::ca::TxType::CALL 
                && global::ca::VIRTUAL_CALL_CONTRACT_ADDR != vout.addr() 
                && global::ca::VIRTUAL_BURN_GAS_ADDR != vout.addr()
                && mapping != 0
                && txUtxo.owner(0) != vout.addr()) 
            {
                if(txUtxo.assettype() != global::ca::ASSET_TYPE_OHI)
                {
                    ERRORLOG("asset type error: {}", txUtxo.assettype());
                    return -4;
                }
            }

            txVoutSum += vout.value();
            if(vout.addr() == global::ca::kVirtualDeploymentContractAddress || vout.addr() == global::ca::VIRTUAL_CALL_CONTRACT_ADDR){
                sourceBurn = vout.value();
                continue;
            }
            
            if(sender == vout.addr()){
                srcBalance = vout.value();
                continue;
            }

            if(global::ca::VIRTUAL_BURN_GAS_ADDR == vout.addr())
            {
                transactionBurnGasRequest = vout.value();
            }
        }

        uint64_t targetBurn = 0, targetBalance = 0;
        uint64_t transactionOutputValueMessage = 0 , callOutTxGasBurn = 0;
        for(const auto& vout : callOutTxUtxo.vout())
        {
            if(txType == global::ca::TxType::CALL 
                && global::ca::VIRTUAL_CALL_CONTRACT_ADDR != vout.addr() 
                && global::ca::VIRTUAL_BURN_GAS_ADDR != vout.addr()
                && mapping != 0
                && txUtxo.owner(0) != vout.addr()) 
            {
                if(txUtxo.assettype() != global::ca::ASSET_TYPE_OHI)
                {
                    ERRORLOG("asset type error: {}", txUtxo.assettype());
                    return -5;
                }
            }

            transactionOutputValueMessage += vout.value();
            if(vout.addr() == global::ca::kVirtualDeploymentContractAddress || vout.addr() == global::ca::VIRTUAL_CALL_CONTRACT_ADDR){
                targetBurn = vout.value();
                continue;
            }

            if(sender == vout.addr()){
                targetBalance = vout.value();
                continue;
            }

            if(global::ca::VIRTUAL_BURN_GAS_ADDR == vout.addr())
            {
                callOutTxGasBurn = vout.value();
            }

        }

        if(targetBurn > 2 * sourceBurn){
            ERRORLOG("targetBurn{}, sourceBurn:{}", targetBurn, sourceBurn);
            return -6;
        }
        
        if((sourceBurn + srcBalance) != (targetBurn + targetBalance)){
            ERRORLOG("sourceBurn: {} , targetBurn:{} ", sourceBurn, targetBurn);
            ERRORLOG("srcBalance: {} , targetBalance:{} ", srcBalance, targetBalance);
            ERRORLOG("srcTotalAmount : {}, targetTotalAmount : {}", (sourceBurn + srcBalance), (targetBurn + targetBalance));
            return -7;
        }

        if(transactionBurnGasRequest != callOutTxGasBurn)
        {
            ERRORLOG("The gas value does not match! transactionBurnGasRequest : {}, callOutTxGasBurn : {}",transactionBurnGasRequest, callOutTxGasBurn);
            return -8;
        }
        
        if(txVoutSum != transactionOutputValueMessage)
        {
            ERRORLOG("The vout value does not match! txVoutSum : {}, transactionOutputValueMessage : {}",txVoutSum , transactionOutputValueMessage);
            return -9;
        }
    }

    return 0;
}

int Evmone::fillCallOutTransaction(const std::string &fromAddr, const std::string &toAddr,
                          const std::vector<TransferInfo> &transferrings, const std::pair<std::string, std::string> &gasTrade,
                          const nlohmann::json &txInfoJson, int64_t gasCost, CTransaction &outTx,
                          TxHelper::vrfAgentType &type, const std::string &encodedInfo, bool isFindUtxo)
{
    if (!isValidAddress(toAddr))
    {
        ERRORLOG("Fromaddr is a non address!");
        return -1;
    }
    
    return fillOutputTransmissionRequest(fromAddr, toAddr,
                     global::ca::TxType::CALL, transferrings, gasTrade,txInfoJson, gasCost, outTx, type,
                     encodedInfo,isFindUtxo);
}

int Evmone::fillDeployOutTransaction(const std::string &fromAddr, const std::string &toAddr,
                            const std::vector<TransferInfo> &transferrings, const std::pair<std::string, std::string> &gasTrade,
                            const nlohmann::json &txInfoJson, int64_t gasCost, CTransaction &outTx,
                            TxHelper::vrfAgentType &type, const std::string &encodedInfo, bool isFindUtxo)
{
    return fillOutputTransmissionRequest(fromAddr, toAddr,
                     global::ca::TxType::DEPLOY, transferrings, gasTrade,txInfoJson, gasCost, outTx, type,
                     encodedInfo,isFindUtxo);
}



int VerifyContractBaseFee(const std::string &fromAddr, int64_t &gasCost, std::string &new_baseFee)
{
    if(gasCost > global::ca::KTargetGasPrice * 2){
        ERRORLOG("Exceeding the contract gas fee limit");
        return -2;
    }

    std::string old_baseFee = kInitialContractBaseFee;
    DBReader dbReader;

    // std::vector<std::string> contractAddresses;
    // auto ret = dbReader.getContractAddrByDeployerAddr(fromAddr,contractAddresses);
    //  if(ret ==  DBStatus::DB_SUCCESS){
    //     std::string last = contractAddresses.back();
    //     std::string txHash;
    //     ret = dbReader.getContractDeployUtxoByContractAddr(last,txHash);
    //     if(ret == DBStatus::DB_SUCCESS){
    //         std::string txRaw;
    //         ret = dbReader.getTransactionByHash(txHash,txRaw);

    //         CTransaction tx;
    //         if(tx.ParseFromString(txRaw)){
    //             nlohmann::json dataJson = nlohmann::json::parse(tx.data());
    //             nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
    //             old_baseFee = txInfo["baseFee"].get<std::string>();
    //         }
    //     }else if(ret == DBStatus::DB_NOT_FOUND){ //nothing to do
    //     }else{
    //         ERRORLOG("getContractDeployUtxoByContractAddr failed!");
    //         return -4;
    //     }
        
    // }else if(ret == DBStatus::DB_NOT_FOUND){
    //     //nothing to do
    // }else{
    //     ERRORLOG("getContractAddrByDeployerAddr failed!");
    //     return -5;
    // }


    uint64_t top = 0;
    auto ret = dbReader.getBlockTop(top);
    if(ret != DBStatus::DB_SUCCESS){
        ERRORLOG("getBlockTop failed!");
        return -1;
    }

    if(top == 0){
        DEBUGLOG("block top is 0");
        gasCost *= std::stoull(old_baseFee);
        new_baseFee = old_baseFee;
        return 0;
    }

    std::vector<std::string> blockHashes;
    ret = dbReader.getBlockHashesByBlockHeight(1,top,blockHashes);
    if(ret != DBStatus::DB_SUCCESS){
        ERRORLOG("getBlockHashesByBlockHeight failed!");
        return -2;
    }

    // for (const auto& blockHash : blockHashes) {

    for (auto it = blockHashes.rbegin(); it != blockHashes.rend(); ++it) {
        const std::string& blockHash = *it;

        std::string blockRaw;
        ret = dbReader.getBlockByBlockHash(blockHash,blockRaw);
        if(ret != DBStatus::DB_SUCCESS){
            ERRORLOG("getBlockByBlockHash failed!");
            return -3;
        }

        CBlock block;
        if(!block.ParseFromString(blockRaw)){
            ERRORLOG("ParseFromString failed!");
            return -4;
        }

        DEBUGLOG("block time : {}, block height : {}",block.time(), block.height());

        // 按时间戳排序交易，确保与执行顺序一致
        // Sort transactions by timestamp to ensure consistent order with execution
        std::vector<CTransaction> sorted_txs(block.txs().begin(), block.txs().end());
        std::sort(sorted_txs.begin(), sorted_txs.end(),
                  [](const CTransaction& a, const CTransaction& b) {
                      if (a.time() != b.time()) return a.time() < b.time();
                      return a.hash() < b.hash();
                  });

        bool isFind = false;
        for(const auto& tx : sorted_txs){
            if(tx.utxos(0).owner(0) != fromAddr){
                continue;
            }

            if((global::ca::TxType)tx.type() == global::ca::TxType::DEPLOY ||
                (global::ca::TxType)tx.type() == global::ca::TxType::CALL){

                nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                std::cout << "tx.data: " << tx.data() << std::endl;
                nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                old_baseFee = txInfo["baseFee"].get<std::string>();
                // 验证 old_baseFee 是否为有效的十进制数字字符串，无效则使用默认值 "10"
                {
                    bool valid = !old_baseFee.empty();
                    for (char c : old_baseFee) {
                        if (!std::isdigit(static_cast<unsigned char>(c)) && c != '.') {
                            valid = false;
                            break;
                        }
                    }
                    if (!valid) {
                        WARNLOG("Invalid old_baseFee '{}', using default '10'", old_baseFee);
                        old_baseFee = "10";
                    }
                }
                std::cout << "old_baseFee : " << old_baseFee << std::endl;
                DEBUGLOG("Address the first contract tx hash : {}",tx.hash());
                isFind = true;
                break;
            }
        }

        if(isFind){
            break;
        }
    }
    

    DEBUGLOG("Prev GasCost : {}",gasCost);

    // old_baseFee 已在上方 829-841 行通过 isdigit 校验保证了有效性，
    // 无效值已被重置为 "10"，无需再做字符串规范化。
    int64_t old_fee_milli = 0;
    try{
        old_fee_milli = EIP1559FeeCalculator::feeFromString(old_baseFee);
    }catch(const std::exception &e){
        ERRORLOG("Invalid contract baseFee:{}, error:{}", old_baseFee, e.what());
        return -5;
    }

    // 使用整数定点数计算新费用
    int64_t new_fee_milli = EIP1559FeeCalculator::calculateNewFee(
        old_fee_milli,
        static_cast<int64_t>(gasCost),
        static_cast<int64_t>(global::ca::KTargetGasPrice)
    );
    new_baseFee = EIP1559FeeCalculator::feeToString(new_fee_milli);
    // 向零取整（与原始 (uint64_t)new_baseFee 行为一致）
    gasCost *= static_cast<uint64_t>(new_fee_milli / EIP1559FeeCalculator::FEE_SCALE);

    DEBUGLOG("gasCost : {} , new_baseFee : {} , old_baseFee : {},",gasCost,new_baseFee,old_baseFee);


    return 0;
}

namespace
{
int GenVinFromExactInputs(const CTransaction& source,
                          const std::pair<std::string, std::string>& addressAsset,
                          uint64_t expend, uint64_t tempGas, CTxUtxos* target,
                          std::vector<std::string>& hashes, uint64_t& total,
                          std::set<std::pair<int, int>>& usedOwners, std::set<std::string>& usedInputs)
{
    const auto match = contract_input::FindNextOwnerGroup(
        source, addressAsset.first, addressAsset.second, usedOwners);
    if (!match) return -1;
    const auto& group = source.utxos(match.group);
    if (group.vin_size() == 0 || group.owner_size() == 0) return -2;

    total = 0;
    size_t inputCount = 0;
    DBReader reader;
    const int firstVin = group.owner_size() == 1 ? 0 : match.owner;
    const int endVin = group.owner_size() == 1 ? group.vin_size() : match.owner + 1;
    if (firstVin >= group.vin_size()) return -3;
    for (int vinIndex = firstVin; vinIndex < endVin; ++vinIndex)
    {
        const std::string& owner = group.owner(match.owner);
        if (owner.empty() || group.vin(vinIndex).prevout_size() == 0) return -3;
        for (const auto& prevout : group.vin(vinIndex).prevout())
        {
            const std::string key = pending_tx::Reservations::UtxoKey(
                group.assettype(), prevout.hash(), prevout.n());
            if (prevout.hash().empty() || !usedInputs.insert(key).second) return -4;
            std::string balance;
            if (reader.getUtxoValueByUtxoHashes(prevout.hash(), owner, group.assettype(), balance) != DBStatus::DB_SUCCESS)
                return -5;
            if (!contract_input::AddWithoutOverflow(TxHelper::calculate_utxo_value(balance), total)) return -6;
            hashes.push_back(prevout.hash());
            ++inputCount;
        }
    }
    if (inputCount == 0) return -7;
    constexpr uint64_t kFixedInputGas = 34;
    constexpr uint64_t kPerInputGas = 64;
    const uint64_t max = std::numeric_limits<uint64_t>::max();
    if (inputCount > (max - kFixedInputGas) / kPerInputGas) return -8;
    const uint64_t vinGas = static_cast<uint64_t>(inputCount) * kPerInputGas;
    if (tempGas > max - kFixedInputGas - vinGas) return -8;
    const uint64_t gasUnits = tempGas + vinGas + kFixedInputGas;
    if (gasUnits > std::numeric_limits<uint64_t>::max() / 100) return -8;
    const uint64_t inputGas = gasUnits * 100;
    if (expend > std::numeric_limits<uint64_t>::max() - inputGas || total < expend + inputGas) return -9;

    target->add_owner(group.owner(match.owner));
    for (int vinIndex = firstVin; vinIndex < endVin; ++vinIndex)
        target->add_vin()->CopyFrom(group.vin(vinIndex));
    target->set_assettype(group.assettype());
    usedOwners.insert({match.group, match.owner});
    return 0;
}
}

int ContractCommonInterfaceHandler::transactionFillings(const std::string &fromAddr, const std::string &toAddr, global::ca::TxType txType,
                                                 const std::map<std::string, std::map<std::string, uint64_t>> &transfersMap, const std::pair<std::string, std::string> &gasTrade, const int64_t gasCost,
                                                 CTransaction &outTx, std::vector<std::string> &utxoHashesList, bool isFindUtxo, bool shouldGenerateSignature, bool isFlowInTx, bool isFlowOutTx,
                                                 const CTransaction* exactInputSource)
{ 

    if(isFlowInTx){
        return 0;
    }

    DBReader db_reader;
    uint64_t expend =  gasCost;// + contractTip;
    DEBUGLOG(" expend : {} , gasCost : {} ", expend, gasCost);;
    uint64_t VoutSize = 3;// + (contractTip != 0 ? 1 : 0); 

    for(auto & iter : transfersMap)
    {
        VoutSize += iter.second.size();

        if(iter.first == fromAddr)
        {
            continue;
        }
        VoutSize += 1;
    }    

    uint64_t tempGas = 0;
    if(precalculatedGas(outTx, VoutSize, tempGas) != 0)
    {
        ERRORLOG(" gas = 0 !");
        return -9;
    }

    std::map<std::string, uint64_t> fromBalance;
    std::set<std::pair<int, int>> usedExactOwners;
    std::set<std::string> usedExactInputs;
    auto genVin = [&](const std::pair<std::string, std::string>& addressAsset,
                      uint64_t required, uint64_t gas, CTxUtxos* target,
                      uint64_t& total, bool sign, const std::string& sender = std::string{}) {
        if (exactInputSource != nullptr)
            return GenVinFromExactInputs(*exactInputSource, addressAsset, required, gas, target,
                                         utxoHashesList, total, usedExactOwners, usedExactInputs);
        return ContractCommonInterfaceHandler::GenVin(addressAsset, required, gas, target,
                                                       utxoHashesList, total, isFindUtxo, sign, sender);
    };
    CTxUtxos *txUtxo ;
    txUtxo = new CTxUtxos();
    for(const auto& iter : transfersMap)
    {
        bool isSign = false;
        std::string utxo;
        if(db_reader.getLatestUtxoByContractAddr(iter.first, utxo) != DBStatus::DB_SUCCESS)
        {
            isSign = true;
        }

        if(!shouldGenerateSignature)
        {
            isSign = false;
        }

        uint64_t allBalance = 0;
        for(auto & toaddr : iter.second)
        {
            allBalance += toaddr.second;
        }

        uint64_t total = 0;
        DEBUGLOG("iter.first fromaddr : {}",iter.first);
        if(iter.first != fromAddr){
            auto ret = genVin(std::make_pair(iter.first, global::ca::ASSET_TYPE_OHI), allBalance, 0, txUtxo, total, isSign, fromAddr);
            if(ret < 0)
            {
                ERRORLOG("GenVin fail!!! ret:{}",ret);
                if (ret == TxHelper::kWaitingPendingUtxo) return ret;
                return -1;
            }
        }else{
            uint64_t Allexpend = expend + allBalance;
            auto ret = genVin(std::make_pair(iter.first, global::ca::ASSET_TYPE_OHI), Allexpend, tempGas, txUtxo, total, isSign);
            if(ret < 0)
            {
                ERRORLOG("GenVin fail!!! ret:{}",ret);
                if (ret == TxHelper::kWaitingPendingUtxo) return ret;
                return -2;
            }
        }
        fromBalance[iter.first] = total;
    }

    auto found = fromBalance.find(fromAddr);
    bool isAssetTypeX = (gasTrade.second == global::ca::ASSET_TYPE_OHI);


    std::string contractDestructor;
    if (txType == global::ca::TxType::DEPLOY)
    {
        contractDestructor = global::ca::kVirtualDeploymentContractAddress;
    }
    else if (txType == global::ca::TxType::CALL)
    {
        contractDestructor = global::ca::VIRTUAL_CALL_CONTRACT_ADDR;
    }
    else
    {
        return -3;
    }

    std::multimap<std::string, int64_t> targetAddrs;
    if(isAssetTypeX && found != fromBalance.end()){//找到发起人，发起人需要转账并支付gas费，且gas费必须是VOTE类型
        // CTxOutput * vout = txUtxo->add_vout();
        // vout->set_addr(contractDestructor);
        // vout->set_value(gasCost);
        targetAddrs.insert({contractDestructor, gasCost});
    }// }else{
    // }

    for(auto & iter : transfersMap)
    {
        auto& balance = fromBalance[iter.first];
        for(const auto& toaddr : iter.second)
        {
            CTxOutput * vout = txUtxo->add_vout();
            vout->set_addr(toaddr.first);
            vout->set_value(toaddr.second);
            targetAddrs.insert({toaddr.first, toaddr.second});

            if(balance < toaddr.second)
            {
                return -4;
            }

            balance -= toaddr.second;
        }
        if(iter.first == fromAddr)
        {
            continue;
        } 
        CTxOutput * vout = txUtxo->add_vout();
        vout->set_addr(iter.first);
        vout->set_value(balance);
        targetAddrs.insert({iter.first, balance});
    }

    targetAddrs.insert({fromAddr, 0});
    targetAddrs.insert({global::ca::VIRTUAL_BURN_GAS_ADDR, 0});
    
    uint64_t gas = 0;
    // if( found != fromBalance.end() && isAssetTypeX ){
    //     uint64_t gasSize = outTx.data().size() + outTx.type().size() + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();
    //     if (GenerateGas(*txUtxo, global::ca::kTxSign, targetAddrs.size(), gasSize, gas) != 0)
    //     {
    //         ERRORLOG(" gas = 0 !");
    //         return -5;
    //     }
    // }

    if( !transfersMap.empty()){
        uint64_t gasSize = outTx.data().size() +  outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();
        if (GenerateGas(*txUtxo,  targetAddrs.size(), gasSize, gas) != 0)
        {
            ERRORLOG(" gas = 0 !");
            return -5;
        }
    }

    uint64_t FlowOutGas_ = 0;
    if(isFlowOutTx && outTx.independence() != global::ca::TX_INDEPENDENCE_NAN){
        auto beginUtxo = outTx.mutable_utxos()->begin();
        uint64_t gasSize = outTx.data().size() + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();
        if (GenerateGas(*beginUtxo,  3, gasSize, FlowOutGas_) != 0)
        {
            ERRORLOG(" FlowOutGas_ = 0 !");
            return -4;
        }
        
    }

    DEBUGLOG("fillingTransaction Vote gas: {},",gas);

    if(GetInitAccountAddr()== fromAddr )
    {
        gas = 0;
        FlowOutGas_ = 0;
    }

    // auto AddOutputs = [](auto* txUtxo, const std::string& addr, uint64_t value, uint64_t gas) {
    //     CTxOutput* vout = txUtxo->add_vout();
    //     vout->set_addr(addr);
    //     vout->set_value(value);

    //     CTxOutput* burnOutput = txUtxo->add_vout();
    //     burnOutput->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
    //     burnOutput->set_value(gas);
    // };


    
    auto AddOutputsGasCost = [](auto* txUtxo, const std::string& addr, uint64_t value, uint64_t gas, uint64_t gasCost,const std::string& contractDestructor) {
        CTxOutput * voutCost = txUtxo->add_vout();
        voutCost->set_addr(contractDestructor);
        voutCost->set_value(gasCost);

        CTxOutput* vout = txUtxo->add_vout();
        vout->set_addr(addr);
        vout->set_value(value);

        CTxOutput* burnOutput = txUtxo->add_vout();
        burnOutput->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
        burnOutput->set_value(gas);
    };




    if( found != fromBalance.end() && isAssetTypeX ){
        expend += gas;
        DEBUGLOG("expend + gas : {} + {} = {}",expend - gas,gas,expend);
    }

    //没有 就是需要单独建立utxo不是X的
    if(found == fromBalance.end() || !isAssetTypeX){//非VOTE类型或者不是发起者
        if(!transfersMap.empty() && found == fromBalance.end() && isAssetTypeX){
            ERRORLOG("You must choose other types of assets to pay the gas");
            return -10;
        }
        //默认跃出资产支付gas
        DEBUGLOG("outTx gasTx : {}",outTx.independence());
        if(isFlowOutTx && outTx.independence() == global::ca::TX_INDEPENDENCE_NAN){
            outTx.set_independence(global::ca::TX_INDEPENDENCE_FALSE);
        }else{ //单独支付
            CTxUtxos* transactionUtxo1;
            uint64_t total1 = 0;
            if(isFlowOutTx){  
                transactionUtxo1 = outTx.add_utxos();
                int errorCode = found == fromBalance.end() ? -2 : -3;
                if (auto ret = genVin(gasTrade, FlowOutGas_, tempGas, transactionUtxo1, total1, shouldGenerateSignature); ret < 0) {
                    ERRORLOG("GenVin fail!!! ret:{}", ret);
                    if (ret == TxHelper::kWaitingPendingUtxo) return ret;
                    return errorCode;
                }
            }else{
                transactionUtxo1 = outTx.add_utxos();
                int errorCode = found == fromBalance.end() ? -2 : -3;       
                if (auto ret = genVin(gasTrade, expend, tempGas, transactionUtxo1, total1, shouldGenerateSignature); ret < 0) {
                    ERRORLOG("GenVin fail!!! ret:{}", ret);
                    if (ret == TxHelper::kWaitingPendingUtxo) return ret;
                    return errorCode;
                }
            }

            uint64_t sologas = 0;
            uint64_t gasSize = outTx.data().size() +  outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();
            if (GenerateGas(*transactionUtxo1,  targetAddrs.size(), gasSize, sologas) != 0)
            {
                ERRORLOG(" gas = 0 !");
                return -5;
            }

            if(GetInitAccountAddr() == fromAddr)
            {
                sologas = 0;
            }

            uint64_t totalGas  = 0;
            if(isFlowOutTx){
                totalGas = sologas + FlowOutGas_;
            }else{
                totalGas =  sologas  + gas;
            }


            DEBUGLOG("expend : {} , gas : {}, totalGas : {}",expend,sologas,totalGas);
            DEBUGLOG("sologas + expend + gas = {}",sologas + expend + gas);
            DEBUGLOG("sologas + FlowOutGas_ = {}",sologas + FlowOutGas_);
            if (total1 < totalGas) {
                ERRORLOG("The total1 cost = {} is less than the totalGas = {}", total1, totalGas);
                return -7;
            }

            AddOutputsGasCost(transactionUtxo1, gasTrade.first, (total1 - totalGas - expend), totalGas, expend, contractDestructor);
        

            transactionUtxo1->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE);
            outTx.set_independence(global::ca::TX_INDEPENDENCE_TRUE);
        }   

        if(found != fromBalance.end())
        {
            AddOutputsGasCost(txUtxo, fromAddr, fromBalance[fromAddr], 0, 0, contractDestructor);
            txUtxo->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_FALSE);
        }
    }else{ 
        fromBalance[fromAddr] -= expend;
        AddOutputsGasCost(txUtxo, fromAddr, fromBalance[fromAddr], gas, gasCost, contractDestructor);
        txUtxo->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_FALSE);
        outTx.set_independence(global::ca::TX_INDEPENDENCE_FALSE);
        CTxUtxos* utxo = outTx.add_utxos();
        utxo->CopyFrom(*txUtxo);
    }
    return 0;   
}

int ContractCommonInterfaceHandler::transactionFillings(const std::string &fromAddr, global::ca::TxType txType, 
                                                        CTransaction &outTx, TxHelper::vrfAgentType &type)
{
    
    auto currentTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    if(global::ca::TxType::CALL == txType || global::ca::TxType::DEPLOY == txType)
    {
        type = TxHelper::vrfAgentType_vrf;
    }

    outTx.set_time(currentTime);

    if (outTx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -9990;
    }

    if (outTx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -9989;
    }

    uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(outTx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
        db_reader.getNonceByAddr(outTx.utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
        ERRORLOG("get NonceByAddr error");
	    return -2;
	}
    outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
    outTx.set_type((uint32_t)txType);
    outTx.set_consensus(global::ca::kConsensus);
    const std::string& pendingAddress = outTx.utxos(0).owner(0);
    std::vector<std::string> pendingUtxos;
    for (const auto& utxo : outTx.utxos())
        for (const auto& vin : utxo.vin())
            for (const auto& prevout : vin.prevout()) pendingUtxos.push_back(utxo.assettype() + "_" + prevout.hash() + "_" + std::to_string(prevout.n()));
    const std::string draftId = "draft_" + pendingAddress + "_" + std::to_string(currentTime) + "_" +
                                std::to_string(g_pendingDraftSequence.fetch_add(1));
    if (MagicSingleton<pending_tx::Reservations>::GetInstance()->Reserve(
            draftId, pendingAddress, nonce, pendingUtxos, &nonce) != pending_tx::ReserveResult::kOk)
    {
        ERRORLOG("reserve pending contract nonce/utxo failed, addr:{}", pendingAddress);
        return -3;
    }
    if (!MagicSingleton<pending_tx::Store>::GetInstance()->Persist(draftId, pendingAddress, nonce, pendingUtxos))
    {
        MagicSingleton<pending_tx::Reservations>::GetInstance()->Release(draftId);
        ERRORLOG("persist pending contract draft failed, addr:{}", pendingAddress);
        return -4;
    }
	outTx.set_nonce(nonce);
    const std::string pendingCommitment = pending_tx::CanonicalCommitment(outTx);
    if (!MagicSingleton<pending_tx::Reservations>::GetInstance()->SetCommitment(draftId, pendingCommitment) ||
        !MagicSingleton<pending_tx::Store>::GetInstance()->Replace(
            draftId, draftId, pendingAddress, nonce, pendingUtxos, pendingCommitment,
            pending_tx::ConsensusDeadline(outTx)))
    {
        MagicSingleton<pending_tx::Reservations>::GetInstance()->Release(draftId);
        MagicSingleton<pending_tx::Store>::GetInstance()->Remove(draftId);
        return -5;
    }

    // Contract dispatcher selection binds to the serialized transaction body.
    // Finalize the transaction fields first so identity derivation and proof
    // creation both see the same public input.
    std::string identity;
    int ret = get_contract_distribution_manager(outTx, identity, TxHelper::SelectLocalSelectionSigner(outTx));
    if(ret != 0)
    {
        MagicSingleton<pending_tx::Reservations>::GetInstance()->Release(draftId);
        MagicSingleton<pending_tx::Store>::GetInstance()->Remove(draftId);
        ERRORLOG("get_contract_distribution_manager fail ret: {}", ret);
        return -1;
    }
    outTx.set_identity(identity);
    DEBUGLOG("@@@@@ owner = {} , packager = {} , txhash = {}",fromAddr, identity,outTx.hash());
    return 0;
}

void TestAddressMapping()
{
    Account defaultAccount;
    MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(defaultAccount);
    std::cout<< "strFromAddr:" << "0x"+defaultAccount.GetAddr() <<std::endl;
    std::cout<< "EvmAddress:" << evm_utils::GetEvmAddr(defaultAccount.GetPubStr()) << std::endl;
}

int Evmone::ValidateMappingTransaction(const std::string &hexStr, const std::string &contractAddr, const std::string &contractOwnerEvmAddress, const CTransaction &outTx, const EvmHost &host,
                                       const evmc_message &message, std::string &output = soutput)
{
    std::map<std::string, TxHelper::ProposalInfo> assetMap;
    if (ca_algorithm::fetchAvailableAssetType(assetMap) != 0)
    {
        return -1;
    }
    
    std::string assetType;
    if (ca_algorithm::GetAsseTypeByContractAddr(contractAddr, assetType) != 0)
    {
        return -2;
    }

    bool flag = false;
    for (const auto &asset : assetMap)
    {
        if (asset.second.ContractAddr == contractAddr)
        {
            flag = true;
            break;
        }
    }

    if (!flag)
        return -3;

    auto utxo = outTx.utxos().begin();
    if (assetType != utxo->assettype())
    {
        return -4;
    }

    std::string ExchangeRate;
    if (ca_algorithm::GetAssetRate(contractAddr, ExchangeRate) != 0)
    {
        return -99;
    }
    boost::multiprecision::cpp_dec_float_100 AsseRate(ExchangeRate);

    std::string strPart;
    boost::multiprecision::cpp_int numPart;
    size_t startIndex = 0;

    if (hexStr.substr(0, 2) == "0x")
    {
        startIndex = 2;
    }

    strPart = hexStr.substr(startIndex, 8);
    std::string numStr = hexStr.substr(startIndex + 8);
    numPart = boost::multiprecision::cpp_int("0x" + numStr);
    static const boost::multiprecision::cpp_int kMaxUint64(static_cast<std::string>("18446744073709551615"));
    boost::multiprecision::cpp_int rateInt;
    int rateDecimal = 0;
    boost::trim(ExchangeRate); // 需 #include <boost/algorithm/string.hpp>
    size_t pos = ExchangeRate.find('.');
    if (pos != std::string::npos)
    {
        std::string integerPart = ExchangeRate.substr(0, pos);
        std::string fractionalPart = ExchangeRate.substr(pos + 1);
        fractionalPart.erase(fractionalPart.find_last_not_of('0') + 1);
        rateDecimal = fractionalPart.length();
        rateInt = boost::multiprecision::cpp_int(integerPart + fractionalPart);
    }
    else
    {
        rateInt = boost::multiprecision::cpp_int(ExchangeRate);
    }
    evmc::bytes input = evm_utils::StringTobytes("0x313ce567");
    EvmHost tempHost = host;
    evmc_message tempMessage = message;
    tempMessage.input_data = input.data();
    tempMessage.input_size = input.size();
    execute_by_evmone(tempMessage, tempHost, output);
    char *endptr;
    int decimal = strtoul(output.substr(2).c_str(), &endptr, 16);
    boost::multiprecision::cpp_int decimalNumBig;
    if (decimal == 0)
    {
        decimalNumBig = 1;
    }
    else
    {
        decimalNumBig = (boost::multiprecision::pow(boost::multiprecision::cpp_int(10), decimal));
    }
    if (strPart == "6e27d889")
    {

        if(outTx.utxos_size() != 1)
        {
            ERRORLOG("outTx.utxos_size() != 1");
            return -5;
        }

        if(utxo->owner(0) != contractOwnerEvmAddress)
        {
            ERRORLOG("utxo->owner(0) != contractOwnerEvmAddress");
            return -6;
        }

        if (utxo->vout_size() != 2)
        {
            ERRORLOG("utxo->vout_size() != 2");
            return -7;
        }
        if (utxo->vin_size() != 0)
        {
            ERRORLOG("utxo->vin_size() != 0");
            return -8;
        }

        boost::multiprecision::cpp_int amountTemp =
            (boost::multiprecision::cpp_int(numPart) * rateInt * global::ca::kDecimalNum) /
            (boost::multiprecision::pow(boost::multiprecision::cpp_int(10), rateDecimal) * decimalNumBig);
        
        if (amountTemp < 0 || amountTemp > kMaxUint64)
        {
            DEBUGLOG("Amount overflow: {}", amountTemp.str());
            return -9;
        }
        uint64_t amount = static_cast<uint64_t>(amountTemp);
        auto utxo = outTx.utxos().begin();
        if (utxo->vout().begin()->addr() != contractOwnerEvmAddress || utxo->vout().begin()->value() != amount)
        {
            ERRORLOG("vout error, contractOwnerEvmAddress:{}, value:{}", contractOwnerEvmAddress, amount);
            return -10;
        }
        if (utxo->vout().rbegin()->addr() != global::ca::VIRTUAL_BURN_GAS_ADDR)
        {
            return -11;
        }

        return 0;
    }
    else if (strPart == "7c405325")
    {
        boost::multiprecision::cpp_int amountTemp =
            (boost::multiprecision::cpp_int(numPart)  / (rateInt * decimalNumBig) * global::ca::kDecimalNum * boost::multiprecision::pow(boost::multiprecision::cpp_int(10), rateDecimal));
        if (amountTemp < 0 || amountTemp > kMaxUint64)
        {
            DEBUGLOG("Amount overflow: {}", amountTemp.str());
            return -12;
        }
        uint64_t amount = amountTemp.convert_to<uint64_t>();
        auto utxo = outTx.utxos().begin();

        if (utxo->vout(0).addr() != global::ca::kVirtualCallFlowOutAddr && utxo->vout(0).value() != amount)
        {
            ERRORLOG("vout error, addr:{}, value:{}", utxo->vout(0).addr(), amount);
            return -13;
        }

        return 0;
    }
    return -14;
}

int Evmone::mapHandleFunction(const std::pair<std::string, std::string> &tradeMapping, const std::string& gasAsetType ,const std::string &hexStr, const std::string &contractAddr, const std::string &contractOwnerEvmAddress, CTransaction &outTx, nlohmann::json &txInfoJson, const std::string &encodedInfo,const EvmHost &host,
											 const evmc_message &message,bool isFindUtxo, bool &isMappingTransaction,bool isFlowOutGasTrade)
{
    std::string strPart;
    boost::multiprecision::cpp_int numPart;
    size_t startIndex = 0;

    if (hexStr.substr(0, 2) == "0x")
    {
        startIndex = 2;
    }

    std::string ExchangeRate;
    if (ca_algorithm::GetAssetRate(contractAddr, ExchangeRate) != 0)
    {
        return -1;
    }
    //rate display
    boost::multiprecision::cpp_dec_float_100 AsseRate(ExchangeRate);
    
    //rate caculate
    boost::multiprecision::cpp_int rateInt;
    int rateDecimal = 0;
    boost::trim(ExchangeRate); 
    size_t pos = ExchangeRate.find('.');
    if (pos != std::string::npos)
    {
        std::string integerPart = ExchangeRate.substr(0, pos);
        std::string fractionalPart = ExchangeRate.substr(pos + 1);
        fractionalPart.erase(fractionalPart.find_last_not_of('0') + 1);
        rateDecimal = fractionalPart.length();
        rateInt = boost::multiprecision::cpp_int(integerPart + fractionalPart);
    }
    else
    {
        rateInt = boost::multiprecision::cpp_int(ExchangeRate);
    }

    //get strPart and numPart
    strPart = hexStr.substr(startIndex, 8);
    std::string numStr = hexStr.substr(startIndex + 8);
    numPart = boost::multiprecision::cpp_int("0x" + numStr);

    //excute contract get decimalNumBig
    std::string output;
    evmc::bytes input = evm_utils::StringTobytes("0x313ce567");
    EvmHost tempHost = host;
    evmc_message tempMessage = message;
    tempMessage.input_data = input.data();
    tempMessage.input_size = input.size();
    execute_by_evmone(tempMessage, tempHost, output);
    char *endptr;
    int decimal = strtoul(output.substr(2).c_str(), &endptr, 16);
    boost::multiprecision::cpp_int decimalNumBig;
    if (decimal == 0)
    {
        decimalNumBig = 1;
    }
    else{
        decimalNumBig = (boost::multiprecision::pow(boost::multiprecision::cpp_int(10), decimal));
    }
    //get MaxUint64
    static const boost::multiprecision::cpp_int kMaxUint64(static_cast<std::string>("18446744073709551615"));
    if (strPart == "6e27d889")
    {
        std::cout << "Current exchange rate:" << AsseRate << std::endl;
        boost::multiprecision::cpp_dec_float_100 curBalance = ((boost::multiprecision::cpp_dec_float_100)numPart * AsseRate);
        std::cout << "Inflow of Actual Balance:" << curBalance << std::endl;
        boost::multiprecision::cpp_int amountTemp =
            (boost::multiprecision::cpp_int(numPart) * rateInt * global::ca::kDecimalNum) /
            (boost::multiprecision::pow(boost::multiprecision::cpp_int(10), rateDecimal) * decimalNumBig);
        if (amountTemp < 0 || amountTemp > kMaxUint64)
        {
            DEBUGLOG("Amount overflow: {}", amountTemp.str());
            return -4;
        }
        uint64_t amount = static_cast<uint64_t>(amountTemp);
        DEBUGLOG("set_value amount:{}", amount);
        CTxUtxos *txUtxo = outTx.add_utxos();
        txUtxo->add_owner(tradeMapping.first);
        CTxOutput *voutToAddress = txUtxo->add_vout();
        voutToAddress->set_addr(contractOwnerEvmAddress);
        voutToAddress->set_value(amount);
        txInfoJson["callType"] = "FlowInTx";
        isMappingTransaction = true;
    }
    else if (strPart == "7c405325")
    {
        boost::multiprecision::cpp_dec_float_100 curBalance = ((boost::multiprecision::cpp_dec_float_100)numPart / AsseRate);
        std::cout << "Current exchange rate:" << AsseRate << std::endl;
        std::cout << "Outflow of Actual Balance:" << curBalance << std::endl;
        auto txUtxo = outTx.add_utxos();
        uint64_t total = 0;
        FillFlowOutVin(tradeMapping, txUtxo, total, isFindUtxo);
        boost::multiprecision::cpp_int amountTemp =
            (boost::multiprecision::cpp_int(numPart) * global::ca::kDecimalNum   /(rateInt * decimalNumBig * boost::multiprecision::pow(boost::multiprecision::cpp_int(10), rateDecimal)));
        if (amountTemp < 0 || amountTemp > kMaxUint64)
        {
            ERRORLOG("Amount overflow: {}", amountTemp.str());
            return -4;
        }
        uint64_t amount = amountTemp.convert_to<uint64_t>();
        if (total < amount)
        {
            return -1;
        }


        auto AddOutputs = [total](auto* txUtxo, const std::string& addr, uint64_t amount, uint64_t gas) {
            CTxOutput *voutToVirtualAddr = txUtxo->add_vout();
            voutToVirtualAddr->set_addr(global::ca::kVirtualCallFlowOutAddr);
            voutToVirtualAddr->set_value(amount);
            
            CTxOutput *voutToFromAddr = txUtxo->add_vout();
            voutToFromAddr->set_addr(addr);
            voutToFromAddr->set_value((total - amount - gas));

            CTxOutput *voutBurnAmount = txUtxo->add_vout();
            voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
            voutBurnAmount->set_value(gas);
                
        };

        txInfoJson["callType"] = "FlowOutTx";
        
        //判断gasTrade.second是否撤销提案 如果撤销提案就必须利用别的资产支付gas 如果没有撤销提案可以自己支付gas
        if(ca_algorithm::GetAssetTypeIsValid(tradeMapping.second) != EXIT_SUCCESS){
            AddOutputs(txUtxo,contractOwnerEvmAddress,amount,0);
            DEBUGLOG("The asset type :{} to be jumped out has already withdrawn the proposal, so other assets must be used to pay the gas on behalf of the proposal",tradeMapping.second);
            DEBUGLOG("is invaild assettype outTx.gastx() : {}",outTx.independence());
        }else{
            //默认是需要跃出的资产类型支付
            if(isFlowOutGasTrade == false){
                uint64_t flowOutGas = 0;

                nlohmann::json data;
                data["txInfo"] = txInfoJson;
                std::string s = data.dump();
                CTransaction tempTx;
               // tempTx.set_type(global::ca::kTxSign);

                uint64_t gasSize = s.size() +  encodedInfo.size() + outTx.reserve0().size() + outTx.reserve1().size();
                if (GenerateGas(*txUtxo, 3, gasSize, flowOutGas) != 0)
                {
                    ERRORLOG(" flowOutGas = 0 !");
                    return -4;
                }
                if(tradeMapping.first == GetInitAccountAddr())
                {
                    flowOutGas = 0;
                }

                AddOutputs(txUtxo,contractOwnerEvmAddress,amount,flowOutGas);
                DEBUGLOG("flowOutGas : {}",flowOutGas);
                outTx.set_independence(global::ca::TX_INDEPENDENCE_NAN);
            }else{
                AddOutputs(txUtxo,contractOwnerEvmAddress,amount,0);
                DEBUGLOG("vaild assettype outTx.gastx() : {}",outTx.independence());
            }
        }


        isMappingTransaction = true;
        
        txUtxo->set_assettype(tradeMapping.second);
        txUtxo->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_FALSE);
    }
    else
    {
        isMappingTransaction = false;
    }

    return 0;
}

int Evmone::FillFlowOutVin(const std::pair<std::string, std::string> &gasTrade, CTxUtxos *txUtxo, uint64_t &total, bool isFindUtxo)
{
    // Find utxo
    std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;

    std::multimap<std::string, std::string> fromAddr_assetType;

    fromAddr_assetType.insert({gasTrade.first, gasTrade.second});
    auto ret = TxHelper::FindUtxo(fromAddr_assetType, TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
    if (ret != 0)
    {
        ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
        return -1;
    }

    if (outputUtxosSet.empty())
    {
        ERRORLOG(RED "Utxo is empty!" RESET);
        return -2;
    }

    std::set<std::string> setTxOwners;
    // Fill Vin
    for (auto &utxo : outputUtxosSet)
    {
        setTxOwners.insert(utxo.addr);
    }
    if (setTxOwners.empty())
    {
        ERRORLOG(RED "Tx owner is empty!" RESET);
        return -3;
    }
    uint32_t n = txUtxo->vin_size();
    for (auto &owner : setTxOwners)
    {
        txUtxo->add_owner(owner);

        CTxInput *vin = txUtxo->add_vin();
        for (auto &utxo : outputUtxosSet)
        {
            if (owner == utxo.addr)
            {
                CTxPrevOutput *prevOutput = vin->add_prevout();
                prevOutput->set_hash(utxo.hash);
                prevOutput->set_n(utxo.n);
                DEBUGLOG("----- utxo.hash:{}, utxo.n:{} owner:{}", utxo.hash, utxo.n, owner);
            }
        }
        vin->set_sequence(n++);
    }
    txUtxo->set_assettype(gasTrade.second);
    return 0;
}


bool checkUtxoOwnership(const CTransaction& tx)
{
    DBReader dbReader;
 
    std::unordered_set<std::string> utxoSet;

    for(const auto &utxo : tx.utxos())
    {
        for(const auto &owner : utxo.owner())
        {
            std::vector<std::string> utxoHashes;
            if (DBStatus::DB_SUCCESS != dbReader.getUtxoHashsByAddress(owner, utxo.assettype(),utxoHashes))
            {
                ERRORLOG("getUtxoHashsByAddress failed! owner: {},utxo.assettype {}", owner,utxo.assettype());
                return false;
            }
    
            if (utxoHashes.empty())
            {
                ERRORLOG("getUtxoHashsByAddress failed! owner: {},utxo,assettype() getUtxoHashsByAddress is empty!", owner);
                return false;
            }
            utxoSet.insert(utxoHashes.begin(), utxoHashes.end());
        }
    }


    for (const auto &utxo : tx.utxos())
    {
        for (const auto &vin : utxo.vin())
        {
            for (const auto &utxo : vin.prevout())
            {
                if (utxoSet.find(utxo.hash()) == utxoSet.end()) {
                    ERRORLOG("utxoSet find failed! vin prevout hash: {}", utxo.hash());
                    return false;
                }
            }
        }
  
    }

    return true;
}

int Evmone::CallContractWithResult(const std::string &from, const std::string &strInput, EvmHost &host,
                                   const uint64_t &contractTransfer,
                                   const std::string &to, evmc_message &message, int64_t blockTimestamp, int64_t blockPrevRandao,
                                   int64_t blockNumber, const std::string &gasType,std::string &output)
{

    int ret = evmEnvironment::makeCallHostRequest(from, to, contractTransfer, host.code, host, blockTimestamp,
                                  blockPrevRandao, blockNumber);
    if (ret != 0)
    {
        ERRORLOG("fail to make call host, ret: {}", ret);
        return ret - 10;
    }
    

    evmc::bytes input = evm_utils::StringTobytes(strInput);
    if (input.empty())
    {
        ERRORLOG("fail to convert contract input to hex format");
        return -1;
    }

    int res = evmEnvironment::MakeCallMessage(evm_utils::convertStringToEvmAddress(from), evm_utils::convertStringToEvmAddress(to), input, contractTransfer, gasType,message);
    if (res != 0)
    {
        ERRORLOG("fail to make call evm message");
        return res - 20;
    }

    res = execute_by_evmone(message, host, output);
    DEBUGLOG("evm execute ret: {}", res);
    if(res != 0)
    {
        return res - 30;
    }

    if(GetInitAccountAddr() == from)
    {
        host.gas_cost = 0;
    }
    return res;
}
