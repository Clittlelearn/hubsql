﻿


#include "ca/global.h"
#include "ca/txhelper.h"
#include "ca/contract.h"
#include "ca/algorithm.h"
#include "ca/block_helper.h"
#include "ca/double_spend_cache.h"
#include "ca/pending_transaction_draft.h"
#include "ca/utxo_selection_policy.h"
#include "ca/pending_transaction_reservations.h"
#include "ca/block_helper.h"
#include "db_api.h"
#include "openssl/core_dispatch.h"
//#include "utils/json.hpp"
#include <cstdint>
#include <nlohmann/json.hpp>
#include "utils/console.h"
#include "utils/tmp_log.h"
#include "utils/time_util.h"
#include "utils/string_util.h"
#include "utils/bench_mark.h"
#include "utils/account_manager.h"
#include "utils/magic_singleton.h"
#include "utils/contract_utils.h"
#include "utils/base64.h"
#include "ca/transaction.h"
#include "include/logging.h"
#include "ca/evm/evmEnvironment.h"
#include "ca/evm/evm_manager.h"
#include "ca.h"
#include "contract/contract_error.h"
#include "utils/version.h"
#include "common/genesis_helper.h"
#include "utils/base64.h"
#include "utils/sha256.h"
#include "utils/pretty_print.h"

// #include "test.h"
int TxHelper::get_tx_utxo_height(const CTransaction &tx, uint64_t& txUtxoHeight)
{
	DBReader dbReader;
	bool flag = false;
	txUtxoHeight = 0;
	for(const auto& utxo : tx.utxos())
	{
		for(const auto& vin : utxo.vin())
		{
			for (auto & prevout : vin.prevout())
			{
				std::string blockHash;
				//std::cout <<"hash:" << prevout.hash() << std::endl;
				if(DBStatus::DB_SUCCESS != dbReader.getBlockHashByTransactionHash(prevout.hash(), blockHash))
				{
					return -1;
				}
				uint32_t blockHeight;
				if(DBStatus::DB_SUCCESS != dbReader.getBlockHeightByBlockHash(blockHash, blockHeight))
				{
					return -2;
				}
				
				if(txUtxoHeight <= blockHeight )
				{
					txUtxoHeight = blockHeight;
					flag = true;
				}
			}
		}
	}
    
	if(!flag)
	{
		return -3;
	}
	return 0;
}

std::set<std::string>  TxHelper::getTransactionOwner(const CTransaction& tx)
{
	std::set<std::string> address;
	for(const auto& utxo : tx.utxos())
	{
		for (int i = 0; i < utxo.vin_size(); i++)
		{
			const CTxInput & txin = utxo.vin(i);
			auto pub = txin.vinsign().pub();
			std::string addr = GenerateAddr(pub);
			auto res = std::find(std::begin(address), std::end(address), addr);
			if (res == std::end(address))
			{
				address.insert(addr);
			}
		}
	}
	return address;

}

int TxHelper::GetUtxos(const std::string & address, std::vector<TxHelper::Utxo>& utxos)
{
	if (address.empty())
	{
		return -1;
	}
	utxos.clear();

	DBReader dbReader;
	{
		std::vector<std::string> assetTypes;
		if (DBStatus::DB_SUCCESS != dbReader.getAssetType(assetTypes))
		{
			ERRORLOG("getAssetType failed!");
			return -2;
		}

		std::vector<std::string> utxoHashes;
		for (const auto & asset : assetTypes)
		{
			if (DBStatus::DB_SUCCESS != dbReader.getUtxoHashsByAddress(address, asset, utxoHashes))
			{
				ERRORLOG("getUtxoHashsByAddress failed!");
				continue;
			}

			std::sort(utxoHashes.begin(), utxoHashes.end());
			utxoHashes.erase(std::unique(utxoHashes.begin(), utxoHashes.end()), utxoHashes.end()); 

			for (const auto& hash : utxoHashes)
			{
				bool flag = false;
				TxHelper::Utxo utxo;
				utxo.hash = hash;
				utxo.addr = address;
				utxo.value = 0;
				utxo.n = 0; 
				std::string balance ;
				if (dbReader.getUtxoValueByUtxoHashes(hash, address, asset, balance) != 0)
				{
					ERRORLOG("getTransactionByHash failed!");
					continue;
				}
				//	If I get the pledged utxo, I will use it together
				std::string underline = "_";
				std::vector<std::string> utxoValues;

				if(balance.find(underline) != std::string::npos)
				{
					StringUtil::SplitString(balance, "_", utxoValues);
					
					for(int i = 0; i < utxoValues.size(); ++i)
					{
						utxo.value += std::stol(utxoValues[i]);
					}
				}
				else
				{
					utxo.value = std::stol(balance);
				}
				if(!flag)
				{
					utxos.push_back(utxo);
				}
			}
			
		}
		
	}
	return 0;
}

const uint32_t TxHelper::MAX_VIN_SIZE = 1000;

int TxHelper::Check(const std::vector<std::string>& fromAddr,const std::string& type ,uint64_t height)
{
//  Fromaddr cannot be empty
	if(fromAddr.empty())
	{
		ERRORLOG("Fromaddr is empty!");		
		return -1;
	}
	//  Fromaddr cannot have duplicate elements
	std::vector<std::string> source_addr_temp = fromAddr;
	std::sort(source_addr_temp.begin(),source_addr_temp.end());
	auto iter = std::unique(source_addr_temp.begin(),source_addr_temp.end());
	source_addr_temp.erase(iter,source_addr_temp.end());
	if(source_addr_temp.size() != fromAddr.size())
	{
		ERRORLOG("Fromaddr have duplicate elements!");		
		return -2;
	}

	DBReader dbReader;
	std::map<std::string, std::vector<std::string>> identities;

	//  Fromaddr cannot be a non  address
	for(auto& from : fromAddr)
	{
		if (!isValidAddress(from))
		{
			ERRORLOG("Fromaddr is a non  address!");
			return -3;
		}

		std::vector<std::string> utxoHashesList;
		if (DBStatus::DB_SUCCESS != dbReader.getUtxoHashsByAddress(from,type,utxoHashesList))
		{
			ERRORLOG(RED "getUtxoHashsByAddress failed!" RESET);
			ERRORLOG("addr:{}, type:{}:", from, type);
			return -4;
		}

		auto found = identities.find(from);
		if (found == identities.end())
		{
			identities[from] = std::vector<std::string>{};
		}

		identities[from] = utxoHashesList;
	}

	if (height == 0)
	{
		ERRORLOG("height is zero!");
		return -5;
	}

	return 0;
}

uint64_t TxHelper::calculate_utxo_value(const std::string& balance)
{
	std::string underline = "_";
    uint64_t totalValue = 0;

    if (balance.find(underline) != std::string::npos) {
        std::vector<std::string> utxoValues;
        StringUtil::SplitString(balance, "_", utxoValues);
        for (const auto& val : utxoValues) {
            totalValue += std::stol(val);
        }
    } else {
        totalValue = std::stol(balance);
    }
    return totalValue;
}

namespace
{
size_t FilterPendingUtxos(const std::string& address,
                          const std::string& assetType,
                          std::vector<std::string>& hashes)
{
    const uint64_t startedAt = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    const size_t before = hashes.size();
    std::vector<std::string> keys;
    keys.reserve(hashes.size());
    for (const auto& hash : hashes)
        keys.push_back(pending_tx::Reservations::UtxoKey(assetType, hash, 0));
    const auto reserved = MagicSingleton<pending_tx::Reservations>::GetInstance()->ReservedUtxos(keys);
    if (!reserved.empty())
        hashes.erase(std::remove_if(hashes.begin(), hashes.end(), [&](const std::string& hash) {
            return reserved.count(pending_tx::Reservations::UtxoKey(assetType, hash, 0)) != 0;
        }), hashes.end());
    const size_t filtered = before - hashes.size();
    const uint64_t duration = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp() - startedAt;
    DEBUGLOG("PENDING_UTXO_FILTER address:{}, asset:{}, candidates:{}, filtered:{}, available:{}, duration_us:{}",
             address, assetType, before, filtered, hashes.size(), duration);
    return filtered;
}
}

int TxHelper::FindUtxo(const std::multimap<std::string, std::string>& fromAddr_assetType, const uint64_t requiredUtxoAmount,
					uint64_t& total,std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator>& outputUtxosSet, bool isFindUtxo,bool filterLocked)
{
	//  Count all utxo
	std::vector<TxHelper::Utxo> Utxos;

	DBReader dbReader;
	for (const auto& [addr, asset_type] : fromAddr_assetType)
	{
		std::vector<std::string> utxoHashes;
		if (DBStatus::DB_SUCCESS != dbReader.getUtxoHashsByAddress(addr, asset_type, utxoHashes))
		{
			ERRORLOG("getUtxoHashsByAddress failed!");
			return -1;
		}

		//  duplicate removal
		std::sort(utxoHashes.begin(), utxoHashes.end());
		utxoHashes.erase(std::unique(utxoHashes.begin(), utxoHashes.end()), utxoHashes.end()); 
		const size_t filteredPending = FilterPendingUtxos(addr, asset_type, utxoHashes);
		if (utxoHashes.empty() && filteredPending != 0)
		{
			INFOLOG("PENDING_UTXO_WAIT address:{}, asset:{}, reason:all_confirmed_candidates_reserved", addr, asset_type);
			return kWaitingPendingUtxo;
		}

		for (const auto& hash : utxoHashes)
		{
			TxHelper::Utxo utxo;
			utxo.hash = hash;
			utxo.addr = addr;
			utxo.value = 0;
			utxo.n = 0; //	At present, the n of utxo is all 0

			std::string balance;
			if (dbReader.getUtxoValueByUtxoHashes(hash, addr, asset_type, balance) != 0)
			{
				ERRORLOG("getTransactionByHash failed!");
				continue;
			}

			DBReadWriter writer;
			uint64_t time = 0;
			if(DBStatus::DB_SUCCESS == writer.get30DayLockData(addr,utxo.hash ,asset_type,time)&&filterLocked){
				INFOLOG("is not locked utxo");
				//continue;
				uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
				if ((curTime - time) < 24 * 60 * 60 * 1000000 * 1) {
					INFOLOG("locked utxo less 1day");
					continue;
	            }	
            }
			

                        utxo.value = calculate_utxo_value(balance);	
			Utxos.push_back(utxo);
		}

	}

	utxo_selection::CanonicalSort(Utxos);

	total = 0;

	if(outputUtxosSet.size() < requiredUtxoAmount)
	{
		//  Fill other positions with non-0
		auto it = Utxos.begin();
		while (it != Utxos.end())
		{
			if (outputUtxosSet.size() == requiredUtxoAmount)
			{
				break;
			}
			total += it->value;

			outputUtxosSet.insert(*it);
			++it;
		}
	}

	if(isFindUtxo)
	{
		int ret = sendConfirmUtxoHashRequest(outputUtxosSet);
		if(ret != 0)
		{
			ERRORLOG("sendConfirmUtxoHashRequest error ret : {}", ret);
			return -2;
		}
	}


	return 0;
}

int TxHelper::FindUtxo(const std::pair<std::string, std::string> addressCurrencyMapping,
					const uint64_t kMaxUtxoSize,const uint64_t expend,
					uint64_t& total, const uint64_t tempGas,
					std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator>& outputUtxosSet, 
					bool isFindUtxo,const std::string& sender,bool filterLocked)
{
	(void)sender;
	
	//  Count all utxo
	std::vector<TxHelper::Utxo> Utxos;

	DBReader dbReader;
	std::string addr = addressCurrencyMapping.first, currency = addressCurrencyMapping.second;
	std::vector<std::string> utxoHashes;
	if (DBStatus::DB_SUCCESS != dbReader.getUtxoHashsByAddress(addr, currency, utxoHashes))
	{
		ERRORLOG("getUtxoHashsByAddress failed!");
		return -1;
	}

	//  duplicate removal
	std::sort(utxoHashes.begin(), utxoHashes.end());
	utxoHashes.erase(std::unique(utxoHashes.begin(), utxoHashes.end()), utxoHashes.end()); 
	const size_t originalCandidateCount = utxoHashes.size();
	const size_t filteredPending = FilterPendingUtxos(addr, currency, utxoHashes);
	if (utxoHashes.empty() && filteredPending != 0)
	{
		INFOLOG("PENDING_UTXO_WAIT address:{}, asset:{}, candidates:{}, filtered:{}, reason:all_confirmed_candidates_reserved",
		        addr, currency, originalCandidateCount, filteredPending);
		return kWaitingPendingUtxo;
	}

	for (const auto& hash : utxoHashes)
	{
		TxHelper::Utxo utxo;
		utxo.hash = hash;
		utxo.addr = addr;
		utxo.value = 0;
		utxo.n = 0; //	At present, the n of utxo is all 0

		std::string balance;
		if (dbReader.getUtxoValueByUtxoHashes(hash, addr, currency, balance) != 0)
		{
			ERRORLOG("getTransactionByHash failed!, hash: {}, addr: {}, currency: {}", hash, addr, currency);
			continue;
		}
		DEBUGLOG("FindUtxo addr: {}, hash: {}, balance:{}", addr, hash, balance);
		DBReadWriter writer;
		uint64_t time = 0;
		if(DBStatus::DB_SUCCESS == writer.get30DayLockData(addr,utxo.hash ,currency,time)&&filterLocked){
			INFOLOG("is not locked utxo");
			
			uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
			if ((curTime - time) < 24 * 60 * 60 * 1000000 * 1) {
				INFOLOG("locked utxo less 1day");
				continue;
	        }	
		}

		utxo.value = calculate_utxo_value(balance);				
		DEBUGLOG("FindUtxo utxo addr: {} , utxo value: {}", utxo.addr, utxo.value);
		Utxos.push_back(utxo);
	}

	if (Utxos.empty())
	{
		ERRORLOG("FindUtxo Utxos is empty");
		return -2;
	}
	
	utxo_selection::CanonicalSort(Utxos);

	for (const auto& utxo : Utxos) {
		DEBUGLOG("utxo addr: {}  hash :{}, utxo value: {}", utxo.addr, utxo.hash, utxo.value);
	}

	int i = 1;
	uint64_t amountSum = 0;

	uint64_t Gas = (tempGas + (1 * 64) + 34) * 100;
	uint64_t temporary_expenditure = expend + Gas;

	for (const auto& utxo : Utxos) {
		amountSum += utxo.value;
		DEBUGLOG("FindUtxo deterministic add outputUtxosSet hash: {}, value: {}", utxo.hash, utxo.value);
		outputUtxosSet.insert(utxo);
		
		Gas = (tempGas + (i * 64) + 34) * 100;
		temporary_expenditure = expend + Gas;

		++i;

		if (amountSum >= temporary_expenditure) {
			break;
		}
	}

	if (amountSum < temporary_expenditure && filteredPending != 0)
	{
		INFOLOG("PENDING_UTXO_WAIT address:{}, asset:{}, candidates:{}, filtered:{}, available_amount:{}, required_amount:{}",
		        addr, currency, originalCandidateCount, filteredPending, amountSum, temporary_expenditure);
		outputUtxosSet.clear();
		return kWaitingPendingUtxo;
	}

	if(outputUtxosSet.empty()){
		ERRORLOG("FindUtxo outputUtxosSet is empty");
		return -3;
	}
	total = amountSum;


	if(isFindUtxo)
	{
		int ret = sendConfirmUtxoHashRequest(outputUtxosSet);
		if(ret != 0)
		{
			ERRORLOG("sendConfirmUtxoHashRequest error ret : {}", ret);
			return -4;
		}
	}

	return 0;
}

static int get_random_node_lists(std::vector<Node>& nodeRandomLists)
{
	std::vector<Node> nodelist = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    auto nodelistsize = nodelist.size();
    if(nodelistsize == 0)
    {
        ERRORLOG("Nodelist Size is empty");
        return -1;
    }
    DEBUGLOG("Nodelist Size {}",nodelistsize);
    
	uint64_t height = 0;
	DBReader db_reader;
    if (DBStatus::DB_SUCCESS != db_reader.getBlockTop(height))
    {
        return -2; 
    }

    std::vector<Node> filtered_height_node_lists;
    for(auto &item : nodelist)
    {
        if(item.height >= height)
        {
            filtered_height_node_lists.push_back(item);
        }
    }
	auto send_num = filtered_height_node_lists.size() >= 100 ? 100 : filtered_height_node_lists.size();
	if(send_num == 0)
	{
		return -3;
	}

	std::default_random_engine e;
  	std::shuffle(filtered_height_node_lists.begin(), filtered_height_node_lists.end(), e);

	for(int i = 0; i < send_num; i++) {
		nodeRandomLists.push_back(filtered_height_node_lists[i]);
	}

	return 0;
}

int TxHelper::sendConfirmUtxoHashRequest(const std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator>& outputUtxosSet){
	std::vector<Node> nodeRandomLists;
    int ret = get_random_node_lists(nodeRandomLists);
	if(ret != 0)
	{
		ERRORLOG("get_random_node_lists ret : {}", ret);
		return -1;
	}
    //send_size
    std::string msgId;
    std::map<std::string, uint32_t> successHash;
    if (!dataMgrPtr.CreateWait(5, nodeRandomLists.size() * 0.8, msgId))
    {
        ERRORLOG("sendConfirmationTransactionRequest CreateWait is error");
        return -2;
    }

    GetUtxoHashReq req;
    req.set_version(ohi::GetVersion());
    req.set_msg_id(msgId);

	std::string connectHash;
	for(auto begin = outputUtxosSet.begin(); begin != outputUtxosSet.end(); ++begin)
	{
		req.add_utxohash(begin->hash);
        successHash.insert(std::make_pair(begin->hash, 0));
	}

    for (auto &node : nodeRandomLists)
    {
        if(!dataMgrPtr.AddResNode(msgId, node.address))
        {
            ERRORLOG("sendConfirmationTransactionRequest AddResNode is error");
            return -3;
        }
        NetSendMessage<GetUtxoHashReq>(node.address, req, net_com::Compress::kCompressDisabled, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
    }

    std::vector<std::string> ret_datas;
    if (!dataMgrPtr.WaitData(msgId, ret_datas))
    {
        ERRORLOG("sendConfirmationTransactionRequest WaitData is error, ret_datas size = {}, nodeRandomLists.size = {}", ret_datas.size(), nodeRandomLists.size());
        return -4;
    }

    GetUtxoHashAck copyAck;
    std::multimap<std::string, int> tx_flag_hashes;
    for (auto &ret_data : ret_datas)
    {
        copyAck.Clear();
        if (!copyAck.ParseFromString(ret_data))
        {
            continue;
        }
        
        for(auto & flag_hash : copyAck.flaghash())
        {
            tx_flag_hashes.insert(std::make_pair(flag_hash.hash(),flag_hash.flag()));
        }
    }

    for(auto & item : tx_flag_hashes)
    {
        for(auto & success : successHash)
        {
            if(item.second == 1 && item.first == success.first)
            {
                success.second++;
            }
        }
    }

    for(auto & success : successHash)
    {
        double rate = (double)success.second / (double)(ret_datas.size());

        if(rate - 0.5 < 0)
        {
            ERRORLOG("sendConfirmationTransactionRequest = {} , rate = {}", success.second, rate);
            return -5;
        }
    }

    return 0;
}

int TxHelper::createTransactionRequest(const std::vector<TxHelper::TransTable> txAsset, std::pair<std::string, std::string> &gasTrade, bool isGasTrade,
											   const std::string &encodedInfo, uint64_t height, CTransaction &outTx,
											   TxHelper::vrfAgentType &type, bool isFindUtxo = false)
{
	outTx.Clear();
	MagicSingleton<Benchmark>::GetInstance()->increase_transaction_initiate_amount();
	//  Check parameters
	std::vector<TxHelper::Utxo> allsetOutUtxos;
	uint64_t totalGas = 0;
	std::vector<std::string> doubleSpendUtxos;
	
	for (auto &i : txAsset)
	{
		std::string tempstring = i.fromAddr[0];
		tempstring += i.asset_type;
		doubleSpendUtxos.push_back(tempstring);
		int ret = Check(i.fromAddr, i.asset_type, height);
		if (ret != 0)
		{
			ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
			ret -= 100;
			return ret;
		}

		if (i.toAddrAmount.empty())
		{
			ERRORLOG("to addr is empty");
			return -1;
		}

		for (auto &addr : i.toAddrAmount)
		{
			if (!isValidAddress(addr.first))
			{
				ERRORLOG(RED "To address is not  address!" RESET);
				return -2;
			}

			for (auto &from : i.fromAddr)
			{
				if (addr.first == from)
				{
					ERRORLOG(RED "From address and to address is equal!" RESET);
					return -3;
				}
			}

			if (addr.second <= 0)
			{
				ERRORLOG(RED "Value is zero!" RESET);
				return -4;
			}
		}

		uint64_t amount = 0; // Transaction fee
		for (auto &i : i.toAddrAmount)
		{
			amount += i.second;
		}
		uint64_t expend = amount;
	
		//  Find utxo
		uint64_t total = 0;
		std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
		
		std::multimap<std::string, std::string> fromAddr_assetType;
		fromAddr_assetType.insert({i.fromAddr[0], i.asset_type});

		ret = FindUtxo(fromAddr_assetType, TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
		if (ret != 0)
		{
			ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
			ret -= 200;
			return ret;
		}
		if (outputUtxosSet.empty())
		{
			ERRORLOG(RED "Utxo is empty!" RESET);
			return -5;
		}
		for(auto& utxo: outputUtxosSet)
		{
			allsetOutUtxos.push_back(utxo);
		}
		
		CTxUtxos *transactionUtxo1 = outTx.add_utxos();
		transactionUtxo1->set_assettype(i.asset_type);
		//  Fill Vin
		std::set<std::string> setTxOwners;
		for (auto &utxo : outputUtxosSet)
		{
			setTxOwners.insert(utxo.addr);
		}
		if (setTxOwners.empty())
		{
			ERRORLOG(RED "Tx owner is empty!" RESET);
			return -6;
		}

		
		uint32_t n = 0;
		for (auto &owner : setTxOwners)
		{
			transactionUtxo1->add_owner(owner);
			CTxInput *vin = transactionUtxo1->add_vin();
			for (auto &utxo : outputUtxosSet)
			{
				if (owner == utxo.addr)
				{
					CTxPrevOutput *prevOutput = vin->add_prevout();
					prevOutput->set_hash(utxo.hash);
					prevOutput->set_n(utxo.n);
				}
			}
			vin->set_sequence(n++);

			std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
			std::string signature;
			std::string pub;
			if (TxHelper::Sign(owner, vinHashSerialized, signature, pub) != 0)
			{
				ERRORLOG("sign fail");
				return -7;
			}

			CSign *vinSign = vin->mutable_vinsign();
			vinSign->set_sign(signature);
			vinSign->set_pub(pub);
		}

		outTx.set_data("");
		outTx.set_note(encodedInfo);
		//outTx.set_type(global::ca::kTxSign);

		uint64_t gasSize = outTx.data().size() + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();
		uint64_t gas = 0;
		std::map<std::string, int64_t> targetAddrs = i.toAddrAmount;
		targetAddrs.insert(make_pair(*(i.fromAddr.rbegin()), total - expend));
		targetAddrs.insert(make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
		if (GenerateGas(*transactionUtxo1,  targetAddrs.size(), gasSize, gas) != 0)
		{
			ERRORLOG(" gas = 0 !");
			return -8;
		}
		if(GetInitAccountAddr() == i.fromAddr[0])
		{
        	gas = 0;
    	}

		DEBUGLOG("expend = {}", expend);
		if (isGasTrade)
		{
			totalGas += gas;
		}
		else
		{
			expend += gas;
		}
		DEBUGLOG("totalGas = {} , expendGas = {} gas = {}", totalGas, expend,gas);

		// Judge whether utxo is enough
		if (total < expend)
		{
			ERRORLOG("The total cost = {} is less than the cost = {}", total, expend);
			return -9;
		}

		// Fill vout
		for (auto &to : i.toAddrAmount)
		{
			CTxOutput *vout = transactionUtxo1->add_vout();
			vout->set_addr(to.first);
			vout->set_value(to.second);
		}
		CTxOutput *voutSourceAddress = transactionUtxo1->add_vout();
		voutSourceAddress->set_addr(*(i.fromAddr.rbegin()));
		voutSourceAddress->set_value(total - expend);

		if (isGasTrade)
		{
			CTxOutput *voutBurnAmount = transactionUtxo1->add_vout();
			voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
			voutBurnAmount->set_value(0);
		}
		else
		{
			CTxOutput *voutBurnAmount = transactionUtxo1->add_vout();
			voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
			voutBurnAmount->set_value(gas);
		}

		std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
		for (auto &owner : setTxOwners)
		{
			if (TxHelper::addMultipleSigns(owner, *transactionUtxo1) != 0)
			{
				ERRORLOG("addd mutil sign fail");
				return -10;
			}
		}
	}
	if (isGasTrade)
	{
		std::vector<std::string> fromaddr;
		fromaddr.push_back(gasTrade.first);
		int ret = Check(fromaddr, gasTrade.second, height);
		if (ret != 0)
		{
			ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
			ret -= 200;
			return ret;
		}

		uint64_t total = 0;
		std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;

		std::multimap<std::string, std::string> fromAddr_assetType;
		fromAddr_assetType.insert({gasTrade.first, gasTrade.second});
		ret = FindUtxo(fromAddr_assetType, TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
		if (ret != 0)
		{
			ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
			ret -= 300;
			return ret;
		}
		if (outputUtxosSet.empty())
		{
			ERRORLOG(RED "Utxo is empty!" RESET);
			return -11;
		}
		for(auto& utxo: outputUtxosSet)
		{
			allsetOutUtxos.push_back(utxo);
		}

		CTxUtxos *transactionUtxo1 = outTx.add_utxos();

		transactionUtxo1->set_assettype(gasTrade.second);
		transactionUtxo1->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE);// other to pay utxo
		outTx.set_independence(global::ca::TX_INDEPENDENCE_TRUE);
		// Fill Vin
		std::set<std::string> setTxOwners;
		for (auto &utxo : outputUtxosSet)
		{
			setTxOwners.insert(utxo.addr);
		}
		if (setTxOwners.empty())
		{
			ERRORLOG(RED "Tx owner is empty!" RESET);
			return -12;
		}

		uint32_t n = 0;

		transactionUtxo1->add_owner(gasTrade.first);
		CTxInput *vin = transactionUtxo1->add_vin();
		for (auto &utxo : outputUtxosSet)
		{
			if (gasTrade.first == utxo.addr)
			{
				CTxPrevOutput *prevOutput = vin->add_prevout();
				prevOutput->set_hash(utxo.hash);
				prevOutput->set_n(utxo.n);
			}
		}
		vin->set_sequence(n++);

		std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
		std::string signature;
		std::string pub;
		if (TxHelper::Sign(gasTrade.first, vinHashSerialized, signature, pub) != 0)
		{
			ERRORLOG("sign fail");
			return -13;
		}

		CSign *vinSign = vin->mutable_vinsign();
		vinSign->set_sign(signature);
		vinSign->set_pub(pub);

		CTxOutput *vout = transactionUtxo1->add_vout();
		vout->set_addr(gasTrade.first);
		vout->set_value(total - totalGas);

		CTxOutput *burnOutput = transactionUtxo1->add_vout();
		burnOutput->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		burnOutput->set_value(totalGas);

		std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
		for (auto &owner : setTxOwners)
		{
			if (TxHelper::addMultipleSigns(owner, *transactionUtxo1) != 0)
			{
				ERRORLOG("addd mutil sign fail");
				return -14;
			}
		}
	}

	auto currentTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	getTransactionStartIdentity(height, currentTime, type);
	DEBUGLOG("getTransactionStartIdentity currentTime = {} type = {}", currentTime, type);
	outTx.set_data("");
	outTx.set_note(encodedInfo);
	//outTx.set_type(global::ca::kTxSign);
	
	outTx.set_time(currentTime);
	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	outTx.set_consensus(global::ca::kConsensus);
	outTx.set_type((uint32_t)global::ca::TxType::TX);

	auto calculate_all_hash = [](const CTransaction& outTx) {
		std::string allHash;
		for (const auto& txUtxo : outTx.utxos()) {
			for (int i = 0; i < txUtxo.vin_size(); i++) {
				auto vin = txUtxo.vin(i);
				for (int j = 0; j < vin.prevout_size(); j++) {
					auto txPrevOutput = vin.prevout(j);
					allHash += txPrevOutput.hash();
				}
			}
		}
		allHash += std::to_string(outTx.time());
		return allHash;
	};
	
	DEBUGLOG("self hash:{}", calculate_all_hash(outTx));
	std::string identity;
	int ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(outTx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(outTx));
	if (ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -15;
	}
	DEBUGLOG("Tx identity:{}", identity);
	outTx.set_identity(identity);
	
	DEBUGLOG("getTransactionStartIdentity tx time = {}, package = {}", outTx.time(), outTx.identity());

	std::string txHash = Getsha256Hash(outTx.SerializeAsString());
	outTx.set_hash(txHash);

	INFOLOG("Transaction Start Time = {}");
	return 0;
}

int TxHelper::CreateStakingTransaction(const std::string & fromAddr,const std::string & asset_type,uint64_t stakeAmount,uint64_t height,
                    TxHelper::stakeType stakeType,CTransaction &outTx,
                    std::vector<TxHelper::Utxo> & outVin,TxHelper::vrfAgentType &type,const std::pair<std::string,std::string>& gasTrade,bool isGasTrade,
                     double commissionRate, bool isFindUtxo, const std::string& encodedInfo)
{
	//  Check parameters
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> allsetOutUtxos;
	uint64_t totalGas = 0;
	std::vector<std::string> addressVector;
	
	addressVector.push_back(fromAddr);
	int ret = Check(addressVector,asset_type,height);
	if(ret != 0)
	{
		ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
		ret -= 100;
		return ret;
	}

	if (!isValidAddress(fromAddr)) 
	{
		ERRORLOG(RED "From address invlaid!" RESET);
		return -1;
	}

	if(stakeAmount == 0 )
	{
		ERRORLOG(RED "Stake amount is zero !" RESET);
		return -2;		
	}
	
	if(stakeAmount < global::ca::MIN_STAKE_AMOUNT)
	{
		std::cout << "The pledge amount must be greater than 100000 !" << std::endl;
		return -3;
	}

	std::string stakeTypeStr;
	if (stakeType == TxHelper::stakeType::STAKE_TYPE_NODE)
	{
		stakeTypeStr = global::ca::STAKE_TYPE_NET;
	}
	else
	{
		ERRORLOG(RED "Unknown stake type!" RESET);
		return -4;
	}

	DBReader dbReader;
	std::vector<std::string> stake_unspent_outputs;
    auto dbret = dbReader.getStakeUtxoByAddr(fromAddr,asset_type,stake_unspent_outputs);
	if(dbret != DBStatus::DB_NOT_FOUND)
	{
		std::cout << "There has been a pledge transaction before !" << std::endl;
		return -5;
	}
	uint64_t expend = stakeAmount;
	//  Find utxo
	uint64_t total = 0;

	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;

	std::multimap<std::string, std::string> fromAddr_assetType;
	fromAddr_assetType.insert({addressVector[0],asset_type});
	ret = FindUtxo(fromAddr_assetType, TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
	if (ret != 0)
	{
		ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
		ret -= 200;
		return ret;
	}

	if (outputUtxosSet.empty())
	{
		ERRORLOG(RED "Utxo is empty!" RESET);
		return -6;
	}

	allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());

	outTx.Clear();
	CTxUtxos * txUtxo = outTx.add_utxos();
	txUtxo->set_assettype(asset_type);
	//  Fill Vin
	std::set<std::string> setTxOwners;
	for (auto & utxo : outputUtxosSet)
	{
		setTxOwners.insert(utxo.addr);
	}
	
	if (setTxOwners.size() != 1)
	{
		ERRORLOG(RED "Tx owner is invalid!" RESET);
		return -7;
	}

	
	for (auto & owner : setTxOwners)
	{
		txUtxo->add_owner(owner);
		uint32_t n = 0;
		CTxInput * vin = txUtxo->add_vin();
		for (auto & utxo : outputUtxosSet)
		{
			if (owner == utxo.addr)
			{
				CTxPrevOutput * prevOutput = vin->add_prevout();
				prevOutput->set_hash(utxo.hash);
				prevOutput->set_n(utxo.n);
			}
		}
		vin->set_sequence(n++);

		std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
		std::string signature;
		std::string pub;
		if (TxHelper::Sign(owner, vinHashSerialized, signature, pub) != 0)
		{
			return -8;
		}

		CSign * vinSign = vin->mutable_vinsign();
		vinSign->set_sign(signature);
		vinSign->set_pub(pub);
	}

	nlohmann::json txInfo;
	txInfo["stakeType"] = stakeTypeStr;
	txInfo["stakeAmount"] = stakeAmount;
	txInfo["commissionRate"] = commissionRate;

	nlohmann::json data;
	data["txInfo"] = txInfo;
	outTx.set_data(data.dump());
	outTx.set_note(encodedInfo);
	////outTx.set_type(global::ca::kTxSign);	

	uint64_t gas = 0;
	uint64_t gasSize = outTx.data().size()  + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();
	//  Calculate total expenditure
	std::map<std::string, int64_t> toAddr;
	toAddr.insert(std::make_pair(global::ca::kTargetAddress, stakeAmount));
	toAddr.insert(std::make_pair(fromAddr, total - expend));
	toAddr.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
	
	if(GenerateGas(*txUtxo,toAddr.size(),gasSize,gas) != 0)
	{
		ERRORLOG(" gas = 0 !");
		return -9;
	}
	if(GetInitAccountAddr() == fromAddr)
	{
        gas = 0;
    }

	auto currentTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	getTransactionStartIdentity(height,currentTime,type);

	if(isGasTrade)
	{
		totalGas += gas;
	}
	else
	{
		expend +=  gas; 
	}

	if(total < expend)
	{
		ERRORLOG("The total cost = {} is less than the cost = {}", total, expend);
		return -10;
	}

	CTxOutput * vout = txUtxo->add_vout(); 
	vout->set_addr(global::ca::kTargetAddress);
	vout->set_value(stakeAmount);

	CTxOutput * voutSourceAddress = txUtxo->add_vout();
	voutSourceAddress->set_addr(fromAddr);
	voutSourceAddress->set_value(total - expend);

	if(isGasTrade)
	{
		CTxOutput * voutBurnAmount = txUtxo->add_vout();
		voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		voutBurnAmount->set_value(0);
	}
	else
	{
		CTxOutput * voutBurnAmount = txUtxo->add_vout();
		voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		voutBurnAmount->set_value(gas);
	}


	std::string serializedUtxoHash = Getsha256Hash(txUtxo->SerializeAsString());
	for (auto & owner : setTxOwners)
	{	
		if (TxHelper::addMultipleSigns(owner, *txUtxo) != 0)
		{
			return -11;
		}
	}

	if(isGasTrade)
	{
		std::vector<std::string> fromaddr;
		fromaddr.push_back(gasTrade.first);
		int ret = Check(fromaddr,gasTrade.second,height);
		if(ret != 0)
		{
			ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
			ret -= 300;
			return ret;
		}
		
		uint64_t total = 0;
		std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
		
		std::multimap<std::string, std::string> fromAddr_assetType;
		fromAddr_assetType.insert({gasTrade.first,gasTrade.second});
		ret = FindUtxo(fromAddr_assetType,TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
		if (ret != 0)
		{
			ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
			ret -= 400;
			return ret;
		}
		if (outputUtxosSet.empty())
		{
			ERRORLOG(RED "Utxo is empty!" RESET);
			return -12;
		}
		allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());
		
		CTxUtxos * transactionUtxo1 = outTx.add_utxos();
		transactionUtxo1->set_assettype(gasTrade.second);
		transactionUtxo1->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE);// other to pay utxo
		outTx.set_independence(global::ca::TX_INDEPENDENCE_TRUE);
		//Fill Vin
		std::set<std::string> setTxOwners;
		for (auto & utxo : outputUtxosSet)
		{
			setTxOwners.insert(utxo.addr);
		}
		if (setTxOwners.empty())
		{
			ERRORLOG(RED "Tx owner is empty!" RESET);
			return -13;
		}

		uint32_t n = 0;

		transactionUtxo1->add_owner(gasTrade.first);
		CTxInput * vin = transactionUtxo1->add_vin();
		for (auto & utxo : outputUtxosSet)
		{
			if (gasTrade.first == utxo.addr)
			{
				CTxPrevOutput * prevOutput = vin->add_prevout();
				prevOutput->set_hash(utxo.hash);
				prevOutput->set_n(utxo.n);
			}
		}
		vin->set_sequence(n++);

		std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
		std::string signature;
		std::string pub;
		if (TxHelper::Sign(gasTrade.first, vinHashSerialized, signature, pub) != 0)
		{
			ERRORLOG("sign fail");
			return -14;
		}

		CSign * vinSign = vin->mutable_vinsign();
		vinSign->set_sign(signature);
		vinSign->set_pub(pub);

		CTxOutput * vout = transactionUtxo1->add_vout();
		vout->set_addr(gasTrade.first);
		vout->set_value(total - totalGas);

		CTxOutput * burnOutput = transactionUtxo1->add_vout();
		burnOutput->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		burnOutput->set_value(totalGas);

		std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
		for (auto & owner : setTxOwners)
		{		
			if (TxHelper::addMultipleSigns(owner,*transactionUtxo1) != 0)
			{
				ERRORLOG("addd mutil sign fail");
				return -15;
			}
		}

	}

	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	outTx.set_time(currentTime);
	outTx.set_consensus(global::ca::kConsensus);
	outTx.set_type((uint32_t)global::ca::TxType::STAKE);

	auto calculate_all_hash = [](const CTransaction& outTx) {
		std::string allHash;
		for (const auto& txUtxo : outTx.utxos()) {
			for (int i = 0; i < txUtxo.vin_size(); i++) {
				auto vin = txUtxo.vin(i);
				for (int j = 0; j < vin.prevout_size(); j++) {
					auto txPrevOutput = vin.prevout(j);
					allHash += txPrevOutput.hash();
				}
			}
		}
		allHash += std::to_string(outTx.time());
		return allHash;
	};

	DEBUGLOG("self hash:{}", calculate_all_hash(outTx));
	std::string identity;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(outTx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(outTx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -16;
	}
	DEBUGLOG("Tx identity:{}", identity);
	outTx.set_identity(identity);

	std::string txHash = Getsha256Hash(outTx.SerializeAsString());
	outTx.set_hash(txHash);
	return 0;
}


int TxHelper::CreateUnstakeTransaction(const std::string &fromAddr,const std::string & asset_type, const std::string &utxoHash, uint64_t height,
											 CTransaction &outTx, std::vector<TxHelper::Utxo> &outVin, TxHelper::vrfAgentType &type,
											 const std::pair<std::string, std::string> &gasTrade, bool isGasTrade,bool isFindUtxo, const std::string &encodedInfo)
{
	//  Check parameters
	std::vector<std::string> addressVector;
	addressVector.push_back(fromAddr);


	int ret = Check(addressVector, asset_type, height);
	if(ret != 0)
	{
		ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
		ret -= 100;
		return ret;
	}

	if (!isValidAddress(fromAddr))
	{
		ERRORLOG(RED "FromAddr is not normal  addr." RESET);
		return -1;
	}


	uint64_t stakeAmount = 0;
	ret = IsQualifiedToUnstake(fromAddr, utxoHash, stakeAmount,asset_type);
	if(ret != 0)
	{
		ERRORLOG(RED "FromAddr is not qualified to unstake! The error code is {}." RESET, ret);
		ret -= 200;
		return ret;
	}	

	// //  Find utxo
	// uint64_t total = 0;
	// std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
	// std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> allsetOutUtxos;
	// //  The number of utxos to be searched here needs to be reduced by 1 \
	// because a VIN to be redeem is from the pledged utxo, so just look for 99
	// std::multimap<std::string, std::string> fromAddr_assetType;
	// fromAddr_assetType.insert(std::make_pair(fromAddr, asset_type));
	// ret = FindUtxo(fromAddr_assetType, TxHelper::MAX_VIN_SIZE - 1, total, outputUtxosSet, isFindUtxo);
	// if (ret != 0)
	// {
	// 	ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
	// 	ret -= 300;
	// 	return ret;
	// }

	// if (outputUtxosSet.empty())
	// {
	// 	ERRORLOG(RED "Utxo is empty!" RESET);
	// 	return -2;
	// }
	// allsetOutUtxos.insert(outputUtxosSet.begin(), outputUtxosSet.end());
	// outTx.Clear();

	CTxUtxos * txUtxo = outTx.add_utxos();

	txUtxo->set_assettype(asset_type);
	//  Fill Vin
	// std::set<std::string> setTxOwners;
	// for (auto & utxo : outputUtxosSet)
	// {
	// 	setTxOwners.insert(utxo.addr);
	// }
	// if (setTxOwners.empty())
	// {
	// 	ERRORLOG(RED "Tx owner is empty!" RESET);
	// 	return -3;
	// }


	{
		//  Fill vin
		txUtxo->add_owner(fromAddr);
		CTxInput* txin = txUtxo->add_vin();
		txin->set_sequence(0);
		CTxPrevOutput* prevout = txin->add_prevout();
		prevout->set_hash(utxoHash);
		prevout->set_n(1);

		std::string vinHashSerialized = Getsha256Hash(txin->SerializeAsString());
		std::string signature;
		std::string pub;
		if (TxHelper::Sign(fromAddr, vinHashSerialized, signature, pub) != 0)
		{
			return -4;
		}

		CSign * vinSign = txin->mutable_vinsign();
		vinSign->set_sign(signature);
		vinSign->set_pub(pub);
	}

	// for (auto & owner : setTxOwners)
	// {
	// 	txUtxo->add_owner(owner);
	// 	uint32_t n = 1;
	// 	CTxInput * vin = txUtxo->add_vin();
	// 	for (auto & utxo : outputUtxosSet)
	// 	{
	// 		if (owner == utxo.addr)
	// 		{
	// 			CTxPrevOutput * prevOutput = vin->add_prevout();
	// 			prevOutput->set_hash(utxo.hash);
	// 			prevOutput->set_n(utxo.n);
	// 		}
	// 	}
	// 	vin->set_sequence(n++);

	// 	std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
	// 	std::string signature;
	// 	std::string pub;
	// 	if (TxHelper::Sign(owner, vinHashSerialized, signature, pub) != 0)
	// 	{
	// 		return -5;
	// 	}

	// 	CSign * vinSign = vin->mutable_vinsign();
	// 	vinSign->set_sign(signature);
	// 	vinSign->set_pub(pub);
	// }

	nlohmann::json txInfo;
	txInfo["unstakeUtxo"] = utxoHash;

	nlohmann::json data;
	data["txInfo"] = txInfo;
	outTx.set_data(data.dump());
	outTx.set_note(encodedInfo);
	//outTx.set_type(global::ca::kTxSign);	
	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);

	uint64_t gas = 0;
	//The filled quantity only participates in the calculation and does not affect others
	uint64_t gasSize = outTx.data().size() + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();
	std::map<std::string, int64_t> toAddr;
	toAddr.insert(std::make_pair(global::ca::kTargetAddress, stakeAmount));
	// toAddr.insert(std::make_pair(fromAddr, total));
	// toAddr.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));

	// if (GenerateGas(*txUtxo, toAddr.size(), gasSize, gas) != 0)
	// {
	// 	ERRORLOG(" gas = 0 !");
	// 	return -6;
	// }
	// if(GetInitAccountAddr() == fromAddr)
	// {
	// 	gas = 0;
	// }

	//  Calculate total expenditure
	uint64_t expend = 0;
	uint64_t totalGas = 0;

	auto currentTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	getTransactionStartIdentity(height,currentTime,type);

	if (isGasTrade)
	{
		totalGas = gas;
	}
	else
	{
		expend += gas;
	}
	
	// Judge whether there is enough money
	// if(total < expend)
	// {
	// 	ERRORLOG("The total cost = {} is less than the cost = {}", total, expend);
	// 	return -7;
	// }

	//  Fill vout
	CTxOutput* outputAddress = txUtxo->add_vout();
	outputAddress->set_addr(fromAddr);      	//  Release the pledge to my account number
	outputAddress->set_value(stakeAmount);

	// outputAddress = txUtxo->add_vout();
	// outputAddress->set_addr(fromAddr);  		//  Give myself the rest
	// outputAddress->set_value(total - expend);

	// if (isGasTrade)
	// {
	// 	CTxOutput *voutBurnAmount = txUtxo->add_vout();
	// 	voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
	// 	voutBurnAmount->set_value(0);
	// }
	// else
	// {
	// 	CTxOutput *voutBurnAmount = txUtxo->add_vout();
	// 	voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
	// 	voutBurnAmount->set_value(gas);
	// }

	std::string serializedUtxoHash = Getsha256Hash(txUtxo->SerializeAsString());
	// for (auto & owner : setTxOwners)
	// {
		if (TxHelper::addMultipleSigns(fromAddr, *txUtxo) != 0)
		{
			return -8;
		}
	// }

	outTx.set_time(currentTime);
	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	outTx.set_consensus(global::ca::kConsensus);
	outTx.set_type((uint32_t)global::ca::TxType::UNSTAKE);

	if (outTx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -1;
    }

    if (outTx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -2;
    }

	uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(outTx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
	db_reader.getNonceByAddr(outTx.utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
		ERRORLOG("get NonceByAddr error");
		ERRORLOG("addr:{}", outTx.utxos(0).owner(0));
		return -10;
	}
	outTx.set_nonce(nonce);
	pending_tx::DraftGuard pendingDraft;
	if (!pendingDraft.Begin(outTx, nonce)) {
		ERRORLOG("reserve pending nonce/UTXO failed");
		return -16;
	}
	outTx.set_nonce(pendingDraft.nonce());


	auto calculate_all_hash = [](const CTransaction& outTx) {
		std::string allHash;
		for (const auto& txUtxo : outTx.utxos()) {
			for (int i = 0; i < txUtxo.vin_size(); i++) {
				auto vin = txUtxo.vin(i);
				for (int j = 0; j < vin.prevout_size(); j++) {
					auto txPrevOutput = vin.prevout(j);
					allHash += txPrevOutput.hash();
				}
			}
		}
		allHash += std::to_string(outTx.time());
		return allHash;
	};

	DEBUGLOG("self hash:{}", calculate_all_hash(outTx));
	std::string identity;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(outTx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(outTx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -12;
	}
	DEBUGLOG("Tx identity:{}", identity);
	outTx.set_identity(identity);

	std::string txHash = Getsha256Hash(outTx.SerializeAsString());
	outTx.set_hash(txHash);
	if (!pendingDraft.Finalize(outTx)) {
		ERRORLOG("finalize pending transaction reservation failed");
		return -17;
	}
	DEBUGLOG("CreatUnstakeTransaction tx time = {}, package = {}", outTx.time(), outTx.identity());

	{
        std::string fileName = "Unstake.txt";
        std::ofstream file;
        file.open(fileName);
        PrintTx(outTx, true, file);
        file.close();
    }
	return 0;
}

int TxHelper::CreateDelegatingTransaction(const std::string & fromAddr, const std::string asset_type, const std::string& toAddr,
                                    uint64_t delegateAmount, uint64_t height,
                                    TxHelper::delegateType delegateType,CTransaction & outTx,
                                    std::vector<TxHelper::Utxo> & outVin,TxHelper::vrfAgentType &type,const std::pair<std::string,std::string>& gasTrade,bool isGasTrade,
                                    bool isFindUtxo, const std::string& encodedInfo)
{
	//  Check parameters

	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> allsetOutUtxos;
	uint64_t totalGas = 0;

	std::vector<std::string> addressVector;
	addressVector.push_back(fromAddr);
	int ret = Check(addressVector, asset_type, height);
	if(ret != 0)
	{
		ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
		ret -= 100;
		return ret;
	}

	//  Neither fromaddr nor toaddr can be a virtual account
	if (!isValidAddress(fromAddr))
	{
		ERRORLOG(RED "FromAddr is not normal  addr." RESET);
		return -1;
	}

	if (!isValidAddress(toAddr))
	{
		ERRORLOG(RED "To address is not  address!" RESET);
		return -2;
	}

	if(delegateAmount < global::ca::kMinDelegatingAmt){
		ERRORLOG("Delegating amount exceeds the limit!");
		return -3;
	}

	ret = CheckDelegatingQualification(fromAddr, toAddr, asset_type, delegateAmount);
	if(ret != 0)
	{
		ERRORLOG(RED "FromAddr is not qualified to delegating! The error code is {}." RESET, ret);
		ret -= 200;
		return ret;
	}	
	std::string delegateTypeName;
	if (delegateType ==  TxHelper::delegateType::kdelegateType_NetLicence)
	{
		delegateTypeName = global::ca::kdelegateTypeNormal;
	}
	else
	{
		ERRORLOG(RED "Unknown delegating type!" RESET);
		return -4;
	}
	
	//  Find utxo
	uint64_t total = 0;
	uint64_t expend = delegateAmount;

	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
	std::multimap<std::string, std::string>	fromAddr_assetType;
	fromAddr_assetType.insert(std::make_pair(fromAddr, asset_type));

	ret = FindUtxo(fromAddr_assetType, TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
	if (ret != 0)
	{
		ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
		ret -= 300;
		return ret;
	}
	if (outputUtxosSet.empty())
	{
		ERRORLOG(RED "Utxo is empty!" RESET);
		return -5;
	}
	allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());

	outTx.Clear();

	CTxUtxos *txUtxo = outTx.add_utxos();
	txUtxo->set_assettype(asset_type);
	
	//  Fill Vin
	std::set<std::string> setTxOwners;
	for (auto & utxo : outputUtxosSet)
	{
		setTxOwners.insert(utxo.addr);
	}
	if (setTxOwners.empty())
	{
		ERRORLOG(RED "Tx owner is empty!" RESET);
		return -6;
	}


	for (auto & owner : setTxOwners)
	{
		txUtxo->add_owner(owner);
		uint32_t n = 0;
		CTxInput * vin = txUtxo->add_vin();
		for (auto & utxo : outputUtxosSet)
		{
			if (owner == utxo.addr)
			{
				CTxPrevOutput * prevOutput = vin->add_prevout();
				prevOutput->set_hash(utxo.hash);
				prevOutput->set_n(utxo.n);
			}
		}
		vin->set_sequence(n++);

		std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
		std::string signature;
		std::string pub;
		if (TxHelper::Sign(owner, vinHashSerialized, signature, pub) != 0)
		{
			return -7;
		}

		CSign * vinSign = vin->mutable_vinsign();
		vinSign->set_sign(signature);
		vinSign->set_pub(pub);
	}

	nlohmann::json txInfo;
	txInfo["delegateType"] = delegateTypeName;
	txInfo["bonusAddr"] = toAddr;
	txInfo["delegateAmount"] = delegateAmount;

	nlohmann::json data;
	data["txInfo"] = txInfo;
	outTx.set_data(data.dump());
	outTx.set_note(encodedInfo);
	//outTx.set_type(global::ca::kTxSign);

	uint64_t gas = 0;	
	//  Calculate total expenditure
	std::map<std::string, int64_t> toAddrs;
	toAddrs.insert(std::make_pair(global::ca::kTargetAddress, delegateAmount));
	toAddrs.insert(std::make_pair(fromAddr, total - expend));
	toAddrs.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
	
	uint64_t gasSize = outTx.data().size() + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();

	if(GenerateGas(*txUtxo,  toAddrs.size(), gasSize, gas) != 0)
	{
		ERRORLOG(" gas = 0 !");
		return -8;
	}
	if(GetInitAccountAddr()== fromAddr)
	{
		gas = 0;
	}

	auto currentTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	getTransactionStartIdentity(height,currentTime,type);

	if(isGasTrade)
	{
		totalGas += gas;
	}
	else
	{
		expend +=  gas; 
	}

	if(total < expend)
	{
		ERRORLOG("The total cost = {} is less than the cost = {}", total, expend);
		return -9;
	}

	CTxOutput * vout = txUtxo->add_vout(); 
	vout->set_addr(global::ca::kVirtualDelegatingAddr);
	vout->set_value(delegateAmount);

	CTxOutput * voutSourceAddress = txUtxo->add_vout();
	voutSourceAddress->set_addr(fromAddr);
	voutSourceAddress->set_value(total - expend);

	if(isGasTrade)
	{
		CTxOutput * voutBurnAmount = txUtxo->add_vout();
		voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		voutBurnAmount->set_value(0);
	}
	else
	{
		CTxOutput * voutBurnAmount = txUtxo->add_vout();
		voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		voutBurnAmount->set_value(gas);
	}

	std::string serializedUtxoHash = Getsha256Hash(txUtxo->SerializeAsString());
	for (auto & owner : setTxOwners)
	{	
		if (TxHelper::addMultipleSigns(owner, *txUtxo) != 0)
		{
			return -10;
		}
	}

	if(isGasTrade)
	{
		std::vector<std::string> fromaddr;
		fromaddr.push_back(gasTrade.first);
		int ret = Check(fromaddr,gasTrade.second,height);
		if(ret != 0)
		{
			ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
			ret -= 400;
			return ret;
		}
		
		uint64_t total = 0;
		std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
		
		std::multimap<std::string, std::string> fromAddr_assetType;
		fromAddr_assetType.insert({gasTrade.first,gasTrade.second});
		ret = FindUtxo(fromAddr_assetType,TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
		if (ret != 0)
		{
			ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
			ret -= 500;
			return ret;
		}
		if (outputUtxosSet.empty())
		{
			ERRORLOG(RED "Utxo is empty!" RESET);
			return -11;
		}
		allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());

		CTxUtxos * transactionUtxo1 = outTx.add_utxos();
		transactionUtxo1->set_assettype(gasTrade.second);
		transactionUtxo1->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE);// other to pay utxo
		outTx.set_independence(global::ca::TX_INDEPENDENCE_TRUE);
		//Fill Vin
		std::set<std::string> setTxOwners;
		for (auto & utxo : outputUtxosSet)
		{
			setTxOwners.insert(utxo.addr);
		}
		if (setTxOwners.empty())
		{
			ERRORLOG(RED "Tx owner is empty!" RESET);
			return -12;
		}

		uint32_t n = 0;

		transactionUtxo1->add_owner(gasTrade.first);
		CTxInput * vin = transactionUtxo1->add_vin();
		for (auto & utxo : outputUtxosSet)
		{
			if (gasTrade.first == utxo.addr)
			{
				CTxPrevOutput * prevOutput = vin->add_prevout();
				prevOutput->set_hash(utxo.hash);
				prevOutput->set_n(utxo.n);
			}
		}
		vin->set_sequence(n++);

		std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
		std::string signature;
		std::string pub;
		if (TxHelper::Sign(gasTrade.first, vinHashSerialized, signature, pub) != 0)
		{
			ERRORLOG("sign fail");
			return -13;
		}

		CSign * vinSign = vin->mutable_vinsign();
		vinSign->set_sign(signature);
		vinSign->set_pub(pub);


		CTxOutput * vout = transactionUtxo1->add_vout();
		vout->set_addr(gasTrade.first);
		vout->set_value(total - totalGas);

		CTxOutput * burnOutput = transactionUtxo1->add_vout();
		burnOutput->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		burnOutput->set_value(totalGas);

		std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
		for (auto & owner : setTxOwners)
		{		
			if (TxHelper::addMultipleSigns(owner,*transactionUtxo1) != 0)
			{
				ERRORLOG("addd mutil sign fail");
				return -14;
			}
		}

	
	}
	
	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	outTx.set_time(currentTime);
	outTx.set_consensus(global::ca::kConsensus);
	outTx.set_type((uint32_t)global::ca::TxType::DELEGATE);

	auto calculate_all_hash = [](const CTransaction& outTx) {
		std::string allHash;
		for (const auto& txUtxo : outTx.utxos()) {
			for (int i = 0; i < txUtxo.vin_size(); i++) {
				auto vin = txUtxo.vin(i);
				for (int j = 0; j < vin.prevout_size(); j++) {
					auto txPrevOutput = vin.prevout(j);
					allHash += txPrevOutput.hash();
				}
			}
		}
		allHash += std::to_string(outTx.time());
		return allHash;
	};

	DEBUGLOG("self hash:{}", calculate_all_hash(outTx));
	std::string identity;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(outTx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(outTx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -15;
	}
	DEBUGLOG("Tx identity:{}", identity);
	outTx.set_identity(identity);

	std::string txHash = Getsha256Hash(outTx.SerializeAsString());
	outTx.set_hash(txHash);
	DEBUGLOG("CreateDelegatingTransaction tx time = {}, package = {}", outTx.time(), outTx.identity());
	return 0;
}

int TxHelper::CreateUndelegatingTransaction(const std::string& fromAddr,const std::string &asset_type, const std::string& toAddr,
                                    const std::string& utxoHash,uint64_t height,CTransaction& outTx,
                                    std::vector<TxHelper::Utxo> & outVin,TxHelper::vrfAgentType &type,const std::pair<std::string,std::string>& gasTrade,bool isGasTrade,
                                    bool isFindUtxo, const std::string& encodedInfo)
    
{
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> allsetOutUtxos;
	//  Check parameters
	std::vector<std::string> addressVector;
	addressVector.push_back(fromAddr);
	int ret = Check(addressVector, asset_type, height);
	if(ret != 0)
	{
		ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
		ret -= 100;
		return ret;
	}

	if (!isValidAddress(fromAddr))
	{
		ERRORLOG(RED "FromAddr is not normal  addr." RESET);
		return -1;
	}

	if (!isValidAddress(toAddr))
	{
		ERRORLOG(RED "To address is not  address!" RESET);
		return -2;
	}

	uint64_t delegatingedAmount = 0;
	if(IsQualifiedToUndelegating(fromAddr, asset_type, toAddr, utxoHash, delegatingedAmount) != 0)
	{
		ERRORLOG(RED "FromAddr is not qualified to Undelegating!." RESET);
		return -3;
	}

	// //  Find utxo
	// uint64_t total = 0;
	// std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
	// std::multimap<std::string, std::string> fromAddr_assetType;
	// fromAddr_assetType.insert(std::make_pair(fromAddr, asset_type));
	// //  The utxo quantity sought here needs to be reduced by 1
	// ret = FindUtxo(fromAddr_assetType, TxHelper::MAX_VIN_SIZE - 1, total, outputUtxosSet, isFindUtxo); 
	// if (ret != 0)
	// {
	// 	ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
	// 	ret -= 200;
	// 	return ret;
	// }
	// if (outputUtxosSet.empty())
	// {
	// 	ERRORLOG(RED "Utxo is empty!" RESET);
	// 	return -4;
	// }
	// allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());

	outTx.Clear();

	CTxUtxos * txUtxo = outTx.add_utxos();
	txUtxo->set_assettype(asset_type);

	//  Fill Vin
	std::set<std::string> setTxOwners;
	setTxOwners.insert(fromAddr);
	// for (auto & utxo : outputUtxosSet)
	// {
	// 	setTxOwners.insert(utxo.addr);
	// }
	if (setTxOwners.empty())
	{
		ERRORLOG(RED "Tx owner is empty!" RESET);
		return -5;
	}

	{
		//  Fill vin
		txUtxo->add_owner(fromAddr);
		CTxInput* txin = txUtxo->add_vin();
		txin->set_sequence(0);
		CTxPrevOutput* prevout = txin->add_prevout();
		prevout->set_hash(utxoHash);
		prevout->set_n(1);

		std::string vinHashSerialized = Getsha256Hash(txin->SerializeAsString());
		std::string signature;
		std::string pub;
		ret = TxHelper::Sign(fromAddr, vinHashSerialized, signature, pub);
		if (ret != 0)
		{
			ERRORLOG("delegating utxoHash Sign error:{}", ret);
			return -6;
		}

		CSign * vinSign = txin->mutable_vinsign();
		vinSign->set_sign(signature);
		vinSign->set_pub(pub);
	}

	// for (auto & owner : setTxOwners)
	// {
	// 	txUtxo->add_owner(owner);
	// 	uint32_t n = 1;
	// 	CTxInput * vin = txUtxo->add_vin();
	// 	for (auto & utxo : outputUtxosSet)
	// 	{
	// 		if (owner == utxo.addr)
	// 		{
	// 			CTxPrevOutput * prevOutput = vin->add_prevout();
	// 			prevOutput->set_hash(utxo.hash);
	// 			prevOutput->set_n(utxo.n);
	// 		}
	// 	}
	// 	vin->set_sequence(n++);

	// 	std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
	// 	std::string signature;
	// 	std::string pub;
	// 	if (TxHelper::Sign(owner, vinHashSerialized, signature, pub) != 0)
	// 	{
	// 		return -7;
	// 	}

	// 	CSign * vinSign = vin->mutable_vinsign();
	// 	vinSign->set_sign(signature);
	// 	vinSign->set_pub(pub);
	// }

	nlohmann::json txInfo;
	txInfo["bonusAddr"] = toAddr;
	txInfo["undelegatingUtxo"] = utxoHash;

	nlohmann::json data;
	data["txInfo"] = txInfo;
	outTx.set_data(data.dump());
	outTx.set_note(encodedInfo);
	//outTx.set_type(global::ca::kTxSign);	

	// uint64_t gas = 0;
	// //  Calculate total expenditure
	// std::map<std::string, int64_t> targetAddrs;
	// targetAddrs.insert(std::make_pair(global::ca::kTargetAddress, delegatingedAmount));
	// // targetAddrs.insert(std::make_pair(fromAddr, total ));
	// targetAddrs.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas ));
	
	
	// uint64_t gasSize = outTx.data().size()  + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();
	// if(GenerateGas(*txUtxo, targetAddrs.size(), gasSize, gas) != 0)
	// {
	// 	ERRORLOG(" gas = 0 !");
	// 	return -8;
	// }
	// if(GetInitAccountAddr() == fromAddr)
	// {
	// 	gas = 0;
	// }

	auto currentTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	getTransactionStartIdentity(height,currentTime,type);

	// uint64_t expend = 0;
	// uint64_t totalGas = 0;
	// if(isGasTrade)
	// {
	// 	totalGas = gas;
	// }else
	// {
	// 	expend += gas;
	// }
	
	// if(total < expend)
	// {
	// 	ERRORLOG("The total cost = {} is less than the cost = {}", total, expend);
	// 	return -9;
	// }	

	// Fill vout
	CTxOutput* outputAddress = txUtxo->add_vout();
	outputAddress->set_addr(fromAddr);      //  Give my account the money I withdraw
	outputAddress->set_value(delegatingedAmount);

	// outputAddress = txUtxo->add_vout();
	// outputAddress->set_addr(fromAddr);  	  //  Give myself the rest
	// outputAddress->set_value(total - expend);

	// if(isGasTrade)
	// {
	// 	CTxOutput * voutBurnAmount = txUtxo->add_vout();
	// 	voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
	// 	voutBurnAmount->set_value(0);
	// }else
	// {
	// 	CTxOutput * voutBurnAmount = txUtxo->add_vout();
	// 	voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
	// 	voutBurnAmount->set_value(gas);
	// }

	std::string serializedUtxoHash = Getsha256Hash(txUtxo->SerializeAsString());
	if (TxHelper::addMultipleSigns(fromAddr,*txUtxo) != 0)
	{
		return -10;
	}
	// for (auto & owner : setTxOwners)
	// {	
	// }

	// if(isGasTrade)
	// {
	// 	std::vector<std::string> fromaddr;
	// 	fromaddr.push_back(gasTrade.first);
	// 	int ret = Check(fromaddr,gasTrade.second,height);
	// 	if(ret != 0)
	// 	{
	// 		ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
	// 		ret -= 300;
	// 		return ret;
	// 	}
		
	// 	uint64_t total = 0;
	// 	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
		
	// 	std::multimap<std::string, std::string> fromAddr_assetType;
	// 	fromAddr_assetType.insert({gasTrade.first,gasTrade.second});
	// 	ret = FindUtxo(fromAddr_assetType,TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
	// 	if (ret != 0)
	// 	{
	// 		ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
	// 		ret -= 400;
	// 		return ret;
	// 	}
	// 	if (outputUtxosSet.empty())
	// 	{
	// 		ERRORLOG(RED "Utxo is empty!" RESET);
	// 		return -11;
	// 	}
	// 	allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());


	// 	CTxUtxos * transactionUtxo1 = outTx.add_utxos();

	// 	transactionUtxo1->set_assettype(gasTrade.second);
	// 	transactionUtxo1->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE);// other to pay utxo
	// 	outTx.set_independence(global::ca::TX_INDEPENDENCE_TRUE);
	// 	//Fill Vin
	// 	std::set<std::string> setTxOwners;
	// 	for (auto & utxo : outputUtxosSet)
	// 	{
	// 		setTxOwners.insert(utxo.addr);
	// 	}
	// 	if (setTxOwners.empty())
	// 	{
	// 		ERRORLOG(RED "Tx owner is empty!" RESET);
	// 		return -12;
	// 	}

	// 	uint32_t n = 0;

	// 	transactionUtxo1->add_owner(gasTrade.first);
	// 	CTxInput * vin = transactionUtxo1->add_vin();
	// 	for (auto & utxo : outputUtxosSet)
	// 	{
	// 		if (gasTrade.first == utxo.addr)
	// 		{
	// 			CTxPrevOutput * prevOutput = vin->add_prevout();
	// 			prevOutput->set_hash(utxo.hash);
	// 			prevOutput->set_n(utxo.n);
	// 		}
	// 	}
	// 	vin->set_sequence(n++);

	// 	std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
	// 	std::string signature;
	// 	std::string pub;
	// 	if (TxHelper::Sign(gasTrade.first, vinHashSerialized, signature, pub) != 0)
	// 	{
	// 		ERRORLOG("sign fail");
	// 		return -13;
	// 	}

	// 	CSign * vinSign = vin->mutable_vinsign();
	// 	vinSign->set_sign(signature);
	// 	vinSign->set_pub(pub);


	// 	CTxOutput * vout = transactionUtxo1->add_vout();
	// 	vout->set_addr(gasTrade.first);
	// 	vout->set_value(total - totalGas);

	// 	CTxOutput * burnOutput = transactionUtxo1->add_vout();
	// 	burnOutput->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
	// 	burnOutput->set_value(totalGas);


	// 	std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
	// 	for (auto & owner : setTxOwners)
	// 	{		
	// 		if (TxHelper::addMultipleSigns(owner,*transactionUtxo1) != 0)
	// 		{
	// 			ERRORLOG("addd mutil sign fail");
	// 			return -14;
	// 		}
	// 	}

	// }

	outTx.set_time(currentTime);
	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	outTx.set_consensus(global::ca::kConsensus);
	outTx.set_type((uint32_t)global::ca::TxType::UNDELEGATE);

	if (outTx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -1;
    }

    if (outTx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -2;
    }

	uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(outTx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
	db_reader.getNonceByAddr(outTx.utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
		ERRORLOG("get NonceByAddr error");
		ERRORLOG("addr:{}", outTx.utxos(0).owner(0));
		return -10;
	}
	outTx.set_nonce(nonce);
	pending_tx::DraftGuard pendingDraft;
	if (!pendingDraft.Begin(outTx, nonce)) {
		ERRORLOG("reserve pending nonce/UTXO failed");
		return -16;
	}
	outTx.set_nonce(pendingDraft.nonce());
	

	auto calculate_all_hash = [](const CTransaction& outTx) {
		std::string allHash;
		for (const auto& txUtxo : outTx.utxos()) {
			for (int i = 0; i < txUtxo.vin_size(); i++) {
				auto vin = txUtxo.vin(i);
				for (int j = 0; j < vin.prevout_size(); j++) {
					auto txPrevOutput = vin.prevout(j);
					allHash += txPrevOutput.hash();
				}
			}
		}
		allHash += std::to_string(outTx.time());
		return allHash;
	};
	

	DEBUGLOG("self hash:{}", calculate_all_hash(outTx));
	std::string identity;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(outTx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(outTx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -15;
	}
	DEBUGLOG("Tx identity:{}", identity);
	outTx.set_identity(identity);

	std::string txHash = Getsha256Hash(outTx.SerializeAsString());
	outTx.set_hash(txHash);
	if (!pendingDraft.Finalize(outTx)) {
		ERRORLOG("finalize pending transaction reservation failed");
		return -17;
	}
	DEBUGLOG("CreateUndelegatingTransaction tx time = {}, package = {}", outTx.time(), outTx.identity());
	return 0;
}

int TxHelper::CreateBonusTransaction(const std::string &addr, const std::string asset_type,uint64_t height,
									 CTransaction &outTx,
									 std::vector<TxHelper::Utxo> &outVin,
									 TxHelper::vrfAgentType &type, const std::pair<std::string, std::string> &gasTrade,
									 bool isGasTrade, bool isFindUtxo, const std::string &encodedInfo,bool firstChoose)
{
	auto pair_is_empty = [](const std::pair<std::string, std::string> &pair) {
        return pair.first.empty() || pair.second.empty();
    };

	if(pair_is_empty(gasTrade) == false)
	{
		int ret = CheckGasAssetsQualification(gasTrade,height);
		if(ret != 0)
		{
			ERRORLOG("CheckGasAssetsQualification error ret is {}",ret);
			return ret;
		}
	}
	std::vector<std::string> addressVector;
	addressVector.push_back(addr);
	//add for bonus
	int ret = Check(addressVector, asset_type, height);
	if(ret != 0)
	{
		ERRORLOG("Check parameters failed");
		ret -= 100;
		return ret;
	}

	if (!isValidAddress(addr))
	{
		ERRORLOG(RED "Default is not normal  addr." RESET);
		return -1;
	}

	DBReader dbReader; 
	std::vector<std::string> utxos;
	uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	ret = evaluateBonusEligibility(addr, curTime);
	if(ret != 0)
	{
		ERRORLOG(RED "Not allowed to Bonus!" RESET);
		return ret -= 200;
	}

	std::map<std::string, uint64_t> companyDividend;
    ret=ca_algorithm::CalcBonusValue(curTime, addr, companyDividend);
	if(ret < 0)
	{
		ERRORLOG("Failed to obtain the amount claimed by the delegatingor ret:({})",ret);
		return ret -= 300;
	}

	uint64_t expend = 0;
	uint64_t total = 0;
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
	std::multimap<std::string, std::string> fromAddr_assetType;
	fromAddr_assetType.insert(std::make_pair(addr, asset_type));
	ret = FindUtxo(fromAddr_assetType, TxHelper::MAX_VIN_SIZE - 1, total, outputUtxosSet, isFindUtxo); 
	if (ret != 0)
	{
		ERRORLOG("TxHelper CreatUnstakeTransaction: FindUtxo failed");
		ret -= 400;
		return ret;
	}
	if (outputUtxosSet.empty())
	{
		ERRORLOG("TxHelper CreatUnstakeTransaction: utxo is zero");
		return -2;
	}
	outTx.Clear();
	CTxUtxos * txUtxo = outTx.add_utxos();

	txUtxo->set_assettype(global::ca::ASSET_TYPE_OHI);
	//  Fill Vin
	std::set<std::string> setTxOwners;
	for (auto & utxo : outputUtxosSet)
	{
		setTxOwners.insert(utxo.addr);
	}
	if (setTxOwners.empty())
	{
		ERRORLOG(RED "Tx owner is empty!" RESET);
		return -3;
	}

	for (auto & owner : setTxOwners)
	{
		txUtxo->add_owner(owner);
		uint32_t n = 0;
		CTxInput * vin = txUtxo->add_vin();
		for (auto & utxo : outputUtxosSet)
		{
			if (owner == utxo.addr)
			{
				CTxPrevOutput * prevOutput = vin->add_prevout();
				prevOutput->set_hash(utxo.hash);
				prevOutput->set_n(utxo.n);
			}
		}
		vin->set_sequence(n++);

		std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
		std::string signature;
		std::string pub;
		if (TxHelper::Sign(owner, vinHashSerialized, signature, pub) != 0)
		{
			return -4;
		}

		CSign * vinSign = vin->mutable_vinsign();
		vinSign->set_sign(signature);
		vinSign->set_pub(pub);
	}
	// Fill data
	uint64_t temp_cost=0;
	uint64_t node_dividend_temp=0;
	uint64_t totalClaimTemp=0;

	double temp_commission_rate;
	int rt = ca_algorithm::GetCommissionPercentage(addr, temp_commission_rate);
	if(rt != 0)
	{
		ERRORLOG("GetCommissionPercentage error:{}", rt);
        return rt -= 500;
	}
	for(auto company : companyDividend)
	{
		temp_cost=company.second*temp_commission_rate+0.5;
		node_dividend_temp+=temp_cost;
		std::string addr = company.first;
		uint64_t award = company.second - temp_cost;
		totalClaimTemp+=award;		
	}
	totalClaimTemp += node_dividend_temp;
	nlohmann::json txInfo;
	txInfo["bonusAmount"] = totalClaimTemp;
	txInfo["bonusAddrList"] = companyDividend.size() + 2;
	nlohmann::json data;
	data["txInfo"] = txInfo;
	outTx.set_data(data.dump());
	outTx.set_note(encodedInfo);
	//outTx.set_type(global::ca::kTxSign);

	// calculation gas
	uint64_t gas = 0;
	uint64_t totalGas = 0;
    uint64_t gasSize = outTx.data().size() + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();
	std::map<std::string, int64_t> toAddrs;
	for(const auto & item : companyDividend)
	{
		toAddrs.insert(make_pair(item.first, item.second));
	}
	toAddrs.insert(std::make_pair(global::ca::kTargetAddress, total - expend));
	toAddrs.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));

	if(GenerateGas(*txUtxo, toAddrs.size(),gasSize, gas) != 0)
	{
		ERRORLOG(" gas = 0 !");
		return -5;
	}

	if(GetInitAccountAddr() == addr)
	{
		gas = 0;
	}
	auto currentTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	getTransactionStartIdentity(height,currentTime,type);
	if(isGasTrade)
	{
		totalGas = gas;
	}else
	{
		expend = gas;
	}

	if(total < expend)
	{
		ERRORLOG("The total cost = {} is less than the cost = {}", total, expend);
		return -6;
	}

	outTx.set_time(currentTime);
	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	outTx.set_consensus(global::ca::kConsensus);
	outTx.set_type((uint32_t)global::ca::TxType::BONUS);
	// Fill vout
	uint64_t costo=0;
	uint64_t nodeDividend = 0;
	uint64_t totalClaim=0;
	std::cout << YELLOW << "Claim addr : Claim Amount" << RESET << std::endl;
	std::cout << "Commission: " << temp_commission_rate << std::endl;
	for(auto company : companyDividend)
	{
		costo=company.second*temp_commission_rate+0.5;
		nodeDividend+=costo;
		uint64_t award = company.second - costo;
		totalClaim+=award;
	}

	for(auto company : companyDividend)
	{
		costo=company.second*temp_commission_rate+0.5;
		std::string addr = company.first;
		uint64_t award = company.second - costo;
		CTxOutput *outputAddress = txUtxo->add_vout();
		outputAddress->set_addr(addr);
		outputAddress->set_value(award);
		DEBUGLOG("addr {}: award{}",company.first,company.second);
	}

	// caculate the value of new guoku award end
	CTxOutput *outputAddress = txUtxo->add_vout();
	outputAddress->set_addr(addr);
	if (firstChoose)
	{
		outputAddress->set_value(nodeDividend);
	}
	else
	{
		outputAddress->set_value(total - expend + nodeDividend);
	}
	
	if(isGasTrade)
	{
		CTxOutput * voutBurnAmount = txUtxo->add_vout();
		voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		voutBurnAmount->set_value(0);
	}else
	{
		CTxOutput * voutBurnAmount = txUtxo->add_vout();
		voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		voutBurnAmount->set_value(gas);
	}

	std::cout << addr << ":" << nodeDividend << std::endl;
	totalClaim+=nodeDividend;
	if(totalClaim == 0)
	{
		ERRORLOG("The claim amount is 0");
		return -12;
	}

	std::string serializedUtxoHash = Getsha256Hash(txUtxo->SerializeAsString());
	for (auto & owner : setTxOwners)
	{	
		if (TxHelper::addMultipleSigns(owner, *txUtxo) != 0)
		{
			return -13;
		}
	}

	if(isGasTrade)
	{
		std::vector<std::string> fromaddr;
		fromaddr.push_back(gasTrade.first);
		
		uint64_t total = 0;
		std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
		
		std::multimap<std::string, std::string> fromAddr_assetType;
		fromAddr_assetType.insert({gasTrade.first,gasTrade.second});
		ret = FindUtxo(fromAddr_assetType,TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
		if (ret != 0)
		{
			ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
			ret -= 700;
			return ret;
		}
		if (outputUtxosSet.empty())
		{
			ERRORLOG(RED "Utxo is empty!" RESET);
			return -14;
		}

		CTxUtxos * transactionUtxo1 = outTx.add_utxos();

		transactionUtxo1->set_assettype(gasTrade.second);
		transactionUtxo1->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE);// other to pay utxo
		outTx.set_independence(global::ca::TX_INDEPENDENCE_TRUE);
		//Fill Vin
		std::set<std::string> setTxOwners;
		for (auto & utxo : outputUtxosSet)
		{
			setTxOwners.insert(utxo.addr);
		}
		if (setTxOwners.empty())
		{
			ERRORLOG(RED "Tx owner is empty!" RESET);
			return -15;
		}

		uint32_t n = 0;

		transactionUtxo1->add_owner(gasTrade.first);
		CTxInput * vin = transactionUtxo1->add_vin();
		for (auto & utxo : outputUtxosSet)
		{
			if (gasTrade.first == utxo.addr)
			{
				CTxPrevOutput * prevOutput = vin->add_prevout();
				prevOutput->set_hash(utxo.hash);
				prevOutput->set_n(utxo.n);
			}
		}
		vin->set_sequence(n++);

		std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
		std::string signature;
		std::string pub;
		if (TxHelper::Sign(gasTrade.first, vinHashSerialized, signature, pub) != 0)
		{
			ERRORLOG("sign fail");
			return -16;
		}

		CSign * vinSign = vin->mutable_vinsign();
		vinSign->set_sign(signature);
		vinSign->set_pub(pub);


		CTxOutput * vout = transactionUtxo1->add_vout();
		vout->set_addr(gasTrade.first);
		vout->set_value(total - totalGas);

		CTxOutput * burnOutput = transactionUtxo1->add_vout();
		burnOutput->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		burnOutput->set_value(totalGas);


		std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
		for (auto & owner : setTxOwners)
		{		
			if (TxHelper::addMultipleSigns(owner,*transactionUtxo1) != 0)
			{
				ERRORLOG("addd mutil sign fail");
				return -17;
			}
		}

	}

	// Determine whether dropshipping is default or local dropshipping

	auto calculate_all_hash = [](const CTransaction& outTx) {
		std::string allHash;
		for (const auto& txUtxo : outTx.utxos()) {
			for (int i = 0; i < txUtxo.vin_size(); i++) {
				auto vin = txUtxo.vin(i);
				for (int j = 0; j < vin.prevout_size(); j++) {
					auto txPrevOutput = vin.prevout(j);
					allHash += txPrevOutput.hash();
				}
			}
		}
		allHash += std::to_string(outTx.time());
		return allHash;
	};

	std::string id;
	DEBUGLOG("self hash : {}",calculate_all_hash(outTx));
	ret = get_block_packager(id, calculate_all_hash(outTx), outTx.time(), TxHelper::SelectLocalSelectionSigner(outTx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -18;
	}

	outTx.set_identity(id);
	
	std::string txHash = Getsha256Hash(outTx.SerializeAsString());
	outTx.set_hash(txHash);

	return 0;
}

int TxHelper::make_evm_deploy_contract_transaction(CTransaction &outTx, std::vector<std::string> &dirtyContract,
											   const std::pair<std::string, std::string> &gasTrade, TxHelper::vrfAgentType &type, EvmHost &host,
											   evmc_message &message, bool isFindUtxo, const std::string &encodedInfo,
											   std::function<int(CTransaction &, std::string &)> signFunction)
{
    std::string sender = evm_utils::evm_addr_to_string(message.sender);
    std::string recipient = evm_utils::evm_addr_to_string(message.recipient);
    nlohmann::json txInfoJson;
    txInfoJson[Evmone::contractVersionId] = 0;
    txInfoJson[Evmone::contractSenderKeyName_] = sender;
    txInfoJson[Evmone::contractVmKeyName] = global::ca::VmType::EVM;
  	txInfoJson[Evmone::contractRecipientKeyNameStr] = recipient;
    txInfoJson[Evmone::contract_input_key_name] = evm_utils::BytesToString(host.code) ;

    // 不记录blockTimestamp到交易体，由打包者决定
    txInfoJson[Evmone::contract_block_timestamp_key_name] = 0;
    txInfoJson[Evmone::contractBlockPrevRandaoKey] = evm_utils::evmc_uint256be_to_uint32(host.tx_context.block_prev_randao);


	// TODO: 过渡期安全系数 - 用于弥补预估Gas与实际执行Gas的差异
	// 后续需改为用户自定义系数（最低1.5倍），当前硬编码为1.5用于测试验证
	constexpr double kGasEstimationSafetyRatio = 1.5;

	// 先用原始gas计算baseFee（与验证侧一致），安全系数稍后应用
	int64_t gasCost = static_cast<int64_t>(host.gas_cost);

	// 添加日志以便观察预估Gas与实际执行Gas的差异及系数放大效果
	DEBUGLOG("Gas estimation with safety ratio: tx_type=DEPLOY, raw_gas={}, safety_ratio={}",
	         host.gas_cost, kGasEstimationSafetyRatio);

	std::string new_baseFee;
    if(VerifyContractBaseFee(sender, gasCost,new_baseFee) != 0){
        ERRORLOG("VerifyContractBaseFee fail!!!");
        return -3;
    }
    txInfoJson["baseFee"] = new_baseFee;

	// VerifyContractBaseFee会修改gasCost(乘以fee倍数)，这里再应用安全系数
	gasCost = static_cast<int64_t>(gasCost * kGasEstimationSafetyRatio);

	// DEBUGLOG("======= baseFee : {}",txInfoJson["baseFee"].get<std::string>());

    Evmone::invokedContract(host, dirtyContract);
    int ret = Evmone::fillDeployOutTransaction(sender ,global::ca::kVirtualDeploymentContractAddress,host.coinTransfersInProgress,gasTrade,
										txInfoJson, gasCost, outTx, type, encodedInfo, isFindUtxo);
	if (ret != 0)
    {
		ERRORLOG("fillDeployOutTransaction fail ret : {}", ret);
		if (ret == TxHelper::kWaitingPendingUtxo)
			return TxHelper::kWaitingPendingUtxo;
		return ret - 1000;
	}

	if(signFunction != nullptr)
	{
		ret = signFunction(outTx, sender);
		if (ret!= 0){
			errorL("sig fial %s", ret);
			return -2;
		}
		std::string txHash = Getsha256Hash(outTx.SerializeAsString());
		outTx.set_hash(txHash);
	}

	return 0;
}

static int RefreshContractDispatcherIdentity(CTransaction& tx)
{
	// 合约交易分发者恢复为按时段确定性轮转。特殊合约交易在补充
	// utxo/vout/independence 后仍要重新写入 identity 和 hash，避免发送
	// 的交易体保留旧身份。
	tx.clear_hash();
	tx.clear_signature();
	tx.clear_selection_vrf();

	std::string identity;
	int ret = get_contract_distribution_manager(tx, identity, TxHelper::SelectLocalSelectionSigner(tx));
	if (ret != 0)
	{
		ERRORLOG("get_contract_distribution_manager fail ret: {}", ret);
		return ret;
	}
	tx.set_identity(identity);
	return 0;
}

expected<int> TxHelper::makeEvmCallContractTransaction(CTransaction &outTx, std::vector<std::string> &dirtyContract,
											 const std::pair<std::string, std::string> &gasTrade,
											 TxHelper::vrfAgentType &type, EvmHost &host,
											 evmc_message &message, const std::string &strInput,
											 const uint64_t contractTransfer, const std::string &toAddr, bool isFindUtxo,
											 const std::string &encodedInfo,
											 std::function<int(CTransaction &, std::string &)> signFunction,bool isFlowOutGasTrade)
{
    std::string sender = evm_utils::evm_addr_to_string(message.sender);
    std::string recipient = evm_utils::evm_addr_to_string(message.recipient);
    nlohmann::json txInfoJson;
    txInfoJson[Evmone::contractVersionId] = 0;
    txInfoJson[Evmone::contractSenderKeyName_] = sender;
    txInfoJson[Evmone::contractRecipientKeyNameStr] = recipient;
    txInfoJson[Evmone::contractVmKeyName] = global::ca::VmType::EVM;
    txInfoJson[Evmone::contract_input_key_name] = strInput;
    txInfoJson[Evmone::contractTransferKeyLabel] = contractTransfer;
    txInfoJson[Evmone::contractDeployerKeyAlias] = toAddr;


	// TODO: 过渡期安全系数 - 用于弥补预估Gas与实际执行Gas的差异
	// 后续需改为用户自定义系数（最低1.5倍），当前硬编码为1.5用于测试验证
	constexpr double kGasEstimationSafetyRatio = 1.5;

	// 先用原始gas计算baseFee（与验证侧一致），安全系数稍后应用
	int64_t gasCost = static_cast<int64_t>(host.gas_cost);

	// 添加日志以便观察预估Gas与实际执行Gas的差异及系数放大效果
	DEBUGLOG("Gas estimation with safety ratio: tx_type=CALL, raw_gas={}, safety_ratio={}",
	         host.gas_cost, kGasEstimationSafetyRatio);

	std::string new_baseFee ;
    if(VerifyContractBaseFee(sender, gasCost,new_baseFee) != 0){
        ERRORLOG("VerifyContractBaseFee fail!!!");
        return PERROR(MEM::CONTRACT_NONCE_FAIL,"VerifyContractBaseFee fail");
    }

    txInfoJson["baseFee"] = new_baseFee;

	// VerifyContractBaseFee会修改gasCost(乘以fee倍数)，这里再应用安全系数
	gasCost = static_cast<int64_t>(gasCost * kGasEstimationSafetyRatio);

	if(signFunction == nullptr)
	{
    	txInfoJson[Evmone::contractOutputKey] = host.output;
	}

    // 不记录blockTimestamp到交易体，由打包者决定
    txInfoJson[Evmone::contract_block_timestamp_key_name] = 0;
    txInfoJson[Evmone::contractBlockPrevRandaoKey] = evm_utils::evmc_uint256be_to_uint32(host.tx_context.block_prev_randao);

    Evmone::invokedContract(host, dirtyContract);
	
	bool isMappingTransaction = false;
	std::string asset_type;
	if (ca_algorithm::GetAsseTypeByContractAddr(recipient, asset_type) == 0)
	{
		std::map<std::string, TxHelper::ProposalInfo> assetMap;
		{
			DBReadWriter db;
			std::vector<std::string> ASSERT_TYPES;
			auto dbRet = db.getAssetType(ASSERT_TYPES);
			if(dbRet == DBStatus::DB_NOT_FOUND)
			{
				return PERROR(MEM::INVALID_ASSET_TYPE,"assetMap error :{}",dbRet);
			}
			else if(dbRet != DBStatus::DB_SUCCESS)
			{
				ERRORLOG("VoteCache error -1, getAssetType error, error num:{}", dbRet);
				return PERROR(MEM::INVALID_ASSET_TYPE,"db error");
			}

			int ret = -1;
			for(const auto& t: ASSERT_TYPES)
			{
				TxHelper::ProposalInfo info;
				ret = ca_algorithm::GetProposalInfo(t, info);   
				if(ret == 0)
				{
					assetMap.insert(std::make_pair(t, info));
				}
			}
		}

		DEBUGLOG("mapHandleFunction start contractAddr:{}", recipient);
		for (const auto &asset : assetMap)
		{
			if (asset.second.ContractAddr == recipient)
			{
				int ret = Evmone::mapHandleFunction({sender, asset_type}, gasTrade.second,strInput, recipient, sender, outTx, txInfoJson,encodedInfo,host,message,isFindUtxo, isMappingTransaction,isFlowOutGasTrade);
				if (ret != 0)
				{
					DEBUGLOG("mapHandleFunction fail!!!, ret:{}", ret);
					return PERROR(MEM::EVM_ASSERT_MAP_ERROR,"mapHandleFunction ret:{}",ret);
				}
				break;
			}
		}
	}


	int ret = Evmone::fillCallOutTransaction(sender, toAddr, host.coinTransfersInProgress,gasTrade, txInfoJson, gasCost, outTx, type,
                                	encodedInfo,isFindUtxo);
    if (ret != 0)
    {
        ERRORLOG("fillCallOutTransaction fail ret: {}", ret);
        if (ret == TxHelper::kWaitingPendingUtxo)
            return PERROR(MEM::PENDING_UTXO_WAIT, "pending UTXO unavailable");
        return PERROR(MEM::EVM_MAKE_TRNAS_FAIL,"fillCallOutTransaction ret: {}",ret); 
    }
	if (isMappingTransaction)
	{
		auto txUtxo = outTx.mutable_utxos()->begin();
		if (ca_algorithm::GetFlowTxType(txInfoJson) == ca_algorithm::FlowTxType::FlowInTx)
		{
			// txUtxo->add_owner(sender);
			txUtxo->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_FALSE);//pay gas utxo is true
			txUtxo->set_assettype(asset_type);
			CTxOutput *voutBurnAmount = txUtxo->add_vout();
			voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
			voutBurnAmount->set_value(0);
			outTx.set_independence(global::ca::TX_INDEPENDENCE_FALSE);

			ret = RefreshContractDispatcherIdentity(outTx);
			if (ret != 0)
			{
				return PERROR(MEM::EVM_UNKONW_BAD_ERROR, "refresh contract dispatcher identity failed ret:{}", ret);
			}

			if (signFunction != nullptr)
			{
				ret = signFunction(outTx, sender);
				if (ret != 0)
				{
					errorL("sig fial %s", ret);
					return PERROR(MEM::EVM_UNKONW_BAD_ERROR,"sig fail");
				}
				std::string txHash = Getsha256Hash(outTx.SerializeAsString());
				outTx.set_hash(txHash);
			}
			else
			{
				std::string txHash = Getsha256Hash(outTx.SerializeAsString());
				outTx.set_hash(txHash);
			}
			return 0;
		}
	}

	if(signFunction != nullptr)
	{
		ret = signFunction(outTx, sender);
		if (ret!= 0){
			errorL("sig fial %s", ret);
		  	return PERROR(MEM::EVM_UNKONW_BAD_ERROR,"sig fail");
		}
		std::string txHash = Getsha256Hash(outTx.SerializeAsString());
		outTx.set_hash(txHash);
	}
	return 0;
}

expected<int> TxHelper::createEvmDeployContractTransactionRequest(uint64_t height, CTransaction &outTx, const std::pair<std::string, std::string> &gasTrade, std::vector<std::string> &dirtyContract,
												 TxHelper::vrfAgentType &type, std::string &code,
												 const std::string &from, uint64_t transfer, const std::string &to,
												 const std::string &encodedInfo, bool isFindUtxo , bool isRpc )
{

	if(!isRpc)
	{
		Account launchAccount;
		if(MagicSingleton<AccountManager>::GetInstance()->FindAccount(from, launchAccount) != 0)
		{
			std::cout<<RED << "Failed to find account:"<<from << RESET << std::endl;
			ERRORLOG("Failed to find account {}", from);
			return PERROR(MEM::NOT_FOUND_ACCOUNT);
		}
	}

    EvmHost host;
    code.erase(std::remove_if(code.begin(), code.end(), ::isspace), code.end());
    host.code = evm_utils::StringTobytes(code);
    if (code.empty())
    {
        ERRORLOG("fail to convert contract code to hex format");
        return PERROR(MEM::INVALID_EVM_BTYEPCODE,"code is empty");
    }

    int64_t blockTimestamp = evmEnvironment::calculateBlockTimestamp(3);
    if (blockTimestamp < 0)
    {
        return PERROR(MEM::GET_TIME_FAIL,"calculateBlockTimestamp get time fail:{}",blockTimestamp);
    }
	int64_t blockPrevRandao = evmEnvironment::blockPrevRandaoCalculator(from, gasTrade.second, isFindUtxo);
	if (blockPrevRandao == kWaitingPendingUtxo)
	{
		return PERROR(MEM::PENDING_UTXO_WAIT, "pending UTXO unavailable during prev_randao calculation");
	}
	if (blockPrevRandao < 0)
	{
		return PERROR(MEM::EVM_PREVRANDA_FAIL);
	}

    int64_t blockNumber = 0;
    try
    {
        blockNumber = Util::convertUnsigned64ToSigned64(height);
    }
    catch (const std::exception& e)
    {
        ERRORLOG("{}", e.what())
        return PERROR(MEM::EVM_UNKONW_BAD_ERROR,"what:{}",e.what());
    }

    if (blockNumber < 0)
    {
        return PERROR(MEM::EVM_BLOCK_NUM_ERROR,"block number:{}",blockNumber);
    }

    evmc_message message{};
	int ret = 0;
	ret = Evmone::DeployContract(from, host, message, to, blockTimestamp,
									 blockPrevRandao,blockNumber, gasTrade.second);
	
	if (ret != 0)
	{
        ERRORLOG("failed to deploy contract! The error code is:{}", ret);
        return PERROR(MEM::EVM_DEPLOY_FAIL,"ret:{}",ret);
    }

	int (*ptr)(CTransaction&, const std::string&);
	if(isRpc)
	{
		ptr = nullptr;
	}
	else
	{
		ptr = SigTx;
	}

    ret = TxHelper::make_evm_deploy_contract_transaction(outTx, dirtyContract,gasTrade,
                                                     type, host, message, isFindUtxo, encodedInfo, ptr);
    if(ret != 0)
    {
        ERRORLOG("Failed to create DeployContract transaction! The error code is:{}", ret);
        if (ret == kWaitingPendingUtxo)
            return PERROR(MEM::PENDING_UTXO_WAIT, "pending UTXO unavailable");
        return PERROR(MEM::EVM_MAKE_TRNAS_FAIL,"ret:{}",ret);
    }
    // RPC requests are finalized after the externally signed transaction is
    // returned; local menu/test transactions are already signed and hashed.
    if (!isRpc && !pending_tx::FinalizeReservedTransaction(outTx))
    {
        ERRORLOG("Failed to finalize DeployContract pending reservation, tx:{}", outTx.hash());
        return PERROR(MEM::EVM_MAKE_TRNAS_FAIL, "pending reservation finalize failed");
    }
    return 0;
}

int TxHelper::createEvmCallContractTransactionRequest(const std::string &from, const std::string &toAddr, const std::string &strInput,
 									 const std::string& encodedInfo, const std::pair<std::string, std::string> &gasTrade,
                                     uint64_t height, CTransaction &outTx, TxHelper::vrfAgentType &type,
                                     const uint64_t contractTransfer,
                                     std::vector<std::string> &dirtyContract, const std::string &to,
                                     bool isFindUtxo ,bool isRpc,bool isFlowOutGasTrade)
{
	if(!isRpc)
	{
		Account launchAccount;
		if(MagicSingleton<AccountManager>::GetInstance()->FindAccount(from, launchAccount) != 0)
		{
			ERRORLOG("Failed to find account {}", from);
			return -1;
		}
	}


    EvmHost host;
    evmc::bytes contractCode;
	std::string _recipient = evm_utils::evm_addr_to_string(evm_utils::convertStringToEvmAddress(to));

    if (evm_utils::GetContractCode(to, contractCode) != 0)
    {
        ERRORLOG("fail to get contract code");
		DEBUGLOG("GetContractCode CreateCallCOntractTraction");
		return -2;
	}
    host.code = contractCode;
    int64_t blockTimestamp = evmEnvironment::calculateBlockTimestamp(3);
    if (blockTimestamp < 0)
    {
        return -3;
    }


	std::string inputPart = strInput.substr(0, 8);

	std::string gasType_;
	gasType_ = gasTrade.second;

	std::string _assetType = "";
	if(inputPart == "7c405325" && isFlowOutGasTrade == false && ca_algorithm::GetAsseTypeByContractAddr(_recipient, _assetType) == 0)
	{//越出

		//说明提案没有撤销
		if(ca_algorithm::GetAssetTypeIsValid(_assetType) == EXIT_SUCCESS){
			gasType_ = _assetType;
		}else{
			ERRORLOG("After revoking a proposal, you must use other types of gas payment");
			return -4;
		}
	}


	int64_t blockPrevRandao = 0;
	blockPrevRandao = evmEnvironment::blockPrevRandaoCalculator(from, gasType_, isFindUtxo);
	if (blockPrevRandao == kWaitingPendingUtxo)
	{
		return kWaitingPendingUtxo;
	}
	if (blockPrevRandao < 0)
	{
		return -4;
	}

    int64_t blockNumber = 0;
    try
    {
        blockNumber = Util::convertUnsigned64ToSigned64(height);
    }
    catch (const std::exception& e)
    {
        ERRORLOG("{}", e.what())
        return -5;
    }

    if (blockNumber < 0)
    {
        return -6;
    }

    evmc_message message{};
	int ret = 0;
	ret = Evmone::CallContract(from, strInput, host,
	                               contractTransfer, to, message, blockTimestamp, blockPrevRandao, blockNumber,gasType_);
	if (ret != 0)
    {
        ERRORLOG("Evmone failed to call contract! ret : {}", ret);
        return - 300;
    }

	int (*ptr)(CTransaction&, const std::string&);
	if(isRpc)
	{
		ptr = nullptr;
	}
	else
	{
		ptr = SigTx;
	}


   auto  ret1 = makeEvmCallContractTransaction(outTx, dirtyContract, gasTrade,type, host, message, strInput,
                                         contractTransfer, toAddr, isFindUtxo, encodedInfo, ptr,isFlowOutGasTrade);
    if (ret1.isOk() == false)
    {
        ERRORLOG("Failed to create CallContract transaction! The error code  is:{},The error message is:{}", ret1.Errors().first, ret1.Errors().second);
        if (ret1.Errors().first == make_error(MEM::PENDING_UTXO_WAIT).code)
            return kWaitingPendingUtxo;
        return -10000;
    }

    // RPC requests are finalized after the externally signed transaction is
    // returned; local menu/test transactions are already signed and hashed.
    if (!isRpc && !pending_tx::FinalizeReservedTransaction(outTx))
    {
        ERRORLOG("Failed to finalize CallContract pending reservation, tx:{}", outTx.hash());
        return -10000;
    }

    return 0;
}

int TxHelper::evmCallContractTransactionCreationRequest(const std::string &from, const std::string &toAddr,
												   const std::string &strInput, const std::string &encodedInfo, const std::pair<std::string, std::string> &gasTrade,
												   uint64_t height, CTransaction &outTx, TxHelper::vrfAgentType &type,
												   const uint64_t contractTransfer,
												   std::vector<std::string> &dirtyContract, const std::string &to,
												   bool isFindUtxo, bool isRpc)

{
	EvmHost host;
    evmc::bytes contractCode;
	if (evm_utils::GetContractCode(to, contractCode) != 0)
    {
        ERRORLOG("fail to get contract code");
        return -1;
    }
    host.code = contractCode;

	int64_t blockTimestamp = evmEnvironment::calculateBlockTimestamp(3);
    if (blockTimestamp < 0)
    {
        return -2;
    }

	int64_t blockPrevRandao = 64;
	if (blockPrevRandao < 0)
	{
		return -3;
	}

	int64_t blockNumber = 0;
    try
    {
        blockNumber = Util::convertUnsigned64ToSigned64(height);
    }
    catch (const std::exception& e)
    {
        ERRORLOG("{}", e.what())
        return -4;
    }

    if (blockNumber < 0)
    {
        return -5;
    }

	evmc_message message{};
	int ret = Evmone::callContractRpcRequest(from, strInput, host,
									   contractTransfer, to, message, blockTimestamp, blockPrevRandao, blockNumber, gasTrade.second);
	if (ret != 0)
    {
        ERRORLOG("Evmone failed to call contract! ret : {}", ret);
        return -300;
    }

	{
		std::string sender = evm_utils::evm_addr_to_string(message.sender);
		std::string recipient = evm_utils::evm_addr_to_string(message.recipient);
		nlohmann::json txInfoJson;
		txInfoJson[Evmone::contractVersionId] = 0;
		txInfoJson[Evmone::contractSenderKeyName_] = sender;
		txInfoJson[Evmone::contractRecipientKeyNameStr] = recipient;
		txInfoJson[Evmone::contractVmKeyName] = global::ca::VmType::EVM;
		txInfoJson[Evmone::contract_input_key_name] = strInput;
		txInfoJson[Evmone::contractTransferKeyLabel] = contractTransfer;
		txInfoJson[Evmone::contractDeployerKeyAlias] = toAddr;

		txInfoJson[Evmone::contractOutputKey] = host.output;

		// 不记录blockTimestamp到交易体，由打包者决定
		txInfoJson[Evmone::contract_block_timestamp_key_name] = 0;
		txInfoJson[Evmone::contractBlockPrevRandaoKey] = evm_utils::evmc_uint256be_to_uint32(host.tx_context.block_prev_randao);

		//outTx.set_type(global::ca::kTxSign);
		nlohmann::json data;
		data["txInfo"] = txInfoJson;
		std::string s = data.dump();
		outTx.set_data(s);		
	}

	return 0;
}

int TxHelper::addMultipleSigns(const std::string & addr, CTxUtxos &utxo)
{
	if (!isValidAddress(addr))
	{
		return -1;
	}

	CTxUtxos copyTransactionUtxo = utxo;
	copyTransactionUtxo.clear_multisign();

	std::string serializeTransactionUtxoRequest = Getsha256Hash(copyTransactionUtxo.SerializeAsString());
	std::string signature;
	std::string pub;
	if(TxHelper::Sign(addr, serializeTransactionUtxoRequest, signature, pub) != 0)
	{
		return -2;
	}

	CSign * multiSign = utxo.add_multisign();
	multiSign->set_sign(signature);
	multiSign->set_pub(pub);

	return 0;
}

int TxHelper::addVerifySign(const std::string & addr, CTransaction &tx)
{
	if (!isValidAddress(addr))
	{
		ERRORLOG("illegal address {}", addr);
		return -1;
	}

	CTransaction copyTx = tx;

	copyTx.clear_hash();
	copyTx.clear_signature();

	std::string serTx = copyTx.SerializeAsString();
	if(serTx.empty())
	{
		ERRORLOG("fail to serialize trasaction");
		return -2;
	}

	std::string message = Getsha256Hash(serTx);

	std::string signature;
	std::string pub;
	int ret = TxHelper::Sign(addr, message, signature, pub);
	if (ret != 0)
	{
		ERRORLOG("fail to sign message, ret :{}", ret);
		return -3;
	}

	DEBUGLOG("-------------------add verify sign addr = {} --------------------------",addr);

	CSign * verifySign = tx.add_signature();
	verifySign->set_sign(signature);
	verifySign->set_pub(pub);
	
	return 0;
}

int TxHelper::Sign(const std::string & addr, 
					const std::string & message, 
                    std::string & signature, 
					std::string & pub)
{
	if (addr.empty() || message.empty())
	{
		ERRORLOG("empt addr or message");
		std::cout << RED << "Empty addr or message" << RESET << std::endl;
		return -1;
	}

	Account account;
	if(MagicSingleton<AccountManager>::GetInstance()->FindAccount(addr ,account) != 0)
	{
		ERRORLOG("account {} doesn't exist", addr);
		std::cout << RED << "Account " << addr << " doesn't exist" << RESET << std::endl;
		return -2;
	}

	if(!account.Sign(message,signature))
	{
		ERRORLOG("signature failed");
		std::cout << RED << "Signature failed" << RESET << std::endl;
		return -3;
	}

	pub = account.GetPubStr();
	return 0;
}

bool TxHelper::requiresAgent(const std::vector<std::string> & fromAddr)
{
	bool shouldUseAgent = true;
	for(auto& owner : fromAddr)
	{
		//  If the transaction owner cannot be found in all accounts of the node, it indicates that it is issued on behalf
		if (owner == MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr())
		{
			shouldUseAgent = false;
		}
	}

	return shouldUseAgent;

}

bool TxHelper::requiresAgent(const CTransaction &tx)
{
	std::set<std::string> ownerAddrs;
	for(const auto& utxo : tx.utxos())
	{
		for(const auto& owner : utxo.owner())
		{
			ownerAddrs.insert(owner);
		}
	}

	if(std::find(ownerAddrs.begin(), ownerAddrs.end(),tx.identity()) == ownerAddrs.end())
	{
		return true;
	}
	
	return false;
}

bool TxHelper::checkTransactionTimeout(const uint64_t & txTime, const uint64_t & timeout,const uint64_t & preHeight)
{
	if(txTime <= 0)
	{
		ERRORLOG("tx time = {} ", txTime);
		return false;
	}
    DBReader dbReader;
    std::vector<std::string> blockHashes;
	auto ret = dbReader.getBlockHashesByBlockHeight(preHeight, preHeight, blockHashes);
    if (DBStatus::DB_SUCCESS != ret)
    {
		if(DBStatus::DB_NOT_FOUND != ret)
		{
			ERRORLOG("can't getBlockHashesByBlockHeight, DBStatus::DB_NOT_FOUND");
			return false;
		}
		uint64_t top = 0;
    	dbReader.getBlockTop(top);
        ERRORLOG("can't getBlockHashesByBlockHeight, fail!!!,top:{}, preHeight:{}",top, preHeight);
        return false;
    }

    std::vector<CBlock> blocks;

    for (auto &hash : blockHashes)
    {
        std::string blockStr;
        if(DBStatus::DB_SUCCESS != dbReader.getBlockByBlockHash(hash, blockStr))
		{
			ERRORLOG("getBlockByBlockHash error block hash = {} ", hash);
			return false;
		}

        CBlock block;
        if(!block.ParseFromString(blockStr))
		{
			ERRORLOG("block parse from string fail = {} ", blockStr);
			return false;
		}
        blocks.push_back(block);
    }

	std::sort(blocks.begin(), blocks.end(), [](const CBlock& x, const CBlock& y){ return x.time() < y.time(); });
	CBlock resultBlock = blocks[blocks.size() - 1];

	if(resultBlock.time() <= 0)
	{
		ERRORLOG("block time = {}  ", resultBlock.time());
		return false;
	}

	uint64_t resultTime = abs(int64_t(txTime - resultBlock.time()));
    if (resultTime > timeout * 1000000)
    {
		DEBUGLOG("vrf Issuing transaction More than 30 seconds time = {}, tx time= {}, top = {} ", resultTime, txTime, preHeight);
        return true;
    }
    return false;
}

TxHelper::vrfAgentType TxHelper::get_vrf_agent_type(const CTransaction &tx, uint64_t &preHeight)
{
	//The type of contract-related transactions is set to vrf
	global::ca::TxType txType = (global::ca::TxType)tx.type();
	if (global::ca::TxType::DEPLOY == txType || global::ca::TxType::CALL == txType)
	{
		return TxHelper::vrfAgentType::vrfAgentType_vrf;
	}
	std::set<std::string> owners;
	for(const auto& utxo : tx.utxos())
	{
		for(const auto& owner : utxo.owner())
		{
			owners.insert(owner);
		}
	}

	//The transaction time is verified to distinguish the agent type of the transaction
	if(TxHelper::checkTransactionTimeout(tx.time(),global::ca::TX_TIMEOUT_MIN, preHeight) == false)
	{	
		if(std::find(owners.begin(), owners.end(), tx.identity()) == owners.end())
		{
			return TxHelper::vrfAgentType::vrfAgentType_vrf;
		}
		return TxHelper::vrfAgentType::vrfAgentType_defalut;
	}
	else
	{
		if(std::find(owners.begin(), owners.end(), tx.identity()) == owners.end())
		{
			return TxHelper::vrfAgentType::vrfAgentType_local;
		}
		else
		{
			return TxHelper::vrfAgentType::vrfAgentType_defalut;
		}
	}
	DEBUGLOG("get_vrf_agent_type tx vrf agent type is vrfAgentType_defalut");
	return TxHelper::vrfAgentType::vrfAgentType_defalut;
}

void TxHelper::getTransactionStartIdentity(const uint64_t &height, const uint64_t &currentTime, TxHelper::vrfAgentType &type)
{
	type = vrfAgentType_vrf;
	return;

}

std::string TxHelper::fetchIdentityNodes()
{
	uint64_t chainHeight = 0;
    if(!BlockHelper::getChainHeight(chainHeight))
    {
        return "";
    }
	std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(chainHeight <= global::ca::MIN_UNSTAKE_HEIGHT)
    {
		return defaultAddr;
	}
	
	bool canReward= VerifyBonusAddr(defaultAddr);
	//int64_t stakeTime = ca_algorithm::GetPledgeTimeByAddr(defaultAddr, global::ca::StakeType::STAKE_TYPE_NODE);
	if (canReward)
	{
		return defaultAddr;
	}
	return "";
}

std::string TxHelper::SelectLocalSelectionSigner(const CTransaction& tx)
{
	// For selection proofs we want an account that is both:
	// 1. one of the transaction owners, and
	// 2. actually loaded on the local node.
	// This keeps the chooser identity tied to the business initiator instead of
	// silently falling back to an unrelated local default account.
	std::set<std::string> owners;
	for (const auto& utxo : tx.utxos())
	{
		for (const auto& owner : utxo.owner())
		{
			if (!owner.empty())
			{
				owners.insert(owner);
			}
		}
	}

	for (const auto& owner : owners)
	{
		if (MagicSingleton<AccountManager>::GetInstance()->IsExist(owner))
		{
			return owner;
		}
	}

	// eth_sendRawTransaction / MetaMask transactions are authorized by the RLP
	// signature, so the wallet private key is intentionally not present in the
	// node AccountManager. In that case the local node acts as the relayer and
	// produces the project ECVRF proof with its default account; verifiers only
	// accept this fallback for raw transactions that carry the relayer's chain
	// endorsement.
	const std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
	if (!defaultAddr.empty() && MagicSingleton<AccountManager>::GetInstance()->IsExist(defaultAddr))
	{
		return defaultAddr;
	}

	return "";
}

int TxHelper::fetchIdentityNodes(TxHelper::vrfAgentType &type,
								 const std::string &txData,
								 const uint64_t txTime,
								 std::string &identity,
								 const std::string& selectorAddr)
{
	int ret = get_block_packager(identity, txData, txTime, selectorAddr);
	if(ret != 0)
	{
		return -1;
	}

	return 0;
}

std::string TxHelper::GetEligibleNodes(){
	std::vector<Node> nodelist = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    std::vector<std::string> result_node;
    for (const auto &node : nodelist)
    {
        bool canReward= VerifyBonusAddr(node.address);

       // int64_t stakeTime = ca_algorithm::GetPledgeTimeByAddr(node.address, global::ca::StakeType::STAKE_TYPE_NODE);
        if (canReward)
        {
            result_node.push_back(node.address);
        }
    }
	auto getNextNumber=[&](int limit) ->int {
	  	std::random_device seed;
	 	std::ranlux48 engine(seed());
	 	std::uniform_int_distribution<int> u(0, limit-1);
	 	return u(engine);
	};
    if(result_node.size()==0){
		ERRORLOG("GetEligibleNodes:result_node is empty");
        return "";
    }

    
	DEBUGLOG("GetEligibleNodes: node size: {}",result_node.size());
	int rumdom=getNextNumber(result_node.size());
	DEBUGLOG("GetEligibleNodes: rumdom: {}",rumdom);
    
	return result_node[rumdom];
}

int TxHelper::createLockTransaction(const std::string & fromAddr,
										uint64_t lockAmount,
										uint64_t height,
										TxHelper::LockType lockType,
										CTransaction & outTx,
										std::vector<TxHelper::Utxo> & outVin,
										TxHelper::vrfAgentType &type ,const std::pair<std::string,std::string>& gasTrade,bool isGasTrade, bool isFindUtxo,
										const std::string& encodedInfo)
{
	//  Check parameters
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> allsetOutUtxos;
	uint64_t totalGas = 0;
	std::vector<std::string> addressVector;
	std::string currencyType = global::ca::ASSET_TYPE_OHI;
	addressVector.push_back(fromAddr);
	int ret = Check(addressVector,currencyType,height);
	if(ret != 0)
	{
		ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
		ret -= 100;
		return ret;
	}

	if (!isValidAddress(fromAddr))
	{
		ERRORLOG(RED "From address invlaid!" RESET);
		return -1;
	}

	if(lockAmount < global::ca::LOCK_AMOUNT * global::ca::kDecimalNum)
	{
		std::cout << "Lock amount must be greater than or equal " << global::ca::kDecimalNum << std::endl;
		return -3;
	}

	std::string strLockType;
	if (lockType == TxHelper::LockType::kLock_Node)
	{
		strLockType = global::ca::kLockTypeNet;
	}
	else
	{
		ERRORLOG(RED "Unknown lock type!" RESET);
		return -4;
	}

	DBReader dbReader;
	std::vector<std::string> stake_unspent_outputs;
    auto dbret = dbReader.getLockAddrUtxo(fromAddr,global::ca::ASSET_TYPE_OHI,stake_unspent_outputs);
	if(dbret != DBStatus::DB_NOT_FOUND)
	{
		std::cout << "There has been a lock transaction before !" << std::endl;
		return -5;
	}
	uint64_t expend = lockAmount;
	//  Find utxo
	uint64_t total = 0;

	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;

	std::multimap<std::string, std::string> fromAddr_currencyType;
	fromAddr_currencyType.insert({addressVector[0],currencyType});
	ret = FindUtxo(fromAddr_currencyType, TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
	if (ret != 0)
	{
		ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
		ret -= 200;
		return ret;
	}

	if (outputUtxosSet.empty())
	{
		ERRORLOG(RED "Utxo is empty!" RESET);
		return -6;
	}
	allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());

	outTx.Clear();
	CTxUtxos * txUtxo = outTx.add_utxos();
	txUtxo->set_assettype(global::ca::ASSET_TYPE_OHI);
	//  Fill Vin
	std::set<std::string> setTxOwners;
	for (auto & utxo : outputUtxosSet)
	{
		setTxOwners.insert(utxo.addr);
	}
	
	if (setTxOwners.size() != 1)
	{
		ERRORLOG(RED "Tx owner is invalid!" RESET);
		return -7;
	}

	for (auto & owner : setTxOwners)
	{
		txUtxo->add_owner(owner);
		uint32_t n = 0;
		CTxInput * vin = txUtxo->add_vin();
		for (auto & utxo : outputUtxosSet)
		{
			if (owner == utxo.addr)
			{
				CTxPrevOutput * prevOutput = vin->add_prevout();
				prevOutput->set_hash(utxo.hash);
				prevOutput->set_n(utxo.n);
			}
		}
		vin->set_sequence(n++);

		std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
		std::string signature;
		std::string pub;
		if (TxHelper::Sign(owner, vinHashSerialized, signature, pub) != 0)
		{
			return -8;
		}

		CSign * vinSign = vin->mutable_vinsign();
		vinSign->set_sign(signature);
		vinSign->set_pub(pub);
	}

	nlohmann::json txInfo;
	txInfo["lockType"] = strLockType;
	txInfo["lockAmount"] = lockAmount;

	nlohmann::json data;
	data["txInfo"] = txInfo;
	outTx.set_data(data.dump());
	outTx.set_note(encodedInfo);
	//outTx.set_type(global::ca::kTxSign);	

	uint64_t gas = 0;
    uint64_t gasSize = outTx.data().size() + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();

	//  Calculate total expenditure
	std::map<std::string, int64_t> toAddr;
	toAddr.insert(std::make_pair(global::ca::VIRTUAL_LOCK_ADDRESS, lockAmount));
	toAddr.insert(std::make_pair(fromAddr, total - expend));
	toAddr.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
	
	if(GenerateGas(*txUtxo, toAddr.size(),gasSize,gas) != 0)
	{
		ERRORLOG(" gas = 0 !");
		return -9;
	}
	if(GetInitAccountAddr() == fromAddr)
	{
        gas = 0;
    }

	auto currentTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	getTransactionStartIdentity(height,currentTime,type);

	if(isGasTrade)
	{
		totalGas += gas;
	}
	else
	{
		expend +=  gas; 
	}

	if(total < expend)
	{
		ERRORLOG("The total cost = {} is less than the cost = {}", total, expend);
		return -10;
	}

	CTxOutput * vout = txUtxo->add_vout(); 
	vout->set_addr(global::ca::VIRTUAL_LOCK_ADDRESS);
	vout->set_value(lockAmount);

	CTxOutput * voutSourceAddress = txUtxo->add_vout();
	voutSourceAddress->set_addr(fromAddr);
	voutSourceAddress->set_value(total - expend);

	if(isGasTrade)
	{
		CTxOutput * voutBurnAmount = txUtxo->add_vout();
		voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		voutBurnAmount->set_value(0);
	}
	else
	{
		CTxOutput * voutBurnAmount = txUtxo->add_vout();
		voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		voutBurnAmount->set_value(gas);
	}

	std::string serializedUtxoHash = Getsha256Hash(txUtxo->SerializeAsString());
	for (auto & owner : setTxOwners)
	{	
		if (TxHelper::addMultipleSigns(owner, *txUtxo) != 0)
		{
			return -11;
		}
	}

	if(isGasTrade)
	{
		std::vector<std::string> fromaddr;
		fromaddr.push_back(gasTrade.first);
		int ret = Check(fromaddr,gasTrade.second,height);
		if(ret != 0)
		{
			ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
			ret -= 100;
			return ret;
		}
		
		uint64_t total = 0;
		std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
		
		std::multimap<std::string, std::string> fromAddr_currencyType;
		fromAddr_currencyType.insert({gasTrade.first,gasTrade.second});
		ret = FindUtxo(fromAddr_currencyType,TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
		if (ret != 0)
		{
			ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
			ret -= 200;
			return ret;
		}
		if (outputUtxosSet.empty())
		{
			ERRORLOG(RED "Utxo is empty!" RESET);
			return -5;
		}
		allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());
		
		CTxUtxos * transactionUtxo1 = outTx.add_utxos();
		transactionUtxo1->set_assettype(gasTrade.second);
		transactionUtxo1->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE);// other to pay utxo
		outTx.set_independence(global::ca::TX_INDEPENDENCE_TRUE);
		//Fill Vin
		std::set<std::string> setTxOwners;
		for (auto & utxo : outputUtxosSet)
		{
			setTxOwners.insert(utxo.addr);
		}
		if (setTxOwners.empty())
		{
			ERRORLOG(RED "Tx owner is empty!" RESET);
			return -6;
		}

		uint32_t n = 0;

		transactionUtxo1->add_owner(gasTrade.first);
		CTxInput * vin = transactionUtxo1->add_vin();
		for (auto & utxo : outputUtxosSet)
		{
			if (gasTrade.first == utxo.addr)
			{
				CTxPrevOutput * prevOutput = vin->add_prevout();
				prevOutput->set_hash(utxo.hash);
				prevOutput->set_n(utxo.n);
			}
		}
		vin->set_sequence(n++);

		std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
		std::string signature;
		std::string pub;
		if (TxHelper::Sign(gasTrade.first, vinHashSerialized, signature, pub) != 0)
		{
			ERRORLOG("sign fail");
			return -8;
		}

		CSign * vinSign = vin->mutable_vinsign();
		vinSign->set_sign(signature);
		vinSign->set_pub(pub);

		if(total < totalGas)
		{
			ERRORLOG("The total cost = {} is less than the cost = {}", total, totalGas);
			return -9;
		}

		CTxOutput * vout = transactionUtxo1->add_vout();
		vout->set_addr(gasTrade.first);
		vout->set_value(total - totalGas);

		CTxOutput * burnOutput = transactionUtxo1->add_vout();
		burnOutput->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		burnOutput->set_value(totalGas);

		std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
		for (auto & owner : setTxOwners)
		{		
			if (TxHelper::addMultipleSigns(owner,*transactionUtxo1) != 0)
			{
				ERRORLOG("addd mutil sign fail");
				return -11;
			}
		}

	}



	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	outTx.set_time(currentTime);
	outTx.set_consensus(global::ca::kConsensus);
	outTx.set_type((uint32_t)global::ca::TxType::LOCK);

	auto calculate_all_hash = [](const CTransaction& outTx) {
		std::string allHash;
		for (const auto& txUtxo : outTx.utxos()) {
			for (int i = 0; i < txUtxo.vin_size(); i++) {
				auto vin = txUtxo.vin(i);
				for (int j = 0; j < vin.prevout_size(); j++) {
					auto txPrevOutput = vin.prevout(j);
					allHash += txPrevOutput.hash();
				}
			}
		}
		allHash += std::to_string(outTx.time());
		return allHash;
	};
	
	DEBUGLOG("self hash:{}", calculate_all_hash(outTx));
	
	std::string identity;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(outTx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(outTx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -12;
	}
	DEBUGLOG("Tx identity:{}", identity);
	outTx.set_identity(identity);

	std::cout << "LockTx gas: " << gas << std::endl;
	std::string txHash = Getsha256Hash(outTx.SerializeAsString());
	outTx.set_hash(txHash);

	return 0;

}


int TxHelper::createUnlockTransactionRequest(const std::string& fromAddr,const std::string& utxoHash,uint64_t height,
		CTransaction &outTx, std::vector<TxHelper::Utxo> & outVin,
		TxHelper::vrfAgentType &type ,const std::pair<std::string,std::string>& gasTrade,bool isGasTrade, bool isFindUtxo, const std::string& encodedInfo)
{
	//  Check parameters
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> allsetOutUtxos;
	std::vector<std::string> addressVector;
	addressVector.push_back(fromAddr);
	//need read from database
	std::string currencyType = global::ca::ASSET_TYPE_OHI;
	int ret = Check(addressVector, currencyType, height);
	if(ret != 0)
	{
		ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
		ret -= 100;
		return ret;
	}

	if (!isValidAddress(fromAddr))
	{
		ERRORLOG(RED "FromAddr is not normal  addr." RESET);
		return -1;
	}


	uint64_t stakeAmount = 0;
	ret = IsQualifiedToUnLock(fromAddr, utxoHash, stakeAmount, global::ca::ASSET_TYPE_OHI);
	if(ret != 0)
	{
		ERRORLOG(RED "FromAddr is not qualified to unstake! The error code is {}." RESET, ret);
		ret -= 200;
		return ret;
	}	

	//  Find utxo
	// uint64_t total = 0;
	// std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
	// //  The number of utxos to be searched here needs to be reduced by 1 \
	// because a VIN to be redeem is from the pledged utxo, so just look for 99
	
	// std::multimap<std::string, std::string> fromAddr_currencyType;
	// fromAddr_currencyType.insert(std::make_pair(fromAddr, currencyType));
	// ret = FindUtxo(fromAddr_currencyType, TxHelper::MAX_VIN_SIZE - 1, total, outputUtxosSet, isFindUtxo); 
	// if (ret != 0)
	// {
	// 	ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
	// 	ret -= 300;
	// 	return ret;
	// }

	// if (outputUtxosSet.empty())
	// {
	// 	ERRORLOG(RED "Utxo is empty!" RESET);
	// 	return -2;
	// }
	// allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());

	outTx.Clear();

	CTxUtxos * txUtxo = outTx.add_utxos();
	txUtxo->set_assettype(currencyType);
	//  Fill Vin
	std::set<std::string> setTxOwners;
	setTxOwners.insert(fromAddr);
	// for (auto & utxo : outputUtxosSet)
	// {
	// 	setTxOwners.insert(utxo.addr);
	// }
	if (setTxOwners.empty())
	{
		ERRORLOG(RED "Tx owner is empty!" RESET);
		return -3;
	}

	{
		//  Fill vin
		txUtxo->add_owner(fromAddr);
		CTxInput* txin = txUtxo->add_vin();
		txin->set_sequence(0);
		CTxPrevOutput* prevout = txin->add_prevout();
		prevout->set_hash(utxoHash);
		prevout->set_n(1);

		std::string vinHashSerialized = Getsha256Hash(txin->SerializeAsString());
		std::string signature;
		std::string pub;
		if (TxHelper::Sign(fromAddr, vinHashSerialized, signature, pub) != 0)
		{
			return -4;
		}

		CSign * vinSign = txin->mutable_vinsign();
		vinSign->set_sign(signature);
		vinSign->set_pub(pub);
	}


	// for (auto & owner : setTxOwners)
	// {
	// 	txUtxo->add_owner(owner);
	// 	uint32_t n = 1;
	// 	CTxInput * vin = txUtxo->add_vin();
	// 	for (auto & utxo : outputUtxosSet)
	// 	{
	// 		if (owner == utxo.addr)
	// 		{
	// 			CTxPrevOutput * prevOutput = vin->add_prevout();
	// 			prevOutput->set_hash(utxo.hash);
	// 			prevOutput->set_n(utxo.n);
	// 		}
	// 	}
	// 	vin->set_sequence(n++);

	// 	std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
	// 	std::string signature;
	// 	std::string pub;
	// 	if (TxHelper::Sign(owner, vinHashSerialized, signature, pub) != 0)
	// 	{
	// 		return -5;
	// 	}

	// 	CSign * vinSign = vin->mutable_vinsign();
	// 	vinSign->set_sign(signature);
	// 	vinSign->set_pub(pub);
	// }

	nlohmann::json txInfo;
	txInfo["unLockUtxo"] = utxoHash;

	nlohmann::json data;
	data["txInfo"] = txInfo;
	outTx.set_data(data.dump());
	outTx.set_note(encodedInfo);
	//outTx.set_type(global::ca::kTxSign);	
	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);

	// uint64_t gas = 0;
	// uint64_t gasSize = outTx.data().size() + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();
	// //The filled quantity only participates in the calculation and does not affect others
	// std::map<std::string, int64_t> toAddr;
	// toAddr.insert(std::make_pair(global::ca::VIRTUAL_LOCK_ADDRESS, stakeAmount));
	// toAddr.insert(std::make_pair(fromAddr, total));
	// toAddr.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
	
	// if(GenerateGas(*txUtxo, toAddr.size(), gasSize, gas) != 0)
	// {
	// 	ERRORLOG(" gas = 0 !");
	// 	return -6;
	// }
	// if(GetInitAccountAddr() == fromAddr)
	// {
    //     gas = 0;
    // }

	// //  Calculate total expenditure
	// uint64_t expend = 0;
	// uint64_t totalGas = 0;

	auto currentTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	getTransactionStartIdentity(height,currentTime,type);

	// if(isGasTrade)
	// {
	// 	totalGas =  gas;
	// }else
	// {
	// 	expend += gas;
	// }

	// // Judge whether there is enough money
	// if(total < expend)
	// {
	// 	ERRORLOG("The total cost = {} is less than the cost = {}", total, expend);
	// 	return -7;
	// }

	//  Fill vout
	CTxOutput* outputAddress = txUtxo->add_vout();
	outputAddress->set_addr(fromAddr);      	//  Release the pledge to my account number
	outputAddress->set_value(stakeAmount);

	// outputAddress = txUtxo->add_vout();
	// outputAddress->set_addr(fromAddr);  		//  Give myself the rest
	// outputAddress->set_value(total - expend);

	// if(isGasTrade)
	// {
	// 	CTxOutput * voutBurnAmount = txUtxo->add_vout();
	// 	voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
	// 	voutBurnAmount->set_value(0);
	// }
	// else
	// {
	// 	CTxOutput * voutBurnAmount = txUtxo->add_vout();
	// 	voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
	// 	voutBurnAmount->set_value(gas);
	// }

	std::string serializedUtxoHash = Getsha256Hash(txUtxo->SerializeAsString());
	for (auto & owner : setTxOwners)
	{	
		if (TxHelper::addMultipleSigns(owner, *txUtxo) != 0)
		{
			return -8;
		}
	}

	// if(isGasTrade)
	// {
	// 	std::vector<std::string> fromaddr;
	// 	fromaddr.push_back(gasTrade.first);
	// 	int ret = Check(fromaddr,gasTrade.second,height);
	// 	if(ret != 0)
	// 	{
	// 		ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
	// 		ret -= 100;
	// 		return ret;
	// 	}
		
	// 	uint64_t total = 0;
	// 	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
		
	// 	std::multimap<std::string, std::string> fromAddr_currencyType;
	// 	fromAddr_currencyType.insert({gasTrade.first,gasTrade.second});
	// 	ret = FindUtxo(fromAddr_currencyType,TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
	// 	if (ret != 0)
	// 	{
	// 		ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
	// 		ret -= 200;
	// 		return ret;
	// 	}
	// 	if (outputUtxosSet.empty())
	// 	{
	// 		ERRORLOG(RED "Utxo is empty!" RESET);
	// 		return -5;
	// 	}
	// 	allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());

	// 	CTxUtxos * transactionUtxo1 = outTx.add_utxos();

	// 	transactionUtxo1->set_assettype(gasTrade.second);
	// 	transactionUtxo1->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE);// other to pay utxo
	// 	outTx.set_independence(global::ca::TX_INDEPENDENCE_TRUE);
	// 	//Fill Vin
	// 	std::set<std::string> setTxOwners;
	// 	for (auto & utxo : outputUtxosSet)
	// 	{
	// 		setTxOwners.insert(utxo.addr);
	// 	}
	// 	if (setTxOwners.empty())
	// 	{
	// 		ERRORLOG(RED "Tx owner is empty!" RESET);
	// 		return -6;
	// 	}

	// 	uint32_t n = 0;

	// 	transactionUtxo1->add_owner(gasTrade.first);
	// 	CTxInput * vin = transactionUtxo1->add_vin();
	// 	for (auto & utxo : outputUtxosSet)
	// 	{
	// 		if (gasTrade.first == utxo.addr)
	// 		{
	// 			CTxPrevOutput * prevOutput = vin->add_prevout();
	// 			prevOutput->set_hash(utxo.hash);
	// 			prevOutput->set_n(utxo.n);
	// 		}
	// 	}
	// 	vin->set_sequence(n++);

	// 	std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
	// 	std::string signature;
	// 	std::string pub;
	// 	if (TxHelper::Sign(gasTrade.first, vinHashSerialized, signature, pub) != 0)
	// 	{
	// 		ERRORLOG("sign fail");
	// 		return -8;
	// 	}

	// 	CSign * vinSign = vin->mutable_vinsign();
	// 	vinSign->set_sign(signature);
	// 	vinSign->set_pub(pub);


	// 	CTxOutput * vout = transactionUtxo1->add_vout();
	// 	vout->set_addr(gasTrade.first);
	// 	vout->set_value(total - totalGas);

	// 	CTxOutput * burnOutput = transactionUtxo1->add_vout();
	// 	burnOutput->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
	// 	burnOutput->set_value(totalGas);


	// 	std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
	// 	for (auto & owner : setTxOwners)
	// 	{		
	// 		if (TxHelper::addMultipleSigns(owner,*transactionUtxo1) != 0)
	// 		{
	// 			ERRORLOG("addd mutil sign fail");
	// 			return -11;
	// 		}
	// 	}

	// }

	outTx.set_time(currentTime);
	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	outTx.set_consensus(global::ca::kConsensus);
	outTx.set_type((uint32_t)global::ca::TxType::UNLOCK);

	if (outTx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -1;
    }

    if (outTx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -2;
    }

	uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(outTx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
	db_reader.getNonceByAddr(outTx.utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
		ERRORLOG("get NonceByAddr error");
		ERRORLOG("addr:{}", outTx.utxos(0).owner(0));
		return -10;
	}
	outTx.set_nonce(nonce);
	pending_tx::DraftGuard pendingDraft;
	if (!pendingDraft.Begin(outTx, nonce)) {
		ERRORLOG("reserve pending nonce/UTXO failed");
		return -16;
	}
	outTx.set_nonce(pendingDraft.nonce());

	auto calculate_all_hash = [](const CTransaction& outTx) {
		std::string allHash;
		for (const auto& txUtxo : outTx.utxos()) {
			for (int i = 0; i < txUtxo.vin_size(); i++) {
				auto vin = txUtxo.vin(i);
				for (int j = 0; j < vin.prevout_size(); j++) {
					auto txPrevOutput = vin.prevout(j);
					allHash += txPrevOutput.hash();
				}
			}
		}
		allHash += std::to_string(outTx.time());
		return allHash;
	};
	
	DEBUGLOG("self hash:{}", calculate_all_hash(outTx));
	
	std::string identity;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(outTx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(outTx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -12;
	}
	DEBUGLOG("Tx identity:{}", identity);
	outTx.set_identity(identity);

	std::string txHash = Getsha256Hash(outTx.SerializeAsString());
	outTx.set_hash(txHash);
	if (!pendingDraft.Finalize(outTx)) {
		ERRORLOG("finalize pending transaction reservation failed");
		return -17;
	}

	return 0;
}


int TxHelper::CreateProposalTransaction(const std::string& fromAddr,             
            uint64_t height,CTransaction& outTx,TxHelper::vrfAgentType &type,
            const std::pair<std::string,std::string>& gasTrade, std::string& identifier, std::string& title,
            std::string& peerChainTokenAddr, uint64_t beinTime, uint64_t endTime, std::string& assetName, std::string& rate, 
			std::string& contractAddr, std::string& crossChainInvestmentContractAddr, global::ca::CrossChainTxType taskType, uint64_t minVote, bool isFindUtxo, const std::string& encodedInfo)
{
	if (!isValidAddress(fromAddr)) 
	{
		ERRORLOG(RED "From address invlaid!" RESET);
		return -1;
	}

	if(fromAddr != GetInitAccountAddr())
    {
		ERRORLOG("The default account is not the genesis account");
        return -2;
    }

	int ret = ca_algorithm::CheckProposaInfo(rate, contractAddr, crossChainInvestmentContractAddr, taskType, minVote, assetName, peerChainTokenAddr);
	if(ret != 0)
	{
		ERRORLOG("CheckProposaInfo error: {}", ret);
		return -3;
	}

	std::vector<std::string> fromaddr;
	fromaddr.push_back(gasTrade.first);
	ret = Check(fromaddr,gasTrade.second,height);
	if(ret != 0)
	{
		ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
		ret -= 100;
		return ret;
	}
	
	
	uint64_t total = 0;
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> allsetOutUtxos;
	std::multimap<std::string, std::string> fromAddr_currencyType;
	fromAddr_currencyType.insert({gasTrade.first,gasTrade.second});
	ret = FindUtxo(fromAddr_currencyType,TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
	if (ret != 0)
	{
		ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
		ret -= 200;
		return ret;
	}
	if (outputUtxosSet.empty())
	{
		ERRORLOG(RED "Utxo is empty!" RESET);
		return -5;
	}
	allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());

	CTxUtxos * transactionUtxo1 = outTx.add_utxos();

	transactionUtxo1->set_assettype(gasTrade.second);
	transactionUtxo1->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE);// other to pay utxo
	outTx.set_independence(global::ca::TX_INDEPENDENCE_TRUE);

	//Fill Vin
	std::set<std::string> setTxOwners;
	for (auto & utxo : outputUtxosSet)
	{
		setTxOwners.insert(utxo.addr);
	}
	if (setTxOwners.empty())
	{
		ERRORLOG(RED "Tx owner is empty!" RESET);
		return -6;
	}

	uint32_t n = 0;

	transactionUtxo1->add_owner(gasTrade.first);
	CTxInput * vin = transactionUtxo1->add_vin();
	for (auto & utxo : outputUtxosSet)
	{
		if (gasTrade.first == utxo.addr)
		{
			CTxPrevOutput * prevOutput = vin->add_prevout();
			prevOutput->set_hash(utxo.hash);
			prevOutput->set_n(utxo.n);
		}
	}
	vin->set_sequence(n++);


	int isEmpty = ca_algorithm::AssetTypeListIsEmpty();
	if(isEmpty < 0)
	{
		ERRORLOG("AssetTypeListIsEmpty error: {}", isEmpty);
		return -7;
	}

	nlohmann::json txInfo;
	txInfo["version"] = global::ca::KProposalInfoVersion;
	txInfo["beginTime"] = beinTime;
	txInfo["endTime"] = endTime;
	txInfo["expirationDate"] = UINT64_MAX;
	txInfo["exchangeRate"] = rate;
	txInfo["crossChainTxType"] = taskType;
	txInfo["tokenContractAddr"] = contractAddr;
	txInfo["crossChainInvestmentContractAddr"] = crossChainInvestmentContractAddr;
	txInfo["genesisToken"] = isEmpty;
	txInfo["minVoteNum"] = minVote;
	txInfo["title"] = title;
	txInfo["identifier"] = identifier;
	txInfo["peerChainTokenAddr"] = peerChainTokenAddr;

	std::string base64string = Base64Encode(assetName);
    std::cout << base64string << std::endl;
	txInfo["name"] = base64string;
	nlohmann::json data;
	data["txInfo"] = txInfo;
	outTx.set_data(data.dump());
	outTx.set_note(encodedInfo);
	//outTx.set_type(global::ca::kTxSign);	

	uint64_t gas = 0;
	uint64_t gasSize = outTx.data().size()  + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();

	std::map<std::string, int64_t> toAddr;
	toAddr.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
	toAddr.insert(std::make_pair(fromAddr, 0));
	if(GenerateGas(*transactionUtxo1, toAddr.size(),gasSize, gas) != 0)
	{
		ERRORLOG(" gas = 0 !");
		return -9;
	}
	if(GetInitAccountAddr() == fromAddr)
	{
        gas = 0;
    }
	
	if(total < gas)
	{
		ERRORLOG("The total cost = {} is less than the gas = {}", total, gas);
		return -10;
	}

	std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
	std::string signature;
	std::string pub;
	if (TxHelper::Sign(gasTrade.first, vinHashSerialized, signature, pub) != 0)
	{
		ERRORLOG("sign fail");
		return -8;
	}

	CSign * vinSign = vin->mutable_vinsign();
	vinSign->set_sign(signature);
	vinSign->set_pub(pub);

	CTxOutput * vout = transactionUtxo1->add_vout();
	vout->set_addr(gasTrade.first);
	vout->set_value(total - gas);

	CTxOutput * burnOutput = transactionUtxo1->add_vout();
	burnOutput->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
	burnOutput->set_value(gas);

	std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
	for (auto & owner : setTxOwners)
	{		
		if (TxHelper::addMultipleSigns(owner,*transactionUtxo1) != 0)
		{
			ERRORLOG("addd mutil sign fail");
			return -11;
		}
	}

	auto currentTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	if(currentTime - global::ca::KVrfVoteBeginTime > beinTime)
	{
		ERRORLOG("begin time error, current time:{}, begin time:{}", currentTime, beinTime);
		return -12;
	}

	getTransactionStartIdentity(height,currentTime,type);

	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	outTx.set_time(currentTime);
	outTx.set_consensus(global::ca::kConsensus);
	outTx.set_type((uint32_t)global::ca::TxType::PROPOSAL);

    if (outTx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -13;
    }

    if (outTx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -14;
    }

    uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(outTx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
        db_reader.getNonceByAddr(outTx.utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
        ERRORLOG("get NonceByAddr error");
        return -15;
	}
    outTx.set_nonce(nonce);
	pending_tx::DraftGuard pendingDraft;
	if (!pendingDraft.Begin(outTx, nonce)) {
		ERRORLOG("reserve pending nonce/UTXO failed");
		return -16;
	}
	outTx.set_nonce(pendingDraft.nonce());

	auto calculate_all_hash = [](const CTransaction& outTx) {
		std::string allHash;
		for (const auto& txUtxo : outTx.utxos()) {
			for (int i = 0; i < txUtxo.vin_size(); i++) {
				auto vin = txUtxo.vin(i);
				for (int j = 0; j < vin.prevout_size(); j++) {
					auto txPrevOutput = vin.prevout(j);
					allHash += txPrevOutput.hash();
				}
			}
		}
		allHash += std::to_string(outTx.time());
		return allHash;
	};
	
	DEBUGLOG("self hash:{}", calculate_all_hash(outTx));
	std::string identity;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(outTx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(outTx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -12;
	}
	DEBUGLOG("Tx identity:{}", identity);
	outTx.set_identity(identity);

	std::string txHash = Getsha256Hash(outTx.SerializeAsString());
	outTx.set_hash(txHash);
	if (!pendingDraft.Finalize(outTx)) {
		ERRORLOG("finalize pending transaction reservation failed");
		return -17;
	}

	return 0;
}


int TxHelper::CreateRevokeProposalTransaction(const std::string& fromAddr,             
            uint64_t height,CTransaction& outTx,TxHelper::vrfAgentType &type,
            const std::pair<std::string,std::string>& gasTrade, 
            uint64_t beinTime, uint64_t endTime, std::string proposalHash, uint64_t minVote, bool isFindUtxo, const std::string& encodedInfo)
{
	if (!isValidAddress(fromAddr)) 
	{
		ERRORLOG(RED "From address invlaid!" RESET);
		return -1;
	}

	if(fromAddr != GetInitAccountAddr())
    {
		ERRORLOG("The default account is not the genesis account");
        return -2;
    }

	std::vector<std::string> fromaddr;
	fromaddr.push_back(gasTrade.first);
	int ret = Check(fromaddr,gasTrade.second,height);
	if(ret != 0)
	{
		ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
		ret -= 100;
		return ret;
	}
	
	ret = ca_algorithm::GetAssetTypeIsValid(proposalHash);
	if(ret != 0)
	{
		ERRORLOG("GetAssetTypeIsValid error, error num:{}", ret);
		return -3;
	}
	
	ret = ca_algorithm::canBeRevoked(proposalHash);
	if(ret != 0)
	{
		ERRORLOG("canBeRevoked error, error num:{}", ret);
		return -4;
	}

	if(minVote < 1)
    {
        ERRORLOG("minVote mest more then 1, minVote:{}", minVote);
        return -7;
    }

	uint64_t total = 0;
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> allsetOutUtxos;
	std::multimap<std::string, std::string> fromAddr_currencyType;
	fromAddr_currencyType.insert({gasTrade.first,gasTrade.second});
	ret = FindUtxo(fromAddr_currencyType,TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
	if (ret != 0)
	{
		ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
		ret -= 200;
		return ret;
	}
	if (outputUtxosSet.empty())
	{
		ERRORLOG(RED "Utxo is empty!" RESET);
		return -5;
	}
	allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());

	CTxUtxos * transactionUtxo1 = outTx.add_utxos();

	transactionUtxo1->set_assettype(gasTrade.second);
	transactionUtxo1->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE);// other to pay utxo
	outTx.set_independence(global::ca::TX_INDEPENDENCE_TRUE);
	
	//Fill Vin
	std::set<std::string> setTxOwners;
	for (auto & utxo : outputUtxosSet)
	{
		setTxOwners.insert(utxo.addr);
	}
	if (setTxOwners.empty())
	{
		ERRORLOG(RED "Tx owner is empty!" RESET);
		return -6;
	}

	uint32_t n = 0;

	transactionUtxo1->add_owner(gasTrade.first);
	CTxInput * vin = transactionUtxo1->add_vin();
	for (auto & utxo : outputUtxosSet)
	{
		if (gasTrade.first == utxo.addr)
		{
			CTxPrevOutput * prevOutput = vin->add_prevout();
			prevOutput->set_hash(utxo.hash);
			prevOutput->set_n(utxo.n);
		}
	}
	vin->set_sequence(n++);

	nlohmann::json txInfo;
	txInfo["version"] = global::ca::KRevokeProposalInfoVersion;
	txInfo["beginTime"] = beinTime;
	txInfo["endTime"] = endTime;
	txInfo["proposalHash"] = proposalHash;
	txInfo["minVoteNum"] = minVote;
	nlohmann::json data;
	data["txInfo"] = txInfo;
	outTx.set_data(data.dump());
	outTx.set_note(encodedInfo);
	//outTx.set_type(global::ca::kTxSign);	

	uint64_t gas = 0;
	uint64_t gasSize = outTx.data().size()  + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();

	std::map<std::string, int64_t> toAddr;
	toAddr.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
	toAddr.insert(std::make_pair(fromAddr, 0));
	if(GenerateGas(*transactionUtxo1, toAddr.size(),gasSize, gas) != 0)
	{
		ERRORLOG(" gas = 0 !");
		return -9;
	}
	if(GetInitAccountAddr() == fromAddr)
	{
        gas = 0;
    }
	if(total < gas)
	{
		ERRORLOG("The total cost = {} is less than the gas = {}", total, gas);
		return -10;
	}

	std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
	std::string signature;
	std::string pub;
	if (TxHelper::Sign(gasTrade.first, vinHashSerialized, signature, pub) != 0)
	{
		ERRORLOG("sign fail");
		return -8;
	}

	CSign * vinSign = vin->mutable_vinsign();
	vinSign->set_sign(signature);
	vinSign->set_pub(pub);

	CTxOutput * vout = transactionUtxo1->add_vout();
	vout->set_addr(gasTrade.first);
	vout->set_value(total - gas);

	CTxOutput * burnOutput = transactionUtxo1->add_vout();
	burnOutput->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
	burnOutput->set_value(gas);

	std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
	for (auto & owner : setTxOwners)
	{		
		if (TxHelper::addMultipleSigns(owner,*transactionUtxo1) != 0)
		{
			ERRORLOG("addd mutil sign fail");
			return -11;
		}
	}

	auto currentTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	if(currentTime - global::ca::KVrfVoteBeginTime > beinTime)
	{
		ERRORLOG("begin time error");
		return -12;
	}

	getTransactionStartIdentity(height,currentTime,type);

	if (outTx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -13;
    }

    if (outTx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -14;
    }

    uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(outTx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
        db_reader.getNonceByAddr(outTx.utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
        ERRORLOG("get NonceByAddr error");
        return -15;
	}

    outTx.set_nonce(nonce);
	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	outTx.set_time(currentTime);
	outTx.set_consensus(global::ca::kConsensus);
	outTx.set_type((uint32_t)global::ca::TxType::REVOKEPROPOSAL);
	pending_tx::DraftGuard pendingDraft;
	if (!pendingDraft.Begin(outTx, nonce)) {
		ERRORLOG("reserve pending nonce/UTXO failed");
		return -16;
	}
	outTx.set_nonce(pendingDraft.nonce());

	auto calculate_all_hash = [](const CTransaction& outTx) {
		std::string allHash;
		for (const auto& txUtxo : outTx.utxos()) {
			for (int i = 0; i < txUtxo.vin_size(); i++) {
				auto vin = txUtxo.vin(i);
				for (int j = 0; j < vin.prevout_size(); j++) {
					auto txPrevOutput = vin.prevout(j);
					allHash += txPrevOutput.hash();
				}
			}
		}
		allHash += std::to_string(outTx.time());
		return allHash;
	};
	
	DEBUGLOG("self hash:{}", calculate_all_hash(outTx));
	
	std::string identity;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(outTx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(outTx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -12;
	}
	DEBUGLOG("Tx identity:{}", identity);
	outTx.set_identity(identity);

	std::string txHash = Getsha256Hash(outTx.SerializeAsString());
	outTx.set_hash(txHash);
	if (!pendingDraft.Finalize(outTx)) {
		ERRORLOG("finalize pending transaction reservation failed");
		return -17;
	}

	return 0;
}


int TxHelper::CreateVoteTransaction(const std::string& fromAddr,             
            uint64_t height,CTransaction& outTx,TxHelper::vrfAgentType &type,
            const std::pair<std::string,std::string>& gasTrade, 
            const std::string& voteHash, const int pollType, const global::ca::TxType& voteTxType, bool isFindUtxo, const std::string& encodedInfo)
{
	if (!isValidAddress(fromAddr)) 
	{
		ERRORLOG(RED "From address invlaid!" RESET);
		return -1;
	}

	std::vector<std::string> fromaddr;
	fromaddr.push_back(gasTrade.first);
	int ret = Check(fromaddr,gasTrade.second,height);
	if(ret != 0)
	{
		ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
		ret -= 100;
		return ret;
	}
	
	DBReadWriter db;
    std::vector<std::string> assertTypes;
    auto dbRet = db.getAssetType(assertTypes);
	if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("VoteCache error -1, getAssetType error, error num:{}", dbRet);
        return -2;
    }

	uint64_t lockValue = 0;
    if(assertTypes.size() == 1 && fromAddr == GetInitAccountAddr())
    {
        lockValue = 1;
    }
    else 
	{
		ret = ca_algorithm::GetLockValue(fromAddr, lockValue);
		if(ret != 0)
		{
			ERRORLOG("GetLockValue error, ret: {}", ret);
			return -3;
		}
	}

	auto currentTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	ret = ca_algorithm::CheckVoteTxInfo(voteHash, (uint32_t)voteTxType, pollType, currentTime);
	if(ret != 0)
	{
		ERRORLOG("CheckVoteTxInfo error, ret: {}", ret);
		return -4;
	}


	
	uint64_t total = 0;
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> outputUtxosSet;
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> allsetOutUtxos;
	std::multimap<std::string, std::string> fromAddr_currencyType;
	fromAddr_currencyType.insert({gasTrade.first,gasTrade.second});
	ret = FindUtxo(fromAddr_currencyType,TxHelper::MAX_VIN_SIZE, total, outputUtxosSet, isFindUtxo);
	if (ret != 0)
	{
		ERRORLOG(RED "FindUtxo failed! The error code is {}." RESET, ret);
		ret -= 200;
		return ret;
	}
	if (outputUtxosSet.empty())
	{
		ERRORLOG(RED "Utxo is empty!" RESET);
		return -5;
	}
	allsetOutUtxos.insert(outputUtxosSet.begin(),outputUtxosSet.end());

	CTxUtxos * transactionUtxo1 = outTx.add_utxos();

	transactionUtxo1->set_assettype(gasTrade.second);
	transactionUtxo1->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE);// other to pay utxo
	outTx.set_independence(global::ca::TX_INDEPENDENCE_TRUE);
	//Fill Vin
	std::set<std::string> setTxOwners;
	for (auto & utxo : outputUtxosSet)
	{
		setTxOwners.insert(utxo.addr);
	}
	if (setTxOwners.empty())
	{
		ERRORLOG(RED "Tx owner is empty!" RESET);
		return -6;
	}

	uint32_t n = 0;

	transactionUtxo1->add_owner(gasTrade.first);
	CTxInput * vin = transactionUtxo1->add_vin();
	for (auto & utxo : outputUtxosSet)
	{
		if (gasTrade.first == utxo.addr)
		{
			CTxPrevOutput * prevOutput = vin->add_prevout();
			prevOutput->set_hash(utxo.hash);
			prevOutput->set_n(utxo.n);
		}
	}
	vin->set_sequence(n++);

	nlohmann::json txInfo;
	txInfo["voteHash"] = voteHash;
	txInfo["voteTxType"] = (int)voteTxType;
	txInfo["voteType"] = pollType;
	txInfo["voteNumber"] = lockValue;
	nlohmann::json data;
	data["txInfo"] = txInfo;
	outTx.set_data(data.dump());
	outTx.set_note(encodedInfo);
	//outTx.set_type(global::ca::kTxSign);	

	uint64_t gas = 0;
	uint64_t gasSize = outTx.data().size()  + outTx.note().size() + outTx.reserve0().size() + outTx.reserve1().size();

	std::map<std::string, int64_t> toAddr;
	toAddr.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
	toAddr.insert(std::make_pair(fromAddr, 0));
	if(GenerateGas(*transactionUtxo1, toAddr.size(),gasSize, gas) != 0)
	{
		ERRORLOG(" gas = 0 !");
		return -9;
	}
    if(GetInitAccountAddr() == fromAddr)
	{
        gas = 0;
    }

	if(total < gas)
	{
		ERRORLOG("The total cost = {} is less than the gas = {}", total, gas);
		return -10;
	}

	std::string vinHashSerialized = Getsha256Hash(vin->SerializeAsString());
	std::string signature;
	std::string pub;
	if (TxHelper::Sign(gasTrade.first, vinHashSerialized, signature, pub) != 0)
	{
		ERRORLOG("sign fail");
		return -8;
	}

	CSign * vinSign = vin->mutable_vinsign();
	vinSign->set_sign(signature);
	vinSign->set_pub(pub);

	CTxOutput * vout = transactionUtxo1->add_vout();
	vout->set_addr(gasTrade.first);
	vout->set_value(total - gas);

	CTxOutput * burnOutput = transactionUtxo1->add_vout();
	burnOutput->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
	burnOutput->set_value(gas);

	std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
	for (auto & owner : setTxOwners)
	{		
		if (TxHelper::addMultipleSigns(owner,*transactionUtxo1) != 0)
		{
			ERRORLOG("addd mutil sign fail");
			return -11;
		}
	}

	getTransactionStartIdentity(height,currentTime,type);

	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	outTx.set_time(currentTime);
	outTx.set_consensus(global::ca::kConsensus);
	outTx.set_type((uint32_t)global::ca::TxType::VOTE);


	auto calculate_all_hash = [](const CTransaction& outTx) {
		std::string allHash;
		for (const auto& txUtxo : outTx.utxos()) {
			for (int i = 0; i < txUtxo.vin_size(); i++) {
				auto vin = txUtxo.vin(i);
				for (int j = 0; j < vin.prevout_size(); j++) {
					auto txPrevOutput = vin.prevout(j);
					allHash += txPrevOutput.hash();
				}
			}
		}
		allHash += std::to_string(outTx.time());
		return allHash;
	};
	
	DEBUGLOG("self hash:{}", calculate_all_hash(outTx));
	
	std::string identity;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(outTx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(outTx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -12;
	}
	DEBUGLOG("Tx identity:{}", identity);
	outTx.set_identity(identity);

	std::string txHash = Getsha256Hash(outTx.SerializeAsString());
	outTx.set_hash(txHash);

	return 0;

}



int TxHelper::CreateFundTransaction(const std::string& addr,
										uint64_t height,
										CTransaction& outTx,
										std::vector<TxHelper::Utxo> & outVin,
										TxHelper::vrfAgentType &type,const std::pair<std::string,std::string>& gasTrade,
										bool isGasTrade,bool isFindUtxo, const std::string& encodedInfo)
{
	if (!isValidAddress(addr))
	{
		ERRORLOG(RED "Default is not normal  addr." RESET);
		return -1;
	}


	std::map<std::string, TxHelper::ProposalInfo> assetMap;
    int ret = ca_algorithm::fetchAvailableAssetType(assetMap);
	if(ret != 0){
		ERRORLOG("Get available asset fail! ret : {}",ret);
		return -10;
	}

	DBReader dbReader; 
	uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(curTime);
	TxHelper::ProposalInfo null;
	// 原强制插入Vote，现改为OHI
	assetMap.insert({global::ca::ASSET_TYPE_OHI,null});

	std::map<std::string,uint64_t> assetTypeAmount;
	for(const auto& _assetType : assetMap){
		uint64_t gasAmount = 0;
		auto result = dbReader.getGasAmountByPeriod(period -1,_assetType.first,gasAmount);
		if(result != DBStatus::DB_SUCCESS && result != DBStatus::DB_NOT_FOUND){
			ERRORLOG("GetGasamountbyTimeType error!");
			return -9;
		}
		if(gasAmount != 0){
			assetTypeAmount.insert({_assetType.first,gasAmount});
		}
	}

	if(assetTypeAmount.empty()){
		ERRORLOG("There was no fund reward the day before!");
		return -999;
	}

	for(const auto& i : assetTypeAmount){
		std::cout << "-----------------------------------------" << std::endl;
		std::cout << "asset_type :" << i.first << "total fund amount :" << i.second << std::endl;
	}


	bool isLocked = false;
	bool isPackage = false;

	uint64_t retValue =  0;

	ret = CheckFundQualificationAndGetRewardAmount(addr, curTime,retValue);
	uint64_t totalLockedAmount = 0;
	if(ret != 0)
	{
		if(ret == -6){
			ERRORLOG( "You have already claimed the fund reward.",ret );
			return -998;
		}else{
			ERRORLOG( "Error in checking eligibility for receiving fund",ret );
			return -996;
		}
	}else{
		if(dbReader.getTotalLockedAmonut(totalLockedAmount) == DBStatus::DB_SUCCESS && totalLockedAmount != 0){
			DEBUGLOG("retValue : {}, totalLockedAmount : {}",retValue,totalLockedAmount);
		}else{
			ERRORLOG("Get total locked amount failed!");
		}
		if(retValue != 0 && totalLockedAmount != 0){
			isLocked = true;
		}
	}

	std::cout << "-----------------------------------------" << std::endl;
	std::cout << "node lockedAmount :" << retValue << "    totalLockedAmount :" << totalLockedAmount << "       rate :"<< (double(retValue) / double(totalLockedAmount)) <<std::endl;


	uint64_t times , count = 0;
	bool canReward = VerifyBonusAddr(addr);
	//int64_t stakeTime = ca_algorithm::GetPledgeTimeByAddr(addr, global::ca::StakeType::STAKE_TYPE_NODE);
	if (canReward)
	{
		DEBUGLOG("Meet the pledge qualifications.");
		if(dbReader.getPackagerCountByPeriod(period -1,addr,times) == DBStatus::DB_SUCCESS && 
			dbReader.getBlockNumberByPeriod(period -1,count) == DBStatus::DB_SUCCESS){
				DEBUGLOG("times : {}, count : {}",times,count);
		}else{
			ERRORLOG("Get addr package times failed!");
		
		}
		if(times !=0 && count != 0){
			isPackage = true;
		}
	}

	std::cout << "-----------------------------------------" << std::endl;
	std::cout << "node package count:" << times << "    total package count :" << "       rate :"  << (double(times) / double(count)) <<std::endl;
	std::cout << "-----------------------------------------" << std::endl;

    // complete fundTransaction
	if(!isPackage && !isLocked){
		ERRORLOG("Nodes are not eligible to claim fund");
		return -11;
	}

	std::map<std::string, uint64_t> lockedReward;
	std::map<std::string, uint64_t> packageReward;

	for(const auto& _assetType : assetTypeAmount){
		CTxUtxos* txUtxo = outTx.add_utxos();
		txUtxo->add_owner(addr);
		txUtxo->set_assettype(_assetType.first);

		if(isLocked){
			double rate = double(retValue) / double(totalLockedAmount);
			CTxOutput* vout =  txUtxo->add_vout();
			vout->set_addr(addr);
			uint64_t value = uint64_t(rate * _assetType.second * 0.5);
			vout->set_value(value);
			lockedReward.insert({_assetType.first,value});
			DEBUGLOG("isLocked");
		}

		if(isPackage){
			double rate = double(times) / double(count);
			CTxOutput* vout =  txUtxo->add_vout();
			vout->set_addr(addr);
			uint64_t value = uint64_t(rate * _assetType.second * 0.5);
			vout->set_value(value);
			packageReward.insert({_assetType.first,value});
			DEBUGLOG("isPackage");
		}

		std::string serializedUtxoHash = Getsha256Hash(txUtxo->SerializeAsString());
		if (TxHelper::addMultipleSigns(addr, *txUtxo) != 0)
		{
			return -8;
		}
	}

	nlohmann::json txInfo;
	txInfo["fundLockedAmount"] = lockedReward;
	txInfo["fundPackageAmount"] = packageReward;
	nlohmann::json data;
	data["txInfo"] = txInfo;
	outTx.set_data(data.dump());
	outTx.set_note(encodedInfo);
	//outTx.set_type(global::ca::kTxSign);
	
	getTransactionStartIdentity(height,curTime,type);
	outTx.set_time(curTime);
	outTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	outTx.set_consensus(global::ca::kConsensus);
	outTx.set_type((uint32_t)global::ca::TxType::FUND);

	auto calculate_all_hash = [](const CTransaction& outTx) {
		std::string allHash;
		for (const auto& txUtxo : outTx.utxos()) {
			for (int i = 0; i < txUtxo.vin_size(); i++) {
				auto vin = txUtxo.vin(i);
				for (int j = 0; j < vin.prevout_size(); j++) {
					auto txPrevOutput = vin.prevout(j);
					allHash += txPrevOutput.hash();
				}
			}
		}
		allHash += std::to_string(outTx.time());
		return allHash;
	};

	std::string id;
	DEBUGLOG("self hash : {}",calculate_all_hash(outTx));
	ret = get_block_packager(id, calculate_all_hash(outTx), outTx.time(), TxHelper::SelectLocalSelectionSigner(outTx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -13;
	}

	outTx.set_identity(id);

	std::string txHash = Getsha256Hash(outTx.SerializeAsString());
	outTx.set_hash(txHash);

	return 0;
}
