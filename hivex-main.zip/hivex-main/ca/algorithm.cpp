﻿#include "ca/algorithm.h"

#include <cstddef>
#include <cstdint>
#include <future>
#include <memory>
#include <algorithm>
#include <boost/multiprecision/cpp_bin_float.hpp>
#include <regex>
#include <set>
#include "ca/ca.h"
#include "ca/global.h"
#include "ca/contract.h"
#include "ca/contract_nonce_policy.h"
#include "ca/sync_block.h"
#include "ca/evm/evm_host.h"
#include "ca/transaction.h"
#include "ca/block_helper.h"
#include "ca/block_http_callback.h"
#include "ca/block_rate_probe.h"
#include "ca/bonus_addr_cache.h"

#include "common.h"
#include "common/genesis.h"
#include "commondata.h"
#include "db_api.h"
#include "eth/eth.h"
#include "eth_trans.h"
#include "logging.h"
#include "utils/console.h"
#include "utils/time_util.h"
#include "utils/contract_utils.h"
#include "utils/bench_mark.h"
#include "utils/magic_singleton.h"
#include "utils/account_manager.h"
#include "utils/base64.h"
#include "utils/pretty_print.h"
#include "ca/evm/evmEnvironment.h"
#include "ca/eth_trans.h"

#include "common/task_pool.h"
#include "include/scope_guard.h"
#include "packager_dispatch.h"
#include "ca/evm/evm_manager.h"
#include "utils/hex_code.h"
#include "utils/keccak_cryopp.hpp"
#include "ca/dispatchtx.h"
#include "common/genesis_helper.h"

#include <boost/multiprecision/cpp_int.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/multiprecision/cpp_dec_float.hpp>
#include "ca/address_status_cache.h"
#include <cmath>
#include <stdexcept>
#include <string>
#include <vector>

typedef boost::multiprecision::cpp_bin_float_50 cpp_bin_float;

namespace
{
int BuildBlockNonceView(const CBlock& block, std::map<std::string, uint64_t>& expected_nonces)
{
    std::vector<contract_nonce::Entry> entries;
    std::map<std::string, uint64_t> committed_nonces;
    DBReader db_reader;

    for (const auto& tx : block.txs())
    {
        // Malformed and special transactions remain the responsibility of the
        // existing transaction validators.
        if (tx.utxos_size() == 0 || tx.utxos(0).owner_size() == 0)
        {
            continue;
        }
        const std::string& address = tx.utxos(0).owner(0);
        if (committed_nonces.find(address) == committed_nonces.end())
        {
            uint64_t committed = 0;
            const auto status = db_reader.getNonceByAddr(address, committed);
            if (status != DBStatus::DB_SUCCESS && status != DBStatus::DB_NOT_FOUND)
            {
                ERRORLOG("getNonceByAddr error while building block nonce view, addr:{}", address);
                return -1;
            }
            committed_nonces.emplace(address, committed);
        }
        entries.push_back({tx.hash(), address, tx.nonce(), tx.time()});
    }

    const auto result = contract_nonce::ValidateCanonicalSequence(entries, committed_nonces, &expected_nonces);
    if (result != contract_nonce::ValidationResult::kOk)
    {
        ERRORLOG("block nonce sequence rejected, result:{}", static_cast<int>(result));
        return -2;
    }
    return 0;
}
} // namespace



static uint64_t GetLocalTimestampUsec()
{
    struct timeval tv;
    gettimeofday(&tv, nullptr);
    return tv.tv_sec * 1000000 + tv.tv_usec;
}

int ca_algorithm::fetchAbnormalSignAddrListByPeriod(uint64_t &curTime, std::map<std::string, double> &addr_percent, std::unordered_map<std::string, uint64_t> & addrSignCount)
{
    DBReader dbReader;
    std::vector<std::string> signatureAddresses;
    uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(curTime);
    if (DBStatus::DB_SUCCESS != dbReader.getSignAddrByPeriod(period - 1, signatureAddresses))
    {
        INFOLOG("getSignAddrByPeriod error period:{}", period - 1);
        return -1;
    }

    uint64_t signNumber = 0;
    uint64_t allSignNumber = 0;

    for(auto addr : signatureAddresses)
    {
        if (DBStatus::DB_SUCCESS != dbReader.getSignCountByPeriod(period - 1, addr, signNumber))
        {
            ERRORLOG("getSignCountByPeriod error period:{},addr:{}", period - 1, addr);
            return -2;
        }

        addrSignCount[addr] = signNumber;
        allSignNumber += signNumber;
    }
    
    if(allSignNumber != 0 && addrSignCount.size() != 0)
    {
        //每个人的平均工作量
        double average = static_cast<double>(allSignNumber) / addrSignCount.size();
        for(auto & addr_cnt : addrSignCount)
        {
            if((double)(addr_cnt.second) >= average)
            {
                continue;
            }
            addr_percent[addr_cnt.first] = ((double)addr_cnt.second/average);
        }
    }
    return 0;  
}

int64_t ca_algorithm::GetPledgeTimeByAddr(const std::string &addr, global::ca::StakeType stakeType, DBReader *dbReaderInstance)
{
    if (stakeType != global::ca::StakeType::STAKE_TYPE_NODE)
    {
        ERRORLOG("unknow pledge type");
        return -1;
    }
    DBReader dbReader;
    if (nullptr == dbReaderInstance)
    {
        dbReaderInstance = &dbReader;
    }

    std::string assetType;
    int ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
    if(ret != 0){
        ERRORLOG("Get Can BeRevoke AssetType fail!");
    }

    std::vector<std::string> pledgeUtxoList;
    ret = dbReader.getStakeUtxoByAddr(addr,assetType, pledgeUtxoList);
    if (DBStatus::DB_NOT_FOUND == ret)
    {
        TRACELOG("DB_NOT_FOUND");
        return 0;
    }
    else if (DBStatus::DB_SUCCESS != ret)
    {
        ERRORLOG("fail to query addr pledge");
        return -2;
    }

    std::vector<CTransaction> txs;
    CTransaction tx;
    std::string txRaw;
    std::string tmpPledgeType;
    for (auto &pledgeUtxoRef : pledgeUtxoList)
    {
        if (DBStatus::DB_SUCCESS != dbReader.getTransactionByHash(pledgeUtxoRef, txRaw))
        {
            ERRORLOG("faile to query trasaction");
            return -3;
        }
        tx.Clear();
        if (!tx.ParseFromString(txRaw))
        {
            ERRORLOG("trasaction parse fail");
            return -4;
        }

        if((global::ca::TxType)tx.type() != global::ca::TxType::TX)
        {
            try
            {
                nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                global::ca::TxType txType = (global::ca::TxType)tx.type();

                if (global::ca::TxType::STAKE != txType)
                {
                    continue;
                }

                nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                tmpPledgeType.clear();
                txInfo["stakeType"].get_to(tmpPledgeType);

                if (tmpPledgeType != global::ca::STAKE_TYPE_NET)
                {
                    continue;
                }
                txs.push_back(tx);
            }
            catch (...)
            {
                ERRORLOG("get pledge trasaction fail");
                return -5;
            }
        }
    }
    std::sort(txs.begin(), txs.end(),
              [](const CTransaction &tx1, const CTransaction &tx2)
              {
                  return tx1.time() < tx2.time();
              });

    uint64_t totalStakeAmount = 0;
    uint64_t lastTime = 0;

    for (auto &tx : txs)
    {
        for (auto &utxo : tx.utxos())
        {
            for(auto &vout : utxo.vout())
            {
                if (vout.addr() == global::ca::kTargetAddress)
                {
                    totalStakeAmount += vout.value();
                    lastTime = tx.time();
                    break;
                }
            }
        }
        if (totalStakeAmount >= global::ca::MIN_STAKE_AMOUNT)
        {
            break;
        }
    }

    if (totalStakeAmount < global::ca::MIN_STAKE_AMOUNT)
    {
        TRACELOG("node type pledge amount is {}", totalStakeAmount);
        return 0;
    }

    
    return lastTime;
}

std::string ca_algorithm::calculateTransactionHash(CTransaction tx)
{
    tx.clear_hash();
    tx.clear_signature();
    tx.clear_selection_vrf();
    return Getsha256Hash(tx.SerializeAsString());
}

std::string ca_algorithm::CalculateSlashEvidenceHash(const std::string &evidenceData)
{
    return Getsha256Hash(evidenceData);
}

std::string ca_algorithm::BuildSlashPunishmentId(const std::string &targetAddr,
                                                 const std::string &violationType,
                                                 uint32_t penaltyLevel,
                                                 const std::string &evidenceRefs)
{
    const std::string evidenceSetHash = Getsha256Hash(evidenceRefs);
    return Getsha256Hash(targetAddr + "|" + violationType + "|" +
                         std::to_string(penaltyLevel) + "|" + evidenceSetHash);
}

static bool ValidateSlashEvidencePayload(const std::string &violationType, const std::string &evidenceData, const std::string &txHash)
{
    nlohmann::json payload;
    try
    {
        payload = nlohmann::json::parse(evidenceData);
    }
    catch (const std::exception &e)
    {
        ERRORLOG("[SLASH] Invalid evidence payload json, hash:{}, error:{}", txHash, e.what());
        return false;
    }

    if (violationType == "DOUBLE_SIGN_VRF")
    {
        const std::string seed = payload.value("seed", "");
        const std::string existingSig = payload.value("existing_sig", "");
        const std::string newSig = payload.value("new_sig", "");
        const std::string existingSigHash = payload.value("existing_sig_hash", "");
        const std::string newSigHash = payload.value("new_sig_hash", "");
        if (seed.empty() || existingSig.empty() || newSig.empty() || existingSig == newSig)
        {
            ERRORLOG("[SLASH] Invalid DOUBLE_SIGN_VRF evidence payload, hash:{}", txHash);
            return false;
        }
        if ((!existingSigHash.empty() && existingSigHash != Getsha256Hash(existingSig)) ||
            (!newSigHash.empty() && newSigHash != Getsha256Hash(newSig)))
        {
            ERRORLOG("[SLASH] DOUBLE_SIGN_VRF signature hash mismatch, hash:{}", txHash);
            return false;
        }
        return true;
    }

    if (violationType == "DOUBLE_SIGN_BLOCK")
    {
        const uint64_t height = payload.value("height", 0);
        const std::string existingBlockHash = payload.value("existing_block_hash", "");
        const std::string newBlockHash = payload.value("new_block_hash", "");
        if (height == 0 || existingBlockHash.size() != 64 || newBlockHash.size() != 64 || existingBlockHash == newBlockHash)
        {
            ERRORLOG("[SLASH] Invalid DOUBLE_SIGN_BLOCK evidence payload, hash:{}", txHash);
            return false;
        }
        return true;
    }

    if (violationType == "LOW_SIGN_RATE")
    {
        const double signRate = payload.value("sign_rate", 1.0);
        const uint32_t signedCount = payload.value("signed_count", 0);
        const uint32_t validPeriods = payload.value("valid_periods", 0);
        if (validPeriods < 50 || signedCount > validPeriods || signRate < 0.0 || signRate > 1.0 ||
            signRate >= global::ca::kJailLowThreshold)
        {
            ERRORLOG("[SLASH] Invalid LOW_SIGN_RATE evidence payload, hash:{}", txHash);
            return false;
        }
        return true;
    }

    ERRORLOG("[SLASH] Unsupported evidence violation type for deterministic payload validation:{}, hash:{}",
             violationType, txHash);
    return false;
}

int ca_algorithm::ValidateSlashEvidenceTx(const CTransaction &tx, DBReader *dbReaderInstance)
{
    nlohmann::json dataJson;
    try
    {
        dataJson = nlohmann::json::parse(tx.data());
    }
    catch (const std::exception &e)
    {
        ERRORLOG("[SLASH] Invalid EVIDENCE tx data json, hash:{}, error:{}", tx.hash(), e.what());
        return -1;
    }

    const std::string targetAddr = dataJson.value("target_addr", "");
    const std::string violationType = dataJson.value("violation_type", "");
    const std::string evidenceHash = dataJson.value("evidence_hash", "");
    const std::string evidenceData = dataJson.value("evidence_data", "");

    if (targetAddr.empty() || violationType.empty() || evidenceHash.empty() || evidenceData.empty())
    {
        ERRORLOG("[SLASH] Invalid EVIDENCE tx: missing required fields, hash:{}", tx.hash());
        return -2;
    }

    if (!isValidAddress(targetAddr))
    {
        ERRORLOG("[SLASH] Invalid EVIDENCE tx target address:{}, hash:{}", targetAddr, tx.hash());
        return -3;
    }

    static const std::set<std::string> kValidViolationTypes = {
        "DOUBLE_SIGN_VRF", "DOUBLE_SIGN_BLOCK", "INVALID_BLOCK",
        "VRF_VERIFY_FAIL", "LOW_SIGN_RATE", "FREQUENT_DISCONNECT",
        "MALICIOUS_REPORTING"
    };
    if (kValidViolationTypes.find(violationType) == kValidViolationTypes.end())
    {
        ERRORLOG("[SLASH] Invalid EVIDENCE tx violation type:{}, hash:{}", violationType, tx.hash());
        return -4;
    }

    if (evidenceHash.size() != 64 || evidenceHash != ca_algorithm::CalculateSlashEvidenceHash(evidenceData))
    {
        ERRORLOG("[SLASH] Invalid EVIDENCE tx evidence hash, tx_hash:{}, evidence_hash:{}", tx.hash(), evidenceHash);
        return -5;
    }

    if (!ValidateSlashEvidencePayload(violationType, evidenceData, tx.hash()))
    {
        return -6;
    }

    if (tx.signature_size() < static_cast<int>(global::ca::kSlashEvidenceQuorum))
    {
        ERRORLOG("[SLASH] EVIDENCE tx has insufficient signatures: {} < {}, hash:{}",
                 tx.signature_size(), global::ca::kSlashEvidenceQuorum, tx.hash());
        return -7;
    }

    DBReader localReader;
    DBReader *reader = dbReaderInstance ? dbReaderInstance : &localReader;
    std::vector<std::string> stakeAddrs;
    auto stakeRet = reader->getStakeAddr(stakeAddrs);
    if (DBStatus::DB_SUCCESS != stakeRet || stakeAddrs.empty())
    {
        ERRORLOG("[SLASH] EVIDENCE tx cannot verify signer eligibility: stake list unavailable, hash:{}", tx.hash());
        return -8;
    }
    std::set<std::string> eligibleSigners(stakeAddrs.begin(), stakeAddrs.end());

    std::set<std::string> uniqueSigners;
    for (int i = 0; i < tx.signature_size(); ++i)
    {
        const CSign &sig = tx.signature(i);
        if (ca_algorithm::VerifySign(sig, evidenceHash) != 0)
        {
            ERRORLOG("[SLASH] EVIDENCE tx signature verification failed, hash:{}, index:{}", tx.hash(), i);
            return -9;
        }

        const std::string signerAddr = GenerateAddr(sig.pub());
        if (eligibleSigners.find(signerAddr) == eligibleSigners.end())
        {
            ERRORLOG("[SLASH] EVIDENCE tx signer is not eligible, hash:{}, signer:{}", tx.hash(), signerAddr);
            return -10;
        }
        if (!uniqueSigners.insert(signerAddr).second)
        {
            ERRORLOG("[SLASH] EVIDENCE tx duplicate signer, hash:{}, signer:{}", tx.hash(), signerAddr);
            return -11;
        }
    }

    if (uniqueSigners.size() < global::ca::kSlashEvidenceQuorum)
    {
        ERRORLOG("[SLASH] EVIDENCE tx unique signer count too low: {} < {}, hash:{}",
                 uniqueSigners.size(), global::ca::kSlashEvidenceQuorum, tx.hash());
        return -12;
    }

    return 0;
}

int ca_algorithm::ValidateSlashPunishmentTx(const CTransaction &tx, DBReader *dbReaderInstance)
{
    nlohmann::json dataJson;
    try
    {
        dataJson = nlohmann::json::parse(tx.data());
    }
    catch (const std::exception &e)
    {
        ERRORLOG("[SLASH] Invalid PUNISHMENT tx data json, hash:{}, error:{}", tx.hash(), e.what());
        return -1;
    }

    const std::string targetAddr = dataJson.value("target_addr", "");
    const std::string violationType = dataJson.value("violation_type", "");
    const std::string evidenceRefs = dataJson.value("evidence_refs", "");
    const std::string punishmentId = dataJson.value("punishment_id", "");
    const uint32_t penaltyLevel = dataJson.value("penalty_level", 0);

    if (targetAddr.empty() || violationType.empty() || evidenceRefs.empty() || punishmentId.empty())
    {
        ERRORLOG("[SLASH] Invalid PUNISHMENT tx: missing required fields, hash:{}", tx.hash());
        return -2;
    }
    if (!isValidAddress(targetAddr))
    {
        ERRORLOG("[SLASH] Invalid PUNISHMENT target address:{}, hash:{}", targetAddr, tx.hash());
        return -3;
    }
    if (penaltyLevel != 3 && penaltyLevel != 4)
    {
        ERRORLOG("[SLASH] Invalid PUNISHMENT level:{}, hash:{}", penaltyLevel, tx.hash());
        return -4;
    }

    const std::string expectedPunishmentId =
        ca_algorithm::BuildSlashPunishmentId(targetAddr, violationType, penaltyLevel, evidenceRefs);
    if (punishmentId != expectedPunishmentId)
    {
        ERRORLOG("[SLASH] PUNISHMENT id mismatch, hash:{}, expected:{}, got:{}",
                 tx.hash(), expectedPunishmentId, punishmentId);
        return -5;
    }

    if (tx.signature_size() < 1)
    {
        ERRORLOG("[SLASH] PUNISHMENT tx missing signature, hash:{}", tx.hash());
        return -6;
    }

    CTransaction txForSign = tx;
    txForSign.clear_hash();
    txForSign.clear_signature();
    const std::string signHash = Getsha256Hash(txForSign.SerializeAsString());
    const CSign &sign = tx.signature(0);
    if (ca_algorithm::VerifySign(sign, signHash) != 0)
    {
        ERRORLOG("[SLASH] PUNISHMENT tx signature verification failed, hash:{}", tx.hash());
        return -7;
    }

    const std::string signerAddr = GenerateAddr(sign.pub());
    if (signerAddr != tx.identity())
    {
        ERRORLOG("[SLASH] PUNISHMENT signer mismatch, hash:{}, identity:{}, signer:{}",
                 tx.hash(), tx.identity(), signerAddr);
        return -8;
    }

    DBReader localReader;
    DBReader *reader = dbReaderInstance ? dbReaderInstance : &localReader;
    std::vector<std::string> stakeAddrs;
    auto stakeRet = reader->getStakeAddr(stakeAddrs);
    if (DBStatus::DB_SUCCESS != stakeRet ||
        std::find(stakeAddrs.begin(), stakeAddrs.end(), signerAddr) == stakeAddrs.end())
    {
        ERRORLOG("[SLASH] PUNISHMENT signer is not eligible, hash:{}, signer:{}", tx.hash(), signerAddr);
        return -9;
    }

    std::string thresholdLevel;
    std::string thresholdViolationType;
    std::string thresholdEvidenceRefs;
    if (DBStatus::DB_SUCCESS != reader->getThresholdDetail(targetAddr, thresholdLevel, thresholdViolationType, thresholdEvidenceRefs))
    {
        ERRORLOG("[SLASH] PUNISHMENT target has no threshold state, hash:{}, target:{}", tx.hash(), targetAddr);
        return -10;
    }

    uint32_t thresholdPenaltyLevel = 0;
    try
    {
        thresholdPenaltyLevel = static_cast<uint32_t>(std::stoul(thresholdLevel));
    }
    catch (...)
    {
        ERRORLOG("[SLASH] PUNISHMENT threshold level parse failed, hash:{}, level:{}", tx.hash(), thresholdLevel);
        return -11;
    }

    if (thresholdPenaltyLevel != penaltyLevel ||
        thresholdViolationType != violationType ||
        thresholdEvidenceRefs != evidenceRefs)
    {
        ERRORLOG("[SLASH] PUNISHMENT threshold mismatch, hash:{}, target:{}", tx.hash(), targetAddr);
        return -12;
    }

    if (!dataJson.contains("stake_refs") || !dataJson["stake_refs"].is_array())
    {
        ERRORLOG("[SLASH] PUNISHMENT missing stake_refs snapshot, hash:{}", tx.hash());
        return -13;
    }
    std::vector<std::string> txStakeRefs = dataJson["stake_refs"].get<std::vector<std::string>>();
    std::sort(txStakeRefs.begin(), txStakeRefs.end());
    txStakeRefs.erase(std::unique(txStakeRefs.begin(), txStakeRefs.end()), txStakeRefs.end());

    std::vector<std::string> currentStakeRefs;
    if (DBStatus::DB_SUCCESS != reader->getStakeUtxoByAddr(targetAddr, "OHI", currentStakeRefs) || currentStakeRefs.empty())
    {
        ERRORLOG("[SLASH] PUNISHMENT target has no stake refs, hash:{}, target:{}", tx.hash(), targetAddr);
        return -14;
    }
    std::sort(currentStakeRefs.begin(), currentStakeRefs.end());
    currentStakeRefs.erase(std::unique(currentStakeRefs.begin(), currentStakeRefs.end()), currentStakeRefs.end());
    if (txStakeRefs != currentStakeRefs)
    {
        ERRORLOG("[SLASH] PUNISHMENT stake_refs mismatch, hash:{}, target:{}", tx.hash(), targetAddr);
        return -15;
    }

    if (DBStatus::DB_SUCCESS == reader->hasPunishmentHistory(punishmentId))
    {
        ERRORLOG("[SLASH] PUNISHMENT already executed, hash:{}, punishment_id:{}", tx.hash(), punishmentId);
        return -16;
    }

    return 0;
}

std::string ca_algorithm::CalcBlockHash(CBlock block)
{
    block.clear_hash();
    block.clear_signature();
    return Getsha256Hash(block.SerializeAsString());
}

std::string ca_algorithm::calculateBlockMerkle(CBlock cblock)
{
	std::string merkle;
	if (cblock.txs_size() == 0)
	{
		return merkle;
	}

	std::vector<std::string> tx_hashes;
	for (int i = 0; i != cblock.txs_size(); ++i)
	{
		CTransaction tx = cblock.txs(i);
		tx_hashes.push_back(tx.hash());
	}

	unsigned int j = 0, nSize;
    for (nSize = cblock.txs_size(); nSize > 1; nSize = (nSize + 1) / 2)
	{
        for (unsigned int i = 0; i < nSize; i += 2)
		{
            unsigned int i2 = std::min(i+1, nSize-1);

			std::string data1 = tx_hashes[j + i];
			std::string data2 = tx_hashes[j + i2];
			data1 = Getsha256Hash(data1);
			data2 = Getsha256Hash(data2);

			tx_hashes.push_back(Getsha256Hash(data1 + data2));
        }

        j += nSize;
    }

	merkle = tx_hashes[tx_hashes.size() - 1];

	return merkle;
}


int ca_algorithm::memoryVerificationTransactionRequest(const CTransaction & tx, global::ca::SaveType saveType,
                                                        std::optional<uint64_t> expectedNonce)
{
    uint64_t startTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	// Transaction version number must be 0
    if (tx.version() != global::ca::CURRENT_TRANSACTION_VERSION)
    {
        return -1;
    }

   // Is the transaction type a normal transaction
    if (GetTransactionType(tx) != kTransactionTypeTx)
    {
        return -2;
    }

	if (tx.time() <= MagicSingleton<Genesis>::GetInstance()->GetGenesisTime())
	{
		return -3;
	}

	// Is the transaction hash length 64
    if (tx.hash().size() != 64)
    {
        return -4;
    }

    // Verify whether the transaction hash is consistent
    if (tx.hash() != ca_algorithm::calculateTransactionHash(tx))
    {
        return -5;
    }

	if (tx.identity().size() == 0)
	{
		return -6;
	}
    
    if((tx.independence() != global::ca::TX_INDEPENDENCE_TRUE) && (tx.independence() != global::ca::TX_INDEPENDENCE_FALSE))
    {
        return -7;
    }

	if ( !isValidAddress(tx.identity()) )
	{
		return -8;
	}

    global::ca::TxType txType = (global::ca::TxType)tx.type();
	int needConsensus = tx.consensus();

    // EVIDENCE transaction validation must be self-contained and deterministic.
    if (txType == global::ca::TxType::EVIDENCE)
    {
        int ret = ca_algorithm::ValidateSlashEvidenceTx(tx);
        if (ret != 0)
        {
            return -60;
        }
        DEBUGLOG("[SLASH] EVIDENCE tx validation passed: type={}, hash={}, signatures={}",
                 (int)txType, tx.hash().substr(0, 8), tx.signature_size());
        return 0;
    }

    // PUNISHMENT transaction must match deterministic on-chain threshold state.
    if (txType == global::ca::TxType::PUNISHMENT)
    {
        int ret = ca_algorithm::ValidateSlashPunishmentTx(tx);
        if (ret != 0)
        {
            return -61;
        }
        DEBUGLOG("[SLASH] PUNISHMENT tx validation passed: type={}, hash={}",
                 (int)txType, tx.hash().substr(0, 8));
        return 0;
    }

    nlohmann::json txInfo;

    if((global::ca::TxType)tx.type() != global::ca::TxType::TX)
    {
        try
        {
            nlohmann::json dataJson = nlohmann::json::parse(tx.data());
            txInfo = dataJson["txInfo"].get<nlohmann::json>();
        }
        catch (...)
        {
            ERRORLOG("parse tx data failed");
            return -9;
        }

    }
    
    if (needConsensus != global::ca::kConsensus)
    {
        return -10;
    }

    // The transaction type can only be one of six, the output quantity  can only be 2
    bool isTx = false;
    bool isStake = false;
    bool isUnstake = false;
    bool isDelegating = false;
    bool isUndelegating = false;
    bool isBonus = false;
    bool isFund = false;
	bool isDeclare = false;
    bool isContractDeploymentEnabled = false;
    bool isCallContractTransfer = false;
    bool isCallContractType = false;
    bool isLock = false;       
    bool isUnLock = false;     
    bool isProposal = false;   
    bool isVote = false;       
    bool isRevokeProposal = false;        
    uint64_t stakeAmount = 0;
    uint64_t delegateAmount = 0;
    uint64_t lockQuantity = 0;     
    std::string voteHash;
    FlowTxType flowTxType = FlowTxType::Unknown;

    bool isGasTransaction = false;
    if(tx.independence() == global::ca::TX_INDEPENDENCE_TRUE) isGasTransaction = true;

	try
	{
		if (global::ca::TxType::STAKE == txType)
		{
			isStake = true;
			stakeAmount = txInfo["stakeAmount"].get<uint64_t>();
			std::string stakeType = txInfo["stakeType"].get<std::string>();

			if (global::ca::STAKE_TYPE_NET != stakeType)
			{
				ERRORLOG("Stake type can only be online stake and public network stake!");            
				return -11;
			}
		}
		else if (global::ca::TxType::UNSTAKE == txType)
		{
			isUnstake = true;
			std::string redeemUtxoHashValue = txInfo["unstakeUtxo"].get<std::string>();
			if(redeemUtxoHashValue.size() != 64)
			{
				return -12;
			}
		}
		else if (global::ca::TxType::LOCK == txType)  
        {
            isLock = true;
	        lockQuantity = txInfo["lockAmount"].get<uint64_t>();
            std::string stakeType = txInfo["lockType"].get<std::string>();
            if (global::ca::kLockTypeNet != stakeType)
			{
				ERRORLOG("Lock type can only be online stake and public vote network stake!");            
				return -13;
			}
        }
		else if(global::ca::TxType::UNLOCK == txType)
        {
            isUnLock = true;
			std::string redeemUtxoHashValue = txInfo["unLockUtxo"].get<std::string>();
			if(redeemUtxoHashValue.size() != 64)
			{
				return -14;
			}
        }
		else if (global::ca::TxType::DELEGATE == txType)
		{
			isDelegating = true;
			delegateAmount = txInfo["delegateAmount"].get<uint64_t>();
			std::string delegatingNode = txInfo["bonusAddr"].get<std::string>();
			if (!isValidAddress(delegatingNode))
			{
				return -15;
			}
			std::string delegateType = txInfo["delegateType"].get<std::string>();
			if (global::ca::kdelegateTypeNormal != delegateType )
			{
				ERRORLOG("the delegating type can only be delegating licence and reserve delegating licence!");
				return -16;
			}
		}
		else if (global::ca::TxType::UNDELEGATE == txType)
		{
			isUndelegating = true;
			std::string UndelegatingUtxoHash = txInfo["undelegatingUtxo"].get<std::string>();
			if (UndelegatingUtxoHash.size() != 64)
			{
				return -17;
			}
		}
		else if (global::ca::TxType::BONUS == txType)
		{
			isBonus = true;
			uint64_t bonusAddrList;
			bonusAddrList = txInfo["bonusAddrList"].get<uint64_t>();

            for (const auto &utxo : tx.utxos())
            {
                if (utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE)
                {
                    continue;
                }
                if (bonusAddrList != utxo.vout_size())
                {
                    ERRORLOG("bonusAddrList != vout size");
                    return -18;
                }
            }
        }
        else if(global::ca::TxType::FUND == txType)
        {
            isFund = true;

            if (!txInfo.contains("fundLockedAmount") ||
                !txInfo.contains("fundPackageAmount"))
            {
                ERRORLOG("Fund txInfo must contain fundLockedAmount and fundPackageAmount");
                return -19;
            }

            if (!txInfo["fundLockedAmount"].is_object() ||
                !txInfo["fundPackageAmount"].is_object())
            {
                ERRORLOG("Fund reward amount fields must be JSON objects");
                return -19;
            }

            // Parse the fields here as well as in verifyTransactionRequest so
            // malformed asset names or non-uint64 reward values are rejected
            // consistently during memory-pool verification.
            txInfo["fundLockedAmount"].get<std::map<std::string, uint64_t>>();
            txInfo["fundPackageAmount"].get<std::map<std::string, uint64_t>>();
        
            TxHelper::ProposalInfo null;
            std::map<std::string, TxHelper::ProposalInfo> assetMap;
            if (ca_algorithm::fetchAvailableAssetType(assetMap) != 0 && assetMap.empty())
            {
                return -2;
            }
	        // 原强制插入Vote，现改为OHI
            assetMap.insert({global::ca::ASSET_TYPE_OHI,null});
            

        	uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
            std::vector<std::string> fundAssetType_;
            for(const auto& _assetType : assetMap){
                uint64_t gasAmount = 0;
                DBReader dbReader; 
                auto result = dbReader.getGasAmountByPeriod(period -1,_assetType.first,gasAmount);
                if(result != DBStatus::DB_SUCCESS && result != DBStatus::DB_NOT_FOUND){
                    ERRORLOG("GetGasamountbyTimeType error!");
                    return -9;
                }
                if(gasAmount != 0){
                    fundAssetType_.push_back(_assetType.first);
                }
            }

            if(fundAssetType_.empty()){
                // std::cout << "There was no fund reward the day before" << std::endl;
                ERRORLOG("There was no fund reward the day before!");
                return -999;
            }
            
            std::vector<std::string> utxoAssetTypeVec;
            for(const auto& utxo : tx.utxos()){
                utxoAssetTypeVec.push_back(utxo.assettype());
                if(utxo.vin_size() != 0){
                    ERRORLOG("Special transactions have no transaction inputs!");
                    return -5;
                }
            }

            if(fundAssetType_.size() != utxoAssetTypeVec.size()){
                ERRORLOG("The number of vouts in utxo is inconsistent with the number of fund that should be claimed!");
                return -10;
            }

            for(const auto& i : fundAssetType_){
                DEBUGLOG("fundAssetType_ : {}",i);
            }
            
            for(const auto& i : utxoAssetTypeVec){
                DEBUGLOG("utxoAssetTypeVec : {}",i);
            }

            std::vector<std::string> result = bidirectionalDifference(fundAssetType_, utxoAssetTypeVec);
            if(!result.empty()){
                ERRORLOG("Wrong claim type");
                return -11;
            }
        }
        else if (global::ca::TxType::DECLARATION == txType)
        {
            isDeclare = true;
			std::string multiSignPub = txInfo["multiSignPub"].get<std::string>();
			nlohmann::json signAddrList = txInfo["signAddrList"].get<nlohmann::json>();
            multiSignPub = Base64Decode(multiSignPub);
			uint64_t threshold = txInfo["signThreshold"].get<uint64_t>();

			if(signAddrList.size() < 2 || signAddrList.size() > 100)
			{
				return -20;
			}

            std::set<std::string> setSignAddr;
			for (auto & signAddr : signAddrList)
			{
				if (!isValidAddress(signAddr))
				{
					return -21;
				}
                setSignAddr.insert(std::string(signAddr));
			}

            if (setSignAddr.size() != signAddrList.size())
            {
                return -22;
            }

			if (threshold > signAddrList.size())
			{
				return -23;
			}
        }
        else if (global::ca::TxType::DEPLOY == txType)
        {
            isContractDeploymentEnabled = true;
        }
        else if (global::ca::TxType::CALL == txType)
        {
            isCallContractType = true;
            flowTxType = GetFlowTxType(txInfo);

            if(txInfo.find(Evmone::contractTransferKeyLabel) != txInfo.end())
            {
                uint64_t contractTransfer = 0;
                contractTransfer = txInfo[Evmone::contractTransferKeyLabel].get<uint64_t>();
                if(contractTransfer != 0)
                {
                    isCallContractTransfer = true;
                }
            }

            if(flowTxType == FlowTxType::FlowInTx)
            {
                auto utxo = tx.utxos().begin();
                if(utxo->vout_size() != 2 || utxo->vin_size() != 0)
                {
                    return -19;
                }
                if(tx.utxos_size() != 1)
                {
                    return -20;
                }
            }
        }
		else if (global::ca::TxType::TX == txType)
		{
			isTx = true;
		}
		else if (global::ca::TxType::PROPOSAL == txType)  
        {
            std::string currencyExchangeRate = txInfo["exchangeRate"].get<std::string>();
            global::ca::CrossChainTxType crossChainTxType = (global::ca::CrossChainTxType)txInfo["crossChainTxType"].get<int>();
            std::string contractAddr = txInfo["tokenContractAddr"].get<std::string>();
            std::string crossChainInvestmentContractAddr = txInfo["crossChainInvestmentContractAddr"].get<std::string>();
            uint64_t proposalStartTime = txInfo["beginTime"].get<std::uint64_t>();
            uint64_t proposalEndTime = txInfo["endTime"].get<std::uint64_t>();
            uint64_t expirationDate = txInfo["expirationDate"].get<std::uint64_t>();
            int proposalVersion = txInfo["version"].get<std::uint64_t>();
            uint64_t canBeUsedForStake = txInfo["genesisToken"].get<std::uint64_t>();
            uint64_t minVote = txInfo["minVoteNum"].get<std::uint64_t>();
            std::string title = txInfo["title"].get<std::string>();
            std::string identifier = txInfo["identifier"].get<std::string>();
            std::string decodeName = txInfo["name"].get<std::string>();
            std::string peerChainTokenAddr = txInfo["peerChainTokenAddr"].get<std::string>();
            
            std::string name = Base64Decode(decodeName);

            if(proposalVersion != global::ca::KProposalInfoVersion)
            {
                ERRORLOG("proposalVersion error: {}", proposalVersion);
                return -24;
            }
            if(tx.time() - global::ca::KVrfVoteBeginTime > proposalStartTime)
            {
                return -25;
            }
            if(proposalEndTime - proposalStartTime < global::ca::KVoteCycle)
            {
                ERRORLOG("proposalEndTime error: begin: {}, end:{}", proposalEndTime, proposalStartTime);
                return -26;
            }  
            int ret = ca_algorithm::CheckProposaInfo(currencyExchangeRate, contractAddr, crossChainInvestmentContractAddr, crossChainTxType, minVote, name, peerChainTokenAddr);
            if(ret != 0)
            {
                ERRORLOG("CheckProposaInfo error: {}", currencyExchangeRate);
                return -27;
            }
            if(expirationDate != UINT64_MAX)
            {
                ERRORLOG("expirationDate error: {}", expirationDate);
                return -28;
            }
            int isEmpty = ca_algorithm::AssetTypeListIsEmpty();
            if(isEmpty < 0)
            {
                ERRORLOG("AssetTypeListIsEmpty error: {}", isEmpty);
                return -1200;
            }
            std::cout << "canBeUsedForStake: " << canBeUsedForStake << "\t isEmpty: " << isEmpty << std::endl;
            if (canBeUsedForStake != isEmpty)
            {
                ERRORLOG("canBeUsedForStake error: {}, isEmpty: {}", canBeUsedForStake, isEmpty);
                return -1201;
            }
            if(title.size() > 1024)
            {
                ERRORLOG("title error: {}", title.size());
                return -1202;
            }
            if(identifier.size() > 1024)
            {
                ERRORLOG("identifier error: {}", identifier.size());
                return -1203;
            }
            isProposal = true;
        }  
		else if(global::ca::TxType::REVOKEPROPOSAL == txType)      
        {
            std::string revokeHash = txInfo["proposalHash"].get<std::string>();
            uint64_t beginTime = txInfo["beginTime"].get<std::uint64_t>();
            uint64_t endTime = txInfo["endTime"].get<std::uint64_t>();
            uint64_t version = txInfo["version"].get<std::uint64_t>();
            uint64_t minVote = txInfo["minVoteNum"].get<std::uint64_t>();

            if(version != global::ca::KRevokeProposalInfoVersion)
            {
                ERRORLOG("proposalVersion error: {}", version);
                return -29;
            }
            if(tx.time() - global::ca::KVrfVoteBeginTime > beginTime)
            {
                return -30;
            }
            if(endTime - beginTime < global::ca::KVoteCycle)
            {
                ERRORLOG("proposalEndTime error: begin: {}, end:{}", endTime, beginTime);
                return -31;
            }  
            int ret = ca_algorithm::GetAssetTypeIsValid(revokeHash);
            if(ret != 0)
            {
                ERRORLOG("GetAssetTypeIsValid error, error num:{}", ret);
                return -32;
            }
            ret = ca_algorithm::canBeRevoked(revokeHash);
            if(ret != 0)
            {
                ERRORLOG("canBeRevoked error, error num:{}", ret);
                return -33;
            }
            if(minVote < 1)
            {
                ERRORLOG("minVote mest more then 1, minVote:{}", minVote);
                return -1202;
            }
            isRevokeProposal = true;
        }
		else if(global::ca::TxType::VOTE == txType)    
        {
            voteHash = txInfo["voteHash"].get<std::string>();
            uint32_t voteTxType = txInfo["voteTxType"].get<std::uint32_t>();
            int pollType = txInfo["voteType"].get<int>();
            
            int ret = ca_algorithm::CheckVoteTxInfo(voteHash, voteTxType, pollType, tx.time(), saveType);
            if(ret != 0)
            {
                ERRORLOG("CheckVoteTxInfo error, ret: {}", ret);
                return -34;
            }
            isVote = true;
        }              
		else
		{
			ERRORLOG("Unknown tx type!");  
			return -35;
		}
	}
	catch(const std::exception& e)
	{
		std::cerr << e.what() << '\n';
		return -36;
	}

    bool falg = false;
    for(const auto & utxo : tx.utxos())
    {
        if(utxo.assettype() != global::ca::ASSET_TYPE_OHI)
        {
            if(flowTxType == FlowTxType::FlowOutTx)
            {
                for(const auto& vout : utxo.vout())
                {
                    if(vout.addr() == global::ca::kVirtualCallFlowOutAddr){
                        TxHelper::ProposalInfo null;
                        auto ret_ = GetProposalInfo(utxo.assettype(),null);
                        if(ret_ != 0){
                            return -1205;
                        }
                    }else if(vout.addr() == global::ca::VIRTUAL_BURN_GAS_ADDR && utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                        int ret = GetAssetTypeIsValid(utxo.assettype());
                        if(ret != 0)
                        {
                            ERRORLOG("GetAssetTypeIsValid error, error code:{}, asset_type:{}, tx.hash:{}, tx.type:{}, flowTxType:{}, utxo.gas:{}",
                                     ret, utxo.assettype(), tx.hash(), tx.type(), static_cast<int>(flowTxType), utxo.gas());
                            return -1204;
                        }
                    }
                }
            }
            else
            {
                int ret = GetAssetTypeIsValid(utxo.assettype());
                if(ret != 0)
                {
                    ERRORLOG("GetAssetTypeIsValid error, error code:{}, asset_type:{}, tx.hash:{}, tx.type:{}, flowTxType:{}, utxo.gas:{}",
                             ret, utxo.assettype(), tx.hash(), tx.type(), static_cast<int>(flowTxType), utxo.gas());
                    return -1204;
                }
            }
        }

        if (isCallContractType && !falg && flowTxType == FlowTxType::FlowInTx && utxo.vout_size() == 2 && utxo.vin_size() == 0 && tx.utxos_size() == 1)
        {
            falg = true;
            continue;
        }

        if((utxo.gas() != global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE) && (utxo.gas() != global::ca::UtxoGasType::UTXO_GAS_TYPE_FALSE))
        {
            ERRORLOG("utxo gas parameter error");
            return -41;
        }

        if (utxo.owner_size() == 0)
        {
            ERRORLOG("utxo size is empty!");
            return -42;
        }


        if(!isFund){
            if (utxo.vin_size() > 100 || utxo.vin_size() <= 0)
            {
                ERRORLOG("The number of vins must be less than or equal to 100!");
                return -43;
            }
        }else{
            if(utxo.vin_size() != 0){
                ERRORLOG("The number of vins must be 0.")
                return -44;
            }
        }

        if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_FALSE)
        {
            if(!isFund){

                if(isUnstake||isUndelegating||isUnLock){
                    if(utxo.vout_size() != 1){
                        ERRORLOG("utxo.gas() : {}, utxo.vout_size() : {}", utxo.gas(), utxo.vout_size());
                        return -45;
                    }
                }else{
                    if (utxo.vout_size() < 3)
                    {
                        ERRORLOG("utxo.gas() : {}, utxo.vout_size() : {}", utxo.gas(), utxo.vout_size());
                        return -44;
                    }
                }
            }else{
                //TODO::Fund
                if (utxo.vout_size() > 2)
                {
                    ERRORLOG("utxo.gas() : {}, utxo.vout_size() : {}", utxo.gas(), utxo.vout_size());
                    return -76;
                }
            }
        }else if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE && (isContractDeploymentEnabled  || isCallContractType) ){
            if(utxo.vout_size() != 3){
                ERRORLOG("utxo.gas() : {}, utxo.vout_size() : {}", utxo.gas(), utxo.vout_size());
                return -112;
            }
        }
        else
        {
            if (utxo.vout_size() != 2 )
            {
                ERRORLOG("utxo.gas() : {}, utxo.vout_size() : {}", utxo.gas(), utxo.vout_size());
                return -45;
            }
        }

        if(utxo.multisign_size() == 0)
        {
            return -46;
        }
    }

    uint64_t gasTotal = 0;
    falg = false;
    for(const auto &utxo : tx.utxos())
    {
        if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE)
        {
            continue;
        }

        if(isCallContractType && !falg && flowTxType == FlowTxType::FlowInTx && utxo.vout_size() == 2 && utxo.vin_size() == 0 && tx.utxos_size() == 1)
        {
            falg = true;
            continue;
        }

        if(isUnstake||isUndelegating||isUnLock){
            if(utxo.vout_size() != 1){
                ERRORLOG("The number of un-trans vouts must be equal to 1!" );
                return -441;
            }

            if(tx.independence() == global::ca::TxIndependence::TX_INDEPENDENCE_TRUE){
                ERRORLOG(
                    "Delegation transactions cannot use separate gas payments!"
                )
                return -49;
            }
        }

        if((isStake || isDelegating || isDeclare || isLock ) && utxo.vout_size() != 3)
        {
            ERRORLOG("The number of vouts must be equal to 3!" );
            return -47;
        }

        std::set<std::string> ownerAddrs;
        {
            std::vector<std::string> tmpAddrs(utxo.owner().begin(), utxo.owner().end());
            std::set<std::string>(tmpAddrs.cbegin(), tmpAddrs.cend()).swap(ownerAddrs);

            if (ownerAddrs.size() == 0)
            {
                return -48;
            }

            for (auto & addr : ownerAddrs)
            {
                if (!isTx)
                {
                    if (!isValidAddress(addr))
                    {
                        return -49;
                    }
                }
                else
                {
                    if (!isValidAddress(addr))
                    {
                        return -50;
                    }
                }
            }

            // The owner size of the following five types of transactions must be 1
            if (isStake || isUnstake || isDelegating || isUndelegating || isFund || isBonus || isDeclare || isLock || isUnLock || isProposal || isRevokeProposal || isVote) 
            {
                if (1 != ownerAddrs.size())
                {
                    ERRORLOG("The owner size of the following five types of transactions must be 1!");
                    return -51;
                }
            }
            else
            {
                // Txowner does not allow duplicate
                if (tmpAddrs.size() != ownerAddrs.size())
                {
                    ERRORLOG( "Txowner does not allow duplicate!" );
                    return -52;
                }
            }
        }
        
        std::set<std::string> vin_addresses_list;
        std::set<std::string> inputUtxos;
    	uint64_t totalVinSize = 0;
        bool isRLPTransaction = false;
        ethVerify::EthTransaction ethTx;
        if (!tx.rlp().empty())
        {
            isRLPTransaction = true;
            dev::bytes rlpBytes = dev::fromHex(tx.rlp());
            eth_errors e;
            int ret_E = ethVerify::verifyRLP(rlpBytes, e, &ethTx, expectedNonce);
            if (ret_E != 0)
            {
                ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
                return ret_E;
            }
            int ret_U = ethVerify::verifyETHUtxo(tx, ethTx);
            if (ret_U != 0)
            {
                ERRORLOG("verifyETHUtxo failed, ret_U = {}", ret_U);
                return ret_U;
            }
        }

        for (auto &vin : utxo.vin())
        {
            std::string ownerAddr;
            if(vin.contractaddr().empty())
            {
                if (vin.vinsign().pub().size() == 0)
                {
                    return -53;
                }
                //TODO:::没有多签了
                ownerAddr = GenerateAddr(vin.vinsign().pub());
            }
            else if(isContractDeploymentEnabled || isCallContractType)
            {
                if (vin.vinsign().pub().size() != 0)
                {
                    return -54;
                }
                ownerAddr = vin.contractaddr();
            }

            if (!isValidAddress(ownerAddr))
            {
                ERRORLOG( "Check Base58Addr failed!" );
                return -55;
            }
            if (isRLPTransaction)
            {
                vin_addresses_list.insert(ethTx.from);
            }else{
                vin_addresses_list.insert(ownerAddr);
            }
            if (vin.prevout_size() == 0)
            {
                return -56;
            }

            for(auto & prevout : vin.prevout())
            {
                if (prevout.hash().size() != 64)
                {
                    return -57;
                }
                totalVinSize++;
                inputUtxos.insert(prevout.hash() + "_" + std::to_string(prevout.n()));
            }
        }
        
        if(!isFund){

            if (!std::equal(ownerAddrs.cbegin(), ownerAddrs.cend(), vin_addresses_list.cbegin(), vin_addresses_list.cend()))
            {
                ERRORLOG("Txowner and VIN signers are not consistent!");
                return -58;
            }
        }

        for (int i = 0; i < utxo.vin_size(); i++)
        {
            if (i != utxo.vin(i).sequence())
            {
                ERRORLOG(RED "The sequence of VIN is not consistent!" RESET);
                return -59;
            }        
        }

        if (isUnstake || isUndelegating || isUnLock)
        {
            if (inputUtxos.size() != totalVinSize && (inputUtxos.size() != (totalVinSize - 1)))
            {
                ERRORLOG("Vin cannot be repeated except for the redeem or Undelegating transaction!");
                return -60;
            }
        }
        else if(!(isContractDeploymentEnabled || isCallContractType))
        {
            if (inputUtxos.size() != totalVinSize)
            {
                ERRORLOG( "Vin cannot be repeated except for the redeem or Undelegating transaction!" );
                return -61;
            }
        }

        if (utxo.vout_size() == 0 || utxo.vout_size() > 1000)
        {
            return -62;
        }

        std::set<std::string> voutAddresses;
        for (int i = 0; i < utxo.vout_size(); i++)
        {
            auto &vout = utxo.vout(i);

            if(i == utxo.vout_size() - 1)
            {

                if(!isFund && !isUndelegating && !isUnstake && !isUnLock){
                    if(utxo.vout(i).addr() != global::ca::VIRTUAL_BURN_GAS_ADDR)
                    {
                        ERRORLOG("Destroy address is not a virtual address !");
                        return -63;
                    }

                    uint64_t gas = 0;
                    uint64_t gasSize = tx.data().size() + tx.note().size() + tx.reserve0().size() + tx.reserve1().size();
                    if(CalculateGas(utxo,gasSize,gas) != 0)
                    {
                        ERRORLOG("CalculateGas error gas = {}", gas);
                        return -64;
                    }

                    DEBUGLOG("CalculateGas gas : {} , utxo assetType : {}" , gas,utxo.assettype());
                    
                    if(GetInitAccountAddr() == *vin_addresses_list.begin())
                    {
                        gas = 0;
                    }

                    if(isGasTransaction)
                    {
                        gasTotal += gas;
                        if(utxo.vout(i).value() != 0)
                        {
                            ERRORLOG("Destroy amount error !");
                            return -65;
                        }
                    }else
                    {
                        if(utxo.vout(i).value() != gas)
                        {
                            ERRORLOG("Destroy amount error !, value:{}, gas:{}", utxo.vout(i).value(), gas);
                            return -66;
                        }
                    }
                }else{
                    if (!isValidAddress(vout.addr()))
                    {
                        ERRORLOG( "Check Base58Addr failed!" );
                        return -83;
                    }

                    if (vout.value() < 0)
                    {
                        ERRORLOG( "The amount in the output must be Greater than 0!" );
                        return -84;
                    }

                    if(utxo.vout(i).addr() != utxo.owner(0)){
                        ERRORLOG("The address to obtain the reward must be your own!");
                        return -67;
                    }
                }   
            }   
            else
            {
                if (isStake)
                {
                    if (i == 0 && (vout.addr() != global::ca::kTargetAddress || vout.value() != stakeAmount))
                    {
                        // The pledge amount should be consistent with the output
                        ERRORLOG(RED "The pledge amount should be consistent with the output!" RESET);
                        return -67;
                    }

                    if(i == 0 && vout.value() < 100000000000)
                    {
                        ERRORLOG(RED "The pledge amount should be consistent with the output!" RESET);
                        return -68;
                    }
                    
                    if (i == 1 && (! isValidAddress(vout.addr())))
                    {
                        return -69;
                    }
                    
                    if (i >= 3)
                    {
                        return -70;
                    }
                }
                else if (isLock)  
                {
                    if (i == 0 && (vout.addr() != global::ca::VIRTUAL_LOCK_ADDRESS || vout.value() != lockQuantity))
                    {
                        // The pledge amount should be consistent with the output
                        ERRORLOG(RED "The pledge amount should be consistent with the output!" RESET);
                        return -71;
                    }
                    std::cout << "----- debug   i: " << i << " vout.value(): " << vout.value() << std::endl;
                    if(i == 0 && vout.value() < global::ca::LOCK_AMOUNT * global::ca::kDecimalNum)
                    {
                        ERRORLOG("stakeAmount error, lockQuantity: ", vout.value());
                        return -72;
                    }
                    if (i == 1 && (! isValidAddress(vout.addr())))
                    {
                        return -73;
                    }
                    if (i >= 3)
                    {
                        return -74;
                    }
                }
                else if(isDelegating)
                {
                    if (i == 0 && (vout.addr() != global::ca::kVirtualDelegatingAddr || vout.value() != delegateAmount))
                    {
                        // The delegating amount should be consistent with the output
                        ERRORLOG(RED "The delegating amount should be consistent with the output!" RESET);
                        return -75;
                    }
                    
                    if (i == 1 && (! isValidAddress(vout.addr())))
                    {
                        return -76;
                    }
                    
                    if(i >= 3)
                    {
                        return -77;
                    }
                }
                else if (isDeclare)
                {
                    if (i == 0 && (!isValidAddress(vout.addr()) || vout.value() < 0) )
                    {
                        return -78;
                    }
                    
                    if (i == 1 && (!isValidAddress(vout.addr()) || (*ownerAddrs.begin() != vout.addr() ) ) )
                    {
                        return -79;
                    }
                    if (i >= 2)
                    {
                        return -80;
                    }
                }
                else if(isContractDeploymentEnabled)
                {
                    if (i == 0 && vout.addr() != global::ca::kVirtualDeploymentContractAddress)
                    {
                        // The DeployContract amount should be consistent with the output
                        ERRORLOG(RED "The DeployContract amount should be consistent with the output!" RESET);
                        return -81;
                    }
                }
                else if(isCallContractTransfer && i ==1 && (vout.addr() == global::ca::VIRTUAL_CALL_CONTRACT_ADDR)){
                    continue;
                }
                else if(isCallContractType && i == 0 && (vout.addr() == global::ca::VIRTUAL_CALL_CONTRACT_ADDR))
                {
                    continue;
                }
                else if(isCallContractType && i == 0 && (vout.addr() == global::ca::kVirtualCallFlowOutAddr))
                {
                    continue;
                }
                else if(isProposal || isVote)     
                {
                    std::cout << "*ownerAddrs.begin() :" << "0x:"+*ownerAddrs.begin() << std::endl;
                    if(*ownerAddrs.begin() != GetInitAccountAddr())
                    {
                        ERRORLOG("proposal tx owner error: {}", *ownerAddrs.begin());
                        return -82;
                    }
                }
                else if(isFund)
                {
                    if(vout.addr() != utxo.owner(0))
                    {
                        ERRORLOG("The address to obtain the reward must be your own!");
                        return -82;
                    }
                }
                else
                {
                    if (!isValidAddress(vout.addr()))
                    {
                        ERRORLOG( "Check Base58Addr failed!" );
                        return -83;
                    }
                    
                    // The amount in the output must be Greater than 0
                    if (vout.value() < 0)
                    {
                        ERRORLOG( "The amount in the output must be Greater than 0!" );
                        return -84;
                    }
                }
            }
        
            voutAddresses.insert(vout.addr());
        }

        if (vin_addresses_list.size() > 1 && !isContractDeploymentEnabled && !isCallContractType)
        {
            std::vector<std::string> vDiff;
            std::set_difference(voutAddresses.begin(), voutAddresses.end(),
                                vin_addresses_list.begin(),vin_addresses_list.end(),
                                std::back_inserter(vDiff));
            if(vDiff.size() > 2)
            {
                ERRORLOG(RED "Multi-to-Multi transaction is not allowed!" RESET);
                return -85;       
            }
        }

        if( !(utxo.vin_size() == 1 && utxo.multisign_size() == 1 &&  utxo.owner_size() == 1 && utxo.vout_size() == 3 && utxo.vout(1).addr() == utxo.owner(0)) )
        {
            if (!(isStake || isUnstake || isDelegating || isUndelegating || isBonus || isDeclare || isLock || isUnLock))
            {
                for (auto & v : utxo.vin())
                {
                    if(!v.contractaddr().empty() && (isContractDeploymentEnabled || isCallContractType))
                    {
                        if(v.vinsign().pub().empty())
                        {
                            continue;
                        }
                        return -86;
                    }
                    CTxInput vin = v;
                    CSign sign = vin.vinsign();
                    vin.clear_vinsign();
                    std::string vinHashSerialized = Getsha256Hash(vin.SerializeAsString());

                    int verificationResult = VerifySign(sign, vinHashSerialized);
                    if (verificationResult != 0)
                    {
                        return -87;
                    }
                }
            }
        }

        if (utxo.multisign_size() == 0)
        {
            return -88;
        }

        //验证utxo签名
        std::set<std::string> multiSignAddr;
        CTxUtxos utxo1 = utxo;
        utxo1.clear_multisign();
        std::string serializedUtxoHash = Getsha256Hash(utxo1.SerializeAsString());
        for(auto & multiSign : utxo.multisign())
        {
            multiSignAddr.insert(GenerateAddr(multiSign.pub()));

            int verificationResult = VerifySign(multiSign, serializedUtxoHash);
            if (verificationResult != 0)
            {
                ERRORLOG("VerifySign failed, verificationResult: {}", verificationResult);
                ERRORLOG("serializedUtxoHash: {}", serializedUtxoHash);
                ERRORLOG("multiSign.pub: {}", GenerateAddr(multiSign.pub()));
                return -89;
            }
        }
    }

    falg = false;
    for(const auto &utxo : tx.utxos())
    {
        if((isCallContractType || isContractDeploymentEnabled)){
            continue;
        }

        if(isCallContractType && !falg && flowTxType == FlowTxType::FlowInTx && utxo.vout_size() == 2 && utxo.vin_size() == 0 && tx.utxos_size() == 1)
        {
            falg = true;
            continue;
        }

        //owner
        if(utxo.gas() != global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE)
        {
            continue;
        }

        std::set<std::string> ownerAddrs;
        {
            std::vector<std::string> tmpAddrs(utxo.owner().begin(), utxo.owner().end());
            std::set<std::string>(tmpAddrs.cbegin(), tmpAddrs.cend()).swap(ownerAddrs);

            if (ownerAddrs.size() == 0)
            {
                return -90;
            }

            for (auto & addr : ownerAddrs)
            {
                if (!isValidAddress(addr))
                {
                    return -91;
                }
            }

            if (1 != ownerAddrs.size())
            {
                ERRORLOG( "The owner size of the following five types of transactions must be 1!" );
                return -92;
            }

            if(isVote)
            {
                int ret = ca_algorithm::CheckForDuplicateVotes(voteHash, *ownerAddrs.begin());
                if(ret != 0)
                {
                    ERRORLOG("CheckForDuplicateVotes error, error num: {}", ret);
                    return -93;
                }
            }
        }
        //vin
        std::string gasOwnerAddress;
        for(auto &vin : utxo.vin())
        {
            if(vin.contractaddr().empty())
            {
                if(vin.vinsign().pub().size() == 0)
                {
                    return -94;
                }
                if (!tx.rlp().empty())
                {
                    ethVerify::EthTransaction ethTx;
                    dev::bytes rlpBytes = dev::fromHex(tx.rlp());
                    eth_errors e;
                    int ret_E = ethVerify::verifyRLP(rlpBytes, e, &ethTx, expectedNonce);
                    if (ret_E != 0)
                    {
                        ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
                        return ret_E;
                    }
                    gasOwnerAddress = ethTx.from;
                }
                else
                {
                    gasOwnerAddress = GenerateAddr(vin.vinsign().pub());
                }
                
            }

            if (!isValidAddress(gasOwnerAddress))
            {
                ERRORLOG( "Check Addr failed!" );
                return -95;
            }

            if (vin.prevout_size() == 0)
            {
                return -96;
            }

            for(auto & prevout : vin.prevout())
            {
                if(prevout.hash().size() != 64)
                {
                    return -97;
                }
            }
        }

        for (int i = 0; i < utxo.vin_size(); i++)
        {
            if (i != utxo.vin(i).sequence())
            {
                ERRORLOG(RED "The sequence of VIN is not consistent!" RESET);
                return -98;
            }        
        }

        if(utxo.vout_size() != 2)
        {
            ERRORLOG("gas utxo vout size not 2");
            return -99;
        }

        //vout
        for(int i = 0; i < utxo.vout_size();i++)
        {
            //第一个vout是给自己
            if(i == (utxo.vout_size() -2))
            {
                if(utxo.vout(i).addr() != gasOwnerAddress)
                {
                    ERRORLOG("the first vout addr is not self");
                    return - 100;
                }
            }

            //第二个vout是给虚拟地址
            if(i == (utxo.vout_size() -1))
            {
                if(utxo.vout(i).addr() != global::ca::VIRTUAL_BURN_GAS_ADDR)
                {
                    ERRORLOG("Destroy amount error !");
                    return - 101;
                }

                if(isProposal || isRevokeProposal || isVote)
                {
                    uint64_t gas = 0;
                    uint64_t gasSize = tx.data().size() +  tx.note().size() + tx.reserve0().size() + tx.reserve1().size();
                    if(CalculateGas(utxo,gasSize,gas) != 0)
                    {
                        ERRORLOG("CalculateGas error gas = {}", gas);
                        return -102;
                    }

                    if(GetInitAccountAddr() == gasOwnerAddress)
                    {
                        gas = 0;
                    }

                    if(utxo.vout(i).value() != gas)
                    {
                        ERRORLOG("Destroy amount error !");
                        return - 103;
                    }
                    continue;
                }

                if(flowTxType == FlowTxType::FlowInTx)
                {
                    if(utxo.vout(i).value() != 0)
                    {
                        return -112;
                    }
                }
                else
                {
                    if(utxo.vout(i).value() != gasTotal)
                    {
                        ERRORLOG("Destroy amount error !, value:{}, gas:{}", utxo.vout(i).value(), gasTotal);
                        return - 104;
                    }
                }
            }
        }
    }


    if (tx.signature_size() < 0)
    {
        std::ostringstream oss;
        PrintTx(tx, true, oss);
        ERRORLOG("tx.verifysign_size:{} \n {}", tx.signature_size(), oss.str());
        return -105;
    }

    if(global::ca::TxType::CALL != txType && global::ca::TxType::DEPLOY != txType)
    {
        if (tx.signature_size() > 0 && GenerateAddr(tx.signature(0).pub()) != tx.identity())
        {
            ERRORLOG("tx verify sign size = {} " , tx.signature_size());
            ERRORLOG("addr = {} , tx identity = {} ", GenerateAddr(tx.signature(0).pub()), tx.identity());
            return -106;
        }
    }


    CTransaction copyTx = tx;
	copyTx.clear_hash();
	copyTx.clear_signature();
	std::string serTxHash = Getsha256Hash(copyTx.SerializeAsString());

    if(tx.signature_size() != 0)
    {
        if (!isValidAddress(GenerateAddr(tx.signature(0).pub())))
        {
            return -107;
        }

        int verificationResult = VerifySign(tx.signature(0), serTxHash);
        if (verificationResult != 0)
        {
            return -108;
        }
    }

    for(int i = 1; i < tx.signature_size(); i++)
    {
        if (!isValidAddress(GenerateAddr(tx.signature(i).pub())))
        {
            return -109;
        }
	}
    
    if (tx.note().size() > 1024)
    {
        return -110;
    }

    if (tx.reserve0().size() != 0 || tx.reserve1().size() != 0)
    {
        return -111;
    }

    uint64_t endTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    if(global::ca::TxType::TX == txType)
    {
        MagicSingleton<Benchmark>::GetInstance()->transactionMemVerifyMap(tx.hash(), endTime - startTime);
    }
    
    return 0;
}


int ca_algorithm::verifyTransactionRequest(const CTransaction &tx, uint64_t txHeight, bool enableMissingBlockRequest,
                                           bool checkAnomaly, std::optional<uint64_t> expectedNonce)
{
    uint64_t startTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    
    DBReader dbReader;

    bool isStake = false;
    double commissionRate = 0.0;
    bool isRedeem = false;
    std::string redeemUtxoHashValue;

    bool isDelegating = false;
    std::string delegatingNode;
    uint64_t delegateAmount = 0;
    bool isUndelegating = false;
    std::string delegatingedNode;
    std::string UndelegatingUtxoHash;  

	bool isDeclare = false;
	std::string multiSignPub;
    bool isContractDeploymentEnabled = false;
    bool isCallContractType = false;
    bool isLock = false;   
    bool isVote = false;   
    bool isUnLock = false;
    std::string lockUtxo;
    // std::string CallType;
    FlowTxType flowTxType = FlowTxType::Unknown;

    auto txType = (global::ca::TxType)tx.type();

    bool isClaim = false;
    uint64_t claimAmount = 0;

    bool isFund = false;

    std::map<std::string, uint64_t> lockedReward;
    std::map<std::string, uint64_t> packageReward;

    bool isTx = false;
    nlohmann::json txInfo;
    if((global::ca::TxType)tx.type() != global::ca::TxType::TX)
    {
        try
        {
            nlohmann::json dataJson = nlohmann::json::parse(tx.data());
            txInfo = dataJson["txInfo"].get<nlohmann::json>();

            if(global::ca::TxType::STAKE == txType)
            {
                isStake = true;
                try
                {
                    commissionRate = txInfo["commissionRate"].get<double>();
                }
                catch (...)
                {
                    commissionRate = global::ca::MAX_COMMISSION_RATE;
                }
                
            }
            if (global::ca::TxType::UNSTAKE == txType)
            {   
                isRedeem = true;            
                redeemUtxoHashValue = txInfo["unstakeUtxo"].get<std::string>();
            }
            else if (global::ca::TxType::LOCK == txType)     
            {
                isLock = true;
            }
            else if (global::ca::TxType::UNLOCK == txType)   
            {
                isUnLock = true;
                lockUtxo = txInfo["unLockUtxo"].get<std::string>();
            }
            else if (global::ca::TxType::DELEGATE == txType)
            {
                isDelegating = true;
                delegatingNode = txInfo["bonusAddr"].get<std::string>();
                delegateAmount = txInfo["delegateAmount"].get<uint64_t>();
            }  
            else if (global::ca::TxType::UNDELEGATE == txType)
            {
                isUndelegating = true;
                UndelegatingUtxoHash = txInfo["undelegatingUtxo"].get<std::string>();
                delegatingedNode = txInfo["bonusAddr"].get<std::string>();   
            }
            else if(global::ca::TxType::BONUS == txType)
            {
                isClaim = true;
                claimAmount = txInfo["bonusAmount"].get<uint64_t>();
            }
            else if(global::ca::TxType::FUND == txType)
            {
                isFund = true;

                if (!txInfo.contains("fundLockedAmount") ||
                    !txInfo.contains("fundPackageAmount"))
                {
                    ERRORLOG("Fund txInfo must contain fundLockedAmount and fundPackageAmount");
                    return -1;
                }

                if (!txInfo["fundLockedAmount"].is_object() ||
                    !txInfo["fundPackageAmount"].is_object())
                {
                    ERRORLOG("Fund reward amount fields must be JSON objects");
                    return -1;
                }

                lockedReward = txInfo["fundLockedAmount"].get<std::map<std::string, uint64_t>>();
                packageReward = txInfo["fundPackageAmount"].get<std::map<std::string, uint64_t>>();
            }
            else if (global::ca::TxType::DECLARATION == txType)
            {
                isDeclare = true;
                multiSignPub = txInfo["multiSignPub"].get<std::string>();
                multiSignPub = Base64Decode(multiSignPub);
            }
            else if (global::ca::TxType::DEPLOY == txType)
            {
                isContractDeploymentEnabled = true;
            }
            else if (global::ca::TxType::CALL == txType)
            {
                isCallContractType = true;
                flowTxType = GetFlowTxType(txInfo);
            }
            else if (global::ca::TxType::TX == txType)
            {
                isTx = true;
            }
            else if (global::ca::TxType::VOTE == txType)   
            {
                isVote = true;
            }
        }
        catch(...)
        {
            ERRORLOG(RED "JSON failed to parse data field!" RESET);
            return -1;
        }
    }

    bool isRLPTransaction = false;
    ethVerify::EthTransaction ethTx;
    if(!tx.rlp().empty()){
        isRLPTransaction = true;
        dev::bytes rlpBytes = dev::fromHex(tx.rlp());
        eth_errors e;
        int ret_E = ethVerify::verifyRLP(rlpBytes,e,&ethTx, expectedNonce);
        if(ret_E != 0){
            ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
            return ret_E;
        }
        int ret_U = ethVerify::verifyETHUtxo(tx,ethTx);
        if(ret_U != 0){
            ERRORLOG("verifyETHUtxo failed, ret_U = {}", ret_U);
            return ret_U;
        }
    }
    
    if (tx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -9990;
    }

    if (tx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -9989;
    }

    const std::string& addr = tx.utxos(0).owner(0);
    uint64_t nonce = 0;
    if (expectedNonce.has_value()) {
        nonce = *expectedNonce;
    } else {
        auto DBRET = dbReader.getNonceByAddr(addr, nonce);
        if (DBStatus::DB_SUCCESS != DBRET && DBStatus::DB_NOT_FOUND != DBRET)
        {
            ERRORLOG("getNonceByAddr error! addr:{} nonce:{}", addr, nonce);
            return -9991;
        }
    }
    if(nonce != tx.nonce()){
        ERRORLOG("nonce mismatch!");
        return -9992;
    }

    std::string missingUtxo = "";
    auto passCode = doubleSpendCheck(tx, enableMissingBlockRequest, &missingUtxo);
    if (passCode != 0)
    {
        DEBUGLOG("doubleSpendCheck missingUtxo:{}, ret:{}", missingUtxo, passCode);
        if(passCode == -5 || passCode == -7 || passCode == -8 && !missingUtxo.empty())
        {
            std::string blockHash;
            if(dbReader.getBlockHashByTransactionHash(missingUtxo, blockHash) == DBStatus::DB_SUCCESS)
            {
                //doubleSpend
                return passCode - 100;
            }
            else
            {
                //block not found
                return passCode - 200;
            }
        }
    }

    bool isGasTransaction = false;
    if(tx.independence() == global::ca::TX_INDEPENDENCE_TRUE) isGasTransaction = true;

    if(tx.utxos_size() == 0){
        ERRORLOG("The utxo structure is empty");
        return -998;
    }

    bool falg = false;
    for(const auto &_utxo : tx.utxos())
    {
        if(_utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE)
        {
            continue;
        }

        if(isCallContractType && !falg && flowTxType == FlowTxType::FlowInTx && _utxo.vout_size() == 2 && _utxo.vin_size() == 0 && tx.utxos_size() == 1)
        {
            falg = true;
            continue;
        }
        uint64_t vinAmount = 0;
        int count = 0;

        if(isFund){
            if(_utxo.vin_size() != 0){
                ERRORLOG("Special transactions have no transaction inputs!");
                return -987;
            }
        }

        if(isRedeem || isUndelegating || isUnLock){
            if(_utxo.vin_size() != 1){
                ERRORLOG("The number of transaction VINs for delegating must be one.");
                return -988;
            }
        }


        for (auto &vin : _utxo.vin())
        {
            global::ca::TxType txType = (global::ca::TxType)tx.type();
            std::string addr;
            if(vin.contractaddr().empty())
            {
                if(isRLPTransaction){
                    addr = ethTx.from;
                }else{addr = GenerateAddr(vin.vinsign().pub());}
            }
            else if(isContractDeploymentEnabled || isCallContractType)
            {
                addr = vin.contractaddr();
            }
            for (auto & prevout : vin.prevout())
            {
                std::string utxo = prevout.hash();


                std::string balance ;
                if(txType ==  global::ca::TxType::UNSTAKE && ++count == 1)
                {
                    addr = global::ca::kTargetAddress;
                }
                else if(txType ==  global::ca::TxType::UNLOCK && ++count == 1) 
                {
                    addr = global::ca::VIRTUAL_LOCK_ADDRESS;
                }
                else if(txType == global::ca::TxType::UNDELEGATE && ++count == 1)
                {
                    addr = global::ca::kVirtualDelegatingAddr;
                }

                if (DBStatus::DB_SUCCESS != dbReader.getUtxoValueByUtxoHashes(utxo, addr, _utxo.assettype(), balance))
                {
                    MagicSingleton<BlockHelper>::GetInstance()->pushMissUtxo(utxo);
                    ERRORLOG("getTransactionByHash failed!");
                    continue;
                }


                uint64_t stakeValue = 0;
                std::string underline = "_";
                std::vector<std::string> utxoValues;

                if(balance.find(underline) != std::string::npos)
                {
                    StringUtil::SplitString(balance, "_", utxoValues);
                    
                    for(int i = 0; i < utxoValues.size(); ++i)
                    {
                        stakeValue += std::stol(utxoValues[i]);
                    }

                    vinAmount += stakeValue;
                }
                else
                {
                    vinAmount +=  std::stol(balance);
                }
            
            }
        }
        
        //vin Accumulated claim balance
        std::map<std::string, uint64_t> companyDividend;
        uint64_t costo=0;
        uint64_t nodeDividend=0;
        uint64_t vinAmountCopia=vinAmount;
        uint64_t TotalClaim=0;
        double commissionRate_1;
        bool firstCheckGas = false;
        if (isClaim)
        {
            if(vinAmount == 0)
            {
                firstCheckGas = true;
            }
            std::string owner = _utxo.owner().at(0);
            int rt = ca_algorithm::GetCommissionPercentage(owner, commissionRate_1);
            if(rt != 0)
            {
                ERRORLOG(RED "GetCommissionPercentage ret: " RESET, rt);
                return -2;
            }
            if(commissionRate_1 > global::ca::MAX_COMMISSION_RATE || commissionRate_1 < global::ca::MIN_COMMISSION_RATE)
            {
                ERRORLOG("Stake tx Commission enter error!");
                return -3;
            }

            uint64_t tx_time = tx.time();
            auto ret = ca_algorithm::CalcBonusValue(tx_time, owner, companyDividend);
            if(ret < 0)
            {
                ERRORLOG(RED "Failed to obtain the amount claimed by the delegatingor ret:({})" RESET, ret);
                return -4;
            } 
            for(auto & Company : companyDividend)
            {
                costo = Company.second * commissionRate_1 + 0.5;
                nodeDividend += costo;
                vinAmount += (Company.second-costo);
                TotalClaim += (Company.second-costo);
                DEBUGLOG("Company.second is {}", Company.second);
                DEBUGLOG("costo is {}", costo);
            }
            vinAmount += nodeDividend;
            TotalClaim += nodeDividend;
            if(TotalClaim != claimAmount) 
            {
                return -6;
            }
            if(firstCheckGas)
            {
                if(tx.utxos_size() != 2)
                {
                    ERRORLOG("Bonus tx must have gas utxo!");
                    return -9;
                }
                uint64_t voutAmount = 0;
                for (auto &vout : _utxo.vout())
                {
                    if(vout.addr() == global::ca::VIRTUAL_BURN_GAS_ADDR)
                    {
                        continue;
                    }
                    voutAmount += vout.value();
                }
                if (voutAmount != vinAmount)
                {
                    ERRORLOG("Input is not equal to output ,voutAmount = {}, vinAmount = {}", voutAmount, vinAmount);
                    return -10;
                }
            }
        }

        // 3. The transaction amount must be consistent 
        uint64_t voutAmount = 0;
        if(!firstCheckGas)
        {
            for (auto &vout : _utxo.vout())
            {
                voutAmount += vout.value();
            }
            
            if(!isFund){
                if (voutAmount != vinAmount)
                {
                    ERRORLOG("Input is not equal to output ,voutAmount = {}, vinAmount = {}", voutAmount, vinAmount);
                    return -11;
                }
            }
        }
        //Calculate whether the pre-transaction includes the account number used
        std::set<std::string> txInputVector;
        for(auto & vin : _utxo.vin())
        {
            std::string vinAddr;
            if(vin.contractaddr().empty())
            {
                vinAddr = GenerateAddr(vin.vinsign().pub());
                if (isRLPTransaction)
                {
                    vinAddr = ethTx.from;
                }
                else
                {
                    vinAddr = GenerateAddr(vin.vinsign().pub());
                }
            }
            else if(isContractDeploymentEnabled || isCallContractType)
            {
                vinAddr = vin.contractaddr();
            }
            for (auto & prevHash : vin.prevout())
            {
                std::string prevUtxo = prevHash.hash();
                std::string txRawData;
                if (DBStatus::DB_SUCCESS !=  dbReader.getTransactionByHash(prevUtxo, txRawData))
                {
                    ERRORLOG("get tx failed");
                    return -12;
                }

                CTransaction prevTx;
                prevTx.ParseFromString(txRawData);
                if (prevTx.hash().size() == 0)
                {
                    return -13;
                }

                std::vector<std::string> prevTxOutAddr;
                for(const auto& utxo2: prevTx.utxos())
                {
                    for (auto & txOut : utxo2.vout())
                    {
                        prevTxOutAddr.push_back(txOut.addr());
                    }
                }
                if (std::find(prevTxOutAddr.begin(), prevTxOutAddr.end(), vinAddr) == prevTxOutAddr.end())
                {
                    ERRORLOG("empty !!!!!!!!!");
                    return -14;
                }
            }
        }

        std::string redeemUtxoRaw;
        CTransaction redeemUtxo;
        std::string UndelegatingUtxoRaw;
        CTransaction UndelegatingUtxo;
        if(global::ca::TxType::STAKE == txType)
        {
            if(commissionRate > global::ca::MAX_COMMISSION_RATE || commissionRate < global::ca::MIN_COMMISSION_RATE)
            {
                ERRORLOG("Stake tx commission enter error!");
                return -15;
            }

            //质押时判断交易类型必须是S类型
            if(ca_algorithm::AssetTypeIsOHI(_utxo.assettype()) != 0) return -199;

            std::vector<std::string> stake_unspent_outputs;
            auto dbret = dbReader.getStakeUtxoByAddr(_utxo.owner(0), _utxo.assettype(), stake_unspent_outputs);
            if(dbret == DBStatus::DB_SUCCESS)
            {
                ERRORLOG("There has been a pledge transaction before !");
                return -16;
            }
        }
        else if (global::ca::TxType::UNSTAKE == txType)
        {
            std::set<std::string> setOwner(_utxo.owner().begin(), _utxo.owner().end());
            if (setOwner.size() != 1)
            {
                return -17;
            }
            uint64_t stakedAmount = 0;
            std::string owner = _utxo.owner().at(0);

            DBReadWriter dbReaderWriter;
            std::string lockHash;
            uint64_t lockTime = 0;
            std::string txRaw;
            if (dbReaderWriter.getTransactionByHash(
                    redeemUtxoHashValue, txRaw) != DBStatus::DB_SUCCESS) {
              return -18;
            }
            CTransaction txraw;
            txraw.ParseFromString(txRaw);
            if (dbReaderWriter.get30DayLockData(tx.utxos(0).owner(0), lockHash,
                                                 tx.utxos(0).assettype(),
                                                 lockTime) ==
                           DBStatus::DB_SUCCESS) {
              ERRORLOG("utxoHash:{} utxoTime:{}", lockHash, tx.time());
              return -19;
            }

            int ret = IsQualifiedToUnstake(owner, redeemUtxoHashValue, stakedAmount, _utxo.assettype());
            if(ret != 0)
            {
                ERRORLOG(RED "Not allowed to delegating!" RESET);
                return ret - 300;
            }
            if (_utxo.vout(0).addr() != owner)
            {
                ERRORLOG(RED "The address of the withdrawal utxo is incorrect!" RESET);
                return -20;
            }
            if (_utxo.vout(0).value() != stakedAmount)
            {
                ERRORLOG(RED "The value of the withdrawal utxo is incorrect!" RESET);
                return -21;
            }

            for (int i = 0; i < _utxo.vin_size(); ++i)
            {
                if(i == 0)
                {
                    if (_utxo.vin(0).prevout(0).hash() != redeemUtxoHashValue || _utxo.vin(0).prevout(0).n() != 1)
                    {
                        ERRORLOG("VIN is not the hash that was originally commissioned.");
                        return -22;
                    }
                }
                else
                {
                    for (auto &prevout : _utxo.vin(i).prevout())
                    {
                        if(prevout.n() != 0)
                        {
                            ERRORLOG("VIN is not the hash that was originally commissioned.");
                            return -23;
                        }
                    }
                }
            }
        }
        else if(global::ca::TxType::LOCK == txType)  
        {

            if(_utxo.assettype() != global::ca::ASSET_TYPE_OHI) return -799;

            std::vector<std::string> stake_unspent_outputs;
            auto dbret = dbReader.getLockAddrUtxo(_utxo.owner(0), _utxo.assettype(),stake_unspent_outputs);
            if(dbret == DBStatus::DB_SUCCESS)
            {
                ERRORLOG("There has been a lock transaction before !");
                return -700;
            }
        }
        else if(global::ca::TxType::UNLOCK == txType)
        {
            if(_utxo.assettype() != global::ca::ASSET_TYPE_OHI) return -798;

            std::set<std::string> setOwner(_utxo.owner().begin(), _utxo.owner().end());
            if (setOwner.size() != 1)
            {
                return -702;
            }
            uint64_t amount = 0;
            std::string owner = _utxo.owner().at(0);
            int ret = IsQualifiedToUnLock(owner, lockUtxo, amount,_utxo.assettype());
            if(ret != 0)
            {
                ERRORLOG("IsQualifiedToUnLock error, erron:{}", ret);
                return ret - 300;
            }
            if (_utxo.vout(0).addr() != owner)
            {
                ERRORLOG(RED "The address of the withdrawal utxo is incorrect!" RESET);
                return -703;
            }
            if (_utxo.vout(0).value() != amount)
            {
                ERRORLOG(RED "The value of the withdrawal utxo is incorrect!" RESET);
                return -704;
            }

            for(int i = 0; i < _utxo.vin_size() ; ++i)
            {
                if(i == 0)
                {
                    if(_utxo.vin(0).prevout(0).hash() != lockUtxo || _utxo.vin(0).prevout(0).n() != 1)
                    {
                        return -705;
                    }
                }
                else
                {
                    for(auto & prevout : _utxo.vin(i).prevout())
                    {
                        if(prevout.n() != 0)
                        {
                            return -706;
                        }
                    }
                }
            }
        }
        else if(global::ca::TxType::DELEGATE == txType)
        {
            if (_utxo.owner().size() != 1)
            {
                return -24;
            }
            std::string owner = _utxo.owner().at(0);
            int ret = CheckDelegatingQualification(owner, delegatingNode,_utxo.assettype(),delegateAmount);
            if(ret != 0)
            {
                ERRORLOG(RED "Not allowed to delegating!" RESET);
                return ret - 400;
            }
        }
        else if (global::ca::TxType::UNDELEGATE == txType)
        {
            std::set<std::string> setOwner(_utxo.owner().begin(), _utxo.owner().end());
            if (setOwner.size() != 1)
            {
                return -25;
            }

            DBReadWriter dbReaderWriter;
            std::string lockHash;
            uint64_t lockTime = 0;
            if (dbReaderWriter.get30DayLockData(
                    tx.utxos(0).owner(0), lockHash, tx.utxos(0).assettype(),
                    lockTime) == DBStatus::DB_SUCCESS) {
              ERRORLOG("utxoHash:{} utxoTime:{}", lockHash, tx.time());
              return -26;
            }

            uint64_t delegatingedAmount = 0;
            std::string owner = _utxo.owner().at(0);
            int ret = IsQualifiedToUndelegating(owner, _utxo.assettype(), delegatingedNode, UndelegatingUtxoHash, delegatingedAmount);
            if(ret != 0)
            {
                ERRORLOG(RED "Not allowed to Ddelegating!" RESET);
                return ret - 500;
            }
            if (_utxo.vout(0).addr() != owner)
            {
                ERRORLOG(RED "The address of the withdrawal utxo is incorrect!" RESET);
                return -27;
            }
            if (_utxo.vout(0).value() != delegatingedAmount)
            {
                ERRORLOG(RED "The value of the withdrawal utxo is incorrect!" RESET);
                return -28;
            }

            for(int i = 0; i < _utxo.vin_size() ; ++i)
            {
                if(i == 0)
                {
                    if(_utxo.vin(0).prevout(0).hash() != UndelegatingUtxoHash || _utxo.vin(0).prevout(0).n() != 1)
                    {
                        return -29;
                    }
                }
                else
                {
                    for(auto & prevout : _utxo.vin(i).prevout())
                    {
                        if(prevout.n() != 0)
                        {
                            return -30;
                        }
                    }
                }
            }
        }
        else if (global::ca::TxType::DECLARATION == txType)
        {
        }
        else if(global::ca::TxType::VOTE == txType)   
        {
            if(_utxo.assettype() != global::ca::ASSET_TYPE_OHI) return -797;
            
            std::vector<std::string> assertTypes;
            auto dbRet = dbReader.getAssetType(assertTypes);
            if(dbRet != DBStatus::DB_SUCCESS)
            {
                ERRORLOG("VoteCache error -1, getAssetType error, error num:{}", dbRet);
                return -31;
            }

            uint64_t lockValue = 0;
            if(assertTypes.size() == 1 && _utxo.owner(0) == GetInitAccountAddr())
            {
                lockValue = 1;
            }
            else 
            {
                auto ret = ca_algorithm::GetLockValue(_utxo.owner(0), lockValue);
                if(ret != 0)
                {
                    ERRORLOG("GetLockValue error, ret: {}", ret);
                    return -701;
                }
            }

            uint64_t voteNumber = txInfo["voteNumber"].get<std::uint64_t>();

            if(lockValue != voteNumber)
            {
                ERRORLOG("lockValue:{}  voteNumber:{}", lockValue, voteNumber);
                return -702;
            }
        }
        else if(global::ca::TxType::BONUS == txType)
        {
            if (_utxo.owner().size() != 1)
            {
                return -32;
            }
            std::string owner = _utxo.owner().at(0);
            int ret = evaluateBonusEligibility(owner, tx.time(), checkAnomaly);
            if(ret != 0)
            {
                ERRORLOG(RED "Not allowed to Bonus!" RESET);
                return ret - 600;
            }
            
            int i=0;
            costo=0;
            nodeDividend=0;
            uint64_t burnFree = _utxo.vout(_utxo.vout().size() - 1).value();
            for (auto &vout : _utxo.vout())
            {
                if(_utxo.vout().size()-2 != i && _utxo.vout().size()-1 != i)
                {
                    if(companyDividend.end() != companyDividend.find(vout.addr()))
                    {
                        costo=companyDividend[vout.addr()] * commissionRate_1 + 0.5;
                        nodeDividend+=costo;
                        if(companyDividend[vout.addr()] - costo != vout.value())
                        {
                            return -33;
                        }
                    }
                    else
                    {
                        return -34;
                    }
                    ++i;
                }
            }

            uint64_t LastVoutAmount = 0;
            if (firstCheckGas)
            {
                LastVoutAmount = vinAmountCopia + nodeDividend;
            }
            else
            {
                LastVoutAmount = vinAmountCopia - burnFree + nodeDividend;
            }
            
            if (owner == _utxo.vout(i).addr())
            {
                if (LastVoutAmount != _utxo.vout(i).value())
                {
                    return -35;
                }
            }
        }
        else if(global::ca::TxType::FUND == txType)
        {
            if(_utxo.owner().size() != 1)
            {
                return -36;
            }

            bool isLocked = false;
            bool isPackage = false;
            double lockedRate = 0.0; 
            double packageRate = 0.0;
            std::map<std::string, TxHelper::ProposalInfo> assetMap;
            int ret = ca_algorithm::fetchAvailableAssetType(assetMap);
            if(ret != 0){
                ERRORLOG("Get available asset fail! ret : {}",ret);
                return -37;
            }
            TxHelper::ProposalInfo null;
            // 原强制插入Vote，现改为OHI
            assetMap.insert({global::ca::ASSET_TYPE_OHI,null});

	        uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
            std::map<std::string,uint64_t> assetTypeAmount;
            for(const auto& _assetType : assetMap){
                uint64_t gasAmount = 0;
                auto result = dbReader.getGasAmountByPeriod(period -1,_assetType.first,gasAmount);
                if(result != DBStatus::DB_SUCCESS && result != DBStatus::DB_NOT_FOUND){
                    ERRORLOG("GetGasamountbyTimeType error!");
                    return -38;
                }
                if(gasAmount != 0){
                    assetTypeAmount.insert({_assetType.first,gasAmount});
                }
            }

            if(assetTypeAmount.empty()){
                ERRORLOG("There was no fund reward the day before!");
                return -999;
            }
            

            uint64_t totalLockedAmount = 0;
            uint64_t retValue = 0;
            std::string owner = _utxo.owner().at(0);

            ret = CheckFundQualificationAndGetRewardAmount(owner,tx.time(),retValue,checkAnomaly);
            // if(ret != 0){
            //     ERRORLOG("Not allowed to Bonus! ret:{}",ret);
            //     return ret - 60;
            // }
            if(ret == -6){
                // std::cout << "You have already claimed the fund reward." << std::endl;
                ERRORLOG( "You have already claimed the fund reward.",ret );
                return -998;
            }else{
                ERRORLOG( "Error in checking eligibility for receiving fund",ret );
            }
        
            if(!lockedReward.empty() && retValue != 0){
                
                if(dbReader.getTotalLockedAmonut(totalLockedAmount) == DBStatus::DB_SUCCESS && totalLockedAmount != 0){
                    DEBUGLOG("retValue : {}, totalLockedAmount : {}", retValue , totalLockedAmount);
                }else{
                    ERRORLOG("Get total locked amount failed!");
                    return -39;
                }

                if(retValue != 0 && totalLockedAmount != 0){
                    isLocked = true;
                    lockedRate = double(retValue) / double(totalLockedAmount);
                }
            }

            uint64_t times , count = 0;
            if(!packageReward.empty()){
                
                bool canReward = VerifyBonusAddr(owner);
                //int64_t stakeTime = ca_algorithm::GetPledgeTimeByAddr(owner, global::ca::StakeType::STAKE_TYPE_NODE);
                if ( canReward)
                {
                    DEBUGLOG("verify: Meet the pledge qualifications.");
                    if(dbReader.getPackagerCountByPeriod(period -1,owner,times) == DBStatus::DB_SUCCESS && 
                        dbReader.getBlockNumberByPeriod(period -1,count) == DBStatus::DB_SUCCESS){
                        DEBUGLOG("times : {}, count : {}",times ,count);
                    }else{
                        ERRORLOG("verify: Get addr package times failed!");
                        return -40;
                    }
                }
                if(times != 0 && count != 0){
                    isPackage = true;
                    packageRate = double(times) / double(count);
                }   

            }

            if(times == 0 && retValue == 0){
                ERRORLOG("The account is not eligible to claim fund rewards");
                return -41;
            }

            uint64_t totalRewardAmount = 0;
            auto iter = assetTypeAmount.find(_utxo.assettype());
            if(iter != assetTypeAmount.end()){
                totalRewardAmount = iter->second;   
            }else{
                ERRORLOG("assetTypeAmount not find utxo assetType :{}",_utxo.assettype());
                return -42;
            }

            if(isLocked && isPackage){
                if(_utxo.vout_size() != 2){
                    ERRORLOG("The number of vouts is incorrect");
                    return -43;
                }
                for(int i = 0; i < _utxo.vout_size(); ++i){
                    if(_utxo.vout(i).addr() != owner){
                        ERRORLOG("The address that receives the reward is not the initiator");
                        return -44;
                    }

                    double rate = 0.0;
                    if(i == 0){
                        //locked reward
                        rate = lockedRate;
                    }else{
                        //package reward
			            rate =  packageRate;
                    }

                    if(_utxo.vout(i).value() !=  uint64_t(totalRewardAmount * rate * 0.5)){
                        ERRORLOG("index :{} vout value :{} is not reward value :{}!",i,_utxo.vout(i).value(),(totalRewardAmount * rate * 0.5));
                        return -45;
                    }
                }
            }else if(isLocked && !isPackage){
                if(_utxo.vout_size() != 1){
                    ERRORLOG("The number of vouts is incorrect");
                    return -46;
                }
                if(_utxo.vout(0).addr() != owner){
                    ERRORLOG("The address that receives the reward is not the initiator");
                    return -47;
                }
                if(_utxo.vout(0).value() != uint64_t(totalRewardAmount * lockedRate * 0.5)){
                    ERRORLOG(" vout value :{} is not reward value :{}!",_utxo.vout(0).value(),(totalRewardAmount * lockedRate * 0.5));
                    return -48;
                }

            }else if(!isLocked && isPackage){
                if(_utxo.vout_size() != 1){
                    ERRORLOG("The number of vouts is incorrect");
                    return -49;
                }
                if(_utxo.vout(0).addr() != owner){
                    ERRORLOG("The address that receives the reward is not the initiator");
                    return -50;
                }
                if(_utxo.vout(0).value() != uint64_t(totalRewardAmount * packageRate * 0.5)){
                    ERRORLOG(" vout value :{} is not reward value :{}!",_utxo.vout(0).value(),(totalRewardAmount * lockedRate * 0.5));
                    return -51;
                }
            }else{
                ERRORLOG("Node are not eligible to receive funds");
                return -52;
            }

        }
        std::string award_addr;
        std::vector<std::string> addressListForPledge;
        auto status = dbReader.getStakeAddr(addressListForPledge);
        if (DBStatus::DB_SUCCESS != status && DBStatus::DB_NOT_FOUND != status)
        {
            return -29;
        }

        if (global::ca::TxType::TX != txType && global::ca::TxType::DEPLOY != txType && global::ca::TxType::CALL != txType)
        {
            std::set<std::string> setOwner(_utxo.owner().begin(), _utxo.owner().end());
            if (setOwner.size() != 1)
            {
                return -30;
            }
        }

        // Within the height of 50, the pledge transaction or the transaction of the initial account can be initiated arbitrarily
        if (txHeight <= global::ca::MIN_UNSTAKE_HEIGHT && (_utxo.owner().at(0) == GetInitAccountAddr() || global::ca::TxType::STAKE == txType || global::ca::TxType::DELEGATE == txType))
        {
            for (auto &signNode : tx.signature())
            {
                if (!isValidAddress(GenerateAddr(signNode.pub())))
                {
                    return -31;
                }
            }
        }
        else
        {
            //Modern development time judges whether the first circulation node is fully pledged and delegatinged
            bool shouldUseAgent = TxHelper::requiresAgent(tx);

            for (int i = (shouldUseAgent ? 0 : 1); i < tx.signature_size(); ++i)
            {
                std::string signAddr;
                signAddr = GenerateAddr(tx.signature(i).pub());
                int ret = CheckNodeValidity(signAddr);
                if(ret != 0){
                    ERRORLOG("shouldUseAgent Check Verify Node Qualification fail, ret {}", ret);
                }
            }
        }
    }

    falg = false;
    for(const auto &_utxo : tx.utxos())
    {
        if(_utxo.gas() != global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE)
        {
            continue;
        }

        if(_utxo.owner(0) != GetInitAccountAddr() &&
            _utxo.assettype() != global::ca::ASSET_TYPE_OHI)
        {
            auto ret = GetAssetTypeIsValid(_utxo.assettype());
            if(ret != 0)
            {
                ERRORLOG("GetAssetTypeIsValid error ret:{} assettype:({})", ret, _utxo.assettype());
                return -900;
            }
        }

        if(isCallContractType && !falg && flowTxType == FlowTxType::FlowInTx && _utxo.vout_size() == 2 && _utxo.vin_size() == 0 && tx.utxos_size() == 1)
        {
            falg = true;
            continue;
        }

        uint64_t vinAmount = 0;
        for (auto &vin : _utxo.vin())
        {
            std::string addr = "";
            if(vin.contractaddr().empty())
            {
                if(isRLPTransaction){
                    addr = ethTx.from;
                }else{addr = GenerateAddr(vin.vinsign().pub());}
            }
            for(auto & prevout : vin.prevout())
            {
                std::string utxo = prevout.hash();
                std::string balance ;
                
                if (DBStatus::DB_SUCCESS != dbReader.getUtxoValueByUtxoHashes(utxo, addr, _utxo.assettype(), balance))
                {
                    MagicSingleton<BlockHelper>::GetInstance()->pushMissUtxo(utxo);
                    ERRORLOG("getTransactionByHash failed!");
                    continue;
                }

                uint64_t stakeValue = 0;
                std::string underline = "_";
                std::vector<std::string> utxoValues;

                if(balance.find(underline) != std::string::npos)
                {
                    StringUtil::SplitString(balance, "_", utxoValues);
                    
                    for(int i = 0; i < utxoValues.size(); ++i)
                    {
                        stakeValue += std::stol(utxoValues[i]);
                    }

                    vinAmount += stakeValue;
                }
                else
                {
                    vinAmount +=  std::stol(balance);
                }

            }
        }

        uint64_t voutAmount = 0;
        for (auto &vout : _utxo.vout())
        {
            voutAmount += vout.value();
        }

        if (voutAmount != vinAmount)
        {
            ERRORLOG("Input is not equal to output ,voutAmount = {}, vinAmount = {}", voutAmount, vinAmount);
            return -34;
        }

        for(auto & vin : _utxo.vin())
        {
            std::string vinAddr;
            if(vin.contractaddr().empty())
            {
                if (!tx.rlp().empty())
                {
                    ethVerify::EthTransaction ethTx;
                    dev::bytes rlpBytes = dev::fromHex(tx.rlp());
                    eth_errors e;
                    int ret_E = ethVerify::verifyRLP(rlpBytes, e, &ethTx, expectedNonce);
                    if (ret_E != 0)
                    {
                        ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
                        return ret_E;
                    }
                    vinAddr = ethTx.from;
                }
                else
                {
                    vinAddr = GenerateAddr(vin.vinsign().pub());
                }
            }
            else if(isContractDeploymentEnabled || isCallContractType)
            {
                vinAddr = vin.contractaddr();
            }

            for (auto & prevHash : vin.prevout())
            {
                std::string prevUtxo = prevHash.hash();
                std::string txRawData;
                if (DBStatus::DB_SUCCESS !=  dbReader.getTransactionByHash(prevUtxo, txRawData))
                {
                    ERRORLOG("get tx failed");
                    return -35;
                }

                CTransaction prevTx;
                prevTx.ParseFromString(txRawData);
                if (prevTx.hash().size() == 0)
                {
                    return -36;
                }

                std::vector<std::string> prevTxOutAddr;
                for(const auto& utxo2: prevTx.utxos())
                {
                    for (auto & txOut : utxo2.vout())
                    {
                        prevTxOutAddr.push_back(txOut.addr());
                    }
                }

                if (std::find(prevTxOutAddr.begin(), prevTxOutAddr.end(), vinAddr) == prevTxOutAddr.end())
                {
                    ERRORLOG("utxo unknown source !");
                    return -37;
                }
            }
        }
    }

    uint64_t endTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    if(global::ca::TxType::TX == txType)
    {
        MagicSingleton<Benchmark>::GetInstance()->transactionDbVerifyMap(tx.hash(), endTime - startTime);  
    }
	
    return 0;
}

int ca_algorithm::doubleSpendCheck(const CTransaction &tx, bool enableMissingBlockRequest, std::string* missingUtxo)
{
    std::string redeemUtxoHashValue;
    std::string UndelegatingUtxoHash;
    std::string delegatingedNode;
    std::string redeemlockUtxoHash;
    global::ca::TxType txType = (global::ca::TxType)tx.type();

    if((global::ca::TxType)tx.type() != global::ca::TxType::TX)
    {
        try
        {
            nlohmann::json dataJson = nlohmann::json::parse(tx.data());
            nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
            if (global::ca::TxType::UNSTAKE == txType)
            {             
                redeemUtxoHashValue = txInfo["unstakeUtxo"].get<std::string>();
            }
            else if(global::ca::TxType::UNLOCK == txType)
            {
                redeemlockUtxoHash = txInfo["unLockUtxo"].get<std::string>();
            }
            else if (global::ca::TxType::UNDELEGATE == txType)
            {
                UndelegatingUtxoHash = txInfo["undelegatingUtxo"].get<std::string>();
                delegatingedNode = txInfo["bonusAddr"].get<std::string>();        
            }

        }
        catch(...)
        {
            ERRORLOG(RED "JSON failed to parse data field!" RESET);
            return -1;
        }
    }

    DBReader dbReader;
    for(const auto & _utxo:tx.utxos())
    {
        for (auto &vin : _utxo.vin())
        {
            global::ca::TxType txType = (global::ca::TxType)tx.type();
            std::string addr;
            if(vin.contractaddr().empty())
            {
                if (!tx.rlp().empty())
                {
                    ethVerify::EthTransaction ethTx;
                    dev::bytes rlpBytes = dev::fromHex(tx.rlp());
                    eth_errors e;
                    int ret_E = ethVerify::verifyRLP(rlpBytes, e, &ethTx);
                    if (ret_E != 0)
                    {
                        ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
                        return ret_E;
                    }
                    addr = ethTx.from;
                }
                else
                {
                    addr = GenerateAddr(vin.vinsign().pub());
                }
            }
            else if(global::ca::TxType::DEPLOY == txType || global::ca::TxType::CALL == txType)
            {
                addr = vin.contractaddr();
            }

            std::vector<std::string> utxoHashesList;
            // specil factor on bonus
            bool bonusCheck = true;
            if (global::ca::TxType::BONUS == txType && dbReader.getUtxoHashsByAddress(addr, _utxo.assettype(), utxoHashesList) == DBStatus::DB_NOT_FOUND)
            {
                bonusCheck = false;
            }
            if (DBStatus::DB_SUCCESS != dbReader.getUtxoHashsByAddress(addr, _utxo.assettype(), utxoHashesList) && bonusCheck)
            {
                ERRORLOG(RED "getUtxoHashsByAddress failed! addr:{}" RESET, addr);
                return -2;
            }

            for (auto & prevout : vin.prevout())
            {
                std::string preUtxo = prevout.hash();
                uint32_t index = prevout.n();
                

                if(global::ca::TxType::STAKE == txType)
                {
                    std::vector<std::string> stake_unspent_outputs;
                    auto ret = dbReader.getStakeUtxoByAddr(addr,_utxo.assettype(),stake_unspent_outputs);
                    if(ret != DBStatus::DB_NOT_FOUND)
                    {
                        ERRORLOG("There has been a pledge transaction before!");
                        return -3;
                    }

                    if (utxoHashesList.cend() == std::find(utxoHashesList.cbegin(), utxoHashesList.cend(), preUtxo))
                    {
                        if (missingUtxo != nullptr)
                        {
                            *missingUtxo = preUtxo;
                        }

                        if (enableMissingBlockRequest)
                        {
                            DEBUGLOG("enableMissingBlockRequest");
                            MagicSingleton<BlockHelper>::GetInstance()->pushMissUtxo(preUtxo);
                        }
                        DEBUGLOG("getUtxoHashsByAddress fail (addr:{}, txHashs:{})", addr, preUtxo);
                        return -8;
                    }

                }
                else if ((global::ca::TxType::UNSTAKE == txType) && redeemUtxoHashValue == preUtxo && 1 == index)
                {
                    if (DBStatus::DB_SUCCESS != dbReader.getStakeUtxoByAddr(addr, _utxo.assettype(), utxoHashesList))
                    {
                        ERRORLOG(RED "getStakeAddrUtxo failed!" RESET);
                        return -4;
                    } 
                    if (utxoHashesList.cend() == std::find(utxoHashesList.cbegin(), utxoHashesList.cend(), preUtxo))
                    {
                        if(missingUtxo != nullptr)
                        {
                            *missingUtxo = preUtxo;
                        }
                        return -5;
                    }
                }
                else if ((global::ca::TxType::UNLOCK == txType) && redeemlockUtxoHash == preUtxo && 1 == index)
                {
                    if (DBStatus::DB_SUCCESS != dbReader.getLockAddrUtxo(addr, _utxo.assettype(), utxoHashesList))
                    {
                        ERRORLOG(RED "getStakeAddrUtxo failed!" RESET);
                        return -4;
                    } 
                    if (utxoHashesList.cend() == std::find(utxoHashesList.cbegin(), utxoHashesList.cend(), preUtxo))
                    {
                        if(missingUtxo != nullptr)
                        {
                            *missingUtxo = preUtxo;
                        }
                        return -5;
                    }
                }
                else if((global::ca::TxType::UNDELEGATE == txType) && UndelegatingUtxoHash == preUtxo && 1 == index)
                {
                    if (DBStatus::DB_SUCCESS != dbReader.getDelegatingAddrUtxoByBonusAddr(delegatingedNode, addr,_utxo.assettype(),utxoHashesList))
                    {
                        ERRORLOG("getDelegatingAddrUtxoByBonusAddr failed! delegatingNode{},addr{},assetType{}utxoHashesList{}",delegatingedNode,addr,_utxo.assettype(),utxoHashesList[0]);
                        return -6;
                    }
                    if (utxoHashesList.cend() == std::find(utxoHashesList.cbegin(), utxoHashesList.cend(), preUtxo))
                    {
                        if(missingUtxo != nullptr)
                        {
                            *missingUtxo = preUtxo;
                        }
                        return -7;
                    }                
                }
                //specil factor on bonus
                else if (!bonusCheck)
                {
                    return 0;
                }
                else
                {
                    if(!tx.rlp().empty()){
                        continue;
                    }

                    if (utxoHashesList.cend() == std::find(utxoHashesList.cbegin(), utxoHashesList.cend(), preUtxo))
                    {
                        if (missingUtxo != nullptr)
                        {
                            *missingUtxo = preUtxo;
                        }

                        if (enableMissingBlockRequest)
                        {
                            DEBUGLOG("enableMissingBlockRequest");
                            MagicSingleton<BlockHelper>::GetInstance()->pushMissUtxo(preUtxo);
                        }
                        DEBUGLOG("getUtxoHashsByAddress fail (addr:{}, txHashs:{})", addr, preUtxo);
                        return -8;
                    }
                }
            }
        }
    }
    return 0;
}

int ca_algorithm::memVerifyBlock(const CBlock& block, bool isVerify, BlockStatus* blockStatus, global::ca::SaveType saveType)
{
    std::map<std::string, uint64_t> expected_nonces;
    if (BuildBlockNonceView(block, expected_nonces) != 0)
    {
        return -10;
    }
    // Block version number must be 0
    if ( block.version() != global::ca::kCurrentBlockVersion)
    {
        return -1;
    }
    
    // The size of the serialized block must be less than 1024 * 1024 * 4
    if (block.SerializeAsString().length() > 1024 * 1024 * 4)
    {
        return -2;
    }
    
    // Verify whether the block hash is the same
    if (block.hash() != CalcBlockHash(block))
    {
        return -3;
    }

    // Verify that merklelot is the same
    if (block.merkleroot() != calculateBlockMerkle(block))
    {
        return -4;
    }
    
    // The number of transactions in the block must be greater than 0 \
    and a multiple of 2 (normal transaction, signature transaction)
    if(block.txs_size() % 1 != 0)
    {
       return -5;
    } 

    // Transactions in the block must be in groups of 2 \
    Key is the calculated hash and value is the transaction
    std::map<std::string ,std::vector<CTransaction>>  txGroup; 
    for(auto tx : block.txs())
    {
        std::string hash;
        if (GetTransactionType(tx) == kTransactionTypeTx) 
        {

            hash = tx.hash();
        }
        else
        {
            return -6;
        }

        auto iter = txGroup.find(hash);
        if(iter == txGroup.end())
        {
            txGroup[hash] = std::vector<CTransaction>{};
        }
        txGroup[hash].push_back(tx);
    }

    // Whether there are two transactions in the same group and whether they are of two types. \
    Re insert the type sorting into the new array
    std::vector<CTransaction> txSort;
    auto iter = txGroup.begin();

    CBlock tmpBlock = block;
    tmpBlock.clear_txs();
    std::map<std::string, std::future<int>> taskResults;
    while(iter != txGroup.end())
    {
        if(iter->second.size() != 1)
        {
            DEBUGLOG("Number of transaction types:{}",iter->second.size());
            return -7;
        }

        CTransaction tx;
        for(auto itemTx : iter->second)
        {
            TransactionType txType = GetTransactionType(itemTx);
            if(txType == kTransactionTypeTx)
            {
                tx = itemTx;
            }
        }

		if (tx.hash().empty() )
		{
			return -8;
		}

        if(isVerify)
        {
            const auto nonce_it = expected_nonces.find(tx.hash());
            const std::optional<uint64_t> expected_nonce =
                nonce_it == expected_nonces.end() ? std::nullopt : std::optional<uint64_t>(nonce_it->second);
            auto task = std::make_shared<std::packaged_task<int()>>([tx, saveType, expected_nonce] {
                return ca_algorithm::memoryVerificationTransactionRequest(tx, saveType, expected_nonce);
            });
            try
            {
                taskResults[tx.hash()] = task->get_future();
            }
            catch(const std::exception& e)
            {
                std::cerr << e.what() << '\n';
            }
            MagicSingleton<TaskPool>::GetInstance()->commitWorkTask([task](){(*task)();});
        }

        ++iter;
    }

    bool verifyFlag = false;
    for (auto& res : taskResults)
    {
        int ret = res.second.get();
        if (ret != 0)
        {
            verifyFlag = true;
            if(blockStatus != NULL)
            {
                auto txStatus = blockStatus->add_txstatus();
                txStatus->set_txhash(res.first);
                txStatus->set_status(ret);
            }
            ERRORLOG("AAAC memoryVerificationTransactionRequest Error:{}, txHash:{}",ret, res.first);
        }
    }
    if(verifyFlag)
    {
        return -9;
    }
    return 0;
}

bool ca_algorithm::verifyDirtyContract(const std::vector<std::string> &isContractVerified, const std::vector<std::string> &calledContract)
{
    std::set<std::string> verifyCalledContractSet(isContractVerified.begin(), isContractVerified.end());
    std::set<std::string> calledContractContainer(calledContract.begin(), calledContract.end());
    std::vector<std::string> result;
    std::set_difference(calledContractContainer.begin(), calledContractContainer.end(),
                        verifyCalledContractSet.begin(), verifyCalledContractSet.end(),
                        std::back_inserter(result));
    if (!result.empty())
    {
        for (const auto& addr : calledContract)
        {
            ERRORLOG("executed {}", addr);
        }
        for (const auto& addr : isContractVerified)
        {
            ERRORLOG("found {}", addr);
        }
        for (const auto& addr : result)
        {
            ERRORLOG("result {}", addr);
        }
        return false;
    }
    return true;
}

int ca_algorithm::verify_contract_storage(const nlohmann::json& txInfo, const nlohmann::json& expected_tx_info)
{
    nlohmann::json storage = txInfo[Evmone::storageKeyForContract];
    nlohmann::json prevHash = txInfo[Evmone::contractPreHashKey];
    nlohmann::json log;
    auto logFound = txInfo.find(Evmone::contract_log_key_name);
    if (logFound != txInfo.end())
    {
        log = logFound.value();
    }

    nlohmann::json selfdestructed = txInfo[Evmone::contractDestructionKey];
    nlohmann::json creation = txInfo[Evmone::contractCreationKeyLabel];

    nlohmann::json expectedStorage = expected_tx_info[Evmone::storageKeyForContract];
    nlohmann::json expectedPrevHash = expected_tx_info[Evmone::contractPreHashKey];
    nlohmann::json expectedLog;
    logFound = expected_tx_info.find(Evmone::contract_log_key_name);
    if (logFound != expected_tx_info.end())
    {
        expectedLog = logFound.value();
    }
    nlohmann::json expectedSelfdestructed = expected_tx_info[Evmone::contractDestructionKey];
    nlohmann::json expectedCreation = expected_tx_info[Evmone::contractCreationKeyLabel];

    if (prevHash != expectedPrevHash)
    {
        ERRORLOG("prevHash doesn't match\ntx: {} \n expect: {}", prevHash.dump(4), expectedPrevHash.dump(4));
        return -1;
    }
    if (storage != expectedStorage)
    {
        ERRORLOG("storage doesn't match\ntx: {} \n expect: {}", storage.dump(4), expectedStorage.dump(4));
        return -2;
    }
    if (log != expectedLog)
    {
        ERRORLOG("log doesn't match\ntx: {} \n expect: {}", log.dump(4), expectedLog.dump(4));
        return -3;
    }
    if (selfdestructed != expectedSelfdestructed)
    {
        ERRORLOG("selfdestructed doesn't match\ntx: {} \n expect: {}", selfdestructed.dump(4), expectedSelfdestructed.dump(4));
        return -4;
    }

    if (creation != expectedCreation)
    {
        ERRORLOG("creation doesn't match\ntx: {} \n expect: {}", creation.dump(4), expectedCreation.dump(4));
        return -5;
    }
    return 0;
}

int ca_algorithm::verifyContractDepsTx(const std::map<std::string, CTransaction>& ContractTxs, std::map<std::string,std::vector<std::string>>& dependencyTransactionRequest, const CBlock &block, nlohmann::json& blockData, global::ca::SaveType saveType)
{
    contractDataContainer contractDataStorage;
    std::map<std::string, std::string> contractPrehashCache_;
    std::string validateOut;

    // 转换为时间戳排序的容器，确保与打包者执行顺序一致
    // Convert to timestamp-sorted container to ensure consistent execution order with packager
    std::vector<std::pair<uint64_t, CTransaction>> tx_with_timestamp;
    for (const auto& it : ContractTxs)
    {
        tx_with_timestamp.emplace_back(it.second.time(), it.second);
    }

    // 按时间戳排序（时间戳相同时按哈希排序保证确定性）
    // Sort by timestamp (use hash as secondary key for determinism)
    std::sort(tx_with_timestamp.begin(), tx_with_timestamp.end(),
              [](const auto& a, const auto& b) {
                  if (a.first != b.first) return a.first < b.first;
                  return a.second.hash() < b.second.hash();
              });

    // 按时间戳顺序验证合约交易
    // Verify contract transactions in timestamp order
    for (const auto& [timestamp, tx] : tx_with_timestamp)
    {
        auto txType = (global::ca::TxType)tx.type();
        if (txType != global::ca::TxType::CALL && txType != global::ca::TxType::DEPLOY)
        {
            continue;
        }
        auto storageFound = blockData.find(tx.hash());
        if (storageFound == blockData.end())
        {
            ERRORLOG("can't find {} storage in block {}", tx.hash(), block.hash());
            return -1;
        }
        try
        {
            auto output = storageFound.value()[Evmone::contractOutputKey].get<std::string>();
            nlohmann::json dataJson = nlohmann::json::parse(tx.data());
            nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();

            std::string contractOwnerEvmAddress;
            if(txInfo.find(Evmone::contractSenderKeyName_) != txInfo.end())
            {
                contractOwnerEvmAddress = txInfo[Evmone::contractSenderKeyName_].get<std::string>();
            }
            auto vmType = txInfo[Evmone::contractVmKeyName].get<global::ca::VmType>();

            std::string code;
            std::string deployerAddr;
            std::string input;
            uint64_t contractTransfer = 0;
            std::string contractAddress;
            FlowTxType flowTxType = FlowTxType::Unknown;
            if (txType == global::ca::TxType::CALL)
            {
                input = txInfo[Evmone::contract_input_key_name].get<std::string>();
                if(vmType == global::ca::VmType::EVM)
                {
                    contractTransfer = txInfo[Evmone::contractTransferKeyLabel].get<uint64_t>();
                    contractAddress = txInfo[Evmone::contractRecipientKeyNameStr].get<std::string>();
			        deployerAddr = txInfo[Evmone::contractDeployerKeyAlias].get<std::string>();		
                }

                flowTxType = GetFlowTxType(txInfo);
            }
            else if (txType == global::ca::TxType::DEPLOY)
            {
                code = txInfo[Evmone::contract_input_key_name].get<std::string>();
                contractAddress = txInfo[Evmone::contractRecipientKeyNameStr].get<std::string>();
                deployerAddr = global::ca::kVirtualDeploymentContractAddress;//todo change to sender
            }

            std::string expectedOutput;
            nlohmann::json expectedJTxInfo;
            EvmHost host(&contractDataStorage);
            int64_t gasCost = 0;
            CTransaction callOutRequest;
            //callOutRequest.set_type(global::ca::kTxSign);
            std::vector<std::string> utxoHashesList;
            std::pair<std::string, std::string> gasTrade = {tx.utxos(0).owner(0),tx.utxos(0).assettype()};
            if (txType == global::ca::TxType::DEPLOY || txType == global::ca::TxType::CALL)
            {   
                // 跃入
                if (flowTxType == FlowTxType::FlowInTx)
                {
                    // gasTrade = {tx.utxos(0).owner(0), global::ca::ASSET_TYPE_VOTE};
                }
                // 跃出
                else if(flowTxType == FlowTxType::FlowOutTx)
                {
                    DEBUGLOG("transaction is FlowOut.");
                    //默认是越出的资产类型支付gas
                    gasTrade = {tx.utxos(0).owner(0), tx.utxos(0).assettype()};
                }
            }

            bool falg = false;
            for(const auto utxo : tx.utxos())
            {
                if (!falg && flowTxType == FlowTxType::FlowInTx && utxo.vout_size() == 2 && utxo.vin_size() == 0 && tx.utxos_size() == 1)
                {
                    falg = true;
                    continue;
                }
                
                if(utxo.gas() != global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE)
                {
                    continue;
                }
                //如果越出单独支付gas
                gasTrade = {utxo.owner(0), utxo.assettype()};
            }

            int ret = 0;
            std::string fromAddr;
            int mapping = -1;
            if(vmType == global::ca::VmType::EVM)
            {

                if(!tx.rlp().empty())
                {
                    ethVerify::EthTransaction ethTx;
                    dev::bytes rlpBytes = dev::fromHex(tx.rlp());
                    eth_errors e;
                    int ret_E = ethVerify::verifyRLP(rlpBytes, e, &ethTx);
                    if (ret_E != 0)
                    {
                        ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
                        return ret_E;
                    }
                    fromAddr = ethTx.from;
                }else{
                    ret = get_call_contract_from_addr(tx,fromAddr);
                    if (ret != 0)
                    {
                        ERRORLOG("get_call_contract_from_addr fail ret: {}", ret);
                        return -2;
                    }
                }

                if(fromAddr != contractOwnerEvmAddress)
                {
                    return -3;
                }
                
                
                evmc_message message{};
                if(txType == global::ca::TxType::DEPLOY)
                {
                    ret = Evmone::VerifyContractAddress(fromAddr, contractAddress);
                    if (ret < 0)
                    {
                        return -4;
                        ERRORLOG("verify contract address fail, ret: {}", ret)
                    }
                    host.code = evm_utils::StringTobytes(code);
                    if (code.empty())
                    {
                        ERRORLOG("fail to convert contract code to hex format");
                        return -5;
                    }


                    // 使用区块头的time字段，上下10秒取整后作为合约内部的blockTimestamp
                    int64_t blockTimestamp = block.time();
                    if (blockTimestamp < 0)
                    {
                        return -6;
                    }

                    int64_t blockPrevRandao = evmEnvironment::get_block_prev_randao(tx);
                    if (blockPrevRandao < 0)
                    {
                        return -7;
                    }
                    
                    ret = Evmone::DeployContract(fromAddr, host, message,
                                                 contractAddress, blockTimestamp, blockPrevRandao, block.height(), gasTrade.second);
                    if(ret != 0)
                    {
                        ERRORLOG("VM failed to deploy contract!, ret {}", ret);
                        return ret - 100;
                    }
                    gasCost = host.gas_cost;
                    //TODO::

                    std::string new_baseFee ;
                    ret = VerifyContractBaseFee(fromAddr,gasCost,new_baseFee);
                    if(ret != 0){
                        ERRORLOG("VerifyContractBaseFee failed!");
                        return ret -200;
                    }

                    if(txInfo["baseFee"].get<std::string>() != new_baseFee){
                        return ret -300;
                    }

                    expectedOutput = host.output;
                }
                else if(txType == global::ca::TxType::CALL)
                {
                    evmc::bytes contractCode;
                    if (evm_utils::GetContractCode(contractAddress, contractCode) != 0)
                    {
                        ERRORLOG("fail to get contract code");
                        return -8;
                    }
                    host.code = contractCode;
                    // 使用区块头的time字段，上下10秒取整后作为合约内部的blockTimestamp
                    int64_t blockTimestamp = block.time();
                    if (blockTimestamp < 0)
                    {
                        return -9;
                    }

                    int64_t blockPrevRandao = evmEnvironment::get_block_prev_randao(tx);
                    if (blockPrevRandao < 0)
                    {
                        return -10;
                    }
                    ret = Evmone::CallContract(fromAddr, input,
                                               host, contractTransfer, contractAddress, message, blockTimestamp,
                                               blockPrevRandao, block.height(),gasTrade.second);
                    if(ret != 0)
                    {
                        ERRORLOG("VM failed to call contract!, ret {}", ret);
                        return ret - 200;
                    }
                    gasCost = host.gas_cost;
                    //TODO::

                    std::string new_baseFee;
                    ret = VerifyContractBaseFee(fromAddr,gasCost,new_baseFee);
                    if(ret != 0){
                        ERRORLOG("VerifyContractBaseFee failed!");
                        return ret -200;
                    }

                    if(txInfo["baseFee"].get<std::string>() != new_baseFee){
                        return ret -300;
                    }

                    expectedOutput = host.output;
                    
                    if (flowTxType == FlowTxType::FlowInTx)
                    {
                        
                        DEBUGLOG("!CallType.empty(), input:{}", input);
                        mapping = Evmone::ValidateMappingTransaction(input, contractAddress, contractOwnerEvmAddress, tx,host,message,validateOut);
                        if (mapping != 0)
                        {
                            ERRORLOG("ValidateMappingTransaction fail !!!,ret:{}", ret);
                            return -11;
                        }
                    }
                    if(flowTxType == FlowTxType::FlowOutTx)
                    {
                        EvmHost tempHost(&contractDataStorage);
                        evmc::bytes contractCode;
                        if (evm_utils::GetContractCode(contractAddress, contractCode) != 0)
                        {
                            ERRORLOG("fail to get contract code");
                            return -12;
                        }
                        tempHost.code = contractCode;
                        evmc_message tempMessage{};
                        evmc::bytes input = evm_utils::StringTobytes("0x313ce567");
                        int ret = Evmone::CallContractWithResult(fromAddr, "0x313ce567",
                                             tempHost, contractTransfer, contractAddress, message, blockTimestamp,
                                             blockPrevRandao, block.height(), gasTrade.second,validateOut);
                        if(ret != 0)
                        return ret;
                    }
                }
                //deal with jumpout contract 
                
                        
                try
                {
                    nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                    nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                    std::string hexStr = txInfo["input"].get<std::string>();
                    std::string strPart;
                    size_t startIndex = 0;
                    if (hexStr.substr(0, 2) == "0x")
                    {
                        startIndex = 2;
                    }
                    strPart = hexStr.substr(startIndex, 8);
                    DEBUGLOG("strPart :{}", strPart);
                    if ((global::ca::TxType)tx.type() == global::ca::TxType::CALL && strPart == "7c405325")
                    {
                        DEBUGLOG("mapping = 0");
                        mapping = 0;
                    }
                }
                catch (const std::exception &e)
                {
                    ERRORLOG("parse transaction data fail {}", e.what())
                    return -14;
                }

                

                ret = Evmone::ContractInfoAdd(host, tx.hash(), txType, tx.version(), expectedJTxInfo, contractPrehashCache_);
                if(ret != 0)
                {
                    ERRORLOG("ContractInfoAdd fail! ret {}", ret);
                    return -15;
                }

                auto found = dependencyTransactionRequest.find(tx.hash());
                if(found == dependencyTransactionRequest.end())
                {
                    return -16;
                }
                std::vector<std::string> calledContract;
                Evmone::invokedContract(host, calledContract);
                if (!verifyDirtyContract(found->second, calledContract))
                {
                    ERRORLOG("dirty contract doesn't match execute result, tx hash: {}", tx.hash());
                    return -17;
                }
                    
                callOutRequest.set_data(tx.data());
                callOutRequest.set_note(tx.note());
                callOutRequest.set_reserve0(tx.reserve0());
                callOutRequest.set_reserve1(tx.reserve1());

                bool isFlowInTx = false;
                bool isFlowOutTx = false;
                std::pair<std::string, std::string> tradeMapping;
                if (mapping == 0)
                {
                    std::string strPart;
                    size_t startIndex = 0;
                    boost::multiprecision::cpp_int numPart;
                    std::string hexStr = txInfo["input"].get<std::string>();
                    if (hexStr.substr(0, 2) == "0x")
                    {
                        startIndex = 2;
                    }
                    strPart = hexStr.substr(startIndex, 8);
                    std::string numStr = hexStr.substr(startIndex + 8);

                    std::string ExchangeRate;
                    if (ca_algorithm::GetAssetRate(contractAddress, ExchangeRate) != 0)
                    {
                        return -18;
                    }
                    boost::multiprecision::cpp_dec_float_100 AsseRate(ExchangeRate);
                    
                    numPart = boost::multiprecision::cpp_int("0x" + numStr);
                    static const boost::multiprecision::cpp_int kMaxUint64(static_cast<std::string>("18446744073709551615"));
                    boost::multiprecision::cpp_int rateInt;
                    int rateDecimal = 0;
                    boost::trim(ExchangeRate); 
                    size_t pos = ExchangeRate.find('.');
                    if (pos != std::string::npos)
                    {
                        std::string integerPart = ExchangeRate.substr(0, pos);
                        std::string fractionalPart = ExchangeRate.substr(pos + 1);
                        fractionalPart.erase(fractionalPart.find_last_not_of('0') + 1);
                        rateDecimal = fractionalPart.length();
                        rateInt = boost::multiprecision::cpp_int(integerPart + fractionalPart);
                    }
                    else
                    {
                        rateInt = boost::multiprecision::cpp_int(ExchangeRate);
                    }
                    char *endptr;
                    //int decimal = strtoul(validateOut.substr(2).c_str(), &endptr, 16);
                    int decimal = 8;
                    boost::multiprecision::cpp_int decimalNumBig;
                    if (decimal == 0)
                    {
                        decimalNumBig = 1;
                    }
                    else
                    {
                        decimalNumBig = (boost::multiprecision::pow(boost::multiprecision::cpp_int(10), decimal));
                    }

                    if (strPart == "6e27d889")
                    {
                        isFlowInTx = true;
                        boost::multiprecision::cpp_dec_float_100 curBalance = ((boost::multiprecision::cpp_dec_float_100)numPart * AsseRate);
                        std::cout << "Current exchange rate:" << AsseRate << std::endl;
                        std::cout << "Inflow of Actual Balance:" << curBalance << std::endl;
                        boost::multiprecision::cpp_int amountTemp =
                            (boost::multiprecision::cpp_int(numPart) * rateInt * global::ca::kDecimalNum) /
                            (boost::multiprecision::pow(boost::multiprecision::cpp_int(10), rateDecimal) * decimalNumBig);

                        if (amountTemp < 0 || amountTemp > kMaxUint64)
                        {
                            DEBUGLOG("Amount overflow: {}", amountTemp.str());
                        }
                         uint64_t amount = static_cast<uint64_t>(amountTemp);
                         CTxUtxos *txUtxo = callOutRequest.add_utxos();
                         CTxOutput *voutToAddress = txUtxo->add_vout();
                         voutToAddress->set_addr(contractOwnerEvmAddress);
                         voutToAddress->set_value(amount);
                     }
                    else if (strPart == "7c405325")
                    {
                        isFlowOutTx = true;
                        std::map<std::string, TxHelper::ProposalInfo> assetMap;
                        {
                    		DBReadWriter db;
                            std::vector<std::string> ASSERT_TYPES;
                            auto dbRet = db.getAssetType(ASSERT_TYPES);
                            if(dbRet == DBStatus::DB_NOT_FOUND)
                            {
                                return -19;
                            }
                            else if(dbRet != DBStatus::DB_SUCCESS)
                            {
                                ERRORLOG("VoteCache error -1, getAssetType error, error num:{}", dbRet);
                                return -2;
                            }

                            int ret = -1;
                            for(const auto& t: ASSERT_TYPES)
                            {
                                TxHelper::ProposalInfo info;
                                ret = ca_algorithm::GetProposalInfo(t, info);   
                                if(ret == 0)
                                {
                                    assetMap.insert(std::make_pair(t, info));
                                }
                            }
                        }

                         std::string assetType;
                         if (ca_algorithm::GetAsseTypeByContractAddr(contractAddress, assetType) == 0)
                         {
                            DEBUGLOG("mapHandleFunction start contractAddr:{}", contractAddress);
                            for (const auto &asset : assetMap)
                            {
                                if (asset.second.ContractAddr == contractAddress)
                                {
                                    boost::multiprecision::cpp_dec_float_100 curBalance = ((boost::multiprecision::cpp_dec_float_100)numPart / AsseRate);
                                    std::cout << "Current exchange rate:" << AsseRate << std::endl;
                                    std::cout << "Outflow of Actual Balance:" << curBalance << std::endl;
                                    auto txUtxo = callOutRequest.add_utxos();
                                    uint64_t total = 0;
                                    std::string sender = evm_utils::evm_addr_to_string(message.sender);
                                    tradeMapping = {sender, assetType};
                                    Evmone::FillFlowOutVin(tradeMapping, txUtxo, total, false);

                                    boost::multiprecision::cpp_int amountTemp =
                                        (boost::multiprecision::cpp_int(numPart) * global::ca::kDecimalNum /(rateInt * decimalNumBig * boost::multiprecision::pow(boost::multiprecision::cpp_int(10), rateDecimal)));
                                    if (amountTemp < 0 || amountTemp > kMaxUint64)
                                    {
                                        ERRORLOG("Amount overflow: {}", amountTemp.str());
                                        return -10;
                                    }
                                    uint64_t amount = amountTemp.convert_to<uint64_t>();
                                    if (total < amount)
                                    {
                                        return -20;
                                    }
                                    
                                    auto AddOutputs = [total](auto* txUtxo, const std::string& addr, uint64_t amount, uint64_t gas) {
                                        CTxOutput *voutToVirtualAddr = txUtxo->add_vout();
                                        voutToVirtualAddr->set_addr(global::ca::kVirtualCallFlowOutAddr);
                                        voutToVirtualAddr->set_value(amount);
    
                                        CTxOutput *voutToFromAddr = txUtxo->add_vout();
                                        voutToFromAddr->set_addr(addr);
                                        voutToFromAddr->set_value((total - amount - gas));

                                        CTxOutput *voutBurnAmount = txUtxo->add_vout();
                                        voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
                                        voutBurnAmount->set_value(gas);
                                    };

                                    if(ca_algorithm::GetAssetTypeIsValid(assetType) != EXIT_SUCCESS){
                                        AddOutputs(txUtxo,contractOwnerEvmAddress,amount,0);
                                        DEBUGLOG("The asset type :{} to be jumped out has already withdrawn the proposal, so other assets must be used to pay the gas on behalf of the proposal",tradeMapping.second);
                                    }else{
                                        if(tx.independence() == global::ca::TX_INDEPENDENCE_FALSE){
                                            uint64_t flowOutGas = 0;
                                            uint64_t gasSize = callOutRequest.data().size()  + callOutRequest.note().size() + callOutRequest.reserve0().size() + callOutRequest.reserve1().size();
                                            if (GenerateGas(*txUtxo, 3, gasSize, flowOutGas) != 0)
                                            {
                                                ERRORLOG(" flowOutGas = 0 !");
                                                return -21;
                                            }
                                            if(tradeMapping.first == GetInitAccountAddr())
                                            {
                                                flowOutGas = 0;
                                            }

                                            AddOutputs(txUtxo,contractOwnerEvmAddress,amount,flowOutGas);
                                            DEBUGLOG("flowOutGas : {}",flowOutGas);
                                            callOutRequest.set_independence(global::ca::TX_INDEPENDENCE_NAN);
                                        }else{
                                            AddOutputs(txUtxo,contractOwnerEvmAddress,amount,0);
                                        }
                                    }
                                    break;
                                }
                            }
                         }
                       
                     }
                }

                bool isFindUtxo = true;
                if (saveType == global::ca::SaveType::SyncNormal)
                {
                    isFindUtxo = false;
                }
                ret = Evmone::generateCallOutMessage(fromAddr, deployerAddr, txType, host.coinTransfersInProgress,gasTrade, gasCost, callOutRequest, utxoHashesList, isFindUtxo,false,isFlowInTx,isFlowOutTx, &tx);
                if(ret < 0)
                {
                    ERRORLOG("generateCallOutMessage fail !!! ret:{}", ret);
                    return -22;
                }
                if(mapping == 0)
                {
                    auto txUtxo = callOutRequest.mutable_utxos()->begin();
                    nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                    nlohmann::json txInfoJson = dataJson["txInfo"].get<nlohmann::json>();
                    if (GetFlowTxType(txInfoJson) == FlowTxType::FlowInTx)
                    {
                        std::string _assetType;
                        if (ca_algorithm::GetAsseTypeByContractAddr(contractAddress, _assetType) != 0)
                        {
                            return -23;
                        }
                        txUtxo->set_assettype(_assetType);
                        txUtxo->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_FALSE);
                        txUtxo->add_owner(contractOwnerEvmAddress);
                        callOutRequest.set_independence(global::ca::TX_INDEPENDENCE_FALSE);

                        CTxOutput *voutBurnAmount = txUtxo->add_vout();
                        voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
                        voutBurnAmount->set_value(0);
                    }
                }

                ret = Evmone::VerifyUtxo(fromAddr,tx, callOutRequest, mapping);
                if(ret < 0)
                {
                    ERRORLOG("VerifyUtxo fail !!! ret:{}", ret);
                    return -24;
                }

                if(host.contractDataStorage != nullptr)    host.contractDataStorage->set(expectedJTxInfo[Evmone::storageKeyForContract]);
                else return -25;
            }

            if (output != expectedOutput)
            {
                return -26;
            }
            ret = verify_contract_storage(storageFound.value(), expectedJTxInfo);
            if (ret != 0)
            {
                ERRORLOG("verify_contract_storage fail TX HASH {}\nblock: {} \n expect: {}", tx.hash(), blockData.dump(4), expectedJTxInfo.dump(4));
                ERRORLOG("tx order:");
                ERRORLOG("this may caused by data inconsistent");
                for (const auto& tx : block.txs())
                {
                    ERRORLOG("{}", tx.hash());
                }
                return -27;
            }
        }
        catch (...)
        {
            ERRORLOG("parse tx data fail")
            return -28;
        }
    }

    return 0;
}

int ca_algorithm::verifyContractBlock(const CBlock &block, global::ca::SaveType saveType)
{
    DBReader dbReader;
    // Verify whether the block exists locally
    std::string blockRaw;
    auto status = dbReader.getBlockByBlockHash(block.hash(), blockRaw);
    if (DBStatus::DB_SUCCESS == status)
    {
        return 0;
    }

    bool isContractualBlock = isContractBlocked(block);
    if (!isContractualBlock)
    {
        return 0;
    }
    nlohmann::json blockData;
    try
    {
        blockData = nlohmann::json::parse(block.data());
    }
    catch (...)
    {
        ERRORLOG("fail to parse block data");
        return -1;
    }

    packDispatch _packdisTx;
    std::map<std::string, std::vector<std::string>> dependencyTransactionRequest;

    for(const auto& tx : block.txs())
    {
        auto& txHash = tx.hash();
        std::vector<std::string> dependentTxHashes;
        auto it = blockData.find(txHash);
        if (it != blockData.end() && it.value().contains("dependentCtx")) 
        {
            for (const auto& dependencyTransactionHashRequest : it.value()["dependentCtx"]) 
            {
                dependentTxHashes.push_back(dependencyTransactionHashRequest.get<std::string>());
            }
        } 
        else 
        {
            ERRORLOG("blockData.find(txHash) error notFoundTx:{}", txHash);
            return -2;
        }

        _packdisTx.Add(txHash, dependentTxHashes, tx);
        dependencyTransactionRequest[txHash] = std::move(dependentTxHashes);
    }
    std::map<uint32_t, std::map<std::string, CTransaction>> dependentContractTxMap_;
    std::map<std::string, CTransaction> non_dependent_contract_tx_map;
    _packdisTx.GetDependentData(dependentContractTxMap_, non_dependent_contract_tx_map);

    std::vector<std::future<int>> taskResults;
    for(const auto& iter : dependentContractTxMap_)
    {
        auto task = std::make_shared<std::packaged_task<int()>>(
        [&iter, &dependencyTransactionRequest, &block, &blockData, saveType = saveType]
        { 
            return verifyContractDepsTx(iter.second, dependencyTransactionRequest, block, blockData, saveType);
        });

        if(task)    taskResults.push_back(task->get_future());
        else    return -10;

        MagicSingleton<TaskPool>::GetInstance()->commit_block_task([task](){(*task)();});
    }
    for(const auto& iter : non_dependent_contract_tx_map)
    {
        auto task = std::make_shared<std::packaged_task<int()>>(
        [&iter, &dependencyTransactionRequest,&block, &blockData, saveType = saveType]
        {
            std::map<std::string, CTransaction> contractTx;
            contractTx.emplace(iter.first, iter.second);
            return verifyContractDepsTx(contractTx, dependencyTransactionRequest, block, blockData, saveType);
        });

        if(task)    taskResults.push_back(task->get_future());
        else    return -10;

        MagicSingleton<TaskPool>::GetInstance()->commit_block_task([task](){(*task)();});
    }

    bool verifyFlag = false;
    for (auto& res : taskResults)
    {
        auto ret = res.get();
        if (ret != 0)
        {
            verifyFlag = true;
            ERRORLOG(RED "contract Tx verify fail!!! ret:{}" RESET, ret);
        }
    }
    if(verifyFlag)
    {
        return -11;
    }

    return 0;
}

int ca_algorithm::VerifyBlock(const CBlock &block, bool enableMissingBlockRequest, bool checkAnomaly, bool isVerify, BlockStatus* blockStatus, BlockMsg *msg, global::ca::SaveType saveType)
{
    uint64_t startTimeForBenchmark = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();

    DBReader dbReader;
    // Verify whether the block exists locally
    std::string blockRaw;
    auto status = dbReader.getBlockByBlockHash(block.hash(), blockRaw);
    if (DBStatus::DB_SUCCESS == status)
    {
        return 0;
    }
    if (DBStatus::DB_NOT_FOUND != status)
    {
        return -1;
    }

    // Verify whether the front block exists
    blockRaw.clear();
    if (DBStatus::DB_SUCCESS != dbReader.getBlockByBlockHash(block.prevhash(), blockRaw))
    {
        MagicSingleton<BlockHelper>::GetInstance()->set_missing_prehash();
        return -2;
    }
    CBlock preBlock;
    if (!preBlock.ParseFromString(blockRaw))
    {
        MagicSingleton<BlockHelper>::GetInstance()->set_missing_prehash();
        return -3;
    }

    // The block height must be the height of the preceding block plus one
    if (block.height() - preBlock.height() != 1)
    {
        ERRORLOG("++++block.height:{}, preBlock.height:{}, block.prevhash:{}, block.txs_size:{}", block.height(), preBlock.height(), block.prevhash(),block.txs_size());
        return -4;
    }
    
    auto startMemVerify = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    auto ret = memVerifyBlock(block, isVerify, blockStatus, saveType);
    if (0 != ret)
    {
        ERRORLOG(RED "memVerifyBlock failed! The error code is {}." RESET, ret);
        ret -= 10000;
        return ret;
    }
    
    auto endMemVerify = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    // Verify whether the block time is greater than the maximum block time before 10 heights
    uint64_t startTime = 0;
    uint64_t endTime = GetLocalTimestampUsec() + 10 * 60 * 1000 * 1000;
    std::cout << "endTime:" << endTime << std::endl;
    {
        uint64_t blockHeight = 0;
        if (block.height() > 10)
        {
            blockHeight = block.height() - 10;
        }
        std::vector<std::string> blockHashs;
        if (DBStatus::DB_SUCCESS != dbReader.getBlockHashsByBlockHeight(blockHeight, blockHashs))
        {
            return -5;
        }
        std::vector<std::string> blocks;
        if (DBStatus::DB_SUCCESS != dbReader.getBlocksByBlockHash(blockHashs, blocks))
        {
            return -6;
        }
        CBlock block;
        for (auto &blockRaw : blocks)
        {
            if (!block.ParseFromString(blockRaw))
            {
                return -7;
            }
            if (startTime < block.time())
            {
                startTime = block.time();
            }
        }
    }

    // Verify whether the transaction time is greater than the maximum block time before 10 heights
    uint64_t tenSec = 10000000;
    if (block.time() > endTime || block.time() < startTime - tenSec)
    {
        return -8;
    }
    
    auto startTransactionVerification = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    if(isVerify)
    {
        std::map<std::string, uint64_t> expected_nonces;
        if (BuildBlockNonceView(block, expected_nonces) != 0)
        {
            return -9;
        }
        std::map<std::string, std::future<int>> taskResults;
        for (auto& tx : block.txs())
        {
            if (GetTransactionType(tx) != kTransactionTypeTx)
            {
                continue;
            }
            // if(tx.verifysign_size() != global::ca::randomNodeGroup)
            // {
            //     if(!checkAnomaly && tx.verifysign_size() == global::ca::randomNodeGroup + 12)
            //     {
            //         DEBUGLOG("old block hash:{}, tx verifysign_size:{}", block.hash().substr(0,6), tx.verifysign_size());
            //         break;
            //     }
            //     return -9;
            // }

            auto blockHeight = block.height();
            const auto nonce_it = expected_nonces.find(tx.hash());
            const std::optional<uint64_t> expected_nonce =
                nonce_it == expected_nonces.end() ? std::nullopt : std::optional<uint64_t>(nonce_it->second);
            auto task = std::make_shared<std::packaged_task<int()>>([tx, blockHeight, enableMissingBlockRequest, checkAnomaly, expected_nonce] {
                return verifyTransactionRequest(tx, blockHeight, enableMissingBlockRequest, checkAnomaly, expected_nonce);
            });
            if(task)
            {
                taskResults[tx.hash()] = task->get_future();
            }
            else
            {
                return -10;
            }
            MagicSingleton<TaskPool>::GetInstance()->commitWorkTask([task](){(*task)();});
        }
        
        DEBUGLOG("verifyContractBlock, blockHash:{}", block.hash());
        ret = verifyContractBlock(block, saveType);
        if (ret != 0)
        {
            ERRORLOG("verifyContractBlock fail ret : {}", ret);
            return -11;
        }
        bool verifyFlag = false;
        for (auto& res : taskResults)
        {
            ret = res.second.get();
            if (ret != 0)
            {
                verifyFlag = true;
                if(blockStatus != NULL)
                {
                    auto txStatus = blockStatus->add_txstatus();
                    txStatus->set_txhash(res.first);
                    txStatus->set_status(ret);
                }
                ERRORLOG(RED "AAAC verifyTransactionRequest failed! The error code is {}. txHash:{}" RESET, ret, res.first);
            }
        }
        if(verifyFlag)
        {
            return -12;
        }
    }
    
    auto transactionVerifyEnd = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    if(isVerify)
    {
        uint64_t memVerify = endMemVerify - startMemVerify;
        uint64_t txVerify = transactionVerifyEnd - startTransactionVerification;
        MagicSingleton<Benchmark>::GetInstance()->setByBlockHash(block.hash(), &memVerify, 5, &txVerify);
    }
    
    uint64_t benchmarkEndTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    MagicSingleton<Benchmark>::GetInstance()->addBlockVerifyMap(block.hash(), benchmarkEndTime - startTimeForBenchmark);
    return 0;
}

int ca_algorithm::verifyPreSaveBlock_(const CBlock &block)
{
    std::set<std::string> addrs;
    for(auto &sig : block.signature())
    {
        addrs.insert(GenerateAddr(sig.pub()));
    }

    if(addrs.size() != global::ca::kConsensus)
    {
        ERRORLOG("size is >:{}, less than >:{}",addrs.size(), global::ca::kConsensus);
        return -1;
    }

    return 0;
}

int ca_algorithm::VerifySign(const CSign & sign, const std::string & serHash)
{       
    if (sign.sign().size() == 0 || sign.pub().size() == 0)
    {
        return -1;
    }
    if (serHash.size() == 0)
    {
        return -2;
    }

    EVP_PKEY* eckey = nullptr;
    if(get_ecdsa_pub_key_by_bytes(sign.pub(), eckey) == false)
    {
        EVP_PKEY_free(eckey);
        return -3;
    }

    if(ecdsaVerificationMessage(serHash, eckey, sign.sign()) == false)
    {
        EVP_PKEY_free(eckey);
        return -4;
    }
    EVP_PKEY_free(eckey);
    return 0;
}


bool ca_algorithm::calculate_height_sum_hash(uint64_t startHeight, uint64_t endHeight, DBReadWriter &dbWriter, std::string& sumHash)
{
    std::map<uint64_t, std::vector<std::string>> hash_data_total;
    for(uint64_t height = startHeight; height < endHeight; ++height)
    {
        std::vector<std::string> blockhashes;
        auto ret = dbWriter.getBlockHashsByBlockHeight(height, blockhashes);
        if(ret != DBStatus::DB_SUCCESS)
        {
            ERRORLOG("calculate sum hash fail");
            return false;
        }
        hash_data_total[height] = blockhashes;
    }
    SyncBlock::sumHeightsHash(hash_data_total, sumHash);
    return true;
}

int ca_algorithm::SaveBlock(DBReadWriter &dbWriter, const CBlock &block, global::ca::SaveType saveType, global::ca::blockMean computeMeanValue)
{
   

    // Determine whether there is a local block
    std::string blockRaw;
    auto ret = dbWriter.getBlockByBlockHash(block.hash(), blockRaw);
    if (DBStatus::DB_SUCCESS == ret)
    {
        INFOLOG("block {} already in cache , skip",block.hash().substr(0, 6));
        return 0;
    }
    else if (DBStatus::DB_NOT_FOUND != ret)
    {
        ERRORLOG("DB error!  {}",ret);
        return -1;
    }

    std::string preBlockRaw;
    if (DBStatus::DB_SUCCESS != dbWriter.getBlockByBlockHash(block.prevhash(), preBlockRaw))
    {
        MagicSingleton<BlockHelper>::GetInstance()->set_missing_prehash();
        DEBUGLOG("DB error or not found prev block");
        return -2;
    }

    // Update node height
    uint64_t nodeHeight = 0;
    if (DBStatus::DB_SUCCESS != dbWriter.getBlockTop(nodeHeight))
    {
         ERRORLOG("getBlockTop error!");
        return -3;
    }

    if (block.height() > nodeHeight)
    {
        if (DBStatus::DB_SUCCESS != dbWriter.setBlockTop(block.height()))
        {
            ERRORLOG("getBlockTop");
            return -4;
        }
    }

    // Add the height corresponding to the block hash
    if (DBStatus::DB_SUCCESS != dbWriter.setBlockHeightByBlockHash(block.hash(), block.height()))
    {
        ERRORLOG("setBlockHeightByBlockHash error! hash:{}",block.hash());
        return -5;
    }

    // Update block hash on height
    if (DBStatus::DB_SUCCESS != dbWriter.setBlockHashByBlockHeight(block.height(), block.hash(), false))
    {
        ERRORLOG("setBlockHeightByBlockHash error! hash:{}",block.hash());
        return -6;
    }
    
    // Add block data corresponding to block hash
    if (DBStatus::DB_SUCCESS != dbWriter.setBlockByBlockHash(block.hash(), block.SerializeAsString()))
    {
        ERRORLOG("setBlockByBlockHash error! hash:{}",block.hash());
        return -7;
    }

    {
        uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(block.time());
        std::vector<std::string> signatureAddresses;
        auto ret = dbWriter.getSignAddrByPeriod(period, signatureAddresses);
        if(DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
        {
            ERRORLOG("getSignAddrByPeriod error! ret:{}",ret);
            return -8;
        }
        for (auto &sign : block.signature())
        {

            std::string voutAddr = GenerateAddr(sign.pub());
            if (!isValidAddress(voutAddr))
            {
                return -9;
            }

            // Block double-sign detection: check if this address signed a different block at the same height
            {
                std::string existingBlockHash;
                auto signRet = dbWriter.getBlockSign(block.height(), voutAddr, existingBlockHash);
                if (DBStatus::DB_SUCCESS == signRet && existingBlockHash != block.hash())
                {
                    ERRORLOG("[SLASH] Block double-sign detected! addr:{}, height:{}, existing_block:{}, new_block:{}",
                             voutAddr, block.height(), existingBlockHash, block.hash());

                    // Store evidence in database for dispatcher
                    // 构造 SlashEvidenceMsg 并发送给分发者
                    SlashEvidenceMsg evidenceMsg;
                    evidenceMsg.set_version("1.0");
                    evidenceMsg.set_target_addr(voutAddr);
                    evidenceMsg.set_violation_type(SlashViolationType::DOUBLE_SIGN_BLOCK);
                    
                    // 构造证据数据
                    nlohmann::json evidenceData;
                    evidenceData["height"] = block.height();
                    evidenceData["existing_block_hash"] = existingBlockHash;
                    evidenceData["new_block_hash"] = block.hash();
                    
                    std::string evidenceDataStr = evidenceData.dump();
                    evidenceMsg.set_evidence_data(evidenceDataStr);
                    evidenceMsg.set_evidence_hash(Getsha256Hash(evidenceDataStr));
                    
                    // 设置当前周期
                    uint64_t currentTime = std::chrono::duration_cast<std::chrono::microseconds>(
                        std::chrono::system_clock::now().time_since_epoch()).count();
                    uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(currentTime);
                    evidenceMsg.set_period(period);
                    
                    // 设置报告者地址（本节点）
                    std::string reporterAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
                    evidenceMsg.set_reporter(reporterAddr);
                    
                    // 用本节点私钥签名
                    CSign* sig = evidenceMsg.mutable_signature();
                    std::string signData, pubKey;
                    if (TxHelper::Sign(reporterAddr, evidenceMsg.evidence_hash(), signData, pubKey) == 0) {
                        sig->set_sign(signData);
                        sig->set_pub(pubKey);
                        
                        // 发送给分发者（带随机退避）
                        SendSlashEvidenceToDispatcher(evidenceMsg);
                    } else {
                        ERRORLOG("[SLASH] Failed to sign evidence message");
                    }
                }
            }

            auto found = std::find(signatureAddresses.begin(), signatureAddresses.end(), voutAddr);
            if(found == signatureAddresses.end())
            {
                if(DBStatus::DB_SUCCESS != dbWriter.setSignAddrByPeriod(period, voutAddr))
                {
                    ERRORLOG("setSignAddrByPeriod error! period:{},vout.addr{}",period,voutAddr);
                    return -10;
                }
            }
            uint64_t signNumber = 0;
            auto ret = dbWriter.getSignCountByPeriod(period, voutAddr, signNumber);
            if(DBStatus::DB_SUCCESS != ret)
            {
                if(DBStatus::DB_NOT_FOUND == ret)
                {
                    signNumber = 0;
                }
                else
                {
                    ERRORLOG("getSignCountByPeriod error! ret:{}",ret);
                    return -11;
                }
            }
            signNumber += 1;
            if(DBStatus::DB_SUCCESS != dbWriter.setSignCountByPeriod(period, voutAddr, signNumber))
            {
                ERRORLOG("setSignCountByPeriod error! period:{},vout.addr:{},signNumber:{}",period,voutAddr,signNumber);
                return -12;
            }

            // Slashing: update last active period for offline tracking
            dbWriter.setLastActivePeriod(voutAddr, period);

            // Slashing: if node is Jailed, track consecutive normal signing for release
            if (DBStatus::DB_SUCCESS == dbWriter.isJailed(voutAddr))
            {
                uint32_t consecNormal = 0;
                dbWriter.getConsecutiveNormal(voutAddr, consecNormal);
                consecNormal++;
                dbWriter.setConsecutiveNormal(voutAddr, consecNormal);

                // Release after kJailManualReleasePeriods (5) consecutive normal periods
                if (consecNormal >= global::ca::kJailManualReleasePeriods)
                {
                    dbWriter.removeJailed(voutAddr);
                    dbWriter.setConsecutiveNormal(voutAddr, 0);
                    INFOLOG("[SLASH] Node {} released from Jailing after {} consecutive normal periods",
                            voutAddr, consecNormal);
                }
            }
        }

        {
            uint64_t blockNumber = 0;
            auto ret = dbWriter.getBlockNumberByPeriod(period,blockNumber);
            if(DBStatus::DB_SUCCESS != ret)
            {
                if(DBStatus::DB_NOT_FOUND == ret)
                {
                    blockNumber = 0;
                }
                else
                {
                   ERRORLOG("Get BLock Num Failed!");
                   return -13;
                }
            }
            blockNumber += 1;

            if(DBStatus::DB_SUCCESS != dbWriter.setBlockNumberByPeriod(period, blockNumber))
            {
                ERRORLOG("setBlockNumberByPeriod error! period:{},signNumber:{}",period,blockNumber);
                return -14;
            }

            uint64_t packageTimes = 0;
            ret = dbWriter.getPackagerCountByPeriod(period,GenerateAddr(block.signature(0).pub()),packageTimes);
            if(DBStatus::DB_SUCCESS != ret){
                if(DBStatus::DB_NOT_FOUND == ret)
                {
                    packageTimes = 0;
                }else{
                   ERRORLOG("Get BLock Num Failed!");
                   return -99;
                }
            }
            packageTimes += 1;

            if(DBStatus::DB_SUCCESS != dbWriter.setPackagerCountByPeriod(period, GenerateAddr(block.signature(0).pub()),packageTimes))
            {
                ERRORLOG("setBlockNumberByPeriod error! period:{},signNumber:{}",period,packageTimes);
                return -98;
            }
        }

        // Slashing: check all stake nodes for offline status and apply Jailing/Archived transitions
        {
            std::vector<std::string> stakeAddrs;
            if (DBStatus::DB_SUCCESS == dbWriter.getStakeAddr(stakeAddrs))
            {
                for (const auto& stakeAddr : stakeAddrs)
                {
                    if (stakeAddr.empty()) continue;

                    // Skip if already Tombstoned
                    if (DBStatus::DB_SUCCESS == dbWriter.isTombstoned(stakeAddr)) continue;

                    // P3-25: Check if node has a valid offline notice
                    // If current time is within the notice window, skip absence calculation
                    {
                        std::string noticeKey = std::string("slash_offline_notice_") + stakeAddr;
                        std::string noticeVal;
                        if (DBStatus::DB_SUCCESS == dbWriter.readSlashingData(noticeKey, noticeVal))
                        {
                            try {
                                auto noticeJson = nlohmann::json::parse(noticeVal);
                                uint64_t onlineTime = noticeJson.value("online_time", 0);
                                // online_time is in microseconds
                                uint64_t currentTimeUs = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
                                if (onlineTime > 0 && currentTimeUs < onlineTime)
                                {
                                    // Node is within planned offline window, skip absence tracking
                                    DEBUGLOG("[SLASH] Node {} has valid offline notice until {}, skipping absence check",
                                             stakeAddr, onlineTime);
                                    continue;
                                }
                                else
                                {
                                    // Notice expired, clean up
                                    dbWriter.deleteSlashingData(noticeKey);
                                }
                            } catch (...) {
                                // Invalid notice data, clean up
                                dbWriter.deleteSlashingData(noticeKey);
                            }
                        }
                    }

                    uint64_t lastActive = 0;
                    auto ret = dbWriter.getLastActivePeriod(stakeAddr, lastActive);
                    if (DBStatus::DB_NOT_FOUND == ret)
                    {
                        // Never seen signing — initialize to current period
                        dbWriter.setLastActivePeriod(stakeAddr, period);
                        continue;
                    }

                    uint64_t absencePeriods = (period > lastActive) ? (period - lastActive) : 0;

                    // Check if Jailed node should be auto-released
                    if (DBStatus::DB_SUCCESS == dbWriter.isJailed(stakeAddr))
                    {
                        // Fix-2: Check if jailed for >= 100 periods (auto-release)
                        std::string jailVal;
                        std::string jailKey = std::string("slash_jail_") + stakeAddr;
                        if (DBStatus::DB_SUCCESS == dbWriter.readSlashingData(jailKey, jailVal))
                        {
                            // Parse jail start period from "startPeriod,reason,level"
                            auto commaPos = jailVal.find(',');
                            if (commaPos != std::string::npos)
                            {
                                uint64_t jailStartPeriod = 0;
                                try { jailStartPeriod = std::stoull(jailVal.substr(0, commaPos)); } catch (...) {}
                                
                                uint64_t jailedDuration = (period > jailStartPeriod) ? (period - jailStartPeriod) : 0;
                                
                                // Auto-release after 100 periods
                                if (jailedDuration >= global::ca::kJailAutoReleasePeriods)
                                {
                                    dbWriter.removeJailed(stakeAddr);
                                    dbWriter.setConsecutiveNormal(stakeAddr, 0);
                                    INFOLOG("[SLASH] Node {} auto-released from Jailing after {} periods (threshold: {})",
                                            stakeAddr, jailedDuration, global::ca::kJailAutoReleasePeriods);
                                    continue;
                                }
                            }
                        }
                        
                        // Archived: absent > 7 days → release from Jailing
                        if (absencePeriods >= global::ca::kSlashArchivePeriods)
                        {
                            dbWriter.removeJailed(stakeAddr);
                            dbWriter.setConsecutiveNormal(stakeAddr, 0);
                            INFOLOG("[SLASH] Node {} archived after {} periods — Jailing released",
                                    stakeAddr, absencePeriods);
                        }
                        continue;
                    }

                    // Not Jailed: check if should be Jailed (absent > 24 hours = 8640 periods)
                    if (absencePeriods >= global::ca::kJailConsecutiveAbsentPeriods)
                    {
                        dbWriter.setJailed(stakeAddr, std::to_string(period), "LONG_OFFLINE", 1);
                        dbWriter.setConsecutiveNormal(stakeAddr, 0);
                        ERRORLOG("[SLASH] Node {} Jailed! absent {} periods (threshold: {})",
                                 stakeAddr, absencePeriods, global::ca::kJailConsecutiveAbsentPeriods);
                    }
                }
            }
        }

        // Slashing: periodic sign rate check (every 100 periods)
        if (period % 100 == 0)
        {
            std::vector<std::string> stakeAddrs;
            if (DBStatus::DB_SUCCESS == dbWriter.getStakeAddr(stakeAddrs))
            {
                for (const auto& stakeAddr : stakeAddrs)
                {
                    if (stakeAddr.empty()) continue;
                    if (DBStatus::DB_SUCCESS == dbWriter.isTombstoned(stakeAddr)) continue;

                    // Check sign rate over last 100 periods
                    uint32_t signedCount = 0;
                    uint32_t validPeriods = 0;
                    for (uint64_t p = (period > 100 ? period - 100 : 0); p < period; ++p)
                    {
                        std::vector<std::string> signAddrs;
                        if (DBStatus::DB_SUCCESS == dbWriter.getSignAddrByPeriod(p, signAddrs))
                        {
                            validPeriods++;
                            if (std::find(signAddrs.begin(), signAddrs.end(), stakeAddr) != signAddrs.end())
                            {
                                signedCount++;
                            }
                        }
                    }

                    if (validPeriods >= 50) // Need at least 50 periods of data
                    {
                        double signRate = static_cast<double>(signedCount) / validPeriods;
                        if (signRate < global::ca::kJailLowThreshold) // < 50%
                        {
                            ERRORLOG("[SLASH] Node {} sign rate {:.1f}% < 50% over {} periods — constructing evidence",
                                     stakeAddr, signRate * 100, validPeriods);
                            
                            // 构造 SlashEvidenceMsg 并发送给分发者
                            SlashEvidenceMsg evidenceMsg;
                            evidenceMsg.set_version("1.0");
                            evidenceMsg.set_target_addr(stakeAddr);
                            evidenceMsg.set_violation_type(SlashViolationType::LOW_SIGN_RATE);
                            
                            // 构造证据数据
                            nlohmann::json evidenceData;
                            evidenceData["sign_rate"] = signRate;
                            evidenceData["period"] = period;
                            evidenceData["signed_count"] = signedCount;
                            evidenceData["valid_periods"] = validPeriods;
                            
                            std::string evidenceDataStr = evidenceData.dump();
                            evidenceMsg.set_evidence_data(evidenceDataStr);
                            evidenceMsg.set_evidence_hash(Getsha256Hash(evidenceDataStr));
                            evidenceMsg.set_period(period);
                            
                            // 设置报告者地址（本节点）
                            std::string reporterAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
                            evidenceMsg.set_reporter(reporterAddr);
                            
                            // 用本节点私钥签名
                            CSign* sig = evidenceMsg.mutable_signature();
                            std::string signData, pubKey;
                            if (TxHelper::Sign(reporterAddr, evidenceMsg.evidence_hash(), signData, pubKey) == 0) {
                                sig->set_sign(signData);
                                sig->set_pub(pubKey);
                                
                                // 发送给分发者（带随机退避）
                                SendSlashEvidenceToDispatcher(evidenceMsg);
                            } else {
                                ERRORLOG("[SLASH] Failed to sign evidence message");
                            }
                        }
                    }
                }
            }
        }

        // P3-28: Periodic cleanup of old slashing evidence
        // Clean up VRF_FAIL records older than 100 periods
        // Clean up DISCONNECT records older than 24 hours
        if (period % 100 == 0)
        {
            std::vector<std::string> stakeAddrs;
            if (DBStatus::DB_SUCCESS == dbWriter.getStakeAddr(stakeAddrs))
            {
                uint64_t currentHour = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp() / 3600000000ULL;

                for (const auto& stakeAddr : stakeAddrs)
                {
                    if (stakeAddr.empty()) continue;

                    // Clean up old VRF_FAIL records (older than 100 periods)
                    if (period > 100)
                    {
                        uint64_t oldPeriod = period - 100;
                        std::string vrfFailKey = std::string("slash_vrf_fail_") + stakeAddr + ":" + std::to_string(oldPeriod);
                        dbWriter.deleteSlashingData(vrfFailKey);
                    }

                    // Clean up old DISCONNECT records (older than 24 hours)
                    if (currentHour > 24)
                    {
                        uint64_t oldHour = currentHour - 24;
                        std::string disconnectKey = std::string("slash_disconnect_") + stakeAddr + ":" + std::to_string(oldHour);
                        dbWriter.deleteSlashingData(disconnectKey);
                    }

                    // Clean up old pending evidence (older than 100 periods)
                    if (period > 100)
                    {
                        uint64_t oldPeriod = period - 100;
                        // Clean up different types of pending evidence
                        std::vector<std::string> prefixes = {
                            "slash_pending_dblsign_",
                            "slash_pending_dblblock_",
                            "slash_pending_lowsign_",
                            "slash_pending_abuse_"
                        };
                        for (const auto& prefix : prefixes)
                        {
                            std::string pendingKey = prefix + stakeAddr + ":" + std::to_string(oldPeriod);
                            dbWriter.deleteSlashingData(pendingKey);
                        }
                    }
                }
            }
        }
    }

    std::set<std::string> blockAddr;
    std::set<std::string> allAddr;
    for (auto &tx : block.txs())
    {
        
        {
            uint64_t nonce = 0;
            auto  DBRET = dbWriter.getNonceByAddr(tx.utxos(0).owner(0), nonce);
            if (DBStatus::DB_SUCCESS != DBRET && DBStatus::DB_NOT_FOUND != DBRET)
            {
                ERRORLOG("getNonceByAddr error! addr:{} nonce:{}", tx.utxos(0).owner(0), nonce);
                return -9991;
            }

            if (DBStatus::DB_SUCCESS != dbWriter.setNonceByAddr(tx.utxos(0).owner(0), nonce + 1))
            {
                ERRORLOG("setNonceByAddr error! addr:{} nonce:{}", tx.utxos(0).owner(0), tx.nonce());
                return -9992;
            }
                
        }

        auto transactionType = GetTransactionType(tx);
        blockAddr.insert(allAddr.cbegin(), allAddr.cend());
        allAddr.clear();
        bool isGasTransaction = false;
        if(tx.independence() == global::ca::TX_INDEPENDENCE_TRUE) isGasTransaction = true;
        
        if (kTransactionTypeTx == transactionType)
        {
            std::string redeemUtxoHashValue;
            std::string UndelegatingUtxoHash;
            if((global::ca::TxType)tx.type() != global::ca::TxType::TX)
            {
                try
                {
                    nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                    global::ca::TxType txType = (global::ca::TxType)tx.type();
                    // The pledge transaction updates the pledge address and the utxo of the pledge address
                    {
                      uint64_t ltime;
                      uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()
                                             ->GetUTCTimestamp();
                      auto stret = dbWriter.get30DayLockData(
                          tx.utxos(0).owner(0), tx.hash(),
                          tx.utxos(0).assettype(), ltime);
                      if (stret == DBStatus::DB_SUCCESS &&
                          (curTime - ltime) > 24 * 60 * 60 * 1000000 * 30) {
                        dbWriter.set30DayLockData(
                            tx.utxos(0).owner(0), tx.hash(),
                            tx.utxos(0).assettype(), 0, true);


                             nlohmann::json lockdata={
                                    {"tx_type",(int)txType},
                                    {"utxo_hash",tx.hash()},
                                    {"asset_type",tx.utxos(0).assettype()}
                                };

                                 std::string ldatahex=dev::toHex(lockdata.dump());

                              dbWriter.removeOneLockData(tx.utxos(0).owner(0), ldatahex);
                      }
                    }

                    if (txType == global::ca::TxType::STAKE)
                    {
                        for(const auto &utxo : tx.utxos())
                        {
                            if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                                continue;
                            }
                            for (auto &vin : utxo.vin())
                            {
                                std::string addr = GenerateAddr(vin.vinsign().pub());
                                if (!isValidAddress(addr))
                                {
                                    ERRORLOG("isValidAddress error!",addr);
                                    return -15;
                                }
                                
                                // Fix-3: Second line of defense — check tombstone in SaveBlock
                                std::string tombstoneVal;
                                if (DBStatus::DB_SUCCESS == dbWriter.readSlashingData(std::string("slash_tombstone_") + addr, tombstoneVal))
                                {
                                    ERRORLOG("[SLASH] Tombstoned node {} attempted to stake — rejected in SaveBlock", addr);
                                    return -15;  // Reject the entire block
                                }
                                
                                if (DBStatus::DB_SUCCESS != dbWriter.setStakeUtxoByAddr(addr, utxo.assettype(), tx.hash()))
                                {
                                    ERRORLOG("setStakeAddrUtxo error! addr:{} hash:{}",addr,tx.hash());
                                    return -16;
                                }
                                std::vector<std::string> addressListForPledge;
                                ret = dbWriter.getStakeAddr(addressListForPledge);
                                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                                {
                                    ERRORLOG("getStakeAddr error! ret:{}",ret);
                                    return -17;
                                }
                                if (addressListForPledge.cend() == std::find(addressListForPledge.cbegin(), addressListForPledge.cend(), addr))
                                {
                                    if (DBStatus::DB_SUCCESS != dbWriter.setStakeAddr(addr))
                                    {
                                        ERRORLOG("setStakeAddr addr:{}",addr);
                                        return -18;
                                    }
                                }
                                break;
                            }
                        }
                    }
                    // The reddem transaction, update the pledge address and the utxo of the pledge address
                    else if (txType == global::ca::TxType::UNSTAKE)
                    {
                        bool flag = false;
                        
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        redeemUtxoHashValue =
                            txInfo["unstakeUtxo"].get<std::string>();
                        uint64_t utxoTime;
                        if (dbWriter.set30DayLockData(
                                tx.utxos(0).owner(0), tx.hash(),
                                tx.utxos(0).assettype(),
                                utxoTime,false) != DBStatus::DB_SUCCESS) {
                          ERRORLOG("utxoHash:{} tx.hash:{}", tx.hash(),
                                   utxoTime);
                          return -19;
                        }


                        nlohmann::json lockdata={
                            {"tx_type",(int)txType},
                            {"utxo_hash",tx.hash()},
                            {"asset_type",tx.utxos(0).assettype()}
                        };
                        std::string ldatahex=dev::toHex(lockdata.dump());

                        if(DBStatus::DB_SUCCESS !=dbWriter.addOneLockData(tx.utxos(0).owner(0), ldatahex)){
                                ERRORLOG("addOneLockData fail {}",tx.hash());
                                return -20;
                        }
                        // std::string txRawData;
                        // dbWriter.getTransactionByHash(redeemUtxoHashValue,
                        //                               txRawData);
                        
                        // CTransaction tx;
                        // if (!tx.ParseFromString(txRawData)) {
                        //   ERRORLOG("Failed to parse transaction body!");
                        //   return -18;
                        // }
                        for (const auto &utxo : tx.utxos()) {
                          if (utxo.gas() ==
                              global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE) {
                            continue;
                          }
                          for (auto &vin : utxo.vin()) {
                            for (auto &prevout : vin.prevout()) {
                              if (redeemUtxoHashValue != prevout.hash() &&
                                  prevout.n() != 1) {
                                continue;
                              }
                              flag = true;
                              std::string addr =
                                  GenerateAddr(vin.vinsign().pub());
                              if (!isValidAddress(addr)) {
                                ERRORLOG("isValidAddress error! addr:{}", addr);
                                return -19;
                              }
                              if (DBStatus::DB_SUCCESS !=
                                  dbWriter.removeStakeUtxoByAddr(
                                      addr, utxo.assettype(),
                                      redeemUtxoHashValue)) {
                                ERRORLOG("removeStakeAddrUtxo error");
                                return -20;
                              }
                              std::vector<std::string> pledgeUtxoHashes;
                              ret = dbWriter.getStakeUtxoByAddr(
                                  addr, utxo.assettype(), pledgeUtxoHashes);
                              if (DBStatus::DB_NOT_FOUND == ret ||
                                  pledgeUtxoHashes.empty()) {
                                if (DBStatus::DB_SUCCESS !=
                                    dbWriter.removeStakeAddr(addr)) {
                                  ERRORLOG("removeStakeAddr addr:{}", addr);
                                  return -21;
                                }
                              } else if (DBStatus::DB_SUCCESS != ret) {
                                ERRORLOG("getStakeAddrUtxo ret:{}", ret);
                                return -22;
                              }
                              break;
                            }
                          }
                        }
                        if (!flag)
                        {
                            ERRORLOG(" TxType unknow");
                            return -23;
                        }
                    }
                    else if (txType == global::ca::TxType::LOCK) 
                    {
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        uint64_t lockAmount = txInfo["lockAmount"].get<uint64_t>();
                        
                        for(const auto &utxo : tx.utxos())
                        {
                            if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                                continue;
                            }
                            for (auto &vin : utxo.vin())
                            {
                                std::string addr;
                                if (!tx.rlp().empty())
                                {
                                    ethVerify::EthTransaction ethTx;
                                    dev::bytes rlpBytes = dev::fromHex(tx.rlp());
                                    eth_errors e;
                                    int ret_E = ethVerify::verifyRLP(rlpBytes, e, &ethTx);
                                    if (ret_E != 0)
                                    {
                                        ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
                                        return ret_E;
                                    }
                                    addr = ethTx.from;
                                }
                                else
                                {
                                    addr = GenerateAddr(vin.vinsign().pub());
                                }
                                if (!isValidAddress(addr))
                                {
                                    ERRORLOG("CheckBase58Addr error!",addr);
                                    return -1000;
                                }
                                std::lock_guard<std::mutex> lock(global::ca::LOCK_MUTEX);
                                if (DBStatus::DB_SUCCESS != dbWriter.setLockAddrUtxo(addr, utxo.assettype() ,tx.hash()))
                                {
                                    ERRORLOG("setStakeAddrUtxo error! addr:{} hash:{}",addr,tx.hash());
                                    return -1001;
                                }

                                uint64_t totalLockedAmount = 0;
                                ret = dbWriter.getTotalLockedAmonut(totalLockedAmount);
                                if(ret != DBStatus::DB_SUCCESS){
                                    if(DBStatus::DB_NOT_FOUND == ret){
                                        totalLockedAmount=0;
                                    }else{
                                        return -1004;
                                    }
                                }

                                
                                totalLockedAmount += lockAmount;
                                ret = dbWriter.setTotalLockedAmonut(totalLockedAmount);
                                if(ret != DBStatus::DB_SUCCESS){
                                    ERRORLOG("set total locked amount fail!");
                                    return -1005;
                                }

                                
                                {
                                    uint64_t LockedAmount = 0;
                                    uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                                    ret = dbWriter.getTotalLockedAmountByPeriod(period, LockedAmount);
                                    if(ret != DBStatus::DB_SUCCESS){
                                        if(DBStatus::DB_NOT_FOUND == ret){
                                            LockedAmount=0;
                                        }else{
                                            return -1004;
                                        }
                                    }

                                    LockedAmount += lockAmount;
                                    ret = dbWriter.setTotalLockedAmonutByPeriod(period, LockedAmount);
                                    if(ret != DBStatus::DB_SUCCESS){
                                        ERRORLOG("set total locked amount by period fail!");
                                        return -1005;
                                    }

                                }

                                std::vector<std::string> addressListForPledge;
                                ret = dbWriter.getLockAddr(addressListForPledge);
                                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                                {
                                    ERRORLOG("getStakeAddr error! ret:{}",ret);
                                    return -1002;
                                }
                                if (addressListForPledge.cend() == std::find(addressListForPledge.cbegin(), addressListForPledge.cend(), addr))
                                {
                                    if (DBStatus::DB_SUCCESS != dbWriter.setLockAddr(addr))
                                    {
                                        ERRORLOG("setStakeAddr addr:{}",addr);
                                        return -1003;
                                    }
                                }
                                break;
                            }
                        }
                    }
                    else if (txType == global::ca::TxType::UNLOCK)  
                    {
                        bool flag = false;
                        std::string unlockUtxoBalance ;
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        redeemUtxoHashValue =
                            txInfo["unLockUtxo"].get<std::string>();
                          for (const auto &utxo : tx.utxos()) {
                            if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                                continue;
                            }
                            for (auto &vin : utxo.vin())
                            {
                              for (auto &prevout : vin.prevout()) {
                                    std::string addr;
                                    if (redeemUtxoHashValue != prevout.hash() && prevout.n() != 1)
                                    {
                                        continue;
                                    }
                                    flag = true;
                                    if (!tx.rlp().empty())
                                    {
                                        ethVerify::EthTransaction ethTx;
                                        dev::bytes rlpBytes = dev::fromHex(tx.rlp());
                                        eth_errors e;
                                        int ret_E = ethVerify::verifyRLP(rlpBytes, e, &ethTx);
                                        if (ret_E != 0)
                                        {
                                            ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
                                            return ret_E;
                                        }
                                        addr = ethTx.from;
                                    }
                                    else
                                    {
                                        addr = GenerateAddr(vin.vinsign().pub());
                                    }
                                    if (!isValidAddress(addr))
                                    {
                                        ERRORLOG("isValidAddress error! addr:{}",addr);
                                        return -1011;
                                    }
                                    if (DBStatus::DB_SUCCESS != dbWriter.removeLockAddrUtxo(addr, utxo.assettype(), redeemUtxoHashValue))
                                    {
                                        ERRORLOG("removeLockAddrUtxo error");
                                        return -1012;
                                    }
                                    std::vector<std::string> pledgeUtxoHashes;
                                    ret = dbWriter.getLockAddrUtxo(addr, utxo.assettype(), pledgeUtxoHashes);
                                    if (DBStatus::DB_NOT_FOUND == ret || pledgeUtxoHashes.empty())
                                    {
                                        if (DBStatus::DB_SUCCESS != dbWriter.removeLockAddr(addr))
                                        {
                                            ERRORLOG("removeLockAddr addr:{}",addr);
                                            return -1013;
                                        }
                                    }
                                    else if (DBStatus::DB_SUCCESS != ret)
                                    {
                                        ERRORLOG("getLockAddrUtxo ret:{}",ret);
                                        return -1014;
                                    }

                                    // auto iter = std::find(pledgeUtxoHashes.begin(),pledgeUtxoHashes.end(),redeemUtxoHashValue);
                                    // if(iter == pledgeUtxoHashes.end()){
                                    //     ERRORLOG("unlock UTXO usage error");
                                    //     return -1015;
                                    // }else{
                                    //     if (DBStatus::DB_SUCCESS != dbWriter.getUtxoValueByUtxoHashes(redeemUtxoHashValue, addr, utxo.assettype(), unlockUtxoBalance))
                                    //     {
                                    //         ERRORLOG("getTransactionByHash failed!");
                                    //         return -1016;
                                    //     }
                                    // }

                                    break;

                                }
                            }
                        }
                        if (!flag)
                        {
                            ERRORLOG(" TxType unknow");
                            return -1015;
                        }

                        uint64_t lockedAmount = 0;
                        std::string strTx;
                        if (dbWriter.getTransactionByHash(redeemUtxoHashValue, strTx) != DBStatus::DB_SUCCESS)
                        {
                            MagicSingleton<BlockHelper>::GetInstance()->pushMissUtxo(redeemUtxoHashValue);
                            ERRORLOG("getTransactionByHash error! unlockUtxoHash:{},strTx:{}",redeemUtxoHashValue, strTx);
                            return -47;
                        }
                        CTransaction lockTx;
                        if(!lockTx.ParseFromString(strTx))
                        {
                            ERRORLOG("lockTx.ParseFromString(strTx) = {} ",strTx);
                            return -48;
                        }

                        for(const auto & utxo : lockTx.utxos())
                        {
                            for (int i = 0; i < utxo.vout_size(); i++)
                            {
                                if (utxo.vout(i).addr() == global::ca::VIRTUAL_LOCK_ADDRESS)
                                {
                                    lockedAmount += utxo.vout(i).value();
                                    break;
                                }
                            }
                        }

                        // if(lockedAmount != stol(unlockUtxoBalance)){
                        //     ERRORLOG("lockedAmount != unlockUtxoBalance");
                        //     return -102;
                        // }

                        uint64_t totalLocked = 0;
                        if(DBStatus::DB_SUCCESS != dbWriter.getTotalLockedAmonut(totalLocked))
                        {
                            ERRORLOG("getTotalDelegatingAmount error! totalLocked:{}",totalLocked);
                            return -50;
                        }
                        totalLocked-=lockedAmount;
                        if(DBStatus::DB_SUCCESS != dbWriter.setTotalLockedAmonut(totalLocked))
                        {
                            ERRORLOG("setTotalDelegatingAmount error! totalLocked:{}",totalLocked);
                            return -51;
                        }

                        {
                            uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                            uint64_t periodLocked = 0;
                            auto _ret = dbWriter.getTotalLockedAmountByPeriod(period, periodLocked);
                            if(_ret != DBStatus::DB_SUCCESS && _ret != DBStatus::DB_NOT_FOUND){
                                ERRORLOG("get total locked amount by period fail!");
                                return -52;
                            }
                            if(periodLocked >= lockedAmount){
                                periodLocked -= lockedAmount;
                            } else {
                                periodLocked = 0;
                            }
                            if(dbWriter.setTotalLockedAmonutByPeriod(period, periodLocked) != DBStatus::DB_SUCCESS){
                                ERRORLOG("set total locked amount by period fail!");
                                return -53;
                            }
                        }
                        }
                    else if ( global::ca::TxType::DECLARATION == txType )
                    {
                    }
                    // The delegating transaction updates the Delegating address and the utxo of the Delegating address
                    else if (txType == global::ca::TxType::DELEGATE)
                    {
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        std::string delegatingNode = txInfo["bonusAddr"].get<std::string>();
                        uint64_t delegateAmount = txInfo["delegateAmount"].get<uint64_t>();

                        uint64_t totaldelegating = 0;
                        for(const auto &utxo : tx.utxos())
                        {
                            if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                                continue;
                            }
                            std::string currency = utxo.assettype();
                            for (auto &vin : utxo.vin())
                            {
                                std::string addr;
                                if (!tx.rlp().empty())
                                {
                                    ethVerify::EthTransaction ethTx;
                                    dev::bytes rlpBytes = dev::fromHex(tx.rlp());
                                    eth_errors e;
                                    int ret_E = ethVerify::verifyRLP(rlpBytes, e, &ethTx);
                                    if (ret_E != 0)
                                    {
                                        ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
                                        return ret_E;
                                    }
                                    addr = ethTx.from;
                                }
                                else
                                {
                                    addr = GenerateAddr(vin.vinsign().pub());
                                }
                                if (!isValidAddress(addr))
                                {
                                    ERRORLOG("isValidAddress addr:{}",addr);
                                    return -31;
                                }

                                MagicSingleton<ohi::ca::BonusAddrCache>::GetInstance()->isDirty(delegatingNode);
                                if (DBStatus::DB_SUCCESS != dbWriter.setDelegatingAddrUtxoByBonusAddr(delegatingNode, addr, currency, tx.hash()))
                                {
                                    ERRORLOG("setDelegatingAddrUtxoByBonusAddr addr:{} delegatingNode:{}",addr,delegatingNode);
                                    return -32;
                                }
                                std::multimap<std::string, std::string> delegatingAddr_currency;
                                ret = dbWriter.getDelegatingAddrAndAssetTypeByBonusAddr(delegatingNode, delegatingAddr_currency);
                                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                                {
                                    ERRORLOG("getDelegatingAddrAndAssetTypeByBonusAddr ret:{}",ret);
                                    return -33;
                                }
                                auto it = find_if(delegatingAddr_currency.begin(), delegatingAddr_currency.end(), 
                                                        [&](const std::pair<std::string, std::string>& p){
                                                        return p.first == addr && p.second == currency;  
                                                        });
                                if(it == delegatingAddr_currency.end())
                                {
                                    if (DBStatus::DB_SUCCESS != dbWriter.setDelegatingAddrAndAssetTypeByBonusAddr(delegatingNode, addr, currency))
                                    {
                                        ERRORLOG("can't find addr from delegatingAddrs addr:{}",addr);
                                        return -34;
                                    }
                                }

                                std::multimap<std::string, std::string> bonusAddr_assetType;
                                ret = dbWriter.getBonusAddrAndAssetTypeByDelegatingAddr(addr, bonusAddr_assetType);
                                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                                {
                                    ERRORLOG("getBonusAddrAndAssetTypeByDelegatingAddr addr:{}",addr);
                                    return -35;
                                }

                                auto find_iter = std::find_if(bonusAddr_assetType.begin(), bonusAddr_assetType.end(), [&delegatingNode, &currency](const auto & p){return p.first == delegatingNode && p.second == currency;});
                                if ( find_iter == bonusAddr_assetType.end())
                                {
                                    if (DBStatus::DB_SUCCESS != dbWriter.setBonusAddrAndAssetTypeByDelegatingAddr(addr, delegatingNode, currency))
                                    {
                                        ERRORLOG("setBonusAddrAndAssetTypeByDelegatingAddr error, addr:{} ,delegatingNode:{}, assetType:{}", addr,delegatingNode, currency);
                                        return -36;
                                    }
                                }
                                break;
                            }
                        
                            {
                                std::lock_guard<std::mutex> lock(global::ca::kDelegatingMutex);
                                ret = dbWriter.getTotalDelegatingAmount(totaldelegating);
                                if(DBStatus::DB_SUCCESS != ret)
                                {
                                    if(DBStatus::DB_NOT_FOUND == ret)
                                    {
                                        totaldelegating=0;
                                    }
                                    else
                                    {
                                        return -37;
                                    }
                                }
                                
                                totaldelegating += delegateAmount;
                                if (DBStatus::DB_SUCCESS != dbWriter.setTotalDelegatingAmount(totaldelegating))
                                {
                                    ERRORLOG("setTotalDelegatingAmount error! {}",totaldelegating);
                                    return -38;
                                }
                                uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                                if(DBStatus::DB_SUCCESS != dbWriter.setDelegatingUtxoByPeriod(period, tx.hash()))
                                {
                                    ERRORLOG("setDelegatingUtxoByPeriod period:{},hash:{}",period,tx.hash());
                                    return -39;
                                }
                            }
                        }
                    }
                    else if (txType == global::ca::TxType::CALL)
                    {

                    }
                    // The divest transaction updates the Delegating address and the utxo of the Delegating address
                    else if (txType == global::ca::TxType::UNDELEGATE)
                    {
                        bool flag = false;
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        UndelegatingUtxoHash = txInfo["undelegatingUtxo"].get<std::string>();
                        std::string delegatingedNode = txInfo["bonusAddr"].get<std::string>();

                        uint64_t utxoTime;
                        if (dbWriter.set30DayLockData(
                                tx.utxos(0).owner(0), tx.hash(),
                                tx.utxos(0).assettype(), utxoTime,
                                false) != DBStatus::DB_SUCCESS) {
                          ERRORLOG("utxoHash:{} tx.hash:{}", tx.hash(),
                                   utxoTime);
                          return -19;
                        }

                        nlohmann::json lockdata={
                            {"tx_type",(int)txType},
                            {"utxo_hash",tx.hash()},
                            {"asset_type",tx.utxos(0).assettype()}
                        };
                        std::string ldatahex=dev::toHex(lockdata.dump());

                        if(DBStatus::DB_SUCCESS !=dbWriter.addOneLockData(tx.utxos(0).owner(0), ldatahex)){
                                ERRORLOG("addOneLockData fail {}",tx.hash());
                                return -20;
                        }
                        for(const auto &utxo : tx.utxos())
                        {
                            if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                                continue;
                            }
                            std::string currency = utxo.assettype();
                            for (auto &vin : utxo.vin())
                            {
                                for (auto & prevout : vin.prevout())
                                {
                                    if (UndelegatingUtxoHash != prevout.hash() && prevout.n() != 1)
                                    {
                                        continue;
                                    }
                                    flag = true;
                                    std::string addr;
                                    if (!tx.rlp().empty())
                                    {
                                        ethVerify::EthTransaction ethTx;
                                        dev::bytes rlpBytes = dev::fromHex(tx.rlp());
                                        eth_errors e;
                                        int ret_E = ethVerify::verifyRLP(rlpBytes, e, &ethTx);
                                        if (ret_E != 0)
                                        {
                                            ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
                                            return ret_E;
                                        }
                                        addr = ethTx.from;
                                    }
                                    else
                                    {
                                        addr = GenerateAddr(vin.vinsign().pub());
                                    }
                                    if (!isValidAddress(addr))
                                    {
                                        ERRORLOG("isValidAddress error addr:{}",addr);
                                        return -40;
                                    }

                                    MagicSingleton<ohi::ca::BonusAddrCache>::GetInstance()->isDirty(delegatingedNode);
                                    if (DBStatus::DB_SUCCESS != dbWriter.removeDelegatingAddrUtxoByBonusAddr(delegatingedNode, addr, currency, UndelegatingUtxoHash))
                                    {
                                        ERRORLOG("removeDelegatingAddrUtxoByBonusAddr error delegatingedNode:{},addr:{},UndelegatingUtxoHash:{}", delegatingedNode, addr, UndelegatingUtxoHash);
                                        return -41;
                                    }

                                    std::vector<std::string> utxos;
                                    ret = dbWriter.getDelegatingAddrUtxoByBonusAddr(delegatingedNode, addr, currency, utxos);
                                    if (ret == DBStatus::DB_NOT_FOUND || utxos.empty())
                                    {
                                        if (DBStatus::DB_SUCCESS != dbWriter.removeDelegatingAddrAndAssetTypeByBonusAddr(delegatingedNode, addr, currency))
                                        {
                                            ERRORLOG("removeDelegatingAddrAndAssetTypeByBonusAddr delegatingedNode:{},addr:{}",delegatingedNode, addr);
                                            return -42;
                                        }
                                        
                                        if (DBStatus::DB_SUCCESS != dbWriter.removeBonusAddrAndAssetTypeByDelegatingAddr(addr, delegatingedNode, currency))
                                        {
                                            ERRORLOG("removeBonusAddrAndAssetTypeByDelegatingAddr error, addr:{},delegatingedNode:{}, assetType:{}",addr, delegatingedNode, currency);
                                            return -44;
                                        }
                                    }
                                    else if (DBStatus::DB_SUCCESS != ret)
                                    {
                                        ERRORLOG("getDelegatingAddrUtxoByBonusAddr error! ret:{}",ret);
                                        return -45;
                                    }
                                    break;
                                }
                            }
                        }
                        if (!flag)
                        {
                            ERRORLOG("unknow type");
                            return -46;
                        }

                        uint64_t delegateAmount = 0;
                        std::string strTx;
                        if (dbWriter.getTransactionByHash(UndelegatingUtxoHash, strTx) != DBStatus::DB_SUCCESS)
                        {
                            MagicSingleton<BlockHelper>::GetInstance()->pushMissUtxo(UndelegatingUtxoHash);
                            ERRORLOG("getTransactionByHash error! UndelegatingUtxoHash:{},strTx:{}",UndelegatingUtxoHash, strTx);
                            return -47;
                        }
                        CTransaction tnvestTx;
                        if(!tnvestTx.ParseFromString(strTx))
                        {
                            ERRORLOG("tnvestTx.ParseFromString(strTx) = {} ",strTx);
                            return -48;
                        }

                        for(const auto & utxo : tnvestTx.utxos())
                        {
                            for (int i = 0; i < utxo.vout_size(); i++)
                            {
                                if (utxo.vout(i).addr() == global::ca::kVirtualDelegatingAddr)
                                {
                                    delegateAmount += utxo.vout(i).value();
                                    break;
                                }
                            }
                        }
                        uint64_t totaldelegating = 0;
                        std::vector<std::string> utxos;
                        {
                            std::lock_guard<std::mutex> lock(global::ca::kDelegatingMutex);
                            uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tnvestTx.time());
                            auto ret = dbWriter.getDelegatingUtxoByPeriod(period, utxos);
                            if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                            {
                                ERRORLOG("DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret {}",ret);
                                return -49;
                            }
                            if (utxos.cend() != std::find(utxos.cbegin(), utxos.cend(), UndelegatingUtxoHash))
                            {
                                if(DBStatus::DB_SUCCESS != dbWriter.getTotalDelegatingAmount(totaldelegating))
                                {
                                    ERRORLOG("getTotalDelegatingAmount error! totaldelegating:{}",totaldelegating);
                                    return -50;
                                }
                                totaldelegating-=delegateAmount;
                                if(DBStatus::DB_SUCCESS != dbWriter.setTotalDelegatingAmount(totaldelegating))
                                {
                                    ERRORLOG("setTotalDelegatingAmount error! totaldelegating:{}",totaldelegating);
                                    return -51;
                                }
                                uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tnvestTx.time());
                                if (DBStatus::DB_SUCCESS != dbWriter.removeDelegatingUtxoByPeriod(period, UndelegatingUtxoHash))
                                {
                                    ERRORLOG("removeDelegatingUtxoByPeriod error! period:{},divestUtxoHash:{}",period, UndelegatingUtxoHash);
                                    return -52;
                                }
                            }
                        }
                    }
                    else if(txType == global::ca::TxType::PROPOSAL)
                    {
                        std::vector<std::string> assertTypes;
                        auto dbRet = dbWriter.getAssetType(assertTypes);
                        if(dbRet != DBStatus::DB_SUCCESS && dbRet != DBStatus::DB_NOT_FOUND)
                        {
                            ERRORLOG("getAssetType error:{}",dbRet);
                            return -1007;
                        }

                        // 第一笔提案的资产类型使用 ASSET_TYPE_OHI（即OHI资产），后续提案使用交易hash
                        // 原逻辑：所有提案的资产类型均为tx.hash()
                        // 现逻辑：因为第一种通过Proposal的Token即为OHI资产，直接使用assetType_MM
                        std::string assetTypeKey = assertTypes.empty() ? global::ca::ASSET_TYPE_OHI : tx.hash();

                        if (DBStatus::DB_SUCCESS != dbWriter.setAssetType(assetTypeKey))
                        {
                            ERRORLOG("setAssetType error:{}",assetTypeKey);
                            return -1004;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.setVoteCountByAssetType(assetTypeKey, 0, 0))
                        {
                            ERRORLOG("setVoteCountByAssetType error:{}",assetTypeKey);
                            return -1005;
                        }
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        std::string proposalInfo = txInfo.dump();

                        std::string base64string = Base64Encode(proposalInfo);
                        std::cout << "saveblock proposalInfo: " << proposalInfo << std::endl;
                        if(DBStatus::DB_SUCCESS != dbWriter.setProposalInfoByAssetType(assetTypeKey, std::move(base64string)))
                        {
                            ERRORLOG("setProposalInfoByAssetType error");
                            return -1006;
                        }
                        std::string contractAddr = txInfo["tokenContractAddr"].get<std::string>();
                        if(DBStatus::DB_SUCCESS != dbWriter.setAssetTypeByContractAddr(contractAddr, assetTypeKey))
                        {
                            ERRORLOG("setAssetTypeByContractAddr error");
                            return -1020;
                        }
                    }
                    else if(txType == global::ca::TxType::REVOKEPROPOSAL) 
                    {
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        std::string proposalHash = txInfo["proposalHash"].get<std::string>();
                        std::string proposalInfo = txInfo.dump();
                        
                        nlohmann::json dataJson = nlohmann::json::parse(proposalInfo);
                        
                        std::string base64string = Base64Encode(proposalInfo);
                        std::cout << "saveblock revoke proposalInfo: " << proposalInfo << std::endl;
                        if (DBStatus::DB_SUCCESS != dbWriter.setRevokeProposalInfoByAssetType(tx.hash(),  std::move(base64string)))
                        {
                            ERRORLOG("setRevokeProposalInfoByAssetType error");
                            return -1008;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.setRevokeTxHashByAssetType(proposalHash, tx.hash()))
                        {
                            ERRORLOG("setRevokeTxHashByAssetType error");
                            return -1009;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.setVoteCountByAssetType(tx.hash(), 0, 0))
                        {
                            ERRORLOG("setVoteCountByAssetType error:{}",tx.hash());
                            return -1010;
                        }
                    }
                    else if (global::ca::TxType::VOTE == txType) 
                    {
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        std::string voteHash = txInfo["voteHash"].get<std::string>();
                        int pollType = txInfo["voteType"].get<int>();
                        uint64_t voteNumber = txInfo["voteNumber"].get<std::uint64_t>();

                        for(const auto &_utxo : tx.utxos())
                        {   
                            std::cout << "save owner: " <<"0x"+ _utxo.owner(0) << std::endl;
                            int ret = ca_algorithm::addVoteCount(dbWriter, voteHash, pollType, _utxo.owner(0), voteNumber);
                            if(ret != 0)
                            {
                                ERRORLOG("addVoteCount error: {}",ret);
                                return -1007;
                            }
                            break;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.setVoteTxHashByAssetType(voteHash, tx.hash()))
                        {
                            ERRORLOG("setVoteTxHashByAssetType error:{}",tx.hash());
                            return -1011;
                        }

                    }
                    // Renewal of claim transaction......
                    else if(txType == global::ca::TxType::BONUS)
                    {
                        uint64_t claimAmount = 0;
                        uint64_t totalCirculation = 0;
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        txInfo["bonusAmount"].get_to(claimAmount);
                        {
                            std::lock_guard<std::mutex> lock(global::ca::bonusMutex);
                            uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                            if(DBStatus::DB_SUCCESS != dbWriter.setBonusUtxoByPeriod(period,tx.hash()))
                            {
                                ERRORLOG("setBonusUtxoByPeriod error! period:{},hash:{}",period,tx.hash());
                                return -54;
                            }

                            if(DBStatus::DB_SUCCESS != dbWriter.getTotalCirculation(totalCirculation) &&
                                 DBStatus::DB_NOT_FOUND != dbWriter.getTotalCirculation(totalCirculation))
                            {
                                ERRORLOG("getTotalCirculation error!");
                                return -55;
                            }
                            DEBUGLOG("totalCirculation:{},claimAmount{}",totalCirculation,claimAmount);
                            if (global::ca::VOTE_CIRCULATION >
                                totalCirculation + claimAmount) {
                              if (DBStatus::DB_SUCCESS !=
                                  dbWriter.setTotalCirculation(
                                      totalCirculation + claimAmount)) {
                                ERRORLOG("setTotalCirculation error! amount:{}",claimAmount);
                                return -55;
                              }
                            }
                        } 
                    }
                    else if(txType == global::ca::TxType::FUND)
                    {
                        uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                        if(DBStatus::DB_SUCCESS != dbWriter.setFundUtxoByPeriod(period,tx.hash()))
                        {
                            ERRORLOG("setBonusUtxoByPeriod error! period:{},hash:{}",period,tx.hash());
                            return -56;
                        }

                    }
                    else if(txType == global::ca::TxType::EVIDENCE)
                    {
                        if (ca_algorithm::ValidateSlashEvidenceTx(tx, &dbWriter) != 0)
                        {
                            ERRORLOG("[SLASH] EVIDENCE tx rejected by deterministic validation, hash:{}", tx.hash());
                            return -56;
                        }

                        // Parse EVIDENCE transaction data
                        nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                        std::string targetAddr = dataJson.value("target_addr", "");
                        std::string violationType = dataJson.value("violation_type", "");
                        std::string evidenceHash = dataJson.value("evidence_hash", "");

                        if (targetAddr.empty() || evidenceHash.empty())
                        {
                            ERRORLOG("[SLASH] Invalid EVIDENCE tx: missing fields, hash:{}", tx.hash());
                            return -56;
                        }

                        // P3-27: Network initialization protection
                        // If stake nodes < kConsensus, just record evidence but don't enforce
                        std::vector<std::string> allStakeAddrs;
                        dbWriter.getStakeAddr(allStakeAddrs);
                        if (allStakeAddrs.size() < static_cast<size_t>(global::ca::kConsensus))
                        {
                            DEBUGLOG("[SLASH] Network too young ({} stake nodes < kConsensus={}), recording evidence but not enforcing",
                                     allStakeAddrs.size(), global::ca::kConsensus);
                            // Still record the evidence for historical purposes
                            dbWriter.setEvidenceOnChain(evidenceHash, targetAddr, violationType);
                        }
                        // Idempotency: check if evidence already recorded
                        else if (DBStatus::DB_SUCCESS == dbWriter.hasEvidenceOnChain(evidenceHash))
                        {
                            DEBUGLOG("[SLASH] EVIDENCE already on chain, hash:{}", evidenceHash);
                        }
                        else
                        {
                            // Record evidence on chain
                            dbWriter.setEvidenceOnChain(evidenceHash, targetAddr, violationType);

                            // Update evidence count
                            int64_t count = 0;
                            dbWriter.getEvidenceCount(targetAddr, violationType, count);
                            count += 1;
                            dbWriter.setEvidenceCount(targetAddr, violationType, count);

                            // Check if threshold reached
                            uint32_t threshold = 0;
                            uint32_t penaltyLevel = 0;
                            if (violationType == "DOUBLE_SIGN_VRF" || violationType == "DOUBLE_SIGN_BLOCK")
                            {
                                threshold = global::ca::kPunishmentThresholdL4;
                                penaltyLevel = 4;
                            }
                            else
                            {
                                threshold = global::ca::kPunishmentThresholdL3;
                                penaltyLevel = 3;
                            }

                            if (static_cast<uint32_t>(count) >= threshold)
                            {
                                // Build evidence refs string
                                std::string evidenceRefs = evidenceHash;
                                dbWriter.addToThresholdExceeded(targetAddr, std::to_string(penaltyLevel), violationType, evidenceRefs);
                                INFOLOG("[SLASH] Threshold reached! addr:{}, type:{}, count:{}, level:{}",
                                        targetAddr, violationType, count, penaltyLevel);
                            }
                        }
                    }
                    else if(txType == global::ca::TxType::PUNISHMENT)
                    {
                        if (ca_algorithm::ValidateSlashPunishmentTx(tx, &dbWriter) != 0)
                        {
                            ERRORLOG("[SLASH] PUNISHMENT tx rejected by deterministic validation, hash:{}", tx.hash());
                            return -56;
                        }

                        // Parse PUNISHMENT transaction data
                        nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                        std::string targetAddr = dataJson.value("target_addr", "");
                        uint32_t penaltyLevel = dataJson.value("penalty_level", 0);
                        std::string violationType = dataJson.value("violation_type", "");
                        std::string evidenceRefs = dataJson.value("evidence_refs", "");
                        std::string punishmentId = dataJson.value("punishment_id", "");
                        std::vector<std::string> stakeRefs = dataJson.value("stake_refs", std::vector<std::string>{});
                        uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                        dbWriter.setPunishmentHistory(punishmentId, targetAddr, std::to_string(period), penaltyLevel, tx.hash());

                            // Calculate total stake amount from the deterministic stake_refs snapshot.
                            int64_t totalStake = 0;
                            std::vector<std::string> stakeUtxoHashes = stakeRefs;
                            for (const auto& utxoHash : stakeUtxoHashes)
                            {
                                std::string txRaw;
                                if (DBStatus::DB_SUCCESS == dbWriter.getTransactionByHash(utxoHash, txRaw))
                                {
                                    CTransaction stakeTx;
                                    if (stakeTx.ParseFromString(txRaw))
                                    {
                                        for (const auto& utxo : stakeTx.utxos())
                                        {
                                            for (const auto& vout : utxo.vout())
                                            {
                                                if (vout.addr() == global::ca::kTargetAddress)
                                                {
                                                    totalStake += vout.value();
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            if (penaltyLevel == 3)
                            {
                                // L3 — Stake slashing with递增 rates
                                uint32_t slashCount = 0;
                                dbWriter.getL3SlashCount(targetAddr, slashCount);
                                slashCount++;

                                double slashRate = global::ca::kSlashRateFirst; // 1%
                                if (slashCount == 2) slashRate = global::ca::kSlashRateSecond; // 3%
                                else if (slashCount >= 3) slashRate = global::ca::kSlashRateThird; // 5%

                                int64_t slashAmount = static_cast<int64_t>(totalStake * slashRate);
                                int64_t remainingStake = totalStake - slashAmount;

                                dbWriter.setL3SlashCount(targetAddr, slashCount);

                                INFOLOG("[SLASH] L3 Stake slash #{} executed! addr:{}, totalStake:{}, slashRate:{}%, slashAmount:{}, remaining:{}",
                                        slashCount, targetAddr, totalStake, slashRate * 100, slashAmount, remainingStake);

                                // Remove consumed stake UTXOs
                                for (const auto& utxoHash : stakeUtxoHashes)
                                {
                                    dbWriter.removeStakeUtxoByAddr(targetAddr, "OHI", utxoHash);
                                }

                                // L3→L4 cascade: if remaining stake < MIN_STAKE_AMOUNT, trigger L4
                                if (remainingStake < static_cast<int64_t>(global::ca::MIN_STAKE_AMOUNT))
                                {
                                    ERRORLOG("[SLASH] L3→L4 cascade! addr:{} remaining stake {} < MIN_STAKE_AMOUNT {}",
                                             targetAddr, remainingStake, global::ca::MIN_STAKE_AMOUNT);
                                    penaltyLevel = 4; // Escalate to L4
                                    // Fall through to L4 handling below
                                }
                                else
                                {
                                    // Re-create stake UTXO for remaining amount and store a synthetic raw tx
                                    // so existing stake queries can resolve the hash deterministically.
                                    std::string remainingUtxoHash = tx.hash() + "_remaining";
                                    CTransaction remainingStakeTx;
                                    remainingStakeTx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
                                    remainingStakeTx.set_type(static_cast<uint32_t>(global::ca::TxType::STAKE));
                                    remainingStakeTx.set_identity(targetAddr);
                                    remainingStakeTx.set_time(tx.time());
                                    remainingStakeTx.set_hash(remainingUtxoHash);
                                    nlohmann::json remainingData;
                                    remainingData["txInfo"]["stakeType"] = global::ca::STAKE_TYPE_NET;
                                    remainingStakeTx.set_data(remainingData.dump());
                                    CTxUtxos* remainingUtxo = remainingStakeTx.add_utxos();
                                    remainingUtxo->set_assettype("OHI");
                                    remainingUtxo->add_owner(targetAddr);
                                    CTxOutput* remainingVout = remainingUtxo->add_vout();
                                    remainingVout->set_addr(global::ca::kTargetAddress);
                                    remainingVout->set_value(remainingStake);
                                    dbWriter.setTransactionByHash(remainingUtxoHash, remainingStakeTx.SerializeAsString());
                                    dbWriter.setStakeUtxoByAddr(targetAddr, "OHI", remainingUtxoHash);
                                    dbWriter.setUtxoValueByUtxoHashes(remainingUtxoHash, targetAddr, "OHI", std::to_string(remainingStake));
                                    INFOLOG("[SLASH] L3 remaining stake UTXO created: hash={}, value={}", remainingUtxoHash, remainingStake);
                                }
                            }

                            if (penaltyLevel == 4)
                            {
                                // L4 — Tombstoning (permanent ban)
                                dbWriter.setTombstoned(targetAddr, "PUNISHMENT_L4", std::to_string(period), tx.hash());

                                // Remove all stake UTXOs and address
                                for (const auto& utxoHash : stakeUtxoHashes)
                                {
                                    dbWriter.removeStakeUtxoByAddr(targetAddr, "OHI", utxoHash);
                                }
                                dbWriter.removeStakeAddr(targetAddr);

                                // Refund all delegations
                                nlohmann::json refundSnapshots = nlohmann::json::array();
                                std::multimap<std::string, std::string> delegatorMap;
                                if (DBStatus::DB_SUCCESS == dbWriter.getDelegatingAddrAndAssetTypeByBonusAddr(targetAddr, delegatorMap))
                                {
                                    for (const auto& [delegatorAddr, assetType] : delegatorMap)
                                    {
                                        // Get delegation amount
                                        std::vector<std::string> delegatingUtxos;
                                        dbWriter.getDelegatingAddrUtxoByBonusAddr(targetAddr, delegatorAddr, assetType, delegatingUtxos);
                                        for (const auto& utxoHash : delegatingUtxos)
                                        {
                                            std::string txRaw;
                                            if (DBStatus::DB_SUCCESS == dbWriter.getTransactionByHash(utxoHash, txRaw))
                                            {
                                                CTransaction delegateTx;
                                                if (delegateTx.ParseFromString(txRaw))
                                                {
                                                    for (const auto& utxo : delegateTx.utxos())
                                                    {
                                                        for (const auto& vout : utxo.vout())
                                                        {
                                                            if (vout.addr() == global::ca::kVirtualDelegatingAddr)
                                                            {
                                                                // Refund to delegator
                                                                std::string refundUtxoHash = tx.hash() + "_refund_" + delegatorAddr + "_" + utxoHash;
                                                                dbWriter.setUtxoHashesByAddr(delegatorAddr, assetType, refundUtxoHash);
                                                                dbWriter.setUtxoValueByUtxoHashes(refundUtxoHash, delegatorAddr, assetType, std::to_string(vout.value()));
                                                                
                                                                // Update delegator's balance
                                                                int64_t delegatorBalance = 0;
                                                                dbWriter.getBalanceByAddr(delegatorAddr, assetType, delegatorBalance);
                                                                delegatorBalance += vout.value();
                                                                dbWriter.setBalanceByAddr(delegatorAddr, assetType, delegatorBalance);

                                                                nlohmann::json refundSnapshot;
                                                                refundSnapshot["delegator_addr"] = delegatorAddr;
                                                                refundSnapshot["asset_type"] = assetType;
                                                                refundSnapshot["delegating_utxo"] = utxoHash;
                                                                refundSnapshot["refund_utxo"] = refundUtxoHash;
                                                                refundSnapshot["amount"] = vout.value();
                                                                refundSnapshots.push_back(refundSnapshot);
                                                                
                                                                INFOLOG("[SLASH] L4 refund {} to delegator:{}, new balance:{}", vout.value(), delegatorAddr, delegatorBalance);
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            // Remove delegation UTXO record
                                            dbWriter.removeDelegatingAddrUtxoByBonusAddr(targetAddr, delegatorAddr, assetType, utxoHash);
                                        }
                                        // Remove delegation address mapping
                                        dbWriter.removeDelegatingAddrAndAssetTypeByBonusAddr(targetAddr, delegatorAddr, assetType);
                                    }
                                }
                                if (!refundSnapshots.empty())
                                {
                                    dbWriter.setPunishmentDelegationRefunds(punishmentId, refundSnapshots.dump());
                                }

                                INFOLOG("[SLASH] L4 Tombstoning executed! addr:{}, period:{}", targetAddr, period);
                            }

                            // Clean up evidence indices for this target
                            dbWriter.removeEvidenceCount(targetAddr, "DOUBLE_SIGN_VRF");
                            dbWriter.removeEvidenceCount(targetAddr, "DOUBLE_SIGN_BLOCK");
                            dbWriter.removeEvidenceCount(targetAddr, "INVALID_BLOCK");
                            dbWriter.removeEvidenceCount(targetAddr, "VRF_VERIFY_FAIL");
                            dbWriter.removeEvidenceCount(targetAddr, "LOW_SIGN_RATE");
                            dbWriter.removeEvidenceCount(targetAddr, "FREQUENT_DISCONNECT");
                            dbWriter.removeFromThresholdExceeded(targetAddr);
                    }
                }
                catch (...)
                {
                    return -56;
                }
            }
            // 需要区分各种类型的资产 现在的utxo相当于(类型 + utxo)
            // All transaction updates delete the utxo used, and subtract the balance of utxo used by the transaction address
            for(const auto& utxo : tx.utxos())
            {
                std::string currency = utxo.assettype();


                std::vector<std::string> vin_hash_values;
                for (auto &vin : utxo.vin())
                {
                    global::ca::TxType txType = (global::ca::TxType)tx.type();

                    std::string addr;
                    if(vin.contractaddr().empty())
                    {
                        if (vin.vinsign().pub().size() == 0)
                        {
                            return -57;
                        }
                        if(!tx.rlp().empty()){
                            ethVerify::EthTransaction ethTx;
                            dev::bytes rlpBytes = dev::fromHex(tx.rlp());
                            eth_errors e;
                            int ret_E = ethVerify::verifyRLP(rlpBytes,e,&ethTx);
                            if(ret_E != 0){
                                ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
                                return ret_E;
                            }
                            addr = ethTx.from;
                        }else{addr = GenerateAddr(vin.vinsign().pub());}
                    }
                    else if(global::ca::TxType::DEPLOY == txType || global::ca::TxType::CALL == txType)
                    {
                        if (vin.vinsign().pub().size() != 0)
                        {
                            return -58;
                        }
                        addr = vin.contractaddr();
                    }

                    allAddr.insert(addr);

                    for (auto & prevout : vin.prevout())
                    {
                        std::string utxoHash = prevout.hash();
                        std::string utxoN = utxoHash + "_" + addr + "_" +std::to_string(prevout.n());
                        if (txType == global::ca::TxType::UNSTAKE && 
                            redeemUtxoHashValue == utxoHash && 
                            1 == prevout.n())
                        {
                            continue;
                        }
                        else if(txType == global::ca::TxType::UNLOCK &&
                            redeemUtxoHashValue == utxoHash && 
                            1 == prevout.n())
                        {
                            continue;
                        }
                        else if (txType == global::ca::TxType::UNDELEGATE && 
                                UndelegatingUtxoHash == utxoHash && 
                                1 == prevout.n())
                        {
                            continue;
                        }                

                        if (vin_hash_values.cend() != std::find(vin_hash_values.cbegin(), vin_hash_values.cend(), utxoN))
                        {
                            continue;
                        }
                        vin_hash_values.push_back(utxoN);

                        if (DBStatus::DB_SUCCESS != dbWriter.removeUtxoHashesByAddr(addr, currency, utxoHash))
                        {
                            ERRORLOG("removeUtxoHashesByAddr addr:{},utxoHash:{}",addr,utxoHash);
                            return -59;
                        }

                        uint64_t amount = 0;
                        std::string balanceUtxo ;
                        //add special check
                        if (global::ca::TxType::BONUS == txType && dbWriter.getUtxoValueByUtxoHashes(utxoHash, addr, currency, balanceUtxo) == DBStatus::DB_NOT_FOUND)
                        {
                            continue;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.getUtxoValueByUtxoHashes(utxoHash, addr, currency, balanceUtxo))
                        {
                            MagicSingleton<BlockHelper>::GetInstance()->pushMissUtxo(utxoHash);
                            ERRORLOG("getUtxoValueByUtxoHashes failed!,utxoHash:{}", utxoHash);
                            return - 60;
                        }
                        
                    
                        if (DBStatus::DB_SUCCESS != dbWriter.removeUtxoValueByUtxoHashes(utxoHash, addr, currency, balanceUtxo))
                        {
                            ERRORLOG("getTransactionByHash failed!");
                            return -61;
                        }
                        

                        uint64_t stakeValue = 0;
                        std::string underline = "_";
                        std::vector<std::string> utxoValues;

                        if(balanceUtxo.find(underline) != std::string::npos)
                        {
                            StringUtil::SplitString(balanceUtxo, "_", utxoValues);
                            
                            for(int i = 0; i < utxoValues.size(); ++i)
                            {
                                stakeValue += std::stol(utxoValues[i]);
                            }
                            amount = stakeValue;
                        }
                        else
                        {
                            amount = std::stol(balanceUtxo);
                        }
                    

                        int64_t balance = 0;
                        ret = dbWriter.getBalanceByAddr(addr, currency, balance);
                        if (DBStatus::DB_SUCCESS != ret)
                        {
                            if (DBStatus::DB_NOT_FOUND != ret)
                            {
                                ERRORLOG("getBalanceByAddr error! ret:{}",ret);
                                return -62;
                            }
                            else
                            {
                                balance = 0;
                            }
                        }
                        balance -= amount;
                        if (balance < 0)
                        {
                            ERRORLOG("SaveBlock vin height:{} hash:{} addr:{} balance:{}", block.height(), block.hash(), addr, balance);
                            return -63;
                        }
                        if (0 == balance)
                        {
                            if (DBStatus::DB_SUCCESS != dbWriter.removeBalanceByAddr(addr, currency))
                            {
                                ERRORLOG("removeBalanceByAddr error! addr:{}",addr);
                                return -64;
                            }
                        }
                        else
                        {
                            if (DBStatus::DB_SUCCESS != dbWriter.setBalanceByAddr(addr, currency, balance))
                            {
                                ERRORLOG("setBalanceByAddr error! addr:{},balance:{}",addr,balance);
                                return -65;
                            }
                        } 
                                         
                    }

                }
            }
        }
        
        //用新类型手续费交易只需要考虑vin
        //普通交易需要特殊判断
        // Add new utxo to all transactions and increase the balance of utxo used by the transaction address
        bool falg = false;
        for(const auto& utxo : tx.utxos())
        {
            // std::multimap<std::string,std::string> utxoValue;
            std::multimap<std::string,std::string> bonusUtxoValue;
            std::multimap<std::string,std::string> fundUtxoValue;
            std::map<std::string,std::multimap<std::string,std::string>> ContractUtxoValue;
            std::string currency = utxo.assettype();

        
            //只需在数据库接口加类型
            for (auto &vout : utxo.vout())
            {
                if(vout.addr() == global::ca::VIRTUAL_BURN_GAS_ADDR || vout.addr() == global::ca::kVirtualDeploymentContractAddress || vout.addr() == global::ca::VIRTUAL_CALL_CONTRACT_ADDR ) 
                {
                    uint64_t totalburn = 0;
                    uint64_t burnAmount = 0;
                    uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                    std::lock_guard<std::mutex> lock(global::ca::BURN_MUTEX);
                    auto ret = dbWriter.getTotalBurnAmount(totalburn);
                    if(ret != DBStatus::DB_SUCCESS && ret != DBStatus::DB_NOT_FOUND)
                    {
                        ERRORLOG("getTotalBurnAmount error! totalburn:{}",totalburn);
                        return -66;
                    }

                    ret = dbWriter.getBurnAmountByPeriod(period, burnAmount);
                    if(DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                    {
                        ERRORLOG("getBurnAmountByPeriod error! ret:{}",ret);
                        return -67;
                    }
                    burnAmount += vout.value();
                    totalburn += vout.value();
                    if(DBStatus::DB_SUCCESS != dbWriter.setBurnAmountByPeriod(period, burnAmount))
                    {
                        ERRORLOG("setBurnAmountByPeriod error! period:{}, burnAmount:{}", period, burnAmount);
                        return -68;
                    }
                    if (DBStatus::DB_SUCCESS != dbWriter.setTotalBurnAmount(totalburn))
                    {
                        ERRORLOG("setTotalBurnAmount error! totalburn:{}", totalburn);
                        return -69;
                    }
                    uint64_t zero_time = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                    uint64_t gasAmount = 0;
                    auto result = dbWriter.getGasAmountByPeriod(zero_time,currency,gasAmount);
                    if(result != DBStatus::DB_SUCCESS && result != DBStatus::DB_NOT_FOUND)
                    {
                        ERRORLOG("getGasAmountByPeriod error! gasAmount:{}",gasAmount);
                        return -170;
                    }
                    DEBUGLOG("getGasAmountByPeriod (zero_time:{}, currency:{},gasAmount:{})",zero_time, currency,gasAmount);
                    gasAmount += vout.value();
                    if(DBStatus::DB_SUCCESS != dbWriter.setGasAmountByPeriod(zero_time,currency,gasAmount))
                    {
                        ERRORLOG("setGasAmountByPeriod error! zero_time:{}, currency:{},gasAmount{}",zero_time,currency,burnAmount);
                        return -171;
                    }

                    continue;
                }

                if(vout.addr() == global::ca::kVirtualDeploymentContractAddress || vout.addr() == global::ca::VIRTUAL_CALL_CONTRACT_ADDR || vout.addr() == global::ca::kVirtualCallFlowOutAddr)
                {
                    continue;
                }

                global::ca::TxType txType = (global::ca::TxType)tx.type();
                if (vout.addr() != global::ca::kTargetAddress && vout.addr() != global::ca::kVirtualDelegatingAddr && vout.addr() != global::ca::VIRTUAL_LOCK_ADDRESS)
                {
                    allAddr.insert(vout.addr());
                }

                std::vector<std::string> utxoHashesList;
                dbWriter.getUtxoHashsByAddress(vout.addr(), currency, utxoHashesList);
                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                {
                    ERRORLOG("setUtxoHashesByAddr error! ret:{}",ret);
                    return -70;
                }
                

                if(utxoHashesList.cend() == std::find(utxoHashesList.cbegin(), utxoHashesList.cend(), tx.hash()))
                {
                    ret = dbWriter.setUtxoHashesByAddr(vout.addr(), currency ,tx.hash());
                    if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                    {
                        ERRORLOG("setUtxoHashesByAddr error! ret:{}",ret);
                        return -71;
                    }
                }

                // if((txType == global::ca::TxType::UNSTAKE || txType == global::ca::TxType::UNDELEGATE || txType == global::ca::TxType::UNLOCK) && utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_FALSE)
                // {
                //     utxoValue.insert(std::make_pair(tx.hash() + "_" + vout.addr(),std::to_string(vout.value())));
                // }
                // else 
                if(txType == global::ca::TxType::BONUS && utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_FALSE)
                {
                    if(vout.addr() == utxo.owner(0))
                    {
                        bonusUtxoValue.insert(std::make_pair(tx.hash() + "_" + vout.addr(),std::to_string(vout.value())));
                    }
                    else
                    {
                        ret = dbWriter.setUtxoValueByUtxoHashes(tx.hash(), vout.addr(), currency, std::to_string(vout.value()));
                        if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                        {
                            ERRORLOG("setUtxoHashesByAddr error! ret:{}",ret);
                            return -72;
                        }
                    }
                }
                else if(txType == global::ca::TxType::DEPLOY || txType == global::ca::TxType::CALL)
                {
                    ContractUtxoValue[vout.addr()].insert(std::make_pair(tx.hash() + "_" + vout.addr(),std::to_string(vout.value())));
                }
                else if(txType == global::ca::TxType::FUND){
                    fundUtxoValue.insert(std::make_pair(tx.hash() + "_" + vout.addr(),std::to_string(vout.value())));
                }
                else
                {
                    ret = dbWriter.setUtxoValueByUtxoHashes(tx.hash(), vout.addr(), currency, std::to_string(vout.value()));
                    if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                    {
                        ERRORLOG("setUtxoHashesByAddr error! ret:{}",ret);
                        return -73;
                    }
                }

                int64_t balance = 0;
                ret = dbWriter.getBalanceByAddr(vout.addr(), currency, balance);
                if (DBStatus::DB_SUCCESS != ret)
                {
                    if (DBStatus::DB_NOT_FOUND != ret)
                    {
                        ERRORLOG("DBStatus::DB_SUCCESS != ret");
                        return -74;
                    }
                    else
                    {
                        balance = 0;
                    }
                }
                balance += vout.value();
                if (balance < 0)
                {
                    ERRORLOG("SaveBlock vout height:{} hash:{} addr:{} balance:{}", block.height(), block.hash(), vout.addr(), balance);
                    return -75;
                }
                if (DBStatus::DB_SUCCESS != dbWriter.setBalanceByAddr(vout.addr(), currency, balance))
                {
                    ERRORLOG("setBalanceByAddr error! vout.addr{},balance:{},currency{}",vout.addr(),balance,currency);
                    return -76;
                }
            }

            // std::vector<std::string> utxoValues;
            // if(utxoValue.size() == 2)
            // {
            //     std::string utxoHashBalance;
            //     auto iter = utxoValue.begin();
            //     for(;iter != utxoValue.end(); iter ++)
            //     {
            //         utxoHashBalance += iter->second + "_";
            //         utxoValues.clear();
            //         StringUtil::SplitString(iter->first, "_", utxoValues);      
            //     }

            //     if(utxoHashBalance[utxoHashBalance.length()-1] == '_')
            //     {
            //         utxoHashBalance = utxoHashBalance.substr(0,utxoHashBalance.length()-1);
            //     }

            //     ret = dbWriter.setUtxoValueByUtxoHashes(utxoValues[0], utxoValues[1], currency, utxoHashBalance);
            //     if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
            //     {
            //         ERRORLOG("setUtxoValueByUtxoHashes error! ret:{}",ret);
            //         return -77;
            //     }

            // }


            if(!fundUtxoValue.empty()){
                std::string utxoHashBalance;
                std::vector<std::string> utxoValues;
                if(fundUtxoValue.size() == 2){
                    auto iter = fundUtxoValue.begin();
                    for(;iter!=fundUtxoValue.end();iter++){
                        utxoHashBalance += iter->second + "_";
                        utxoValues.clear();
                        StringUtil::SplitString(iter->first, "_", utxoValues);
                    }

                    if(utxoHashBalance[utxoHashBalance.length()-1] == '_'){
                        utxoHashBalance = utxoHashBalance.substr(0,utxoHashBalance.length()-1);
                    }

                }else if(fundUtxoValue.size() == 1){
                    auto iter = fundUtxoValue.begin();
                    utxoHashBalance = iter->second;
                    StringUtil::SplitString(iter->first, "_", utxoValues);
                    
                }

                ret = dbWriter.setUtxoValueByUtxoHashes(utxoValues[0], utxoValues[1], currency, utxoHashBalance);
                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                {
                    ERRORLOG("setUtxoValueByUtxoHashes error! ret:{}",ret);
                    return -97;
                }
            }

            std::vector<std::string> bonusUtxoValues;
            if(!bonusUtxoValue.empty())
            {
                std::string utxoHashBalance;
                auto iter = bonusUtxoValue.begin();
                for(;iter != bonusUtxoValue.end(); iter ++)
                {
                    utxoHashBalance += iter->second + "_";   
                    bonusUtxoValues.clear();
                    StringUtil::SplitString(iter->first, "_", bonusUtxoValues);   
                }
                if(utxoHashBalance[utxoHashBalance.length()-1] == '_')
                {
                    utxoHashBalance = utxoHashBalance.substr(0,utxoHashBalance.length()-1);
                }

                ret = dbWriter.setUtxoValueByUtxoHashes(bonusUtxoValues[0], bonusUtxoValues[1], currency, utxoHashBalance);
                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                {
                    ERRORLOG("setUtxoValueByUtxoHashes error! ret:{}",ret);
                    return -78;
                }

            }

            if(!ContractUtxoValue.empty())
            {
                for(const auto& UtxoValue : ContractUtxoValue)
                {
                    std::vector<std::string> ContractUtxoValues;
                    std::string utxoHashBalance;
                    auto iter = UtxoValue.second.begin();
                    for(;iter != UtxoValue.second.end(); iter ++)
                    {
                        utxoHashBalance += iter->second + "_";   
                        ContractUtxoValues.clear();
                        StringUtil::SplitString(iter->first, "_", ContractUtxoValues);   
                    }
                    if(utxoHashBalance[utxoHashBalance.length()-1] == '_')
                    {
                        utxoHashBalance = utxoHashBalance.substr(0,utxoHashBalance.length()-1);
                    }

                    ret = dbWriter.setUtxoValueByUtxoHashes(ContractUtxoValues[0], ContractUtxoValues[1], currency, utxoHashBalance);
                    if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                    {
                        ERRORLOG("setUtxoValueByUtxoHashes error! ret:{}",ret);
                        return -79;
                    }
                    
                }
            }
        }

        // Store keccak256(rlp) → internal hash mapping for ETH wallet compatibility
        if (!tx.rlp().empty())
        {
            dev::bytes rlpBytes = dev::fromHex(tx.rlp());
            std::string rlpHash = keccak256_hex(std::string(reinterpret_cast<const char*>(rlpBytes.data()), rlpBytes.size()));
            std::transform(rlpHash.begin(), rlpHash.end(), rlpHash.begin(), ::tolower);
            ERRORLOG("SaveBlock eth rlp mapping begin! block.hash:{}, block.height:{}, rlpHash:{}, tx.hash:{}, rlp.size:{}",
                     block.hash(), block.height(), rlpHash, tx.hash(), tx.rlp().size());
            if (DBStatus::DB_SUCCESS != dbWriter.setInternalHashByRlpHash(rlpHash, tx.hash()))
            {
                ERRORLOG("setInternalHashByRlpHash error! rlpHash:{}, tx.hash:{}", rlpHash, tx.hash());
                return -82;
            }
            ERRORLOG("SaveBlock eth rlp mapping success! rlpHash:{}, tx.hash:{}", rlpHash, tx.hash());
        }

        // Add transaction body data corresponding to transaction hash
        const std::string serializedTx = tx.SerializeAsString();
        ERRORLOG("SaveBlock transaction body begin! block.hash:{}, block.height:{}, tx.hash:{}, serialized.size:{}, has.rlp:{}",
                 block.hash(), block.height(), tx.hash(), serializedTx.size(), !tx.rlp().empty());
        if (DBStatus::DB_SUCCESS != dbWriter.setTransactionByHash(tx.hash(), serializedTx))
        {
            ERRORLOG("setTransactionByHash error! tx.hash:{}, serialized.size:{}", tx.hash(), serializedTx.size());
            return -80;
        }
        ERRORLOG("SaveBlock transaction body success! tx.hash:{}", tx.hash());

        // Add block hash corresponding to transaction hash
        if (DBStatus::DB_SUCCESS != dbWriter.setBlockHashByTransactionHash(tx.hash(), block.hash()))
        {
            ERRORLOG("setBlockHashByTransactionHash error! tx.hash:{},block.hash:{}",tx.hash(),block.hash());
            return -81;
        }
    }

    if (block.version() == global::ca::kCurrentBlockVersion && isContractBlocked(block))
    {
        nlohmann::json blockData;
        try
        {
            blockData = nlohmann::json::parse(block.data());
        }
        catch (...)
        {
            ERRORLOG("parse blockData fail");
            return -82;
        }
        auto saveContractTx = [&](const std::map<std::string, CTransaction>& CTxs)
        {
            // 转换为时间戳排序的容器，确保与执行顺序一致
            // Convert to timestamp-sorted container to ensure consistent order with execution
            std::vector<std::pair<uint64_t, CTransaction>> tx_with_timestamp;
            for (const auto& item : CTxs)
            {
                tx_with_timestamp.emplace_back(item.second.time(), item.second);
            }
            std::sort(tx_with_timestamp.begin(), tx_with_timestamp.end(),
                      [](const auto& a, const auto& b) {
                          if (a.first != b.first) return a.first < b.first;
                          return a.second.hash() < b.second.hash();
                      });

            for (const auto& [timestamp, tx] : tx_with_timestamp)
            {
                global::ca::VmType vmType;
                std::string contractAddress;
                std::string CallType;
                try
                {
                    nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                    nlohmann::json _txInfo = dataJson["txInfo"].get<nlohmann::json>();
                    vmType = _txInfo[Evmone::contractVmKeyName].get<global::ca::VmType>();
                    contractAddress = _txInfo[Evmone::contractRecipientKeyNameStr].get<std::string>();
                }
                catch(...)
                {
                    ERRORLOG("parse TxInfo fail");
                    return -83;
                }
                if (global::ca::TxType::DEPLOY == (global::ca::TxType)tx.type())
                {
                                        //判断用其他类型的手续费的vin
                    for(const auto& utxo : tx.utxos())
                    {
                        for (auto &vin : utxo.vin())
                        {
                            //这里合约地址需不需要加类型 
                            const std::string deployerAddress = GenerateAddr(vin.vinsign().pub());
                            const std::string deployHash = tx.hash();
                            std::cout << "contractAddress: " << "0x"+contractAddress << std::endl;

                            nlohmann::json txInfo;
                            for (const auto&[key, value] : blockData.items())
                            {
                                if (key == deployHash)
                                {
                                    txInfo = value;
                                    break;
                                }
                            }

                            std::string runtimeCode = txInfo[Evmone::contractOutputKey].get<std::string>();

                            int saveResult = Evmone::SaveContract(deployerAddress, deployHash, contractAddress, runtimeCode,
                                                                dbWriter, vmType);
                            if (saveResult != 0)
                            {
                                ERRORLOG("SaveBlock SaveContract Error{}", saveResult);
                                return saveResult;
                            }

                            for(const auto& [contractCreatorAddr, code] : txInfo[Evmone::contractCreationKeyLabel].items())
                            {
                                if(contractCreatorAddr.empty())
                                {
                                    ERRORLOG("empty create internal contract address")
                                    return -99999;
                                }
                                DEBUGLOG("create internal contract at addr:{} \n code:{}", contractCreatorAddr, code);
                                saveResult = Evmone::SaveContract(deployerAddress, deployHash, contractCreatorAddr,
                                                                code, dbWriter, vmType);
                                if (saveResult != 0)
                                {
                                    ERRORLOG("SaveBlock SaveContract Error{}", saveResult);
                                    return saveResult;
                                }
                            }
                            for(auto &it : txInfo[Evmone::contractPreHashKey].items())
                            {
                                if(it.key() == "") continue;
                                std::string prevHashCache;
                                if (DBStatus::DB_SUCCESS != dbWriter.getLatestUtxoByContractAddr(it.key(), prevHashCache))
                                {
                                    return -84;
                                }

                                if(prevHashCache != it.value().get<std::string>())
                                {
                                    MagicSingleton<BlockHelper>::GetInstance()->pushMissUtxo(it.value());
                                    return -85;
                                }

                                if (DBStatus::DB_SUCCESS != dbWriter.setLatestUtxoByContractAddr(it.key(), deployHash))
                                {
                                    return -86;
                                }
                            }

                            for(const auto& it : txInfo[Evmone::contractDestructionKey].items())
                            {
                                if(it.key() == "") continue;
                                DEBUGLOG("removeContractDeployUtxoByContractAddr,addr:{}", it.key());
                                if (DBStatus::DB_SUCCESS != dbWriter.removeContractDeployUtxoByContractAddr(it.key()))
                                {
                                    return -87;
                                }
                                if (DBStatus::DB_SUCCESS != dbWriter.removeContractCodeByContractAddr(it.key()))
                                {
                                    return -88;
                                }
                            }

                            nlohmann::json storage = txInfo[Evmone::storageKeyForContract];
                            if(!storage.is_null())
                            {
                                for (auto it = storage.begin(); it != storage.end(); ++it)
                                {
                                    std::string strKey = it.key();
                                    if (strKey.substr(strKey.length() - 8 , strKey.length()) == "rootHash" || strKey.empty())
                                    {
                                        continue;
                                    }
                                    size_t pos = strKey.find('_');
                                    if(pos != std::string::npos)
                                    {
                                        strKey = contractAddress + strKey.substr(pos);
                                    }
                                    if (dbWriter.setMptValueByMptKey(strKey, it.value()) != DBStatus::DB_SUCCESS)
                                    {
                                        return -89;
                                    }
                                }
                            }


                            break;
                        }
                        
                        DEBUGLOG("TransactionConfirmed, tx hash: {}", tx.hash());
                        MagicSingleton<EventManager>::GetInstance()->Publish("TransactionConfirmed", tx.hash());
                    }    
                }
                else if (global::ca::TxType::CALL == (global::ca::TxType)tx.type())
                {
                    std::string deployerAddress;
                    for (const auto &utxo : tx.utxos())
                    {
                        for (auto &vin : utxo.vin())
                        {
                            deployerAddress = GenerateAddr(vin.vinsign().pub());
                        }
                    }
                            
                    const std::string deployHash = tx.hash();
                    nlohmann::json txInfo;
                    for (const auto&[key, value] : blockData.items()) {
                        if (key == tx.hash()) {
                            txInfo = value;
                            break;
                        }
                    }
                    DEBUGLOG("AAS txInfo: {}", txInfo.dump(4));
                    for (const auto&[contractCreatorAddr, code] : txInfo[Evmone::contractCreationKeyLabel].items()) {
                        if (contractCreatorAddr.empty()) {
                            ERRORLOG("empty create internal contract address")
                            return -99999;
                        }
                        DEBUGLOG("create internal contract at addr:{} \n code:{}", contractCreatorAddr, code);
                        int saveResult = Evmone::SaveContract(deployerAddress, deployHash, contractCreatorAddr,
                                                                code, dbWriter, vmType);
                        if (saveResult != 0) {
                            ERRORLOG("SaveContract Error{}", saveResult);
                            return saveResult;
                        }
                        
                    }

                    DEBUGLOG("blockHash:{}, txHash:{} \n txInfo:{}", block.hash().substr(0, 6),
                                tx.hash().substr(0, 6), txInfo[Evmone::contractPreHashKey].dump(4));
                    for (auto &it : txInfo[Evmone::contractPreHashKey].items())
                    {
                        std::string prevHashCache;
                        if (DBStatus::DB_SUCCESS !=
                            dbWriter.getLatestUtxoByContractAddr(it.key(), prevHashCache))
                        {
                            return -90;
                        }
                        DEBUGLOG("it.key:{}, it.value:{}, prevHashCache:{}", it.key(), it.value(), prevHashCache);
                        if (prevHashCache != it.value().get<std::string>())
                        {
                            MagicSingleton<BlockHelper>::GetInstance()->pushMissUtxo(it.value());
                            return -91;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.setLatestUtxoByContractAddr(it.key(), tx.hash()))
                        {
                            return -92;
                        }
                    }

                    for (const auto &it : txInfo[Evmone::contractDestructionKey].items())
                    {
                        if (it.key() == "")
                            continue;
                        DEBUGLOG("removeContractDeployUtxoByContractAddr,addr:{}", it.key());
                        if (DBStatus::DB_SUCCESS != dbWriter.removeContractDeployUtxoByContractAddr(it.key()))
                        {
                            return -93;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.removeContractCodeByContractAddr(it.key()))
                        {
                            return -94;
                        }
                    }
                    DEBUGLOG("txhash: {}", tx.hash());
                    DEBUGLOG("storageKeyForContract: {}", txInfo[Evmone::storageKeyForContract].dump());
                    nlohmann::json storage = txInfo[Evmone::storageKeyForContract];
                    if (!storage.is_null())
                    {
                        for (auto it = storage.begin(); it != storage.end(); ++it)
                        {
                            std::string strKey = it.key();
                            if (strKey.substr(strKey.length() - 8, strKey.length()) == "rootHash" ||
                                strKey.empty())
                            {
                                continue;
                            }
                            DEBUGLOG("setMptValueByMptKey - key: {}, value: {}", strKey, it.value().dump());
                            if (dbWriter.setMptValueByMptKey(strKey, it.value()) != DBStatus::DB_SUCCESS)
                            {
                                return -95;
                            }
                        }
                    }
                    DEBUGLOG("TransactionConfirmed, tx hash: {}", tx.hash());
                    MagicSingleton<EventManager>::GetInstance()->Publish("TransactionConfirmed", tx.hash());
                }
            }
            return 0;  
        };
        
        packDispatch _packdisTx;
        for(const auto& tx : block.txs())
        {
            auto& txHash = tx.hash();
            std::vector<std::string> dependentTxHashes;
            auto it = blockData.find(txHash);
            if (it != blockData.end() && it.value().contains("dependentCtx")) 
            {
                for (const auto& dependencyTransactionHashRequest : it.value()["dependentCtx"]) 
                {
                    dependentTxHashes.push_back(dependencyTransactionHashRequest.get<std::string>());
                }
            } 
            else 
            {
                ERRORLOG("blockData.find(txHash) error notFoundTx:{}", txHash);
                return -96;
            }

            _packdisTx.Add(txHash, dependentTxHashes, tx);
        }

        std::map<uint32_t, std::map<std::string, CTransaction>> dependentContractTxMap_;
        std::map<std::string, CTransaction> non_dependent_contract_tx_map;
        _packdisTx.GetDependentData(dependentContractTxMap_, non_dependent_contract_tx_map);

        for(const auto& dependent : dependentContractTxMap_)
        {
            DEBUGLOG("AAS dependent size: {}", dependent.second.size());
            DEBUGLOG("AAS dependent hash: {}", dependent.second.begin()->second.hash());
            auto ret = saveContractTx(dependent.second);
            if(ret != 0)
            {
                ERRORLOG("SaveBlock SaveContracTx Error {}", ret);
                return ret;
            }
        }
        if(!non_dependent_contract_tx_map.empty())
        {
            DEBUGLOG("AAS non_dependent_contract_tx_map size: {}", non_dependent_contract_tx_map.size());
            DEBUGLOG("AAS non_dependent_contract_tx_map hash: {}", non_dependent_contract_tx_map.begin()->second.hash());
            auto ret = saveContractTx(non_dependent_contract_tx_map);
            if(ret != 0)
            {
                ERRORLOG("SaveBlock SaveContracTx Error {}",ret);
                return ret;
            }
        }
    }

    int result = calculateHeightsSumHash(block.height(), dbWriter);
    if(result != 0)
    {
        ERRORLOG("SaveBlock calculateHeightsSumHash Error {}",result);
        return result - 10000;
    }

    for(auto &t:block.txs()){
        for(auto &u:t.utxos()){
            for(auto &vo:u.vout()){
                MagicSingleton<ohi::utils::AddressStatusCache>::GetInstance()->markExpired(vo.addr());
            }
        }
    }
    std::vector<uint64_t> rollBackheights;
    dbWriter.getRollbackBlockNum(rollBackheights);
    
    for(const auto &h:rollBackheights){
        if(h == block.height()){
             dbWriter.removeRollBackBlock(block.height(),blockRaw,false);
             std::vector<std::string> blocks_raw;
             dbWriter.getRollBackBlock(block.height(), blocks_raw);
             if(blocks_raw.empty()){
                dbWriter.setRollbackBlockNum(block.height(), false);
                dbWriter.removeRollBackBlock(block.height(), "", true);
            
            }
             
        }
    }

    // 区块保存成功后，触发上链率探测
    // 仅 SyncNormal 和 Broadcast 类型的区块进入探测流程
    // 如果区块时间已经超过当前时间5分钟，则不将该区块添加到探测队列
    if (saveType == global::ca::SaveType::SyncNormal || saveType == global::ca::SaveType::Broadcast)
    {
        uint64_t now = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
        uint64_t blockTime = block.time();
        // GetUTCTimestamp() 和 block.time() 的单位均为微秒，需转换为秒后比较
        uint64_t diffSeconds = (now > blockTime) ? ((now - blockTime) / 1000000ULL) : ((blockTime - now) / 1000000ULL);
        if (diffSeconds <= 300) // 5分钟 = 300秒
        {
            MagicSingleton<BlockRateProbe>::GetInstance()->AddBlock(block.hash());
        }
        else
        {
            DEBUGLOG("Block {} time diff {}s > 300s, skip block rate probe",
                     block.hash().substr(0, 8), diffSeconds);
        }
    }


    return 0;
}







int ca_algorithm::DeleteBlock(DBReadWriter &dbWriter, const std::string &blockHash)
{
    CBlock block;
    std::string blockRaw;
    auto ret = dbWriter.getBlockByBlockHash(blockHash, blockRaw);

    if (DBStatus::DB_NOT_FOUND == ret)
    {
        return 0;
    }
    else if (DBStatus::DB_SUCCESS != ret)
    {
        ERRORLOG("getBlockByBlockHash blockHash:{},blockRaw:{}",blockHash,blockRaw);
        return -1;
    }
    if (!block.ParseFromString(blockRaw))
    {
        ERRORLOG("ParseFromString error!");
        return -2;
    }

    // Judge the height of the block and whether to update the node height
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbWriter.getBlockTop(top))
    {
        ERRORLOG("getBlockTop error! top:{}",top);
        return -3;
    }
    if (block.height() == top)
    {
        std::vector<std::string> block_hashes_temp;
        if (DBStatus::DB_SUCCESS != dbWriter.getBlockHashsByBlockHeight(block.height(), block_hashes_temp)) //hash Get the hash of all blocks with the height of this block
        {
            ERRORLOG("getBlockHashsByBlockHeight  block.height:{}",block.height());
            return -4;
        }
        if (1 == block_hashes_temp.size())
        {
            if (DBStatus::DB_SUCCESS != dbWriter.setBlockTop(block.height() - 1))
            {
                return -5;
            }
        }
	}

    // Delete the height corresponding to the block hash
    if (DBStatus::DB_SUCCESS != dbWriter.removeBlockHeightByBlockHash(block.hash()))
    {
        ERRORLOG("removeBlockHeightByBlockHash block.hash:{}",block.hash());
        return -6;
    }

    // Delete block hash corresponding to height
    if (DBStatus::DB_SUCCESS != dbWriter.removeBlockHashByBlockHeight(block.height(), block.hash()))
    {
        ERRORLOG("removeBlockHashByBlockHeight block.height:{},block.hash:{}",block.height(),block.hash());
        return -7;
    }

    // Delete the block data corresponding to the block hash
    if (DBStatus::DB_SUCCESS != dbWriter.removeBlockByBlockHash(block.hash()))
    {
        ERRORLOG("removeBlockByBlockHash failed block.hash:{}",block.hash());
        return -8;
    }

    uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(block.time());
    for (auto &sign : block.signature())
    {
        std::string voutAddr = GenerateAddr(sign.pub());
        if (!isValidAddress(voutAddr))
        {
            return -9;
        }
        uint64_t signNumber = 0;
        if(DBStatus::DB_SUCCESS != dbWriter.getSignCountByPeriod(period, voutAddr, signNumber))
        {
            ERRORLOG("getSignCountByPeriod period:{},vout.addr:{},signNumber:{}",period, voutAddr, signNumber);
            return -10;
        }

        if(signNumber > 1)
        {
            --signNumber;
            if(DBStatus::DB_SUCCESS != dbWriter.setSignCountByPeriod(period, voutAddr, signNumber))
            {
                ERRORLOG("setSignCountByPeriod error! period:{},vout.addr:{},signNumber:{}",period, voutAddr, signNumber);
                return -11;
            }
        }
        else
        {
            if(DBStatus::DB_SUCCESS != dbWriter.removeSignAddrByPeriod(period, voutAddr))
            {
                ERRORLOG("removeSignAddrByPeriod error! period:{},vout.addr:{}",period,voutAddr);
                return -12;
            }
            if(DBStatus::DB_SUCCESS != dbWriter.removeSignCountByPeriod(period, voutAddr))
            {
                ERRORLOG("removeSignCountByPeriod error! period:{},vout.addr:{}",period,voutAddr);
                return -13;
            }
        }
    }

    {
        uint64_t blockNumber = 0;
        auto ret = dbWriter.getBlockNumberByPeriod(period,blockNumber);
        if(DBStatus::DB_SUCCESS != ret)
        {
            if(DBStatus::DB_NOT_FOUND == ret)
            {
                blockNumber = 0;
            }
            else
            {
                ERRORLOG("Get BLock Num Failed!");
                return -14;
            }
        }

        if(blockNumber > 1)
        {
            blockNumber -= 1;
            if(DBStatus::DB_SUCCESS != dbWriter.setBlockNumberByPeriod(period, blockNumber))
            {
                ERRORLOG("setBlockNumberByPeriod error! period:{},signNumber:{}",period,blockNumber);
                return -15;
            }
        }
        else
        {
            if(DBStatus::DB_SUCCESS != dbWriter.removeBlockNumberByPeriod(period))
            {
                ERRORLOG("removeBlockNumberByPeriod error! period:{},vout.addr:{}",period);
                return -16;
            }
        }


        uint64_t packageTimes = 0;
        ret = dbWriter.getPackagerCountByPeriod(period,GenerateAddr(block.signature(0).pub()),packageTimes);
        if(DBStatus::DB_SUCCESS != ret){
            if(DBStatus::DB_NOT_FOUND == ret)
            {
                packageTimes = 0;
            }else{
                ERRORLOG("Get BLock Num Failed!");
                return -99;
            }
        }

        if(packageTimes>=1){
            packageTimes -= 1;
            
            if(DBStatus::DB_SUCCESS != dbWriter.setPackagerCountByPeriod(period, GenerateAddr(block.signature(0).pub()),packageTimes))
            {
                ERRORLOG("setBlockNumberByPeriod error! period:{},signNumber:{}",period,packageTimes);
                return -98;
            }
        }
    }

    std::set<std::string> blockAddr; //   Currently, all transactions in the start processing block are removed
    std::set<std::string> allAddr;
    for (auto &tx : block.txs())
    {

        {   
            uint64_t nonce = 0;
            //nonce至少为1
            if(dbWriter.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS){
                ERRORLOG("get nonce failed!");
                return -110;
            }
            if(nonce >=1 ){nonce -=1;}else{ERRORLOG("nonce error!");}
            if(dbWriter.setNonceByAddr( tx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS){
                ERRORLOG("set nonce failed!");
                return -112;
            }
        }

        auto transactionType = GetTransactionType(tx);
        blockAddr.insert(allAddr.cbegin(), allAddr.cend());
        allAddr.clear();
        if (kTransactionTypeTx == transactionType)
        {
            bool isRedeem = false;
            bool isUnLock = false;
            std::string redeemUtxoHashValue;
            bool isUndelegating = false;
            std::string UndelegatingUtxoHash;
            if((global::ca::TxType)tx.type() != global::ca::TxType::TX)
            {
                try
                {
                    nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                    global::ca::TxType txType = (global::ca::TxType)tx.type();

                    {
                        uint64_t ltime;
                        uint64_t curTime =MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
                        auto stret=dbWriter.get30DayLockData(tx.utxos(0).owner(0),tx.hash(),tx.utxos(0).assettype(),ltime);
                        if (stret == DBStatus::DB_SUCCESS &&
                            (curTime - ltime) > 24 * 60 * 60 * 1000000 * 30) {
                          dbWriter.set30DayLockData(
                              tx.utxos(0).owner(0), tx.hash(),
                              tx.utxos(0).assettype(), 0, false);

                             
                        }
                    }

                    // The stake transaction updates the pledge address and the utxo of the pledge address
                    if (global::ca::TxType::STAKE == txType)
                    {
                        for(const auto &utxo : tx.utxos())
                        { 
                            if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                                continue;
                            }
                            for (auto &vin : utxo.vin())
                            {
                                std::string addr = GenerateAddr(vin.vinsign().pub());
                                if (!isValidAddress(addr))
                                {
                                    ERRORLOG("isValidAddress error! addr:{}",addr);
                                    return -17;
                                }
                                if (DBStatus::DB_SUCCESS != dbWriter.removeStakeUtxoByAddr(addr, utxo.assettype(), tx.hash()))
                                {
                                    ERRORLOG("removeStakeAddrUtxo error! addr:{},tx.hash:{}",addr,tx.hash());
                                    return -18;
                                }
                                std::vector<std::string> pledgeUtxoHashes;
                                auto ret = dbWriter.getStakeUtxoByAddr(addr, utxo.assettype(), pledgeUtxoHashes);
                                if (DBStatus::DB_NOT_FOUND == ret || pledgeUtxoHashes.empty())
                                {
                                    if (DBStatus::DB_SUCCESS != dbWriter.removeStakeAddr(addr))
                                    {
                                        ERRORLOG("removeStakeAddrUtxo error! ret:{}",ret);
                                        return -19;
                                    }
                                }
                                break;
                            }
                        }
                    }
                    else if(global::ca::TxType::LOCK == txType)
                    {
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        uint64_t lockAmount = txInfo["lockAmount"].get<uint64_t>();
                        
                        for(const auto &utxo : tx.utxos())
                        { 
                            if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                                continue;
                            }
                            for (auto &vin : utxo.vin())
                            {
                                std::string addr = GenerateAddr(vin.vinsign().pub());
                                if (!isValidAddress(addr))
                                {
                                    ERRORLOG("isValidAddress error! addr:{}",addr);
                                    return -77000;
                                }
                                std::lock_guard<std::mutex> lock(global::ca::LOCK_MUTEX);
                                if (DBStatus::DB_SUCCESS != dbWriter.removeLockAddrUtxo(addr, utxo.assettype() ,tx.hash()))
                                {
                                    ERRORLOG("removeLockAddrUtxo error! addr:{},tx.hash:{}",addr,tx.hash());
                                    return -77001;
                                }
                                std::vector<std::string> pledgeUtxoHashes;
                                auto ret = dbWriter.getLockAddrUtxo(addr, utxo.assettype(),pledgeUtxoHashes);
                                if (DBStatus::DB_NOT_FOUND == ret || pledgeUtxoHashes.empty())
                                {
                                    if (DBStatus::DB_SUCCESS != dbWriter.removeLockAddr(addr))
                                    {
                                        ERRORLOG("removeLockAddr error! ret:{}",ret);
                                        return -77002;
                                    }
                                }

                                uint64_t totalLockedAmount = 0;
                                ret = dbWriter.getTotalLockedAmonut(totalLockedAmount);
                                if(DBStatus::DB_SUCCESS != ret)
                                {
                                    ERRORLOG("getTotalLockedAmonut total locked amount:{}",totalLockedAmount);
                                    return -77003;
                                }

                                totalLockedAmount -= lockAmount;
                                if(DBStatus::DB_SUCCESS != dbWriter.setTotalLockedAmonut(totalLockedAmount))
                                {
                                    ERRORLOG("setTotalLockedAmonut error! total locked amount:{}",totalLockedAmount);
                                    return -77004;
                                }



                                {
                                    uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                                    uint64_t _LockedAmount = 0;
                                    ret = dbWriter.getTotalLockedAmountByPeriod(period, _LockedAmount); 
                                    if(ret != DBStatus::DB_SUCCESS){
                                        ERRORLOG("get total locked amount by period fail!");
                                        return -77004;
                                    }
                                    _LockedAmount -= lockAmount;
                                    ret = dbWriter.setTotalLockedAmonutByPeriod(period, _LockedAmount);
                                    if(ret != DBStatus::DB_SUCCESS){
                                        ERRORLOG("set total locked amount by period fail!");
                                        return -77005;
                                    }
                                }

                                break;
                            }
                        }
                    }
                    // The redeem transaction, update the pledge address and the utxo of the pledge address
                    else if (global::ca::TxType::UNSTAKE == txType)
                    {
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        isRedeem = true;
                        redeemUtxoHashValue =
                            txInfo["unstakeUtxo"].get<std::string>();
                        uint64_t utxoTime;
                        if (dbWriter.set30DayLockData(tx.utxos(0).owner(0),
                                                      tx.hash(),tx.utxos(0).assettype(), utxoTime,true) !=
                            DBStatus::DB_SUCCESS) {
                          ERRORLOG("utxoHash:{} utxoTime:{}", tx.hash(),
                                   utxoTime);
                          return -19;
                        } 



                      
                        for(const auto &utxo : tx.utxos())
                        {   
                            if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                                continue;
                            }
                            for (auto &vin : utxo.vin())
                            {
                                std::string addr = GenerateAddr(vin.vinsign().pub());
                                if (!isValidAddress(addr))
                                {
                                    ERRORLOG("isValidAddress error! addr:{}",addr);
                                    return -20;
                                }
                                if (DBStatus::DB_SUCCESS != dbWriter.setStakeUtxoByAddr(addr, utxo.assettype(), redeemUtxoHashValue))
                                {
                                    ERRORLOG("setStakeAddrUtxo addr:{},utxoHash:{}",addr,redeemUtxoHashValue);
                                    return -21;
                                }
                                std::vector<std::string> addressListForPledge;
                                auto ret = dbWriter.getStakeAddr(addressListForPledge);
                                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                                {
                                    ERRORLOG("getStakeAddr error! ret:{}",ret);
                                    return -22;
                                }
                                if (addressListForPledge.cend() == std::find(addressListForPledge.cbegin(), addressListForPledge.cend(), addr))
                                {
                                    if (DBStatus::DB_SUCCESS != dbWriter.setStakeAddr(addr))
                                    {
                                        ERRORLOG("setStakeAddr error! can't find addr from addressListForPledge addr:{}",addr);
                                        return -23;
                                    }
                                }
                                break;
                            }
                        }
                    }
                    else if (global::ca::TxType::UNLOCK == txType)
                    {
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        isUnLock = true;
                        redeemUtxoHashValue =
                            txInfo["unLockUtxo"].get<std::string>();
                          for (const auto &utxo : tx.utxos()) {   
                            if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                                continue;
                            }
                            for (auto &vin : utxo.vin())
                            {
                                std::string addr = GenerateAddr(vin.vinsign().pub());
                                if (!isValidAddress(addr))
                                {
                                    ERRORLOG("isValidAddress error! addr:{}",addr);
                                    return -77003;
                                }
                                if (DBStatus::DB_SUCCESS != dbWriter.setLockAddrUtxo(addr, utxo.assettype() ,redeemUtxoHashValue))
                                {
                                    ERRORLOG("setLockAddrUtxo addr:{},utxoHash:{}",addr,redeemUtxoHashValue);
                                    return -77004;
                                }
                                std::vector<std::string> addressListForPledge;
                                auto ret = dbWriter.getLockAddr(addressListForPledge);
                                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                                {
                                    ERRORLOG("getLockAddr error! ret:{}",ret);
                                    return -77005;
                                }
                                if (addressListForPledge.cend() == std::find(addressListForPledge.cbegin(), addressListForPledge.cend(), addr))
                                {
                                    if (DBStatus::DB_SUCCESS != dbWriter.setLockAddr(addr))
                                    {
                                        ERRORLOG("setLockAddr error! can't find addr from addressListForPledge addr:{}",addr);
                                        return -77006;
                                    }
                                }
                                break;
                            }
                        }


                        uint64_t lockedAmount = 0;
                        std::string strTx;
                        if (dbWriter.getTransactionByHash(redeemUtxoHashValue, strTx) != DBStatus::DB_SUCCESS)
                        {
                            MagicSingleton<BlockHelper>::GetInstance()->pushMissUtxo(redeemUtxoHashValue);
                            ERRORLOG("getTransactionByHash error! unlockUtxoHash:{},strTx:{}",redeemUtxoHashValue, strTx);
                            return -47;
                        }
                        CTransaction unlockTx;
                        if(!unlockTx.ParseFromString(strTx))
                        {
                            ERRORLOG("unlockTx.ParseFromString(strTx) = {} ",strTx);
                            return -48;
                        }

                        for(const auto & utxo : unlockTx.utxos())
                        {
                            for (int i = 0; i < utxo.vout_size(); i++)
                            {
                                if (utxo.vout(i).addr() == global::ca::VIRTUAL_LOCK_ADDRESS)
                                {
                                    lockedAmount += utxo.vout(i).value();
                                    break;
                                }
                            }
                        }

                        uint64_t totalLocked = 0;
                        if(DBStatus::DB_SUCCESS != dbWriter.getTotalLockedAmonut(totalLocked))
                        {
                            ERRORLOG("getTotalDelegatingAmount error! totalLocked:{}",totalLocked);
                            return -50;
                        }
                        totalLocked+=lockedAmount;
                        if(DBStatus::DB_SUCCESS != dbWriter.setTotalLockedAmonut(totalLocked))
                        {
                            ERRORLOG("setTotalDelegatingAmount error! totalLocked:{}",totalLocked);
                            return -51;
                        }

                        {
                            uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                            uint64_t periodLocked = 0;
                            auto _ret = dbWriter.getTotalLockedAmountByPeriod(period, periodLocked);
                            if(_ret != DBStatus::DB_SUCCESS && _ret != DBStatus::DB_NOT_FOUND){
                                ERRORLOG("get total locked amount by period fail!");
                                return -52;
                            }
                            periodLocked += lockedAmount;
                            if(dbWriter.setTotalLockedAmonutByPeriod(period, periodLocked) != DBStatus::DB_SUCCESS){
                                ERRORLOG("set total locked amount by period fail!");
                                return -53;
                            }
                        }
                        }
                    // The Delegating transaction updates the Delegating address and the utxo of the Delegating address
                    else if (global::ca::TxType::DELEGATE == txType)
                    {
                        uint64_t delegateAmount = 0; 
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        std::string delegatingNode = txInfo["bonusAddr"].get<std::string>();
                        txInfo["delegateAmount"].get_to(delegateAmount);
                        for(const auto &utxo : tx.utxos())
                        {   
                            if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                                continue;
                            }
                            std::string currency = utxo.assettype();
                            for (auto &vin : utxo.vin())
                            {
                                std::string addr = GenerateAddr(vin.vinsign().pub());

                                MagicSingleton<ohi::ca::BonusAddrCache>::GetInstance()->isDirty(delegatingNode);
                                if (DBStatus::DB_SUCCESS != dbWriter.removeDelegatingAddrUtxoByBonusAddr(delegatingNode, addr, currency, tx.hash()))
                                {
                                    ERRORLOG("removeDelegatingAddrUtxoByBonusAddr error delegatingNode:{},addr:{},tx.hash:{}",delegatingNode, addr, tx.hash());
                                    return -24;
                                }
                                std::vector<std::string> utxos;
                                if (dbWriter.getDelegatingAddrUtxoByBonusAddr(delegatingNode, addr, currency, utxos) == DBStatus::DB_NOT_FOUND || utxos.empty())
                                {
                                    if (DBStatus::DB_SUCCESS != dbWriter.removeDelegatingAddrAndAssetTypeByBonusAddr(delegatingNode, addr, currency))
                                    {
                                        ERRORLOG("removeDelegatingAddrAndAssetTypeByBonusAddr error! delegatingNode:{},addr:{}",delegatingNode,addr);
                                        return -25;
                                    }

                                    if (DBStatus::DB_SUCCESS != dbWriter.removeBonusAddrAndAssetTypeByDelegatingAddr(addr, delegatingNode, currency))
                                    {
                                        ERRORLOG("removeBonusAddrAndAssetTypeByDelegatingAddr addr:{},delegatingNode:{}, assetType:{}",addr, delegatingNode, currency);
                                        return -27;
                                    }
                                }
                                break;
                            }
                        }
                        uint64_t totaldelegating = 0;
                        std::vector<std::string> utxos;
                        {
                            std::lock_guard<std::mutex> lock(global::ca::kDelegatingMutex);
                            uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                            auto ret = dbWriter.getDelegatingUtxoByPeriod(period, utxos);
                            if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                            {
                                return -28;
                            }
                            if (utxos.cend() != std::find(utxos.cbegin(), utxos.cend(), tx.hash()))
                            {
                                if(DBStatus::DB_SUCCESS != dbWriter.getTotalDelegatingAmount(totaldelegating))
                                {
                                    ERRORLOG("getTotalDelegatingAmount Totalinves:{}",totaldelegating);
                                    return -29;
                                }
                                totaldelegating-=delegateAmount;
                                if(DBStatus::DB_SUCCESS != dbWriter.setTotalDelegatingAmount(totaldelegating))
                                {
                                    ERRORLOG("setTotalDelegatingAmount error! totaldelegating:{}",totaldelegating);
                                    return -30;
                                }
                                uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                                if(DBStatus::DB_SUCCESS != dbWriter.removeDelegatingUtxoByPeriod(period, tx.hash()))
                                {
                                    ERRORLOG("removeDelegatingUtxoByPeriod error! period:{},tx.hash:{}",period,tx.hash());
                                    return -31;
                                }
                            }
                        }
                    }
                    // The Undelegatingment transaction updates the investment address and the utxo of the investment address
                    else if(global::ca::TxType::UNDELEGATE == txType)
                    {
                        isUndelegating = true;
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        UndelegatingUtxoHash = txInfo["undelegatingUtxo"].get<std::string>();
                        std::string delegatingedNode = txInfo["bonusAddr"].get<std::string>();
                        uint64_t utxoTime;

                        if(DBStatus::DB_SUCCESS != dbWriter.set30DayLockData(tx.utxos(0).owner(0),
                                                      tx.hash(),
                                                      tx.utxos(0).assettype(),
                                                      tx.time(),true)){
                                                            ERRORLOG("not set undelegate utxo {}",tx.hash());
                                                      }


                       

                        for(const auto & utxo : tx.utxos())
                        {
                            if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                                continue;
                            }
                            std::string currency = utxo.assettype();
                            for (auto &vin : utxo.vin())
                            {
                                std::string addr = GenerateAddr(vin.vinsign().pub());
                                if (!isValidAddress(addr))
                                {
                                    return -34;
                                }
                                
                                MagicSingleton<ohi::ca::BonusAddrCache>::GetInstance()->isDirty(delegatingedNode);
                                if (DBStatus::DB_SUCCESS != dbWriter.setDelegatingAddrUtxoByBonusAddr(delegatingedNode, addr, currency, UndelegatingUtxoHash))
                                {
                                    return -35;
                                }
                                
                                std::multimap<std::string, std::string> delegatingAddr_currency;
                                ret = dbWriter.getDelegatingAddrAndAssetTypeByBonusAddr(delegatingedNode, delegatingAddr_currency);
                                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                                {
                                    ERRORLOG("getDelegatingAddrAndAssetTypeByBonusAddr ret:{}",ret);
                                    return -36;
                                }

                                auto it = find_if(delegatingAddr_currency.begin(), delegatingAddr_currency.end(), 
                                                    [&](const std::pair<std::string, std::string>& p){
                                                    return p.first == addr && p.second == currency;  
                                                    });
                                if(it == delegatingAddr_currency.end())
                                {
                                    if (DBStatus::DB_SUCCESS != dbWriter.setDelegatingAddrAndAssetTypeByBonusAddr(delegatingedNode, addr, currency))
                                    {
                                        ERRORLOG("can't find addr from delegatingAddrs addr:{}",addr);
                                        return -37;
                                    }
                                }

                                std::multimap<std::string, std::string> bonusAddr_assetType;
                                ret = dbWriter.getBonusAddrAndAssetTypeByDelegatingAddr(addr, bonusAddr_assetType);
                                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                                {
                                    return -38;
                                }

                                auto find_iter = std::find_if(bonusAddr_assetType.begin(), bonusAddr_assetType.end(), [&delegatingedNode, &currency](const auto & p){return p.first == delegatingedNode && p.second == currency;});
                                if (find_iter == bonusAddr_assetType.end())
                                {
                                    if (DBStatus::DB_SUCCESS != dbWriter.setBonusAddrAndAssetTypeByDelegatingAddr(addr, delegatingedNode,currency))
                                    {
                                        return -39;
                                    }
                                }
                                break;
                            }

                        }
                        uint64_t delegateAmount = 0;
                        std::string strTx;
                        if (dbWriter.getTransactionByHash(UndelegatingUtxoHash, strTx) != DBStatus::DB_SUCCESS)
                        {
                            return -40;
                        }
                        CTransaction tnvestTx;
                        if(!tnvestTx.ParseFromString(strTx))
                        {
                            return -41;
                        }

                        for(const auto & tnvestTxUtxo : tnvestTx.utxos())
                        {
                            for (int i = 0; i < tnvestTxUtxo.vout_size(); i++)
                            {
                                if (tnvestTxUtxo.vout(i).addr() == global::ca::kVirtualDelegatingAddr)
                                {
                                    delegateAmount += tnvestTxUtxo.vout(i).value();
                                    break;
                                }
                            }
                        }
             
                        uint64_t totaldelegating = 0;
                        std::vector<std::string> utxos;
                        {
                            std::lock_guard<std::mutex> lock(global::ca::kDelegatingMutex);
                            uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tnvestTx.time());
                            auto ret = dbWriter.getDelegatingUtxoByPeriod(period, utxos);
                            if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                            {
                                return -42;
                            }
                            if (utxos.cend() == std::find(utxos.cbegin(), utxos.cend(), UndelegatingUtxoHash))
                            {
                                if(DBStatus::DB_SUCCESS != dbWriter.getTotalDelegatingAmount(totaldelegating))
                                {
                                    return -43;
                                }
                                totaldelegating+=delegateAmount;
                                if(DBStatus::DB_SUCCESS != dbWriter.setTotalDelegatingAmount(totaldelegating))
                                {
                                    return -44;
                                }
                                uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tnvestTx.time());
                                if (DBStatus::DB_SUCCESS != dbWriter.setDelegatingUtxoByPeriod(period, UndelegatingUtxoHash))
                                {
                                    return -45;
                                }
                            }
                        }
                    }
                    else if(global::ca::TxType::BONUS == txType)
                    {
                        uint64_t claimAmount=0;
                        std::vector<std::string> utxos;
                        
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        txInfo["bonusAmount"].get_to(claimAmount);
                        {
                            std::lock_guard<std::mutex> lock(global::ca::bonusMutex);
                            uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                            auto ret = dbWriter.getBonusUtxoByPeriod(period, utxos);
                            if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                            {
                                return -46;
                            }
                            if (utxos.cend() != std::find(utxos.cbegin(), utxos.cend(), tx.hash()))
                            {
                                uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                                if(DBStatus::DB_SUCCESS != dbWriter.removeBonusUtxoByPeriod(period, tx.hash()))
                                {
                                    return -49;
                                }
                            }

                            uint64_t totalCirculation = 0;

                            if(DBStatus::DB_SUCCESS != dbWriter.getTotalCirculation(totalCirculation))
                            {
                                ERRORLOG("getTotalCirculation error!");
                                return -55;
                            }

                            if(claimAmount > totalCirculation)
                            {
                                ERRORLOG("claimAmount:{} is greater than totalCirculation:{}",claimAmount,totalCirculation);
                                return -56;
                            }

                            totalCirculation -= claimAmount;
                            if (global::ca::VOTE_CIRCULATION >
                                totalCirculation + claimAmount){
                              if (DBStatus::DB_SUCCESS !=
                                  dbWriter.setTotalCirculation(
                                      totalCirculation)) {
                                ERRORLOG("setTotalCirculation error! amount:{} , total circulation:{}",claimAmount,totalCirculation);
                                return -57;
                              }
                            }

                        }
                        
                    }
                    else if(txType == global::ca::TxType::FUND)
                    {
                        std::vector<std::string> utxos;
                        uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                        auto ret = dbWriter.getFundUtxoByPeriod(period, utxos);
                        if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                        {
                            return -46;
                        }

                        if (utxos.cend() != std::find(utxos.cbegin(), utxos.cend(), tx.hash()))
                        {
                            uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                            if(DBStatus::DB_SUCCESS != dbWriter.removeFundUtxoByPeriod(period, tx.hash()))
                            {
                                return -49;
                            }
                        }
                    }
                    else if(txType == global::ca::TxType::CALL)
                    {
                    }
                    else if(global::ca::TxType::DECLARATION == txType)
                    {

                    }
                    else if(txType == global::ca::TxType::EVIDENCE)
                    {
                        // Reverse EVIDENCE transaction
                        nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                        std::string targetAddr = dataJson.value("target_addr", "");
                        std::string violationType = dataJson.value("violation_type", "");
                        std::string evidenceHash = dataJson.value("evidence_hash", "");

                        if (!evidenceHash.empty())
                        {
                            dbWriter.removeEvidenceOnChain(evidenceHash);
                        }
                        if (!targetAddr.empty() && !violationType.empty())
                        {
                            int64_t count = 0;
                            dbWriter.getEvidenceCount(targetAddr, violationType, count);
                            if (count > 0)
                            {
                                count -= 1;
                                if (count == 0)
                                {
                                    dbWriter.removeEvidenceCount(targetAddr, violationType);
                                }
                                else
                                {
                                    dbWriter.setEvidenceCount(targetAddr, violationType, count);
                                }
                            }
                            // Remove from threshold if below threshold
                            uint32_t threshold = (violationType == "DOUBLE_SIGN_VRF" || violationType == "DOUBLE_SIGN_BLOCK")
                                ? global::ca::kPunishmentThresholdL4
                                : global::ca::kPunishmentThresholdL3;
                            if (static_cast<uint32_t>(count) < threshold)
                            {
                                dbWriter.removeFromThresholdExceeded(targetAddr);
                            }
                        }
                    }
                    else if(txType == global::ca::TxType::PUNISHMENT)
                    {
                        // Reverse PUNISHMENT transaction
                        nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                        std::string targetAddr = dataJson.value("target_addr", "");
                        uint32_t penaltyLevel = dataJson.value("penalty_level", 0);
                        std::string violationType = dataJson.value("violation_type", "");
                        std::string evidenceRefs = dataJson.value("evidence_refs", "");
                        std::string punishmentId = dataJson.value("punishment_id", "");
                        std::vector<std::string> stakeRefs = dataJson.value("stake_refs", std::vector<std::string>{});
                        if (punishmentId.empty())
                        {
                            punishmentId = ca_algorithm::BuildSlashPunishmentId(targetAddr, violationType, penaltyLevel, evidenceRefs);
                        }

                        if (!targetAddr.empty())
                        {
                            dbWriter.removePunishmentHistory(punishmentId, targetAddr);

                            int64_t totalStake = 0;
                            for (const auto& stakeRef : stakeRefs)
                            {
                                std::string stakeRaw;
                                if (DBStatus::DB_SUCCESS != dbWriter.getTransactionByHash(stakeRef, stakeRaw))
                                {
                                    continue;
                                }
                                CTransaction stakeTx;
                                if (!stakeTx.ParseFromString(stakeRaw))
                                {
                                    continue;
                                }
                                for (const auto& utxo : stakeTx.utxos())
                                {
                                    for (const auto& vout : utxo.vout())
                                    {
                                        if (vout.addr() == global::ca::kTargetAddress)
                                        {
                                            totalStake += vout.value();
                                            break;
                                        }
                                    }
                                }
                            }

                            bool l3CascadeToL4 = false;
                            if (penaltyLevel == 3)
                            {
                                uint32_t slashCount = 0;
                                if (DBStatus::DB_SUCCESS == dbWriter.getL3SlashCount(targetAddr, slashCount) && slashCount > 0)
                                {
                                    double slashRate = global::ca::kSlashRateFirst;
                                    if (slashCount == 2) slashRate = global::ca::kSlashRateSecond;
                                    else if (slashCount >= 3) slashRate = global::ca::kSlashRateThird;

                                    int64_t slashAmount = static_cast<int64_t>(totalStake * slashRate);
                                    l3CascadeToL4 = (totalStake - slashAmount) < static_cast<int64_t>(global::ca::MIN_STAKE_AMOUNT);

                                    if (slashCount == 1)
                                    {
                                        dbWriter.removeL3SlashCount(targetAddr);
                                    }
                                    else
                                    {
                                        dbWriter.setL3SlashCount(targetAddr, slashCount - 1);
                                    }
                                }
                            }

                            std::string remainingUtxoHash = tx.hash() + "_remaining";
                            dbWriter.removeStakeUtxoByAddr(targetAddr, "OHI", remainingUtxoHash);
                            dbWriter.removeUtxoValueByUtxoHashes(remainingUtxoHash, targetAddr, "OHI", "");
                            dbWriter.removeTransactionByHash(remainingUtxoHash);

                            for (const auto& stakeRef : stakeRefs)
                            {
                                if (!stakeRef.empty())
                                {
                                    dbWriter.setStakeUtxoByAddr(targetAddr, "OHI", stakeRef);
                                }
                            }
                            if (!stakeRefs.empty())
                            {
                                dbWriter.setStakeAddr(targetAddr);
                            }

                            if (penaltyLevel == 4 || l3CascadeToL4)
                            {
                                dbWriter.removeTombstoned(targetAddr);
                                INFOLOG("[SLASH] L4 rollback: tombstone removed for addr:{}", targetAddr);
                            }

                            std::string refundSnapshot;
                            if (DBStatus::DB_SUCCESS == dbWriter.getPunishmentDelegationRefunds(punishmentId, refundSnapshot))
                            {
                                try
                                {
                                    auto refunds = nlohmann::json::parse(refundSnapshot);
                                    for (const auto& item : refunds)
                                    {
                                        const std::string delegatorAddr = item.value("delegator_addr", "");
                                        const std::string assetType = item.value("asset_type", "");
                                        const std::string delegatingUtxo = item.value("delegating_utxo", "");
                                        const std::string refundUtxo = item.value("refund_utxo", "");
                                        const int64_t amount = item.value("amount", 0);
                                        if (delegatorAddr.empty() || assetType.empty() || delegatingUtxo.empty() || refundUtxo.empty())
                                        {
                                            continue;
                                        }

                                        dbWriter.removeUtxoHashesByAddr(delegatorAddr, assetType, refundUtxo);
                                        dbWriter.removeUtxoValueByUtxoHashes(refundUtxo, delegatorAddr, assetType, "");

                                        int64_t balance = 0;
                                        dbWriter.getBalanceByAddr(delegatorAddr, assetType, balance);
                                        if (balance <= amount)
                                        {
                                            dbWriter.removeBalanceByAddr(delegatorAddr, assetType);
                                        }
                                        else
                                        {
                                            dbWriter.setBalanceByAddr(delegatorAddr, assetType, balance - amount);
                                        }

                                        dbWriter.setDelegatingAddrUtxoByBonusAddr(targetAddr, delegatorAddr, assetType, delegatingUtxo);
                                        dbWriter.setDelegatingAddrAndAssetTypeByBonusAddr(targetAddr, delegatorAddr, assetType);
                                    }
                                }
                                catch (...)
                                {
                                    ERRORLOG("[SLASH] Failed to parse punishment delegation refund snapshot, punishment_id:{}", punishmentId);
                                }
                                dbWriter.removePunishmentDelegationRefunds(punishmentId);
                            }

                            if (!violationType.empty() && !evidenceRefs.empty())
                            {
                                dbWriter.addToThresholdExceeded(targetAddr, std::to_string(penaltyLevel), violationType, evidenceRefs);
                                uint32_t threshold = (violationType == "DOUBLE_SIGN_VRF" || violationType == "DOUBLE_SIGN_BLOCK")
                                    ? global::ca::kPunishmentThresholdL4
                                    : global::ca::kPunishmentThresholdL3;
                                int64_t count = 0;
                                dbWriter.getEvidenceCount(targetAddr, violationType, count);
                                if (count < static_cast<int64_t>(threshold))
                                {
                                    dbWriter.setEvidenceCount(targetAddr, violationType, threshold);
                                }
                            }
                        }
                    }
                    else if(global::ca::TxType::PROPOSAL == txType)
                    {
                        // 确定此提案使用的资产类型key：第一笔提案用assetType_MM，后续用tx.hash()
                        std::vector<std::string> currentAssertTypes;
                        dbWriter.getAssetType(currentAssertTypes);
                        std::string assetTypeKey = tx.hash();
                        if (std::find(currentAssertTypes.begin(), currentAssertTypes.end(), tx.hash()) == currentAssertTypes.end())
                        {
                            // tx.hash()不在资产类型列表中，说明这是第一笔提案，使用了assetType_MM
                            assetTypeKey = global::ca::ASSET_TYPE_OHI;
                        }

                        if (DBStatus::DB_SUCCESS != dbWriter.removeAssetType(assetTypeKey))
                        {
                            ERRORLOG("removeAssetType error:{}",assetTypeKey);
                            return -77006;
                        }
                        uint64_t approveNum, againstNum;
                        int rt = ca_algorithm::GetVoteNum(dbWriter, assetTypeKey, approveNum, againstNum);
                        if(rt != 0)
                        {
                            ERRORLOG("GetVoteNum error:{}",rt);
                            return -77007;
                        }
                        if (0 != approveNum && 0 != againstNum)
                        {
                            ERRORLOG("approveNum againstNum:{}",approveNum, againstNum);
                            return -77008;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.removeVoteCountByAssetType(assetTypeKey))
                        {
                            ERRORLOG("removeVoteCountByAssetType error:{}",assetTypeKey);
                            return -77009;
                        }
                        if(DBStatus::DB_SUCCESS != dbWriter.removeProposalInfoByAssetType(assetTypeKey))
                        {
                            ERRORLOG("removeProposalInfoByAssetType error");
                            return -77010;
                        }
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        std::string contractAddr = txInfo["tokenContractAddr"].get<std::string>();
                        if(DBStatus::DB_SUCCESS != dbWriter.removeAssetTypeByContractAddr(contractAddr))
                        {
                            ERRORLOG("setAssetTypeByContractAddr error");
                            return -77020;
                        }
                    }
                    else if(txType == global::ca::TxType::REVOKEPROPOSAL) 
                    {
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        std::string proposalHash = txInfo["proposalHash"].get<std::string>();
                        if (DBStatus::DB_SUCCESS != dbWriter.removeRevokeProposalInfoByAssetType(tx.hash()))
                        {
                            ERRORLOG("removeRevokeProposalInfoByAssetType error");
                            return -77011;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.removeRevokeTxHashByAssetType(proposalHash, tx.hash()))
                        {
                            ERRORLOG("setRevokeTxHashByAssetType error");
                            return -77012;
                        }
                        uint64_t approveNum, againstNum;
                        int rt = ca_algorithm::GetVoteNum(dbWriter, tx.hash(), approveNum, againstNum);
                        if(rt != 0)
                        {
                            ERRORLOG("GetVoteNum error:{}",rt);
                            return -77013;
                        }
                        if (0 != approveNum && 0 != againstNum)
                        {
                            ERRORLOG("approveNum againstNum:{}",approveNum, againstNum);
                            return -77014;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.removeVoteCountByAssetType(tx.hash()))
                        {
                            ERRORLOG("removeVoteCountByAssetType error:{}",tx.hash());
                            return -77015;
                        }
                    }
                    else if (global::ca::TxType::VOTE == txType) 
                    {
                        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                        std::string voteHash = txInfo["voteHash"].get<std::string>();
                        int pollType = txInfo["voteType"].get<int>();
                        uint64_t voteNumber = txInfo["voteNumber"].get<std::uint64_t>();

                        for(const auto &_utxo : tx.utxos())
                        {
                            std::cout << "save owner: " << "0x"+_utxo.owner(0) << std::endl;
                            int ret = ca_algorithm::subVoteNum(dbWriter, voteHash, pollType, _utxo.owner(0), voteNumber);
                            if(ret != 0)
                            {
                                ERRORLOG("subVoteNum error: {}", ret);
                                return -77016;
                            }
                            break;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.removeVoteTxHashByAssetType(voteHash, tx.hash()))
                        {
                            ERRORLOG("removeVoteTxHashByAssetType error:{}", tx.hash());
                            return -77017;
                        }
                    }
                }
                catch (...)
                {
                    return -53;
                }
            }

            for(const auto &utxo : tx.utxos())
            {
                std::string addr;
                std::string utxoHash;
                CTransaction utxoTx;
                std::string utxoTransactionRawData;
                std::vector<std::string> vin_hash_values;
                std::string utxoN;

                std::string currency = utxo.assettype();
                for (auto &vin : utxo.vin())
                {
                    
                    global::ca::TxType txType = (global::ca::TxType)tx.type();
                    
                    std::string addr;
                    if(vin.contractaddr().empty())
                    {
                        if (vin.vinsign().pub().size() == 0)
                        {
                            return -54;
                        }
                        if(!tx.rlp().empty()){
                            ethVerify::EthTransaction ethTx;
                            dev::bytes rlpBytes = dev::fromHex(tx.rlp());
                            eth_errors e;
                            int ret_E = ethVerify::verifyRLP(rlpBytes,e,&ethTx);
                            if(ret_E != 0){
                                ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
                                return ret_E;
                            }
                            addr = ethTx.from;
                        }else{addr = GenerateAddr(vin.vinsign().pub());}
                    }
                    else if(global::ca::TxType::DEPLOY == txType || global::ca::TxType::CALL == txType)
                    {
                        if (vin.vinsign().pub().size() != 0)
                        {
                            return -55;
                        }
                        addr = vin.contractaddr();
                    }

                    allAddr.insert(addr); 

                    for (auto & prevout : vin.prevout())
                    {
                        utxoHash = prevout.hash();
                        utxoN = utxoHash + "_" + addr + "_" +std::to_string(prevout.n());
                        if (isUnLock && redeemUtxoHashValue == utxoHash && 1 == prevout.n())
                        {
                            continue;
                        }
                        if (isRedeem && redeemUtxoHashValue == utxoHash && 1 == prevout.n())
                        {
                            continue;
                        }
                        else if (isUndelegating && UndelegatingUtxoHash == utxoHash && 1 == prevout.n())
                        {
                            continue;
                        }  

                        if (vin_hash_values.cend() != std::find(vin_hash_values.cbegin(), vin_hash_values.cend(), utxoN))
                        {
                            continue;
                        }
                        vin_hash_values.push_back(utxoN); 
                        // All transactions update the utxo used and the balance of utxo used by the transaction address
                        if (DBStatus::DB_SUCCESS != dbWriter.setUtxoHashesByAddr(addr, currency, utxoHash))
                        {
                            return -56;
                        }
                        
                        if (DBStatus::DB_SUCCESS != dbWriter.getTransactionByHash(utxoHash, utxoTransactionRawData))
                        {
                            return -57;
                        }
                        if (!utxoTx.ParseFromString(utxoTransactionRawData))
                        {
                            return -58;
                        }

                        uint64_t amount = 0;
                        for(const auto& utxoTx_utxo : utxoTx.utxos())
                        {
                            for (int j = 0; j < utxoTx_utxo.vout_size(); j++)
                            {
                                const CTxOutput & txout = utxoTx_utxo.vout(j);
                                //同类型资产才Set  区分类型资产 
                                if (txout.addr() == addr && utxoTx_utxo.assettype() == currency)
                                {
                                    amount += txout.value();
                                }
                                
                            }
                        }

                        ret = dbWriter.setUtxoValueByUtxoHashes(utxoHash, addr, currency, std::to_string(amount));
                        if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                        {
                            ERRORLOG("setUtxoHashesByAddr error! ret:{}",ret);
                            return -59;
                        }
                        
                        int64_t balance = 0;
                        ret = dbWriter.getBalanceByAddr(addr, currency, balance);
                        if (DBStatus::DB_SUCCESS != ret)
                        {
                            if (DBStatus::DB_NOT_FOUND != ret)
                            {
                                return -60;
                            }
                            else
                            {
                                balance = 0;
                            }
                        }
                        balance += amount;
                        if (balance < 0)
                        {
                            ERRORLOG("DeleteBlock vin height:{} hash:{} addr:{} balance:{}", block.height(), block.hash(), addr, balance);
                            return -61;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.setBalanceByAddr(addr, currency, balance))
                        {
                            return -62;
                        }
                    }
                }
            }
        }

        bool falg = false;
        for(const auto &utxo : tx.utxos())
        {   
            // All transactions delete utxo and the balance of utxo used by the transaction address
            // std::multimap<std::string,std::string> utxoValue;
            std::multimap<std::string,std::string> bonusUtxoValue;
            std::multimap<std::string,std::string> fundUtxoValue;
            std::map<std::string,std::multimap<std::string,std::string>> ContractUtxoValue;
            std::string currency = utxo.assettype();

            for(const auto & vout : utxo.vout())
            {
                if(vout.addr() == global::ca::VIRTUAL_BURN_GAS_ADDR || vout.addr() == global::ca::kVirtualDeploymentContractAddress || vout.addr() == global::ca::VIRTUAL_CALL_CONTRACT_ADDR)
                {
                    uint64_t totalburn = 0;
                    uint64_t burnAmount = 0;
                    uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                    std::lock_guard<std::mutex> lock(global::ca::BURN_MUTEX);
                    auto ret = dbWriter.getTotalBurnAmount(totalburn);
                    if(ret != DBStatus::DB_SUCCESS && ret != DBStatus::DB_NOT_FOUND)
                    {
                        ERRORLOG("getTotalBurnAmount error! totalburn:{}",totalburn);
                        return -63;
                    }

                    ret = dbWriter.getBurnAmountByPeriod(period, burnAmount);
                    if(DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                    {
                        ERRORLOG("getBurnAmountByPeriod error! ret:{}",ret);
                        return -64;
                    }   
                    burnAmount -= vout.value();
                    totalburn -= vout.value();
                    if(DBStatus::DB_SUCCESS != dbWriter.setBurnAmountByPeriod(period, burnAmount))
                    {
                        ERRORLOG("setBurnAmountByPeriod error! period:{}, burnAmount:{}", period, burnAmount);
                        return -65; 
                    }
                    if (DBStatus::DB_SUCCESS != dbWriter.setTotalBurnAmount(totalburn))
                    {
                        ERRORLOG("setTotalBurnAmount error! totalburn:{}", totalburn);
                        return -66;
                    }

                    uint64_t zero_time = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(tx.time());
                    uint64_t gasAmount = 0;
                    auto result = dbWriter.getGasAmountByPeriod(zero_time,currency,gasAmount);
                    if(result != DBStatus::DB_SUCCESS && result != DBStatus::DB_NOT_FOUND)
                    {
                        ERRORLOG("getGasAmountByPeriod error! gasAmount:{}",gasAmount);
                        return -167;
                    }
                    
                    DEBUGLOG("getGasAmountByPeriod (zero_time:{}, currency:{},gasAmount:{})",zero_time, currency,gasAmount);
                    gasAmount -= vout.value();
                    if(DBStatus::DB_SUCCESS != dbWriter.setGasAmountByPeriod(zero_time,currency,gasAmount))
                    {
                        ERRORLOG("setGasAmountByPeriod error! zero_time:{}, currency:{},gasAmount{}",zero_time,currency,burnAmount);
                        return -168;
                    }

                    continue;
                }

                if(vout.addr() == global::ca::kVirtualDeploymentContractAddress || vout.addr() == global::ca::VIRTUAL_CALL_CONTRACT_ADDR || vout.addr() == global::ca::kVirtualCallFlowOutAddr)
                {
                    continue;
                }

                global::ca::TxType txType = (global::ca::TxType)tx.type();
                allAddr.insert(vout.addr());
                ret = dbWriter.removeUtxoHashesByAddr(vout.addr(), currency, tx.hash());
                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                {
                    return -67;
                }


                std::string balanceUtxo ;
                // if((txType == global::ca::TxType::UNSTAKE || txType == global::ca::TxType::UNDELEGATE || txType == global::ca::TxType::UNLOCK) && utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_FALSE)
                // {
                //     utxoValue.insert(std::make_pair(tx.hash() + "_" + vout.addr(),std::to_string(vout.value())));
                // }
                // else 
                if(txType == global::ca::TxType::BONUS && utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_FALSE)
                {

                    if(vout.addr() == utxo.owner(0))
                    {
                        bonusUtxoValue.insert(std::make_pair(tx.hash() + "_" + vout.addr(),std::to_string(vout.value())));
                    }
                    else
                    {
                        if (DBStatus::DB_SUCCESS != dbWriter.removeUtxoValueByUtxoHashes(tx.hash(), vout.addr(), currency, balanceUtxo))
                        {
                            ERRORLOG("getTransactionByHash failed!");
                            return -68;
                        }
                    }
                }
                else if(txType == global::ca::TxType::DEPLOY || txType == global::ca::TxType::CALL)
                {
                    ContractUtxoValue[vout.addr()].insert(std::make_pair(tx.hash() + "_" + vout.addr(),std::to_string(vout.value())));
                }
                else if(txType == global::ca::TxType::FUND){
                    fundUtxoValue.insert(std::make_pair(tx.hash() + "_" + vout.addr(),std::to_string(vout.value())));
                }
                else
                {
                    if (DBStatus::DB_SUCCESS != dbWriter.removeUtxoValueByUtxoHashes(tx.hash(), vout.addr(), currency, balanceUtxo))
                    {
                        ERRORLOG("getTransactionByHash failed!");
                        return -69;
                    }
                }

                int64_t balance = 0;
                ret = dbWriter.getBalanceByAddr(vout.addr(), currency, balance);
                if (DBStatus::DB_SUCCESS != ret)
                {
                    if (DBStatus::DB_NOT_FOUND != ret)
                    {
                        ERRORLOG("getBalanceByAddr error! ret:{}",ret);
                        return -70;
                    }
                    else
                    {
                        balance = 0;
                    }
                }
                balance -= vout.value();
                if (balance < 0)
                {
                    ERRORLOG("DeleteBlock vout height:{} hash:{} addr:{} balance:{}", block.height(), block.hash(), vout.addr(), balance);
                    return -71;
                }
                if (0 == balance)
                {
                    if (DBStatus::DB_SUCCESS != dbWriter.removeBalanceByAddr(vout.addr(), currency))
                    {
                        ERRORLOG("removeBalanceByAddr vout.addr:{}",vout.addr());
                        return -72;
                    }
                }
                else
                {
                    if (DBStatus::DB_SUCCESS != dbWriter.setBalanceByAddr(vout.addr(), currency, balance))
                    {
                        ERRORLOG("setBalanceByAddr vout.addr:{},balance:{},currency{}",vout.addr(),balance,currency);
                        return -73;
                    }
                }
            }

            // //下面的逻辑需要变动，暂存修改
            // std::vector<std::string> utxoValues;
            // if(utxoValue.size() == 2)
            // {
            //     std::string utxoHashBalance;
            //     auto iter = utxoValue.begin();
            //     for(;iter != utxoValue.end(); iter ++)
            //     {
            //         utxoHashBalance += iter->second + "_";
            //         utxoValues.clear();
            //         StringUtil::SplitString(iter->first, "_", utxoValues);      
            //     }

            //     if(utxoHashBalance[utxoHashBalance.length()-1] == '_')
            //     {
            //         utxoHashBalance = utxoHashBalance.substr(0,utxoHashBalance.length()-1);
            //     }

            //     if (DBStatus::DB_SUCCESS != dbWriter.removeUtxoValueByUtxoHashes(utxoValues[0], utxoValues[1],currency,utxoHashBalance))
            //     {
            //         ERRORLOG("getTransactionByHash failed!");
            //         return -74;
            //     }

            // }

            if(!fundUtxoValue.empty()){
                std::string utxoHashBalance;
                std::vector<std::string> utxoValues;
                if(fundUtxoValue.size() == 2){
                    auto iter = fundUtxoValue.begin();
                    for(;iter!=fundUtxoValue.end();iter++){
                        utxoHashBalance += iter->second + "_";
                        utxoValues.clear();
                        StringUtil::SplitString(iter->first, "_", utxoValues);
                    }

                    if(utxoHashBalance[utxoHashBalance.length()-1] == '_'){
                        utxoHashBalance = utxoHashBalance.substr(0,utxoHashBalance.length()-1);
                    }

                }else if(fundUtxoValue.size() == 1){
                    auto iter = fundUtxoValue.begin();
                    utxoHashBalance = iter->second;
                    StringUtil::SplitString(iter->first, "_", utxoValues);
                    
                }

                ret = dbWriter.removeUtxoValueByUtxoHashes(utxoValues[0], utxoValues[1], currency, utxoHashBalance);
                if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                {
                    ERRORLOG("removeUtxoValueByUtxoHashes error! ret:{}",ret);
                    return -97;
                }
            }

            std::vector<std::string> bonusUtxoValues;
            if(!bonusUtxoValue.empty())
            {
                std::string utxoHashBalance;
                auto iter = bonusUtxoValue.begin();
                for(;iter != bonusUtxoValue.end(); iter ++)
                {
                    utxoHashBalance += iter->second + "_";
                    bonusUtxoValues.clear();
                    StringUtil::SplitString(iter->first, "_", bonusUtxoValues);      
                }

                if(utxoHashBalance[utxoHashBalance.length()-1] == '_')
                {
                    utxoHashBalance = utxoHashBalance.substr(0,utxoHashBalance.length()-1);
                }

                if (DBStatus::DB_SUCCESS != dbWriter.removeUtxoValueByUtxoHashes(bonusUtxoValues[0], bonusUtxoValues[1],currency,utxoHashBalance))
                {
                    ERRORLOG("getTransactionByHash failed!");
                    return -75;
                }

            }

            if(!ContractUtxoValue.empty())
            {
                for(const auto& UtxoValue : ContractUtxoValue)
                {
                    std::vector<std::string> ContractUtxoValues;
                    std::string utxoHashBalance;
                    auto iter = UtxoValue.second.begin();
                    for(;iter != UtxoValue.second.end(); iter ++)
                    {
                        utxoHashBalance += iter->second + "_";   
                        ContractUtxoValues.clear();
                        StringUtil::SplitString(iter->first, "_", ContractUtxoValues);   
                    }
                    if(utxoHashBalance[utxoHashBalance.length()-1] == '_')
                    {
                        utxoHashBalance = utxoHashBalance.substr(0,utxoHashBalance.length()-1);
                    }

                    ret = dbWriter.removeUtxoValueByUtxoHashes(ContractUtxoValues[0], ContractUtxoValues[1],currency,utxoHashBalance);
                    if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
                    {
                        ERRORLOG("removeUtxoValueByUtxoHashes error! ret:{}",ret);
                        return -76;
                    }
                }
            }
        }
        
        // Delete keccak256(rlp) → internal hash mapping
        if (!tx.rlp().empty())
        {
            dev::bytes rlpBytes = dev::fromHex(tx.rlp());
            std::string rlpHash = keccak256_hex(std::string(reinterpret_cast<const char*>(rlpBytes.data()), rlpBytes.size()));
            std::transform(rlpHash.begin(), rlpHash.end(), rlpHash.begin(), ::tolower);
            if (DBStatus::DB_SUCCESS != dbWriter.removeInternalHashByRlpHash(rlpHash))
            {
                ERRORLOG("removeInternalHashByRlpHash error! rlpHash:{}", rlpHash);
                return -79;
            }
        }

        // Delete transaction body data corresponding to transaction hash
        if (DBStatus::DB_SUCCESS != dbWriter.removeTransactionByHash(tx.hash()))
        {
            ERRORLOG("removeTransactionByHash hash:{}",tx.hash());
            return -77;
        }

        // Delete the block hash corresponding to the transaction hash
        if (DBStatus::DB_SUCCESS != dbWriter.removeBlockHashByTransactionHash(tx.hash()))
        {
            ERRORLOG("removeBlockHashByTransactionHash error! hash:{}",tx.hash());
            return -78;
        }

        auto blockHeight = block.height();
        auto hashHeightSum = calculateSumHashCeilingHeight(blockHeight);
        std::string sumHash;
        uint64_t newTop = 0;
        if (DBStatus::DB_SUCCESS != dbWriter.getBlockTop(newTop))
        {
            ERRORLOG("getBlockTop error! top:{}",top);
            return -79;
        }
        DEBUGLOG("robackblockAAABBBB:blockHeight:{}, hashHeightSum:{}, newTop:{}", blockHeight, hashHeightSum, newTop);
        if (DBStatus::DB_SUCCESS == dbWriter.getSumHashByHeight(hashHeightSum, sumHash))
        {
            if (blockHeight % global::ca::hashRangeSum == 1)
            {
                // uint64_t newTop = 0;
                // if (DBStatus::DB_SUCCESS != dbWriter.getBlockTop(newTop))
                // {
                //     ERRORLOG("getBlockTop error! top:{}",top);
                //     return -80;
                // }
                INFOLOG("rollback block height: {}, top: {}", blockHeight, newTop);

                if (blockHeight > newTop)
                {
                    if (DBStatus::DB_SUCCESS != dbWriter.removeSumHashByHeight(hashHeightSum))
                    {
                        return -81;
                    }

                    DEBUGLOG("delete height sum hash at height {}", hashHeightSum);
                    continue;
                }
                
                int rt = recalculate_heights_sum_hash(newTop, hashHeightSum, sumHash, blockHeight, dbWriter);
                if(rt != 0)
                {
                    ERRORLOG("recalculate_heights_sum_hash error! rt:{}", rt);
                    return -82;
                }
            }
            else
            {
                int rt = recalculate_heights_sum_hash(newTop, hashHeightSum, sumHash, blockHeight, dbWriter);
                if(rt != 0)
                {
                    ERRORLOG("recalculate_heights_sum_hash error! rt:{}", rt);
                    return -83;
                }
            }
        }

        if((newTop + 1) % global::ca::sumHashRange == 0)
        {
            int end_top = newTop / global::ca::sumHashRange ;
            if (DBStatus::DB_SUCCESS != dbWriter.removeThousandSumHashByBlockHeight(newTop + 1))
            {
                DEBUGLOG("remove thousands hash height >: {}", newTop + 1);
                return -84;
            }
            
            
            if(newTop + 1 == global::ca::sumHashRange)
            {
                if (DBStatus::DB_SUCCESS != dbWriter.removeThousandSumHashTop(global::ca::sumHashRange))
                {
                    return -85;
                }
            }
            else
            {

                DBReader dbReader;
                uint64_t maxHeight = 0;
                if(DBStatus::DB_SUCCESS != dbReader.getThousandSumHashTop(maxHeight))
                {
                    ERRORLOG("getThousandSumHashTop deleteblock failed!");
                    return -86;
                }

                if(end_top * global::ca::sumHashRange < maxHeight)
                {
                    if(DBStatus::DB_SUCCESS != dbWriter.setThousandSumHashTop(end_top * global::ca::sumHashRange))
                    {
                        return -87;
                    }
                }
                DEBUGLOG("delete rollback block maxheight >: {}" , maxHeight);

            }
        }

    }

    if (block.version() == global::ca::kCurrentBlockVersion && isContractBlocked(block))
    {
        nlohmann::json blockData = nlohmann::json::parse(block.data());
        global::ca::VmType vmType; std::string contractAddress;
        auto deleteContractRequest = [&](const std::map<std::string, CTransaction>& CTxs)
        {
            // 转换为时间戳排序的容器，然后逆序遍历（回滚需要逆序）
            // Convert to timestamp-sorted container, then iterate in reverse (rollback needs reverse order)
            std::vector<std::pair<uint64_t, CTransaction>> tx_with_timestamp;
            for (const auto& item : CTxs)
            {
                tx_with_timestamp.emplace_back(item.second.time(), item.second);
            }
            std::sort(tx_with_timestamp.begin(), tx_with_timestamp.end(),
                      [](const auto& a, const auto& b) {
                          if (a.first != b.first) return a.first < b.first;
                          return a.second.hash() < b.second.hash();
                      });

            for (auto iter = tx_with_timestamp.rbegin(); iter != tx_with_timestamp.rend(); ++iter)
            {
                const auto& tx = iter->second;
                try
                {
                    nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                    nlohmann::json _txInfo = dataJson["txInfo"].get<nlohmann::json>();
                    vmType = _txInfo[Evmone::contractVmKeyName].get<global::ca::VmType>();
                    contractAddress = _txInfo[Evmone::contractRecipientKeyNameStr].get<std::string>();
                }
                catch(...)
                {
                    ERRORLOG("parse TxInfo fail");
                    return -88;
                }
                
                if(global::ca::TxType::DEPLOY == (global::ca::TxType)tx.type())
                {
                    for(const auto &utxo : tx.utxos())
                    {
                        for (auto &vin : utxo.vin())
                        {
                            const std::string deployerAddress = GenerateAddr(vin.vinsign().pub());
                            const std::string deployHash = tx.hash();

                            nlohmann::json txInfo;
                            for (const auto&[key, value] : blockData.items())
                            {
                                if (key == tx.hash())
                                {
                                    txInfo = value;
                                    break;
                                }
                            }
                            int deleteResult = Evmone::DeleteContract(deployerAddress, contractAddress,
                                                                    dbWriter, vmType);

                            if (deleteResult != 0)
                            {
                                ERRORLOG("Delete Block DeleteContract Error {}", deleteResult);
                                return deleteResult;
                            }
                            for(const auto& [contractCreatorAddr, code] : txInfo[Evmone::contractCreationKeyLabel].items())
                            {
                                if(contractCreatorAddr.empty())
                                {
                                    ERRORLOG("empty create internal contract address")
                                    return -999999;
                                }
                                DEBUGLOG("create internal contract at addr:{} \n code:{}", contractCreatorAddr, code);
                                deleteResult = Evmone::DeleteContract(deployerAddress, contractCreatorAddr,
                                                                    dbWriter, vmType);
                                if (deleteResult != 0)
                                {
                                    ERRORLOG("Delete Block DeleteContract Error {}",deleteResult);
                                    return deleteResult;
                                }
                            }
                            for(auto &it : txInfo[Evmone::contractPreHashKey].items())
                            {
                                if(it.key() == "") continue;
                                ERRORLOG("=========================delete_addr: {}", it.key());
                                std::string prevTxHash = it.value().get<std::string>();
                                ERRORLOG("=========================prevTxHash: {}", prevTxHash);
                                if (DBStatus::DB_SUCCESS != dbWriter.setLatestUtxoByContractAddr(it.key(), prevTxHash))
                                {
                                    return -89;
                                }
                            }

                            for(const auto& it : txInfo[Evmone::contractDestructionKey].items())
                            {
                                if(it.key() == "") continue;
                                DEBUGLOG("setContractDeployUtxoByContractAddr,addr:{},value:{}", it.key(), it.value());

                                if (DBStatus::DB_SUCCESS != dbWriter.setContractDeployUtxoByContractAddr(it.key(), it.value()));
                                {
                                    return -90;
                                }

                                if (DBStatus::DB_SUCCESS != dbWriter.setContractCodeByContractAddr(it.key(), it.value()));
                                {
                                    return -91;
                                }
                            }
                            nlohmann::json storage = txInfo[Evmone::storageKeyForContract];
                            if(!storage.is_null())
                            {
                                for (auto it = storage.begin(); it != storage.end(); ++it)
                                {
                                    std::string strKey = it.key();
                                    if (strKey.substr(strKey.length() - 8 , strKey.length()) == "rootHash" || strKey.empty())
                                    {
                                        continue;
                                    }
                                    size_t pos = strKey.find('_');
                                    if(pos != std::string::npos)
                                    {
                                        strKey = contractAddress + strKey.substr(pos);
                                    }
                                    if (dbWriter.removeMptValueByMptKey(strKey) != DBStatus::DB_SUCCESS)
                                    {
                                        return -92;
                                    }
                                }
                            }

                            break;
                        }
                    }
                }
                else if(global::ca::TxType::CALL == (global::ca::TxType)tx.type())
                {
                    std::string deployerAddress = "";
                    for(const auto &utxo : tx.utxos())
                    {
                        for (auto &vin : utxo.vin())
                        {
                            deployerAddress = GenerateAddr(vin.vinsign().pub());
                        }
                    }
                    nlohmann::json txInfo;
                    for (const auto&[key, value] : blockData.items()) {
                        if (key == tx.hash()) {
                            txInfo = value;
                            break;
                        }

                    }
                    for (auto &it : txInfo[Evmone::contractPreHashKey].items()) {
                        if (it.key() == "") continue;
                        ERRORLOG("=========================delete_addr: {}", it.key());
                        std::string prevTxHash = it.value().get<std::string>();
                        ERRORLOG("=========================prevTxHash: {}", prevTxHash);
                        if (DBStatus::DB_SUCCESS != dbWriter.setLatestUtxoByContractAddr(it.key(), prevTxHash)) {
                            return -93;
                        }
                    }

                    for (const auto &it : txInfo[Evmone::contractDestructionKey].items()) {
                        if (it.key() == "") continue;
                        DEBUGLOG("setContractDeployUtxoByContractAddr,addr:{},value:{}", it.key(), it.value());
                        if (DBStatus::DB_SUCCESS != dbWriter.setContractDeployUtxoByContractAddr(it.key(), it.value()));
                        {
                            return -94;
                        }
                        if (DBStatus::DB_SUCCESS != dbWriter.setContractCodeByContractAddr(it.key(), it.value()));
                        {
                            return -95;
                        }
                    }

                    nlohmann::json storage = txInfo[Evmone::storageKeyForContract];
                    if (!storage.is_null()) {
                        for (auto it = storage.begin(); it != storage.end(); ++it) {
                            std::string strKey = it.key();
                            if (strKey.substr(strKey.length() - 8, strKey.length()) == "rootHash" ||
                                strKey.empty()) {
                                continue;
                            }
                            if (dbWriter.removeMptValueByMptKey(strKey) != DBStatus::DB_SUCCESS) {
                                return -96;
                            }
                        }
                    }
                    for (const auto&[contractCreatorAddr, code] : txInfo[Evmone::contractCreationKeyLabel].items()) {
                        if (contractCreatorAddr.empty()) {
                            ERRORLOG("empty create internal contract address")
                            return -999999;
                        }
                        DEBUGLOG("create internal contract at addr:{} \n code:{}", contractCreatorAddr, code);
                        int deleteResult = Evmone::DeleteContract(deployerAddress, contractCreatorAddr,
                                                                dbWriter, vmType);
                        if (deleteResult != 0) {
                            return deleteResult;
                        }
                    }
                }
            }
            return 0;
        };

        packDispatch _packdisTx;
        for(const auto& tx : block.txs())
        {
            auto& txHash = tx.hash();
            std::vector<std::string> dependentTxHashes;
            auto it = blockData.find(txHash);
            if (it != blockData.end() && it.value().contains("dependentCtx")) 
            {
                for (const auto& dependencyTransactionHashRequest : it.value()["dependentCtx"]) 
                {
                    dependentTxHashes.push_back(dependencyTransactionHashRequest.get<std::string>());
                }
            } 
            else 
            {
                ERRORLOG("blockData.find(txHash) error notFoundTx:{}", txHash);
                return -97;
            }

            _packdisTx.Add(txHash, dependentTxHashes, tx);
        }

        std::map<uint32_t, std::map<std::string, CTransaction>> dependentContractTxMap_;
        std::map<std::string, CTransaction> non_dependent_contract_tx_map;
        _packdisTx.GetDependentData(dependentContractTxMap_, non_dependent_contract_tx_map);

        for(const auto& dependent : dependentContractTxMap_)
        {
            auto ret = deleteContractRequest(dependent.second);
            if(ret != 0)
            {
                ERRORLOG("DeleteBlock deleteContractRequest Error{}", ret);
                return ret;
            }
        }
        if(!non_dependent_contract_tx_map.empty())
        {
            auto ret = deleteContractRequest(non_dependent_contract_tx_map);
            if(ret != 0)
            {
                ERRORLOG("DeleteBlock deleteContractRequest Error{}", ret);
                return ret;
            }
        }
    }


     for(auto &t:block.txs()){
        for(auto &u:t.utxos()){
            for(auto &vo:u.vout()){
                MagicSingleton<ohi::utils::AddressStatusCache>::GetInstance()->markExpired(vo.addr());
            }
        }
    }
    dbWriter.setRollbackBlockNum(block.height(),true);
    dbWriter.saveRollBackBlock(block.height(), blockRaw);

    return 0;
}






static int RollBackBlock(const std::multimap<uint64_t, std::string> &hashs)
{
    int i = 0;
    DBReadWriter dbWriter;
   //rollback_wbl_blocks;
  

    for (auto it = hashs.rbegin(); hashs.rend() != it; ++it)
    {
        ++i;
        std::string deleteHash = it->second;
        TRACELOG("begin delete block {}", deleteHash);





        auto ret = ca_algorithm::DeleteBlock(dbWriter, deleteHash);
        if (0 != ret)
        {
            ERRORLOG("faill to delete block {}, ret {}", deleteHash, ret);
            return ret - 100;
        }
        else
        {
            DEBUGLOG("RollBackBlock delete block: {}",deleteHash);
            
            //cache_block->addBlockHashByHeight(uint64_t height, const std::string &block)
        }
        TRACELOG("successfully delete block {}", deleteHash);
        {
                CBlock block;
                DBReadWriter dbReader;
                std::ostringstream filestream;
                std::string blockRaw;
                
                auto ret = dbReader.getBlockByBlockHash(deleteHash, blockRaw);

                if (DBStatus::DB_NOT_FOUND == ret)
                {
                    return 0;
                }
                else if (DBStatus::DB_SUCCESS != ret)
                {
                    ERRORLOG("getBlockByBlockHash delete_block_hash:{},blockRaw:{}",deleteHash,blockRaw);
                    return -1;
                }
                if (!block.ParseFromString(blockRaw))
                {
                    ERRORLOG("ParseFromString error!");
                    return -2;
                }
                PrintBlock(block,true,filestream);

                std::string teststr = filestream.str();
                DEBUGLOG("rollback block --> {}", teststr);
        }
        
        if(10 == i)
        {
            i = 0;
            if (DBStatus::DB_SUCCESS != dbWriter.transactionCommit())
            {
                return -3;
            }
            if (DBStatus::DB_SUCCESS != dbWriter.reInitTransaction())
            {
                return -4;
            }
        }
    }
    if(i > 0)
    {
        if (DBStatus::DB_SUCCESS != dbWriter.transactionCommit())
        {
            return -5;
        }
    }
    MagicSingleton<BlockStorage>::GetInstance()->clearPreHashMap();
    // cache_block->SaveToDB(dbWriter);

    // cache_block->clearCache();
    return 0;
}
int ca_algorithm::RollBackToHeight(uint64_t height)
{
    DBReadWriter dbWriter;
    uint64_t nodeHeight = 0;
    if (DBStatus::DB_SUCCESS != dbWriter.getBlockTop(nodeHeight))
    {
        return -1;
    }
    std::multimap<uint64_t, std::string> hashs;
    std::vector<CBlock>backupblocks;
    std::vector<std::string> blockHashs;
    for (uint32_t i = nodeHeight; i > height; --i)
    {
        blockHashs.clear();
        int res = dbWriter.getBlockHashsByBlockHeight(i, blockHashs);
        if (DBStatus::DB_SUCCESS != res)
        {
            DEBUGLOG("query block height {} fail, ret: {}", i, res);
            return -2;
        }
        for (auto &hash : blockHashs)
        {
            hashs.insert(std::make_pair(i, hash)); // All hash keys in a height can have multiple
        }
    }

    for(auto it = hashs.begin(); hashs.end() != it; ++it)
    {
        std::string blockStr;
        if (DBStatus::DB_SUCCESS != dbWriter.getBlockByBlockHash(it->second,blockStr))
        {
            return -3;
        }
        CBlock block;
        if (!block.ParseFromString(blockStr))
        {
            return -4;
        }
        backupblocks.push_back(block);
    }

    auto ret = RollBackBlock(hashs);
    if (0 != ret)
    {
        return ret - 100;
    }
    if(ret == 0)
    {
        for (auto &block:backupblocks)
        {
            if (MagicSingleton<BlockHttpCallbackHandler>::GetInstance()->IsRunning())
            {
                MagicSingleton<BlockHttpCallbackHandler>::GetInstance()->RollbackBlock(block);
            }
        }
    }
    
    return 0;
}

int ca_algorithm::rollback_by_hash(const std::string &blockHash)
{
    DBReadWriter dbWriter;
    std::multimap<uint64_t, std::string> hashs;
    std::vector<CBlock> backupblocks;
    uint64_t height = 0;
    bool rollbackByBlockHeight = false;
    {
        std::set<std::string> rollbackBlockHashs;
        std::set<std::string> rollbackTransHashs;
        CBlock block;
        {
            std::string blockRaw;
            auto ret = dbWriter.getBlockByBlockHash(blockHash, blockRaw);
            if (DBStatus::DB_NOT_FOUND == ret)
            {
                return 0;
            }
            else if (DBStatus::DB_SUCCESS != ret)
            {
                return -1;
            }
            if (!block.ParseFromString(blockRaw))
            {
                return -2;
            }
            hashs.insert(std::make_pair(block.height(), block.hash()));
            rollbackBlockHashs.insert(block.hash());
            for (auto &tx : block.txs())
            {
                rollbackTransHashs.insert(tx.hash());
            }
        }
        uint64_t nodeHeight = 0;
        if (DBStatus::DB_SUCCESS != dbWriter.getBlockTop(nodeHeight))
        {
            return -3;
        }
        std::vector<std::string> blockRaws;
        std::vector<std::string> blockHashs;
        for (height = block.height(); height < nodeHeight + 1; ++height)
        {
            blockHashs.clear();
            blockRaws.clear();
            if (DBStatus::DB_SUCCESS != dbWriter.getBlockHashsByBlockHeight(height, blockHashs))
            {
                return -4;
            }
            if (DBStatus::DB_SUCCESS != dbWriter.getBlocksByBlockHash(blockHashs, blockRaws))
            {
                return -5;
            }
            bool flag = false;
            for (auto &blockRaw : blockRaws)
            {
                block.Clear();
                if (!block.ParseFromString(blockRaw))
                {
                    return -6;
                }
                if (rollbackBlockHashs.end() == std::find(rollbackBlockHashs.cbegin(), rollbackBlockHashs.cend(), block.prevhash()))
                {
                    for (auto &tx : block.txs())
                    {
                        if (GetTransactionType(tx) != kTransactionTypeTx)
                        {
                            continue;
                        }
                        for(const auto & utxo : tx.utxos())
                        {
                            for (auto &vin : utxo.vin())
                            {
                                for (auto & prevout : vin.prevout())
                                {
                                    auto utxoHash = prevout.hash();
                                    if (rollbackTransHashs.end() != std::find(rollbackTransHashs.cbegin(), rollbackTransHashs.cend(), utxoHash))
                                    {
                                        flag = true;
                                        break;
                                    }
                                }
                                
                            }
                        }
                        if (flag)
                        {
                            break;
                        }
                    }
                }
                else
                {
                    flag = true;
                }
                if (flag)
                {
                    hashs.insert(std::make_pair(block.height(), block.hash()));
                    rollbackBlockHashs.insert(block.hash());
                    for (auto &tx : block.txs())
                    {
                        rollbackTransHashs.insert(tx.hash());
                    }
                }
            }
            if (flag && blockHashs.size() <= 1)
            {
                height = block.height();
                rollbackByBlockHeight = true;
                break;
            }
        }
    }
    if (rollbackByBlockHeight)
    {
        uint64_t nodeHeight = 0;
        if (DBStatus::DB_SUCCESS != dbWriter.getBlockTop(nodeHeight))
        {
            return -7;
        }
        std::vector<std::string> blockHashs;

        for (uint32_t i = nodeHeight; i > height; --i)
        {
            blockHashs.clear();
            if (DBStatus::DB_SUCCESS != dbWriter.getBlockHashsByBlockHeight(i, blockHashs))
            {
                return -8;
            }
            for (auto &hash : blockHashs)
            {
                hashs.insert(std::make_pair(i, hash));

            }
        }
    }

    for(auto it = hashs.begin(); hashs.end() != it; ++it)
    {
        std::string blockStr;
        if (DBStatus::DB_SUCCESS != dbWriter.getBlockByBlockHash(it->second,blockStr))
        {
            return -9;
        }
        CBlock block;
        if (!block.ParseFromString(blockStr))
        {
            return -10;
        }
        backupblocks.push_back(block);
    }


    auto ret = RollBackBlock(hashs);

    if (0 != ret)
    {
        return ret - 100;
    }
    if(ret == 0)
    {
        for (auto &block :backupblocks)
        {
            if (MagicSingleton<BlockHttpCallbackHandler>::GetInstance()->IsRunning())
            {
                MagicSingleton<BlockHttpCallbackHandler>::GetInstance()->RollbackBlock(block);
            }
        }
    }
    return 0;
}


int ca_algorithm::CalcBonusValue(uint64_t &curTime, const std::string &bonusAddr, std::map<std::string, uint64_t> & values,bool isDisplay)
{
    // Slashing L2 Forfeit check: if node is Jailed beyond 8 hours, reward = 0
    {
        DBReader dbReader;

        // L4 Tombstoned check: permanently banned nodes get no rewards
        std::string tombstoneVal;
        if (DBStatus::DB_SUCCESS == dbReader.readData(std::string("slash_tombstone_") + bonusAddr, tombstoneVal))
        {
            ERRORLOG("[SLASH] Node {} is Tombstoned — permanently banned from rewards", bonusAddr);
            return -201;  // Special error code: permanently banned
        }

        std::string jailVal;
        if (DBStatus::DB_SUCCESS == dbReader.readData(std::string("slash_jail_") + bonusAddr, jailVal))
        {
            // Parse jail start period from "startPeriod,reason,level"
            auto commaPos = jailVal.find(',');
            if (commaPos != std::string::npos)
            {
                uint64_t jailStartPeriod = 0;
                try { jailStartPeriod = std::stoull(jailVal.substr(0, commaPos)); } catch (...) {}

                uint64_t currentPeriod = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(curTime);
                uint64_t jailedDuration = (currentPeriod > jailStartPeriod) ? (currentPeriod - jailStartPeriod) : 0;

                if (jailedDuration >= global::ca::kForfeitJailPeriods)
                {
                    ERRORLOG("[SLASH] Node {} L2 Forfeit: jailed for {} periods (threshold: {})",
                             bonusAddr, jailedDuration, global::ca::kForfeitJailPeriods);
                    return -200;  // Special error code: reward forfeited
                }
            }
        }

        // Check excessive disconnects (>= 10/hour)
        uint64_t currentHour = curTime / (3600 * 1000000);  // Convert microseconds to hours
        uint32_t disconnectCount = 0;
        std::string dcVal;
        std::string dcKey = std::string("slash_disconnect_") + bonusAddr + ":" + std::to_string(currentHour);
        if (DBStatus::DB_SUCCESS == dbReader.readData(dcKey, dcVal))
        {
            try { disconnectCount = std::stoul(dcVal); } catch (...) {}
        }
        if (disconnectCount >= global::ca::kForfeitDisconnectCount)
        {
            ERRORLOG("[SLASH] Node {} L2 Forfeit: {} disconnects this hour (threshold: {})",
                     bonusAddr, disconnectCount, global::ca::kForfeitDisconnectCount);
            return -200;  // Special error code: reward forfeited
        }
    }

    std::map<std::string, double> addr_percent;
    std::unordered_map<std::string, uint64_t> addrSignCount;
    auto ret = ca_algorithm::fetchAbnormalSignAddrListByPeriod(curTime, addr_percent, addrSignCount);
    if(ret < 0) return ret - 100;
    std::ofstream outFile("example.txt", std::ios::trunc);

    if(addrSignCount.empty() )
    {
        std::cout << "No one worked the day before ! \n"; 
        return -1;
    }

    if(isDisplay)
    {
        usleep(1);
        std::vector<std::pair<std::string, uint64_t>> vec(addrSignCount.begin(), addrSignCount.end());

        std::sort(vec.begin(), vec.end(), [](const auto& lhs, const auto& rhs) {
                    return lhs.second > rhs.second;
                });
        std::cout << "SignInfo:" << std::endl;
        outFile << "SignInfo:" << std::endl;
        for (const auto& p : vec)
        {
            usleep(1);
            std::cout << " addr: " << addHexPrefix(p.first) << "  count: " << p.second << std::endl;
            outFile << " addr: " << addHexPrefix(p.first) << "  count: " << p.second << std::endl;
        }
    }

    double dividendRate = 0.0;
    bool isQualified = false;
    auto iter = addr_percent.find(bonusAddr);
    auto _iter = addrSignCount.find(bonusAddr);
    if(iter != addr_percent.end())
    {
        dividendRate = iter->second;
    }
    else if(_iter != addrSignCount.end())
    {
        isQualified = true;
    }else //节点没有资格申领
    {
        ERRORLOG("Node not qualified");
        return -5;
    }

	std::string strTx;
	CTransaction tx;
	uint64_t zeroTime = MagicSingleton<TimeUtil>::GetInstance()->GetMorningTime(curTime) * 1000000;
    std::multimap<std::string, std::pair<uint64_t,uint64_t>> mpDelegatingAddr2Amount;

    ret = GetDelegatingAmountAndDuration(bonusAddr, curTime, zeroTime, mpDelegatingAddr2Amount);
    if(ret < 0) return ret-=200;

    if(isDisplay)
    {
        usleep(1);
        std::cout << "bonusAddr: " << addHexPrefix(bonusAddr) << std::endl;
        outFile << "bonusAddr: " << addHexPrefix(bonusAddr) << std::endl;
        for(auto &it : mpDelegatingAddr2Amount)
        {
            usleep(1);
            std::cout << "delegatingor: " << it.first << " amount: " << it.second.first << " duration: " << it.second.second << std::endl;
            outFile << "delegatingor: " << it.first << " amount: " << it.second.first << " duration: " << it.second.second << std::endl;
        }
        std::cout<<std::endl;
    }
    //使用新的通胀和年化率计算方法
    double annualizedRate = 0.0;
    
    // 获取当前网络质押率
    double stakingRate = 0.0;
    ret = GetNetworkStakingRate(curTime, stakingRate);
    if (ret != 0)
    {
        ERRORLOG("GetNetworkStakingRate failed: {}", ret);
        return -4;
    }
    
    // 使用新的年化率计算方法
    ret = GetNewAnnualizedRate(curTime, stakingRate, annualizedRate);
    if (ret != 0)
    {
        ERRORLOG("GetNewAnnualizedRate failed: {}", ret);
        return -4;
    }

    // 提前将百分比年化率转换为小数形式，避免后续计算溢出
    annualizedRate = annualizedRate / 100.0;

    if (isDisplay)
    {
        usleep(1);
        std::cout << "stakingRate : " << stakingRate << "%" << std::endl;
        std::cout << "annualizedRate : " << annualizedRate << std::endl;
        std::cout << "new calculation method--------------------------------------------------\n";
        outFile << "stakingRate : " << stakingRate << "%" << std::endl;
        outFile << "annualizedRate : " << annualizedRate << std::endl;
        outFile << "new calculation method--------------------------------------------------\n";
        for(auto &it : mpDelegatingAddr2Amount)
        {
            usleep(1);
            values[it.first] = annualizedRate * it.second.first / 365;

            std::cout << "DelegatingAddr: " <<addHexPrefix(it.first) << std::endl;
            std::cout << "delegateAmount: " << it.second.first << std::endl; 
            std::cout << "reward: " << values[it.first] << std::endl;
            outFile << "DelegatingAddr: " << addHexPrefix(it.first) << std::endl;
            outFile << "delegateAmount: " << it.second.first << std::endl;
            outFile << "reward: " << values[it.first] << std::endl;
        }

        if (dividendRate > 0.0)
        {
          usleep(1);
          std::cout
              << "workload "
                 "adjusted--------------------------------------------------\n";
          std::cout << "dividendRate :" << dividendRate << "\n";
          outFile
              << "workload "
                 "adjusted--------------------------------------------------\n";
          outFile << "dividendRate :" << dividendRate << "\n";
          for (auto &it : mpDelegatingAddr2Amount) {
            usleep(1);
            values[it.first] =
                dividendRate * (annualizedRate * it.second.first / 365);

            std::cout << "DelegatingAddr: " << addHexPrefix(it.first)
                      << std::endl;
            std::cout << "delegateAmount: " << it.second.first << std::endl;
            std::cout << "reward: " << values[it.first] << std::endl;
            outFile << "DelegatingAddr: " << addHexPrefix(it.first)
                    << std::endl;
            outFile << "delegateAmount: " << it.second.first << std::endl;
            outFile << "reward: " << values[it.first] << std::endl;
          }
        }
    }
    //Maximum inflation rate/minimum pledge rate=maximum yield rate

    if (dividendRate > 0.0) //说明这个节点小于每个人的平均事务量                          //从而按工作量的百分比分配分红奖励
    {
      for (auto &it : mpDelegatingAddr2Amount) {
        values[it.first] =
            dividendRate * (annualizedRate * it.second.first / 365);
      }
      DEBUGLOG("Nodes with less than the average transaction volume per user");
      return 0;
    } else if (isQualified == true) //说明这个节点大于每个人的平均事务量
    {
      for (auto &it : mpDelegatingAddr2Amount) {
        values[it.first] = annualizedRate * it.second.first / 365;
      }
    }

    return 0;
}

double ca_algorithm::mapStakingRateToK(double stakingRate) 
{ 
    DEBUGLOG("开始质押率到k值映射 - 输入质押率: {}%", stakingRate);
    
    // 将质押率 (10% 到 100%) 映射到 k 值 (1 到 20) 
    if (stakingRate < 10 || stakingRate > 100) 
    { 
        ERRORLOG("质押率{}%超出有效范围[10%, 100%]", stakingRate);
        throw std::invalid_argument("质押率必须在 10% 到 100% 之间"); 
    } 
    double kMin = 1.0, kMax = 20.0; 
    double minStaking = 10.0, maxStaking = 100.0; 
    double k = kMin + (stakingRate - minStaking) * (kMax - kMin) / (maxStaking - minStaking);
    
    DEBUGLOG("k值映射计算: {}% -> k={} (范围: {}%-{}% 映射到 {}-{})", 
             stakingRate, k, minStaking, maxStaking, kMin, kMax);
    
    return k; 
} 

std::vector<double> ca_algorithm::calculateInflationRates(double k, int totalWeeks, double startRate, double endRate) 
{ 
    DEBUGLOG("开始计算通胀率 - 参数: k={}, 总周数={}, 起始率={}%, 结束率={}%", 
             k, totalWeeks, startRate, endRate);
    
    // 计算每周的通胀率 
    std::vector<double> rates; 
    for (int w = 1; w <= totalWeeks; ++w) 
    { 
        double x = static_cast<double>(w - 1) / (totalWeeks - 1); // 归一化时间 
        double rate = endRate + (startRate - endRate) * std::exp(-k * x); 
        rates.push_back(rate); 
        
        // 记录关键周数的通胀率
        if (w == 1 || w == totalWeeks || w % 52 == 0) // 第1周、最后一周、每年(52周)
        {
            DEBUGLOG("第{}周通胀率: {}% (归一化时间x={})", w, rate, x);
        }
    } 
    
    DEBUGLOG("通胀率计算完成 - 总计{}周, 衰减系数k={}", rates.size(), k);
    return rates; 
} 

std::vector<double> ca_algorithm::calculateAnnualizedRates(const std::vector<double>& inflationRates, double stakingRate) 
{ 
    DEBUGLOG("开始计算年化率 - 输入: 通胀率数组大小={}, 质押率={}%", 
             inflationRates.size(), stakingRate);

    // 根据通胀率和质押率计算年化率
    if (stakingRate < 10) {
        stakingRate = 10.0;
    }
    
    if (stakingRate > 100) 
    { 
        ERRORLOG("质押率{}%超出有效范围[10%, 100%]", stakingRate);
        throw std::invalid_argument("质押率必须在 10% 到 100% 之间"); 
    } 
    
    double stakingRatio = stakingRate / 100.0;
    DEBUGLOG("质押率转换: {}% -> 比例={}", stakingRate, stakingRatio);
    
    std::vector<double> annualizedRates; 
    for (size_t i = 0; i < inflationRates.size(); ++i) 
    { 
        double rate = inflationRates[i];
        double annualizedRate = rate / stakingRatio;
        annualizedRates.push_back(annualizedRate); 
        
        // 记录关键周数的年化率
        // if (i == 0 || i == inflationRates.size() - 1 || (i + 1) % 52 == 0) // 第1周、最后一周、每年(52周)
        {
            DEBUGLOG("第{}周年化率: 通胀率{}% / 质押比例{} = {}%", 
                     i + 1, rate, stakingRatio, annualizedRate);
        }
    } 
    
    DEBUGLOG("年化率计算完成 - 总计{}周数据", annualizedRates.size());
    return annualizedRates; 
}

int ca_algorithm::GetNewAnnualizedRate(const uint64_t &curTime, double stakingRate, double &annualizedRate)
{
    try 
    {
        DEBUGLOG("开始计算新年化率 - 输入参数: 当前时间={}, 质押率={}%", curTime, stakingRate);
        
        // 计算当前是第几周（从项目启动开始）
        // 这里假设项目启动时间为某个固定时间戳
        uint64_t projectStartTime = MagicSingleton<Genesis>::GetInstance()->GetGenesisTime(); //UTC (微秒)
        DEBUGLOG("项目启动时间: {}", projectStartTime);
        
        // 检查时间单位是否一致 - 如果创世时间看起来是秒级时间戳，需要转换为微秒
        if (projectStartTime < 1000000000000ULL) { // 小于 10^12，可能是秒级时间戳
            DEBUGLOG("检测到创世时间可能是秒级时间戳，转换为微秒: {} -> {}", projectStartTime, projectStartTime * 1000000);
            projectStartTime = projectStartTime * 1000000; // 转换为微秒
        }
        
        // 计算时间差
        uint64_t timeDiff = curTime - projectStartTime;
        uint64_t weekInMicroseconds = 7ULL * 24ULL * 60ULL * 60ULL * 1000000ULL; // 一周的微秒数
        uint64_t weeksSinceStart = timeDiff / weekInMicroseconds; // 转换为周数
        
        DEBUGLOG("详细计算过程:");
        DEBUGLOG("  当前时间: {} 微秒", curTime);
        DEBUGLOG("  项目启动时间: {} 微秒", projectStartTime);
        DEBUGLOG("  时间差: {} 微秒", timeDiff);
        DEBUGLOG("  一周微秒数: {} 微秒", weekInMicroseconds);
        DEBUGLOG("  计算周数: {} / {} = {}", timeDiff, weekInMicroseconds, weeksSinceStart);
        
        // 限制在520周内
        if (weeksSinceStart >= 520) 
        {
            DEBUGLOG("周数超出限制 {} >= 520, 调整为519周", weeksSinceStart);
            weeksSinceStart = 519; // 使用最后一周的数据
        }
        
        // 计算k值
        double k = mapStakingRateToK(stakingRate);
        DEBUGLOG("质押率映射: {}% -> k值={}", stakingRate, k);
        
        // 计算通胀率
        std::vector<double> inflationRates = calculateInflationRates(k, 520, 5.0, 0.5);
        DEBUGLOG("计算通胀率完成, 总周数: {}, 第一周通胀率: {}%, 最后一周通胀率: {}%", 
                 inflationRates.size(), 
                 inflationRates.empty() ? 0.0 : inflationRates[0],
                 inflationRates.empty() ? 0.0 : inflationRates.back());
        
        // 计算年化率
        std::vector<double> annualizedRates = calculateAnnualizedRates(inflationRates, stakingRate);
        DEBUGLOG("计算年化率完成, 总周数: {}, 第一周年化率: {}%, 最后一周年化率: {}%", 
                 annualizedRates.size(),
                 annualizedRates.empty() ? 0.0 : annualizedRates[0],
                 annualizedRates.empty() ? 0.0 : annualizedRates.back());
        
        // 获取当前周的年化率
        if (weeksSinceStart < annualizedRates.size()) 
        {
            annualizedRate = annualizedRates[weeksSinceStart];
            DEBUGLOG("获取第{}周年化率: {}%", weeksSinceStart, annualizedRate);
        } 
        else 
        {
            // 如果超出范围，使用最后一个值
            annualizedRate = annualizedRates.back();
            DEBUGLOG("周数{}超出范围, 使用最后一周年化率: {}%", weeksSinceStart, annualizedRate);
        }
        
        DEBUGLOG("年化率计算完成 - 最终结果: {}%", annualizedRate);
        return 0;
    } 
    catch (const std::exception& e) 
    {
        ERRORLOG("GetNewAnnualizedRate error: {}", e.what());
        return -1;
    }
}

int ca_algorithm::GetNetworkStakingRate(const uint64_t &curTime, double &stakingRate)
{
    try 
    {
        
        DBReader dbReader;
        
        uint64_t totalSupply = 0;
        int ret = getTotalCirculationAsOfTodayStart(curTime, totalSupply);
        if(ret != 0){
            ERRORLOG("Get total circulation amount failed!");
            return -1;
        }
        
        uint64_t totalLockedAmount = 0;
        ret = getLockedAmountAsOfTodayStart(curTime, totalLockedAmount);
        if(ret != 0){
            ERRORLOG("Get total locked amount failed!");
            return -1;
        }

        // 计算质押率百分比
        if (totalSupply > 0) 
        {
            stakingRate = (static_cast<double>(totalLockedAmount) / static_cast<double>(totalSupply)) * 100.0;
            
            // 确保质押率在合理范围内
            if (stakingRate < 10.0) 
            {
                stakingRate = 10.0; // 最小质押率
            } 
            else if (stakingRate > 100.0) 
            {
                stakingRate = 100.0; // 最大质押率
            }
        } 
        else 
        {
            stakingRate = 10.0; // 默认值
        }
        DEBUGLOG("totalSupply: {}, totalLockedAmount: {}, stakingRate: {}", totalSupply, totalLockedAmount, stakingRate);
        return 0;
    } 
    catch (const std::exception& e) 
    {
        ERRORLOG("GetNetworkStakingRate error: {}", e.what());
        stakingRate = 10.0; // 默认值
        return -2;
    }
}

uint64_t ca_algorithm::calculateSumHashCeilingHeight(uint64_t height)
{
    if(height == 0)
    {
        return global::ca::hashRangeSum;
    }
    auto quotient = height / global::ca::hashRangeSum;
    auto remainder = height % global::ca::hashRangeSum;
    if(remainder == 0)
    {
        return height;
    }
    else
    {
        return (quotient + 1) * global::ca::hashRangeSum;
    }
}


uint64_t ca_algorithm::get_sum_hash_floor_height(uint64_t height)
{
    auto quotient = height / global::ca::hashRangeSum;
    auto remainder = height % global::ca::hashRangeSum;
    if(remainder == 0)
    {
        return (quotient - 1) * global::ca::hashRangeSum;
    }
    else
    {
        return quotient * global::ca::hashRangeSum;
    }
}

int ca_algorithm::calculateHeightsSumHash(uint64_t blockHeight, DBReadWriter &dbWriter)
{
    if (blockHeight == 0)
    {
        return 0;
    }
    uint64_t sumHashKey = calculateSumHashCeilingHeight(blockHeight);
    if(blockHeight % global::ca::hashRangeSum != 0)
    {
        uint64_t nodeHeight = 0;
        if (DBStatus::DB_SUCCESS != dbWriter.getBlockTop(nodeHeight))
        {
            ERRORLOG("getBlockTop error!");
            return -1;
        }

        if (sumHashKey > nodeHeight)
        {
            return 0;
        }
    }

    std::string sumHash;
    auto startHeight = get_sum_hash_floor_height(blockHeight) + 1;
    auto endHeight = calculateSumHashCeilingHeight(blockHeight) + 1;
    if(!calculate_height_sum_hash(startHeight, endHeight, dbWriter, sumHash))
    {
        return -2;
    }
    if (DBStatus::DB_SUCCESS != dbWriter.setSumHashByHeight(sumHashKey, sumHash))
    {
        return -3;
    }
    INFOLOG("set height sum hash at height {} hash: {}, key: {}", blockHeight, sumHash, sumHashKey);

    return 0;
}


int ca_algorithm::recalculate_heights_sum_hash(const uint64_t newTop, const uint64_t hashHeightSum, std::string& sumHash, uint64_t blockHeight, DBReadWriter &dbWriter)
{
    auto startHeight = get_sum_hash_floor_height(blockHeight) + 1;
    uint64_t endHeight = 0;
    if(newTop + 1 == blockHeight || newTop == blockHeight)
    {
        endHeight = std::min(newTop, calculateSumHashCeilingHeight(blockHeight) + 1);
    }
    else
    {
        endHeight = calculateSumHashCeilingHeight(blockHeight) + 1;
        (endHeight > newTop) ? (endHeight = newTop) : (endHeight);
    }
    
    ERRORLOG("recalculate_heights_sum_hash start height: {}, end height: {}", startHeight, endHeight);
    if(!calculate_height_sum_hash(startHeight, endHeight, dbWriter, sumHash))
    {
        ERRORLOG("calculate_height_sum_hash error, start height: {}, end height: {}", startHeight, endHeight);
        return -1;
    }
    if (DBStatus::DB_SUCCESS != dbWriter.setSumHashByHeight(hashHeightSum, sumHash))
    {
        ERRORLOG("setSumHashByHeight error, hashHeightSum: {}, sumHash: {}", hashHeightSum, sumHash);
        return -2;
    }
    ERRORLOG("rollback set height sum hash at height {} hash: {}", hashHeightSum, sumHash);

    return 0;
}

int ca_algorithm::calculateSumHashOf1000Heights(uint64_t blockHeight, DBReadWriter &dbWriter, std::string& backHash)
{

    if(blockHeight < global::ca::sumHashRange)
    {
        return 0;
    }

    int  quotient  = blockHeight / global::ca::sumHashRange;

    //We need to determine whether one is the first thousand-height store
    std::vector<std::string> hash_of_hundred;
    if(quotient != 1)
    {
        //Take out the previous 1000 height joint hash and the current required 1000 height joint hash together to calculate a hash
        std::string Comhash;
        if(DBStatus::DB_SUCCESS != dbWriter.getThousandSumHashByBlockHeight((quotient - 1) * global::ca::sumHashRange ,Comhash))
        {
            return -1;
        }
        hash_of_hundred.push_back(Comhash);
    }

    //The combined hashes within the height of the current requirement of 1000 are counted together as a hash
    auto hashHeightSum =  (quotient - 1) * global::ca::sumHashRange;
    for(int i = 1 ; i <= 10; ++i )
    {   
        hashHeightSum += global::ca::hashRangeSum;
        std::string sumHash;
        if (DBStatus::DB_SUCCESS != dbWriter.getSumHashByHeight(hashHeightSum, sumHash))
        {    
            return -2;
        }

        hash_of_hundred.push_back(sumHash);
    }


    //The joint hash within one thousand and the joint hash of the first thousand heights calculated before are calculated as a joint hash of the new height
    std::string endComhash;
    std::sort(hash_of_hundred.begin(), hash_of_hundred.end());
    endComhash = Getsha256Hash(StringUtil::concat(hash_of_hundred, ""));

    backHash = endComhash;

    return 0;
}


int ca_algorithm::GetCommissionPercentage(const std::string& addr, double& commissionRateRet)
{
    DBReader bonusDbReader;

    std::string assetType;
    int ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
    if(ret != 0){
        ERRORLOG("Get Can BeRevoke AssetType fail!");
    }
    
    std::vector<std::string> bonusutxos; 
    ret = bonusDbReader.getStakeUtxoByAddr(addr, assetType, bonusutxos);
    if(ret != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("GetCommissionPercentage getStakeAddrUtxo error:{}", -1);
        return -1;
    }
    std::reverse(bonusutxos.begin(), bonusutxos.end());
	CTransaction tx;

    bool flag = false;
    for (auto &utxo : bonusutxos) 
	{
        std::string txRaw;
        if(DBStatus::DB_SUCCESS != bonusDbReader.getTransactionByHash(utxo, txRaw))
        {
            ERRORLOG("GetCommissionPercentage getTransactionByHash error{} ", -2);
            return -2;
        }

        tx.ParseFromString(txRaw);
        for(const auto & utxo : tx.utxos())
        {
            for (auto &vout : utxo.vout()) 
            {
                if (vout.addr() == global::ca::kTargetAddress)
                {
                    flag = true;
                    break;
                }
            }
        }
    }

    if(!flag)
    {
        ERRORLOG("GetCommissionPercentage Get Stake tx error{} ", -3);
        return -3;
    }

    nlohmann::json txInfo;
    try
    {
        nlohmann::json commissionJson = nlohmann::json::parse(tx.data());
        txInfo = commissionJson["txInfo"].get<nlohmann::json>();
    }
    catch (const std::exception&)
    {
        ERRORLOG("GetCommissionPercentage Get TxInfo error{} ", -4);
        return -4;
    }

    double commissionRate_1 = 0.0;
    try
    {
        commissionRate_1 = txInfo["commissionRate"].get<double>();
    }
    catch (...)
    {
        commissionRate_1 = global::ca::MAX_COMMISSION_RATE;
    }


    if(commissionRate_1 > global::ca::MAX_COMMISSION_RATE || commissionRate_1 < global::ca::MIN_COMMISSION_RATE)
    {
		commissionRateRet = global::ca::MAX_COMMISSION_RATE;
    }
    else
    {
        commissionRateRet = commissionRate_1;
    }

    return 0;
}



int ca_algorithm::get_call_contract_from_addr(const CTransaction& transaction, std::string& fromAddr)
{

    // std::string tx_string;
    // Util::proto_to_json(transaction,tx_string);

    // ERRORLOG("call {}",tx_string);


    for (const auto &utxo : transaction.utxos())
    {
        if(utxo.vin_size() == 0){
            //验证utxo签名            
            CTxUtxos utxo1 = utxo;
            utxo1.clear_multisign();
            std::string serializedUtxoHash = Getsha256Hash(utxo1.SerializeAsString());
            for(auto & multiSign : utxo.multisign())
            {
                fromAddr = GenerateAddr(multiSign.pub());

                int verificationResult = VerifySign(multiSign, serializedUtxoHash);
                if (verificationResult != 0)
                {
                    return -1;
                }
            }
        }else{
            for (auto &vin : utxo.vin())
            {
                if (vin.contractaddr().empty())
                {
                    if (vin.vinsign().pub().empty())
                    {
                        ERRORLOG("vin.vinsign().pub() is empty");
                        return -2;
                    }
                    CTxInput copyVin_ = vin;
                    copyVin_.clear_vinsign();
                    int verificationResult = VerifySign(vin.vinsign(), Getsha256Hash(copyVin_.SerializeAsString()));
                    if (verificationResult != 0)
                    {
                        ERRORLOG("VerifySign fail ret : {}", verificationResult);
                        return -3;
                    }
                    fromAddr = GenerateAddr(vin.vinsign().pub());
                    break;
                }
            }
        }
    }

    if (fromAddr.empty())
    {
        ERRORLOG("fail to parse fromaddr");
        return -3;
    }
    return 0;
}

void ca_algorithm::GetAddrType(std::string& addr, std::vector<std::pair<std::string, bool>> &vecAddrType)
{
    DBReader dbReader;
    std::vector<std::string> utxos;
    DBStatus::DB_SUCCESS == dbReader.getLockAddrUtxo(addr, global::ca::ASSET_TYPE_OHI, utxos)
        ? vecAddrType.emplace_back(std::make_pair("Locked", true)) : vecAddrType.emplace_back(std::make_pair("Locked", false));

    utxos.clear();
    std::string assetType;
    auto ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
    if(ret != 0)
    {
        vecAddrType.emplace_back(std::make_pair("Staked", false));
    }
    else 
    {
        DBStatus::DB_SUCCESS == dbReader.getStakeUtxoByAddr(addr, assetType, utxos) ? 
            vecAddrType.emplace_back(std::make_pair("Staked", true)) : vecAddrType.emplace_back(std::make_pair("Staked", false));
    }


    utxos.clear();
    std::multimap<std::string, std::string> bonusAddr_assetType;
    bool find_bonusAddr = DBStatus::DB_SUCCESS == dbReader.getBonusAddrAndAssetTypeByDelegatingAddr(addr, bonusAddr_assetType);
    vecAddrType.emplace_back(std::make_pair("Delegatinged", find_bonusAddr));

	uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    std::map<std::string, uint64_t> companyDividend;
    ret = ca_algorithm::CalcBonusValue(curTime, addr, companyDividend);
    if(ret != 0)
    {
        vecAddrType.emplace_back(std::make_pair("Bonus", false));
        vecAddrType.emplace_back(std::make_pair("Qualified", false));
        return;
    }

	ret = CheckNodeValidity(addr);
	if(ret != 0)
	{
        vecAddrType.emplace_back(std::make_pair("Bonus", false));
        vecAddrType.emplace_back(std::make_pair("Qualified", false));
		return;
	}

	ret = evaluateBonusEligibility(addr, curTime);
    ret == 0 ? vecAddrType.emplace_back(std::make_pair("Bonus", true)) : vecAddrType.emplace_back(std::make_pair("Bonus", false));

    vecAddrType.emplace_back(std::make_pair("Qualified", true));
}

//根据合约地址获取资产类型
int ca_algorithm::GetAsseTypeByContractAddr(const std::string& contractAddr, std::string& assetType)
{
    DBReadWriter db;
    auto dbRet = db.getAssetTypeByContractAddr(contractAddr, assetType);
    if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("getAssetTypeByContractAddr, error num:{}, contractAddr:{}", dbRet, contractAddr);
        return -1;
    }

    return 0;
}


//获取当前可用投票的资产
int ca_algorithm::GetVoteAssetType(std::map<std::string, TxHelper::VoteInfo>& voteAsset)
{
    DBReadWriter db;
    std::vector<std::string> ASSERT_TYPES;
    auto dbRet = db.getAssetType(ASSERT_TYPES);
    if(dbRet == DBStatus::DB_NOT_FOUND)
    {
        return 0;
    }
    else if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("VoteCache error -1, getAssetType error, error num:{}", dbRet);
        return -2;
    }

    uint64_t time = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    for(const auto& t: ASSERT_TYPES)
    {
        std::string info;
        dbRet = db.getProposalInfoByAssetType(t, info);
        if(DBStatus::DB_SUCCESS != dbRet)
        {
            ERRORLOG("getProposalInfoByAssetType error, error num: {}, type:{}", dbRet, t); 
            return -3;
        }
        
        std::string decode = Base64Decode(info);
        nlohmann::json dataJson = nlohmann::json::parse(decode);
        uint64_t beginTime = dataJson["beginTime"].get<uint64_t>();
        uint64_t endTime = dataJson["endTime"].get<uint64_t>();
        std::string decodeName = dataJson["name"].get<std::string>();
        if(time >= beginTime && time < endTime)
        { 
            TxHelper::VoteInfo proposalInfo;
            nlohmann::json dataJson = nlohmann::json::parse(decode);
            proposalInfo.TxType = (uint32_t)global::ca::TxType::PROPOSAL;
            proposalInfo.AssetName = Base64Decode(decodeName);
            proposalInfo.ExchangeRate = dataJson["exchangeRate"].get<std::string>();
            proposalInfo.BeginTime = beginTime;
            proposalInfo.EndTime = endTime;
            proposalInfo.CrossChainTxType = dataJson["crossChainTxType"].get<int>();
            proposalInfo.ContractAddr = dataJson["tokenContractAddr"].get<std::string>();
            proposalInfo.CrossChainInvestmentContractAddr = dataJson["crossChainInvestmentContractAddr"].get<std::string>();
            proposalInfo.ProposalHash = "";
            proposalInfo.PeerChainTokenAddr = dataJson["peerChainTokenAddr"].get<std::string>();
            proposalInfo.MIN_VOTE_NUM = dataJson["minVoteNum"].get<uint64_t>();
            voteAsset.insert(std::make_pair(t, std::move(proposalInfo)));
            continue;
        }
        
        if(time >= endTime)
        {
            std::vector<std::string> revokeTxHashs;
            auto dbRet = db.getRevokeTxHashByAssetType(t, revokeTxHashs);
            if(dbRet == DBStatus::DB_NOT_FOUND)
            {
                continue;
            }
            else if(dbRet != DBStatus::DB_SUCCESS)
            {
                ERRORLOG("getRevokeTxHashByAssetType error, error num:{}", dbRet);
                return -4;
            }

            std::string revokeInfo;
            dbRet = db.getRevokeProposalInfoByAssetType(*revokeTxHashs.rbegin(), revokeInfo);
            if(DBStatus::DB_SUCCESS != dbRet)
            {
                ERRORLOG("getRevokeProposalInfoByAssetType error, ret = {}", dbRet);
                return -5;
            }
            
            std::string decode2 = Base64Decode(revokeInfo);
            nlohmann::json dataJson2 = nlohmann::json::parse(decode2);
            uint64_t beginTime2 = dataJson2["beginTime"].get<uint64_t>();
            uint64_t endTime2 = dataJson2["endTime"].get<uint64_t>();
            std::string proposalHash = dataJson2["proposalHash"].get<std::string>();
            if(time >= beginTime2 && time < endTime2)
            {
                if(proposalHash != t)
                {
                    ERRORLOG("{}, {}", proposalHash, t);
                    return -6;
                }
                TxHelper::VoteInfo revokeProposalInfo;
                revokeProposalInfo.TxType = (uint32_t)global::ca::TxType::REVOKEPROPOSAL;
                revokeProposalInfo.AssetName = Base64Decode(decodeName);
                revokeProposalInfo.ExchangeRate = dataJson["exchangeRate"].get<std::string>();
                revokeProposalInfo.BeginTime = beginTime2;
                revokeProposalInfo.EndTime = endTime2;
                revokeProposalInfo.CrossChainTxType = dataJson["crossChainTxType"].get<int>();
                revokeProposalInfo.ContractAddr = dataJson["tokenContractAddr"].get<std::string>();
                revokeProposalInfo.CrossChainInvestmentContractAddr = dataJson["crossChainInvestmentContractAddr"].get<std::string>();
                revokeProposalInfo.ProposalHash = t;
                revokeProposalInfo.PeerChainTokenAddr = dataJson["peerChainTokenAddr"].get<std::string>();
                revokeProposalInfo.MIN_VOTE_NUM = dataJson2["minVoteNum"].get<uint64_t>();
                voteAsset.insert(std::make_pair(*revokeTxHashs.rbegin(), std::move(revokeProposalInfo)));
            }
        }
    }
    return 0;
}


int ca_algorithm::AssetTypeIsOHI(const std::string& assetType)
{
    DBReadWriter db;
    std::string info;
    auto dbRet = db.getProposalInfoByAssetType(assetType, info);
    if(DBStatus::DB_SUCCESS != dbRet)
    {
        ERRORLOG("getProposalInfoByAssetType error, error num: {}, type:{}", dbRet, assetType); 
        return -1;
    }
    
    std::string decode = Base64Decode(info);
    nlohmann::json dataJson = nlohmann::json::parse(decode);

    if(dataJson["genesisToken"].get<uint64_t>() == 1)
    {
        return 0;
    }

    return -2;
}

int ca_algorithm::GetAssetTypeIsValid(const std::string& assetType, TxHelper::ProposalInfo* proposalInfo)
{
    DBReadWriter db;
    bool flag = false;

    std::string info;
    auto dbRet = db.getProposalInfoByAssetType(assetType, info);
    if(DBStatus::DB_SUCCESS != dbRet)
    {
        ERRORLOG("getProposalInfoByAssetType error, error num: {}, type:{}", dbRet, assetType); 
        return -1;
    }
    
    std::string decode = Base64Decode(info);
    nlohmann::json dataJson = nlohmann::json::parse(decode);
    uint64_t beginTime = dataJson["beginTime"].get<uint64_t>();
    uint64_t endTime = dataJson["endTime"].get<uint64_t>();
    uint64_t expirationDate = dataJson["expirationDate"].get<uint64_t>();
    uint64_t minVote = dataJson["minVoteNum"].get<std::uint64_t>();
    
    uint64_t time = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    if(time <= endTime || time > expirationDate)
    {
        ERRORLOG("The vote is not over, time:{}, endTime:{}", time, endTime);
        return -2;
    }

    uint64_t approveNum = 0;
    uint64_t againstNum = 0;
    int ret = ca_algorithm::GetVoteNum(db, assetType, approveNum, againstNum);
    if(0 != ret)
    {
        ERRORLOG("GetVoteNum error, error num: ", ret);
        return -3;
    }

    uint64_t totalNumberOfVoters = 0;
    dbRet = db.getTotalCountByAssetType(assetType, totalNumberOfVoters);
    if(dbRet == DBStatus::DB_NOT_FOUND)
    {
        totalNumberOfVoters = 0;
    }
    else if(dbRet != DBStatus::DB_SUCCESS)
    {
        INFOLOG("getTotalCountByAssetType error {}", dbRet);
        return -4;
    }

    if(totalNumberOfVoters < minVote)
    {
        ERRORLOG("Proposal The vote num is not enough, totalNumberOfVoters:{}, minVote:{}", totalNumberOfVoters, minVote);
        return -5;
    }
    if(approveNum <= againstNum)
    {
        ERRORLOG("The vote failed, approveNum:{}, againstNum:{}", approveNum, againstNum);
        return -6;
    }

    ON_SCOPE_EXIT
    {
        if(flag && proposalInfo)
        {
            nlohmann::json dataJson = nlohmann::json::parse(decode);
            std::string decodeName = dataJson["name"].get<std::string>();
            proposalInfo->Name = Base64Decode(decodeName);
            proposalInfo->ExchangeRate = dataJson["exchangeRate"].get<std::string>();
            proposalInfo->ContractAddr = dataJson["tokenContractAddr"].get<std::string>();
            proposalInfo->CrossChainTxType = dataJson["crossChainTxType"].get<int>();
            proposalInfo->ContractAddr = dataJson["tokenContractAddr"].get<std::string>();
            proposalInfo->CrossChainInvestmentContractAddr = dataJson["crossChainInvestmentContractAddr"].get<std::string>();
            proposalInfo->BeginTime = beginTime;
            proposalInfo->EndTime = endTime;
            proposalInfo->version = dataJson["version"].get<double>();
            proposalInfo->canBeStake = dataJson["genesisToken"].get<uint64_t>();
            proposalInfo->MIN_VOTE_NUM = minVote;
            std::string decodeTitle = dataJson["title"].get<std::string>();
            std::string decodeIdentifier = dataJson["identifier"].get<std::string>();
            proposalInfo->Title = Base64Decode(decodeTitle);
            proposalInfo->Identifier = Base64Decode(decodeIdentifier);
        }
    };

    std::vector<std::string> revokeTxHashs;
    dbRet = db.getRevokeTxHashByAssetType(assetType, revokeTxHashs);
    if(dbRet == DBStatus::DB_NOT_FOUND)
    {
        flag = true;
        return 0;
    }
    else if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("getRevokeTxHashByAssetType error, error num:{}", dbRet);
        return -7;
    }

    std::string revokeInfo;
    dbRet = db.getRevokeProposalInfoByAssetType(*revokeTxHashs.rbegin(), revokeInfo);
    if(DBStatus::DB_SUCCESS != dbRet)
    {
        ERRORLOG("getRevokeProposalInfoByAssetType error, ret = {}", dbRet);
        return -8;
    }
    
    std::string decode2 = Base64Decode(revokeInfo);
    nlohmann::json dataJson2 = nlohmann::json::parse(decode2);
    uint64_t endTime2 = dataJson2["endTime"].get<uint64_t>();
    uint64_t minVoteThreshold = dataJson2["minVoteNum"].get<std::uint64_t>();
    if(time <= endTime2)    //撤销提案没结束时 当前提案还可以继续使用
    {
        flag = true;
        return 0;
    }

    ret = ca_algorithm::GetVoteNum(db, *revokeTxHashs.rbegin(), approveNum, againstNum);
    if(0 != ret)
    {
        ERRORLOG("GetVoteNum error, error num: ", ret);
        return -9;
    }

    uint64_t totalNumberOfVoters2 = 0;
    dbRet = db.getTotalCountByAssetType(*revokeTxHashs.rbegin(), totalNumberOfVoters2);
    if(dbRet == DBStatus::DB_NOT_FOUND)
    {
        totalNumberOfVoters2 = 0;
    }
    else if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("getTotalCountByAssetType error {}", dbRet);
        return -10;
    }

    if(totalNumberOfVoters2 < minVoteThreshold)
    {
        INFOLOG("RevokeProposal The vote num is not enough, totalNumberOfVoters2:{}, minVote:{}", totalNumberOfVoters2, minVoteThreshold);
        flag = true;
        return 0;
    }

    if(againstNum >= approveNum)
    {
        flag = true;
        return 0;
    }

    INFOLOG("time:{}, endTime2:{}, approveNum:{}, againstNum:{}",time, endTime2, approveNum, againstNum);
    return -11;
}

//获取所有可用资产
int ca_algorithm::fetchAvailableAssetType(std::map<std::string, TxHelper::ProposalInfo>& assetMap)
{
    DBReadWriter db;
    std::vector<std::string> ASSERT_TYPES;
    auto dbRet = db.getAssetType(ASSERT_TYPES);
    if(dbRet == DBStatus::DB_NOT_FOUND)
    {
        return -1;
    }
    else if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("VoteCache error -1, getAssetType error, error num:{}", dbRet);
        return -2;
    }

    int ret = -1;
    for(const auto& t: ASSERT_TYPES)
    {
        TxHelper::ProposalInfo info;
        ret = GetAssetTypeIsValid(t, &info);   
        if(ret == 0)
        {
            assetMap.insert(std::make_pair(t, info));
        }
    }

    return 0;
}

int ca_algorithm::GetUnavailableAssetType(std::vector<std::string>& assetList)
{
    DBReadWriter db;
    std::vector<std::string> ASSERT_TYPES;
    auto dbRet = db.getAssetType(ASSERT_TYPES);
    if(dbRet == DBStatus::DB_NOT_FOUND)
    {
        return -1;
    }
    else if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("VoteCache error -1, getAssetType error, error num:{}", dbRet);
        return -2;
    }

    int ret = -1;
    for(const auto& t: ASSERT_TYPES)
    {
        ret = GetAssetTypeIsValid(t, nullptr);
        if(ret != 0)
        {
            assetList.emplace_back(t);
        }
    }

    return 0;
}

int ca_algorithm::GetAssetRate(const std::string& contractAddr, std::string& ExchangeRate)
{
    std::map<std::string, TxHelper::ProposalInfo> assetMap;
    DBReadWriter db;
    std::vector<std::string> ASSERT_TYPES;
    auto dbRet = db.getAssetType(ASSERT_TYPES);
    if(dbRet == DBStatus::DB_NOT_FOUND)
    {
        return -1;
    }
    else if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("VoteCache error -1, getAssetType error, error num:{}", dbRet);
        return -2;
    }

    int ret = -1;
    for(const auto& t: ASSERT_TYPES)
    {
        TxHelper::ProposalInfo info;
        ret = ca_algorithm::GetProposalInfo(t, info);   
        if(ret == 0)
        {
            assetMap.insert(std::make_pair(t, info));
        }
    }
    
	for (const auto& asset : assetMap) 
	{
        if(asset.second.ContractAddr == contractAddr)
        {
            ExchangeRate = asset.second.ExchangeRate;
            break;
        }
    }
    return 0;
}

void ca_algorithm::GetAllMappedAssets()
{
	DBReader dbReader;
    std::map<std::string, TxHelper::ProposalInfo> assetMap;
    if (ca_algorithm::fetchAvailableAssetType(assetMap) != 0)
    {
        return;
    }

	std::vector<std::string> asset_type_list;
	for (const auto& asset : assetMap) 
	{
        std::string assetType;
        if(ca_algorithm::GetAsseTypeByContractAddr(asset.second.ContractAddr, assetType) != 0)
        {
            return;
        }
        asset_type_list.push_back(assetType);
    }
    using namespace std;
    std::string addr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
   // cout << "*********************************************************************************" << endl;
    CaConsole infoColor(CONSOLE_COLOR_GREEN, CONSOLE_COLOR_BLACK, true);
    for(const auto& assetType : asset_type_list)
    {
        uint64_t balance = 0;
        if(get_balance_by_utxo(addr, assetType, balance) != 0)
        {
            balance = 0;
        }
        if(balance > 0)
        {
            double d = balance / double(100000000);   
            std::ostringstream oss;
            TxHelper::ProposalInfo info;
            GetProposalInfo(assetType, info);
            double rate = std::stod(info.ExchangeRate);

            oss << "Asset: 0x" << assetType << "  Name: " << info.Name << "  Exchange rate: " << setiosflags(ios::fixed) << setprecision(8) << rate;
            cout << oss.str() << "  Balance: " << setiosflags(ios::fixed) << setprecision(8) << d << endl;
        }
    }
   // cout << "*********************************************************************************" << endl;

    std::vector<std::string> unavaliableAsset;
    auto ret = ca_algorithm::GetUnavailableAssetType(unavaliableAsset);
    if(ret != 0)
    {
        ERRORLOG("GetUnavailableAssetType error, code:{}", ret);
        return;
    }

    asset_type_list.clear();
    auto currentTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	for (const auto& asset : unavaliableAsset) 
	{
        std::string assetType;
        TxHelper::ProposalInfo info;
        ca_algorithm::GetProposalInfo(asset, info);
        if(ca_algorithm::GetAsseTypeByContractAddr(info.ContractAddr, assetType) != 0)
        {
            return;
        }
        if(info.EndTime > currentTime)
        {
            continue;
        }
        asset_type_list.push_back(assetType);
    }
    if(asset_type_list.empty())
    {
        return;
    }
    std::cout << "Proposal that has been withdrawn: " << std::endl;
    for(const auto& assetType : asset_type_list)
    {
        uint64_t balance = 0;
        if(get_balance_by_utxo(addr, assetType, balance) != 0)
        {
            balance = 0;
        }
        if(balance > 0)
        {
            double d = balance / double(100000000);   
            std::ostringstream oss;
            TxHelper::ProposalInfo info;
            GetProposalInfo(assetType, info);
            double rate = std::stod(info.ExchangeRate);

            oss << "Asset: 0x" << assetType << "  Name: " << info.Name << "  Exchange rate: " << setiosflags(ios::fixed) << setprecision(8) << rate;
            cout << oss.str() << "  Balance: " << setiosflags(ios::fixed) << setprecision(8) << d << endl;
        }
    }
    //cout << "*********************************************************************************" << endl;
}

int ca_algorithm::canBeRevoked(const std::string& assetType)
{
    DBReadWriter db;
    std::vector<std::string> revokeTxHashs;
    auto dbRet = db.getRevokeTxHashByAssetType(assetType, revokeTxHashs);
    if(dbRet == DBStatus::DB_NOT_FOUND)
    {
        return 0;
    }
    else if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("getRevokeTxHashByAssetType error, error num:{}", dbRet);
        return -5;
    }

    std::string revokeInfo;
    dbRet = db.getRevokeProposalInfoByAssetType(*revokeTxHashs.rbegin(), revokeInfo);
    if(DBStatus::DB_SUCCESS != dbRet)
    {
        ERRORLOG("getRevokeProposalInfoByAssetType error, ret = {}", dbRet);
        return -5;
    }
    
    std::string decode = Base64Decode(revokeInfo);
    nlohmann::json dataJson = nlohmann::json::parse(decode);
    uint64_t endTime = dataJson["endTime"].get<uint64_t>();
    uint64_t time = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    if(time <= endTime)
    {
        ERRORLOG("There are outstanding revoke proposal, hash: {}, time: {}, endTime: {}", *revokeTxHashs.rbegin(), time, endTime);
        return -6;
    }

    return 0;
}

int ca_algorithm::CheckProposaInfo(std::string& rate, std::string& contractAddr, std::string& crossChainInvestmentContractAddr, global::ca::CrossChainTxType taskType, uint64_t minVote, std::string& assetName, std::string& peerChainTokenAddr)
{

    boost::multiprecision::cpp_bin_float_100 num(rate);
    if(num < global::ca::KLowestExchangeRate)
    {
        ERRORLOG("rate error: {}", rate);
        return -1;
    }

    const std::regex pattern(R"(\b\d+(\.\d{1,8})?\b)");
    if (!std::regex_match(rate, pattern))
    {
        ERRORLOG("rate error : {}", rate);
        return -2;
    }

    DBReader db;
    
    auto checkContractAddr = [&](const std::string& addr, int errorCode, const std::string& name) -> int {
        std::string deployUtxoInfo;
        auto dbRet = db.getContractDeployUtxoByContractAddr(addr, deployUtxoInfo);
        if (dbRet != DBStatus::DB_SUCCESS || deployUtxoInfo.empty()) {
            ERRORLOG("{} not found: {}", name, addr);
            return errorCode;
        }
        return 0;
    };

    switch (taskType) 
    {
        case global::ca::CrossChainTxType::EnteringMore:
        {
            int ret = checkContractAddr(contractAddr, -3, "Contract address");
            if (ret != 0) return ret;
            break;
        }
        case global::ca::CrossChainTxType::CrossChainInvestment:
        {
            int ret = checkContractAddr(crossChainInvestmentContractAddr, -4, "crossChainInvestmentContractAddr");
            if (ret != 0) return ret;
            break;
        }
        case global::ca::CrossChainTxType::Both:
        {
            int ret = checkContractAddr(contractAddr, -5, "Contract address");
            if (ret != 0) return ret;

            ret = checkContractAddr(crossChainInvestmentContractAddr, -6, "crossChainInvestmentContractAddr");
            if (ret != 0) return ret;

            if (contractAddr == crossChainInvestmentContractAddr) 
            {
                ERRORLOG("contractAddr = crossChainInvestmentContractAddr:{}", contractAddr);
                return -7;
            }
            break;
        }
        default:
        {
            ERRORLOG("Invalid task type: {}", static_cast<int>(taskType));
            return -8;
        }
    }

    if(taskType == global::ca::CrossChainTxType::EnteringMore || taskType == global::ca::CrossChainTxType::Both)
    {
        std::string assetType;
        int ret = GetAsseTypeByContractAddr(contractAddr, assetType);
        if(ret == 0)
        {
            ERRORLOG("contractAddr:{} has already been proposed, Proposal hash:{}", contractAddr, assetType);
            return -9;
        }
    }

    if(minVote < 1)
    {
        ERRORLOG("minVote mest more then 1, minVote:{}", minVote);
        return -10;
    }

    ca_algorithm::Trim(assetName);
    std::vector<std::string> assetTypes;

    auto dbRet = db.getAssetType(assetTypes);
    if(dbRet == DBStatus::DB_NOT_FOUND)
    {
        return 0;
    }
    else if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("getAssetType error, error num:{}", dbRet);
        return -11;
    }

    uint64_t time = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    for(const auto& type : assetTypes)
    {
        std::string info;
        dbRet = db.getProposalInfoByAssetType(type, info);
        if(DBStatus::DB_SUCCESS != dbRet)
        {
            ERRORLOG("getProposalInfoByAssetType error, error num: {}, type:{}", dbRet, type); 
            return -12;
        }
        
        std::string decode = Base64Decode(info);
        nlohmann::json dataJson = nlohmann::json::parse(decode);
        std::string decodeName = dataJson["name"].get<std::string>();
        std::string name = Base64Decode(decodeName);

        if(name == assetName)
        {
            ERRORLOG("name:{}, assetName:{}", name, assetName);
            return -13;
        }

        uint64_t endTime = dataJson["endTime"].get<uint64_t>();
        int isValid = GetAssetTypeIsValid(type);

        if(taskType == global::ca::CrossChainTxType::CrossChainInvestment || taskType == global::ca::CrossChainTxType::Both)
        {
            std::string addr = dataJson["crossChainInvestmentContractAddr"].get<std::string>();
            if(addr == crossChainInvestmentContractAddr)
            {
                if(isValid == 0)
                {
                    ERRORLOG("There are available crossChainInvestmentContractAddr 1, assetType:{}", type);
                    return -14;
                }
                if(endTime > time)
                {
                    ERRORLOG("There are available crossChainInvestmentContractAddr 2, assetType:{}", type);
                    return -15;
                }
            }
        }
        
        std::string tokenAddr = dataJson["peerChainTokenAddr"].get<std::string>();
        if(tokenAddr == peerChainTokenAddr)
        {
            if(isValid == 0)
            {
                ERRORLOG("There are available peerChainTokenAddr 1, assetType:{}", type);
                return -16;
            }
            if(endTime > time)
            {
                ERRORLOG("There are available peerChainTokenAddr 2, assetType:{}", type);
                return -17;
            }
        }

    }

    if(assetName.size() > 1024)
    {
        ERRORLOG("assetName is too long, size: ", assetName.size());
        return -18;
    }

    const std::regex patternName("^[0-9A-Za-z]+$");
    if (!std::regex_match(assetName, patternName))
    {
        ERRORLOG("assetName error:{}", assetName);
        return -19;
    }
    
    const std::regex patternToken(R"(^(0x[0-9a-fA-F]{64}|[0-9a-fA-F]{64})$)");
    if (!std::regex_match(peerChainTokenAddr, patternToken))
    {
        ERRORLOG("peerChainTokenAddr error:{}", peerChainTokenAddr);
        return -20;
    }

    return 0;
}


//赞成票数量，反对票数量
int ca_algorithm::GetVoteNum(DBReadWriter& db, const std::string &assetType, uint64_t &approveNum, uint64_t &againstNum)
{
    if (__builtin_expect(assetType.empty(), 0))
    {
        return -1;
    }

    if(DBStatus::DB_SUCCESS != db.getVoteCountByAssetType(assetType, approveNum, againstNum))
    {
        ERRORLOG("getVoteCountByAssetType error");
        return -2;
    }

    return 0;
}

//检查是否重复投票
int ca_algorithm::CheckForDuplicateVotes(const std::string &assetType, const std::string addr)
{
    if (__builtin_expect(assetType.empty(), 0))
    {
        return -1;
    }
    if (__builtin_expect(addr.empty(), 0))
    {
        return -2;
    }

    DBReadWriter db;
    std::set<std::string> addrs;
    auto dbRet = db.getApproveAddrsByAssetType(assetType, addrs);
    if(dbRet != DBStatus::DB_SUCCESS && dbRet != DBStatus::DB_NOT_FOUND)
    {
        ERRORLOG("getApproveAddrsByAssetType error");
        std::cout << "dbRet: " << (int)dbRet << std::endl;
        return -3;
    }

    auto find = addrs.find(addr);
    if(find != addrs.end())
    {
        ERRORLOG("Approve Duplicate Votes");
        return -4;
    }

    addrs.clear();
    dbRet = db.getAgainstAddrsByAssetType(assetType, addrs);
    if(dbRet != DBStatus::DB_SUCCESS && dbRet != DBStatus::DB_NOT_FOUND)
    {
        ERRORLOG("getAgainstAddrsByAssetType error");
        std::cout << "dbRet: " << (int)dbRet << std::endl;
        return -5;
    }

    find = addrs.find(addr);
    if(find != addrs.end())
    {
        ERRORLOG("Against Duplicate Votes");
        return -6;
    }

    return 0;
}


//票数量+1，并添加投票ID    反对票数_赞成票数
int ca_algorithm::addVoteCount(DBReadWriter& db, const std::string &assetType, const int voteType, const std::string& addr, const uint64_t& voteNumber)
{
    if (__builtin_expect(assetType.empty(), 0))
    {
        return -1;
    }
    if (__builtin_expect(addr.empty(), 0))
    {
        return -2;
    }

    int ret = ca_algorithm::CheckForDuplicateVotes(assetType, addr);
    if(0 != ret)
    {
        ERRORLOG("addVoteCount CheckForDuplicateVotes error, error num: {}", ret);
        return -3;
    }

    uint64_t approveNum = 0;
    uint64_t againstNum = 0;
    ret = ca_algorithm::GetVoteNum(db, assetType, approveNum, againstNum);
    if(0 != ret)
    {
        ERRORLOG("addVoteCount GetVoteNum error, error num: {}", ret);
        return -4;
    }

    if((int)global::ca::VoteType::Approve == voteType)
    {
        approveNum += voteNumber;
        if(DBStatus::DB_SUCCESS != db.setApproveAddrsByAssetType(assetType, addr))
        {
            ERRORLOG("setApproveAddrsByAssetType error");
            return -5;
        }
    }
    else if((int)global::ca::VoteType::Against == voteType)
    {
        againstNum += voteNumber;
        if(DBStatus::DB_SUCCESS != db.setAgainstAddrsByAssetType(assetType, addr))
        {
            ERRORLOG("setAgainstAddrsByAssetType error");
            return -6;
        }
    }
    else
    {
        ERRORLOG("voteType error, voteType: {}", voteType);
        return -7;
    }

    if(DBStatus::DB_SUCCESS != db.setVoteCountByAssetType(assetType, approveNum, againstNum))
    {
        ERRORLOG("addVoteCount setVoteCountByAssetType error");
        return -8;
    }

    if(DBStatus::DB_SUCCESS != db.setVoteCountByAddr(addr, assetType, voteNumber))
    {
        ERRORLOG("addVoteCount setVoteCountByAddr error");
        return -9;
    }
    
    uint64_t totalNumberOfVoters = 0;
    auto dbRet = db.getTotalCountByAssetType(assetType, totalNumberOfVoters);
    if(dbRet == DBStatus::DB_NOT_FOUND)
    {
        totalNumberOfVoters = 0;
    }
    else if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("addVoteCount getTotalCountByAssetType error {}", dbRet);
        return -14;
    }

    if(DBStatus::DB_SUCCESS != db.setTotalCountByAssetType(assetType, ++totalNumberOfVoters))
    {
        ERRORLOG("addVoteCount setTotalCountByAssetType error");
        return -15;
    }

    return 0;
}

//票数量-1，并删除投票ID
int ca_algorithm::subVoteNum(DBReadWriter& db, const std::string &assetType, const int voteType, const std::string& addr, const uint64_t& voteNumber)
{
    if (__builtin_expect(assetType.empty(), 0))
    {
        return -1;
    }
    if (__builtin_expect(addr.empty(), 0))
    {
        return -2;
    }

    uint64_t approveNum = 0;
    uint64_t againstNum = 0;
    int ret = ca_algorithm::GetVoteNum(db, assetType, approveNum, againstNum);
    if(0 != ret)
    {
        ERRORLOG("subVoteNum GetVoteNum error, error num: ", ret);
        return -3;
    }

    uint64_t voteNum = 0;
    if(DBStatus::DB_SUCCESS != db.getVoteCountByAddr(addr, assetType, voteNum))
    {
        ERRORLOG("subVoteNum getVoteCountByAddr error");
        return -4;
    }

    if(voteNum != voteNumber)
    {
        ERRORLOG("subVoteNum voteNum:{}  voteNumber:{}", voteNum, voteNumber);
        return -5;
    }

    if((int)global::ca::VoteType::Approve == voteType)
    {
        if(approveNum < voteNum)
        {
            ERRORLOG("approveNum error");
            return -6;
        }
        approveNum -= voteNum;
        if(DBStatus::DB_SUCCESS != db.removeApproveAddrsByAssetType(assetType, addr))
        {
            ERRORLOG("subVoteNum removeApproveAddrsByAssetType error");
            return -7;
        }
    }
    else if((int)global::ca::VoteType::Against == voteType)
    {
        if(againstNum < voteNum)
        {
            ERRORLOG("againstNum error");
            return -8;
        }
        againstNum -= voteNum;
        if(DBStatus::DB_SUCCESS != db.removeAgainstAddrsByAssetType(assetType, addr))
        {
            ERRORLOG("subVoteNum removeAgainstAddrsByAssetType error");
            return -9;
        }
    }
    else
    {
        ERRORLOG("subVoteNum voteType error, voteType: {}", voteType);
        return -10;
    }

    if(DBStatus::DB_SUCCESS != db.setVoteCountByAssetType(assetType, approveNum, againstNum))
    {
        ERRORLOG("subVoteNum setVoteCountByAssetType error"); 
        return -11;
    }

    if(DBStatus::DB_SUCCESS != db.removeVoteCountByAddr(addr, assetType))
    {
        ERRORLOG("subVoteNum addVoteCount removeVoteCountByAddr error");
        return -12;
    }

    uint64_t totalNumberOfVoters = 0;
    auto dbRet = db.getTotalCountByAssetType(assetType, totalNumberOfVoters);
    if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("subVoteNum getTotalCountByAssetType error {}", dbRet);
        return -13;
    }

    if(totalNumberOfVoters == 0)
    {
        ERRORLOG("subVoteNum totalNumberOfVoters error");
        return -14;
    }

    --totalNumberOfVoters;

    if(totalNumberOfVoters == 0 && DBStatus::DB_SUCCESS != db.removeTotalNumberOfVotersByAssetHash(assetType))
    {
        ERRORLOG("subVoteNum removeTotalNumberOfVotersByAssetHash error");
        return -15;
    }
    else if(DBStatus::DB_SUCCESS != db.setTotalCountByAssetType(assetType, totalNumberOfVoters))
    {
        ERRORLOG("subVoteNum setTotalCountByAssetType error");
        return -16;
    }

    return 0;
}

int ca_algorithm::CheckVoteTxInfo(const std::string& voteHash, uint32_t voteTxType, int pollType, uint64_t currentTime, global::ca::SaveType saveType)
{
	if(pollType != (int)global::ca::VoteType::Against && pollType != (int)global::ca::VoteType::Approve)
	{
		ERRORLOG("pollType error, pollType: {}", pollType);
		return -1;
	}

    DBReadWriter db;
    uint64_t beginTime, endTime;
    int ret = -1;
	if((uint32_t)global::ca::TxType::PROPOSAL == voteTxType)
	{
        std::string info;
        auto dbRet = db.getProposalInfoByAssetType(voteHash, info);
        if(DBStatus::DB_SUCCESS != dbRet)
        {
            ERRORLOG("getProposalInfoByAssetType error, error num: {}, type:{}", dbRet, voteHash); 
            return -2;
        }
        
        std::string decode = Base64Decode(info);
        nlohmann::json dataJson = nlohmann::json::parse(decode);
        beginTime = dataJson["beginTime"].get<uint64_t>();
        endTime = dataJson["endTime"].get<uint64_t>();
	}
	else if((uint32_t)global::ca::TxType::REVOKEPROPOSAL == voteTxType)
	{
        std::string revokeInfo;
        auto dbRet = db.getRevokeProposalInfoByAssetType(voteHash, revokeInfo);
        if(DBStatus::DB_SUCCESS != dbRet)
        {
            ERRORLOG("getRevokeProposalInfoByAssetType error, ret = {}", dbRet);
            return -3;
        }
        
        std::string decode = Base64Decode(revokeInfo);
        nlohmann::json dataJson = nlohmann::json::parse(decode);
        std::string proposalHash = dataJson["proposalHash"].get<std::string>();
        beginTime = dataJson["beginTime"].get<uint64_t>();
        endTime = dataJson["endTime"].get<uint64_t>();
        if(saveType != global::ca::SaveType::SyncNormal)
        {
            ret = GetAssetTypeIsValid(proposalHash);
            if(ret != 0)
            {
                ERRORLOG("GetAssetTypeIsValid error, error num: {}, type:{}", ret, proposalHash); 
                return -4;
            }
        }
	}
	else
	{
		ERRORLOG("voteTxType error, voteTxType: {}", (int)voteTxType);
		return -5;
	}

    if(currentTime < beginTime || currentTime >= endTime)
	{
		ERRORLOG("vote finished, currentTime:{}, endTime{}", currentTime, endTime);
		return -6;
	}

    return 0;
}

int ca_algorithm::GetCrossChainInvestmentContractAddrByAssetType(const std::string& assetType, std::string &crossChainInvestmentContractAddr)
{
    DBReader db;
    std::string info;
    auto dbRet = db.getProposalInfoByAssetType(assetType, info);
    if(DBStatus::DB_SUCCESS != dbRet)
    {
        ERRORLOG("getProposalInfoByAssetType error, error num: {}, type:{}", dbRet, assetType); 
        return -1;
    }
    
    std::string decode = Base64Decode(info);
    nlohmann::json dataJson = nlohmann::json::parse(decode);
    auto crossChainTxType = (global::ca::CrossChainTxType)dataJson["crossChainTxType"].get<int>();

    if(crossChainTxType == global::ca::CrossChainTxType::CrossChainInvestment || crossChainTxType == global::ca::CrossChainTxType::Both)
    {
        crossChainInvestmentContractAddr = dataJson["crossChainInvestmentContractAddr"].get<std::string>();
        return 0;
    }

    ERRORLOG("crossChainTxType error, crossChainTxType:{}", (int)crossChainTxType);
    return -2;
}

int ca_algorithm::GetProposalInfo(const std::string& assetType, TxHelper::ProposalInfo& proposalInfo)
{
    DBReadWriter db;

    std::string info;
    auto dbRet = db.getProposalInfoByAssetType(assetType, info);
    if(DBStatus::DB_SUCCESS != dbRet)
    {
        ERRORLOG("getProposalInfoByAssetType error, error num: {}, type:{}", dbRet, assetType); 
        return -1;
    }
    
    std::string decode = Base64Decode(info);
    nlohmann::json dataJson = nlohmann::json::parse(decode);
    std::string decodeName = dataJson["name"].get<std::string>();
    proposalInfo.Name = Base64Decode(decodeName);
    proposalInfo.ExchangeRate = dataJson["exchangeRate"].get<std::string>();
    proposalInfo.CrossChainTxType = dataJson["crossChainTxType"].get<int>();
    proposalInfo.ContractAddr = dataJson["tokenContractAddr"].get<std::string>();
    proposalInfo.CrossChainInvestmentContractAddr = dataJson["crossChainInvestmentContractAddr"].get<std::string>();
    proposalInfo.BeginTime = dataJson["beginTime"].get<uint64_t>();
    proposalInfo.EndTime = dataJson["endTime"].get<uint64_t>();
    proposalInfo.version = dataJson["version"].get<double>();
    proposalInfo.canBeStake = dataJson["genesisToken"].get<uint64_t>();
    proposalInfo.MIN_VOTE_NUM = dataJson["minVoteNum"].get<uint64_t>();
    std::string decodeTitle = dataJson["title"].get<std::string>();
    std::string decodeIdentifier = dataJson["identifier"].get<std::string>();
    
    proposalInfo.Title = Base64Decode(decodeTitle);
    proposalInfo.Identifier = Base64Decode(decodeIdentifier);
    proposalInfo.PeerChainTokenAddr = dataJson["peerChainTokenAddr"].get<std::string>();

    return 0;
}

int ca_algorithm::AssetTypeListIsEmpty()
{
    DBReadWriter db;
    std::vector<std::string> ASSERT_TYPES;
    auto dbRet = db.getAssetType(ASSERT_TYPES);
    if(dbRet == DBStatus::DB_NOT_FOUND)
    {
        return 1;
    }
    else if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("VoteCache error -1, getAssetType error, error num:{}", dbRet);
        return -1;
    }

    if(ASSERT_TYPES.empty())
    {
        return -2;
    }

    return 0;
}


int ca_algorithm::GetLockValue(const std::string& addr, uint64_t &lockValue)
{
    DBReader dbReader;
    std::vector<std::string> utxos;
    auto ret = dbReader.getLockAddrUtxo(addr, global::ca::ASSET_TYPE_OHI ,utxos);
    if(ret != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("GetLockValue getLockAddrUtxo error, error num: {}", ret);
        return -1;
    }

    std::reverse(utxos.begin(), utxos.end());

    for (auto &utxo : utxos) {
        std::string txRaw;
        ret = dbReader.getTransactionByHash(utxo, txRaw);
        if(ret != DBStatus::DB_SUCCESS)
        {
            ERRORLOG("GetLockValue getTransactionByHash error, error num: {}", ret);
            return -2;
        }

        CTransaction tx;
        auto parseRet = tx.ParseFromString(txRaw);
        if(!parseRet)
        {
            ERRORLOG("GetLockValue ParseFromString error");
            return -3;
        }
        
        for(const auto & txUtxo : tx.utxos())
        {
            for (auto &vout : txUtxo.vout()) 
            {
                if (vout.addr() == global::ca::VIRTUAL_LOCK_ADDRESS) 
                {
                    lockValue = vout.value();
                    break;
                }
            }
        }
    }

    lockValue = std::trunc(lockValue / global::ca::kDecimalNum);

    if(lockValue < global::ca::LOCK_AMOUNT)
    {
        ERRORLOG("GetLockValue lockValue error, lockValue: {}", lockValue);
        return -4;
    } 

    return 0;
}


int ca_algorithm::GetCanBeRevokeAssetType(std::string &assetType)
{
    DBReader db;
    std::vector<std::string> assetTypes;
    auto dbRet = db.getAssetType(assetTypes);
    if(dbRet != DBStatus::DB_SUCCESS)
    {
        INFOLOG("GetCanBeRevokeAssetType getAssetType error, {}", dbRet);
        return -1;
    }

    if(assetTypes.empty())
    {
        ERRORLOG("GetCanBeRevokeAssetType assetTypes is empty");
        return -2;
    }

    // 遍历所有资产类型，找到canBeStake==1的那个（即OHI资产）
    // 不能直接取at(0)，因为列表中可能有多个提案的资产类型，OHI不一定在第一个
    for (const auto& type : assetTypes)
    {
        int ret = AssetTypeIsOHI(type);
        if (ret == 0)
        {
            assetType = type;
            return 0;
        }
    }

    ERRORLOG("GetCanBeRevokeAssetType no OHI asset type found among {} types", assetTypes.size());
    return -3;

    return 0;
}


void ca_algorithm::Trim(std::string& str)
{
    auto start = std::find_if_not(str.begin(), str.end(), ::isspace);
    str.erase(str.begin(), start);

    auto end = std::find_if_not(str.rbegin(), str.rend(), ::isspace).base();
    str.erase(end, str.end());
}


int ca_algorithm::fetchBonusAddressInfo(std::map<std::string, uint64_t> &bonusAddrDelegatingMap)
{
    std::pair<std::string, uint64_t> bonusAddrDelegatingMapPair;
    DBReader dbReader;
    std::multimap<std::string, std::string> delegatingAddr_currency;
    std::vector<std::string> stake_addresses_list;
    dbReader.getStakeAddr(stake_addresses_list);
    for (auto &bonusAddr : stake_addresses_list)
    {
        usleep(1);
        delegatingAddr_currency.clear();
        bonusAddrDelegatingMapPair.first = addHexPrefix(bonusAddr);
        auto ret = dbReader.getDelegatingAddrAndAssetTypeByBonusAddr(bonusAddr, delegatingAddr_currency);
        if (ret != DBStatus::DB_SUCCESS && ret != DBStatus::DB_NOT_FOUND)
        {
            return -1;
        }

        uint64_t sumdelegateAmount = 0;

        for (auto &[delegatingAddr, currency] : delegatingAddr_currency)
        {
            std::vector<std::string> utxos;
            ret = dbReader.getDelegatingAddrUtxoByBonusAddr(bonusAddr, delegatingAddr, currency, utxos);
            if (ret != DBStatus::DB_SUCCESS && ret != DBStatus::DB_NOT_FOUND)
            {
                return -2;
            }

            uint64_t delegateAmount = 0;
            for (const auto &hash : utxos)
            {
                std::string txRaw;
                if (dbReader.getTransactionByHash(hash, txRaw) != DBStatus::DB_SUCCESS)
                {
                    return -3;
                }
                CTransaction tx;
                if (!tx.ParseFromString(txRaw))
                {
                    return -4;
                }
                for (const auto &utxo : tx.utxos())
                {
                    for (int i = 0; i < utxo.vout_size(); i++)
                    {
                        if (utxo.vout(i).addr() == global::ca::kVirtualDelegatingAddr)
                        {
                            delegateAmount += utxo.vout(i).value();
                            break;
                        }
                    }
                }
            }
            sumdelegateAmount += delegateAmount;
        }
        bonusAddrDelegatingMapPair.second = sumdelegateAmount;
        bonusAddrDelegatingMap.insert(bonusAddrDelegatingMapPair);
    }
    return 0;
}

int ca_algorithm::GetAnnualizedRate(const uint64_t &curTime, double &annualizedRate)
{
    double startRate = 0.23;
    double endRate = 0.15;
    double attenuationValue = 0.0001;

    uint64_t fragmentTime = (uint64_t)60 * 60 * 24 * 7;
    uint64_t fragmentParts = ((curTime / 1000000) - (MagicSingleton<Genesis>::GetInstance()->GetGenesisTime() / 1000000))/fragmentTime;
    annualizedRate = startRate - fragmentParts * attenuationValue;

    if (annualizedRate < endRate)
    {
        annualizedRate = endRate;
    }

    if(annualizedRate > startRate)
    {
        return -1;
    }
    return 0;
}


int ca_algorithm::GetVitrualDelegateInfo(const std::string &from, const std::string &toAddr,
												   const std::string &strInput, uint64_t height,
												   const uint64_t contractTransfer, const std::string &to, std::string& outPut)

{
	EvmHost host;
    evmc::bytes contractCode;
	if (evm_utils::GetContractCode(to, contractCode) != 0)
    {
        ERRORLOG("fail to get contract code");
        return -1;
    }
    host.code = contractCode;

	int64_t blockTimestamp = evmEnvironment::calculateBlockTimestamp(3);
    if (blockTimestamp < 0)
    {
		ERRORLOG("Calculate block timestamp failed!");
        return -2;
    }

	int64_t blockPrevRandao = 64;
	if (blockPrevRandao < 0)
	{
		return -3;
	}

	int64_t blockNumber = 0;
    try
    {
        blockNumber = Util::convertUnsigned64ToSigned64(height);
    }
    catch (const std::exception& e)
    {
        ERRORLOG("{}", e.what())
        return -4;
    }

    if (blockNumber < 0)
    {
        return -5;
    }

	evmc_message message{};
	int ret = Evmone::callContractRpcRequest(from, strInput, host,
									   contractTransfer, to, message, blockTimestamp, blockPrevRandao, blockNumber, "");
	if (ret != 0)
    {
        ERRORLOG("Evmone failed to call contract! ret : {}", ret);
        return -300;
    }

    outPut = host.output;
	// {
	// 	std::string sender = evm_utils::evm_addr_to_string(message.sender);
	// 	std::string recipient = evm_utils::evm_addr_to_string(message.recipient);
	// 	nlohmann::json txInfoJson;
	// 	txInfoJson[Evmone::contractVersionId] = 0;
	// 	txInfoJson[Evmone::contractSenderKeyName_] = sender;
	// 	txInfoJson[Evmone::contractRecipientKeyNameStr] = recipient;
	// 	txInfoJson[Evmone::contractVmKeyName] = global::ca::VmType::EVM;
	// 	txInfoJson[Evmone::contract_input_key_name] = strInput;
	// 	txInfoJson[Evmone::contractTransferKeyLabel] = contractTransfer;
	// 	txInfoJson[Evmone::contractDeployerKeyAlias] = toAddr;

	// 	txInfoJson[Evmone::contractOutputKey] = host.output;
	
	// 	txInfoJson[Evmone::contract_block_timestamp_key_name] = host.tx_context.block_timestamp;
	// 	txInfoJson[Evmone::contractBlockPrevRandaoKey] = evm_utils::evmc_uint256be_to_uint32(host.tx_context.block_prev_randao);

	// 	nlohmann::json data;
	// 	data["TxInfo"] = txInfoJson;
	// 	std::string s = data.dump();
	// }

	return 0;
}


int ca_algorithm::getAllAddrSignCountByPeriod(uint64_t period, std::unordered_map<std::string, uint64_t> & addr_sign_count)
{
    DBReader db_reader;
    std::vector<std::string> sign_address;

    if (DBStatus::DB_SUCCESS != db_reader.getSignAddrByPeriod(period, sign_address))
    {
        ERRORLOG("getSignAddrByPeriod failed");
        return -1;
    }

    for (const auto & addr : sign_address)
    {
        uint64_t sign_count;
        if (DBStatus::DB_SUCCESS != db_reader.getSignCountByPeriod(period, addr, sign_count))
        {
            continue;
        }

        addr_sign_count[addr] = sign_count;
   }
   
    return 0;
}

ca_algorithm::FlowTxType ca_algorithm::GetFlowTxType(const nlohmann::json& txInfoJson)
{
    FlowTxType type = FlowTxType::Unknown;
    if (txInfoJson.is_null())
    {
        return type;
    }

    auto calltype = txInfoJson.find("callType");
    if (calltype != txInfoJson.end() && calltype->is_string())
    {
        if (calltype.value() == "FlowInTx")
        {
            type = FlowTxType::FlowInTx;
            return type;
        }
        if (calltype.value() == "FlowOutTx")
        {
            type = FlowTxType::FlowOutTx;
            return type;
        }
    }
    
    return type;
}
