﻿#include <sstream>
#include <random>

#include "ca/global.h"
#include "ca/block_http_callback.h"

#include "include/logging.h"
#include "include/scope_guard.h"

#include "db/db_api.h"
#include "net/httplib.h"
#include "common/config.h"
#include "utils/magic_singleton.h"
#include "utils/pretty_print.h"
#include "utils/json_output.h"
#include "ca.h"


BlockHttpCallbackHandler::BlockHttpCallbackHandler() : _running(false),_ip("localhost"),_port(11190),_path("/Browser/block")
{
    Config::HttpCallback httpCallback = {};
    MagicSingleton<Config>::GetInstance()->GetHttpCallback(httpCallback);
    if (!httpCallback.ip.empty() && httpCallback.port > 0)
    {
        this->Start(httpCallback.ip, httpCallback.port, httpCallback.path);
    }
    else
    {
        ERRORLOG("Http callback is not config!");
    }
}

bool BlockHttpCallbackHandler::AddBlock(const std::string& block)
{
    if (block.empty())
        return false;
    std::unique_lock<std::mutex> lck(_addMutex);
    _addblocks.push_back( block );
    _cvadd.notify_all();

    return true;
}

bool BlockHttpCallbackHandler::AddBlock(const CBlock& block)
{
    std::string json = ToJson(block);
    return AddBlock(json);
}

bool BlockHttpCallbackHandler::rollback_block_str(const std::string& block)
{
      if (block.empty())
        return false;
        
    std::unique_lock<std::mutex> lck(rollbackMutex);
    rollbackBlocks_.push_back( block );
    cvRollback.notify_all();

    return true;
}


bool BlockHttpCallbackHandler::RollbackBlock(const CBlock& block)
{
    std::string json = ToJson(block);
    return rollback_block_str(json);
}


void BlockHttpCallbackHandler::addBlockWork(const std::string &method)
{
    DEBUGLOG("addBlockWork thread started: method={}", method);
    
    while (_running)
    {
        std::string currentBlock;
        {
            std::unique_lock<std::mutex> lck(_addMutex);
            while (_addblocks.empty())
            {
                DEBUGLOG("Enter waiting for condition variable.");
                _cvadd.wait(lck);
            }
            DEBUGLOG("Handle the first block...");
            currentBlock = _addblocks.front();
            _addblocks.erase(_addblocks.begin());
        }

        sendBlockHttpRequest(currentBlock,method);
    }
    
    DEBUGLOG("addBlockWork thread exited: reason=_running set to false");
}


void BlockHttpCallbackHandler::rollbackBlockWork_(const std::string &method)
{
    DEBUGLOG("rollbackBlockWork_ thread started: method={}", method);
    
    while (_running)
    {
        std::string currentBlock;
        {
            std::unique_lock<std::mutex> lck(rollbackMutex);
            while (rollbackBlocks_.empty())
            {
                DEBUGLOG("Enter waiting for condition variable.");
                cvRollback.wait(lck);
            }
            DEBUGLOG("Handle the first block...");
            currentBlock = rollbackBlocks_.front();
            rollbackBlocks_.erase(rollbackBlocks_.begin());
        }
        sendBlockHttpRequest(currentBlock,method);
    }
    
    DEBUGLOG("rollbackBlockWork_ thread exited: reason=_running set to false");
}

void BlockHttpCallbackHandler::Start(const std::string& ip, int port,const std::string& path)
{
    _ip = ip;
    _port = port;
    _path = path;
    _running = true;
    const std::string method1 = "/addblock";
    const std::string method2 = "/rollbackblock";
    workAddBlockThread = std::thread(std::bind(&BlockHttpCallbackHandler::addBlockWork, this, method1));
    workRollbackThread = std::thread(std::bind(&BlockHttpCallbackHandler::rollbackBlockWork_, this, method2));
    workAddBlockThread.detach();
    workRollbackThread.detach();
}

void BlockHttpCallbackHandler::Stop()
{
    _running = false;
}

bool BlockHttpCallbackHandler::IsRunning()
{
    return _running;
}

bool BlockHttpCallbackHandler::sendBlockHttpRequest(const std::string& block,const std::string &method)
{
    httplib::Client client(_ip, _port);
    std::string path = _path + method;
    auto res = client.Post(path.data(), block, "application/json");
    if (res)
    {
        DEBUGLOG("status:{}, Content-Type:{}, body:{}", res->status, res->get_header_value("Content-Type"), res->body);
    }
    else
    {
        DEBUGLOG("Client post failed");
    }

    return (bool)res;
}

std::string BlockHttpCallbackHandler::ToJson(const CBlock& block)
{
    nlohmann::json block_json = ohi::json::block2Json(block);
    return block_json.dump(4);
}

void BlockHttpCallbackHandler::Test()
{
    std::random_device rd;
    std::mt19937 mt(rd());
    std::uniform_int_distribution<int> dist(1, 32767);

    std::stringstream stream;
    stream << "Test http callback, ID: " << dist(mt);
    std::string testStr = stream.str();
    AddBlock(testStr);
}

