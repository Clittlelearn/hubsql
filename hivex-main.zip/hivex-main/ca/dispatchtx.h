#ifndef DISPATCHER_HEADER_PROTECTION
#define DISPATCHER_HEADER_PROTECTION
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include <functional>
#include <unordered_map>
#include <unordered_set>
#include <condition_variable>

#include "ca/global.h"
#include "ca/interface.h"
#include "ca/transaction.h"
#include "ca/transaction_cache.h"

class DependencyManager;
class MessageDispatcher;
class TimerProcessor;

class ContractDispatcher {
public:
    ContractDispatcher();
    ~ContractDispatcher();

    void AddContractInfo(const std::string& contract_hash, const std::vector<std::string>& dependent_contracts);
    void AddContractMessageRequest(const std::string& contract_hash, const ContractTxMsgReq& msg);
    void AddContractRequest(const std::string& contract_hash, const std::vector<std::string>& dependent_contracts, const ContractTxMsgReq& msg);
    void Process();
    void SetTimeValue(const uint64_t& new_value);
    
    struct MsgInfo {
        std::vector<TxMsgReq> tx_msg_req;
    };

private:
    static constexpr uint64_t kContractWaitingTime = 3 * 1000000ULL;

    std::mutex time_mutex_;
    std::condition_variable cv_;
    bool is_first_ = false;
    uint64_t time_value_ = 0;
};

// EventManager for event-driven management
class EventManager {
public:
    using Callback = std::function<void(const std::string& block_hash)>;
    void Subscribe(const std::string& event, Callback cb);
    void Publish(const std::string& event, const std::string& block_hash);
private:
    std::map<std::string, std::vector<Callback>> callbacks_;
};

class DependencyManager {
public:
    DependencyManager() = default;
    void AddContractInfo(const std::string& contract_hash, const std::vector<std::string>& dependent_addresses);
    void AddMessageRequest(const std::string& contract_hash, const ContractTxMsgReq& msg);
    void AddContractRequest(const std::string& contract_hash, const std::vector<std::string>& dependent_addresses, const ContractTxMsgReq& msg);
    std::vector<std::vector<TxMsgReq>> GetDependentData();
    std::vector<std::vector<TxMsgReq>> GroupData(const std::vector<std::vector<TxMsgReq>>& tx_vectors);
    bool HasDuplicate(const std::vector<std::string>& vec1, const std::vector<std::string>& vec2);
    void RemoveProcessed(const std::vector<TxMsgReq>& processed);
    
    // // 获取所有依赖地址及其关联的交易哈希
    // std::map<std::string, std::vector<std::string>> GetAllDependenciesWithTxHashes();
    // // 获取所有唯一的依赖地址
    // std::set<std::string> GetAllUniqueDependencies() const;

    // int HandleContractDependencyBroadcastMsg(const std::shared_ptr<ContractDependencyBroadcastMsg>& msg, const MsgData &msgData);
    // void StoreBroadcastDependencies(const ContractDependencyBroadcastMsg& msg);
    // // bool CanSendTransaction(const ContractTxMsgReq& msg);
    // void ClearDependency(const std::string& tx_hash);
    // void BroadcastAddedDependency(const std::string& contract_hash, const std::vector<std::string>& dependent_addresses);
private:
    // void RememberClearedDependencyHash(const std::string& tx_hash);
    // void PruneClearedDependencyHashes(uint64_t now);
    // bool IsClearedDependencyHash(const std::string& tx_hash) const;
    // void RememberDependencyHash(const std::string& tx_hash, uint64_t now);
    // void PruneExpiredDependencyHashes(uint64_t now);

    //The data received from the initiator is stored
    std::unordered_map<std::string/*txHash*/, std::vector<std::string>/*Contract dependency address*/> contract_dep_cache_; 
    std::unordered_map<std::string, TxMsgReq> contract_msg_cache_;
    mutable std::mutex dep_mutex_;
    mutable std::mutex msg_mutex_;
    
    // 依赖地址对应的交易哈希：依赖地址 -> 交易哈希列表
    // std::unordered_map<std::string, std::vector<std::string>> dependency_tx_hashes_;
    // std::unordered_map<std::string, uint64_t> dependency_hash_times_;
    // std::unordered_map<std::string, uint64_t> cleared_dependency_hashes_;
    // mutable std::shared_mutex dependency_tx_mutex_; 
    // static constexpr uint64_t kDependencyHashTtl = 60 * 1000000ULL;
    // static constexpr uint64_t kClearedDependencyRetention = 10 * 60 * 1000000ULL;
};

class MessageDispatcher {
public:
    int DistributionContractTransactionRequest(std::multimap<std::string, ContractDispatcher::MsgInfo>& distribution,
                                               const std::vector<std::vector<TxMsgReq>>& grouped_data);
    int SendTransactionInfoRequest(const std::string& packager, std::vector<TxMsgReq>& tx_msgs);
};

// SlashEvidencePool: collects evidence and builds EVIDENCE/PUNISHMENT transactions
class SlashEvidencePool {
public:
    // P3-26: Malicious reporter tracking
    struct ReporterStats {
        uint32_t totalReports = 0;      // Total evidence submitted
        uint32_t validReports = 0;       // Evidence that reached consensus
        uint64_t windowStart = 0;        // Tracking window start
    };

    // Check pending evidence in DB and build EVIDENCE transactions for dispatch
    std::vector<TxMsgReq> buildEvidenceTransactions();

    // Check threshold-exceeded entries and build PUNISHMENT transactions
    std::vector<TxMsgReq> buildPunishmentTransactions();

    // Handle incoming SlashEvidenceMsg from detection nodes
    void addEvidence(const SlashEvidenceMsg& msg);

    // Clean up expired evidence
    void cleanup(uint64_t currentPeriod);

    // P3-26: Check for malicious reporters and return list of addresses to penalize
    std::vector<std::string> getMaliciousReporters();

    // P3-26: Get reporter stats for malicious reporting evidence
    ReporterStats getReporterStats(const std::string& reporter);

private:
    struct EvidenceEntry {
        SlashEvidenceMsg evidence;
        std::vector<CSign> signatures;
        uint64_t firstSeenPeriod;
        bool consensusReached;
    };

    std::unordered_map<std::string, EvidenceEntry> pool_;
    mutable std::mutex pool_mutex_;
    std::unordered_map<std::string, ReporterStats> reporterStats_;

    bool verifyEvidence(const SlashEvidenceMsg& msg);
    CTransaction buildEvidenceTx(const EvidenceEntry& entry);
    CTransaction buildPunishmentTx(const std::string& targetAddr, const std::string& level, const std::string& violationType, const std::string& evidenceRefs);
};

// NodeSlashTracker: tracks node offline status, VRF failures, disconnects
class NodeSlashTracker {
public:
    void recordDisconnect(const std::string& addr);
    bool isJailed(const std::string& addr);
    bool isTombstoned(const std::string& addr);

    // Check sign rate for a node over recent periods
    // Returns sign rate (0.0 ~ 1.0), or -1.0 if insufficient data
    double checkSignRate(const std::string& addr, uint64_t currentPeriod, uint32_t lookbackPeriods = 100);
};


// TimerProcessor class declaration
class TimerProcessor {
public:
    TimerProcessor() = default;
    ~TimerProcessor() = default;
    void Start();
    void Stop();
    void SetTimeValue(uint64_t value);
private:
    void ProcessingFunc();
    std::thread timer_thread_;
    std::mutex timer_mutex_;
    std::condition_variable timer_cv_;
    bool running_ = false;
    uint64_t time_value_ = 0;
    static constexpr uint64_t kContractWaitingTime = 3 * 1000000ULL;
};

int HandleContractDependencyBroadcastMsg(const std::shared_ptr<ContractDependencyBroadcastMsg> &msg, const MsgData &msgData);
int HandleSlashEvidenceMsg(const std::shared_ptr<SlashEvidenceMsg> &msg, const MsgData &msgData);
int HandleNodeOfflineNotice(const std::shared_ptr<NodeOfflineNotice> &msg, const MsgData &msgData);

// 辅助函数：发送举证消息给当前分发者
void SendSlashEvidenceToDispatcher(const SlashEvidenceMsg& evidence);

#endif
