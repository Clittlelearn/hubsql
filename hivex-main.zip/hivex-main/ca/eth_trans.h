#ifndef ETH_TRANS_H
#define ETH_TRANS_H

#include<iostream>
#include <utility>
#include <optional>

// #include"eth_rpc.h"
#include"rlp.h"
#include"include/logging.h"
#include"utils/account_manager.h"
#include "utils/hex_string.h"
#include "contract/precompiles_silkpre.hpp"
#include "db/db_api.h"
#include "ca/global.h"
#include "eth/eth.h"
// #include "ca/transaction/trans.h"

namespace ethVerify {
    struct EthTransaction {
        std::string from;
        uint64_t nonce;
        uint64_t gasPrice;
        uint64_t gasLimit;
        std::string to;
        std::string value;
        std::string data;
        uint64_t chainId;
        uint64_t maxPriorityFeePerGas;
        uint64_t maxFeePerGas;
        uint8_t txType;

        void print(){
            std::cout << "from: " << from << std::endl;
            std::cout << "nonce: " << nonce << std::endl;
            std::cout << "gasPrice: " << gasPrice << std::endl;
            std::cout << "gasLimit: " << gasLimit << std::endl;
            std::cout << "to: " << to << std::endl;
            std::cout << "value: " << value << std::endl;
            std::cout << "data: " << data << std::endl;
            std::cout << "chainId: " << chainId << std::endl;
            std::cout << "maxPriorityFeePerGas: " << maxPriorityFeePerGas << std::endl;
            std::cout << "maxFeePerGas: " << maxFeePerGas << std::endl;
        }
    };



    int verifyRLP(dev::bytes &transaction_rlp, eth_errors &e, EthTransaction *tx = nullptr,
                  std::optional<uint64_t> expectedNonce = std::nullopt);
    int verifyETHUtxo(const CTransaction& tx,const EthTransaction& eth_tx);
    // int memoryVerifyETHTransaction(const CTransaction& tx);

    // int VerifyETHTransaction(const CTransaction& tx);
}

#endif
