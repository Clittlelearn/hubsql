﻿#include "eth_trans.h"
#include "db_api.h"
#include "global.h"
#include "transaction.pb.h"
#include "transaction.h"
#include "algorithm.h"
#include "utils/account_manager.h"
#include "utils/bench_mark.h"
#include "block_helper.h"
#include "utils/contract_utils.h"
#include "eth/eth_impl.h"
#include <unistd.h>


namespace ethVerify {
    int verifyRLP(dev::bytes& transaction_rlp,eth_errors & e, EthTransaction* tx,
                  std::optional<uint64_t> expectedNonce){
        if(transaction_rlp.empty()){
            DEBUGLOG("The transaction is not an RLP transaction.");
            e.ok=false;
            e.message="The transaction is not an RLP transaction.";
            return -1;
        }

        uint8_t txType = 0; // 0: Legacy, 1: EIP-2930, 2: EIP-1559
        if (!transaction_rlp.empty() && transaction_rlp[0] <= 0x7f) {
            txType = transaction_rlp[0];
            // Remove type byte for RLP parsing
            transaction_rlp.erase(transaction_rlp.begin());
        }

        dev::RLP rlp(transaction_rlp);
        if (!rlp.isList()) {
            e.ok=false;
            e.message="Invalid transaction RLP.";
            // return ret.make();
            ERRORLOG("Invalid transaction RLP.");
            return -2;
        };

        uint64_t nonce, gasPrice, gasLimit, chainId = 0, recoveryId = 0;
        std::string toAddress, value, data, v_bytes, r_str, s_str;
        bool isEIP155 = false;
        std::string msgHash;

        if (txType == 0) { // Legacy Transaction
            std::cout << "Legacy Transaction" << std::endl;
            nonce = rlp[0].toInt<uint64_t>();
            gasPrice = rlp[1].toInt<uint64_t>();
            gasLimit = rlp[2].toInt<uint64_t>();
            // toAddress = rlp[3].toString();
            std::string toBytes = rlp[3].toString();
            if(!toBytes.empty()) {
                toAddress = evm_utils::ToChecksumAddress(dev::toHex(toBytes));
            } else {
                toAddress = "";
            }
            value = rlp[4].toString();
            data = rlp[5].toString();

            uint64_t v_val = 0;
            if (rlp[6].isInt()) {
                v_val = rlp[6].toInt<uint64_t>();
            } else {
                v_bytes = rlp[6].toString();
                if (!v_bytes.empty()) v_val = (uint8_t)v_bytes[0];
            }
            
            r_str = rlp[7].toString();
            s_str = rlp[8].toString();

            // Handle EIP-155
            if (v_val >= 35) {
                chainId = (v_val - 35) / 2;
                recoveryId = v_val - (chainId * 2 + 35);
                isEIP155 = true;
            } else if (v_val >= 27) {
                recoveryId = v_val - 27;
            }

            // Reconstruct RLP for signing
            dev::RLPStream stream;
            if (isEIP155) {
                stream.appendList(9);
            } else {
                stream.appendList(6);
            }
            
            // Append first 6 fields directly
            for(int i=0; i<6; ++i) {
                stream.appendRaw(rlp[i].data(), 1);
            }

            if (isEIP155) {
                stream << chainId << 0 << 0;
            }
            
            std::string rlpToSign(stream.out().begin(), stream.out().end());
            msgHash = EthMessageHash(rlpToSign);

        } else if (txType == 2) { // EIP-1559 Transaction
            // Format: [chainId, nonce, maxPriorityFeePerGas, maxFeePerGas, gasLimit, to, value, data, accessList, v, r, s]
            std::cout << "EIP-1559 Transaction" << std::endl;
            chainId = rlp[0].toInt<uint64_t>();
            nonce = rlp[1].toInt<uint64_t>();
            // index 2: maxPriorityFeePerGas
            // index 3: maxFeePerGas
            gasLimit = rlp[4].toInt<uint64_t>();
            std::string toBytes = rlp[5].toString();
            if(!toBytes.empty()) {
                toAddress = evm_utils::ToChecksumAddress(dev::toHex(toBytes));
            } else {
                toAddress = "";
            }

            value = rlp[6].toString();
            data = rlp[7].toString();
            // index 8: accessList
            
            uint64_t v_val = 0;
            if (rlp[9].isInt()) {
                v_val = rlp[9].toInt<uint64_t>();
            } else {
                v_bytes = rlp[9].toString();
                if (!v_bytes.empty()) v_val = (uint8_t)v_bytes[0];
            }
            recoveryId = v_val; // For EIP-1559, v is just the parity (0 or 1)

            r_str = rlp[10].toString();
            s_str = rlp[11].toString();

            // For EIP-1559, the message to sign is keccak256(0x02 || rlp([chainId, nonce, maxPriorityFeePerGas, maxFeePerGas, gasLimit, to, value, data, accessList]))
            dev::RLPStream stream;
            stream.appendList(9);
            // Append first 9 fields directly (excluding v, r, s)
            for(int i=0; i<9; ++i) {
                stream.appendRaw(rlp[i].data(), 1);
            }
            
            std::string rlpPayload(stream.out().begin(), stream.out().end());
            std::string preImage;
            preImage.push_back((char)0x02); // Type 2 prefix
            preImage.append(rlpPayload);
            msgHash = EthMessageHash(preImage);
        } else {
            e.ok=false;
            e.message="Unsupported transaction type.";
            // return ret.make();
            ERRORLOG("Unsupported transaction type.")
            return -3;
        }
        
        // 4. Prepare ecrecover input (128 bytes)
        uint8_t input[128] = {0};
        // Hash (0-31)
        if (msgHash.size() == 32) {
            memcpy(input, msgHash.data(), 32);
        }
        // V (32-63, padded)
        input[63] = recoveryId + 27; 
        // R (64-95)
        if (r_str.size() <= 32) {
            size_t offset = 32 - r_str.size();
            memcpy(input + 64 + offset, r_str.data(), r_str.size());
        }
        // S (96-127)
        if (s_str.size() <= 32) {
            size_t offset = 32 - s_str.size();
            memcpy(input + 96 + offset, s_str.data(), s_str.size());
        }

        // 5. Call ecrecover
        uint8_t output[32] = {0};
        auto result = evmone::state::silkpre_ecrecover_execute(input, 128, output, 32);
        std::string addr_no_0x;        
        if (result.status_code != EVMC_SUCCESS) {
            std::cout << "Signature verification failed" << std::endl;
            e.ok = false;
            e.message = "Signature verification failed";
            ERRORLOG("Signature verification failed.");
            return -4;
        } else {
            // Recovered Address (last 20 bytes of output)
            std::string recoveredAddrBytes((char*)output + 12, 20);
            // Manual Hex conversion if dev::toHex not available or ambiguous
            static const char hex_chars[] = "0123456789abcdef";
            std::string recoveredAddrHex = "0x";
            for (unsigned char c : recoveredAddrBytes) {
                recoveredAddrHex += hex_chars[c >> 4];
                recoveredAddrHex += hex_chars[c & 0x0F];
            }
            std::cout << "Recovered Address: " << recoveredAddrHex << std::endl;

	            // Verify Nonce
	            addr_no_0x = evm_utils::ToChecksumAddress(recoveredAddrHex);
	            DEBUGLOG("Recovered Address: {}", addr_no_0x);

            uint64_t db_nonce = 0;
            if (expectedNonce.has_value()) {
                db_nonce = *expectedNonce;
            } else {
                DBReader db_reader;
                if (db_reader.getNonceByAddr(addr_no_0x, db_nonce) != DBStatus::DB_SUCCESS) {
                    db_nonce = 0;
                }
            }
            if (nonce != db_nonce) {
                ERRORLOG("Nonce mismatch! Tx:{}, DB: {}",nonce,db_nonce);
                e.ok = false;
                e.message = "Nonce mismatch.";
                return -5;
            }

            // Verify Balance (Simple check)
            DBReader db_reader;
            int64_t db_balance = 0;
            if (db_reader.getBalanceByAddr(addr_no_0x, global::ca::ASSET_TYPE_OHI, db_balance) != DBStatus::DB_SUCCESS) {
                ERRORLOG("Get balance failed.");
                e.ok = false;
                e.message = "Get balance failed.";
                return -6;
            }
            DEBUGLOG("Balance: {}", db_balance);
            if(db_balance < scale_down_10_18_to_8(value)){
                ERRORLOG("Balance is not enough.");
                e.ok = false;
                e.message = "Balance is not enough.";
                return -7;
            }
        }

	        if (tx) {
	            tx->txType = txType;
	            tx->nonce = nonce;
            tx->gasLimit = gasLimit;
            tx->to = toAddress;
            tx->value = value;
            tx->data = data;
            tx->chainId = chainId;
            tx->from = addr_no_0x;
            if (txType == 0) {
                tx->gasPrice = gasPrice;
                tx->maxFeePerGas = gasPrice;
                tx->maxPriorityFeePerGas = gasPrice;
            } else if (txType == 2) {
                tx->maxPriorityFeePerGas = rlp[2].toInt<uint64_t>();
                tx->maxFeePerGas = rlp[3].toInt<uint64_t>();
                tx->gasPrice = tx->maxFeePerGas;
            }
        }
        return 0;
    }

    int verifyETHUtxo(const CTransaction& tx,const EthTransaction& eth_tx){
        if((global::ca::TxType)tx.type() == global::ca::TxType::TX){
            if(tx.independence() != global::ca::TX_INDEPENDENCE_FALSE){
                ERRORLOG("transaction must be independence.");
                return -1;
            }
            for(const auto& utxo : tx.utxos()){
                if(utxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE){
                    ERRORLOG("Gas utxo is not supported.");
                    return -1;
                }

                if(utxo.assettype() != global::ca::ASSET_TYPE_OHI){
                    ERRORLOG("Only OHI asset type is supported.");
                    return -2;
                }
            }
             
            for(const auto& utxo : tx.utxos()){
                for (auto & vin : utxo.vin())
                {
                    for(auto & prevout : vin.prevout()){
                        std::string preUtxo = prevout.hash();
                        uint32_t index = prevout.n();
                        DBReader dbReader;
                        std::vector<std::string> utxoHashesList;
                        if (DBStatus::DB_SUCCESS != dbReader.getUtxoHashsByAddress(eth_tx.from, global::ca::ASSET_TYPE_OHI, utxoHashesList))
                        {
                            ERRORLOG( "getUtxoHashsByAddress failed! addr:{}", eth_tx.from);
                            return -3;
                        }    
                        if(std::find(utxoHashesList.begin(), utxoHashesList.end(), preUtxo) == utxoHashesList.end()){
                            ERRORLOG( "prevout not found! addr:{} preUtxo:{}", eth_tx.from, preUtxo);
                            return -4;
                        }                    
                    }
                }

                for(int i = 0; i < utxo.vout().size(); i++){
                    auto & vout = utxo.vout()[i];
                    if(i == 0 ){
                        if(vout.addr() != eth_tx.to){
                            ERRORLOG( "vout addr not match! addr:{} to:{}", vout.addr(), eth_tx.to);
                            return -5;
                        }
                    }
                }
            }

        }else if( (global::ca::TxType)tx.type() == global::ca::TxType::CALL || (global::ca::TxType)tx.type() == global::ca::TxType::DEPLOY){
        }else if((global::ca::TxType)tx.type() == global::ca::TxType::LOCK )
        {
            for (const auto &utxo : tx.utxos())
            {
                for (int i = 0; i < utxo.vout().size(); i++)
                {
                    auto &vout = utxo.vout()[i];
                    if (i == 1)
                    {
                        if (vout.addr() != eth_tx.from)
                        {
                            ERRORLOG("vout addr not match! addr:{} to:{}", vout.addr(), eth_tx.from);
                            return -7;
                        }
                    }
                }
            }
        }
        else if ((global::ca::TxType)tx.type() == global::ca::TxType::DELEGATE)
        {}
        else if ((global::ca::TxType)tx.type() == global::ca::TxType::UNDELEGATE)
        {
        }
        else if ((global::ca::TxType)tx.type() == global::ca::TxType::BONUS)
        {}
        else if ((global::ca::TxType)tx.type() == global::ca::TxType::VOTE)
        {
        }
        else if ((global::ca::TxType)tx.type() == global::ca::TxType::FUND)
        {
        }
        else if ((global::ca::TxType)tx.type() == global::ca::TxType::UNLOCK)
        {
        }
        else{
        ERRORLOG("Unsupported transaction type.");
        return -8;
        }

        return 0;
    }

}   
