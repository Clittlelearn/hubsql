/**
 * *****************************************************************************
 * @file        ca.h
 * @brief       
 * @date        2023-09-26
 * @copyright   mm
 * *****************************************************************************
 */

#ifndef CA_H
#define _CA_H

#include <iostream>
#include <thread>
#include <shared_mutex>

#include "pb/transaction.pb.h"
#include "ca/transaction/bonus.h"
#include "ca/transaction/fund.h"
#include "ca/transaction/delegating.h"
#include "ca/transaction/undelegating.h"
extern bool bStopTx;
extern bool isCreateTx;




void RegisterCallback();
void TestCreateTx(const std::vector<std::string> & addrs, const int & sleepTime);

/**
 * @brief       CA initialization
 * 
 * @return      true success
 * @return      false failure
 */
bool CaInit();

/**
 * @brief       CA cleanup function
 */
void CaCleanup();

/**
 * @brief
 */
void HandleTransaction();

/**
 * @brief       
 */
void HandleStake();

/**
 * @brief       
 */
void HandleUnstake();

/**
 * @brief       
 */
void handleDelegating();

/**
 * @brief       
 */
void HandleUndelegating();

/**
 * @brief       
 */
void HandleBonus();

/**
 * @brief       
 */
void HandleChangeAccountPassword();

/**
 * @brief       
 */
void handleAccountManager();

/**
 * @brief       
 */
void handle_set_default_account();

/**
 * @brief       
 */
void DeployContract();

/**
 * @brief       
 */
void CallContract();

/**
 * @brief Deletes the private key from the system.
 */
void DeletePrivateKey();


void GenKey();
/**
 * @brief Imports a private key into the system.
 */
void ImportPrivateKey();

/**
 * @brief       
 */
void handleExportPrivateKey();

/**
 * @brief       使用统一密码导出所有账户的16进制私钥到同一个文件
 */
void handleExportAllPrivateKeys();

/**
 * @brief       NTPcheckout
 * 
 * @return      int 
 */
int CheckNtpTime();

/**
 * @brief       Get the Chain Height object
 * 
 * @param       chainHeight: 
 * @return      int 
 */
int GetChainHeight(unsigned int & chainHeight);


/**
 * @brief       
 * 
 * @param       arg: 
 * @param       ack: 
 * @return      std::string 
 */
std::string rpcCallRequest(void * arg,void *ack);

/**
 * @brief       
 * 
 * @param       arg: 
 * @param       ack: 
 * @return      std::string 
 */
std::string deployContractRequest(void * arg,void *ack);

/**
 * @brief       
 * 
 * @param       tx: 
 * @param       addr: 
 * @return      int 
 */
int SigTx(CTransaction &tx,const std::string & addr);
/**
 * @brief   Deploy multiple contracts with one click   
 * 
 */
void createAutomaticDeployContract();
/**
 * @brief   Processing contract transactions   
 * 
 */
void handleMultiDeployContract(const std::string &strFromAddr);
/**
 * @brief   The contract data is exported to json
 * 
 */
void printJson();

// 以下这两个函数（remove0xPrefix，addHexPrefix） 待删除，替代函数使用utils/hex_string.h
std::string remove0xPrefix(std::string str);
std::string addHexPrefix(std::string hexStr);

//投票质押菜单                
void HandleLock();            
//解投票质押菜单              
void HandleUnLock();          
//创世账号发起添加资产投票菜单
void HandleProposal();        
//创世账号发撤销资产投票菜单  
void revokeProposalRequest();  
//投票菜单                    
void HandleVote();    
//申领国库奖励菜单
void HandleTresury();


int transactionDiscoveryHeight(uint64_t &height);

#endif
