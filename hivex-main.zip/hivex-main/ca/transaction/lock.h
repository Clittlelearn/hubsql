﻿#pragma  once

#include "trie.h"
#include "txhelper.h"
#include "utxo_core.h"
#include "CowString.hpp"
#include <cstdint>


 
class LockTrans:public ohi::UtxoCore{
public:
    
    struct LockTransParam{
       ohi::CowString lock_addr;
       uint64_t lock_amount;
       uint64_t height;
       TxHelper::LockType lock_type;
       ohi::UtxoCore::OtherToPayGas gas;
       bool is_gas_tray;
       bool is_find_utxo;
       ohi::CowString encoded_info;
    }s_lock_param;

    LockTrans(const LockTransParam & param):s_lock_param(param){}

    
    expected<bool> trans()override;
    expected<bool> goMessage()override;
protected:
    expected<bool> checkParams() override;
    expected<bool> makeTxInfor(CTransaction * tx) override;
    //expected<bool> checkParams()override;
    expected<int64_t> getGasValue(CTxUtxos * u,int trans_index);
private:

};