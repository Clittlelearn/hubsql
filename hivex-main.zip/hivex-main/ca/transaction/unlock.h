﻿
#pragma  once
#include "txhelper.h"
#include "CowString.hpp"
#include <cstdint>
#include "utxo_core.h"



class UnlockTrans:public ohi::UtxoCore{
public:
    
    struct UnlockTransParam{
       ohi::CowString lock_addr;
       ohi::CowString utxo_hash;
       uint64_t height;
       ohi::UtxoCore::OtherToPayGas gas;
       bool is_gas_tray;
       bool is_find_utxo;
       ohi::CowString encoded_info;
       uint64_t time;
    }s_unlock_param;

    UnlockTrans(const UnlockTransParam & param):s_unlock_param(param){}
    
    expected<bool> trans()override;
    expected<bool> goMessage()override;
protected:
    expected<bool> makeTxInfor(CTransaction * tx) override;
    expected<bool> checkParams()override;
    expected<int64_t> getGasValue(CTxUtxos * u,int trans_index);
private:

};