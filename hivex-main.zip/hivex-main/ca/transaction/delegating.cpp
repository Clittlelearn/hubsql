﻿#include "delegating.h"
#include "errorn/ca/error.def.h"
#include "error.h"
#include "utils/account_manager.h"
#include "utils/bench_mark.h"
#include "utxo_core.h"
#include "ca/global.h"
#include "pb/transaction.pb.h"
#include "transaction.pb.h"
#include "ca/transaction.h"
#include "utils/tmp_log.h"
#include <cstdint>
#include "utils/version.h"
#include "common/genesis_helper.h"
#include "ca/address_status_cache.h"
#include "utils/magic_singleton.h"

expected<bool> DelegatingTrans::trans()
{
    auto checkRet = checkParams();
    if (!checkRet.isOk()) {
        return checkRet.Error();
    }

    uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk()){
       	return  PERROR(MEM::FAILED_TO_GET_HEIGHT);;
    }
	top=retNum.Value();
	//  Check parameters
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> all_set_out_utxos;

    // initialize transaction
    uint64_t totalGas = 0;
    std::string from_addr = s_delegating_trans_param.from_addr.str();
    std::string to_addr = s_delegating_trans_param.to_addr.str();
    std::string asset_type = s_delegating_trans_param.asset_type.str();
    delegatinged_amount = s_delegating_trans_param.delegatinged_amount;
    std::vector<std::string> address_vector;
    address_vector.push_back(s_delegating_trans_param.from_addr.str());
    int ret = TxHelper::Check(address_vector, asset_type, top+1);
    if (ret != 0)
    {
        //ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
        return PERROR(MEM::CHECK_ADDR_ASSET_TYPE_HEIGHT_FAIL,"ret:{}",ret);
        // ret -= 100;
        // return ret;
    }

    if (!isValidAddress(from_addr))
    {
        // ERRORLOG("to from_addr is empty");
        // return -1;
        return PERROR(MEM::INVALID_ADDR);
    }


    if (!isValidAddress(to_addr))
    {
        // ERRORLOG(RED "To address is not  address!" RESET);
        // return -2;
        return PERROR(MEM::INVALID_ADDR);
    }

    if (delegatinged_amount < global::ca::kMinDelegatingAmt) {
        ERRORLOG("Delegating amount exceeds the limit!");
        return PERROR(MEM::DELEGATING_AMOUNT_EXCEED_THE_LIMIT);
    }

    ret = CheckDelegatingQualification(from_addr, to_addr, asset_type,
                                       delegatinged_amount);
    if (ret != 0) {
      ERRORLOG("CheckDelegatingQualification failed! The error code is {}.",
               ret);
        ret -= 200;
		return PERROR(MEM::NOT_QUALIFIED_FOR_UNDELEGATION,"ret:{}",ret);
	}

    if (s_delegating_trans_param.delegate_type ==
        TxHelper::delegateType::kdelegateType_NetLicence) {
        delegate_type_name = global::ca::kdelegateTypeNormal;
    } else
    {
      ERRORLOG("Unknown delegate type!");
        return PERROR(MEM::UNKNOWN_DELEGATE_TYPE,"Unknown delegate type!");
    }


    // Find utxo
    // Transaction fee
    TransferFromParam from_param;

    from_param.from = from_addr;
    from_param.asset_type = asset_type;
    from_param.amount = TxHelper::MAX_VIN_SIZE;
    from_param.is_find_utxo=s_delegating_trans_param.is_find_utxo;
    auto u=tx.add_utxos();
    auto fromret=createUtxoTransferFrom(u,from_param,0);
    if(!fromret.isOk()){
        return fromret  << PERROR(MEM::GEN_VIN_FAIL);
    }
    int index = 0;
    expend = delegatinged_amount;
    makeTxInfor(&tx);
    auto gasre=getGasValue(u,index);
    if(!gasre.isOk()){
        return gasre<< PERROR(MEM::GET_GAS_VALUE_FAIL);
    }

    int64_t gas=gasre.Value();
            DEBUGLOG("expend = {}", expend);
    if (s_delegating_trans_param.is_gas_tray)
    {
        totalGas += gasre.Value();
    }
    else
    {
        expend += gasre.Value();
    }

    DEBUGLOG("totalGas = {} , expendGas = {} gas = {}", totalGas, expend,gas);
    total = fromret.Value();
    // Judge whether utxo is enough
    if (total < expend)
    {
        ERRORLOG("The total cost = {} is less than the cost = {}", total, expend);
        return PERROR(MEM::BALANCE_IS_INSUFFICIENT,"total:{},expend:{}" , total, expend);
    }

    // Fill vout
    

    TransferToParam to_param;
    to_param.to=global::ca::kVirtualDelegatingAddr;
    to_param.amount= delegatinged_amount;
    createUtxoTransferTo(u,to_param);
    // CTxOutput *vout = transactionUtxo1->add_vout();
    // vout->set_addr(to.first);
    // vout->set_value(to.second);
    TransferToParam to_self_param;
    to_self_param.to= from_addr;
    to_self_param.amount=total - expend;
    createUtxoTransferTo(u,to_self_param);

    // CTxOutput *voutSourceAddress = transactionUtxo1->add_vout();
    // voutSourceAddress->set_addr(*(i.fromAddr.rbegin()));
    // voutSourceAddress->set_value(total - expend);

    if (s_delegating_trans_param.is_gas_tray)
    {    
        TransferToParam to_burn_param;
        to_burn_param.amount=0;
        to_burn_param.to = global::ca::VIRTUAL_BURN_GAS_ADDR;
        createUtxoTransferTo(u,to_burn_param);
        // CTxOutput *voutBurnAmount = transactionUtxo1->add_vout();
        // voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
        // voutBurnAmount->set_value(0);
    }
    else
    {
        TransferToParam to_burn_param;
        to_burn_param.amount=gas;
        to_burn_param.to=global::ca::VIRTUAL_BURN_GAS_ADDR;
        createUtxoTransferTo(u,to_burn_param);
        // CTxOutput *voutBurnAmount = transactionUtxo1->add_vout();
        // voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
        // voutBurnAmount->set_value(gas);
    }

		// std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
		// for (auto &owner : setTxOwners)
		// {
		// 	if (TxHelper::addMultipleSigns(owner, *transactionUtxo1) != 0)
		// 	{
		// 		ERRORLOG("addd mutil sign fail");
		// 		return -10;
		// 	}
		// }
	
    

    if(s_delegating_trans_param.is_gas_tray)
    {
        UtxoGasParam param;
        param.asset_type = s_delegating_trans_param.gas_tray.asset_type;
        param.from = s_delegating_trans_param.gas_tray.addr;
        param.gas=totalGas;
        auto gasret= createUtxoGas(&tx, param);
        if(!gasret.isOk()){
            return gasret<< PERROR(MEM::GEN_GAS_UTXO_FAIL);
    }
    }
   	auto current_time = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	tx.set_time(current_time);
	tx.set_consensus(global::ca::kConsensus);
	tx.set_type((uint32_t)global::ca::TxType::DELEGATE);

	DEBUGLOG("self hash:{}", calculate_all_hash(&tx));
    std::string identity;
    TxHelper::vrfAgentType type;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(&tx), current_time, identity, TxHelper::SelectLocalSelectionSigner(tx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return PERROR(MEM::FAILED_TO_PICK_A_PACKAGER);
	}
	DEBUGLOG("Tx identity:{}", identity);
	tx.set_identity(identity);

	// std::string txHash = Getsha256Hash(tx.SerializeAsString());
	// tx.set_hash(txHash);
    DEBUGLOG("CreateDelegatingTransaction tx time = {}, package = {}",
                 tx.time(), tx.identity());
        
    return true;
}

expected<bool> DelegatingTrans::goMessage() {
      TxMsgReq txMsg;

    uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk() ){
        return retNum<< PERROR(MEM::FAILED_TO_GET_HEIGHT);
    }
    top=retNum.Value();
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(tx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    auto ret = TxHelper::get_tx_utxo_height(tx, txUtxoLocalHeight);
    if(ret != 0)
    {
        return PERROR(MEM::FAILED_TO_GET_UTXO_HEIGHT);
        
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    auto msg = std::make_shared<TxMsgReq>(txMsg);

    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

    if(tx.identity() == defaultAddr)
    {
        ret = handleTransaction(msg,tx);
        
    }
    else
    {
        ret = DropShippingTransaction(msg, tx, tx.identity());
    }

    if (ret != 0)
    {
        //UtxoError().trace(UE_NOERROR,"%s => what:%s",ret).to_string();
        ret -= 100;
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, tx.hash());
    return true;
 }

expected<bool> DelegatingTrans::makeTxInfor(CTransaction * tx){

    nlohmann::json txInfo;
  	txInfo["bonusAddr"] = s_delegating_trans_param.to_addr.str();
	txInfo["delegateAmount"] = delegatinged_amount;
    txInfo["delegateType"] = delegate_type_name.str();

	nlohmann::json data;
	data["txInfo"] = txInfo;
    
    if (tx->utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -1;
    }

    if (tx->utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -2;
    }

    uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(tx->utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
        db_reader.getNonceByAddr(tx->utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
        ERRORLOG("get NonceByAddr error");
        return PERROR(MEM::FAILED_TO_GET_NONCE,"addr:{}", tx->utxos(0).owner(0));
        }
	tx->set_nonce(nonce);

    tx->set_data(data.dump());
	tx->set_note(s_delegating_trans_param.encoded_info.str());
	//tx->set_type(global::ca::kTxSign);
    return "";
}
expected<bool> DelegatingTrans::checkParams()
{
    // 1. 地址有效性
    if (!isValidAddress(s_delegating_trans_param.from_addr.str())) {
        return PERROR(MEM::INVALID_ADDR);
    }
    if (!isValidAddress(s_delegating_trans_param.to_addr.str())) {
        return PERROR(MEM::INVALID_ADDR);
    }

    // 2. 投资金额 ≥ 最小值
    if (s_delegating_trans_param.delegatinged_amount < global::ca::kMinDelegatingAmt) {
        return PERROR(MEM::DELEGATING_AMOUNT_EXCEED_THE_LIMIT,
                      "amount:{} min:{}", s_delegating_trans_param.delegatinged_amount,
                      global::ca::kMinDelegatingAmt);
    }

    return true;
}


expected<int64_t> DelegatingTrans::getGasValue(CTxUtxos * u,int trans_index){
        uint64_t gasSize = tx.data().size() +  tx.note().size() + tx.reserve0().size() + tx.reserve1().size();
        uint64_t gas = 0;

        std::map<std::string, uint64_t> toAddrs;
	    toAddrs.insert(std::make_pair(global::ca::kTargetAddress, delegatinged_amount));
	    toAddrs.insert(std::make_pair(s_delegating_trans_param.from_addr.str(), total - expend));
        toAddrs.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
            
		if (GenerateGas(*u,  toAddrs.size(), gasSize, gas) != 0)
		{
			return PERROR(MEM::GAS_IS_ZERO);
		}
		if(GetInitAccountAddr() == s_delegating_trans_param.from_addr.str())
        {
        	gas = 0;
    	}
    return gas;
}
