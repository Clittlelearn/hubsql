﻿#pragma once
#include "utxo_core.h"
#include "CowString.hpp"
#include <cstdint>

/*投票*/

class VoteTrans:public ohi::UtxoCore{
public:
    
    struct VoteTransParam{
        ohi::CowString addr;
        ohi::UtxoCore::UtxoGasParam gas;
        bool is_gas_tray;
        ohi::CowString vote_hash;
        bool is_find_utxo;
        int vote_type;
        global::ca::TxType tx_type;
        ohi::CowString encoded_info;
    }s_vote_param;

    VoteTrans(const VoteTransParam & param):s_vote_param(param){}
    
    expected<bool> trans()override;
    expected<bool> goMessage()override;
protected:
   
   
    expected<bool> makeTxInfor(CTransaction * tx) override;
    expected<bool> checkParams()override;
    expected<int64_t> getGasValue(CTxUtxos *u, int index) override;
    expected<bool> makeTxData(CTransaction * tx);
private:
    uint64_t lockValue;
};
