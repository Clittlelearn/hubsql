﻿#include "fund.h"
#include "ca/algorithm.h"
#include "ca/global.h"
#include "ca/transaction.h"
#include "error.h"
#include "errorn/ca/error.def.h"
#include "pb/transaction.pb.h"
#include "transaction.pb.h"
#include "utils/account_manager.h"
#include "utils/bench_mark.h"
#include "utils/tmp_log.h"
#include "utils/version.h"
#include "common/genesis_helper.h"
#include "utxo_core.h"
#include "ca/address_status_cache.h"
#include "utils/magic_singleton.h"
#include <cstdint>

expected<bool> FundTrans::trans() {
    auto checkRet = checkParams();
    if (!checkRet.isOk()) {
        return checkRet.Error();
    }

  //  Check parameters
  std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator>
      all_set_out_utxos;

  // initialize transaction
  uint64_t totalGas = 0;
  std::string addr = s_fund_trans_param.addr.str();

  if (!isValidAddress(addr)) {
    // ERRORLOG("to from_addr is empty");
    // return -1;
    return PERROR(MEM::INVALID_ADDR);
  }

  int ret = ca_algorithm::fetchAvailableAssetType(asset_map);
  if (ret != 0) {
    // ERRORLOG("Get available asset fail! ret : {}",ret);
    // return -10;
    return PERROR(MEM::GET_UNAVAILABLE_ASSET);
  }

  DBReader dbReader;
  uint64_t current_time =
      MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
  uint64_t period =
      MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(current_time);
  TxHelper::ProposalInfo null;
  // 原强制插入Vote资产类型，现改为OHI
asset_map.insert({global::ca::ASSET_TYPE_OHI, null});

  std::map<std::string, uint64_t> asset_type_amount;
  for (const auto &per_asset_type : asset_map) {
    uint64_t gas_amount = 0;
    auto result = dbReader.getGasAmountByPeriod(
        period - 1, per_asset_type.first, gas_amount);
    if (result != DBStatus::DB_SUCCESS && result != DBStatus::DB_NOT_FOUND) {
      // ERRORLOG("GetGasamountbyTimeType error!");
      //             return -9;
      return PERROR(MEM::GET_GAS_AMOUNT_BY_TIME_TYPE_FAILED, "ret:{}", ret);
    }
    if (gas_amount != 0) {
      asset_type_amount.insert({per_asset_type.first, gas_amount});
    }
  }

  if (asset_type_amount.empty()) {
    // ERRORLOG("There was no fund reward the day before!");
    // return -999;
    return PERROR(MEM::NO_FUND_REWARD_THE_DAY_BEFORE);
  }

  for (const auto &i : asset_type_amount) {
    std::cout << "-----------------------------------------" << std::endl;
    std::cout << "assetType :" << i.first << "total fund amount :" << i.second
              << std::endl;
  }

  ret = CheckFundQualificationAndGetRewardAmount(addr, current_time,
                                                 return_value);
  if (ret != 0) {
    if (ret == -6) {
      // ERRORLOG( "You have already claimed the fund reward.",ret
      // ); return -998;
      return PERROR(MEM::HAVE_CLAIMED_THE_FUND_REWARD, "ret:{}", ret);
    } else {
      // ERRORLOG( "Error in checking eligibility for receiving fund",ret );
      // return -996;
      return PERROR(MEM::CHECK_INELIGIBILITY_FOR_RECEIVING_FUND, "{}", ret);
    }
  } else {
    if (dbReader.getTotalLockedAmonut(total_locked_amount) ==
            DBStatus::DB_SUCCESS &&
        total_locked_amount != 0) {
      DEBUGLOG("return_value : {}, total_locked_amount : {}", return_value,
               total_locked_amount);
    } else {
      ERRORLOG("Get total locked amount failed!");
    }
    if (return_value != 0 && total_locked_amount != 0) {
      is_locked = true;
    }
  }

  std::cout << "-----------------------------------------" << std::endl;
  std::cout << "node lockedAmount :" << return_value
            << "    totalLockedAmount :" << total_locked_amount
            << "       rate :"
            << (double(return_value) / double(total_locked_amount))
            << std::endl;

  bool canReward = VerifyBonusAddr(addr);
 
  if (canReward) {
    DEBUGLOG("Meet the pledge qualifications.");
    if (dbReader.getPackagerCountByPeriod(period - 1, addr, times) ==
            DBStatus::DB_SUCCESS && // dbReader.getPa
        dbReader.getBlockNumberByPeriod(period - 1, count) ==
            DBStatus::DB_SUCCESS) {
      DEBUGLOG("times : {}, count : {}", times, count);
    } else {
      ERRORLOG("Get addr package times failed!");
    }
    if (times != 0 && count != 0) {
      is_packaged = true;
    }
  }

  std::cout << "-----------------------------------------" << std::endl;
  std::cout << "node package count:" << times << "    total package count :"
            << "       rate :" << (double(times) / double(count)) << std::endl;
  std::cout << "-----------------------------------------" << std::endl;

  if (!is_packaged && !is_locked) {
    ERRORLOG("Nodes are not eligible to claim fund");
    return -11;
  }

  std::map<std::string, uint64_t> lockedReward;
  std::map<std::string, uint64_t> packageReward;

  for (const auto &per_asset_type : asset_type_amount) {
    CTxUtxos *utxo = tx.add_utxos();
    TransferToParam param;
    param.to = addr;
    param.asset_type = per_asset_type.first;
    // tx_utxo->add_owner(addr);
    // tx_utxo->set_assettype(per_asset_type.first);

    // TransferToParam to_param;
    // to_param.to = addr;
    // to_param.asset_type= per_asset_type.first;
    // createUtxoTransferTo(tx_utxo,to_param);

    // if(is_locked){
    // 	double rate = double(return_value) / double(total_locked_amount);
    // 	CTxOutput* vout =  tx_utxo->add_vout();
    // 	vout->set_addr(addr);
    // 	uint64_t value = uint64_t(rate * per_asset_type.second * 0.5);
    // 	vout->set_value(value);
    // 	lockedReward.insert({per_asset_type.first,value});
    // 	DEBUGLOG("isLocked");
    // }

    // if(is_packaged){
    // 	double rate = double(times) / double(count);
    // 	CTxOutput* vout =  tx_utxo->add_vout();
    // 	vout->set_addr(addr);
    // 	uint64_t value = uint64_t(rate * per_asset_type.second * 0.5);
    // 	vout->set_value(value);
    // 	packageReward.insert({per_asset_type.first,value});
    // 	DEBUGLOG("isPackage");
    // }

    FundTrans::createUtxoFundTransfer(utxo, param, s_fund_trans_param,
                                      per_asset_type);
  }
  auto info_ret = makeTxInfor(&tx);
  if (!info_ret.isOk()) {
    return info_ret << PERROR(MEM::GEN_VIN_FAIL, "make fund tx info failed");
  }

  current_time = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
  tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
  tx.set_time(current_time);
  tx.set_consensus(global::ca::kConsensus);
  tx.set_type((uint32_t)global::ca::TxType::FUND);

  DEBUGLOG("self hash:{}", ohi::UtxoCore::calculate_all_hash(&tx));
  std::string identity;
  TxHelper::vrfAgentType type;
  ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(&tx),
                                     current_time, identity, TxHelper::SelectLocalSelectionSigner(tx));
  if (ret != 0) {
    ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
    return PERROR(MEM::FAILED_TO_PICK_A_PACKAGER);
  }
  DEBUGLOG("Tx identity:{}", identity);
  tx.set_identity(identity);

  // std::string txHash = Getsha256Hash(tx.SerializeAsString());
  // tx.set_hash(txHash);
  DEBUGLOG("CreateFundTransaction tx time = {}, package = {}", tx.time(),
           tx.identity());

  return true;
}

expected<bool> FundTrans::goMessage() {
  TxMsgReq txMsg;

  uint64_t top = 0;
  auto retNum = transactionDiscoveryHeight();
  if (!retNum.isOk()) {
    return retNum << PERROR(MEM::FAILED_TO_GET_HEIGHT);
  }
  top = retNum.Value();
  txMsg.set_version(ohi::GetVersion());
  TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
  txMsgInfo->set_type(0);
  txMsgInfo->set_tx(tx.SerializeAsString());
  txMsgInfo->set_nodeheight(top);
  txMsgInfo->set_txutxoheight(top);
  int ret = 0;
  auto msg = std::make_shared<TxMsgReq>(txMsg);

  std::string defaultAddr =
      MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

  if (tx.identity() == defaultAddr) {
    ret = handleTransaction(msg, tx);

  } else {
    ret = DropShippingTransaction(msg, tx, tx.identity());
  }

  if (ret != 0) {
    // UtxoError().trace(UE_NOERROR,"%s => what:%s",ret).to_string();
    ret -= 100;
  }

  DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, tx.hash());
  return true;
}

expected<bool> FundTrans::makeTxInfor(CTransaction *tx) {

  nlohmann::json txInfo;
  txInfo["fundLockedAmount"] = locked_reward;
  txInfo["fundPackageAmount"] = packaged_reward;

  nlohmann::json data;
  data["txInfo"] = txInfo;

  const std::string dataDump = data.dump();
  if (dataDump.empty())
  {
      ERRORLOG("fund tx data dump is empty");
      return -3;
  }
  tx->set_data(dataDump);
  tx->set_note(s_fund_trans_param.encoded_info.str());

  if (tx->data().empty())
  {
      ERRORLOG("fund tx data is empty after set_data, locked_reward.size:{}, packaged_reward.size:{}",
               locked_reward.size(), packaged_reward.size());
      return -4;
  }

  if (tx->utxos_size() <= 0)
  {
      ERRORLOG("tx has no utxos!");
      return -1;
  }

  if (tx->utxos(0).owner_size() <= 0)
  {
      ERRORLOG("utxos(0) has no owner!");
      return -2;
  }


  uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(tx->utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
		db_reader.getNonceByAddr(tx->utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
		ERRORLOG("get NonceByAddr error");
		return PERROR(MEM::FAILED_TO_GET_NONCE,"addr:{}", tx->utxos(0).owner(0));
	}
	tx->set_nonce(nonce);

  // tx->set_type(global::ca::kTxSign);
  return true;
}
expected<bool> FundTrans::checkParams()
{
    // 1. 地址有效性
    if (!isValidAddress(s_fund_trans_param.addr.str())) {
        return PERROR(MEM::INVALID_ADDR);
    }

    return true;
}

void FundTrans::createUtxoFundTransfer(
    CTxUtxos *utxo, const FundTrans::TransferToParam &param,
    FundTransParam &s_fund_trans_param,
    std::pair<std::string, uint64_t> asset_type) {
  utxo->add_owner(param.to.str());
  utxo->set_assettype(param.asset_type.str());

  if (is_locked) {
    double rate = double(return_value) / double(total_locked_amount);
    CTxOutput *vout = utxo->add_vout();
    vout->set_addr(s_fund_trans_param.addr.str());
    uint64_t value = uint64_t(rate * asset_type.second * 0.5);
    vout->set_value(value);
    locked_reward.insert({asset_type.first, value});
    DEBUGLOG("isLocked");
  }

  if (is_packaged) {
    double rate = double(times) / double(count);
    CTxOutput *vout = utxo->add_vout();
    vout->set_addr(s_fund_trans_param.addr.str());
    uint64_t value = uint64_t(rate * asset_type.second * 0.5);
    vout->set_value(value);
    packaged_reward.insert({asset_type.first, value});
    DEBUGLOG("isPackage");
  }
}

expected<int64_t> FundTrans::getGasValue(CTxUtxos *u, int index) {
  uint64_t gas = 0;
  uint64_t gasSize = tx.data().size() + tx.note().size() +
                     tx.reserve0().size() + tx.reserve1().size();
  // The filled quantity only participates in the calculation and does not
  // affect others
  std::map<std::string, int64_t> toAddr;
  toAddr.insert(std::make_pair(global::ca::VIRTUAL_LOCK_ADDRESS, 0));
  toAddr.insert(std::make_pair(s_fund_trans_param.addr.str(), 0));
  toAddr.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));

  if (GenerateGas(*u, toAddr.size(), gasSize, gas) != 0) {
    ERRORLOG(" gas = 0 !");
    return PERROR(MEM::GAS_IS_ZERO);
  }
  if (GetInitAccountAddr() == s_fund_trans_param.addr.str()) 
  {
    gas = 0;
  }
  return gas;
}

expected<bool> FundTrans::signTransaction(const ohi::CowString &addr) {
  for (int i = 0; i < tx.utxos_size(); ++i) {
    int index = 0;
    auto utxo = tx.mutable_utxos(i);
    /// utxo sign
    CTxUtxos copyTransactionUtxo = *utxo;
    copyTransactionUtxo.clear_multisign();
    for (auto &owner : utxo->owner()) {
      {
        std::string serializeTransactionUtxoRequest =
            Getsha256Hash(copyTransactionUtxo.SerializeAsString());
        std::string signature;
        std::string pub;
        auto ret = sign(owner, serializeTransactionUtxoRequest);
        if (!ret.isOk()) {
          return ret << PERROR(MEM::SIGN_UTXO_FAIL);
        }
        CSign *multiSign = utxo->add_multisign();
        multiSign->set_sign(ret.Value().signature.str());
        multiSign->set_pub(ret.Value().pubkey.str());
      }
    }
  }

  std::string txHash = Getsha256Hash(tx.SerializeAsString());
  tx.set_hash(txHash);
  return true;
}
