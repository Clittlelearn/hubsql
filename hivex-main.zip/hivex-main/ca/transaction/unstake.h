﻿#pragma once

#include "utxo_core.h"
#include "CowString.hpp"


struct UnStakeParam{
       ohi::CowString addr;
       ohi::CowString assert_type;
       ohi::CowString stake_utxo_hash;
       ohi::UtxoCore::OtherToPayGas gas_tray;
       ohi::CowString encoded_info;
       uint64_t time;
      // uint64_t height;
       bool is_find_utxo=false;
       bool is_gas_tray;
       REFLECT(addr,assert_type,stake_utxo_hash,gas_tray,encoded_info,is_find_utxo,is_gas_tray)
};



class UnStake:public ohi::UtxoCore{
public:
    
    UnStakeParam s_unstake_param;

    UnStake(const UnStakeParam & param):s_unstake_param(param){}
    
    expected<bool> trans()override;
    expected<bool> goMessage()override;
    expected<int64_t> getGasValue(CTxUtxos * u,int index) override;
protected:
    std::uint64_t currentTime;
    expected<bool> makeTxInfor(CTransaction * tx) override;
    expected<bool> checkParams()override;
};