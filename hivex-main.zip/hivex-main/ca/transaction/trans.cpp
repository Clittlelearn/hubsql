﻿#include "trans.h"
#include "db_api.h"
#include "errorn/ca/error.def.h"
#include "error.h"
#include "logging.h"
#include "utils/bench_mark.h"
#include "utils/version.h"
#include "utxo_core.h"
#include "ca/global.h"
#include "pb/transaction.pb.h"
#include "transaction.pb.h"
#include "ca/transaction.h"
#include "utils/tmp_log.h"
#include "utils/version.h"
#include "common/genesis_helper.h"
#include <cstdint>




expected<bool> TransforerTrans::trans()
{
    auto checkRet = checkParams();
    if (!checkRet.isOk()) {
        return checkRet.Error();
    }

	uint64_t top = s_transforer_param.known_top;
    if (top == 0)
    {
        auto retNum = transactionDiscoveryHeight();
        if (!retNum.isOk())
        {
            return PERROR(MEM::FAILED_TO_GET_HEIGHT);
        }
        top = retNum.Value();
    }
   
	MagicSingleton<Benchmark>::GetInstance()->increase_transaction_initiate_amount();
	//  Check parameters

	
	std::vector<TxHelper::Utxo> allsetOutUtxos;
	uint64_t totalGas = 0;
	std::vector<std::string> doubleSpendUtxos;
	int index=0;
	for (auto &i : s_transforer_param.tx_asset)
	{
		std::string tempstring = i.fromAddr[0];
		tempstring += i.asset_type;
		doubleSpendUtxos.push_back(tempstring);
		int ret = TxHelper::Check(i.fromAddr, i.asset_type, top+1);
		if (ret != 0)
		{
			//ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
            return PERROR(MEM::CHECK_ADDR_ASSET_TYPE_HEIGHT_FAIL,"ret:{}",ret);
			// ret -= 100;
			// return ret;
		}

		if (i.toAddrAmount.empty())
		{
			// ERRORLOG("to addr is empty");
			// return -1;
            return PERROR(MEM::INVALID_ADDR);
		}

		for (auto &addr : i.toAddrAmount)
		{
			if (!isValidAddress(addr.first))
			{
				// ERRORLOG(RED "To address is not  address!" RESET);
				// return -2;
                return PERROR(MEM::INVALID_ADDR);
			}

			for (auto &from : i.fromAddr)
			{
				if (addr.first == from)
				{
					///ERRORLOG(RED "From address and to address is equal!" RESET);
                    return PERROR(MEM::INVALID_ADDR,"From address and to address is equal!");
					
				}
			}

			if (addr.second <= 0)
			{
				// ERRORLOG(RED "Value is zero!" RESET);
                return PERROR(MEM::INVALID_ADDR,"value is zero");
				
			}
		}

		uint64_t amount = 0; // Transaction fee
		for (auto &i : i.toAddrAmount)
		{
			amount += i.second;
		}
		uint64_t expend = amount;
        
        TransferFromParam from_param;

        from_param.from = i.fromAddr[0];
        from_param.asset_type = i.asset_type;
        from_param.amount = expend;
		from_param.is_find_utxo=s_transforer_param.is_find_utxo;
        auto u=tx.add_utxos();
        auto fromret=createUtxoTransferFrom(u,from_param,0);
        if(!fromret.isOk()){
            return fromret<< PERROR(MEM::GEN_VIN_FAIL);
        }

		tx.set_data("");
		tx.set_note(s_transforer_param.encoded_info.str());
		//tx.set_type(global::ca::kTxSign);

        auto gasre=getGasValue(u,index);
        if(!gasre.isOk()){
            return gasre<< PERROR(MEM::GET_GAS_VALUE_FAIL);
        }

        int64_t gas=gasre.Value();
       

		

		DEBUGLOG("expend = {}", expend);
		if (s_transforer_param.is_gas_tray)
		{
			totalGas += gasre.Value();
		}
		else
		{
			expend += gasre.Value();
		}
		DEBUGLOG("totalGas = {} , expendGas = {} gas = {}", totalGas, expend,gas);
        int64_t total = fromret.Value();
		// Judge whether utxo is enough
		if (total < expend)
		{
			ERRORLOG("The total cost = {} is less than the cost = {}", total, expend);
            return PERROR(MEM::BALANCE_IS_INSUFFICIENT,"total:{},expend:{}" , total, expend);
		}

		// Fill vout
        
		for (auto &to : i.toAddrAmount)
		{

            TransferToParam to_param;
            to_param.to=to.first;
            to_param.amount=to.second;
            createUtxoTransferTo(u,to_param);
			
		}
        TransferToParam to_self_param;
        to_self_param.to=*(i.fromAddr.rbegin());
        to_self_param.amount=total - expend;
        createUtxoTransferTo(u,to_self_param);

		

		if (s_transforer_param.is_gas_tray)
		{    TransferToParam to_burn_param;
            to_burn_param.amount=0;
            to_burn_param.to=global::ca::VIRTUAL_BURN_GAS_ADDR;
            createUtxoTransferTo(u,to_burn_param);
			
		}
		else
		{
             TransferToParam to_burn_param;
            to_burn_param.amount=gas;
            to_burn_param.to=global::ca::VIRTUAL_BURN_GAS_ADDR;
            createUtxoTransferTo(u,to_burn_param);
			
		}
	}

	if(s_transforer_param.is_gas_tray)
	{
		UtxoGasParam param;
    	param.asset_type = s_transforer_param.gas_tray.asset_type;
    	param.from = s_transforer_param.gas_tray.addr;
    	param.gas=totalGas;
     	auto gasret= createUtxoGas(&tx, param);
   		if(!gasret.isOk()){
        	return gasret<< PERROR(MEM::GEN_GAS_UTXO_FAIL);
   		}
	}

	auto makeInfoRet = makeTxInfor(&tx);
	if(!makeInfoRet.isOk()){
		ERRORLOG("TransforerTrans makeTxInfor failed: {}", makeInfoRet.error_message());
		return makeInfoRet << PERROR(MEM::FAILED_TO_PICK_A_PACKAGER, "makeTxInfor failed");
	}
	if(tx.identity().empty()){
		ERRORLOG("TransforerTrans makeTxInfor produced empty identity, tx.hash:{}", tx.hash());
		return PERROR(MEM::FAILED_TO_PICK_A_PACKAGER, "empty transaction identity");
	}

	
   	
    return true;
}


expected<bool> TransforerTrans::goMessage(){

			uint64_t top = s_transforer_param.known_top;
			if (top == 0)
			{
				auto retNum = transactionDiscoveryHeight();
				if (!retNum.isOk())
				{
					return retNum << PERROR(MEM::FAILED_TO_GET_HEIGHT);
				}
				top = retNum.Value();
			}

		TxMsgReq txMsg;
        txMsg.set_version(ohi::GetVersion());
        TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
        txMsgInfo->set_type(0);
        txMsgInfo->set_tx(tx.SerializeAsString());
        txMsgInfo->set_nodeheight(top);

        uint64_t txUtxoLocalHeight;
        auto ret = TxHelper::get_tx_utxo_height(tx, txUtxoLocalHeight);
        if (ret != 0)
        {
            return PERROR(MEM::FAILED_TO_GET_UTXO_HEIGHT,"ret:{}",ret);
        }

        txMsgInfo->set_txutxoheight(txUtxoLocalHeight);
        
        auto msg = std::make_shared<TxMsgReq>(txMsg);
        std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

        if (tx.identity() == defaultAddr)
        {
            ret = handleTransaction(msg, tx);
        }
        else
        {
            ret = DropShippingTransaction(msg, tx, tx.identity());
        }
    return true;
}

expected<bool> TransforerTrans::makeTxInfor(CTransaction * tx_){
    
    

	auto currentTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	
	tx.set_time(currentTime);
	tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	tx.set_consensus(global::ca::kConsensus);
	tx.set_type((uint32_t)global::ca::TxType::TX);

	if (tx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -1;
    }

    if (tx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -2;
    }


	uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
		db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
		ERRORLOG("get NonceByAddr error");
		return PERROR(MEM::FAILED_TO_GET_NONCE,"addr:{}", tx.utxos(0).owner(0));
	}
	tx.set_nonce(nonce);

	std::string identity;
	TxHelper::vrfAgentType type=TxHelper::vrfAgentType_vrf;
	int ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(&tx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(tx));
	if (ret != 0)
	{
		return PERROR(MEM::FAILED_TO_PICK_A_PACKAGER,"ret:{}", ret);
	}
	ERRORLOG("Tx identity:{}", identity);
	tx.set_identity(identity);
	
	ERRORLOG("getTransactionStartIdentity tx time = {}, package = {}", tx.time(), tx.identity());
	

	// std::string txHash = Getsha256Hash(tx.SerializeAsString());
	// tx.set_hash(txHash);

    return "";
}
expected<bool> TransforerTrans::checkParams()
{
    // 1. 遍历所有 tx_asset 进行基础校验
    for (const auto& asset : s_transforer_param.tx_asset) {
        // 地址有效性
        for (const auto& from : asset.fromAddr) {
            if (!isValidAddress(from)) {
                return PERROR(MEM::INVALID_ADDR, "from address invalid");
            }
        }
        for (const auto& [to, amount] : asset.toAddrAmount) {
            if (!isValidAddress(to)) {
                return PERROR(MEM::INVALID_ADDR, "to address invalid");
            }
            // from ≠ to
            for (const auto& from : asset.fromAddr) {
                if (to == from) {
                    return PERROR(MEM::INVALID_ADDR, "from and to address are equal");
                }
            }
            // 金额 > 0
            if (amount <= 0) {
                return PERROR(MEM::INVALID_ADDR, "transfer amount must be > 0");
            }
        }
        // toAddrAmount 非空
        if (asset.toAddrAmount.empty()) {
            return PERROR(MEM::INVALID_ADDR, "toAddrAmount is empty");
        }
    }

    return true;
}
expected<int64_t> TransforerTrans::getGasValue(CTxUtxos * u,int trans_index){
        uint64_t gasSize = tx.data().size() +  tx.note().size() + tx.reserve0().size() + tx.reserve1().size();
		uint64_t gas = 0;
		//std::map<std::string, int64_t> targetAddrs = i.toAddrAmount;
        std::map<std::string, int64_t> targetAddrs = s_transforer_param.tx_asset[trans_index].toAddrAmount;
		targetAddrs.insert({"cost",/*tatol-expend*/0});
		targetAddrs.insert(make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
		if (GenerateGas(*u,  targetAddrs.size(), gasSize, gas) != 0)
		{
			return PERROR(MEM::GAS_IS_ZERO);
		}
		if(GetInitAccountAddr() == s_transforer_param.tx_asset[trans_index].fromAddr[0])
		{
        	gas = 0;
    	}
    return gas;
}
