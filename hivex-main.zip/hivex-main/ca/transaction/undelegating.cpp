﻿#include "undelegating.h"
#include "errorn/ca/error.def.h"
#include "error.h"
#include "utils/account_manager.h"
#include "utils/bench_mark.h"
#include "utils/version.h"
#include "utxo_core.h"
#include "ca/global.h"
#include "pb/transaction.pb.h"
#include "transaction.pb.h"
#include "ca/transaction.h"
#include "utils/tmp_log.h"
#include "utils/version.h"
#include "common/genesis_helper.h"
#include "ca/address_status_cache.h"
#include "utils/magic_singleton.h"
#include <cstdint>

expected<bool> UndelegatingTrans::trans()
{
    auto checkRet = checkParams();
    if (!checkRet.isOk()) {
        return checkRet.Error();
    }

    uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk()){
       	return  PERROR(MEM::FAILED_TO_GET_HEIGHT);;
    }
	top=retNum.Value();
    const uint64_t height = top + 1;
    std::string from_addr = s_undelegating_trans_param.from_addr.str();
    std::string to_addr = s_undelegating_trans_param.to_addr.str();
    std::string asset_type = s_undelegating_trans_param.asset_type.str();
    std::string utxo_hash = s_undelegating_trans_param.utxo_hash.str();

    std::vector<std::string> address_vector;
    address_vector.push_back(from_addr);
    int ret = TxHelper::Check(address_vector, asset_type, height);
    if (ret != 0)
    {
        return  PERROR(MEM::CHECK_ADDR_ASSET_TYPE_HEIGHT_FAIL,"ret:{}",ret);
    }

    if (!isValidAddress(from_addr))
    {
        return PERROR(MEM::INVALID_ADDR);
    }


    if (!isValidAddress(to_addr))
    {
        // ERRORLOG(RED "To address is not  address!" RESET);
        // return -2;
        return PERROR(MEM::INVALID_ADDR);
    }

	if(IsQualifiedToUndelegating(from_addr, asset_type, to_addr, utxo_hash, delegatinged_amount) != 0)
	{
	    return PERROR(MEM::NOT_QUALIFIED_FOR_UNDELEGATION,"ret:{}",ret);
	}

    tx.Clear();
    CTxUtxos *u = tx.add_utxos();
    u->set_assettype(asset_type);
    u->add_owner(from_addr);
    CTxInput *txin = u->add_vin();
    txin->set_sequence(0);
    CTxPrevOutput* prevout = txin->add_prevout();
    prevout->set_hash(utxo_hash);
    prevout->set_n(1);

    nlohmann::json txInfo;
    txInfo["bonusAddr"] = to_addr;
	txInfo["undelegatingUtxo"] = utxo_hash;
	nlohmann::json data;
	data["txInfo"] = txInfo;
    tx.set_data(data.dump());
    tx.set_note(s_undelegating_trans_param.encoded_info.str());

    CTxOutput* outputAddress = u->add_vout();
    outputAddress->set_addr(from_addr);
    outputAddress->set_value(delegatinged_amount);

    auto current_time = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    TxHelper::vrfAgentType type=TxHelper::vrfAgentType::vrfAgentType_vrf;
    TxHelper::getTransactionStartIdentity(height, current_time, type);

    tx.set_time(current_time);
	tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	tx.set_consensus(global::ca::kConsensus);
	tx.set_type((uint32_t)global::ca::TxType::UNDELEGATE);

    if (tx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return PERROR(MEM::GEN_VIN_FAIL, "tx has no utxos");
    }

    if (tx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return PERROR(MEM::GEN_VIN_FAIL, "utxos(0) has no owner");
    }

    uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
	   db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
		ERRORLOG("get NonceByAddr error, addr:{}", tx.utxos(0).owner(0));
		return PERROR(MEM::FAILED_TO_GET_NONCE,"addr:{}", tx.utxos(0).owner(0));
	}
	tx.set_nonce(nonce);

	DEBUGLOG("self hash:{}", calculate_all_hash(&tx));
    std::string identity;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(&tx), current_time, identity, TxHelper::SelectLocalSelectionSigner(tx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return PERROR(MEM::FAILED_TO_PICK_A_PACKAGER, "ret:{}", ret);
	}
	DEBUGLOG("Tx identity:{}", identity);
	tx.set_identity(identity);

	tx.clear_hash();
	tx.clear_signature();
	std::string txHash = Getsha256Hash(tx.SerializeAsString());
	tx.set_hash(txHash);
    DEBUGLOG("CreateUndelegatingTransaction tx time = {}, package = {}",
             tx.time(), tx.identity());

    return true;
}

expected<bool> UndelegatingTrans::goMessage()
{     TxMsgReq txMsg;

    uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk() ){
        return retNum<< PERROR(MEM::FAILED_TO_GET_HEIGHT);
    }
    top=retNum.Value();
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(tx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    auto ret = TxHelper::get_tx_utxo_height(tx, txUtxoLocalHeight);
    if(ret != 0)
    {
        return PERROR(MEM::FAILED_TO_GET_UTXO_HEIGHT);
        
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    auto msg = std::make_shared<TxMsgReq>(txMsg);

    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

    if(tx.identity() == defaultAddr)
    {
        ret = handleTransaction(msg,tx);
        
    }
    else
    {
        ret = DropShippingTransaction(msg, tx, tx.identity());
    }

    if (ret != 0)
    {
        //UtxoError().trace(UE_NOERROR,"%s => what:%s",ret).to_string();
        ret -= 100;
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, tx.hash());
    return true;
}

 expected<bool> UndelegatingTrans::makeTxInfor(CTransaction * tx){

    nlohmann::json txInfo;
  	txInfo["bonusAddr"] = s_undelegating_trans_param.to_addr.str();
	txInfo["undelegatingUtxo"] = s_undelegating_trans_param.utxo_hash.str();

	nlohmann::json data;
	data["txInfo"] = txInfo;

    tx->set_data(data.dump());
    tx->set_note(s_undelegating_trans_param.encoded_info.str());

    if (tx->utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -1;
    }

    if (tx->utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -2;
    }

    uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(tx->utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
	db_reader.getNonceByAddr(tx->utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
	ERRORLOG("get NonceByAddr error");
	return PERROR(MEM::FAILED_TO_GET_NONCE,"addr:{}", tx->utxos(0).owner(0));
	}
	tx->set_nonce(nonce);
	//tx->set_type(global::ca::kTxSign);
    return true;
}
expected<bool> UndelegatingTrans::checkParams()
{
    // 1. 地址有效性
    if (!isValidAddress(s_undelegating_trans_param.from_addr.str())) {
        return PERROR(MEM::INVALID_ADDR);
    }
    if (!isValidAddress(s_undelegating_trans_param.to_addr.str())) {
        return PERROR(MEM::INVALID_ADDR);
    }

    return true;
}


expected<int64_t> UndelegatingTrans::getGasValue(CTxUtxos * u,int trans_index){
        uint64_t gasSize = tx.data().size() + tx.note().size() + tx.reserve0().size() + tx.reserve1().size();
        uint64_t gas = 0;
        std::map<std::string, int64_t> targetAddrs;
	    targetAddrs.insert(std::make_pair(global::ca::kTargetAddress, delegatinged_amount));
	    targetAddrs.insert(std::make_pair(s_undelegating_trans_param.from_addr.str(), total ));
	    targetAddrs.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas ));
		if (GenerateGas(*u,  targetAddrs.size(), gasSize, gas) != 0)
		{
			return PERROR(MEM::GAS_IS_ZERO);
		}
		if(GetInitAccountAddr() == s_undelegating_trans_param.from_addr.str())
        {
        	gas = 0;
    	}
    return gas;
}
