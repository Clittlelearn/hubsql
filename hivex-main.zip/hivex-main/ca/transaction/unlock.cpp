﻿#include "unlock.h"
#include "ca/transaction.h"

#include "common/genesis_helper.h"
#include "db/db_api.h"
#include "error.h"
#include "errorn/ca/error.def.h"
#include "utils/version.h"
#include "ca/address_status_cache.h"
#include "utils/magic_singleton.h"

expected<bool> UnlockTrans::trans()
{
    auto checkRet = checkParams();
    if (!checkRet.isOk()) {
        return checkRet.Error();
    }

	uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk()){
       	return  PERROR(MEM::FAILED_TO_GET_HEIGHT);;
    }
	top=retNum.Value();
    const uint64_t height = top + 1;
    const std::string fromAddr = s_unlock_param.lock_addr.str();
    const std::string utxoHash = s_unlock_param.utxo_hash.str();

	std::vector<std::string> addressVector;
	addressVector.push_back(fromAddr);
	//need read from database
	std::string currencyType = global::ca::ASSET_TYPE_OHI;
	int ret = TxHelper::Check(addressVector, currencyType, height);
	if(ret != 0)
	{
		ERRORLOG( "Check parameters failed! The error code is {}." , ret);
		return  PERROR(MEM::CHECK_ADDR_ASSET_TYPE_HEIGHT_FAIL,"ret:{}",ret);
	}

	if (!isValidAddress(fromAddr))
	{
		ERRORLOG( "FromAddr is not normal  addr." );
		return PERROR(MEM::INVALID_ADDR);
	}


	uint64_t lock_amount = 0;
	ret = IsQualifiedToUnLock(fromAddr, utxoHash, lock_amount, global::ca::ASSET_TYPE_OHI);
	if(ret != 0)
	{
		ERRORLOG( "FromAddr is not qualified to unlock! The error code is {}." , ret);
		return PERROR(MEM::NOT_QUALIFIED_TO_UNLOCK,"ret:{}",ret);
	}	

	tx.Clear();
    CTxUtxos * txUtxo = tx.add_utxos();
	txUtxo->set_assettype(currencyType);
	txUtxo->add_owner(fromAddr);
	CTxInput* txin = txUtxo->add_vin();
	txin->set_sequence(0);
	CTxPrevOutput* prevout = txin->add_prevout();
	prevout->set_hash(utxoHash);
	prevout->set_n(1);

	nlohmann::json txInfo;
	txInfo["unLockUtxo"] = utxoHash;
	nlohmann::json data;
	data["txInfo"] = txInfo;
	tx.set_data(data.dump());
	tx.set_note(s_unlock_param.encoded_info.str());

	CTxOutput* outputAddress = txUtxo->add_vout();
	outputAddress->set_addr(fromAddr);
	outputAddress->set_value(lock_amount);

	auto currentTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	TxHelper::vrfAgentType type=TxHelper::vrfAgentType::vrfAgentType_vrf;
	TxHelper::getTransactionStartIdentity(height, currentTime, type);

	tx.set_time(currentTime);
	tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	tx.set_consensus(global::ca::kConsensus);
	tx.set_type((uint32_t)global::ca::TxType::UNLOCK);

	if (tx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return PERROR(MEM::GEN_VIN_FAIL, "tx has no utxos");
    }

    if (tx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return PERROR(MEM::GEN_VIN_FAIL, "utxos(0) has no owner");
    }

	uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
	   db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
		ERRORLOG("get NonceByAddr error, addr:{}", tx.utxos(0).owner(0));
		return PERROR(MEM::FAILED_TO_GET_NONCE,"addr:{}", tx.utxos(0).owner(0));
	}
	tx.set_nonce(nonce);

	DEBUGLOG("self hash:{}", calculate_all_hash(&tx));
	
	std::string identity;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(&tx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(tx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return PERROR(MEM::FAILED_TO_PICK_A_PACKAGER,"fetchIdentityNodes fail!!! ret:{}",ret);
	}
	DEBUGLOG("Tx identity:{}", identity);
        tx.set_identity(identity);

        tx.clear_hash();
        tx.clear_signature();
        std::string txHash = Getsha256Hash(tx.SerializeAsString());
        tx.set_hash(txHash);
        DEBUGLOG("CreateUnlockTransaction tx time = {}, package = {}", tx.time(), tx.identity());
        return true;
}

expected<bool> UnlockTrans::goMessage()
{

	uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk() ){
        return retNum<< PERROR(MEM::FAILED_TO_GET_HEIGHT);
   	}
	top=retNum.Value();
	TxMsgReq txMsg;
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(tx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    auto ret = TxHelper::get_tx_utxo_height(tx, txUtxoLocalHeight);
    if(ret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
		return PERROR(MEM::FAILED_TO_GET_UTXO_HEIGHT,"ret:{}",ret);
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    auto msg = std::make_shared<TxMsgReq>(txMsg);

    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(tx.identity() == defaultAddr)
    {
        ret = handleTransaction(msg,tx);
    }
    else
    {
        ret = DropShippingTransaction(msg, tx, tx.identity());
    }

    if (ret != 0)
    {
        ret -= 100;
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, tx.hash());
	return true;
}

expected<bool> UnlockTrans::makeTxInfor(CTransaction *)
{
    nlohmann::json txInfo;
	txInfo["unLockUtxo"] = s_unlock_param.utxo_hash.str();

	nlohmann::json data;
	data["txInfo"] = txInfo;
	tx.set_data(data.dump());
	tx.set_note(s_unlock_param.encoded_info.str());
	//tx.set_type(global::ca::kTxSign);	
	tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);

	if (tx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -1;
    }

    if (tx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -2;
    }


	uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
	db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
	ERRORLOG("get NonceByAddr error");
	return PERROR(MEM::FAILED_TO_GET_NONCE,"addr:{}", tx.utxos(0).owner(0));
	}
	tx.set_nonce(nonce);

	return true;
}

expected<int64_t> UnlockTrans::getGasValue(CTxUtxos * u,int trans_index)
{
    uint64_t gas = 0;
	uint64_t gasSize = tx.data().size() +  tx.note().size() + tx.reserve0().size() + tx.reserve1().size();
	//The filled quantity only participates in the calculation and does not affect others
	std::map<std::string, int64_t> toAddr;
	toAddr.insert(std::make_pair(global::ca::VIRTUAL_LOCK_ADDRESS, 0));
	toAddr.insert(std::make_pair(s_unlock_param.lock_addr.str(), 0));
	toAddr.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));

	if(GenerateGas(*u, toAddr.size(), gasSize, gas) != 0)
	{
		ERRORLOG(" gas = 0 !");
		return PERROR(MEM::GAS_IS_ZERO);
	}
	if(GetInitAccountAddr() == s_unlock_param.lock_addr.str())
	{
        gas = 0;
    }
    return gas;
}

expected<bool> UnlockTrans::checkParams()
{
    // 1. 地址有效性
    if (!isValidAddress(s_unlock_param.lock_addr.str())) {
        return PERROR(MEM::INVALID_ADDR);
    }

    // 2. utxo_hash 非空
    if (s_unlock_param.utxo_hash.str().empty()) {
        return PERROR(MEM::INVALID_ADDR, "utxo_hash is empty");
    }

    return true;
}
