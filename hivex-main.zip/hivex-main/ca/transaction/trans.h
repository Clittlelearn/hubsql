﻿#pragma once

#include "utxo_core.h"
#include "interface.pb.h"
#include "transaction.pb.h"
#include "txhelper.h"
#include "CowString.hpp"
#include <cstdint>



struct TransforerTransParam{
       std::vector<TxHelper::TransTable> tx_asset;
       ohi::UtxoCore::OtherToPayGas gas_tray;
       ohi::CowString encoded_info;
       uint64_t known_top = 0;
       bool is_find_utxo=false;
       bool is_gas_tray;
       REFLECT(tx_asset,gas_tray,encoded_info,known_top,is_gas_tray,is_find_utxo);
};


class TransforerTrans:public ohi::UtxoCore{
public:
    
    TransforerTransParam s_transforer_param;

    TransforerTrans(const TransforerTransParam & param):s_transforer_param(param){}

    
    expected<bool> trans()override;
    expected<bool> goMessage()override;
protected:
    expected<bool> makeTxInfor(CTransaction * tx) override;
    expected<bool> checkParams()override;
    expected<int64_t> getGasValue(CTxUtxos * u,int trans_index) override;
private:

};



