﻿#include "utxo_core.h"
#include "algorithm.h"
#include "block_helper.h"
#include "common/global_data.h"
#include "db_api.h"
#include "google/protobuf/util/json_util.h"
#include "net/peer_node.h"
#include "sync_block.h"
#include "transaction.h"
#include "transaction.pb.h"
#include "txhelper.h"
#include "utils/account_manager.h"
#include "utils/tmp_log.h"
#include "errorn/ca/error.def.h"
#include "error.h"
namespace ohi {

expected<bool> UtxoCore::signUtxo(const ohi::CowString &addr,
                                       CTxUtxos *utxo) {
  ohi::CowString serializeTransactionUtxoRequest =
      Getsha256Hash(utxo->SerializeAsString());

  expected<SingRe> singre = sign(addr, serializeTransactionUtxoRequest);

  if (!singre.isOk()) {
    return singre << PERROR(MEM::SIGN_UTXO_FAIL);
  }
  SingRe ms = singre.Value();
  CSign *multiSign = utxo->add_multisign();
  multiSign->set_sign(ms.signature.str());
  multiSign->set_pub(ms.pubkey.str());
  return true;
}

void UtxoCore::print_debug_tx(CTransaction *tx_) {
  if (tx_ == nullptr) {
    google::protobuf::util::JsonPrintOptions options;
    options.add_whitespace = true;
    options.always_print_primitive_fields = true;
    options.preserve_proto_field_names = true;
    std::string jsonString;
    auto status =
        google::protobuf::util::MessageToJsonString(tx, &jsonString, options);
    if (!status.ok()) {
      ERRORLOG("Failed to convert protobuf message to JSON: {}",
               status.ToString());
      return;
    }
    std::cout << "Transaction JSON:\n" << jsonString << std::endl;
  } else {
    google::protobuf::util::JsonPrintOptions options;
    options.add_whitespace = true;
    options.always_print_primitive_fields = true;
    options.preserve_proto_field_names = true;
    std::string jsonString;
    auto status =
        google::protobuf::util::MessageToJsonString(*tx_, &jsonString, options);
    if (!status.ok()) {
      ERRORLOG("Failed to convert protobuf message to JSON: {}",
               status.ToString());
      return;
    }
    std::cout << "Transaction JSON:\n" << jsonString << std::endl;
  }
}

void UtxoCore::createUtxoTransferTo(CTxUtxos *utxo,
                                    const TransferToParam &param) {
  CTxOutput *output = utxo->add_vout();
  output->set_addr(param.to.str());
  output->set_value(param.amount);
}

expected<int64_t>
UtxoCore::createUtxoTransferFrom(CTxUtxos *utxo, const TransferFromParam &param,
                                 int64_t sq) {

  // 设置查找UTXO的参数
  FindUtxoParam findParam;
  findParam.addr = param.from;
  findParam.asset_type = param.asset_type;
  findParam.need_amount = param.amount;

  // 初始化余额变量
  uint64_t balance = 0;

  utxo->set_assettype(param.asset_type.str());

  // 根据地址查找UTXO并检查余额
//  auto vect_utxos = findUtxoByAddrAndCheckBalance(findParam, balance);

  std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator>
      outputUtxosSet;

  std::multimap<std::string, std::string> fromAddr_assetType;
  fromAddr_assetType.insert({param.from.str(), param.asset_type.str()});
  int ret = TxHelper::FindUtxo(fromAddr_assetType, TxHelper::MAX_VIN_SIZE, balance,outputUtxosSet, param.is_find_utxo);
  if (ret != 0) {
    ERRORLOG( "FindUtxo failed! The error code is {} " , ret);
    std::cout << Sutil::Format("addr:%s,assettype:%s,ret:%s,is_find_utxo:%s", param.from.str(),param.asset_type.str(),ret,param.is_find_utxo) << std::endl;
    return PERROR(MEM::FIND_UTXO_FAIL,"addr:{},asset_type:{}",param.from.str(),param.asset_type.str());
  }



  if (outputUtxosSet.empty()) {
    ERRORLOG( "Utxo is empty!" );
     return PERROR(MEM::FIND_UTXO_FAIL);
  }
  utxo->set_assettype(param.asset_type.str());
  //  Fill Vin
  std::set<std::string> setTxOwners;
  for (auto &utxo : outputUtxosSet) {
    setTxOwners.insert(utxo.addr);
  }

  if (setTxOwners.size() != 1) {
      ERRORLOG( "Tx owner is invalid!" );
      return PERROR(MEM::FIND_UTXO_FAIL);
  }

  for (auto &owner : setTxOwners) {
    utxo->add_owner(owner);
    uint32_t n = sq;
    CTxInput *vin = utxo->add_vin();
    for (auto &utxo : outputUtxosSet) {
      if (owner == utxo.addr) {
        CTxPrevOutput *prevOutput = vin->add_prevout();
        prevOutput->set_hash(utxo.hash);
        prevOutput->set_n(utxo.n);
      }
    }
    vin->set_sequence(n++);

 
  }

  
  return balance;
}

expected<bool> UtxoCore::signTx(const ohi::CowString &addr,const bool isRLPTransaction) {
  for (int i = 0; i < tx.utxos_size(); ++i) {
    int index = 0;
    auto utxo = tx.mutable_utxos(i);
    auto vin = utxo->mutable_vin();
    for (auto &owner : utxo->owner()) {
      // vin sign

      if (utxo->vin_size() == 0) {
         // std::cout << "vin_size is 0" << std::endl;
          continue;
      }
      auto vin_t = vin->Mutable(index);
      if (!vin_t->contractaddr().empty()) {
          index++;
          std::cout << "contractaddr is not empty" << std::endl;
          continue;
      }

      std::string vinHashSerialized = Getsha256Hash(vin_t->SerializeAsString());
      std::string signature;
      std::string pub;
      
      auto ret = expected<SingRe>(PERROR(MEM::SIGN_VIN_FAIL));
      if(isRLPTransaction){
         ret = sign(addr, vinHashSerialized);
      }else{
         ret = sign(owner, vinHashSerialized);
      }
      // auto ret = sign(owner, vinHashSerialized);
     // std::cout << "signature12333:" << ret.unwrap().signature.str() << std::endl;
      if (!ret.isOk()) {
        return ret << PERROR(MEM::SIGN_VIN_FAIL);
      }

      CSign *vinSign = vin_t->mutable_vinsign();
      vinSign->set_sign(ret.Value().signature.str());
      vinSign->set_pub(ret.Value().pubkey.str());
      index++;
    }
    /// utxo sign
    CTxUtxos copyTransactionUtxo = *utxo;
    copyTransactionUtxo.clear_multisign();
    std::set<std::string> setTxOwners;


    for( auto &owner : utxo->owner()) {
      setTxOwners.insert(owner);
    }

    for (auto &owner : setTxOwners) {
      {
        std::string serializeTransactionUtxoRequest =
            Getsha256Hash(copyTransactionUtxo.SerializeAsString());
        std::string signature;
        std::string pub;
        auto ret = expected<SingRe>(PERROR(MEM::SIGN_UTXO_FAIL));
        if(isRLPTransaction){
          ret = sign(addr, serializeTransactionUtxoRequest);
        }else{
          ret = sign(owner, serializeTransactionUtxoRequest);
        }
        if (!ret.isOk()) {
          return ret << PERROR(MEM::SIGN_UTXO_FAIL);
        }
        CSign *multiSign = utxo->add_multisign();
        multiSign->set_sign(ret.Value().signature.str());
        multiSign->set_pub(ret.Value().pubkey.str());
      }
    }


  }
  tx.clear_hash();
  tx.clear_signature();
  std::string txHash = Getsha256Hash(tx.SerializeAsString());
  tx.set_hash(txHash);
  return true;
}

expected<int64_t> UtxoCore::createUtxoGas(CTransaction *tx,
                                               const UtxoGasParam &param) {
  CTxUtxos *u = tx->add_utxos();
  TransferFromParam VinParam;
  VinParam.from = param.from;
  VinParam.amount = param.gas;
  VinParam.asset_type = param.asset_type;
  auto BalnaceRet = createUtxoTransferFrom(u, VinParam, 0);
  if (!BalnaceRet.isOk()) {
    return BalnaceRet << PERROR(MEM::GEN_VIN_FAIL);
  }

  u->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE); // 这是支付gas的utxo
  tx->set_independence(global::ca::TX_INDEPENDENCE_TRUE);  // 这笔交易中有其他币种支付gas的utxo

  TransferToParam to_self;
  TransferToParam to_burn;

  to_self.amount = BalnaceRet.Value() - param.gas;
  to_self.to = param.from;

  to_burn.amount = param.gas;
  to_burn.to = global::ca::VIRTUAL_BURN_GAS_ADDR;

  createUtxoTransferTo(u, to_self);
  createUtxoTransferTo(u, to_burn);

  // auto singre = signUtxo(param.from, u);

  // if (singre.is_error()) {
  //   return singre.get_error();
  // }
  return 0;
}


expected<int64_t> UtxoCore::createUtxoGasBylameda(CTransaction *tx,
                                               const UtxoGasParam &param,const std::function<uint64_t(CTxUtxos *u,int index)> & gasLamda) {
  CTxUtxos *u = tx->add_utxos();
  TransferFromParam VinParam;
  VinParam.from = param.from;
  //VinParam.amount = param.gas;
  VinParam.asset_type = param.asset_type;
  auto BalnaceRet = createUtxoTransferFrom(u, VinParam, 0);
  if (!BalnaceRet.isOk()) {
    return BalnaceRet << PERROR(MEM::GEN_VIN_FAIL);
  }

  u->set_gas(global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE); // 这是支付gas的utxo
  tx->set_independence(global::ca::TX_INDEPENDENCE_TRUE);  // 这笔交易中有其他币种支付gas的utxo

  TransferToParam to_self;
  TransferToParam to_burn;


  uint64_t gas=gasLamda(u,0);

  to_self.amount = BalnaceRet.Value() - gas;
  to_self.to = param.from;

  to_burn.amount =gas;
  to_burn.to = global::ca::VIRTUAL_BURN_GAS_ADDR;

  createUtxoTransferTo(u, to_self);
  createUtxoTransferTo(u, to_burn);


  return 0;
}


expected<int64_t>
UtxoCore::getStakeAmount(const ohi::CowString &addr,
                         const ohi::CowString &assetType) {
  DBReader dbReader;
  std::vector<std::string> utxos;
  auto status = dbReader.getStakeUtxoByAddr(addr.str(), assetType.str(), utxos);
  //dbReader.getStakeUtxoByAddr(const std::string &address, const std::string &assetType, std::vector<std::string> &utxos)
  if (DBStatus::DB_SUCCESS != status) {
    return 0;
  }
  int64_t total = 0;
  for (auto &item : utxos) {
    std::string txRawData;
    if (DBStatus::DB_SUCCESS !=
        dbReader.getTransactionByHash(item, txRawData)) {
      continue;
    }
    CTransaction utxoTx;
    utxoTx.ParseFromString(txRawData);

    nlohmann::json data = nlohmann::json::parse(utxoTx.data());
    nlohmann::json txInfo = data["txInfo"].get<nlohmann::json>();
    std::string txStakeTypeNet = txInfo["stakeType"].get<std::string>();

    if (txStakeTypeNet != global::ca::STAKE_TYPE_NET) {
      continue;
    }

    for (auto &utxo : utxoTx.utxos()) {
      for (int i = 0; i < utxo.vout_size(); i++) {
        CTxOutput txout = utxo.vout(i);
        if (txout.addr() == global::ca::kTargetAddress) {
          total += txout.value();
        }
      }
    }
  }
  return total;
}

expected<std::vector<TxHelper::Utxo>>
UtxoCore::findUtxoByAddrAndCheckBalance(const FindUtxoParam &param,
                                        int64_t &_total) {

  DBReader dbReader;
  std::vector<TxHelper::Utxo> Utxos;
  std::vector<TxHelper::Utxo> retUtxos;
  if (!isValidAddress(param.addr.str())) {
    return PERROR(MEM::INVALID_ADDR,param.addr.str());
  }
  std::vector<std::string> utxoHashesList;
  if (DBStatus::DB_SUCCESS !=
          dbReader.getUtxoHashsByAddress(
              param.addr.str(), param.asset_type.str(), utxoHashesList) ||
      utxoHashesList.empty()) {
    return PERROR(MEM::ASSET_NOT_EXIST);
  }

  std::sort(utxoHashesList.begin(), utxoHashesList.end());
  utxoHashesList.erase(
      std::unique(utxoHashesList.begin(), utxoHashesList.end()),
      utxoHashesList.end());

  for (const auto &hash : utxoHashesList) {
    TxHelper::Utxo utxo;
    utxo.hash = hash;
    utxo.addr = param.addr.str();
    utxo.value = 0;
    utxo.n = 0; //	At present, the n of utxo is all 0

    std::string balance;
    if (dbReader.getUtxoValueByUtxoHashes(
            hash, param.addr.str(), param.asset_type.str(), balance) != 0) {
       return PERROR(MEM::NOT_FIND_UTXO_BY_HASH,"hash:{}", hash);
      continue;
    }

    utxo.value = TxHelper::calculate_utxo_value(balance);
    Utxos.push_back(utxo);
  }

  int total = 0;

  if (retUtxos.size() < UTxoRulers::max_vin_size) {
    //  Fill other positions with non-0
    auto it = Utxos.begin();
    while (it != Utxos.end()) {
      if (retUtxos.size() == UTxoRulers::max_vin_size) {
        break;
      }
      total += it->value;

      if (total >= param.need_amount) {
        break;
      }

      retUtxos.push_back(*it);
      ++it;
    }
  }

  if (total < param.need_amount) {
    return PERROR(MEM::INSUFFICIENT_ASSET_TYPE,"amout:{}", param.need_amount);
  }
  // const std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator>
  // outputUtxosSet; if(param.needWidUtxo)
  // {
  // 	int ret = sendConfirmUtxoHashRequest(outputUtxosSet);
  // 	if(ret != 0)
  // 	{
  // 		ERRORLOG("sendConfirmUtxoHashRequest error ret : {}", ret);
  // 		return -2;
  // 	}
  // }

  _total = total;
  return retUtxos;
}

expected<UtxoCore::SingRe> UtxoCore::sign(const ohi::CowString &addr,
                                               const ohi::CowString &data) {
  UtxoCore::SingRe retS;
  std::string signature;
  std::string pub;
 // std::cout << "addr ____ :" << addr.c_str() << std::endl;
  int ret = TxHelper::Sign(addr.c_str(), data.c_str(), signature, pub);
  if (ret != 0) {
    return PERROR(MEM::SIGN_VIN_FAIL);
  }
 // std::cout << "signature ____ :" << signature << std::endl;
  retS.signature = signature;
  retS.pubkey = pub;
  return retS;
}
std::string UtxoCore::calculate_all_hash(CTransaction *tx) {
  std::string allHash;
  for (const auto &txUtxo : tx->utxos()) {
    for (int i = 0; i < txUtxo.vin_size(); i++) {
      auto vin = txUtxo.vin(i);
      for (int j = 0; j < vin.prevout_size(); j++) {
        auto txPrevOutput = vin.prevout(j);
        allHash += txPrevOutput.hash();
      }
    }
  }
  allHash += std::to_string(tx->time());
  return allHash;
}

expected<uint64_t> UtxoCore::transactionDiscoveryHeight() {
  uint64_t top;
  if (!BlockHelper::getChainHeight(top)) {
    ERRORLOG("getChainHeight get top failed!!")
    return PERROR(MEM::GET_TOP_FAIL);
  }

  DEBUGLOG("current top: {}", top);
  DBReader dbReader;
  uint64_t nodeSelfHeight = 0;
  auto status = dbReader.getBlockTop(nodeSelfHeight);
  if (DBStatus::DB_SUCCESS != status) {
    DEBUGLOG("GetBlockTop fail!!!");
    return PERROR(MEM::GET_TOP_FAIL);
  }

  if (nodeSelfHeight >= top) {
    return nodeSelfHeight;
  }

  std::vector<std::string> pledgeAddr;

  std::vector<Node> nodelist =
      MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
  for (const auto &node : nodelist) {
    bool canReward = VerifyBonusAddr(node.address);

    // int64_t stakeTime = ca_algorithm::GetPledgeTimeByAddr(
    //     node.address, global::ca::StakeType::STAKE_TYPE_NODE);
    if (canReward) {
      pledgeAddr.push_back(node.address);
    }
  }

  uint64_t endSyncHeight_ = nodeSelfHeight - 3;
  std::string msgId;
  if (!dataMgrPtr.CreateWait(90, pledgeAddr.size() * 0.8, msgId)) {
    return PERROR(MEM::GET_TOP_FAIL);
  }
  for (auto &nodeId : pledgeAddr) {
    if (!dataMgrPtr.AddResNode(msgId, nodeId)) {
      ERRORLOG("transactionDiscoveryHeight AddResNode error");
      return PERROR(MEM::GET_TOP_FAIL);
    }
    DEBUGLOG("Find the transaction height to {}", nodeId);
    sendSyncGetHeightHashRequest(nodeId, msgId, nodeSelfHeight, endSyncHeight_);
  }
  std::vector<std::string> retDatas;
  if (!dataMgrPtr.WaitData(msgId, retDatas)) {
    if (retDatas.size() < pledgeAddr.size() * 0.5) {
      ERRORLOG("wait sync block hash time out send:{} recv:{}",
               pledgeAddr.size(), retDatas.size());
      return PERROR(MEM::GET_TOP_FAIL,"wait sync block hash time out send:{} recv:{} -5",
                       pledgeAddr.size(), retDatas.size());
    }
  }

  uint64_t successCounter = 0;
  SyncGetHeightHashAck ack;
  std::map<std::string, std::set<std::string>> syncBlockHashList;
  for (auto &retData : retDatas) {
    ack.Clear();
    if (!ack.ParseFromString(retData)) {
      continue;
    }
    if (ack.code() != 0) {
      continue;
    }
    successCounter++;
    for (auto &key : ack.block_hashes()) {
      auto it = syncBlockHashList.find(key);
      if (syncBlockHashList.end() == it) {
        syncBlockHashList.insert(std::make_pair(key, std::set<std::string>()));
      }
      auto &value = syncBlockHashList.at(key);
      value.insert(ack.self_node_id());
    }
  }

  if (successCounter < (size_t)(retDatas.size() * global::ca::kByzantineFaultToleranceThreshold)) {
    ERRORLOG("ret data error successCounter:{}, (uint32_t)(retDatas * "
             "global::ca::kByzantineFaultToleranceThreshold):{}, retDatas.size():{}",
             successCounter, (size_t)(retDatas.size() * global::ca::kByzantineFaultToleranceThreshold), retDatas.size());
    return PERROR(MEM::GET_TOP_FAIL);
  }

  size_t verifyNum = successCounter * global::ca::kHighConfidenceThreshold;
  std::vector<std::string> hashes;
  std::string strblock;
  CBlock block;
  uint64_t highestHeight = 0;
  for (auto &syncBlockHash : syncBlockHashList) {
    strblock.clear();
    auto res = dbReader.getBlockByBlockHash(syncBlockHash.first, strblock);
    if (DBStatus::DB_NOT_FOUND != res) {
      continue;
    }
    if (syncBlockHash.second.size() < verifyNum) {
      continue;
    }

    hashes.push_back(syncBlockHash.first);

    if (!block.ParseFromString(strblock)) {
      return PERROR(MEM::GET_TOP_FAIL);
    }
    highestHeight =
        highestHeight > block.height() ? highestHeight : block.height();
  }
  return highestHeight;
}

int64_t UtxoCore::GetChainId() {
  static int64_t chainId = 0;
  if (chainId != 0) {
    return chainId;
  }

  std::string blockHash;
  DBReader dbReader;
  if (DBStatus::DB_SUCCESS !=
      dbReader.getBlockHashByBlockHeight(0, blockHash)) {
    ERRORLOG("fail to read genesis block hash")
    return -1;
  }

  std::string genesisBlockPrefix = blockHash.substr(0, 8);
  chainId = StringUtil::StringToNumber(genesisBlockPrefix);
  return chainId;
}

int UtxoCore::checkGasAssetsQualification(
    const std::pair<std::string, std::string> &gasAssets,
    const uint64_t &height) {
  std::vector<std::string> gasTradeFromAddress;
  gasTradeFromAddress.push_back(gasAssets.first);
  int ret = TxHelper::Check(gasTradeFromAddress, gasAssets.second, height);
  if (ret != 0) {
    ERRORLOG("Check parameters failed! The error code is {}.", ret);
    ret -= 600;
    return ret;
  }
  return 0;
}
// namespace ohi
} // namespace ohi  