﻿#pragma once


#include <memory>
#include <string>
#include <cassert>
#include "utils/reflect_struct/field_type.h"

namespace ohi{

class CowString {
public:
    // 默认构造
    CowString() : data_(std::make_shared<std::string>()) {}

    // 从 C 字符串构造
    CowString(const char* str) : data_(std::make_shared<std::string>(str)) {}

    // 从 std::string 构造
    CowString(const std::string& str) : data_(std::make_shared<std::string>(str)) {}

    // 拷贝构造（共享数据）
    CowString(const CowString& other) = default;

    // 移动构造（接管数据）
    CowString(CowString&& other) noexcept = default;

    // 拷贝赋值（共享数据）
    CowString& operator=(const CowString& other) = default;

    // 移动赋值（接管数据）
    CowString& operator=(CowString&& other) noexcept = default;


    bool operator==(const CowString& other) const{
        return *data_ == *other.data_;
    }
     bool operator!=(const CowString& other)const {
        return *data_ != *other.data_;
    }

    // 获取字符串长度
    size_t size() const { return data_->size(); }

    // 判断是否为空
    bool empty() const { return data_->empty(); }

    // 只读访问（不触发 COW）
    const char& operator[](size_t index) const {
        return (*data_)[index];
    }

    // 可写访问（触发 COW）
    char& operator[](size_t index) {
        if (data_.use_count() > 1) {
            // 如果有其他对象共享数据，先拷贝
            data_ = std::make_shared<std::string>(*data_);
        }
        return (*data_)[index];
    }

    // 只读获取 C 字符串
    const char* c_str() const { return data_->c_str(); }

    // 只读获取 std::string
    const std::string& str() const { return *data_; }

    // 修改字符串（触发 COW）
    void append(const std::string& str) {
        if (data_.use_count() > 1) {
            data_ = std::make_shared<std::string>(*data_);
        }
        data_->append(str);
    }

    // 获取引用计数（调试用）
    long use_count() const { return data_.use_count(); }

private:
    std::shared_ptr<std::string> data_;  // 共享数据
};

}

template <>
   class field_type<ohi::CowString> {
public:
    template< typename J_T>
    static void to_json(J_T & json,const ohi::CowString & t) {
        json=t.str();
    }
    template< typename J_T>
    static bool to_obj(J_T & json, ohi::CowString & obj,std::string & error) {
        try {
            obj= ohi::hex::remove0xPrefix(json.template get<std::string>());
            return true;
        }catch (std::exception &e) {
            error=e.what();
            return false;
        }
    }
};


