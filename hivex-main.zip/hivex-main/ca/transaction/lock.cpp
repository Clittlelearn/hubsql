﻿#include "lock.h"
#include "errorn/ca/error.def.h"
#include "error.h"
#include "ca/transaction.h"
#include "transaction.pb.h"
#include "txhelper.h"
#include "utils/version.h"
#include "common/genesis_helper.h"
#include "ca/address_status_cache.h"
#include "utils/magic_singleton.h"


expected<bool> LockTrans::trans()
{
    auto checkRet = checkParams();
    if (!checkRet.isOk()) {
        return checkRet.Error();
    }

	uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk()){
       	return  PERROR(MEM::FAILED_TO_GET_HEIGHT);;
    }
	top=retNum.Value();
    std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> allsetOutUtxos;
	uint64_t totalGas = 0;
	std::vector<std::string> addressVector;
	std::string currencyType = global::ca::ASSET_TYPE_OHI;
	addressVector.push_back(s_lock_param.lock_addr.str());
	int ret = TxHelper::Check(addressVector,currencyType,top+1);
	if(ret != 0)
	{
		ERRORLOG( "Check parameters failed! The error code is {}." , ret);
        return PERROR(MEM::CHECK_ADDR_ASSET_TYPE_HEIGHT_FAIL,"ret:{}",ret);
	}

	if (!isValidAddress(s_lock_param.lock_addr.str())) 
	{
        return PERROR(MEM::INVALID_ADDR);
	}

	if(s_lock_param.lock_amount < global::ca::LOCK_AMOUNT * global::ca::kDecimalNum)
	{
		std::cout << "Lock amount must be greater than or equal " << global::ca::kDecimalNum << std::endl;
		return PERROR(MEM::LESS_THAN_MIN_LOCK_AMOUNT);
	}

	std::string strLockType;
	if (s_lock_param.lock_type == TxHelper::LockType::kLock_Node)
	{
		strLockType = global::ca::kLockTypeNet;
	}
	else
	{
		ERRORLOG( "Unknown lock type!" );
        return PERROR(MEM::UNKNOWN_LOCK_TYPE,"unkonw lock type");
	}

	DBReader dbReader;
	std::vector<std::string> stake_unspent_outputs;
    auto dbret = dbReader.getLockAddrUtxo(s_lock_param.lock_addr.str(),global::ca::ASSET_TYPE_OHI,stake_unspent_outputs);
	if(dbret != DBStatus::DB_NOT_FOUND)
	{
		std::cout << "There has been a lock transaction before !" << std::endl;
		return PERROR(MEM::UNKNOWN_LOCK_TYPE,"There has been a lock transaction before ");
	}
	uint64_t expend = s_lock_param.lock_amount;
	//  Find utxo
	uint64_t total = 0;

    TransferFromParam vin_param;

    vin_param.from = s_lock_param.lock_addr.str();
    vin_param.asset_type = global::ca::ASSET_TYPE_OHI;
    vin_param.amount = s_lock_param.lock_amount;
	vin_param.is_find_utxo=s_lock_param.is_find_utxo;

    CTxUtxos * u=tx.add_utxos();
    auto vin_ret=  createUtxoTransferFrom(u, vin_param, 0);

	if(!vin_ret.isOk()){
        return vin_ret<< PERROR(MEM::GEN_VIN_FAIL);
    }

    total=vin_ret.Value();

	makeTxInfor(&tx);
    auto gas_value= getGasValue(u, 0);

    if(!gas_value.isOk())
    {
        return gas_value<< PERROR(MEM::GET_GAS_VALUE_FAIL);
    }
    uint64_t gas = gas_value.Value();


    

	auto currentTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	//getTransactionStartIdentity(height,currentTime,type);

	if(s_lock_param.is_gas_tray)
	{
		totalGas += gas;
	}
	else
	{
		expend +=  gas; 
	}

	if(total < expend)
	{
		ERRORLOG("The total cost = {} is less than the cost = {}", total, expend);
		return PERROR(MEM::BALANCE_IS_INSUFFICIENT);
	}

	CTxOutput * vout = u->add_vout(); 
	vout->set_addr(global::ca::VIRTUAL_LOCK_ADDRESS);
	vout->set_value(s_lock_param.lock_amount);

	CTxOutput * voutSourceAddress = u->add_vout();
	voutSourceAddress->set_addr(s_lock_param.lock_addr.str());
	voutSourceAddress->set_value(total - expend);

	if(s_lock_param.is_gas_tray)
	{
		CTxOutput * voutBurnAmount = u->add_vout();
		voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		voutBurnAmount->set_value(0);
	}
	else
	{
		CTxOutput * voutBurnAmount = u->add_vout();
		voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
		voutBurnAmount->set_value(gas);
	}
	if(s_lock_param.is_gas_tray){
		UtxoGasParam gas_param;
    	gas_param.asset_type = s_lock_param.gas.asset_type;
    	gas_param.from = s_lock_param.gas.addr;
    	gas_param.gas = gas;

    	auto gas_ret= createUtxoGas(&tx, gas_param);
    	if (!gas_ret.isOk()) {
        	return gas_ret<< PERROR(MEM::GEN_GAS_UTXO_FAIL);
    	}
	}

	tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	tx.set_time(currentTime);
	tx.set_consensus(global::ca::kConsensus);
	tx.set_type((uint32_t)global::ca::TxType::LOCK);

	std::string identity;
	TxHelper::vrfAgentType type;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(&tx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(tx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return PERROR(MEM::FAILED_TO_PICK_A_PACKAGER,"fetchIdentityNodes fail!!! ret:%s",ret);
	}
	DEBUGLOG("Tx identity:{}", identity);
	std::cout << Sutil::Format("Tx identity:%s", identity) << std::endl;
	tx.set_identity(identity);
    
	return true;

}

expected<bool> LockTrans::goMessage()
{
    uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk() ){
        return retNum<< PERROR(MEM::FAILED_TO_GET_HEIGHT);
    }
	top=retNum.Value();
    TxMsgReq txMsg;
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(tx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    auto ret = TxHelper::get_tx_utxo_height(tx, txUtxoLocalHeight);
    if(ret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        return PERROR(MEM::FAILED_TO_GET_UTXO_HEIGHT,"utxo height ret:{}",ret);
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    auto msg = std::make_shared<TxMsgReq>(txMsg);

    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

    if(tx.identity() == defaultAddr)
    {
        ret = handleTransaction(msg,tx);
    }
    else
    {
        ret = DropShippingTransaction(msg, tx, tx.identity());
    }

    if (ret != 0)
    {
        ret -= 100;
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, tx.hash());
	std::cout << Sutil::Format("Transaction result,package:%s  txHash:%s", ret,tx.hash()) << std::endl;
    return true;
}

expected<bool> LockTrans::makeTxInfor(CTransaction * tx_)
{
    nlohmann::json txInfo;
	std::string strLockType;
	if (s_lock_param.lock_type == TxHelper::LockType::kLock_Node)
	{
		strLockType = global::ca::kLockTypeNet;
	}
	else
	{
		return PERROR(MEM::UNKNOWN_LOCK_TYPE,"Unknown lock type");
	}
	txInfo["lockType"] = strLockType;
	txInfo["lockAmount"] = s_lock_param.lock_amount;

	nlohmann::json data;
	data["txInfo"] = txInfo;
	tx.set_data(data.dump());
	tx.set_note(s_lock_param.encoded_info.str());

	if (tx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -1;
    }

    if (tx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -2;
    }


	uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
		db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
		ERRORLOG("get NonceByAddr error");
		return PERROR(MEM::FAILED_TO_GET_NONCE,"addr:{}", tx.utxos(0).owner(0));
	}
	tx.set_nonce(nonce);

	//tx.set_type(global::ca::kTxSign);	
	return true;
}

expected<int64_t> LockTrans::getGasValue(CTxUtxos * u,int trans_index)
{
    uint64_t gas = 0;
    uint64_t gasSize = tx.data().size() +  tx.note().size() + tx.reserve0().size() + tx.reserve1().size();

	//  Calculate total expenditure
	std::map<std::string, int64_t> toAddr;
	toAddr.insert(std::make_pair(global::ca::VIRTUAL_LOCK_ADDRESS, s_lock_param.lock_amount));
	toAddr.insert(std::make_pair("addr", 0));
	toAddr.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));

	if(GenerateGas(*u,toAddr.size(),gasSize,gas) != 0)
	{
		ERRORLOG(" gas = 0 !");
		return PERROR(MEM::GAS_IS_ZERO);
	}
	if(GetInitAccountAddr() == s_lock_param.lock_addr.str())
	{
        gas = 0;
    }
    return gas;
}

expected<bool> LockTrans::checkParams()
{
    // 1. 地址有效性
    if (!isValidAddress(s_lock_param.lock_addr.str())) {
        return PERROR(MEM::INVALID_ADDR);
    }

    // 2. 不允许多次锁定 — 必须当前未锁定
    // if (MagicSingleton<ohi::utils::AddressStatusCache>::GetInstance()->isLocked(
    //         s_lock_param.lock_addr.str())) {
    //     return PERROR(MEM::INVALID_ADDR, "address already locked");
    // }

    // 3. 锁定金额 ≥ 最小值
    if (s_lock_param.lock_amount < global::ca::LOCK_AMOUNT * global::ca::kDecimalNum) {
        return PERROR(MEM::LESS_THAN_MIN_LOCK_AMOUNT, "lock amount too small");
    }

    return true;
}
