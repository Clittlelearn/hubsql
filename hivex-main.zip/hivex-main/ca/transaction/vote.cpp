﻿#pragma  once
#include "vote.h"
#include "algorithm.h"
#include "interface.pb.h"
#include "transaction.h"
#include "transaction.pb.h"
#include "txhelper.h"
#include "errorn/ca/error.def.h"
#include "error.h"
#include "utils/version.h"
#include "common/genesis_helper.h"
#include "ca/address_status_cache.h"
#include "utils/magic_singleton.h"

expected<bool> VoteTrans::trans()
{
    auto checkRet = checkParams();
    if (!checkRet.isOk()) {
        return checkRet.Error();
    }

	uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk()){
       	return  PERROR(MEM::FAILED_TO_GET_HEIGHT);;
    }
	top=retNum.Value();
   // s_vote_param.addr;
    if (!isValidAddress( s_vote_param.addr.str())) 
	{
        return PERROR(MEM::INVALID_ADDR);
	}

	std::vector<std::string> fromaddr;
	fromaddr.push_back(s_vote_param.gas.from.str());
	int ret = TxHelper::Check(fromaddr,s_vote_param.gas.asset_type.str(),top+1);
	if(ret != 0)
	{
		return PERROR(MEM::CHECK_ADDR_ASSET_TYPE_HEIGHT_FAIL);
	}
	
	DBReadWriter db;
    std::vector<std::string> assertTypes;
    auto dbRet = db.getAssetType(assertTypes);
	if(dbRet != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("VoteCache error -1, getAllAssetType error, error num:{}", dbRet);
        return PERROR(MEM::GET_TOP_FAIL);
    }

	//uint64_t lockValue = 0;
    if(assertTypes.size() == 1 && s_vote_param.addr == GetInitAccountAddr())
    {
        lockValue = 1;
    }
    else 
	{
		ret = ca_algorithm::GetLockValue(s_vote_param.addr.str(), lockValue);
		if(ret != 0)
		{
			ERRORLOG("GetLockValue error, ret: {}", ret);
			return -3;
		}
	}

	auto currentTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	ret = ca_algorithm::CheckVoteTxInfo(s_vote_param.vote_hash.str(), (uint32_t)s_vote_param.tx_type, s_vote_param.vote_type, currentTime);
	if(ret != 0)
	{
		ERRORLOG("CheckVoteTxInfo error, ret: {}", ret);
        return PERROR(MEM::VOTE_INFO_CHECK_FAIL);
	}


	
	// uint64_t total = 0;
    //  CTxUtxos u;
    // auto gas_value_ret=  getGasValue(&u, 0);
    // if(gas_value_ret.is_error()){
    //     return gas_value_ret.get_error();
    // }


    UtxoGasParam param;
    param.from = s_vote_param.gas.from;
    param.asset_type = s_vote_param.gas.asset_type;
    param.gas = 0;
    auto gas_utxo_ret = createUtxoGasBylameda(
        &tx, param, [this](CTxUtxos *u, int index) -> uint64_t {
          if (makeTxData(&tx) != 0)
          {
            ERRORLOG("make tx data failed{}");
		  }
          auto gas_value_ret = this->getGasValue(u, index);
          if (!gas_value_ret.isOk()) {
            ERRORLOG("lamda getGasValue fail: {}",
                     gas_value_ret.error_message(true));
            return 0;
          }
          return gas_value_ret.Value();
        });

    if (!gas_utxo_ret.isOk()) {
        return gas_utxo_ret << PERROR(MEM::GEN_GAS_UTXO_FAIL);
    }
	
	

	
    TxHelper::vrfAgentType vtype;
	TxHelper::getTransactionStartIdentity(top+1,currentTime,vtype);

	makeTxInfor(&tx);
	tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	tx.set_time(currentTime);
	tx.set_consensus(global::ca::kConsensus);
	tx.set_type((uint32_t)global::ca::TxType::VOTE);


	
	
	DEBUGLOG("self hash:{}", calculate_all_hash(&tx));
	
	std::string identity;
    
	ret = TxHelper::fetchIdentityNodes(vtype, calculate_all_hash(&tx), currentTime, identity, TxHelper::SelectLocalSelectionSigner(tx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return -12;
	}
	DEBUGLOG("Tx identity:{}", identity);
	tx.set_identity(identity);

	// std::string txHash = Getsha256Hash(tx.SerializeAsString());
	// tx.set_hash(txHash);

	return true;
}


expected<bool> VoteTrans::goMessage(){

	uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk() ){
        return retNum << PERROR(MEM::FAILED_TO_GET_HEIGHT);
   	}
	top=retNum.Value();
    TxMsgReq txMsg;
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(tx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    auto ret = TxHelper::get_tx_utxo_height(tx, txUtxoLocalHeight);
    if(ret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
		return PERROR(MEM::FAILED_TO_GET_UTXO_HEIGHT,"ret:{}",ret);
       
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    auto msg = std::make_shared<TxMsgReq>(txMsg);

    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(tx.identity() == defaultAddr)
    {
        ret = handleTransaction(msg,tx);
    }
    else
    {
        ret = DropShippingTransaction(msg, tx, tx.identity());
    }

    if (ret != 0)
    {
        ret -= 100;
    }
	return true;
}


// expected<ohi::UtxoCore::SingRe> VoteTrans::sign(const ohi::CowString &addr,const ohi::CowString & data){
//     return ohi::UtxoCore::SingRe();
// }
expected<bool> VoteTrans::makeTxInfor(CTransaction * tx_){

	
	if (tx.utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -1;
    }

    if (tx.utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -2;
    }

	uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
	db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
	ERRORLOG("get NonceByAddr error");
	return PERROR(MEM::FAILED_TO_GET_NONCE,"addr:{}", tx.utxos(0).owner(0));
	}
	tx.set_nonce(nonce);

	//tx.set_type(global::ca::kTxSign);	
    return true;
}
expected<bool> VoteTrans::checkParams()
{
    // 1. 地址有效性
    if (!isValidAddress(s_vote_param.addr.str())) {
        return PERROR(MEM::INVALID_ADDR);
    }
    if (!isValidAddress(s_vote_param.gas.from.str())) {
        return PERROR(MEM::INVALID_ADDR);
    }

    // 2. 必须有锁定记录 - 创世账号做第一笔投票交易时例外
	DBReadWriter db;
    std::vector<std::string> assertTypes;
    auto dbRet = db.getAssetType(assertTypes);
	if(dbRet != DBStatus::DB_SUCCESS)
    {
        return PERROR(MEM::GET_TOP_FAIL, "getAllAssetType error, error num:{}", dbRet);
    }

	//uint64_t lockValue = 0;
    if(assertTypes.size() == 1 && s_vote_param.addr == GetInitAccountAddr())
    {
        return true;
    }
    
    if(!MagicSingleton<ohi::utils::AddressStatusCache>::GetInstance()->isLocked(
            s_vote_param.addr.str()))
    {
        return PERROR(MEM::INVALID_ADDR, "address has no lock record");
    }

    return true;
}
expected<int64_t> VoteTrans::getGasValue(CTxUtxos * u,int index){
    uint64_t gas = 0;
	uint64_t gasSize = tx.data().size()  + tx.note().size() + tx.reserve0().size() + tx.reserve1().size();

	std::map<std::string, int64_t> toAddr;
	toAddr.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
	toAddr.insert(std::make_pair("", 0));
	if(GenerateGas(*u, toAddr.size(),gasSize, gas) != 0)
	{
		ERRORLOG(" gas = 0 !");
		return PERROR(MEM::GAS_IS_ZERO);
	}
    if(GetInitAccountAddr() == s_vote_param.gas.from.str())
	{
        gas = 0;
    }
    return gas;
}

expected<bool> VoteTrans::makeTxData(CTransaction *tx) {
  nlohmann::json txInfo;
  txInfo["voteHash"] = s_vote_param.vote_hash.str();
  txInfo["voteTxType"] = s_vote_param.tx_type;
  txInfo["voteType"] = s_vote_param.vote_type;
  txInfo["voteNumber"] = lockValue;

  nlohmann::json data;
  data["txInfo"] = txInfo;
  tx->set_data(data.dump());
  tx->set_note(s_vote_param.encoded_info.str());
  return true;
}
