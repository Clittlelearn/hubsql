﻿#pragma once

#include "utxo_core.h"
#include "interface.pb.h"
#include "transaction.pb.h"
#include "txhelper.h"
#include "CowString.hpp"
#include "algorithm.h"
#include <cstdint>
#include <vector>
struct BonusTransParam{
    ohi::CowString addr;
    ohi::CowString asset_type;
    ohi::CowString encoded_info;
    ohi::UtxoCore::OtherToPayGas gas_tray;
    bool is_gas_tray = false;
    bool first_choose = false;
    bool is_find_utxo=false;
    REFLECT(addr,asset_type,encoded_info,gas_tray,is_gas_tray,first_choose,is_gas_tray,is_find_utxo)
};

class BonusTrans:public ohi::UtxoCore{
public:
    
    BonusTransParam s_bonus_trans_param;

    BonusTrans(const  BonusTransParam & param ){
        s_bonus_trans_param=param;
    }

    expected<int64_t> createUtxoTransFrom(CTxUtxos *utxo, const TransferFromParam &param,int64_t sq);

    expected<bool> trans() override;
    bool pairIsEmpty(const ohi::UtxoCore::OtherToPayGas &gas_tray);
    expected<bool> goMessage()override;
protected:
    expected<bool> makeTxInfor(CTransaction * tx) override;
    expected<bool> checkParams()override;
    expected<int64_t> getGasValue(CTxUtxos *u, int trans_index)override;
private:
private:
       int64_t total = 0;
       int64_t expend = 0;
       std::map<std::string, uint64_t> delegator_reward_allocations{};
       double temp_commission_rate = 0.0;
};