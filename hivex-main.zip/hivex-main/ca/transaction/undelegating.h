﻿#pragma once
#include "utxo_core.h"

#include "interface.pb.h"
#include "transaction.pb.h"
#include "txhelper.h"
#include "CowString.hpp"
#include <cstdint>
#include <vector>

    
struct UndelegatingTransParam{
    ohi::CowString from_addr;
    ohi::CowString to_addr;
    ohi::CowString asset_type;
    ohi::CowString encoded_info;
    ohi::CowString utxo_hash;
    ohi::UtxoCore::OtherToPayGas gas_tray;
    uint64_t time;
    bool is_gas_tray = false;
    bool is_find_utxo=false;
    REFLECT(from_addr,to_addr,asset_type,encoded_info,utxo_hash,gas_tray,is_gas_tray,is_find_utxo)
};
class UndelegatingTrans:public ohi::UtxoCore{
public:
    UndelegatingTransParam   s_undelegating_trans_param;
    UndelegatingTrans(const  UndelegatingTransParam & param ){
        s_undelegating_trans_param=param;
    }
    
    expected<bool> trans()override;
    expected<bool> goMessage()override;
protected:
    expected<bool> makeTxInfor(CTransaction * tx) override;
    expected<bool> checkParams()override;
    expected<int64_t> getGasValue(CTxUtxos * u,int trans_index);
private:
private:
    uint64_t total = 0;
    uint64_t delegatinged_amount = 0;
};