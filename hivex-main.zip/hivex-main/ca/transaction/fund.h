﻿#pragma once

#include "utxo_core.h"
#include "interface.pb.h"
#include "transaction.pb.h"
#include "txhelper.h"
#include "CowString.hpp"
#include <cstdint>
#include <vector>

struct FundTransParam{
    ohi::CowString addr;
    ohi::CowString encoded_info;
    bool is_find_utxo=false;
   // uint64_t height = 0;
    REFLECT(addr,encoded_info,is_find_utxo)
};
class FundTrans:public ohi::UtxoCore{
public:
    
    FundTransParam   s_fund_trans_param;
    FundTrans(const FundTransParam &param){ s_fund_trans_param = param; }

    struct TransferToParam{
        ohi::CowString to;
        int64_t amount;
        ohi::CowString asset_type;
    };
    expected<bool> trans()override;
    expected<bool> goMessage()override;
    expected<bool> signTransaction(const ohi::CowString &addr);
protected:
     expected<bool> makeTxInfor(CTransaction * tx) override;
    expected<bool> checkParams()override;
    void createUtxoFundTransfer(CTxUtxos *utxo,
                                const FundTrans::TransferToParam &param,
                                FundTransParam &s_fund_trans_param,
                                std::pair<std::string, uint64_t> asset_type);
    expected<int64_t> getGasValue(CTxUtxos * u,int index) override;
private:
private:
    bool is_locked = false;
    bool is_packaged = false;
    uint64_t total = 0;
    uint64_t expend = 0;
    uint64_t times = 0;
    uint64_t count = 0;
    uint64_t return_value = 0;
    uint64_t total_locked_amount = 0;
    std::map<std::string, uint64_t> locked_reward{};
    std::map<std::string, uint64_t> packaged_reward{};
    std::map<std::string, TxHelper::ProposalInfo> asset_map{};
};