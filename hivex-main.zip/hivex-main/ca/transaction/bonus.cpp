﻿#include "bonus.h"
#include "ca/algorithm.h"
#include "errorn/ca/error.def.h"
#include "error.h"
#include "utils/account_manager.h"
#include "utils/bench_mark.h"
#include "utils/magic_singleton.h"
#include "utils/version.h"
#include "utxo_core.h"
#include "ca.h"
#include "ca/global.h"
#include "pb/transaction.pb.h"
#include "transaction.pb.h"
#include "ca/transaction.h"
#include "utils/tmp_log.h"
#include "common/genesis_helper.h"
#include "ca/address_status_cache.h"
#include <cstdint>

expected<bool> BonusTrans::trans()
{
    auto checkRet = checkParams();
    if (!checkRet.isOk()) {
        return checkRet.Error();
    }

    uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk()){
       	return  PERROR(MEM::FAILED_TO_GET_HEIGHT);;
    }
	top=retNum.Value();
  if (BonusTrans::pairIsEmpty(s_bonus_trans_param.gas_tray) == false) {
        std::pair<std::string, std::string> gas_tran;
        gas_tran.first = s_bonus_trans_param.gas_tray.addr.str();
        gas_tran.second = s_bonus_trans_param.gas_tray.asset_type.str();
        int ret = checkGasAssetsQualification(gas_tran, top+1);
        if(ret != 0)
        {
               return PERROR(MEM::CHECK_GAS_ASSET_FAILED);
        }
    }

        // initialize transaction
    uint64_t totalGas = 0;
    std::string addr = s_bonus_trans_param.addr.str();
    std::string asset_type = s_bonus_trans_param.asset_type.str();

    std::vector<std::string> address_vector;
    address_vector.push_back(addr);

	//  Check parameters    
	std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator> all_set_out_utxos;
        int ret = TxHelper::Check(address_vector,
                                  s_bonus_trans_param.asset_type.str(), top);
        if (ret != 0) {
          // ERRORLOG(RED "Check parameters failed! The error code is {}."
          // RESET, ret);
          return PERROR(MEM::CHECK_ADDR_ASSET_TYPE_HEIGHT_FAIL, "ret:{}", ret);
          // ret -= 100;
          // return ret;
    }

    if (!isValidAddress(addr))
    {
        // ERRORLOG("to from_addr is empty");
        // return -1;
       return  PERROR(MEM::INVALID_ADDR);
    }

    DBReader dbReader;
    std::vector<std::string> utxos;

    uint64_t current_time =
        MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    ret = evaluateBonusEligibility(addr,current_time);
    if (ret != 0) {
        ERRORLOG("Not allowed to Bonus!");
        return PERROR(MEM::NOT_QUALIFIED_FOR_BONUS,"ret:{}",ret);
    }

    ret=ca_algorithm::CalcBonusValue(current_time, addr, delegator_reward_allocations);
	if(ret < 0)
	{
          ERRORLOG("Failed to obtain the amount claimed by the delegatingor "
                   "ret:({})",
                   ret);
          ret -= 300;
        return PERROR(MEM::NOT_QUALIFIED_FOR_BONUS,"ret:{}",ret);
	}

    // Find utxo

    // Transaction fee
    TransferFromParam from_param;

    from_param.from = addr;
    from_param.asset_type = asset_type;
    from_param.amount = TxHelper::MAX_VIN_SIZE;
    from_param.is_find_utxo=s_bonus_trans_param.is_find_utxo;
    auto u=tx.add_utxos();
    auto fromret=createUtxoTransFrom(u,from_param,0);
    if(!fromret.isOk()){
        return fromret<< PERROR(MEM::GEN_VIN_FAIL);
    }
    int index = 0;
    
    makeTxInfor(&tx);
    auto gasre=getGasValue(u,index);
    if(!gasre.isOk()){
        return gasre<< PERROR(MEM::GET_GAS_VALUE_FAIL);
    }

    int64_t gas=gasre.Value();
            DEBUGLOG("expend = {}", expend);
    if (s_bonus_trans_param.is_gas_tray)
    {
        totalGas += gasre.Value();
    }
    else
    {
        expend += gasre.Value();
    }

	int rt = ca_algorithm::GetCommissionPercentage(addr, temp_commission_rate);
	if(rt != 0)
	{
		ERRORLOG("GetCommissionPercentage error:{}", rt);
        return rt -= 500;
	}
    
    
    DEBUGLOG("totalGas = {} , expendGas = {} gas = {}", totalGas, expend,gas);
    total = fromret.Value();
    if (total < expend)
    {
        ERRORLOG("The total cost = {} is less than the cost = {}", total, expend);
        return PERROR(MEM::BALANCE_IS_INSUFFICIENT,"total:{},expend:{}" , total, expend);
    }

    // Fill vout
    uint64_t operator_commission=0;
	uint64_t total_operator_commission = 0;
	uint64_t total_claim=0;
	std::cout << "Claim addr : Claim Amount" << std::endl;
	std::cout << "Commission: " << temp_commission_rate << std::endl;

    for(auto delegator : delegator_reward_allocations)
	{
		operator_commission = delegator.second * temp_commission_rate+0.5;
		total_operator_commission += operator_commission;
		uint64_t award = delegator.second - operator_commission;
		total_claim += award;
	}

    for(auto delegator : delegator_reward_allocations)
	{
		operator_commission = delegator.second * temp_commission_rate+0.5;
		std::string addr = delegator.first;
		uint64_t award = delegator.second - operator_commission;
        TransferToParam to_param;
        to_param.to=addr;
        to_param.amount= award;
        createUtxoTransferTo(u,to_param);
        // CTxOutput *outputAddress = u->add_vout();
		// outputAddress->set_addr(addr);
		// outputAddress->set_value(award);
		DEBUGLOG("addr {}: award{}",delegator.first,delegator.second);
	}

        // caculate the value of new guoku award end
        // CTxOutput *outputAddress = u->add_vout();
        // outputAddress->set_addr(addr);

    TransferToParam to_param;
    to_param.to=addr;
    if (s_bonus_trans_param.first_choose)
    {
        to_param.amount = total_operator_commission;
    }
    else
    {
        to_param.amount = total - expend + total_operator_commission;
    }
    createUtxoTransferTo(u,to_param);

        

    // CTxOutput *vout = transactionUtxo1->add_vout();
    // vout->set_addr(to.first);
    // vout->set_value(to.second);

    std::cout << addr << ":" << total_operator_commission << std::endl;
	total_claim += total_operator_commission;
	if(total_operator_commission == 0)
	{
		ERRORLOG("The claim amount is 0");
		return -12;
	}

    if (s_bonus_trans_param.is_gas_tray)
    {    
        TransferToParam to_burn_param;
        to_burn_param.amount=0;
        to_burn_param.to=global::ca::VIRTUAL_BURN_GAS_ADDR;
        createUtxoTransferTo(u,to_burn_param);
        // CTxOutput *voutBurnAmount = transactionUtxo1->add_vout();
        // voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
        // voutBurnAmount->set_value(0);
    }
    else
    {
        TransferToParam to_burn_param;
        to_burn_param.amount=gas;
        to_burn_param.to=global::ca::VIRTUAL_BURN_GAS_ADDR;
        createUtxoTransferTo(u,to_burn_param);
        // CTxOutput *voutBurnAmount = transactionUtxo1->add_vout();
        // voutBurnAmount->set_addr(global::ca::VIRTUAL_BURN_GAS_ADDR);
        // voutBurnAmount->set_value(gas);
    }

		// std::string serializedUtxoHash = Getsha256Hash(transactionUtxo1->SerializeAsString());
		// for (auto &owner : setTxOwners)
		// {
		// 	if (TxHelper::addMultipleSigns(owner, *transactionUtxo1) != 0)
		// 	{
		// 		ERRORLOG("addd mutil sign fail");
		// 		return -10;
		// 	}
		// }
	
    if(s_bonus_trans_param.is_gas_tray)
    {
    UtxoGasParam param;
    param.asset_type = s_bonus_trans_param.gas_tray.asset_type;
    param.from = s_bonus_trans_param.gas_tray.addr;
    param.gas=totalGas;
    auto gasret= createUtxoGas(&tx, param);
    if(!gasret.isOk()){
        return gasret <<  PERROR(MEM::GEN_GAS_UTXO_FAIL);
   }
   }


    tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	tx.set_time(current_time);
	tx.set_consensus(global::ca::kConsensus);
    tx.set_type((uint32_t)global::ca::TxType::BONUS);

    DEBUGLOG("self hash:{}", calculate_all_hash(&tx));
    std::string identity;
    current_time = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    TxHelper::vrfAgentType type;
	ret = TxHelper::fetchIdentityNodes(type, calculate_all_hash(&tx), current_time, identity, TxHelper::SelectLocalSelectionSigner(tx));
	if(ret != 0)
	{
		ERRORLOG("fetchIdentityNodes fail!!! ret:{}", ret);
		return PERROR(MEM::FAILED_TO_PICK_A_PACKAGER);
	}
	DEBUGLOG("Tx identity:{}", identity);
	tx.set_identity(identity);


	// std::string txHash = Getsha256Hash(tx.SerializeAsString());
	// tx.set_hash(txHash);
        DEBUGLOG("CreateDelegatingTransaction tx time = {}, package = {}",
                 tx.time(), tx.identity());
        
    return true;
}

expected<bool> BonusTrans::goMessage() {
      TxMsgReq txMsg;

    uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk() ){
        return retNum<< PERROR(MEM::FAILED_TO_GET_HEIGHT);
    }
    top=retNum.Value();
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(tx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    auto ret = TxHelper::get_tx_utxo_height(tx, txUtxoLocalHeight);
    if(ret != 0)
    {
        return PERROR(MEM::FAILED_TO_GET_UTXO_HEIGHT);
        
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    auto msg = std::make_shared<TxMsgReq>(txMsg);

    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

    if(tx.identity() == defaultAddr)
    {
        ret = handleTransaction(msg,tx);
        
    }
    else
    {
        ret = DropShippingTransaction(msg, tx, tx.identity());
    }

    if (ret != 0)
    {
        //UtxoError().trace(UE_NOERROR,"%s => what:%s",ret).to_string();
        ret -= 100;
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, tx.hash());
    return true;
 }

expected<bool> BonusTrans::makeTxInfor(CTransaction * tx){
    uint64_t operator_commission=0;
    uint64_t total_operator_commission = 0;
    uint64_t total_claim=0;
    for(auto company : delegator_reward_allocations)
	{
		operator_commission=company.second * temp_commission_rate +0.5;
		total_operator_commission += operator_commission;
		std::string addr = company.first;
		uint64_t award = company.second - operator_commission;
		total_claim += award;		
	}
	total_claim += total_operator_commission;
	nlohmann::json txInfo;
	txInfo["bonusAmount"] = total_claim;
	txInfo["bonusAddrList"] = delegator_reward_allocations.size() + 2;

	nlohmann::json data;
	data["txInfo"] = txInfo;
    

    if (tx->utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -1;
    }

    if (tx->utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -2;
    }


    uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(tx->utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
        db_reader.getNonceByAddr(tx->utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
        ERRORLOG("get NonceByAddr error");
        return PERROR(MEM::FAILED_TO_GET_NONCE,"addr:{}", tx->utxos(0).owner(0));
        }
    tx->set_nonce(nonce);

    tx->set_data(data.dump());
	tx->set_note(s_bonus_trans_param.encoded_info.str());
	//tx->set_type(global::ca::kTxSign);
    return "";
}
expected<bool> BonusTrans::checkParams()
{
    // 1. 地址有效性
    if (!isValidAddress(s_bonus_trans_param.addr.str())) {
        return PERROR(MEM::INVALID_ADDR);
    }

    // 2. 必须有奖励领取资格
    if (!MagicSingleton<ohi::utils::AddressStatusCache>::GetInstance()->canReward(
            s_bonus_trans_param.addr.str())) {
        return PERROR(MEM::CHECK_INELIGIBILITY_FOR_RECEIVING_FUND, "no reward qualification");
    }

    return true;
}


expected<int64_t> BonusTrans::getGasValue(CTxUtxos * u,int index){
    uint64_t gasSize = tx.data().size() +  tx.note().size() + tx.reserve0().size() + tx.reserve1().size();
    uint64_t gas = 0;

    std::map<std::string, int64_t> toAddrs;
    for (const auto &item : delegator_reward_allocations)
    {
        toAddrs.insert(make_pair(item.first, item.second));
    }
    toAddrs.insert(std::make_pair(global::ca::kTargetAddress, total - expend));
    toAddrs.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
        
    if (GenerateGas(*u,  toAddrs.size(), gasSize, gas) != 0)
    {
        return PERROR(MEM::GAS_IS_ZERO);
    }
    if(GetInitAccountAddr() == s_bonus_trans_param.addr.str()){
        gas = 0;
    }
    return gas;
}

bool BonusTrans::pairIsEmpty(const ohi::UtxoCore::OtherToPayGas &gas_tray) {
    return gas_tray.addr.str().empty() || gas_tray.asset_type.str().empty();
}


expected<int64_t> BonusTrans::createUtxoTransFrom(CTxUtxos *utxo, const TransferFromParam &param,
                                 int64_t sq) {

  // 设置查找UTXO的参数
  FindUtxoParam findParam;
  findParam.addr = param.from;
  findParam.asset_type = param.asset_type;
  findParam.need_amount = param.amount;

  // 初始化余额变量
  uint64_t balance = 0;

  // 根据地址查找UTXO并检查余额
//  auto vect_utxos = findUtxoByAddrAndCheckBalance(findParam, balance);

  std::multiset<TxHelper::Utxo, TxHelper::UnspentTxOutputComparator>
      outputUtxosSet;

  std::multimap<std::string, std::string> fromAddr_assetType;
  fromAddr_assetType.insert({param.from.str(), param.asset_type.str()});
  int ret = TxHelper::FindUtxo(fromAddr_assetType, TxHelper::MAX_VIN_SIZE, balance,outputUtxosSet, param.is_find_utxo);
  if (ret != 0) {
    ERRORLOG( "FindUtxo failed! The error code is {} " , ret);
    std::cout << "addr:" << param.from.str() << ", asset_type:" << param.asset_type.str() << std::endl;
    
    return PERROR(MEM::FIND_UTXO_FAIL,"addr:{},asset_type:{}",param.from.str(),param.asset_type.str());
  }

  if (outputUtxosSet.empty()) {
    ERRORLOG( "Utxo is empty!" );
     return PERROR(MEM::FIND_UTXO_FAIL,"Utxo is empty!");
  }
  // 原使用Vote作为分红资产类型，现统一改为OHI
utxo->set_assettype(global::ca::ASSET_TYPE_OHI);
  //  Fill Vin
  std::set<std::string> setTxOwners;
  for (auto &utxo : outputUtxosSet) {
    setTxOwners.insert(utxo.addr);
  }

  if (setTxOwners.size() != 1) {
      ERRORLOG( "Tx owner is invalid!" );
      return PERROR(MEM::FIND_UTXO_FAIL,"Tx owner is invalid!");
  }

  for (auto &owner : setTxOwners) {
    utxo->add_owner(owner);
    uint32_t n = sq;
    CTxInput *vin = utxo->add_vin();
    for (auto &utxo : outputUtxosSet) {
      if (owner == utxo.addr) {
        CTxPrevOutput *prevOutput = vin->add_prevout();
        prevOutput->set_hash(utxo.hash);
        prevOutput->set_n(utxo.n);
      }
    }
    vin->set_sequence(n++);

 
  }

  
  return balance;
}
