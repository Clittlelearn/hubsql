﻿#pragma  once
#include "transaction.pb.h"
#include "utxo_core.h"

struct StakeTransParam{
        ohi::CowString addr;
        ohi::CowString asset_type;
        int64_t amount;
        ohi::CowString reward_rank_string;
        ohi::CowString encoded_info;
        ohi::UtxoCore::OtherToPayGas gas_tray;
        bool is_gas_tray=false;
        bool is_find_utxo=false;
        REFLECT(addr,asset_type,amount,reward_rank_string,encoded_info,gas_tray,is_gas_tray,is_find_utxo)
    };

class StakeTrans:public ohi::UtxoCore{
   
    public:
    


    StakeTransParam s_stake_trans_param;

   
    StakeTrans(const  StakeTransParam & param ){
        s_stake_trans_param=param;
        
    }
    expected<bool> trans()override;
    expected<bool> goMessage()override;
    
protected:
    // expected<int64_t> createUtxoGas(CTransaction * tx,const UtxoGasParam & param)override;
    // expected<UtxoCore::SingRe> sign(const ohi::CowString &addr,const ohi::CowString & data)override;
    expected<bool> makeTxInfor(CTransaction * tx) override;
    expected<bool> checkParams()override;
    expected<int64_t> getGasValue(CTxUtxos * u,int index) override;
    

   
private:

private:
    double commission_rate_=0;
};
