﻿#include "stake.h"
#include "ca/global.h"
#include "pb/transaction.pb.h"
#include "transaction.pb.h"
#include "transaction/utxo_core.h"
#include "utils/tmp_log.h"
#include "errorn/ca/error.def.h"
#include "error.h"
#include "ca/transaction.h"
#include "ca/address_status_cache.h"
#include "utils/version.h"
#include "common/genesis_helper.h"


using namespace ohi;
expected<bool> StakeTrans::trans()
{

   // --network dev_genesis.json --menu
    auto checkRet=checkParams();
    if(!checkRet.isOk()){
        return checkRet.Error();
    }
    //create stake utxo
    CTxUtxos * u=tx.add_utxos();
    TransferFromParam VinParm;
    VinParm.from=s_stake_trans_param.addr;
    VinParm.amount=s_stake_trans_param.amount;
    VinParm.asset_type=s_stake_trans_param.asset_type;
    VinParm.is_find_utxo=s_stake_trans_param.is_find_utxo;
    auto BalnaceRet=createUtxoTransferFrom(u,VinParm,0);
    if(!BalnaceRet.isOk()){
        return BalnaceRet<< PERROR(MEM::GEN_VIN_FAIL);
    }

    makeTxInfor(&tx);
    
    auto e_gas_value=getGasValue(u,0);

    if(!e_gas_value.isOk()){
        return e_gas_value<< PERROR(MEM::GET_GAS_VALUE_FAIL);
    }

    //to stake account
    TransferToParam tos_StakeTrans_param;
    tos_StakeTrans_param.amount=s_stake_trans_param.amount;
    tos_StakeTrans_param.to=global::ca::kTargetAddress;
   

    // to burn and to slef;
    TransferToParam to_burn_param,to_slef_param;
    to_burn_param.to=global::ca::VIRTUAL_BURN_GAS_ADDR;
    to_slef_param.to=s_stake_trans_param.addr;


    if(s_stake_trans_param.is_gas_tray){//if other pay gas
        to_burn_param.amount=0;
        to_slef_param.amount=BalnaceRet.Value()-s_stake_trans_param.amount;
    }else{
        to_burn_param.amount=e_gas_value.Value();

        int64_t expend=s_stake_trans_param.amount+e_gas_value.Value();
        if(expend > BalnaceRet.Value()){
            return PERROR(MEM::INSUFFICIENT_ASSET_TYPE);
        }
        to_slef_param.amount=BalnaceRet.Value()-expend;
    }
    createUtxoTransferTo(u,tos_StakeTrans_param);// to stake
    createUtxoTransferTo(u,to_slef_param);// to self
    createUtxoTransferTo(u, to_burn_param);// to burn

    // auto singre=signUtxo(s_stake_trans_param.addr, u);

    // if(singre.isOk()){
    //     return singre.get_error();
    // }

    if(s_stake_trans_param.is_gas_tray)
    {
        UtxoGasParam gas_param;
        gas_param.asset_type=s_stake_trans_param.gas_tray.asset_type;
        gas_param.from=s_stake_trans_param.gas_tray.addr;
        gas_param.gas=e_gas_value.Value();
        auto GasRet=createUtxoGas(&tx,gas_param);
        if(!GasRet.isOk()){
            return GasRet<< PERROR(MEM::GEN_GAS_UTXO_FAIL);
        }
    }

    auto currentTime=MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
	tx.set_time(currentTime);
	tx.set_consensus(global::ca::kConsensus);
	tx.set_type((uint32_t)global::ca::TxType::STAKE);
    
    std::string all_hash=calculate_all_hash(&tx);
    
    TxHelper::vrfAgentType vrftype=TxHelper::vrfAgentType_vrf;
    std::string identity;

	int ret = TxHelper::fetchIdentityNodes(vrftype, all_hash, currentTime, identity, TxHelper::SelectLocalSelectionSigner(tx));
	if(ret != 0)
	{
        return PERROR(MEM::FAILED_TO_PICK_A_PACKAGER);
		
	}
	DEBUGLOG("Tx identity:{}", identity);
	tx.set_identity(identity);

	// std::string txHash = Getsha256Hash(tx.SerializeAsString());
	// tx.set_hash(txHash);
    return true;
}


expected<bool> StakeTrans::makeTxInfor(CTransaction * tx)
{
    
    ohi::CowString stakeTypeStr=global::ca::STAKE_TYPE_NET;

    nlohmann::json txInfo;
	txInfo["stakeType"] = stakeTypeStr.str();
	txInfo["stakeAmount"] = s_stake_trans_param.amount;
	txInfo["commissionRate"] = commission_rate_;

	nlohmann::json data;
	data["txInfo"] = txInfo;
	tx->set_data(data.dump());
	tx->set_note(s_stake_trans_param.encoded_info.str());


    if (tx->utxos_size() <= 0)
    {
        ERRORLOG("tx has no utxos!");
        return -1;
    }

    if (tx->utxos(0).owner_size() <= 0)
    {
        ERRORLOG("utxos(0) has no owner!");
        return -2;
    }

    uint64_t nonce = 0;
	DBReader db_reader;
	if(db_reader.getNonceByAddr(tx->utxos(0).owner(0), nonce) != DBStatus::DB_SUCCESS &&
	db_reader.getNonceByAddr(tx->utxos(0).owner(0), nonce) != DBStatus::DB_NOT_FOUND){
	ERRORLOG("get NonceByAddr error");
	return PERROR(MEM::FAILED_TO_GET_NONCE,"addr:{}", tx->utxos(0).owner(0));
	}
	tx->set_nonce(nonce);
	//tx->set_type(global::ca::kTxSign);	
    return true;
    
}

expected<bool> StakeTrans::checkParams()
{
    // if(s_stake_trans_param.gas_tray.addr.empty()|| s_stake_trans_param.gas_tray.asset_type.empty()){
    //     s_stake_trans_param.is_gas_tray=false;
    // }

    bool isStake= MagicSingleton<ohi::utils::AddressStatusCache>::GetInstance()->isStaked(s_stake_trans_param.addr.c_str());


    if(isStake){
       return PERROR(MEM::ACCOUNT_HAS_STAKED);
    }
    
    // Fix-3: Check if node is tombstoned (permanently banned)
    DBReader dbReader;
    std::string tombstoneVal;
    if (DBStatus::DB_SUCCESS == dbReader.readData(std::string("slash_tombstone_") + s_stake_trans_param.addr.str(), tombstoneVal))
    {
        ERRORLOG("[SLASH] Tombstoned node {} attempted to re-stake — rejected", s_stake_trans_param.addr.str());
        return PERROR(MEM::ACCOUNT_HAS_STAKED);  // Reuse this error code
    }
    
    if(s_stake_trans_param.amount < global::ca::MIN_STAKE_AMOUNT){
         return PERROR(MEM::THE_STAKE_AMOUNT_IS_INSUFFICIENT);
    }

    commission_rate_ = std::stold(s_stake_trans_param.reward_rank_string.str()) / 100;
    if(commission_rate_ < global::ca::MIN_COMMISSION_RATE || commission_rate_ > global::ca::MAX_COMMISSION_RATE)
    {
        return PERROR(MEM::THE_PUMPING_RATIO_IS_WRONG,"comission rate is {}",commission_rate_);
    }
    return true;
}

expected<int64_t> StakeTrans::getGasValue(CTxUtxos * u,int index)
{
    uint64_t gas = 0;
	uint64_t gasSize = tx.data().size() + tx.note().size() + tx.reserve0().size() + tx.reserve1().size();
	//  Calculate total expenditure
	std::map<std::string, int64_t> toAddr;
	toAddr.insert(std::make_pair(global::ca::kTargetAddress, 0));
	toAddr.insert(std::make_pair(s_stake_trans_param.addr.str(), 0));
	toAddr.insert(std::make_pair(global::ca::VIRTUAL_BURN_GAS_ADDR, gas));
	// auto &  u=tx->utxos()[0];
	if(GenerateGas(*u, toAddr.size(),gasSize,gas) != 0)
	{
		return PERROR(MEM::GAS_IS_ZERO);
		
	}
    if(GetInitAccountAddr() == s_stake_trans_param.addr.str())
    {
        gas = 0;
    }

    return gas;
}



expected<bool> StakeTrans::goMessage()
{
    TxMsgReq txMsg;

    uint64_t top = 0;
    auto  retNum = transactionDiscoveryHeight();
    if(!retNum.isOk() ){
        return retNum<< PERROR(MEM::FAILED_TO_GET_HEIGHT);
    }
    top=retNum.Value();
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(tx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    auto ret = TxHelper::get_tx_utxo_height(tx, txUtxoLocalHeight);
    if(ret != 0)
    {
        return PERROR(MEM::FAILED_TO_GET_UTXO_HEIGHT);
        
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);
 
    auto msg = std::make_shared<TxMsgReq>(txMsg);

    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

    if(tx.identity() == defaultAddr)
    {
        ret = handleTransaction(msg,tx);
        
    }
    else
    {
        ret = DropShippingTransaction(msg, tx, tx.identity());
    }

    if (ret != 0)
    {
        //UtxoError().trace(NOERROR,"%s => what:%s",ret).to_string();
        ret -= 100;
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, tx.hash());
    return true;
}
