﻿#pragma once

#include "utxo_core.h"
#include "interface.pb.h"
#include "transaction.pb.h"
#include "txhelper.h"
#include "CowString.hpp"
#include <cstdint>
#include <vector>


    struct DelegatingTransParam{
       ohi::CowString from_addr;
       ohi::CowString to_addr;
       ohi::CowString asset_type;
       ohi::CowString encoded_info;
       int delegate_type;
       ohi::UtxoCore::OtherToPayGas gas_tray;
       bool is_gas_tray = false;
       bool is_find_utxo=false;
       //uint64_t height = 0;
       uint64_t delegatinged_amount = 0;
       REFLECT(from_addr,to_addr,asset_type,encoded_info,delegate_type,gas_tray,is_gas_tray,is_find_utxo,delegatinged_amount)
    };
class DelegatingTrans:public ohi::UtxoCore{
public:
    
    DelegatingTransParam s_delegating_trans_param;

    DelegatingTrans(const  DelegatingTransParam & param ){
        s_delegating_trans_param=param;
    }
    
    expected<bool> trans()override;
    expected<bool> goMessage()override;
protected:
    expected<bool> makeTxInfor(CTransaction * tx) override;
    expected<bool> checkParams()override;
    expected<int64_t> getGasValue(CTxUtxos * u,int trans_index);
private:
    uint64_t delegatinged_amount = 0;
    uint64_t total = 0;
    uint64_t expend = 0;
    ohi::CowString delegate_type_name{};
};