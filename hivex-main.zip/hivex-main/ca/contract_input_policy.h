#ifndef OPENHIVE_CA_CONTRACT_INPUT_POLICY_H
#define OPENHIVE_CA_CONTRACT_INPUT_POLICY_H

#include <cstdint>
#include <limits>
#include <set>
#include <string>
#include <utility>

namespace contract_input
{
struct GroupOwnerMatch
{
    int group = -1;
    int owner = -1;
    explicit operator bool() const { return group >= 0 && owner >= 0; }
};

template <typename Transaction>
GroupOwnerMatch FindNextOwnerGroup(const Transaction& tx, const std::string& owner,
                                   const std::string& asset_type,
                                   const std::set<std::pair<int, int>>& used)
{
    for (int i = 0; i < tx.utxos_size(); ++i)
    {
        if (tx.utxos(i).assettype() != asset_type) continue;
        for (int ownerIndex = 0; ownerIndex < tx.utxos(i).owner_size(); ++ownerIndex)
            if (tx.utxos(i).owner(ownerIndex) == owner && used.count({i, ownerIndex}) == 0)
                return {i, ownerIndex};
    }
    return {};
}

inline bool AddWithoutOverflow(uint64_t value, uint64_t& total)
{
    if (value > std::numeric_limits<uint64_t>::max() - total) return false;
    total += value;
    return true;
}
} // namespace contract_input

#endif // OPENHIVE_CA_CONTRACT_INPUT_POLICY_H
