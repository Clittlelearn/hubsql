﻿#include <iostream>
#include <memory>
#include <string>
#include <unordered_map>
#include <future>
#include <chrono>
#include <thread>
#include <sstream>
#include <algorithm>


#include "ca/checker.h"
#include "ca/contract.h"
#include "ca/txhelper.h"
#include "ca/algorithm.h"
#include "ca/transaction.h"
#include "ca/block_helper.h"
#include "ca/transaction_cache.h"
#include "ca/contract_nonce_policy.h"
#include "ca/contract_waiting_store.h"
#include "ca/confirmed_exclusion_verifier.h"
#include "ca/confirmed_exclusion_policy.h"
#include "ca/failed_transaction_cache.h"
#include "ca/dispatchtx.h"
#include "ca/sync_block.h"

#include <nlohmann/json.hpp>
#include "utils/console.h"
#include "utils/tmp_log.h"
#include "include/scope_guard.h"
#include "utils/time_util.h"
#include "utils/time_util.h"
#include "utils/bench_mark.h"
#include "utils/contract_utils.h"
#include "utils/magic_singleton.h"
#include "utils/account_manager.h"
#include "utils/pretty_print.h"

#include "db/db_api.h"
#include "net/unregister_node.h"
#include "eth/eth.h"
#include "eth_trans.h"

#include "common/time_report.h"
#include "common/global_data.h"
#include "ca/evm/evm_manager.h"
#include "utils/version.h"

class contractDataContainer;

namespace {

constexpr char kStageContractPackagerHandle[] = "contract_packager_handle";

contract_repack::ChainTipSnapshot CaptureChainTip()
{
    contract_repack::ChainTipSnapshot snapshot;
    DBReader dbReader;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(snapshot.height)) return snapshot;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockHashsByBlockHeight(snapshot.height, snapshot.hashes)) return snapshot;
    contract_repack::Canonicalize(snapshot);
    snapshot.valid = !snapshot.hashes.empty();
    return snapshot;
}

bool HasChainTipChanged(const contract_repack::ChainTipSnapshot& executionBase, const char* checkpoint)
{
    const auto current = CaptureChainTip();
    const auto comparison = contract_repack::CompareTips(executionBase, current);
    if (comparison == contract_repack::TipComparison::kUnavailable)
    {
        ERRORLOG("CONTRACT_REPACK tip check unavailable, checkpoint:{}, base_valid:{}, current_valid:{}",
                checkpoint, executionBase.valid, current.valid);
        return true;
    }
    if (comparison == contract_repack::TipComparison::kUnchanged) return false;
    WARNLOG("CONTRACT_REPACK stale parent, checkpoint:{}, reason:{}, base_height:{}, current_height:{}, base_hashes:{}, current_hashes:{}",
            checkpoint, contract_repack::TipComparisonName(comparison), executionBase.height, current.height,
            executionBase.hashes.size(), current.hashes.size());
    return true;
}

}  // namespace

const int TransactionCache::BUILD_INTERVAL = 3 * 1000;
const time_t TransactionCache::_kTxExpireInterval  = 10;
const int TransactionCache::BUILD_THRESHOLD = 1000000;
const size_t TransactionCache::MAX_TX_POOL_SIZE = 10000;
const size_t TransactionCache::MAX_CONTRACT_POOL_SIZE = 5000;


int CreateBlock(const std::list<CTransaction>& txs, const uint64_t& blockHeight, CBlock& cblock)
{
	cblock.Clear();

	// Fill version
	cblock.set_version(global::ca::kCurrentBlockVersion);

	// Fill height
	uint64_t prevBlockHeight = blockHeight;
	cblock.set_height(prevBlockHeight + 1);

    nlohmann::json storage;
    bool isContractualBlock = false;

    uint64_t blockTime = 0;
    packDispatch packdis;
	// Fill tx
	for(auto& tx : txs)
	{
		// Add major transaction
		CTransaction * majorTx = cblock.add_txs();
		*majorTx = tx;
		auto& txHash = tx.hash();
        //DEBUGLOG("txHash:{}, txTime:{}", txHash, tx.time() / 1000000);
        auto txType = (global::ca::TxType)tx.type();
        if(tx.time() > blockTime)
        {
            blockTime = tx.time();
        }
        if (txType == global::ca::TxType::CALL || txType == global::ca::TxType::DEPLOY)
        {
            isContractualBlock = true;
            nlohmann::json txStorage;
            if (MagicSingleton<TransactionCache>::GetInstance()->get_contract_info_cache(txHash, txStorage) != 0)
            {
                ERRORLOG("can't find storage of tx {}", txHash);
                return -1;
            }

            std::set<std::string> dirtyContractList_;
            if(!MagicSingleton<TransactionCache>::GetInstance()->get_dirty_contract_map(tx.hash(), dirtyContractList_))
            {
                ERRORLOG("get_dirty_contract_map fail!!! txHash:{}", tx.hash());
                return -2;
            }
            txStorage["dependentCtx"] = dirtyContractList_;

            storage[txHash] = txStorage;
        }
	}
    cblock.set_time(blockTime);

    cblock.set_data(storage.dump());
    // Fill preblockhash
    uint64_t seekPrehashTimeValue = 0;
    std::future_status status;
    auto futurePreHash = MagicSingleton<BlockStorage>::GetInstance()->GetPrehash(prevBlockHeight);
    if(!futurePreHash.valid())
    {
        ERRORLOG("futurePreHash invalid,hight:{}",prevBlockHeight);
        return -2;
    }
    status = futurePreHash.wait_for(std::chrono::seconds(6));
    if (status == std::future_status::timeout) 
    {
        ERRORLOG("seek prehash timeout, hight:{}",prevBlockHeight);
        return -3;
    }
    else if(status == std::future_status::ready) 
    {
        std::string preBlockHash = futurePreHash.get().first;
        if(preBlockHash.empty())
        {
            ERRORLOG("seek prehash <fail>!!!,hight:{},prehash:{}",prevBlockHeight, preBlockHash);
            return -4;
        }
        DEBUGLOG("seek prehash <success>!!!,hight:{},prehash:{},blockHeight:{}",prevBlockHeight, preBlockHash, blockHeight);
        seekPrehashTimeValue = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
        cblock.set_prevhash(preBlockHash);
    }
    
	// Fill merkleroot
	cblock.set_merkleroot(ca_algorithm::calculateBlockMerkle(cblock));
	// Fill hash
	cblock.set_hash(Getsha256Hash(cblock.SerializeAsString()));
    DEBUGLOG("blockHash:{}, \n storage:{}", cblock.hash().substr(0,6), storage.dump(4));
    DEBUGLOG("block hash = {} set time blockTime:{}",cblock.hash(), blockTime);
	return 0;
}

int BuildBlock(const std::list<CTransaction>& txs, const uint64_t& blockHeight, bool build_first,
               bool isConTractTx = false,
               const contract_repack::ChainTipSnapshot* executionBase = nullptr)
{
	if(txs.empty())
	{
		ERRORLOG("Txs is empty!");
		return -1;
	}

	CBlock cblock;
	if (isConTractTx && executionBase != nullptr && HasChainTipChanged(*executionBase, "before_create_block"))
	{
		return contract_repack::kBuildStaleParent;
	}
	int ret = CreateBlock(txs, blockHeight, cblock);
    if(ret != 0)
    {
        if(ret == -3 || ret == -4 || ret == -5)
        {
            MagicSingleton<BlockStorage>::GetInstance()->ForceCommitSeekJob(cblock.height() - 1);
        }
        auto tx_sum = cblock.txs_size();
        ERRORLOG("Create block failed! : {},  Total number of transactions : {} ", ret, tx_sum);
		return ret - 100;
    }
    if (isConTractTx && executionBase != nullptr && HasChainTipChanged(*executionBase, "after_create_block"))
    {
        return contract_repack::kBuildStaleParent;
    }
    
    print_block_as_json(cblock, std::cout);

	std::string serBlock = cblock.SerializeAsString();

    BlockMsg blockmsg;
    blockmsg.set_version(ohi::GetVersion());
    blockmsg.set_time(MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp());
    blockmsg.set_block(serBlock);
    
    // Keep the dispatcher's packager-selection proof on the block for tracing.
    // Only the selected packager verifies this proof when it receives the
    // ContractPackagerMsg; later block validators no longer re-verify it.
    if (isConTractTx) {
        blockmsg.set_dispatcher_vrf(MagicSingleton<TransactionCache>::GetInstance()->GetContractPackagerSelectionVrf());
    }

    // --- Partial Block: Inject Exclusion Proof if transactions were excluded ---
    auto instance = MagicSingleton<TransactionCache>::GetInstance();
    std::vector<CTransaction> excludedTxs;
    std::vector<ConfirmedTransactionProof> confirmedExclusions;
    uint64_t gasBefore = 0;
    if (instance->GetAndClearExclusionData(excludedTxs, gasBefore, confirmedExclusions)) {
        auto* proof = blockmsg.mutable_exclusion_proof();
        for (const auto& tx : excludedTxs) {
            *proof->add_excluded_txs() = tx;
        }
        proof->set_cumulative_gas_before(gasBefore);
        if (!confirmedExclusions.empty()) {
            proof->set_reason("ALREADY_CONFIRMED");
            proof->set_reason_type(EXCLUSION_ALREADY_CONFIRMED);
            for (const auto& confirmed : confirmedExclusions) *proof->add_confirmed_transactions() = confirmed;
            proof->set_candidate_parent_hash(cblock.prevhash());
            proof->set_dispatcher_vrf_digest(Getsha256Hash(blockmsg.dispatcher_vrf()));
            std::vector<std::string> includedHashes;
            std::vector<std::string> originalHashes;
            for (const auto& tx : cblock.txs()) {
                includedHashes.push_back(tx.hash());
                originalHashes.push_back(tx.hash());
            }
            for (const auto& tx : excludedTxs) originalHashes.push_back(tx.hash());
            proof->set_original_transaction_set_digest(confirmed_exclusion::OrderedSetDigest(originalHashes));
            proof->set_included_transaction_set_digest(confirmed_exclusion::OrderedSetDigest(includedHashes));
        } else {
            proof->set_reason("BLOCK_GAS_LIMIT_EXCEEDED");
            proof->set_reason_type(EXCLUSION_BLOCK_GAS_LIMIT);
        }

        // Sign the proof
        std::string signerAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
        std::string proofData = confirmed_exclusion::SigningPayload(*proof);
        std::string signature, pub;
        if (TxHelper::Sign(signerAddr, proofData, signature, pub) == 0) {
            proof->set_packager_signature(signature);
            WARNLOG("Partial Block: ExclusionProof created and signed for {} excluded txs", excludedTxs.size());
        } else {
            ERRORLOG("Failed to sign ExclusionProof");
        }
    }
    // ------------------------------------------------------------------------

    // Debug: 打印序列化后的大小
    std::string serializedMsg = blockmsg.SerializeAsString();
    WARNLOG("[DEBUG] BlockMsg serialized size: {}, has_exclusion_proof: {}, blockHash: {}", 
            serializedMsg.size(), blockmsg.has_exclusion_proof(), cblock.hash().substr(0, 6));

    auto msg = std::make_shared<BlockMsg>(blockmsg);
	ret = handleBlock(msg);
    if(ret != 0)
    {
        ERRORLOG("handleBlock failed The error code is {} ,blockHash:{}",ret, cblock.hash().substr(0,6));
        if (isConTractTx && executionBase != nullptr && HasChainTipChanged(*executionBase, "after_handle_block_failure"))
        {
            return contract_repack::kBuildStaleParent;
        }
        CBlock cblock;
	    if (!cblock.ParseFromString(msg->block()))
	    {
		    ERRORLOG("fail to serialization!!");
		    return -5;
	    }
        return -6;
    }
    for(const auto& tx : cblock.txs())
    {
        DEBUGLOG("blockHash:{}, txHash:{}", cblock.hash().substr(0,6), tx.hash().substr(0,6));
    }
    DEBUGLOG("block successfully packaged, blockHash:{}", cblock.hash().substr(0,6));
	return 0;
}

TransactionCache::TransactionCache()
{
    _buildTimer.AsyncLoop(
        BUILD_INTERVAL, 
        [this](){
            _blockBuilder.notify_one();
            ScheduleWaitingContractRetry();
        }
        );
}

uint64_t TransactionCache::getBlockCount()
{
    std::unique_lock<std::mutex> locker(transactionCacheMutex);
    return _transactionCache.rbegin()->get_tx_utxo_height();
}

int TransactionCache::AddCache(CTransaction& transaction, const std::shared_ptr<TxMsgReq>& msg)
{
    auto txType = (global::ca::TxType)transaction.type();
    bool isContractExecution = txType == global::ca::TxType::CALL || txType == global::ca::TxType::DEPLOY;
    if (isContractExecution)
    {
        std::unique_lock<std::mutex> locker(contractCacheMutex);
        if(Checker::CheckConflict(transaction, _contractCache))
        {
            DEBUGLOG("DoubleSpentTransactions, txHash:{}", transaction.hash());
            return -1;
        }
        
        // Clean expired transactions before adding new one
        cleanExpiredTransactions(_contractCache, MAX_CONTRACT_POOL_SIZE);
        
        // Check if cache is full after cleanup
        if (_contractCache.size() >= MAX_CONTRACT_POOL_SIZE)
        {
            // Remove the oldest transaction (earliest time)
            _contractCache.erase(_contractCache.begin());
            DEBUGLOG("Contract cache is full, removed oldest transaction, current size: {}", _contractCache.size());
        }
        
        _contractCache.push_back({transaction, msg->txmsginfo().nodeheight(), false});
    }
    else
    {
        std::unique_lock<std::mutex> locker(transactionCacheMutex);
        if(Checker::CheckConflict(transaction, _transactionCache))
        {
            DEBUGLOG("DoubleSpentTransactions, txHash:{}", transaction.hash());
            return -2;
        }

        // Clean expired transactions before adding new one
        cleanExpiredTransactions(_transactionCache, MAX_TX_POOL_SIZE);
        
        // Check if cache is full after cleanup
        if (_transactionCache.size() >= MAX_TX_POOL_SIZE)
        {
            // Remove the oldest transaction (earliest time)
            _transactionCache.erase(_transactionCache.begin());
            DEBUGLOG("Transaction cache is full, removed oldest transaction, current size: {}", _transactionCache.size());
        }

        if((global::ca::TxType)transaction.type() == global::ca::TxType::FUND){
            _transactionCache.push_back({*msg, transaction, msg->txmsginfo().nodeheight()});
        }else{
            _transactionCache.push_back({*msg, transaction, msg->txmsginfo().txutxoheight()});
        }

        if (_transactionCache.size() >= BUILD_THRESHOLD)
        {
            _blockBuilder.notify_one();
        }
    }
    return 0;
}

bool TransactionCache::Process()
{
    transactionCacheBuildThread = std::thread(std::bind(&TransactionCache::processTransactionCacheFunc, this));
    transactionCacheBuildThread.detach();
    ScheduleWaitingContractRetry();
    return true;
}

void TransactionCache::Stop(){
    _threadRun=false;
}

int TransactionCache::get_build_block_height(std::vector<TransactionEntity>& txcache)
{
    int max_utxo_height = 0;
    for(const auto& item : txcache)
    {
        auto txUtxoBlockHeight = item.get_tx_utxo_height();
        if(max_utxo_height < txUtxoBlockHeight)
        {
            max_utxo_height = txUtxoBlockHeight;
        }
    }

    std::vector<Node> nodelist = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    std::map<std::string, uint64_t> satisfiedAddresses;
    for(auto & node : nodelist)
    {
        //Verification of Delegating and pledge
       bool canReward = VerifyBonusAddr(node.address);
        //int64_t stakeTime = ca_algorithm::GetPledgeTimeByAddr(node.address, global::ca::StakeType::STAKE_TYPE_NODE);
        if (canReward)
        {
            satisfiedAddresses[node.address] = node.height;
        }
    }

    if (satisfiedAddresses.size() < global::ca::MIN_SYNC_QUAL_NODES && (max_utxo_height < global::ca::MIN_UNSTAKE_HEIGHT))
	{
		for(auto & node : nodelist)
        {
            if(satisfiedAddresses.find(node.address) == satisfiedAddresses.end())
            {
                satisfiedAddresses[node.address] = node.height;
            }
        }
	}
	else if(satisfiedAddresses.size() < global::ca::MIN_SYNC_QUAL_NODES)
	{
		DEBUGLOG("Insufficient qualified signature nodes satisfiedAddresses.size:{}", satisfiedAddresses.size());
		return -1;
	}


    std::map<uint64_t, uint64_t> heightCount;
    uint64_t heightMatchCount = 0;
    std::map<uint64_t, uint64_t> heightFrequency;

    for(auto &it : satisfiedAddresses)
    {
        if(it.second >= max_utxo_height)
        {        
            heightMatchCount++;
        }
        heightFrequency[it.second]++;
    }
    
    uint64_t cumulativeCount = 0;
    for(auto it = heightFrequency.rbegin(); it != heightFrequency.rend(); it++)
    {
        cumulativeCount += it->second; // Add the frequency of this height to the cumulative count
        heightCount[it->first] = cumulativeCount; 
        DEBUGLOG("heightFrequency, hegiht:{}, sum:{}", it->first, it->second);
    }

    if(heightMatchCount < satisfiedAddresses.size() * global::ca::kChainHeightPercentile)
    {
        DEBUGLOG("heightMatchCount:{}, satisfiedAddresses.size:{}, {}, max_utxo_height:{}", heightMatchCount, satisfiedAddresses.size(), satisfiedAddresses.size() * global::ca::kChainHeightPercentile, max_utxo_height);
        return -2;
    }

    DBReader dbReader;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
    }

    if(top >= max_utxo_height)
    {
        auto it = heightCount.find(top);
        DEBUGLOG("top:{}, it->second:{}, satisfiedAddresses.size:{}", top, it->second, satisfiedAddresses.size());
        if(it != heightCount.end() && it->second >= satisfiedAddresses.size() * global::ca::kChainHeightPercentile)
        {
            DEBUGLOG("top top top top top");
            return top;
        }
    }



    for(auto item = heightCount.rbegin(); item != heightCount.rend(); item++)
    {
        DEBUGLOG("item.first:{}, max_utxo_height:{}, {}", item->first, max_utxo_height, satisfiedAddresses.size() * global::ca::kChainHeightPercentile);
        if(item->first < max_utxo_height)
        {
            return -3;
        }
        if(item->second >= satisfiedAddresses.size() * global::ca::kChainHeightPercentile)
        {
            return item->first;
        }
    }
    return -4;
}

void TransactionCache::cleanExpiredTransactions(std::vector<TransactionEntity>& cache, size_t maxSize)
{
    if (cache.empty())
        return;

    uint64_t nowTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    uint64_t expireTime = _kTxExpireInterval * 1000000; // Convert to microseconds

    // Find the first transaction that hasn't expired
    auto it = cache.begin();
    while (it != cache.end())
    {
        uint64_t txTime = it->GetTxTime();
        // 关键修复：防止下溢
        // 当 txTime > nowTime 时（交易时间戳比节点时钟快），不应过期
        // 当 txTime == 0 时（无效时间戳），跳过
        if (txTime == 0 || txTime > nowTime || (nowTime - txTime) <= expireTime)
        {
            // This transaction hasn't expired yet, stop removing
            break;
        }

        DEBUGLOG("Transaction expired, removing txHash: {}, txTime: {}, nowTime: {}, age: {} seconds",
            it->GetTx().hash().substr(0, 8),
            txTime / 1000000,
            nowTime / 1000000,
            (nowTime - txTime) / 1000000);

        it = cache.erase(it);
    }

    // If cache is still full after cleanup, remove oldest transactions
    while (cache.size() > maxSize)
    {
        DEBUGLOG("Cache is full after cleanup, removing oldest transaction, current size: {}, max: {}", cache.size(), maxSize);
        cache.erase(cache.begin());
    }
}

void TransactionCache::processTransactionCacheFunc()
{
    std::stringstream ss;
    ss << std::this_thread::get_id();
    DEBUGLOG("processTransactionCacheFunc thread started, thread_id: {}", ss.str());
    while (_threadRun)
    {
        std::unique_lock<std::mutex> locker(transactionCacheMutex);
        _blockBuilder.wait(locker);

        std::list<CTransaction> buildTxs;
        if(_transactionCache.empty())
        {
            continue;
        }

        // Clean expired transactions before building block
        cleanExpiredTransactions(_transactionCache, MAX_TX_POOL_SIZE);
        
        if(_transactionCache.empty())
        {
            continue;
        }

        clearBuiltTransactions();
        int buildHeight = get_build_block_height(_transactionCache);
        if(buildHeight < 0)
        {
            _transactionCache.clear();
            ERRORLOG("get_build_block_height fail!!! ret:{}", buildHeight);
            DEBUGLOG("processTransactionCacheFunc thread iteration skipped: get_build_block_height failed with ret: {}, thread_id: {}", buildHeight, ss.str());
            continue;
        }
        MagicSingleton<BlockStorage>::GetInstance()->commitLookupTask(buildHeight);

        std::map<std::string, std::future<int>> taskResults;
        for(auto& txs : _transactionCache)
        {
            buildTxs.push_back(txs.GetTx());
        }

        auto ret = BuildBlock(buildTxs, buildHeight, false);
        if(ret != 0)
        {
            ERRORLOG("{} build block fail", ret);
            if(ret == -103 || ret == -104 || ret == -105)
            {
                DEBUGLOG("processTransactionCacheFunc thread iteration skipped: BuildBlock failed with recoverable error ret: {}, thread_id: {}", ret, ss.str());
                continue;
            }
            
            _transactionCache.clear();
            std::cout << "block packaging fail" << std::endl;
            DEBUGLOG("processTransactionCacheFunc thread iteration skipped: BuildBlock failed with non-recoverable error ret: {}, thread_id: {}", ret, ss.str());
            continue;
        }
        std::cout << "block successfully packaged" << std::endl;
        _transactionCache.clear();

        locker.unlock();
    }
    DEBUGLOG("processTransactionCacheFunc thread exited: _threadRun set to false, thread_id: {}", ss.str());
}

int TransactionCache::ProcessContract(
    int64_t topTransactionHeight_,
    const contract_repack::ChainTipSnapshot& executionBase,
    const std::vector<std::string>& authorizedTxHashes)
{
    std::scoped_lock locker(contractCacheMutex, contractInfoCacheMutex, dirtyContractMapMutex);
    
    // Clean expired transactions before processing
    cleanExpiredTransactions(_contractCache, MAX_CONTRACT_POOL_SIZE);
    
    std::list<CTransaction> buildTxs;

    for(const auto& txEntity : _contractCache)
    {
        buildTxs.push_back(txEntity.GetTransaction());
    }

    if (buildTxs.empty())
    {
        DEBUGLOG("buildTxs.empty() after cleanup");
        return -1;
    }

    std::vector<std::string> includedTxHashes;
    includedTxHashes.reserve(buildTxs.size());
    for (const auto& tx : buildTxs) includedTxHashes.push_back(tx.hash());

    std::vector<std::string> excludedTxHashes;
    {
        std::lock_guard<std::mutex> exclusionLock(m_excludedTransactionsMutex);
        if (!m_confirmedExclusions.empty() && m_confirmedExclusions.size() != m_excludedTransactions.size())
        {
            ERRORLOG("CONTRACT_REPACK mixed confirmed and gas exclusions are not representable safely");
            return contract_repack::kBatchTransactionRejected;
        }
        excludedTxHashes.reserve(m_excludedTransactions.size());
        for (const auto& tx : m_excludedTransactions) excludedTxHashes.push_back(tx.hash());
    }

    const auto setComparison = contract_repack::CompareAuthorizedTransactionSet(
        authorizedTxHashes, includedTxHashes, excludedTxHashes);
    if (setComparison != contract_repack::BatchSetComparison::kEqual)
    {
        ERRORLOG("CONTRACT_REPACK batch atomicity violation, reason:{}, authorized:{}, included:{}, excluded:{}",
                 contract_repack::BatchSetComparisonName(setComparison), authorizedTxHashes.size(),
                 includedTxHashes.size(), excludedTxHashes.size());
        return contract_repack::kBatchTransactionSetMismatch;
    }

    DBReader dbReader;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("getBlockTop error!");
        std::cout << "block packaging fail" << std::endl;
        // ClearContractDependencies(buildTxs, "contract block top lookup failed");
        return -1;
    }
    if (top > topTransactionHeight_)
    {
        MagicSingleton<BlockStorage>::GetInstance()->commitLookupTask(top);
        topTransactionHeight_ = top;
        DEBUGLOG("top:{} > topTransactionHeight_:{}", top, topTransactionHeight_);
    }
    if (buildTxs.empty())
    {
        DEBUGLOG("buildTxs.empty()");
        return -1;
    }

    bool clearContractCacheOnExit = true;
    ON_SCOPE_EXIT{
        removeExpiredFromDirtyContractMap();
        if (clearContractCacheOnExit)
        {
            _contractCache.clear();
            contractInfoCache.clear();
        }
    };

    if (HasChainTipChanged(executionBase, "before_contract_prehash"))
    {
        clearContractCacheOnExit = false;
        return contract_repack::kBuildStaleParent;
    }

    std::list<std::pair<std::string, std::string>> contractTxPrevHashList;
    if(fetchContractTxPreHash(buildTxs,contractTxPrevHashList) != 0)
    {
        clearContractCacheOnExit = false;
        ERRORLOG("fetchContractTxPreHash fail");
        return -1;
    }
    if(contractTxPrevHashList.empty())
    {
        DEBUGLOG("contractTxPrevHashList empty");
    }
    else
    {
        auto ret = newSeekContractPreHash(contractTxPrevHashList);
        if ( ret != 0)
        {
            clearContractCacheOnExit = false;
            ERRORLOG("{} newSeekContractPreHash fail", ret);
            return ret;
        }
    }

    auto ret = BuildBlock(buildTxs, topTransactionHeight_, false, true, &executionBase);
    if(ret != 0)
    {
        if (contract_repack::IsRecoverableBuildResult(ret))
        {
            clearContractCacheOnExit = false;
            WARNLOG("retain contract cache for retry after recoverable build block failure, ret:{}", ret);
        }
        ERRORLOG("{} build block fail", ret);
        std::cout << "block packaging fail" << std::endl;
    }
    else
    {
        std::cout << "block successfully packaged" << std::endl;
    }
    DEBUGLOG("FFF 555555555");
    return ret;
}

std::pair<int, std::string>
TransactionCache::executeContracts(const std::map<std::string, CTransaction> &dependentContractTxMap_,
                                    int64_t blockNumber)
{
    uint64_t StartTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    contractDataContainer contractDataStorage;
    std::map<std::string, std::string> contractPreHashCache_;

    // 累计区块实际Gas消耗
    uint64_t totalBlockGasCost = 0;
    uint64_t contractTxCount = 0;

    // 转换为时间戳排序的容器，确保与打包者执行顺序一致
    // Convert to timestamp-sorted container to ensure consistent execution order with packager
    std::vector<std::pair<uint64_t, CTransaction>> tx_with_timestamp;
    for (const auto& iterPair : dependentContractTxMap_)
    {
        const auto& tx = iterPair.second;
        tx_with_timestamp.emplace_back(tx.time(), tx);
    }

    // 按时间戳排序（时间戳相同时按哈希排序保证确定性）
    // Sort by timestamp (use hash as secondary key for determinism)
    std::sort(tx_with_timestamp.begin(), tx_with_timestamp.end(),
              [](const auto& a, const auto& b) {
                  if (a.first != b.first) return a.first < b.first;
                  return a.second.hash() < b.second.hash();
              });

    // 遍历依赖合约交易：按时间戳顺序逐个执行
    // Iterate dependent contract transactions: execute in timestamp order
    auto it = tx_with_timestamp.begin();
    for (; it != tx_with_timestamp.end(); ++it)
    {
        uint64_t StartTime1 = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
        const auto& tx = it->second;
        auto txType = (global::ca::TxType)tx.type();

        uint64_t txGasCost = 0;

        // System transactions (EVIDENCE/PUNISHMENT) skip contract execution and gas accumulation
        if (txType == global::ca::TxType::EVIDENCE || txType == global::ca::TxType::PUNISHMENT)
        {
            DEBUGLOG("[SLASH] System tx skipped: type={}, hash={}", (int)txType, tx.hash().substr(0, 8));
            continue;
        }

        if ( (txType != global::ca::TxType::CALL && txType != global::ca::TxType::DEPLOY)
            || addContractInfoCache(tx, contractPreHashCache_, &contractDataStorage, blockNumber + 1, &txGasCost) != 0)
        {
            return {-1,tx.hash()};
        }

        // 累计Gas
        totalBlockGasCost += txGasCost;
        contractTxCount++;

        // 熔断机制：如果累计Gas超过区块上限
        if (totalBlockGasCost > global::ca::kBlockGasLimit) {
            WARNLOG("Block circuit breaker triggered (Partial Block): block_height={}, tx_count={}, total_gas_cost={}, gas_limit={}, last_tx={}",
                    blockNumber + 1, contractTxCount, totalBlockGasCost, global::ca::kBlockGasLimit, tx.hash().substr(0, 8));
            
            // 1. 记录导致超限的当前交易和剩余所有交易为 "Excluded"
            {
                std::lock_guard<std::mutex> lock(m_excludedTransactionsMutex);
                m_cumulativeGasBeforeExclusion = totalBlockGasCost - txGasCost; // Gas before this tx
                
                // 添加当前交易
                m_excludedTransactions.push_back(tx);
                
                // 添加剩余所有交易
                auto nextIt = std::next(it);
                for (; nextIt != tx_with_timestamp.end(); ++nextIt) {
                    m_excludedTransactions.push_back(nextIt->second);
                }
            }

            // 2. 从缓存中移除这些交易，防止 ProcessContract 打包它们
            removeContractInfoCacheRequest({{tx.hash(), tx}});
            // 移除当前交易
            removeTransactionFromContractCache(tx);

            // 移除剩余交易
            auto nextIt = std::next(it);
            for (; nextIt != tx_with_timestamp.end(); ++nextIt) {
                removeContractInfoCacheRequest({{nextIt->second.hash(), nextIt->second}});
                removeTransactionFromContractCache(nextIt->second);
            }

            // 返回成功（Partial Block），让流程继续构建区块
            return {0, "PartialBlock"};
        }

        uint64_t StartTime2 = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
        DEBUGLOG("FFF executeContracts HHHHHHHHHH txHash:{}, time:{}", tx.hash().substr(0,6), (StartTime2 - StartTime1) / 1000000.0);
    }
    uint64_t EndTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    DEBUGLOG("FFF executeContracts HHHHHHHHHH txSize:{}, Time:{}",tx_with_timestamp.size(), (EndTime - StartTime) / 1000000.0);

    // 输出区块级Gas统计（测试用）
    DEBUGLOG("Block gas stats: block_height={}, contract_tx_count={}, total_gas_cost={}, block_gas_limit={}, usage_pct={:.1f}%",
             blockNumber + 1, contractTxCount, totalBlockGasCost, global::ca::kBlockGasLimit,
             (double)totalBlockGasCost / global::ca::kBlockGasLimit * 100.0);

    return {0,""};
}

bool TransactionCache::verifyDirtyContractFlag(const std::string &transactionHash, const std::vector<std::string> &calledContract)
{
    auto found = dirtyContractMap.find(transactionHash);
    if (found == dirtyContractMap.end())
    {
        ERRORLOG("dirty contract not found hash: {}", transactionHash);
        return false;
    }
    std::set<std::string> calledContractContainer(calledContract.begin(), calledContract.end());
    std::vector<std::string> result;
    std::set_difference(calledContractContainer.begin(), calledContractContainer.end(),
                        found->second.second.begin(), found->second.second.end(),
                        std::back_inserter(result));
    if (!result.empty())
    {
        for (const auto& addr : calledContract)
        {
            ERRORLOG("executed {}", addr);
        }
        for (const auto& addr : found->second.second)
        {
            ERRORLOG("found {}", addr);
        }
        for (const auto& addr : result)
        {
            ERRORLOG("result {}", addr);
        }
        ERRORLOG("dirty contract doesn't match execute result, tx hash: {}", transactionHash);
        return false;
    }
    return true;
}

int TransactionCache::addContractInfoCache(const CTransaction &transaction,
                                            std::map<std::string, std::string> &contractPreHashCache_,
                                            contractDataContainer *contractDataStorage, int64_t blockNumber,
                                            uint64_t* outGasCost)
{
    auto txType = (global::ca::TxType)transaction.type();
    if (txType != global::ca::TxType::CALL && txType != global::ca::TxType::DEPLOY)
    {
        return 0;
    }

    std::string contractOwnerEvmAddress;
    global::ca::VmType vmType;

    std::string code;
    std::string input;
    std::string deployerAddr;
    std::string destAddr;
    uint64_t contractTransfer;
    std::string contractAddress;
    // bool isFlowInTx = false;
    // bool isFlowOutTx = false;
    ca_algorithm::FlowTxType flowTxType = ca_algorithm::FlowTxType::Unknown;
    try
    {
        nlohmann::json dataJson = nlohmann::json::parse(transaction.data());
        nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();

        if(txInfo.find(Evmone::contractSenderKeyName_) != txInfo.end())
        {
            contractOwnerEvmAddress = txInfo[Evmone::contractSenderKeyName_].get<std::string>();
        }
        vmType = txInfo[Evmone::contractVmKeyName].get<global::ca::VmType>();

        if (txType == global::ca::TxType::CALL)
        {
            input = txInfo[Evmone::contract_input_key_name].get<std::string>();

            flowTxType = ca_algorithm::GetFlowTxType(txInfo);

            if(vmType == global::ca::VmType::EVM)
            {
                contractTransfer = txInfo[Evmone::contractTransferKeyLabel].get<uint64_t>();
                contractAddress = txInfo[Evmone::contractRecipientKeyNameStr].get<std::string>();
            }
        }
        else if (txType == global::ca::TxType::DEPLOY)
        {
            code = txInfo[Evmone::contract_input_key_name].get<std::string>();
            contractAddress = txInfo[Evmone::contractRecipientKeyNameStr].get<std::string>();
        }

    }
    catch (...)
    {
        ERRORLOG("json parse fail");
        return -2;
    }
              
    int64_t gasCost = 0;
    nlohmann::json txInfoJson;
    std::string expectedOutput;
    std::vector<std::string> calledContract;
    std::string coinbase = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();


    
    std::pair<std::string, std::string> gasTrade = {transaction.utxos(0).owner(0), transaction.utxos(0).assettype()};
    if (flowTxType == ca_algorithm::FlowTxType::FlowInTx)
    {
        //越入 默认X单独支付gas
        // gasTrade = {transaction.utxos(0).owner(0), global::ca::ASSET_TYPE_VOTE};
    }
    else if(flowTxType == ca_algorithm::FlowTxType::FlowOutTx)
    {
        DEBUGLOG("transaction is FlowOut.");
        //越出 默认是本资产类型支付gas
        gasTrade = {transaction.utxos(0).owner(0), transaction.utxos(0).assettype()};
    }

    bool falg = false;
    for (const auto &utxo : transaction.utxos())
    {
        //如果是越入 直接跳过  因为他不会有utxo.gasutxo == 1的情况
        if (!falg && flowTxType == ca_algorithm::FlowTxType::FlowInTx && utxo.vout_size() == 2 && utxo.vin_size() == 0 && transaction.utxos_size() == 1)
        {
            falg = true;
            continue;
        }

        if (utxo.gas() != global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE)
        {
            continue;
        }

        std::string currency = utxo.assettype();
        if (utxo.owner_size() != 0 && !currency.empty())
        {
            gasTrade = {utxo.owner(0), currency};
            DEBUGLOG("addContractInfoCache owner :{}, assetType :{}", utxo.owner(0), currency);
        }
    }


    std::string fromAddr;
    if(!transaction.rlp().empty())
    {
        ethVerify::EthTransaction ethTx;
        dev::bytes rlpBytes = dev::fromHex(transaction.rlp());
        eth_errors e;
        int ret_E = ethVerify::verifyRLP(rlpBytes, e, &ethTx);
        if (ret_E != 0)
        {
            ERRORLOG("verifyETHTransaction failed, ret_E = {}", ret_E);
            return ret_E;
        }
        fromAddr = ethTx.from;
    }else{
        int ret = ca_algorithm::get_call_contract_from_addr(transaction,fromAddr);
        if (ret != 0)
        {
            ERRORLOG("get_call_contract_from_addr fail ret: {}", ret);
            return -1;
        }
    }
    
    

    if(vmType == global::ca::VmType::EVM)
    {
        destAddr = contractOwnerEvmAddress;
        if(destAddr != fromAddr)
        {
            ERRORLOG("fromAddr {}  is not equal to detAddr {} ", fromAddr, destAddr);
            return -3;
        }
        

        EvmHost host(contractDataStorage);
        if(txType == global::ca::TxType::DEPLOY)
        {
            int ret = Evmone::VerifyContractAddress(fromAddr, contractAddress);
            if (ret < 0)
            {
                ERRORLOG("verify contract address fail, ret: {}", ret)
                return ret - 100;
            }
            DEBUGLOG("888Output: {}", code);

            host.code = evm_utils::StringTobytes(code);
            if (code.empty())
            {
                ERRORLOG("fail to convert contract code to hex format");
                return -21;
            }
            // 使用打包者的时间戳，忽略交易体中的blockTimestamp
            int64_t blockTimestamp = evmEnvironment::calculateBlockTimestamp(3);
            if (blockTimestamp < 0)
            {
                return -5;
            }
            DEBUGLOG("777Output: {}", evmc::hex({host.code.data(), host.code.size()}) );
            int64_t blockPrevRandao = evmEnvironment::get_block_prev_randao(transaction);
            if (blockPrevRandao < 0)
            {
                return -6;
            }
            evmc_message message{};

            ret = Evmone::DeployContract(fromAddr, host, message,
                                         contractAddress, blockTimestamp, blockPrevRandao, blockNumber,gasTrade.second);

            if(ret != 0)
            {
                ERRORLOG("VM failed to deploy contract!, ret {}", ret);
                return ret - 100;
            }
            gasCost = host.gas_cost;
            expectedOutput = host.output;
            DEBUGLOG("111Output: {}", expectedOutput);

        }
        else if(txType == global::ca::TxType::CALL)
        {
            evmc::bytes contractCode;
            if (evm_utils::GetContractCode(contractAddress, contractCode) != 0)
            {
                ERRORLOG("fail to get contract code");
                return -2;
            }
            
            host.code = contractCode;

            // 使用打包者的时间戳，忽略交易体中的blockTimestamp
            int64_t blockTimestamp = evmEnvironment::calculateBlockTimestamp(3);
            if (blockTimestamp < 0)
            {
                return -5;
            }

            int64_t blockPrevRandao = evmEnvironment::get_block_prev_randao(transaction);
            if (blockPrevRandao < 0)
            {
                return -6;
            }
            evmc_message message{};
            int ret = Evmone::CallContract(fromAddr, input, host, contractTransfer, contractAddress,
                                       message, blockTimestamp, blockPrevRandao, blockNumber,gasTrade.second);
            if(ret != 0)
            {
                ERRORLOG("VM failed to call contract!, ret {}", ret);
                return ret - 200;
            }
            gasCost = host.gas_cost;
            expectedOutput = host.output;
            std::string validateOut;
            if (flowTxType == ca_algorithm::FlowTxType::FlowInTx)
            {
                ret = Evmone::ValidateMappingTransaction(input, contractAddress, contractOwnerEvmAddress, transaction,host,message,validateOut);
                if (ret != 0)
                {
                    ERRORLOG("ValidateMappingTransaction fail !!!,ret:{}", ret);
                    return -4;
                }
            }
        }

        int ret = Evmone::ContractInfoAdd(host, transaction.hash(), txType, transaction.version(), txInfoJson,
                                    contractPreHashCache_, true);
        if(ret != 0)
        {
            ERRORLOG("ContractInfoAdd fail ret: {}", ret);
            return -4;
        }

        Evmone::invokedContract(host, calledContract);
   
        if(host.contractDataStorage != nullptr) host.contractDataStorage->set(txInfoJson[Evmone::storageKeyForContract]);
        else return -7;
    }

    if (!verifyDirtyContractFlag(transaction.hash(), calledContract))
    {
        ERRORLOG("verifyDirtyContractFlag fail");
        return -7;
    }
    DEBUGLOG("999Output: {}", expectedOutput);
    txInfoJson[Evmone::contractOutputKey] = expectedOutput;
    DEBUGLOG("888Output: {}", txInfoJson.dump(4));
    txInfoJson[Evmone::contractBlockCoinbaseKeyName] = coinbase;
    addContractInfoToCache(transaction.hash(), txInfoJson, transaction.time());

    // 输出单交易Gas消耗日志（测试用）
    DEBUGLOG("Contract exec gas: tx_hash={}, tx_type={}, gas_cost={}", transaction.hash().substr(0, 8),
             txType == global::ca::TxType::DEPLOY ? "DEPLOY" : "CALL", gasCost);

    if (outGasCost != nullptr) {
        *outGasCost = gasCost;
    }

    return 0;
}

void TransactionCache::addContractInfoToCache(const std::string& transactionHash, const nlohmann::json& txInfoJson, const uint64_t& txtime)
{
    std::unique_lock<std::shared_mutex> locker(contractInfoCacheMutex);
    contractInfoCache[transactionHash] = {txInfoJson, txtime};
    return;
}

int TransactionCache::get_contract_info_cache(const std::string& transactionHash, nlohmann::json& txInfoJson)
{
//    std::shared_lock<std::shared_mutex> locker(contractInfoCacheMutex);
    auto found = contractInfoCache.find(transactionHash);
    if (found == contractInfoCache.end())
    {
        return -1;
    }

    txInfoJson = found->second.first;
    return 0;
}

std::string TransactionCache::get_contract_prev_block_hash()
{
    return preContractBlockHash;
}

bool TransactionCache::hasContractPackingPermission(const std::string& addr, uint64_t transactionHeight, uint64_t time)
{
    std::string packingAddr;
    if (calculatePackerByTime(time, packingAddr) != 0)
    {
        return false;
    }
    DEBUGLOG("time: {}, height: {}, packer {}", time, transactionHeight, packingAddr);
    return packingAddr == addr;
}

void TransactionCache::contractBlockNotification(const std::string& blockHash)
{
    if (!preContractBlockHash.empty() && blockHash == preContractBlockHash)
    {
        contractPreBlockWaiter.notify_one();
    }
    ScheduleWaitingContractRetry();
}

void TransactionCache::ScheduleWaitingContractRetry()
{
    bool expected = false;
    if (!waitingRetryScheduled.compare_exchange_strong(expected, true)) return;
    MagicSingleton<TaskPool>::GetInstance()->commitWorkTask([this]() {
        RetryWaitingContractBatches();
        waitingRetryScheduled.store(false);
    });
}

std::string
TransactionCache::get_and_update_contract_pre_hash(const std::string &contractAddress, const std::string &transactionHash,
                                              std::map<std::string, std::string> &contractPreHashCache_)
{
    std::string prevTxHash;
    auto found = contractPreHashCache_.find(contractAddress);
    if (found == contractPreHashCache_.end())
    {
        DBReader dbReader;
        if (dbReader.getLatestUtxoByContractAddr(contractAddress, prevTxHash) != DBStatus::DB_SUCCESS)
        {
            ERRORLOG("GetLatestUtxo of ContractAddr {} fail", contractAddress);
            return "";
        }
        if (prevTxHash.empty())
        {
            return "";
        }
    }
    else
    {
        prevTxHash = found->second;
    }
    contractPreHashCache_[contractAddress] = transactionHash;

    return prevTxHash;
}

void TransactionCache::set_dirty_contract_map(const std::string& transactionHash, const std::set<std::string>& dirtyContract)
{
    std::unique_lock locker(dirtyContractMapMutex);
    uint64_t currentTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    dirtyContractMap[transactionHash]= {currentTime, dirtyContract};

}

bool TransactionCache::get_dirty_contract_map(const std::string& transactionHash, std::set<std::string>& dirtyContract)
{
    auto found = dirtyContractMap.find(transactionHash);
    if(found != dirtyContractMap.end())
    {
        dirtyContract = found->second.second;
        return true;
    }
    
    return false;
}

void TransactionCache::removeExpiredFromDirtyContractMap()
{
    uint64_t nowTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    for(auto iter = dirtyContractMap.begin(); iter != dirtyContractMap.end();)
    {
        if(nowTime >= iter->second.first + 60 * 1000000ull)
        {
            DEBUGLOG("remove txHash:{}", iter->first);
            dirtyContractMap.erase(iter++);
        }
        else
        {
            ++iter;
        }
    }
}

void TransactionCache::addBuildTransaction(const CTransaction &transaction)
{
    std::unique_lock<std::mutex> locker(buildTxsMutex);
    buildTxs.push_back(transaction);
}
const std::list<CTransaction>& TransactionCache::getBuildTransactions()
{
    std::unique_lock<std::mutex> locker(buildTxsMutex);
    return buildTxs;
}
void TransactionCache::clearBuiltTransactions()
{
    std::unique_lock<std::mutex> locker(buildTxsMutex);
    buildTxs.clear();
}

int get_contract_prehash_find_node(uint32_t num, uint64_t nodeSelfHeight, const std::vector<std::string> &pledgeAddr,
                            std::vector<std::string> &node_ids_to_send)
{
    int ret = 0;
    if ((ret = SyncBlock::getSyncNodeSimplified(num, nodeSelfHeight, pledgeAddr, node_ids_to_send)) != 0)
    {
        ERRORLOG("get seek node fail, ret:{}", ret);
        return -1;
    }
    return 0;
}

namespace
{
constexpr uint64_t kMaxWaitingNonceGap = 1024;
constexpr int kContractBatchReady = 0;
constexpr int kContractBatchWaiting = 1;

uint64_t GetContractBatchDeadline(const ContractPackagerMsg& message)
{
    std::vector<uint64_t> transaction_times;
    transaction_times.reserve(message.txmsgreq_size());
    for (const auto& request : message.txmsgreq())
    {
        CTransaction tx;
        if (!tx.ParseFromString(request.txmsginfo().tx())) return 0;
        transaction_times.push_back(tx.time());
    }
    return contract_repack::ContractBatchDeadline(transaction_times);
}

}

int TransactionCache::ClassifyContractBatch(const ContractPackagerMsg& message,
                                            std::vector<std::string>& accounts) const
{
    std::vector<contract_nonce::Entry> entries;
    std::map<std::string, uint64_t> committed;
    std::set<std::string> unique_accounts;
    DBReader db;
    for (const auto& request : message.txmsgreq())
    {
        CTransaction tx;
        if (!tx.ParseFromString(request.txmsginfo().tx()) || tx.utxos_size() == 0 ||
            tx.utxos(0).owner_size() == 0) return -1;
        const std::string address = tx.utxos(0).owner(0);
        if (unique_accounts.insert(address).second)
        {
            uint64_t nonce = 0;
            const auto status = db.getNonceByAddr(address, nonce);
            if (status != DBStatus::DB_SUCCESS && status != DBStatus::DB_NOT_FOUND) return -2;
            committed[address] = nonce;
        }
        entries.push_back({tx.hash(), address, tx.nonce(), tx.time()});
    }
    accounts.assign(unique_accounts.begin(), unique_accounts.end());
    switch (contract_nonce::ClassifyCanonicalBatch(entries, committed, kMaxWaitingNonceGap))
    {
        case contract_nonce::BatchReadiness::kReady: return kContractBatchReady;
        case contract_nonce::BatchReadiness::kWaitingNonce: return kContractBatchWaiting;
        case contract_nonce::BatchReadiness::kNonceConflict: return -3;
        case contract_nonce::BatchReadiness::kInvalidSequence: return -4;
        case contract_nonce::BatchReadiness::kGapLimitExceeded: return -5;
    }
    return -6;
}

int TransactionCache::EnqueueWaitingContractBatch(const ContractPackagerMsg& message,
                                                   const std::vector<std::string>& accounts)
{
    const uint64_t now = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    contract_waiting::Limits limits;
    contract_waiting::Record record;
    record.id = Getsha256Hash(message.SerializeAsString());
    record.message = message;
    record.accounts = accounts;
    record.created_at = now;
    const uint64_t consensus_deadline = GetContractBatchDeadline(message);
    if (!contract_repack::CanStartDeferredRetry(now, consensus_deadline))
    {
        WARNLOG("CONTRACT_WAIT enqueue skipped, reason:insufficient_validity_window, tx_count:{}, deadline:{}, now:{}",
                message.txmsgreq_size(), consensus_deadline, now);
        return -2;
    }
    record.expires_at = std::min(now + limits.ttl_micros, consensus_deadline);
    const auto result = contract_waiting::Store().Enqueue(record, limits);
    if (result != contract_waiting::EnqueueResult::kOk &&
        result != contract_waiting::EnqueueResult::kAlreadyExists)
    {
        ERRORLOG("CONTRACT_WAIT enqueue rejected, id:{}, result:{}", record.id, static_cast<int>(result));
        return -1;
    }
    INFOLOG("CONTRACT_WAIT queued, id:{}, tx_count:{}, account_count:{}, duplicate:{}",
            record.id, message.txmsgreq_size(), accounts.size(),
            result == contract_waiting::EnqueueResult::kAlreadyExists);
    return 0;
}

void TransactionCache::RetryWaitingContractBatches()
{
    std::unique_lock<std::mutex> locker(_threadMutex);
    const uint64_t now = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    contract_waiting::Store store;
    std::vector<std::string> expired;
    if (!store.PruneExpired(now, &expired))
    {
        ERRORLOG("CONTRACT_WAIT prune failed");
        return;
    }
    for (const auto& id : expired) WARNLOG("CONTRACT_WAIT expired, id:{}", id);

    std::vector<contract_waiting::Record> records;
    if (!store.Load(records))
    {
        ERRORLOG("CONTRACT_WAIT restore failed");
        return;
    }
    std::set<std::string> blocked_accounts;
    for (const auto& record : records)
    {
        const uint64_t consensus_deadline = GetContractBatchDeadline(record.message);
        if (!contract_repack::CanStartDeferredRetry(now, consensus_deadline))
        {
            WARNLOG("CONTRACT_WAIT expired by consensus deadline, id:{}, tx_count:{}, deadline:{}, now:{}",
                    record.id, record.message.txmsgreq_size(), consensus_deadline, now);
            store.Remove(record.id);
            continue;
        }
        if (contract_nonce::SharesAccount(record.accounts, blocked_accounts))
        {
            blocked_accounts.insert(record.accounts.begin(), record.accounts.end());
            continue;
        }
        std::vector<std::string> accounts;
        const int readiness = ClassifyContractBatch(record.message, accounts);
        if (readiness == kContractBatchWaiting)
        {
            blocked_accounts.insert(record.accounts.begin(), record.accounts.end());
            continue;
        }
        if (readiness != kContractBatchReady && readiness != -3)
        {
            ERRORLOG("CONTRACT_WAIT permanently rejected, id:{}, reason:{}", record.id, readiness);
            store.Remove(record.id);
            continue;
        }
        {
            std::lock_guard<std::mutex> vrf_lock(_contractPackagerSelectionVrfMutex);
            _contractPackagerSelectionVrf = record.message.selection_vrf();
        }
        std::vector<TxMsgReq> requests(record.message.txmsgreq().begin(), record.message.txmsgreq().end());
        if (!ValidateContractRetryAuthorization(requests))
        {
            ERRORLOG("CONTRACT_WAIT authorization changed, abandoning id:{}", record.id);
            store.Remove(record.id);
            continue;
        }
        const int result = ContractTransaction(requests);
        if (result == 0)
        {
            if (!store.Remove(record.id))
            {
                ERRORLOG("CONTRACT_WAIT remove after success failed, id:{}", record.id);
            }
            else
            {
                INFOLOG("CONTRACT_WAIT resumed successfully, id:{}, tx_count:{}", record.id, requests.size());
            }
        }
        else
        {
            WARNLOG("CONTRACT_WAIT resume deferred, id:{}, result:{}", record.id, result);
            blocked_accounts.insert(record.accounts.begin(), record.accounts.end());
        }
    }
}


int TransactionCache::handleContractPackagerMessage(const std::shared_ptr<ContractPackagerMsg> &msg, const MsgData &msgdata)
{
    std::unique_lock<std::mutex> locker(_threadMutex);
    DEBUGLOG("=== handleContractPackagerMessage START ===");
    DEBUGLOG("Received ContractPackagerMsg, selection_vrf size: {}", msg->selection_vrf().size());
    DEBUGLOG("Received ContractPackagerMsg, txmsgreq size: {}", msg->txmsgreq().size());

    if (msg->txmsgreq().empty()) {
        ERRORLOG("ContractPackagerMsg has no transactions!");
        return -4;
    }

    std::string contractHash;
    std::vector<uint64_t> txTimestamps;
    std::multimap<uint64_t, std::string> tx_hash_time;
    std::string dispatcherAddr;
    DEBUGLOG("Processing {} transactions...", msg->txmsgreq().size());
    for (const TxMsgReq& txMsg : msg->txmsgreq())
    {
        const TxMsgInfo& txMsgInfo = txMsg.txmsginfo();
        CTransaction transaction;
        if (!transaction.ParseFromString(txMsgInfo.tx()))
        {
            ERRORLOG("Failed to deserialize transaction body!");
            return -3;
        }
        contractHash += transaction.hash();
        txTimestamps.push_back(transaction.time());
        tx_hash_time.emplace(transaction.time(), transaction.hash());

        if (transaction.identity().empty())
        {
            ERRORLOG("Contract transaction identity is empty, tx: {}", transaction.hash());
            return -6;
        }

        if (dispatcherAddr.empty())
        {
            dispatcherAddr = transaction.identity();
            DEBUGLOG("Set dispatcherAddr: {}", dispatcherAddr);
        }
        else if (dispatcherAddr != transaction.identity())
        {
            ERRORLOG("ContractPackagerMsg contains multiple dispatchers, first:{}, current:{}, tx:{}",
                     dispatcherAddr, transaction.identity(), transaction.hash());
            return -7;
        }
    }

    // 按排序后的顺序连接hash
    std::string hash_concat;
    DEBUGLOG("Building hash_concat from {} transactions (sorted by timestamp)...", tx_hash_time.size());
    for (const auto& [timestamp, hash] : tx_hash_time) {
        hash_concat += hash;
        DEBUGLOG("  Adding hash: {} (timestamp: {})", hash.substr(0, 16), timestamp);
    }

    if (hash_concat.empty()) {
        ERRORLOG("hash_concat is empty after processing transactions!");
        return -5;
    }

    std::string input_hash = Getsha256Hash(hash_concat);
    DEBUGLOG("Calculated input_hash: {}", input_hash.substr(0, 16));

    //找出时间最晚的交易时间
	auto maxIterator = std::max_element(txTimestamps.begin(), txTimestamps.end());
	uint64_t maxTxTime = 0;
	if (maxIterator != txTimestamps.end()) {
		maxTxTime = *maxIterator;
	}
    DEBUGLOG("Max transaction time: {}", maxTxTime);

    DEBUGLOG("Verifying dispatcher's VRF proof...");
    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    int ret = ContractPackVerifier(input_hash, maxTxTime, defaultAddr, msg->selection_vrf(), dispatcherAddr, kStageContractPackagerHandle);
    if(ret != 0)
    {
        ERRORLOG("ContractPackVerifier failed, ret: {}", ret);
        return -8;
    }
    DEBUGLOG("Dispatcher's VRF proof verified successfully");

    std::vector<std::string> batchAccounts;
    int batchReadiness = ClassifyContractBatch(*msg, batchAccounts);
    if (batchReadiness == kContractBatchReady)
    {
        std::vector<contract_waiting::Record> waitingRecords;
        if (!contract_waiting::Store().Load(waitingRecords))
        {
            ERRORLOG("CONTRACT_WAIT failed to inspect queue head");
            return -9;
        }
        std::set<std::string> waitingAccounts;
        for (const auto& record : waitingRecords)
            waitingAccounts.insert(record.accounts.begin(), record.accounts.end());
        if (contract_nonce::SharesAccount(batchAccounts, waitingAccounts)) batchReadiness = kContractBatchWaiting;
    }
    if (batchReadiness == kContractBatchWaiting)
    {
        return EnqueueWaitingContractBatch(*msg, batchAccounts) == 0 ? 0 : -10;
    }
    if (batchReadiness == -3) batchReadiness = kContractBatchReady;
    if (batchReadiness != kContractBatchReady)
    {
        ERRORLOG("CONTRACT_WAIT batch nonce preflight rejected, reason:{}", batchReadiness);
        return -11;
    }
    
    {
        std::lock_guard<std::mutex> lock(_contractPackagerSelectionVrfMutex);
        _contractPackagerSelectionVrf = msg->selection_vrf();
    }
    DEBUGLOG("Saved dispatcher's VRF proof to TransactionCache, size: {}", msg->selection_vrf().size());
    DEBUGLOG("handleContractPackagerMessage txSize:{}", msg->txmsgreq().size());
    std::vector<TxMsgReq> transmitMessageRequests(msg->txmsgreq().begin(), msg->txmsgreq().end());
    const int contractResult = ContractTransaction(transmitMessageRequests);
    if (contractResult != 0)
    {
        if (contract_repack::ShouldDeferAfterFastRetries(contractResult, contract_repack::kMaxAttempts))
        {
            if (EnqueueWaitingContractBatch(*msg, batchAccounts) != 0)
            {
                ERRORLOG("CONTRACT_REPACK deferred retry persistence failed, tx_count:{}, ret:{}",
                         transmitMessageRequests.size(), contractResult);
                return contractResult;
            }
            INFOLOG("CONTRACT_REPACK fast retries exhausted, batch persisted for deferred retry, tx_count:{}, ret:{}",
                    transmitMessageRequests.size(), contractResult);
            return 0;
        }
        ERRORLOG("CONTRACT_REPACK complete authorized batch processing failed, tx_count:{}, ret:{}",
                 transmitMessageRequests.size(), contractResult);
        return contractResult;
    }

    return 0;
}

int TransactionCache::ContractTransaction(const std::vector<TxMsgReq>& transmitMessageRequests)
{
    int result = -1;
    for (int attempt = 1; attempt <= contract_repack::kMaxAttempts; ++attempt)
    {
        if (attempt > 1)
        {
            ResetContractAttemptState(transmitMessageRequests);
        }

        const auto executionBase = CaptureChainTip();
        if (!executionBase.valid)
        {
            ERRORLOG("CONTRACT_REPACK failed to capture execution base tip, attempt:{}", attempt);
            return -11;
        }

        if (!ValidateContractRetryAuthorization(transmitMessageRequests))
        {
            ERRORLOG("CONTRACT_REPACK dispatcher authorization changed, attempt:{}", attempt);
            return contract_repack::kRetryAuthorizationChanged;
        }

        INFOLOG("CONTRACT_REPACK attempt begin, attempt:{}, max_attempts:{}, tx_count:{}, base_height:{}, base_hash_count:{}",
                attempt, contract_repack::kMaxAttempts, transmitMessageRequests.size(),
                executionBase.height, executionBase.hashes.size());
        result = ContractTransactionAttempt(transmitMessageRequests, executionBase);
        if (result == 0)
        {
            INFOLOG("CONTRACT_REPACK attempt success, attempt:{}, tx_count:{}", attempt, transmitMessageRequests.size());
            return 0;
        }

        WARNLOG("CONTRACT_REPACK attempt failed, attempt:{}, ret:{}, recoverable:{}",
                attempt, result, contract_repack::IsRecoverableBuildResult(result));
        if (!contract_repack::ShouldRetry(result, attempt))
        {
            break;
        }

        const auto retryBackoff = std::chrono::milliseconds(50 * attempt);
        INFOLOG("CONTRACT_REPACK retry backoff, milliseconds:{}, next_attempt:{}",
                retryBackoff.count(), attempt + 1);
        std::this_thread::sleep_for(retryBackoff);
    }

    ResetContractAttemptState(transmitMessageRequests);
    ERRORLOG("CONTRACT_REPACK attempts exhausted or non-recoverable, ret:{}, tx_count:{}",
             result, transmitMessageRequests.size());
    return result;
}

int TransactionCache::ContractTransactionAttempt(
    const std::vector<TxMsgReq>& transmitMessageRequests,
    const contract_repack::ChainTipSnapshot& executionBase) {
    packDispatch packdis;
    std::map<std::string, std::future<int>> txTaskResults_;
    int64_t topTransactionHeight_ = 0;
    std::vector<std::string> authorizedTxHashes;
    authorizedTxHashes.reserve(transmitMessageRequests.size());
    DEBUGLOG("CONTRACT_REPACK execution base captured, height:{}, hash_count:{}",
             executionBase.height, executionBase.hashes.size());

    for (const auto& txMsg : transmitMessageRequests)
    {
        CTransaction transaction;
        if (!transaction.ParseFromString(txMsg.txmsginfo().tx()))
        {
            ERRORLOG("CONTRACT_REPACK batch preflight failed to deserialize transaction");
            return contract_repack::kBatchTransactionRejected;
        }
        authorizedTxHashes.push_back(transaction.hash());
    }
    const auto preflightComparison = contract_repack::CompareAuthorizedTransactionSet(
        authorizedTxHashes, authorizedTxHashes);
    if (preflightComparison != contract_repack::BatchSetComparison::kEqual)
    {
        ERRORLOG("CONTRACT_REPACK batch preflight rejected, reason:{}, authorized:{}",
                 contract_repack::BatchSetComparisonName(preflightComparison), authorizedTxHashes.size());
        return contract_repack::kBatchTransactionSetMismatch;
    }

    std::vector<TxMsgReq> executableRequests;
    DBReader confirmationDb;
    for (const auto& txMsg : transmitMessageRequests)
    {
        CTransaction tx;
        if (!tx.ParseFromString(txMsg.txmsginfo().tx()) || tx.utxos_size() == 0 ||
            tx.utxos(0).owner_size() == 0) return contract_repack::kBatchTransactionRejected;
        uint64_t committedNonce = 0;
        const auto nonceStatus = confirmationDb.getNonceByAddr(tx.utxos(0).owner(0), committedNonce);
        if (nonceStatus != DBStatus::DB_SUCCESS && nonceStatus != DBStatus::DB_NOT_FOUND)
            return contract_repack::kBatchTransactionRejected;
        if (tx.nonce() >= committedNonce)
        {
            executableRequests.push_back(txMsg);
            continue;
        }

        std::string confirmedBlockHash;
        std::string confirmedBlockRaw;
        if (confirmationDb.getBlockHashByTransactionHash(tx.hash(), confirmedBlockHash) != DBStatus::DB_SUCCESS ||
            confirmationDb.getBlockByBlockHash(confirmedBlockHash, confirmedBlockRaw) != DBStatus::DB_SUCCESS)
        {
            ERRORLOG("CONTRACT_REPACK old nonce belongs to a different or unavailable transaction, tx:{}", tx.hash());
            return contract_repack::kBatchTransactionRejected;
        }
        CBlock confirmedBlock;
        if (!confirmedBlock.ParseFromString(confirmedBlockRaw) || confirmedBlock.hash() != confirmedBlockHash)
            return contract_repack::kBatchTransactionRejected;
        int confirmedIndex = -1;
        for (int i = 0; i < confirmedBlock.txs_size(); ++i)
        {
            if (confirmed_exclusion::IsSameConfirmedTransactionBody(tx, confirmedBlock.txs(i)))
            {
                confirmedIndex = i;
                break;
            }
        }
        if (confirmedIndex < 0)
        {
            ERRORLOG("CONTRACT_REPACK confirmed transaction body mismatch, tx:{}", tx.hash());
            return contract_repack::kBatchTransactionRejected;
        }
        std::lock_guard<std::mutex> exclusionLock(m_excludedTransactionsMutex);
        m_excludedTransactions.push_back(tx);
        auto* confirmed = &m_confirmedExclusions.emplace_back();
        *confirmed->mutable_transaction() = tx;
        confirmed->set_confirmed_block_height(confirmedBlock.height());
        confirmed->set_confirmed_block_hash(confirmedBlock.hash());
        confirmed->set_transaction_index(static_cast<uint32_t>(confirmedIndex));
    }
    if (executableRequests.empty())
    {
        INFOLOG("CONTRACT_REPACK entire authorized batch is already confirmed, tx_count:{}", authorizedTxHashes.size());
        std::lock_guard<std::mutex> exclusionLock(m_excludedTransactionsMutex);
        m_excludedTransactions.clear();
        m_confirmedExclusions.clear();
        return 0;
    }

    for (const TxMsgReq& txMsg : executableRequests)
    {
        const TxMsgInfo& txMsgInfo = txMsg.txmsginfo();
        CTransaction transaction;
        if (!transaction.ParseFromString(txMsgInfo.tx()))
        {
            ERRORLOG("Failed to deserialize transaction body!");
            return contract_repack::kBatchTransactionRejected;
        }
        if (txMsgInfo.nodeheight() > topTransactionHeight_)
        {
            topTransactionHeight_ = txMsgInfo.nodeheight();
        }
        DEBUGLOG("tx:{} height {}", transaction.hash(), txMsgInfo.nodeheight());
        DEBUGLOG("set_dirty_contract_map, txHash:{}", transaction.hash());
        set_dirty_contract_map(transaction.hash(), {txMsgInfo.contractstoragelist().begin(), txMsgInfo.contractstoragelist().end()});

        //打包者将收到的交易依赖关系整理
        std::vector<std::string> dependentAddress(txMsgInfo.contractstoragelist().begin(), txMsgInfo.contractstoragelist().end());
        packdis.Add(transaction.hash(),dependentAddress,transaction);

        auto task = std::make_shared<std::packaged_task<int()>>(
                [txMsg, txMsgInfo, transaction] {
                    // std::string dispatcherAddr = transaction.identity();
                    // if(ContractVerifier(transaction) != 0)
                    // {
                    //     ERRORLOG("ContractVerifier fail!!!, txHash:{}", transaction.hash().substr(0,6));
                    //     return -1;
                    // }

                    int ret = handleTransaction(std::make_shared<TxMsgReq>(txMsg), *std::make_unique<CTransaction>());
                    if (ret != 0)
                    {
                        ERRORLOG("handleTransaction fail ret: {}, tx hash : {}", ret, transaction.hash());
                        return ret;
                    }
                    return 0;
                });
        try
        {
            txTaskResults_[transaction.hash()] = task->get_future();
        }
        catch(const std::exception& e)
        {
            std::cerr << e.what() << '\n';
        }
        MagicSingleton<TaskPool>::GetInstance()->commitWorkTask([task](){(*task)();});
    }
    DEBUGLOG("block height will be {}", topTransactionHeight_);
    DEBUGLOG("3333333333333444 HHHHHHHHHH");

    std::map<uint32, std::future<std::pair<int, std::string>>> dependentContractTxTaskResults_;
    std::vector<std::future<std::pair<int, std::string>>> nonDependentContractTxTaskResults;

    std::map<uint32_t, std::map<std::string, CTransaction>> dependentContractTxMap_;
    std::map<std::string, CTransaction> non_dependent_contract_tx_map;
    packdis.GetDependentData(dependentContractTxMap_, non_dependent_contract_tx_map);
    DEBUGLOG("44444444444 HHHHHHHHHH");
    auto processDependencyContract = [&dependentContractTxTaskResults_](const uint32_t N, std::map<std::string, CTransaction> ContractTxs, int64_t blockNumber) {
        auto task = std::make_shared<std::packaged_task<std::pair<int, std::string>()>>(
            [ContractTxs, blockNumber] {
                return MagicSingleton<TransactionCache>::GetInstance()->executeContracts(ContractTxs, blockNumber);
            });

        if (task)
            dependentContractTxTaskResults_[N] =task->get_future();
        else
            return -10;

        MagicSingleton<TaskPool>::GetInstance()->CommitTransactionTask([task]() { (*task)(); });

        return 0; // 返回需要的结果，这里示例返回0
    };

    for(const auto& iter : dependentContractTxMap_)
    {
        DEBUGLOG("dependentContractTxMap_ HHHHHHHHHH first:{}, second size:{}", iter.first, iter.second.size());
        processDependencyContract(iter.first, iter.second, topTransactionHeight_);
    }
    DEBUGLOG("555555555555 HHHHHHHHHH");

    DEBUGLOG("non_dependent_contract_tx_map HHHHHHHHHH size:{}", non_dependent_contract_tx_map.size());
    for(const auto& iter : non_dependent_contract_tx_map)
    {
        std::map<std::string, CTransaction> ContractTxs;
        ContractTxs.emplace(iter.first, iter.second);

        auto task = std::make_shared<std::packaged_task<std::pair<int, std::string>()>>(
        [ContractTxs, topTransactionHeight_]
        {
            return MagicSingleton<TransactionCache>::GetInstance()->executeContracts(ContractTxs, topTransactionHeight_);
        });

        if(task)    nonDependentContractTxTaskResults.push_back(task->get_future());
        else    return -10;

        MagicSingleton<TaskPool>::GetInstance()->commit_block_task([task](){(*task)();});
    }
    DEBUGLOG("66666666666 HHHHHHHHHH");
    std::map<std::string, int> txRes;
    for (auto& res : txTaskResults_)
    {
        if (res.second.valid()) 
        {
            auto retPair = res.second.get();
            txRes[res.first] = retPair;
        }
    }
    DEBUGLOG("77777777777 HHHHHHHHHH");

    const bool transactionVerificationFailed = txRes.size() != executableRequests.size() || std::any_of(
        txRes.begin(), txRes.end(), [](const auto& result) { return result.second != 0; });
    if (transactionVerificationFailed)
    {
        for (auto& pending : dependentContractTxTaskResults_)
        {
            if (pending.second.valid()) (void)pending.second.get();
        }
        for (auto& pending : nonDependentContractTxTaskResults)
        {
            if (pending.valid()) (void)pending.get();
        }
        ERRORLOG("CONTRACT_REPACK batch rejected atomically after transaction verification failure, authorized:{}",
                 authorizedTxHashes.size());
        return contract_repack::kBatchTransactionRejected;
    }

    std::set<uint32_t> isFailureDependent;
    for (auto& res : txRes)
    {
        if(res.second != 0)
        {
            ERRORLOG("isFailureDependent txHash:{}, ret:{}", res.first, res.second);
            for (auto iter = dependentContractTxMap_.begin(); iter != dependentContractTxMap_.end();) 
            {
                if (iter->second.find(res.first) != iter->second.end()) 
                {
                    removeContractInfoCacheRequest(iter->second);
                    isFailureDependent.insert(iter->first);
                    ERRORLOG("verify tx fail !!! delete contract tx:{}", res.first);
                    iter->second.erase(res.first);
                }

                if (iter->second.empty()) 
                {
                    iter = dependentContractTxMap_.erase(iter);
                } 
                else 
                {
                    ++iter;
                }
            }
            if(non_dependent_contract_tx_map.find(res.first) != non_dependent_contract_tx_map.end())
            {
                std::map<std::string, CTransaction> contractTxs;
                contractTxs[res.first] = {};
                removeContractInfoCacheRequest(contractTxs);
            }
        }
    }

    for(const auto& iter : isFailureDependent)
    {
        dependentContractTxTaskResults_.erase(iter);
        processDependencyContract(iter, dependentContractTxMap_[iter], topTransactionHeight_);
    }

    std::map<std::string, int> dependentContextResult;
    for (auto& res : dependentContractTxTaskResults_)
    {
        if (res.second.valid()) 
        {
            auto retPair = res.second.get();
            dependentContextResult[retPair.second] = retPair.first;
        }
    }
    DEBUGLOG("888888888888 HHHHHHHHHH");

    std::map<std::string, int> non_dependent_ctx_result;
    for (auto& res : nonDependentContractTxTaskResults)
    {
        if(res.valid())
        {
            auto retPair = res.get();
            non_dependent_ctx_result[retPair.second] = retPair.first;
        }
        
    }
    DEBUGLOG("999999999999 HHHHHHHHHH");

    const bool contractExecutionFailed =
        std::any_of(dependentContextResult.begin(), dependentContextResult.end(),
                    [](const auto& result) { return result.second != 0; }) ||
        std::any_of(non_dependent_ctx_result.begin(), non_dependent_ctx_result.end(),
                    [](const auto& result) { return result.second != 0; });
    if (contractExecutionFailed)
    {
        ERRORLOG("CONTRACT_REPACK batch rejected atomically after contract execution failure, authorized:{}",
                 authorizedTxHashes.size());
        return contract_repack::kBatchTransactionRejected;
    }

    for (auto& res : dependentContextResult)
    {
        if(res.second != 0)
        {
            // 【新增日志】如果是熔断（ret == -2），打印该分组内所有被丢弃的交易哈希
            if (res.second == -2) {
                for(const auto& iter : dependentContractTxMap_)
                {
                    if(iter.second.find(res.first) != iter.second.end())
                    {
                        std::string dropped_txs;
                        for(const auto& p : iter.second) {
                            dropped_txs += p.first.substr(0, 8) + ", ";
                        }
                        WARNLOG("BLOCK DROPPED (Gas Fuse): Group size={}, Dropped txs: [{}]", iter.second.size(), dropped_txs);
                        break; 
                    }
                }
            }

            ERRORLOG("faildepenDentCTxRes txHash:{}, ret:{}", res.first, res.second);
            for(const auto& iter : dependentContractTxMap_)
            {
                if(iter.second.find(res.first) != iter.second.end())
                {
                    // ClearContractDependencies(iter.second, "dependent contract group execution failed");
                    removeContractsCacheRequest(iter.second);
                }
            }
            ERRORLOG("_ExecuteDependentContractTx fail!!!, txHash:{}", res.first);
        }
    }

    for (auto& res : non_dependent_ctx_result)
    {
        if(res.second != 0)
        {
            ERRORLOG("non_dependent_ctx_result txHash:{}, ret:{}", res.first, res.second);
            std::map<std::string, CTransaction> contractTxs;
            contractTxs[res.first] = {};
            removeContractsCacheRequest(contractTxs);
            ERRORLOG("_ExecuteNonDependentContractTx fail!!!, txHash:{}", res.first);
        }
    }
    
    DEBUGLOG("1010101010101 HHHHHHHHHH");
    const int processRet = ProcessContract(topTransactionHeight_, executionBase, authorizedTxHashes);
    if (processRet != 0)
    {
        ERRORLOG("CONTRACT_REPACK ProcessContract failed, ret:{}", processRet);
        return processRet;
    }
    DEBUGLOG("Packager handleContractPackagerMessage 005 ");
    return 0;
}

int TransactionCache::fetchContractTxPreHash(const std::list<CTransaction>& txs, std::list<std::pair<std::string, std::string>>& contractTxPrevHashList)
{
    std::map<std::string, std::vector<std::pair<std::string, std::string>>> contractTxPreCacheMap;
    for(auto& tx : txs)
	{
        if (global::ca::TxType::DEPLOY == (global::ca::TxType)tx.type())
        {
            continue;
        }
        auto txHash = tx.hash();
        nlohmann::json txStorage;
        if (MagicSingleton<TransactionCache>::GetInstance()->get_contract_info_cache(txHash, txStorage) != 0)
        {
            ERRORLOG("can't find storage of tx {}", txHash);
            return -1;
        }

        for(auto &it : txStorage[Evmone::contractPreHashKey].items())
        {
            contractTxPreCacheMap[txHash].push_back({it.key(), it.value()});
        }
	}
    DBReader dbReader;
    for(auto& iter : contractTxPreCacheMap)
    {
        for(auto& preHashPair : iter.second)
        {
            if(contractTxPreCacheMap.find(preHashPair.second) != contractTxPreCacheMap.end())
            {
                continue;
            }
            std::string dbContractPreHash;
            if (DBStatus::DB_SUCCESS != dbReader.getLatestUtxoByContractAddr(preHashPair.first, dbContractPreHash))
            {
                ERRORLOG("getLatestUtxoByContractAddr fail !!! ContractAddr:{}", preHashPair.first);
                return -2;
            }
            if(dbContractPreHash != preHashPair.second)
            {
                ERRORLOG("dbContractPreHash:({}) != preHashPair.second:({})", dbContractPreHash, preHashPair.second);
                return -3;
            }
            contractTxPrevHashList.push_back(preHashPair);
        }
    }
    return 0;
}

void TransactionCache::removeTransactionFromContractCache(const CTransaction& tx) {
    std::unique_lock<std::mutex> locker(contractCacheMutex);
    _contractCache.erase(
        std::remove_if(_contractCache.begin(), _contractCache.end(),
            [&](TransactionEntity& entity){ // Removed const to match non-const GetTx()
                return entity.GetTx().hash() == tx.hash();
            }),
        _contractCache.end()
    );
}

void TransactionCache::ResetContractAttemptState(const std::vector<TxMsgReq>& transmitMessageRequests)
{
    std::set<std::string> txHashes;
    for (const auto& txMsg : transmitMessageRequests)
    {
        CTransaction tx;
        if (tx.ParseFromString(txMsg.txmsginfo().tx()))
        {
            txHashes.insert(tx.hash());
        }
    }

    {
        std::lock_guard<std::mutex> lock(contractCacheMutex);
        _contractCache.erase(
            std::remove_if(_contractCache.begin(), _contractCache.end(),
                [&txHashes](TransactionEntity& entity) {
                    return txHashes.count(entity.GetTransaction().hash()) != 0;
                }),
            _contractCache.end());
    }
    {
        std::unique_lock<std::shared_mutex> lock(contractInfoCacheMutex);
        for (const auto& hash : txHashes)
        {
            contractInfoCache.erase(hash);
        }
    }
    {
        std::unique_lock<std::shared_mutex> lock(dirtyContractMapMutex);
        for (const auto& hash : txHashes)
        {
            dirtyContractMap.erase(hash);
        }
    }
    {
        std::lock_guard<std::mutex> lock(m_excludedTransactionsMutex);
        m_excludedTransactions.clear();
        m_cumulativeGasBeforeExclusion = 0;
        m_confirmedExclusions.clear();
    }

    INFOLOG("CONTRACT_REPACK attempt state reset, tx_count:{}", txHashes.size());
}

bool TransactionCache::ValidateContractRetryAuthorization(
    const std::vector<TxMsgReq>& transmitMessageRequests)
{
    if (transmitMessageRequests.empty()) return false;

    std::multimap<uint64_t, std::string> txHashTime;
    std::string dispatcherAddr;
    for (const auto& txMsg : transmitMessageRequests)
    {
        CTransaction tx;
        if (!tx.ParseFromString(txMsg.txmsginfo().tx()) || tx.identity().empty()) return false;
        if (dispatcherAddr.empty()) dispatcherAddr = tx.identity();
        else if (dispatcherAddr != tx.identity()) return false;
        txHashTime.emplace(tx.time(), tx.hash());
    }

    std::string hashConcat;
    for (const auto& [timestamp, hash] : txHashTime)
    {
        (void)timestamp;
        hashConcat += hash;
    }
    const std::string inputHash = Getsha256Hash(hashConcat);
    const uint64_t maxTxTime = txHashTime.rbegin()->first;
    const std::string packagerAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    const std::string selectionVrf = GetContractPackagerSelectionVrf();

    const int ret = ContractPackVerifier(
        inputHash, maxTxTime, packagerAddr, selectionVrf, dispatcherAddr, kStageContractPackagerHandle);
    if (ret != 0)
    {
        ERRORLOG("CONTRACT_REPACK dispatcher_vrf reuse rejected, ret:{}, tx_count:{}",
                 ret, transmitMessageRequests.size());
        return false;
    }

    DEBUGLOG("CONTRACT_REPACK dispatcher_vrf reuse accepted, tx_count:{}, max_tx_time:{}",
             transmitMessageRequests.size(), maxTxTime);
    return true;
}

bool TransactionCache::GetAndClearExclusionData(std::vector<CTransaction>& out_txs, uint64_t& out_gas,
                                                std::vector<ConfirmedTransactionProof>& confirmed) {
    std::lock_guard<std::mutex> lock(m_excludedTransactionsMutex);
    if (m_excludedTransactions.empty()) {
        return false;
    }
    out_txs = std::move(m_excludedTransactions);
    m_excludedTransactions.clear();
    out_gas = m_cumulativeGasBeforeExclusion;
    m_cumulativeGasBeforeExclusion = 0;
    confirmed = std::move(m_confirmedExclusions);
    m_confirmedExclusions.clear();
    return true;
}

bool TransactionCache::removeContractInfoCacheRequest(const std::map<std::string, CTransaction>& contractTxs)
{
  std::unique_lock<std::shared_mutex> locker(contractInfoCacheMutex);
  auto it = contractInfoCache.begin();
  while (it != contractInfoCache.end()) {
    if (contractTxs.find(it->first) != contractTxs.end()) {
      DEBUGLOG("txHash:{}", it->first);
      it = contractInfoCache.erase(it); // 删除与 txHash 匹配的元素
    } else {
      ++it;
    }
    }
    return true;
}

bool TransactionCache::removeContractsCacheRequest(const std::map<std::string, CTransaction>& contractTxs) {
    std::unique_lock<std::mutex> locker(contractCacheMutex);
    auto it = _contractCache.begin();
    while (it != _contractCache.end()) {
        if (contractTxs.find(it->GetTransaction().hash()) != contractTxs.end()) {
            it = _contractCache.erase(it); // 删除与 txHash 匹配的元素
        } else {
            ++it;
        }
    }
    return true;
}

int handleSeekContractPreHashRequest(const std::shared_ptr<newSeekContractPreHashReq> &msg, const MsgData &msgdata)
{
    newSeekContractPreHashAck ack;
    ack.set_version(msg->version());
    ack.set_msg_id(msg->msg_id());
    ack.set_self_node_id(MagicSingleton<PeerNode>::GetInstance()->GetSelfId());
    Node node;
	if (!MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(msgdata.fd, node))
	{
        ERRORLOG("locateNodeByFd fail !!!, seekId:{}", node.address);
		return -1;
	}

    DBReader dbReader;
    if(msg->seekroothash_size() >= 200)
    {
        ERRORLOG("msg->seekroothash_size:({}) >= 200", msg->seekroothash_size());
        return -2;
    }
    for(auto& preHashPair : msg->seekroothash())
    {
        std::string dbContractPreHash;
        if (DBStatus::DB_SUCCESS != dbReader.getLatestUtxoByContractAddr(preHashPair.contractaddr(), dbContractPreHash))
        {
            ERRORLOG("getLatestUtxoByContractAddr fail !!!");
            return -3;
        }
        if(dbContractPreHash != preHashPair.roothash())
        {
            DEBUGLOG("dbContractPreHash:({}) != roothash:({}) seekId:{}", dbContractPreHash, preHashPair.roothash(), node.address);
            std::string prevBlockHash;
            if(dbReader.getBlockHashByTransactionHash(dbContractPreHash, prevBlockHash) != DBStatus::DB_SUCCESS)
            {
                ERRORLOG("getBlockHashByTransactionHash failed!");
                return -4;
            }
            std::string blockRaw;
            if(dbReader.getBlockByBlockHash(prevBlockHash, blockRaw) != DBStatus::DB_SUCCESS)
            {
                ERRORLOG("getBlockByBlockHash failed!");
                return -5;
            }
            auto seekContractBlock = ack.add_seekcontractblock();
            seekContractBlock->set_contractaddr(preHashPair.contractaddr());
            seekContractBlock->set_roothash(prevBlockHash);
            seekContractBlock->set_blockraw(blockRaw);
        }
    }

    NetSendMessage<newSeekContractPreHashAck>(node.address, ack, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
    return 0;
}
int handleSeekContractPreHashAcknowledgement(const std::shared_ptr<newSeekContractPreHashAck> &msg, const MsgData &msgdata)
{
    dataMgrPtr.waitDataToAdd(msg->msg_id(),msg->self_node_id(),msg->SerializeAsString());
    return 0;
}

int newSeekContractPreHash(const std::list<std::pair<std::string, std::string>> &contractTxPrevHashList)
{
    DEBUGLOG("newSeekContractPreHash.............");
    uint64_t chainHeight;
    if(!MagicSingleton<BlockHelper>::GetInstance()->getChainHeight(chainHeight))
    {
        DEBUGLOG("getChainHeight fail!!!");
    }
    uint64_t nodeSelfHeight = 0;
    std::vector<std::string> pledgeAddr;
    {
        DBReader dbReader;
        auto status = dbReader.getBlockTop(nodeSelfHeight);
        if (DBStatus::DB_SUCCESS != status)
        {
            DEBUGLOG("getBlockTop fail!!!");

        }
        std::vector<Node> nodelist = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
        for (const auto &node : nodelist)
        {
            bool canReward= VerifyBonusAddr(node.address);

            //int64_t stakeTime = ca_algorithm::GetPledgeTimeByAddr(node.address, global::ca::StakeType::STAKE_TYPE_NODE);
            if (canReward)
            {
                pledgeAddr.push_back(node.address);
            }
        }
    }
    std::vector<std::string> node_ids_to_send;
    if (get_prehash_find_node(pledgeAddr.size(), chainHeight, pledgeAddr, node_ids_to_send) != 0)
    {
        ERRORLOG("get sync node fail");
    }

    if(node_ids_to_send.size() == 0)
    {
        DEBUGLOG("node_ids_to_send {}",node_ids_to_send.size());
        return -2;
    }

    //send_size
    std::string msgId;
    if (!dataMgrPtr.CreateWait(3, node_ids_to_send.size() * 0.8, msgId))
    {
        return -3;
    }

    newSeekContractPreHashReq req;
    req.set_version(ohi::GetVersion());
    req.set_msg_id(msgId);

    for(auto &item : contractTxPrevHashList)
    {
        preHashPair * _hashPair = req.add_seekroothash();
        _hashPair->set_contractaddr(item.first);
        _hashPair->set_roothash(item.second);
        DEBUGLOG("req contractAddr:{}, contractTxHash:{}", item.first, item.second);
    }
    
    for (auto &node : node_ids_to_send)
    {
        if(!dataMgrPtr.AddResNode(msgId, node))
        {
            return -4;
        }
        NetSendMessage<newSeekContractPreHashReq>(node, req, net_com::Compress::kCompressDisabled, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
    }

    std::vector<std::string> ret_datas;
    if (!dataMgrPtr.WaitData(msgId, ret_datas))
    {
        return -5;
    }

    newSeekContractPreHashAck ack;
    std::map<std::string, std::set<std::string>> blockHashMap;
    std::map<std::string, std::pair<std::string, std::string>> testMap;
    for (auto &ret_data : ret_datas)
    {
        ack.Clear();
        if (!ack.ParseFromString(ret_data))
        {
            continue;
        }
        for(auto& iter : ack.seekcontractblock())
        {
            blockHashMap[ack.self_node_id()].insert(iter.blockraw());
            testMap[iter.blockraw()] = {iter.contractaddr(), iter.roothash()};
        }
    }

    std::unordered_map<std::string , int> countMap;
    for (auto& iter : blockHashMap) 
    {
        for(auto& iter_second : iter.second)
        {
            countMap[iter_second]++;
        }
        
    }

    DBReader dbReader;
    std::vector<std::pair<CBlock,std::string>> seekBlocks;
    for (const auto& iter : countMap) 
    {
        double rate = double(iter.second) / double(blockHashMap.size());
        auto test_iter = testMap[iter.first];
        if(rate < global::ca::kByzantineFaultToleranceThreshold)
        {
            ERRORLOG("rate:({}) < global::ca::kByzantineFaultToleranceThreshold, contractAddr:{}, contractTxHash:{}", rate, test_iter.first, test_iter.second);
            continue;
        }

        CBlock block;
        if(!block.ParseFromString(iter.first))
        {
            continue;
        }
        std::string blockStr;
        if(dbReader.getBlockByBlockHash(block.hash(), blockStr) != DBStatus::DB_SUCCESS)
        {
            seekBlocks.push_back({block, block.hash()});
            DEBUGLOG("rate:({}) < global::ca::kByzantineFaultToleranceThreshold, contractAddr:{}, contractTxHash:{}, blockHash:{}", rate, test_iter.first, test_iter.second, block.hash());
            MagicSingleton<BlockHelper>::GetInstance()->add_seek_block(seekBlocks);
        }
    }

    uint64_t timeOut = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp() + 2 * 1000000;
    uint64_t currentTime;
    bool flag;
    do
    {
        flag = true;
        for(auto& it : seekBlocks)
        {
            std::string blockRaw;
            if(dbReader.getBlockByBlockHash(it.second, blockRaw) != DBStatus::DB_SUCCESS)
            {
                flag = false;
                break;
            }
        }
        if(flag)
        {
            DEBUGLOG("find block successfuly ");
            return 0;
        }
        sleep(1);
        currentTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    }while(currentTime < timeOut && !flag);
    return -6;
}

std::string TransactionCache::GetContractPackagerSelectionVrf() const {
    std::lock_guard<std::mutex> lock(const_cast<std::mutex&>(_contractPackagerSelectionVrfMutex));
    return _contractPackagerSelectionVrf;
}

int handleContractPackagerMessage(const std::shared_ptr<ContractPackagerMsg> &msg, const MsgData &msgdata)
{
    MagicSingleton<TransactionCache>::GetInstance()->handleContractPackagerMessage(msg, msgdata);
    return 0;
}
