#include "ca/confirmed_exclusion_policy.h"

#include <algorithm>
#include <set>

#include "utils/sha256.h"

namespace confirmed_exclusion
{
std::string OrderedSetDigest(const std::vector<std::string>& hashes)
{
    std::vector<std::string> ordered = hashes;
    std::sort(ordered.begin(), ordered.end());
    std::string input;
    for (const auto& hash : ordered)
    {
        input += std::to_string(hash.size());
        input.push_back(':');
        input += hash;
    }
    return Getsha256Hash(input);
}

ValidationResult ValidateBindings(
    const std::vector<std::string>& authorized_hashes,
    const std::vector<std::string>& included_hashes,
    const std::vector<Confirmation>& confirmations,
    const std::string& candidate_parent_hash,
    const std::string& proof_candidate_parent_hash,
    const std::string& dispatcher_vrf,
    const std::string& proof_dispatcher_vrf_digest,
    const std::string& proof_original_set_digest,
    const std::string& proof_included_set_digest)
{
    if (confirmations.empty()) return ValidationResult::kEmptyProof;
    const std::set<std::string> authorized(authorized_hashes.begin(), authorized_hashes.end());
    const std::set<std::string> included(included_hashes.begin(), included_hashes.end());
    if (authorized.size() != authorized_hashes.size()) return ValidationResult::kDuplicateAuthorized;
    if (included.size() != included_hashes.size()) return ValidationResult::kDuplicateIncluded;
    std::set<std::string> excluded;
    for (const auto& confirmation : confirmations)
    {
        if (confirmation.transaction_hash.empty() || confirmation.block_hash.empty() ||
            !excluded.insert(confirmation.transaction_hash).second)
            return confirmation.transaction_hash.empty() || confirmation.block_hash.empty()
                       ? ValidationResult::kInvalidConfirmation
                       : ValidationResult::kDuplicateExcluded;
    }
    for (const auto& hash : included)
        if (excluded.count(hash) != 0) return ValidationResult::kIncludedExcludedOverlap;
    std::set<std::string> reconstructed = included;
    reconstructed.insert(excluded.begin(), excluded.end());
    if (reconstructed != authorized) return ValidationResult::kSetMismatch;
    if (candidate_parent_hash.empty() || candidate_parent_hash != proof_candidate_parent_hash ||
        proof_dispatcher_vrf_digest != Getsha256Hash(dispatcher_vrf) ||
        proof_original_set_digest != OrderedSetDigest(authorized_hashes) ||
        proof_included_set_digest != OrderedSetDigest(included_hashes))
        return ValidationResult::kBindingMismatch;
    return ValidationResult::kOk;
}
} // namespace confirmed_exclusion
