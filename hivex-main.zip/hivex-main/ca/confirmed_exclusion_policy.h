#ifndef OPENHIVE_CONFIRMED_EXCLUSION_POLICY_H
#define OPENHIVE_CONFIRMED_EXCLUSION_POLICY_H

#include <cstdint>
#include <string>
#include <vector>

#include "utils/sha256.h"

namespace confirmed_exclusion
{
struct Confirmation
{
    std::string transaction_hash;
    uint64_t block_height = 0;
    std::string block_hash;
    uint32_t transaction_index = 0;
};

enum class ValidationResult
{
    kOk,
    kEmptyProof,
    kDuplicateAuthorized,
    kDuplicateIncluded,
    kDuplicateExcluded,
    kIncludedExcludedOverlap,
    kSetMismatch,
    kBindingMismatch,
    kInvalidConfirmation,
};

std::string OrderedSetDigest(const std::vector<std::string>& hashes);

// Contract verification nodes append top-level verification signatures after
// the transaction hash has been fixed.  Those endorsements are deliberately
// excluded here; every other field (including dispatcher VRF, identity, RLP,
// nonce, UTXOs and user authorization) remains byte-for-byte bound.
template <typename Transaction>
std::string ConfirmedBodyCommitment(Transaction transaction)
{
    transaction.clear_signature();
    return Getsha256Hash(transaction.SerializeAsString());
}

template <typename Transaction>
bool IsSameConfirmedTransactionBody(const Transaction& expected, const Transaction& confirmed)
{
    return !expected.hash().empty() && expected.hash() == confirmed.hash() &&
           ConfirmedBodyCommitment(expected) == ConfirmedBodyCommitment(confirmed);
}

ValidationResult ValidateBindings(
    const std::vector<std::string>& authorized_hashes,
    const std::vector<std::string>& included_hashes,
    const std::vector<Confirmation>& confirmations,
    const std::string& candidate_parent_hash,
    const std::string& proof_candidate_parent_hash,
    const std::string& dispatcher_vrf,
    const std::string& proof_dispatcher_vrf_digest,
    const std::string& proof_original_set_digest,
    const std::string& proof_included_set_digest);
} // namespace confirmed_exclusion
#endif
