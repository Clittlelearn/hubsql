#ifndef OPENHIVE_PENDING_TRANSACTION_DRAFT_H
#define OPENHIVE_PENDING_TRANSACTION_DRAFT_H

#include <cstdint>
#include <string>
#include <vector>

#include "transaction.pb.h"

namespace pending_tx
{
std::string CanonicalCommitment(CTransaction tx);
uint64_t ConsensusDeadline(const CTransaction& tx);
// Finalizes a draft created by the contract filling path after all public
// transaction fields and the transaction hash have been fixed.
bool FinalizeReservedTransaction(const CTransaction& tx);
class DraftGuard
{
public:
    DraftGuard() = default;
    ~DraftGuard();
    DraftGuard(const DraftGuard&) = delete;
    DraftGuard& operator=(const DraftGuard&) = delete;

    bool Begin(const CTransaction& tx, uint64_t confirmed_nonce);
    bool Finalize(const CTransaction& tx);
    uint64_t nonce() const { return nonce_; }

private:
    std::string id_;
    std::string address_;
    std::vector<std::string> utxos_;
    uint64_t nonce_ = 0;
    std::string commitment_;
    bool active_ = false;
};
} // namespace pending_tx
#endif
