#include "ca/confirmed_exclusion_verifier.h"

#include <map>
#include <set>
#include <vector>

#include "ca/confirmed_exclusion_policy.h"
#include "db/db_api.h"

namespace confirmed_exclusion
{
namespace
{
bool Fail(const std::string& reason, std::string* error)
{
    if (error != nullptr) *error = reason;
    return false;
}

bool IsAncestorConfirmation(const CBlock& candidate, const Confirmation& confirmation,
                            const CTransaction& expected, std::string* error)
{
    if (candidate.height() == 0 || confirmation.block_height >= candidate.height())
        return Fail("confirmed height is not below candidate", error);
    DBReader db;
    std::string current_hash = candidate.prevhash();
    while (!current_hash.empty())
    {
        std::string raw;
        if (db.getBlockByBlockHash(current_hash, raw) != DBStatus::DB_SUCCESS)
            return Fail("ancestor block unavailable", error);
        CBlock block;
        if (!block.ParseFromString(raw) || block.hash() != current_hash)
            return Fail("invalid ancestor block", error);
        if (block.height() < confirmation.block_height)
            return Fail("confirmed block is not an ancestor", error);
        if (block.height() == confirmation.block_height)
        {
            if (block.hash() != confirmation.block_hash)
                return Fail("confirmed block hash is on another branch", error);
            if (confirmation.transaction_index >= static_cast<uint32_t>(block.txs_size()))
                return Fail("confirmed transaction index out of range", error);
            const auto& stored = block.txs(static_cast<int>(confirmation.transaction_index));
            if (stored.hash() != confirmation.transaction_hash ||
                !IsSameConfirmedTransactionBody(expected, stored))
                return Fail("confirmed transaction body mismatch", error);
            return true;
        }
        current_hash = block.prevhash();
    }
    return Fail("confirmed block is not reachable from candidate parent", error);
}
} // namespace

std::string SigningPayload(const ExclusionProof& proof)
{
    ExclusionProof unsigned_proof = proof;
    unsigned_proof.clear_packager_signature();
    return unsigned_proof.SerializeAsString();
}

bool VerifyConfirmedProof(const CBlock& candidate,
                          const ExclusionProof& proof,
                          const std::string& dispatcher_vrf,
                          std::string* error)
{
    if (proof.reason_type() != EXCLUSION_ALREADY_CONFIRMED)
        return Fail("wrong exclusion reason type", error);
    if (proof.confirmed_transactions_size() == 0 ||
        proof.confirmed_transactions_size() != proof.excluded_txs_size())
        return Fail("confirmed/excluded transaction count mismatch", error);

    std::vector<std::string> included;
    std::vector<std::string> authorized;
    std::vector<Confirmation> confirmations;
    std::map<std::string, CTransaction> excluded_bodies;
    for (const auto& tx : candidate.txs())
    {
        included.push_back(tx.hash());
        authorized.push_back(tx.hash());
    }
    for (const auto& tx : proof.excluded_txs())
    {
        authorized.push_back(tx.hash());
        if (!excluded_bodies.emplace(tx.hash(), tx).second)
            return Fail("duplicate excluded transaction", error);
    }
    for (const auto& item : proof.confirmed_transactions())
    {
        if (!item.has_transaction()) return Fail("missing confirmed transaction body", error);
        const auto body = excluded_bodies.find(item.transaction().hash());
        if (body == excluded_bodies.end() ||
            !IsSameConfirmedTransactionBody(body->second, item.transaction()))
            return Fail("confirmed transaction does not match excluded set", error);
        confirmations.push_back({item.transaction().hash(), item.confirmed_block_height(),
                                 item.confirmed_block_hash(), item.transaction_index()});
    }
    const auto binding_result = ValidateBindings(
        authorized, included, confirmations, candidate.prevhash(), proof.candidate_parent_hash(),
        dispatcher_vrf, proof.dispatcher_vrf_digest(), proof.original_transaction_set_digest(),
        proof.included_transaction_set_digest());
    if (binding_result != ValidationResult::kOk)
        return Fail("confirmed exclusion binding mismatch: " + std::to_string(static_cast<int>(binding_result)), error);

    for (size_t i = 0; i < confirmations.size(); ++i)
        if (!IsAncestorConfirmation(candidate, confirmations[i],
                                    proof.confirmed_transactions(static_cast<int>(i)).transaction(), error)) return false;
    return true;
}
} // namespace confirmed_exclusion
