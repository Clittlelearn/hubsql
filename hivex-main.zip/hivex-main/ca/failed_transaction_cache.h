/**
 * *****************************************************************************
 * @file        failed_transaction_cache.h
 * @brief       
 * @date        2023-09-27
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef TRAN_STORAGE
#define TRAN_STORAGE

#include <map>
#include <unistd.h>
#include <shared_mutex>

#include "utils/timer.hpp"
#include "ca/txhelper.h"
#include "ca/transaction_cache.h"
#include "pb/transaction.pb.h"
#include "pb/ca_protomsg.pb.h"

/**
 * @brief       失败交易缓存条目
 */
struct FailedTxEntry
{
    TxMsgReq msg;
    uint32_t failCount = 0;
    bool verified = false;  // 验证成功标记
};

/**
 * @brief       
 */
class failedTransactionCache
{
public:
    failedTransactionCache(){ _StartTimer(); };
    ~failedTransactionCache() = default;
    failedTransactionCache(failedTransactionCache &&) = delete;
    failedTransactionCache(const failedTransactionCache &) = delete;
    failedTransactionCache &operator=(failedTransactionCache &&) = delete;
    failedTransactionCache &operator=(const failedTransactionCache &) = delete;

public:
    /**
     * @brief       
     * 
     * @param       height: 
     * @param       msg: 
     * @return      int 
     */
	int Add(uint64_t height,const TxMsgReq& msg);
    
    /**
     * @brief       
     * 
     */
	void _StartTimer();

    /**
     * @brief       
     * 
     */
    void StopTimer() { _timer.Cancel(); }
private:
    /**
     * @brief       
     * 
     * @return      true 
     * @return      false 
     */
    bool _IsEmpty();

    /**
     * @brief       
     * 
     */
	void _Check();
private:
    mutable std::shared_mutex txPendingMutex;
    std::map<uint64_t, std::vector<std::shared_ptr<FailedTxEntry>>> _txPending;
	CTimer _timer;
};

#endif