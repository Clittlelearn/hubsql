#ifndef OPENHIVE_DISPATCH_SNAPSHOT_POLICY_H
#define OPENHIVE_DISPATCH_SNAPSHOT_POLICY_H

#include <string>

namespace dispatch_snapshot
{
inline bool CanRemove(const std::string& snapshot_body,
                      const std::string& current_body,
                      bool handed_to_send_layer)
{
    return handed_to_send_layer && !snapshot_body.empty() && snapshot_body == current_body;
}
} // namespace dispatch_snapshot

#endif
