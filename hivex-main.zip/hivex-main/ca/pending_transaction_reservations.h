#ifndef OPENHIVE_PENDING_TRANSACTION_RESERVATIONS_H
#define OPENHIVE_PENDING_TRANSACTION_RESERVATIONS_H

#include <cstdint>
#include <map>
#include <mutex>
#include <set>
#include <string>
#include <vector>

namespace pending_tx
{
enum class ReserveResult { kOk, kNonceConflict, kUtxoConflict, kInvalidRequest };

class Reservations
{
public:
    ReserveResult Reserve(const std::string& tx_hash, const std::string& address,
                          uint64_t confirmed_nonce, const std::vector<std::string>& input_utxos,
                          uint64_t* nonce_out);
    ReserveResult ReserveExact(const std::string& reservation_id, const std::string& address,
                               uint64_t nonce, const std::vector<std::string>& input_utxos,
                               const std::string& commitment = {});
    bool SetCommitment(const std::string& reservation_id, const std::string& commitment);
    ReserveResult ReserveOrAdoptExact(const std::string& transaction_id, const std::string& address,
                                      uint64_t nonce, const std::vector<std::string>& input_utxos,
                                      const std::string& commitment, std::string* adopted_id);
    bool Release(const std::string& tx_hash);
    bool Confirm(const std::string& tx_hash);
    uint64_t PendingNonce(const std::string& address, uint64_t confirmed_nonce) const;
    std::set<std::string> ReservedUtxos(const std::vector<std::string>& candidates) const;

    static std::string UtxoKey(const std::string& asset_type, const std::string& hash, uint32_t index);

private:
    struct Record { std::string address; uint64_t nonce; std::vector<std::string> utxos; std::string commitment; };
    mutable std::mutex mutex_;
    std::map<std::string, Record> records_;
    std::map<std::string, std::set<uint64_t>> reserved_nonces_;
    std::map<std::string, std::string> reserved_utxos_;
};
} // namespace pending_tx

#endif
