#include "ca/failed_transaction_cache.h" 
#include "db/db_api.h"
#include "transaction.h"

#include "utils/tmp_log.h"
#include "common/task_pool.h"
#include "include/logging.h"

void failedTransactionCache::_StartTimer()
{
	//Notifications for inspections at regular intervals
	_timer.AsyncLoop(2 * 1000, [this](){
        if(!_IsEmpty())
        {
            _Check();
        }
	});
}

bool failedTransactionCache::_IsEmpty()
{
    std::shared_lock<std::shared_mutex> lock(txPendingMutex);
    if(_txPending.empty())
    {
        return true;
    }
    else
    {
        return false;
    }
}

void failedTransactionCache::_Check()
{
    DBReader dbReader;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return;
    }

    std::vector<Node> nodelist = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    std::vector<decltype(_txPending.begin())> deleteTransactionPendingStatus;

    {
        std::unique_lock<std::shared_mutex> lock(txPendingMutex);
        for (auto iter = _txPending.begin(); iter != _txPending.end(); /* no increment */)
        {
            auto txHeight = iter->first;
            uint64_t nodeHeight = 0;
            for (auto &node : nodelist)
            {
                if (node.height >= txHeight)
                {
                    nodeHeight++;
                }
            }

            if (nodeHeight < nodelist.size() * global::ca::kChainHeightPercentile || top < txHeight)
            {
                ++iter;
                continue;
            }

            // 清理已验证成功或失败次数超限的条目
            for (auto txIter = iter->second.begin(); txIter != iter->second.end(); /* no increment */)
            {
                if ((*txIter)->failCount > 5 || (*txIter)->verified)
                {
                    txIter = iter->second.erase(txIter);
                }
                else
                {
                    ++txIter;
                }
            }

            if (top > txHeight + 3)
            {
                deleteTransactionPendingStatus.push_back(iter);
                ++iter;
                continue;
            }

            if (iter->second.empty())
            {
                deleteTransactionPendingStatus.push_back(iter);
                ++iter;
                continue;
            }

            for (auto &entryPtr : iter->second)
            {
                auto transmitMessageCopy = std::make_shared<TxMsgReq>(entryPtr->msg);

                MagicSingleton<TaskPool>::GetInstance()->CommitTransactionTask(
                    [transmitMessageCopy, entryPtr]() {
                        CTransaction tx;
                        int ret = handleTransaction(transmitMessageCopy, tx);

                        if (ret != 0)
                        {
                            entryPtr->failCount++;
                            DEBUGLOG("TTT tx verify <fail!!!> txhash:{}, ret:{}, failCount:{}", tx.hash(), ret, entryPtr->failCount);
                            return;
                        }

                        entryPtr->verified = true;
                        DEBUGLOG("TTT tx verify <success> txhash:{}", tx.hash());
                    });
            }

            ++iter;
        }
    }

    {
        std::unique_lock<std::shared_mutex> lock(txPendingMutex);
        for (auto &iter : deleteTransactionPendingStatus)
        {
            _txPending.erase(iter);
        }
    }
}
	
int failedTransactionCache::Add(uint64_t height, const TxMsgReq& msg)
{
    DEBUGLOG("TTT NodelistHeight discontent, repeat commit tx ,NodeHeight:{}, txUtxoHeight:{}",height, msg.txmsginfo().txutxoheight());
    std::unique_lock<std::shared_mutex> lock(txPendingMutex);
    auto entry = std::make_shared<FailedTxEntry>();
    entry->msg = msg;
    _txPending[height].push_back(entry);
	return 0;
}
