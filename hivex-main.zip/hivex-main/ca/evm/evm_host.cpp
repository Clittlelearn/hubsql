﻿//
// Created by root on 2024/4/30.
//

#include <db_api.h>
#include <utils/contract_utils.h>
#include <precompiles.hpp>
#include <ethash/keccak.hpp>
#include "evm_host.h"
#include "transaction.h"
#include "evm_manager.h"

EvmHost::EvmHost(contractDataContainer *contractDataStorage)
{
    if (contractDataStorage != nullptr)
    {
        this->contractDataStorage = contractDataStorage;
    }
    else
    {
        this->contractDataStorage = nullptr;
    }
}

// Record an account access.
// @param addr  The address of the accessed account.
void EvmHost::recordAccountAccess(const evmc::address &addr) const
{
    if (recorded_account_accesses.empty())
        recorded_account_accesses.reserve(maxRecordedAccountAccesses);

    if (recorded_account_accesses.size() < maxRecordedAccountAccesses)
        recorded_account_accesses.emplace_back(addr);

    auto found = accounts.find(addr);
    if (found != accounts.end())
    {
        if (!found->second.code.empty())
        {
            return;
        }
    }

    DBReader db_reader;
    std::string contractAddress = evm_utils::evm_addr_to_string(addr);

    evmc::bytes code;
    if (evm_utils::GetContractCode(contractAddress, code) < 0)
    {
        ERRORLOG("fail to get contract code");
        return;
    }
    if (!code.empty())
    {
        accounts[addr].set_code(code);
    }
}

int EvmHost::getContractTransfer(uint64_t amount, const std::string &fromAddr, const std::string &toAddr,
                                 std::vector<TransferInfo> &transferInfo)
{
    if (amount > 0)
    {
        for (auto &iter : coinTransfersInProgress)
        {
            if (iter.amount == 0)
            {
                continue;
            }
            if (iter.to == fromAddr)
            {
                if (iter.amount >= amount)
                {
                    iter.amount = iter.amount - amount;
                    transferInfo.emplace_back(iter.from, toAddr, amount);
                    amount = 0;
                    break;
                }
                else
                {
                    if (iter.from != toAddr)
                    {
                        transferInfo.emplace_back(iter.from, toAddr, iter.amount);
                    }
                    amount = amount - iter.amount;
                    iter.amount = 0;
                    uint64_t balance = 0;
                    get_balance_by_utxo(fromAddr, global::ca::ASSET_TYPE_OHI, balance);
                    dbSpendMap[fromAddr] += amount;
                    if (balance < dbSpendMap[fromAddr])
                    {
                        ERRORLOG("fromAddr:{}, balance:{} < amount:{} failed!", fromAddr, balance,
                                 dbSpendMap[fromAddr]);
                        return -1;
                    }
                }
            }
        }
        transferInfo.emplace_back(fromAddr, toAddr, amount);
    }
    return 0;
}

// Returns true if an account exists (EVMC Host method).
bool EvmHost::account_exists(const evmc::address &addr) const noexcept
{
    recordAccountAccess(addr);
    return accounts.count(addr) != 0;
}

evmc::bytes32 EvmHost::get_storage(const evmc::address &addr, const evmc::bytes32 &key) const noexcept
{
    std::string addrStr = evm_utils::evm_addr_to_string(addr);
    std::string keyStr = evmc::hex({key.bytes, sizeof(key.bytes)});
    DEBUGLOG("get_storage called - addr:{}, key:{}", addrStr, keyStr);

    
    EvmHost * host_t = const_cast<EvmHost*>(this);
    host_t->usedInfo.read_count++;
    recordAccountAccess(addr);

    const auto account_iter = accounts.find(addr);
    if (account_iter == accounts.end())
    {
        DEBUGLOG("get_storage - account not found, addr:{}", addrStr);
        return {};
    }

    const auto storage_iter = account_iter->second.storage.find(key);
    if (storage_iter != account_iter->second.storage.end())
    {
        std::string k = evmc::hex({key.bytes, sizeof(key.bytes)});
        auto mptv = account_iter->second.storageRoot->Get(k);
        if (!mptv.empty())
        {
            auto result = evmc::from_hex<evmc::bytes32>(mptv.c_str()).value_or(evmc::bytes32{});
            std::string valueStr = evmc::hex({result.bytes, sizeof(result.bytes)});
            DEBUGLOG("get_storage - found in MPT, addr:{}, key:{}, value:{}", addrStr, keyStr, valueStr);
            return result;
        }

        auto result = storage_iter->second.value;
        std::string valueStr = evmc::hex({result.bytes, sizeof(result.bytes)});
        DEBUGLOG("get_storage - found in storage map, addr:{}, key:{}, value:{}", addrStr, keyStr, valueStr);
        return result;
    }
    else
    {
        std::string k = evmc::hex({key.bytes, sizeof(key.bytes)});
        auto value = account_iter->second.storageRoot->Get(k);
        if (!value.empty())
        {
            auto result = evmc::from_hex<evmc::bytes32>(value.c_str()).value_or(evmc::bytes32{});
            std::string valueStr = evmc::hex({result.bytes, sizeof(result.bytes)});
            DEBUGLOG("get_storage - found in MPT (storage not in map), addr:{}, key:{}, value:{}", addrStr, keyStr, valueStr);
            return result;
        }
    }
    DEBUGLOG("get_storage - not found, returning empty, addr:{}, key:{}", addrStr, keyStr);
    return {};
}

evmc_storage_status
EvmHost::set_storage(const evmc::address &addr, const evmc::bytes32 &key, const evmc::bytes32 &value) noexcept
{
    std::string addrStr = evm_utils::evm_addr_to_string(addr);
    std::string keyStr = evmc::hex({key.bytes, sizeof(key.bytes)});
    std::string valueStr = evmc::hex({value.bytes, sizeof(value.bytes)});
    DEBUGLOG("set_storage called - addr:{}, key:{}, value:{}", addrStr, keyStr, valueStr);

    usedInfo.write_count++;
    recordAccountAccess(addr);

    auto &old = accounts[addr].storage[key];

    evmc_storage_status status{};
    std::string mptk = evmc::hex({key.bytes, sizeof(key.bytes)});
    auto mptv = accounts[addr].storageRoot->Get(mptk);

    if (!mptv.empty())
    {
        old.value = evmc::from_hex<evmc::bytes32>(mptv.c_str()).value_or(evmc::bytes32{});
        std::string oldValueStr = evmc::hex({old.value.bytes, sizeof(old.value.bytes)});
        DEBUGLOG("set_storage - found old value in MPT, addr:{}, key:{}, old_value:{}, new_value:{}", 
                 addrStr, keyStr, oldValueStr, valueStr);
        
        if (old.value != value)
        {
            accounts[addr].storageRoot->Update(evmc::hex({key.bytes, sizeof(key.bytes)}),
                                               evmc::hex({value.bytes, sizeof(value.bytes)}));
            DEBUGLOG("set_storage - updated MPT, addr:{}, key:{}, value:{}", addrStr, keyStr, valueStr);
        }
        else
        {
            DEBUGLOG("set_storage - value unchanged, skipping MPT update, addr:{}, key:{}", addrStr, keyStr);
        }
        old.dirty = true;
        status = EVMC_STORAGE_ADDED;
        DEBUGLOG("set_storage - returning EVMC_STORAGE_ADDED, addr:{}, key:{}", addrStr, keyStr);
        return status;
    }
    else
    {
        DEBUGLOG("set_storage - no old value in MPT, adding new, addr:{}, key:{}, value:{}", 
                 addrStr, keyStr, valueStr);
        std::string mptKey = evmc::hex({key.bytes, sizeof(key.bytes)});
        std::string mptValue = evmc::hex({value.bytes, sizeof(value.bytes)});
        accounts[addr].storageRoot->Update(mptKey, mptValue);
    }

    std::string oldValueStr = evmc::hex({old.value.bytes, sizeof(old.value.bytes)});
    if (old.value == value)
    {
        DEBUGLOG("set_storage - value unchanged, returning EVMC_STORAGE_ASSIGNED, addr:{}, key:{}, value:{}", 
                 addrStr, keyStr, valueStr);
        return EVMC_STORAGE_ASSIGNED;;
    }
    
    if (!old.dirty)
    {
        old.dirty = true;
        if (!old.value)
        {
            status = EVMC_STORAGE_ADDED;
            DEBUGLOG("set_storage - storage added (was empty), addr:{}, key:{}, value:{}", 
                     addrStr, keyStr, valueStr);
        }
        else if (value)
        {
            status = EVMC_STORAGE_MODIFIED;
            DEBUGLOG("set_storage - storage modified, addr:{}, key:{}, old_value:{}, new_value:{}", 
                     addrStr, keyStr, oldValueStr, valueStr);
        }
        else
        {
            status = EVMC_STORAGE_DELETED;
            DEBUGLOG("set_storage - storage deleted (set to zero), addr:{}, key:{}, old_value:{}", 
                     addrStr, keyStr, oldValueStr);
        }
    }
    else
    {
        status = EVMC_STORAGE_ASSIGNED;
        DEBUGLOG("set_storage - storage already dirty, returning EVMC_STORAGE_ASSIGNED, addr:{}, key:{}, value:{}", 
                 addrStr, keyStr, valueStr);
    }

    old.value = value;
    return status;
}

evmc::uint256be EvmHost::get_balance(const evmc::address &addr) const noexcept
{
    EvmHost * host_t = const_cast<EvmHost*>(this);
    host_t->usedInfo.read_count++;
    recordAccountAccess(addr);

    uint64_t amount = 0;
    auto Addr = evm_utils::evm_addr_to_string(addr);
    if (get_balance_by_utxo(Addr, global::ca::ASSET_TYPE_OHI, amount) != 0)
    {
        amount = 0;
    }

    for (auto &iter : coinTransfersInProgress)
    {
        if (iter.to == Addr)
        {
            amount += iter.amount;
        }
    }

    auto found = dbSpendMap.find(Addr);
    if (found != dbSpendMap.end() && found->second <= amount)
    {
        amount -= found->second;
    }

    evmc::uint256be balance = evmc::uint256be{};
    for (std::size_t i = 0; i < sizeof(amount); ++i)
        balance.bytes[sizeof(balance) - 1 - i] = static_cast<uint8_t>(amount >> (8 * i));

    return balance;
}

size_t EvmHost::get_code_size(const evmc::address &addr) const noexcept
{
    EvmHost * host_t = const_cast<EvmHost*>(this);
    host_t->usedInfo.read_count++;
    recordAccountAccess(addr);
    const auto it = accounts.find(addr);
    if (it == accounts.end())
    {
        DEBUGLOG("can't find code of address {}", evm_utils::evm_addr_to_string(addr));
        return 0;
    }
    host_t->usedInfo.input_size += it->second.code.size();

    return it->second.code.size();
}

evmc::bytes32 EvmHost::get_code_hash(const evmc::address &addr) const noexcept
{
    EvmHost * host_t = const_cast<EvmHost*>(this);
    host_t->usedInfo.read_count++;
    
    recordAccountAccess(addr);
    const auto it = accounts.find(addr);
    if (it == accounts.end())
        return {};

    host_t->usedInfo.input_size += it->second.code.size();
    return it->second.codehash;
}

size_t EvmHost::copy_code(const evmc::address &addr, size_t code_offset, uint8_t *buffer_data,
                          size_t buffer_size) const noexcept
{
    recordAccountAccess(addr);
    const auto it = accounts.find(addr);
    if (it == accounts.end())
        return 0;

    const auto &code = it->second.code;

    if (code_offset >= code.size())
        return 0;

    const auto n = std::min(buffer_size, code.size() - code_offset);

    if (n > 0)
        std::copy_n(&code[code_offset], n, buffer_data);
    return n;
}

bool EvmHost::selfdestruct(const evmc::address &addr, const evmc::address &beneficiary) noexcept
{
    recordAccountAccess(addr);
    recorded_selfdestructs.push_back({addr, beneficiary});

    std::string fromAddr = evm_utils::evm_addr_to_string(addr);
    std::string toAddr = evm_utils::evm_addr_to_string(beneficiary);

    evmc::uint256be value = get_balance(addr);
    dev::bytes by2(value.bytes, value.bytes + sizeof(value.bytes) / sizeof(uint8_t));
    uint64_t amount = dev::toUint64(dev::fromBigEndian<dev::u256>(by2));

    for (auto &iter : coinTransfersInProgress)
    {
        if (iter.amount == 0)
        {
            continue;
        }
        if (iter.to == fromAddr)
        {
            amount -= iter.amount;
            iter.to = toAddr;
        }
    }

    DEBUGLOG("fromAddr:{}, toAddr:{}, amount:{}", fromAddr, toAddr, amount);
    coinTransfersInProgress.emplace_back(fromAddr, toAddr, amount);
    return true;
}

evmc::Result EvmHost::call(const evmc_message &msg) noexcept
{


    recordAccountAccess(msg.recipient);
    if (recorded_calls.empty())
    {
        recorded_calls.reserve(max_recorded_calls);
        callInputsRecorded.reserve(max_recorded_calls);  // Iterators will not invalidate.
    }

    if (recorded_calls.size() < max_recorded_calls)
    {
        recorded_calls.emplace_back(msg);
        auto &call_msg = recorded_calls.back();
        if (call_msg.input_size > 0)
        {
            callInputsRecorded.emplace_back(call_msg.input_data, call_msg.input_size);
            const auto &input_copy = callInputsRecorded.back();
            call_msg.input_data = input_copy.data();
        }
    }

    evmc_result evmcSuccessResult = evmc::make_result(EVMC_SUCCESS, msg.gas, 0, 0, 0);
    evmc_result evmc_failure_outcome = evmc::make_result(EVMC_FAILURE, msg.gas, 0, 0, 0);

    auto found = std::find_if(recorded_selfdestructs.begin(), recorded_selfdestructs.end(),
                              [msg](const selfDestructRecord &item) {

                                  if (item.selfdestructed == msg.code_address)
                                  {
                                      return true;
                                  }
                                  return false;
                              });
    if (found != recorded_selfdestructs.end())
    {
        DEBUGLOG("Contract selfdestructs addr:{}", evm_utils::evm_addr_to_string(found->selfdestructed));
        return evmc::Result{evmc_failure_outcome};
    }


    dev::bytes by2(msg.value.bytes, msg.value.bytes + sizeof(msg.value.bytes) / sizeof(uint8_t));
    uint64_t amount = dev::toUint64(dev::fromBigEndian<dev::u256>(by2));
    std::string fromAddr = evm_utils::evm_addr_to_string(msg.sender);
    std::string toAddr = evm_utils::evm_addr_to_string(msg.code_address);

    std::string input = evmc::hex({msg.input_data, msg.input_size});
    
    if (msg.kind == EVMC_CREATE)
    {
        ++nonceCache;
        // 兼容以太坊合约地址生成：keccak256(rlp([sender, nonce])) 末20字节
        std::string ethAddr = evm_utils::GenerateContractAddrEth(fromAddr, nonceCache);
        std::string contractAddress = evm_utils::ToChecksumAddress(ethAddr);
		return createContract(msg, amount, fromAddr, contractAddress);

    }
    else if (msg.kind == EVMC_CREATE2)
    {
        ++nonceCache;
        std::string contractAddress = calculateCreate2Address(msg);
        return createContract(msg, amount, fromAddr, contractAddress);

    }

    std::vector<TransferInfo> ongoingTransfer;
    if (getContractTransfer(amount, fromAddr, toAddr, ongoingTransfer) != 0)
    {
        return evmc::Result{evmc_failure_outcome};
    }

    coinTransfersInProgress.insert(coinTransfersInProgress.end(), ongoingTransfer.begin(), ongoingTransfer.end());

    if (msg.input_size <= 0)
    {
        DEBUGLOG("empty input data, sender: {}, code_address: {}", fromAddr, toAddr);
        return evmc::Result{evmcSuccessResult};
    }


    if (auto precompiledOutcome = evmone::state::call_precompile(EVMC_MAX_REVISION,
                                                                 msg); precompiledOutcome.has_value())
    {
        return std::move(*precompiledOutcome);
    }


    std::string contractAddress = evm_utils::evm_addr_to_string(msg.code_address);
    evmc::bytes code;
    bool new_contract = false;
    auto codeFound = createdContract.find(contractAddress);
    if (codeFound != createdContract.end())
    {
        code = evm_utils::StringTobytes(codeFound->second);
        new_contract = true;
    }
    else
    {
        int foundResult = evm_utils::GetContractCode(contractAddress, code);
        if (foundResult > 0)
        {
            return evmc::Result{evmcSuccessResult};
        }
        else if (foundResult < 0)
        {
            ERRORLOG("fail to get contract code");
            return evmc::Result{evmc_failure_outcome};
        }
        else
        {
            if (code.empty())
            {
                ERRORLOG("contract code is empty");
                return evmc::Result{evmc_failure_outcome};
            }
        }
    }
    bool loadedContract = loadContract.find(contractAddress) != loadContract.end();

    if (msg.kind == EVMC_CALL && !new_contract && !loadedContract)
    {
        DEBUGLOG("EVMC_CALL:");
        std::string rootHash;
        int ret = fetchContractRootHash(contractAddress, rootHash, contractDataStorage);
        if (ret != 0)
        {
            return evmc::Result{evmc_failure_outcome};
        }
        auto found = accounts.find(msg.recipient);
        bool trie_initialized = !found->second.storageRoot->contractAddr.empty();
        if (found == accounts.end() || !trie_initialized)
        {
            this->accounts[msg.recipient].CreateTrie(rootHash, contractAddress, contractDataStorage);
        }
		loadContract.insert(contractAddress);
    }
    else if (msg.kind == EVMC_DELEGATECALL)
    {
        DEBUGLOG("EVMC_DELEGATECALL:");
    }
    struct evmc_vm *pvm = evmc_create_evmone();
    if (!pvm)
    {
        return evmc::Result{evmc_failure_outcome};
    }
    if (!evmc_is_abi_compatible(pvm))
    {
        return evmc::Result{evmc_failure_outcome};
    }
    evmc::VM vm{pvm};

    evmc::Result re = vm.execute(*this, EVMC_MAX_REVISION, msg, code.data(), code.size());
    DEBUGLOG("ContractAddress: {} , Result: {}", contractAddress, re.status_code);
    if (re.status_code != EVMC_SUCCESS)
    {
        ERRORLOG("Evmone execution failed!");
        auto strOutput = std::string_view(reinterpret_cast<const char *>(re.output_data), re.output_size);
        DEBUGLOG("Output:   {}\n", strOutput);
        return re;
    }
    std::string strOutput = std::move(evmc::hex({re.output_data, re.output_size}));
    DEBUGLOG("Output:   {}\n", strOutput);
    return re;
}

evmc::Result EvmHost::createContract(const evmc_message &msg, uint64_t amount, const std::string &fromAddr,
                                     const std::string &contractAddress)
                                     {
    evmc_result evmcSuccessResult = evmc::make_result(EVMC_SUCCESS, msg.gas, 0, 0, 0);
    evmc_result evmc_failure_outcome = evmc::make_result(EVMC_FAILURE, msg.gas, 0, 0, 0);
    if (amount >= 0)
    {
        std::vector<TransferInfo> ongoingTransfer;
        if (getContractTransfer(amount, fromAddr, contractAddress, ongoingTransfer) != 0)
        {
            return evmc::Result{evmc_failure_outcome};
        }
        coinTransfersInProgress.insert(coinTransfersInProgress.end(), ongoingTransfer.begin(), ongoingTransfer.end());
    }

    std::string runtimeCode;
    evmc_message createMessage = msg;
    createMessage.recipient = evm_utils::convertStringToEvmAddress(contractAddress);
    accounts[createMessage.recipient].CreateTrie("", evm_utils::evm_addr_to_string(createMessage.recipient));
    int result = Evmone::executeSynchronouslyWithEvmone(createMessage, {createMessage.input_data, createMessage.input_size}, *this, runtimeCode);
    if (result != 0)
    {
        return evmc::Result{evmc_failure_outcome};
    }
    createdContract[contractAddress] = runtimeCode;
    evmcSuccessResult.create_address = evm_utils::convertStringToEvmAddress(contractAddress);
    auto converted_code_result = evmc::from_hex(runtimeCode);
    if(!converted_code_result.has_value())
    {
        ERRORLOG("fail to convert code to hex , code: {}", runtimeCode);
        return evmc::Result{evmc_failure_outcome};
    }
    accounts[createMessage.recipient].set_code(converted_code_result.value());
    return evmc::Result{evmcSuccessResult};
}


evmc_tx_context EvmHost::get_tx_context() const noexcept
{
    return tx_context;
}

evmc::bytes32 EvmHost::get_block_hash(int64_t block_number) const noexcept
{
    recorded_blockhashes.emplace_back(block_number);
    return block_hash;
}

void EvmHost::emit_log(const evmc::address &addr, const uint8_t *data, size_t data_size, const evmc::bytes32 topics[],
                       size_t topics_count) noexcept
{
    recorded_logs.push_back({addr, {data, data_size}, {topics, topics + topics_count}});
}

evmc_access_status EvmHost::access_account(const evmc::address &addr) noexcept
{
    const auto already_accessed =
            std::find(recorded_account_accesses.begin(), recorded_account_accesses.end(), addr) !=
            recorded_account_accesses.end();

    recordAccountAccess(addr);

    using namespace evmc;
    if (addr >= 0x0000000000000000000000000000000000000001_address &&
        addr <= 0x0000000000000000000000000000000000000009_address)
        return EVMC_ACCESS_WARM;

    return already_accessed ? EVMC_ACCESS_WARM : EVMC_ACCESS_COLD;
}

evmc_access_status EvmHost::access_storage(const evmc::address &addr, const evmc::bytes32 &key) noexcept
{
    auto &value = accounts[addr].storage[key];
    const auto access_status = value.access_status;
    value.access_status = EVMC_ACCESS_WARM;
    return access_status;
}

/// @copydoc evmc_host_interface::get_transient_storage
evmc::bytes32 EvmHost::get_transient_storage(const evmc::address &addr, const evmc::bytes32 &key) const noexcept
{
    return {};
}

/// @copydoc evmc_host_interface::set_transient_storage
void
EvmHost::set_transient_storage(const evmc::address &addr, const evmc::bytes32 &key, const evmc::bytes32 &value) noexcept
{

}

std::string EvmHost::calculateCreate2Address(const evmc_message& message) noexcept
{
    static constexpr uint8_t PREVENT_COLLISION_CONSTANT = 0xff;
    static constexpr size_t EVM_ADDRESS_SIZE = 20;
    static constexpr size_t createSaltSize = 32;
    static constexpr size_t kKeccakHashSize = 32;
    static constexpr size_t creationSeedSize = sizeof PREVENT_COLLISION_CONSTANT + EVM_ADDRESS_SIZE + createSaltSize + kKeccakHashSize;

    uint8_t creationSeed[creationSeedSize] = {0};

    creationSeed[0] = PREVENT_COLLISION_CONSTANT;
    uint32_t offset = sizeof PREVENT_COLLISION_CONSTANT;

    std::memcpy(creationSeed + offset, message.sender.bytes, EVM_ADDRESS_SIZE);
    offset += EVM_ADDRESS_SIZE;

    std::memcpy(creationSeed + offset, message.create2_salt.bytes, createSaltSize);
    offset += createSaltSize;

    auto  initCodeHash = ethash::keccak256(message.input_data, message.input_size);
    std::memcpy(creationSeed + offset, initCodeHash.bytes, kKeccakHashSize);

     static constexpr size_t evmAddrOffset = kKeccakHashSize - EVM_ADDRESS_SIZE;
    evmc_address address = {0};
    auto addressBase = ethash::keccak256(creationSeed,creationSeedSize);
    std::memcpy(address.bytes, addressBase.bytes + evmAddrOffset, sizeof address);

    std::string contractAddress = evm_utils::evm_addr_to_string(address);
    return contractAddress;
}
