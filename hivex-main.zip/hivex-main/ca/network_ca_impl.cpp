/**
 * *****************************************************************************
 * @file        network_ca_impl.cpp
 * @brief       CA layer implementation of network interface (NET-017)
 * @date        2026-06-25
 * @copyright   mm
 * *****************************************************************************
 */
#include "network_ca_impl.h"
#include "algorithm.h"
#include "bonus_addr_cache.h"
#include "dispatchtx.h"
#include "utils/magic_singleton.h"

int NetworkCAImpl::GetCanBeRevokeAssetType(std::string& assetType) {
    return ca_algorithm::GetCanBeRevokeAssetType(assetType);
}

int NetworkCAImpl::getBonusAmount(const std::string& bonusAddr, uint64_t& delegateAmount) {
    return MagicSingleton<ohi::ca::BonusAddrCache>::GetInstance()->getAmount(bonusAddr, delegateAmount);
}

void NetworkCAImpl::RecordDisconnect(const std::string& addr) {
    MagicSingleton<NodeSlashTracker>::GetInstance()->recordDisconnect(addr);
}

// Auto-register the implementation when this file is loaded
namespace {
    struct NetworkCAImplRegistrar {
        NetworkCAImplRegistrar() {
            NetworkCAInterfaceRegistry::Register(std::make_shared<NetworkCAImpl>());
        }
    };
    static NetworkCAImplRegistrar registrar;
}
