﻿/**
 * *****************************************************************************
 * @file        algorithm.h
 * @brief       
 * @date        2023-09-25
 * @copyright   mm
 * *****************************************************************************
 */

#ifndef CRYPTO_ALGORITHM_HEADER_GUARD
#define CRYPTO_ALGORITHM_HEADER_GUARD

#include <nlohmann/json.hpp>
#include <optional>
#include "global.h"
#include "db/db_api.h"
#include "txhelper.h"
namespace ca_algorithm
{
/**
 * @brief       Get the Abnormal Sign Addr List By Period object
 * 
 * @param       curTime: 
 * @param       abnormal_addr_list: 
 * @param       addr_sign_cnt: 
 * @return      int 
 */
int fetchAbnormalSignAddrListByPeriod(uint64_t &curTime, std::map<std::string, double> &addr_percent, std::unordered_map<std::string, uint64_t> & addrSignCount);

/**
 * @brief       Obtain the time (nanosecond) of pledge transaction with pledge limit of more than 500 according to the addressGet the Pledge Time By Addr object
                When the return value is less than 0, the function execution fails
                Equal to 0 means no pledge
                Greater than 0 means pledge time

 * 
 * @param       addr: 
 * @param       stakeType: 
 * @param       db_reader_ptr: 
 * @return      int64_t 
 */
int64_t GetPledgeTimeByAddr(const std::string &addr, global::ca::StakeType stakeType, DBReader *dbReaderInstance = nullptr);
/**
 * @brief       
 * 
 * @param       tx: 
 * @return      std::string 
 */
std::string calculateTransactionHash(CTransaction tx);
std::string CalculateSlashEvidenceHash(const std::string &evidenceData);
std::string BuildSlashPunishmentId(const std::string &targetAddr,
                                   const std::string &violationType,
                                   uint32_t penaltyLevel,
                                   const std::string &evidenceRefs);
int ValidateSlashEvidenceTx(const CTransaction &tx, DBReader *dbReaderInstance = nullptr);
int ValidateSlashPunishmentTx(const CTransaction &tx, DBReader *dbReaderInstance = nullptr);
/**
 * @brief       
 * 
 * @param       block: 
 * @return      std::string 
 */
std::string CalcBlockHash(CBlock block);

/**
 * @brief       
 * 
 * @param       cblock: 
 * @return      std::string 
 */
std::string calculateBlockMerkle(CBlock cblock);

/**
 * @brief       
 * 
 * @param       tx: 
 * @param       missingBlockProtocolEnabled: 
 * @param       missing_utxo: 
 * @return      int 
 */
int doubleSpendCheck(const CTransaction &tx, bool missingBlockProtocolEnabled, std::string* missing_utxo = nullptr);

/**
 * @brief       Verification transaction
 * 
 * @param       tx: 
 * @return      int 
 */
int memoryVerificationTransactionRequest(const CTransaction &tx, global::ca::SaveType saveType = global::ca::SaveType::Unknow,
                                         std::optional<uint64_t> expectedNonce = std::nullopt);

/**
 * @brief       Verification transaction
 * 
 * @param       tx: 
 * @param       tx_height: 
 * @param       missingBlockProtocolEnabled: 
 * @param       verify_abnormal: 
 * @return      int 
 */
int verifyTransactionRequest(const CTransaction &tx, uint64_t txHeight, bool enableMissingBlockRequest = false,
                             bool checkAnomaly = true, std::optional<uint64_t> expectedNonce = std::nullopt);

/**
 * @brief       
 * 
 * @param       block: 
 * @return      int 
 */
int verifyPreSaveBlock_(const CBlock &block);
/**
 * @brief       
 * 
 * @param       sign: 
 * @param       serHash: 
 * @return      int 
 */
int VerifySign(const CSign & sign, const std::string & serHash);
/**
 * @brief       Check block
 * 
 * @param       block: 
 * @param       isVerify: 
 * @param       blockStatus: 
 * @return      int 
 */
int memVerifyBlock(const CBlock& block, bool isVerify = true, BlockStatus* blockStat = nullptr, global::ca::SaveType saveType = global::ca::SaveType::Unknow);

/**
 * @brief
 * 
 * @param       isContractVerified: 
 * @param       calledContract: 
 * @return      bool 
 */
bool verifyDirtyContract(const std::vector<std::string> &isContractVerified, const std::vector<std::string> &calledContract);

/**
 * @brief       Verify the contract storage data
 * 
 * @param       txInfo: 
 * @param       expected_tx_info: 
 * @return      int 
 */
int verify_contract_storage(const nlohmann::json& txInfo, const nlohmann::json& expected_tx_info);
/**
 * @brief
 * 
 * @param       ContractTxs: 
 * @param       dependencyTransactionRequest: 
 * @param       block:
 * @param       blockData:
 * @return      int 
 */
int verifyContractDepsTx(const std::map<std::string, CTransaction>& ContractTxs, std::map<std::string,std::vector<std::string>>& dependencyTransactionRequest, const CBlock &block, nlohmann::json& blockData, global::ca::SaveType saveType = global::ca::SaveType::Unknow);

/**
 * @brief       Verify that the contract block is correct
 * 
 * @param       block: 
 * @return      int 
 */
int verifyContractBlock(const CBlock &block, global::ca::SaveType saveType = global::ca::SaveType::Unknow);
/**
 * @brief       Check block
 * 
 * @param       block: 
 * @param       enableMissingBlockRequest: 
 * @param       checkAnomaly: 
 * @param       isVerify: 
 * @param       blockStatus: 
 * @param       msg: 
 * @return      int 
 */
int VerifyBlock(const CBlock &block, bool enableMissingBlockRequest = false, bool checkAnomaly = true, bool isVerify = true, BlockStatus* blockStatus = nullptr,BlockMsg* msg = nullptr, global::ca::SaveType saveType = global::ca::SaveType::Unknow);
/**
 * @brief       
 * 
 * @param       dbWriter: 
 * @param       block: 
 * @param       saveType: 
 * @param       computeMeanValue: 
 * @return      int 
 */
int SaveBlock(DBReadWriter &dbWriter, const CBlock &block, global::ca::SaveType saveType, global::ca::blockMean computeMeanValue);

/**
 * @brief       
 * 
 * @param       dbWriter: 
 * @param       blockHash: 
 * @return      int 
 */
int DeleteBlock(DBReadWriter &dbWriter, const std::string &blockHash);

/**
 * @brief       When calling, pay attention not to have too much difference between the height and the maximum height. The memory occupation is too large, and the process is easy to be killed
                Rollback to specified height
 * 
 * @param       height: 
 * @return      int 
 */
int RollBackToHeight(uint64_t height);

/**
 * @brief       Rollback specified hash
 * 
 * @param       blockHash: 
 * @return      int 
 */
int rollback_by_hash(const std::string &blockHash);

/**
 * @brief       Calculate the pledge rate and obtain the rate of return
 * 
 * @param       curTime: 
 * @param       bonusAddr: 
 * @param       vlaues: 
 * @param       isDisplay: 
 * @return      int 
 */
int CalcBonusValue(uint64_t &curTime, const std::string &bonusAddr,std::map<std::string, uint64_t> & vlaues,bool isDisplay = false);
/**
 * @brief       Get the Inflation Rate object
 *
 * @param       curTime:
 * @param       annualizedRate:
 * @return      int
 */
int GetAnnualizedRate(const uint64_t &curTime,double &annualizedRate);

/**
 * @brief       Map staking rate to k value for inflation calculation
 * 
 * @param       stakingRate: Staking rate percentage (10% to 100%)
 * @return      double: k value (1 to 20)
 */
double mapStakingRateToK(double stakingRate);

/**
 * @brief       Calculate weekly inflation rates using exponential decay
 * 
 * @param       k: Decay parameter
 * @param       totalWeeks: Total number of weeks (default 520 = 10 years)
 * @param       startRate: Initial inflation rate (default 7.0%)
 * @param       endRate: Final inflation rate (default 1.5%)
 * @return      std::vector<double>: Weekly inflation rates
 */
std::vector<double> calculateInflationRates(double k, int totalWeeks = 520, double startRate = 7.0, double endRate = 1.5);

/**
 * @brief       Calculate annualized rates based on inflation rates and staking rate
 * 
 * @param       inflationRates: Vector of inflation rates
 * @param       stakingRate: Current staking rate percentage
 * @return      std::vector<double>: Annualized rates
 */
std::vector<double> calculateAnnualizedRates(const std::vector<double>& inflationRates, double stakingRate);

/**
 * @brief       Get current annualized rate using new inflation model
 * 
 * @param       curTime: Current timestamp
 * @param       stakingRate: Current network staking rate
 * @param       annualizedRate: Output annualized rate
 * @return      int: 0 on success, negative on error
 */
int GetNewAnnualizedRate(const uint64_t &curTime, double stakingRate, double &annualizedRate);

/**
 * @brief       Get current network staking rate
 * 
 * @param       stakingRate: Output current staking rate percentage
 * @return      int: 0 on success, negative on error
 */
int GetNetworkStakingRate(const uint64_t &curTime, double &stakingRate);

/**
 * @brief       Get the Sum Hash Ceiling Height object
 * 
 * @param       height: 
 * @return      uint64_t Ceiling Height
 */
uint64_t calculateSumHashCeilingHeight(uint64_t height);
/**
 * @brief       Get the Sum Hash Floor Height object
 * 
 * @param       height: 
 * @return      uint64_t Floor Height
 */
uint64_t get_sum_hash_floor_height(uint64_t height);
/**
 * @brief       
 * 
 * @param       blockHeight: 
 * @param       dbWriter: 
 * @return      int 
 */
int calculateHeightsSumHash(uint64_t blockHeight, DBReadWriter &dbWriter);

/**
 * @brief       
 * 
 * @param       blockHeight: 
 * @param       dbWriter: 
 * @return      int 
 */
int recalculate_heights_sum_hash(const uint64_t newTop, const uint64_t hashHeightSum, std::string& sumHash, uint64_t blockHeight, DBReadWriter &dbWriter);


/**
 * @brief       
 * 
 * @param       blockHeight: 
 * @param       dbWriter: 
 * @param       backHash: 
 * @return      int 
 */
int calculateSumHashOf1000Heights(uint64_t blockHeight, DBReadWriter &dbWriter, std::string& backHash);

/**
 * @brief       
 * 
 * @param       startHeight: 
 * @param       endHeight: 
 * @param       dbWriter: 
 * @param       sumHash: 
 * @return      true 
 * @return      false 
 */
bool calculate_height_sum_hash(uint64_t startHeight, uint64_t endHeight, DBReadWriter &dbWriter, std::string &sumHash);
/**
 * @brief       Get the Commission Percentage object
 * 
 * @param       addr: 
 * @param       commissionRateRet: Commission Percentage
 * @return      int 0 success
 */
int GetCommissionPercentage(const std::string& addr, double& commissionRateRet);
/**
 * @brief       Get the starting address for executing the contract
 * 
 * @param       transaction:
 * @param       fromAddr:
 * @return      int 0 success
 */
int get_call_contract_from_addr(const CTransaction& transaction, std::string& fromAddr);

int GetVitrualDelegateInfo(const std::string &from, const std::string &toAddr,
												   const std::string &strInput, uint64_t height,
												   const uint64_t contractTransfer, const std::string &to, std::string& outPut);

void GetAddrType(std::string& addr, std::vector<std::pair<std::string, bool>> &vecAddrType);

//根据合约地址获取资产类型
int GetAsseTypeByContractAddr(const std::string& contractAddr, std::string& assetType);

//获取当前可用投票的资产
int GetVoteAssetType(std::map<std::string, TxHelper::VoteInfo>& voteAsset);

int AssetTypeIsOHI(const std::string& assetType);

//获取资产类型是否可用
int GetAssetTypeIsValid(const std::string& assetType, TxHelper::ProposalInfo* proposalInfo = nullptr);

void GetAllMappedAssets();
int GetAssetRate(const std::string& contractAddr, std::string& ExchangeRate);
//获取所有可用资产
int fetchAvailableAssetType(std::map<std::string, TxHelper::ProposalInfo>& assetMap);
//获取所有不可用的资产
int GetUnavailableAssetType(std::vector<std::string>& assetList);

//判断当前资产是否可以撤销
int canBeRevoked(const std::string& assetType);

int CheckProposaInfo(std::string& rate, std::string& contractAddr, std::string& crossChainInvestmentContractAddr, global::ca::CrossChainTxType taskType, uint64_t minVote, std::string& assetName, std::string& peerChainTokenAddr);

//获取 赞成票数量，反对票数量
int GetVoteNum(DBReadWriter& db, const std::string &assetType, uint64_t &approveNum, uint64_t &againstNum);
//检查是否重复投票
int CheckForDuplicateVotes(const std::string &assetType, const std::string addr);
//票数量+1，并添加投票ID   
int addVoteCount(DBReadWriter& db, const std::string &assetType, const int voteType, const std::string& addr, const uint64_t& voteNumber);
//票数量-1，并删除投票ID
int subVoteNum(DBReadWriter& db, const std::string &assetType, const int voteType, const std::string& addr, const uint64_t& voteNumber);
//检验投票交易info
int CheckVoteTxInfo(const std::string& voteHash, uint32_t voteTxType, int pollType, uint64_t currentTime, global::ca::SaveType saveType = global::ca::SaveType::Unknow);
//根据资产类型获取跨链投资合约地址
int GetCrossChainInvestmentContractAddrByAssetType(const std::string& assetType, std::string &crossChainInvestmentContractAddr);

int GetProposalInfo(const std::string& assetType, TxHelper::ProposalInfo& proposalInfo);

//判断当前资产类型列表是否为空 1 空 0 非空 负数错误
int AssetTypeListIsEmpty();

int GetCanBeRevokeAssetType(std::string &assetType);

//获取锁定金额 - 
int GetLockValue(const std::string& addr, uint64_t &lockValue);

//去除字符串前后的空白
void Trim(std::string& str);

/**
 * @brief       Get the Bonus Addr Info object
 * 
 * @param       bonusAddrDelegatingMap 
 * @return      int 
 */
int fetchBonusAddressInfo(std::map<std::string, uint64_t> &bonusAddrDelegatingMap);

/**
 * @brief       CaculateGuoKu
 *
 * @param       dbReader
 * @param       bonusExchequer
 * @param       addr
 * @param       currentTime
 * @return      int
 */


template <typename T>
std::vector<T> bidirectionalDifference(const std::vector<T>& a, const std::vector<T>& b) {
    std::vector<T> a_sorted(a);
    std::vector<T> b_sorted(b);
    
    // 先排序（必须操作）
    std::sort(a_sorted.begin(), a_sorted.end());
    std::sort(b_sorted.begin(), b_sorted.end());

    std::vector<T> diff;

    // A - B 的差集
    std::set_difference(
        a_sorted.begin(), a_sorted.end(),
        b_sorted.begin(), b_sorted.end(),
        std::back_inserter(diff)
    );

    // B - A 的差集
    std::set_difference(
        b_sorted.begin(), b_sorted.end(),
        a_sorted.begin(), a_sorted.end(),
        std::back_inserter(diff)
    );

    return diff;
}

int getAllAddrSignCountByPeriod(uint64_t period, std::unordered_map<std::string, uint64_t> & addr_sign_count);


enum class FlowTxType
{
    Unknown = 0,
    FlowInTx,
    FlowOutTx,
};

FlowTxType GetFlowTxType(const nlohmann::json& txInfoJson);

}; // namespace ca_algorithm

#endif
