#ifndef OPENHIVE_CONTRACT_NONCE_POLICY_H
#define OPENHIVE_CONTRACT_NONCE_POLICY_H

#include <cstdint>
#include <map>
#include <set>
#include <string>
#include <vector>

namespace contract_nonce
{
struct Entry
{
    std::string tx_hash;
    std::string address;
    uint64_t nonce = 0;
    uint64_t time = 0;
};

enum class ValidationResult
{
    kOk,
    kDuplicateTransaction,
    kNonceMismatch,
};

enum class BatchReadiness
{
    kReady,
    kWaitingNonce,
    kNonceConflict,
    kInvalidSequence,
    kGapLimitExceeded,
};

ValidationResult ValidateCanonicalSequence(
    std::vector<Entry> entries,
    const std::map<std::string, uint64_t>& committed_nonces,
    std::map<std::string, uint64_t>* expected_nonces = nullptr);

BatchReadiness ClassifyCanonicalBatch(
    std::vector<Entry> entries,
    const std::map<std::string, uint64_t>& committed_nonces,
    uint64_t max_nonce_gap,
    std::map<std::string, uint64_t>* missing_nonces = nullptr);

bool SharesAccount(const std::vector<std::string>& accounts,
                   const std::set<std::string>& blocked_accounts);
} // namespace contract_nonce

#endif
