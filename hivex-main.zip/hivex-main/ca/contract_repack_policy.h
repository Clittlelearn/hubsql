#ifndef OHI_CA_CONTRACT_REPACK_POLICY_H_
#define OHI_CA_CONTRACT_REPACK_POLICY_H_

#include <algorithm>
#include <cstdint>
#include <iterator>
#include <limits>
#include <string>
#include <vector>

namespace contract_repack {

inline constexpr int kBuildStaleParent = -106;
inline constexpr int kRetryAuthorizationChanged = -107;
inline constexpr int kBatchTransactionRejected = -108;
inline constexpr int kBatchTransactionSetMismatch = -109;
inline constexpr int kMaxAttempts = 3;
inline constexpr uint64_t kContractValidityMicros = 30ULL * 1000ULL * 1000ULL;
inline constexpr uint64_t kDeferredRetryGuardMicros = 2ULL * 1000ULL * 1000ULL;

struct ChainTipSnapshot {
    uint64_t height = 0;
    std::vector<std::string> hashes;
    bool valid = false;
};

enum class TipComparison { kUnchanged, kHeightChanged, kHashSetChanged, kUnavailable };

enum class BatchSetComparison {
    kEqual,
    kDuplicateAuthorized,
    kDuplicateIncluded,
    kDuplicateExcluded,
    kIncludedExcludedOverlap,
    kSetMismatch
};

inline bool HasDuplicates(std::vector<std::string> values)
{
    std::sort(values.begin(), values.end());
    return std::adjacent_find(values.begin(), values.end()) != values.end();
}

inline BatchSetComparison CompareAuthorizedTransactionSet(
    std::vector<std::string> authorized,
    std::vector<std::string> included,
    std::vector<std::string> excluded = {})
{
    if (HasDuplicates(authorized)) return BatchSetComparison::kDuplicateAuthorized;
    if (HasDuplicates(included)) return BatchSetComparison::kDuplicateIncluded;
    if (HasDuplicates(excluded)) return BatchSetComparison::kDuplicateExcluded;

    std::sort(authorized.begin(), authorized.end());
    std::sort(included.begin(), included.end());
    std::sort(excluded.begin(), excluded.end());

    std::vector<std::string> overlap;
    std::set_intersection(included.begin(), included.end(), excluded.begin(), excluded.end(),
                          std::back_inserter(overlap));
    if (!overlap.empty()) return BatchSetComparison::kIncludedExcludedOverlap;

    included.insert(included.end(), excluded.begin(), excluded.end());
    std::sort(included.begin(), included.end());
    return included == authorized ? BatchSetComparison::kEqual : BatchSetComparison::kSetMismatch;
}

inline void Canonicalize(ChainTipSnapshot& snapshot)
{
    std::sort(snapshot.hashes.begin(), snapshot.hashes.end());
    snapshot.hashes.erase(std::unique(snapshot.hashes.begin(), snapshot.hashes.end()), snapshot.hashes.end());
}

inline TipComparison CompareTips(ChainTipSnapshot expected, ChainTipSnapshot current)
{
    if (!expected.valid || !current.valid) return TipComparison::kUnavailable;
    if (expected.height != current.height) return TipComparison::kHeightChanged;
    Canonicalize(expected);
    Canonicalize(current);
    return expected.hashes == current.hashes ? TipComparison::kUnchanged : TipComparison::kHashSetChanged;
}

inline bool IsRecoverableBuildResult(const int result)
{
    return result == -103 || result == -104 || result == -105 || result == kBuildStaleParent;
}

inline bool ShouldRetry(const int result, const int completedAttempts, const int maxAttempts = kMaxAttempts)
{
    return IsRecoverableBuildResult(result) && completedAttempts < maxAttempts;
}

inline bool ShouldDeferAfterFastRetries(const int result,
                                        const int completedAttempts,
                                        const int maxAttempts = kMaxAttempts)
{
    return IsRecoverableBuildResult(result) && completedAttempts >= maxAttempts;
}

inline uint64_t ContractBatchDeadline(const std::vector<uint64_t>& transactionTimes,
                                      const uint64_t validityMicros = kContractValidityMicros)
{
    if (transactionTimes.empty() || validityMicros == 0) return 0;
    uint64_t deadline = std::numeric_limits<uint64_t>::max();
    for (const auto time : transactionTimes)
    {
        if (time == 0 || time > std::numeric_limits<uint64_t>::max() - validityMicros) return 0;
        deadline = std::min(deadline, time + validityMicros);
    }
    return deadline;
}

inline bool CanStartDeferredRetry(const uint64_t nowMicros,
                                  const uint64_t deadlineMicros,
                                  const uint64_t guardMicros = kDeferredRetryGuardMicros)
{
    return deadlineMicros > nowMicros && deadlineMicros - nowMicros > guardMicros;
}

inline bool CanReuseDispatcherAuthorization(const bool proofValid,
                                            const bool transactionSetUnchanged,
                                            const bool dependencySetWithinOriginal)
{
    return proofValid && transactionSetUnchanged && dependencySetWithinOriginal;
}

inline const char* TipComparisonName(const TipComparison comparison)
{
    switch (comparison)
    {
        case TipComparison::kUnchanged: return "unchanged";
        case TipComparison::kHeightChanged: return "height_changed";
        case TipComparison::kHashSetChanged: return "hash_set_changed";
        case TipComparison::kUnavailable: return "unavailable";
    }
    return "unknown";
}

inline const char* BatchSetComparisonName(const BatchSetComparison comparison)
{
    switch (comparison)
    {
        case BatchSetComparison::kEqual: return "equal";
        case BatchSetComparison::kDuplicateAuthorized: return "duplicate_authorized";
        case BatchSetComparison::kDuplicateIncluded: return "duplicate_included";
        case BatchSetComparison::kDuplicateExcluded: return "duplicate_excluded";
        case BatchSetComparison::kIncludedExcludedOverlap: return "included_excluded_overlap";
        case BatchSetComparison::kSetMismatch: return "set_mismatch";
    }
    return "unknown";
}

}  // namespace contract_repack

#endif  // OHI_CA_CONTRACT_REPACK_POLICY_H_
