#ifndef OPENHIVE_PENDING_TRANSACTION_POLICY_H
#define OPENHIVE_PENDING_TRANSACTION_POLICY_H

#include <cstdint>
#include <limits>

namespace pending_tx
{
inline constexpr uint32_t kDeployTransactionType = 7;
inline constexpr uint32_t kCallTransactionType = 8;
inline constexpr uint64_t kNormalValidityMicros = 10ULL * 1000ULL * 1000ULL;
inline constexpr uint64_t kContractValidityMicros = 30ULL * 1000ULL * 1000ULL;

inline uint64_t ConsensusDeadline(const uint64_t transaction_time, const uint32_t transaction_type)
{
    const uint64_t validity = transaction_type == kCallTransactionType ||
                                      transaction_type == kDeployTransactionType
                                  ? kContractValidityMicros : kNormalValidityMicros;
    if (transaction_time == 0 || transaction_time > std::numeric_limits<uint64_t>::max() - validity) return 0;
    return transaction_time + validity;
}
}

#endif
