#ifndef OPENHIVE_CONFIRMED_EXCLUSION_VERIFIER_H
#define OPENHIVE_CONFIRMED_EXCLUSION_VERIFIER_H

#include <string>

#include "pb/block.pb.h"
#include "pb/ca_protomsg.pb.h"

namespace confirmed_exclusion
{
std::string SigningPayload(const ExclusionProof& proof);
bool VerifyConfirmedProof(const CBlock& candidate,
                          const ExclusionProof& proof,
                          const std::string& dispatcher_vrf,
                          std::string* error = nullptr);
} // namespace confirmed_exclusion
#endif
