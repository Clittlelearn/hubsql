#include "vrf_consensus.h"
#include <openssl/sha.h>
#include <numeric>
#include <functional>
#include <unordered_set>
#include <cmath>
#include "net/api.h"
#include "utils/account_manager.h"
#include "ca/txhelper.h"
#include "ca/algorithm.h"
#include "ca/dispatchtx.h"
#include "common/genesis.h"
#include "common/task_pool.h"
#include "ca/transaction.h"
#include "utils/tmp_log.h"
#include "utils/magic_singleton.h"
#include "utils/time_util.h"
#include <nlohmann/json.hpp>
#include <sstream>
#include <algorithm>
#include <iomanip>
#define DEBUGLOG(format,...) 

static std::string BinaryToHexString(const std::string& data)
{
    std::ostringstream oss;
    oss << std::hex << std::setfill('0');
    for (unsigned char c : data)
    {
        oss << std::setw(2) << static_cast<unsigned int>(c);
    }
    return oss.str();
}

std::string convertToReadableDate(const std::chrono::system_clock::time_point& timePoint) {
    std::time_t timeT = std::chrono::system_clock::to_time_t(timePoint);

    // 使用 std::gmtime 代替 std::localtime 以避免时区问题
    std::tm tm = *std::gmtime(&timeT);

    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");

    return oss.str();
}

// VRFStructure implementations
VRFStructure::VRFStructure(const std::string& seed, const std::string& signature, const std::string& nodeId)
    : seed(seed), signature(signature), nodeId(nodeId), signatureHash(Getsha256Hash(signature)), frequency(0.0) {}

std::string VRFStructure::getAddress() const {
    return nodeId;
}

std::string VRFStructure::getSignature() const {
    return signature;
}

std::string VRFStructure::getSignatureHash() const {
    return signatureHash;
}

std::string VRFStructure::getSeed() const{
    return seed;
}

double VRFStructure::getFrequency() const{
    return frequency;
}

std::map<uint64_t, std::vector<std::string>> VRFStructure::calculateHeightHashes() const{
    return height_hashes;
}

void VRFStructure::addHashForHeight(uint64_t height, const std::string& hash) {
    height_hashes[height].push_back(hash);
}

void VRFStructure::addFrequency(const double frequency)
{
    this->frequency = frequency;
}

// VRFConsensusNode implementations
int VRFConsensusNode::sign(const std::string& data, std::string& signature, std::string& pub) {
    std::string hash = Getsha256Hash(data);
    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if (TxHelper::Sign(defaultAddr, hash, signature, pub) != 0) {
        ERRORLOG("Signature failed");
        return -1;
    }
    return 0;
}

int VRFConsensusNode::generateVRFStructure(const std::string& seed, VRFConsensusInfo& vrf) {
    // 先填充所有数据（seed和blockinfo）
    vrf.set_vrfseed(seed);

    DBReader dbReader;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("getBlockTop error! top:{}",top);
        return -2;
    }

    for(int i = top; i >= top - 10; i--)
    {
        std::vector<std::string> block_hashes_temp;
        if (DBStatus::DB_SUCCESS != dbReader.getBlockHashsByBlockHeight(i, block_hashes_temp)) //hash Get the hash of all blocks with the height of this block
        {
            ERRORLOG("getBlockHashsByBlockHeight  block.height:{}", i);
            return -3;
        }
        
        for(const auto& hash : block_hashes_temp)
        {
            auto blockinfo = vrf.add_blockinfo();
            blockinfo->set_blockhash(hash.substr(0,8));
            blockinfo->set_height(i);
            if(vrf.blockinfo_size() >= 10)
            {
                break;
            }
        }
        if(vrf.blockinfo_size() >= 10)
        {
            break;
        }
    }

    // 直接序列化整个vrf结构（此时还没有签名）
    std::string vrfData = vrf.SerializeAsString();
    
    // 对整个vrf结构进行签名
    std::string signature;
    std::string pub;
    if (sign(vrfData, signature, pub) != 0) {
        ERRORLOG("Sign vrf structure failed");
        return -1;
    }

    // 设置签名信息
    CSign* sign = vrf.mutable_vrfsign();
    sign->set_sign(signature);
    sign->set_pub(pub);

    return 0;
}

void VRFConsensusNode::vrfBroadcastMessage(const VRFConsensusInfo& vrf) {
    auto vrfPtr = std::make_shared<VRFConsensusInfo>(vrf);
    const auto& public_node_list = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    for (const auto& node : public_node_list) {
        MagicSingleton<TaskPool>::GetInstance()->commitBroadcastRequest(
            [node, vrfPtr]() {
                net_com::SendVRFConsensusInfoTask(node, *vrfPtr);
            }
        );
    }
    return;
}

bool VRFConsensusNode::validate_block_info(const VRFConsensusInfo& vrfInfo, const std::string& nodeId) const{

   bool canReward= VerifyBonusAddr(nodeId);
    //int64_t stakeTime = ca_algorithm::GetPledgeTimeByAddr(nodeId, global::ca::StakeType::STAKE_TYPE_NODE);
    if (!canReward) {
        return false;
    }

    if(vrfInfo.blockinfo_size() != 10){
        ERRORLOG("vrf.blockinfo_size:{} != 10", vrfInfo.blockinfo_size());
        return false;
    }

    std::unordered_set<std::string> hashSet;
    for (const auto& blockinfo : vrfInfo.blockinfo()) {
        const std::string& hash = blockinfo.blockhash();
        // 检查是否有重复哈希
        if (hashSet.find(hash) != hashSet.end()) {
            return false;
        }
        hashSet.insert(hash);
    }
    
    return true;
}


void VRFConsensusNode::receiveVRRequest(const VRFConsensusInfo& vrf) {
    auto generatedSeedTime = std::chrono::system_clock::now();
    const CSign& sign = vrf.vrfsign();
    std::string nodeId = GenerateAddr(sign.pub());

    // 新增的种子验证部分
    std::string receivedSeed = vrf.vrfseed();
    auto receivedSeedTime = std::chrono::system_clock::from_time_t(std::stoll(receivedSeed));
    auto generatedSeedTimeInSeconds = std::chrono::system_clock::to_time_t(generatedSeedTime);
    auto adjustedGeneratedSeedTime = std::chrono::system_clock::from_time_t(generatedSeedTimeInSeconds);
    
    auto timeDiff = std::chrono::duration_cast<std::chrono::seconds>(adjustedGeneratedSeedTime - receivedSeedTime).count();
    //wbl test
  //  DEBUGLOG("seed:{}, receivedSeedTime:{}, generatedSeedTime:{}, timeDiff:{}, id:{}",receivedSeed, convertToReadableDate(receivedSeedTime), convertToReadableDate(adjustedGeneratedSeedTime), timeDiff, nodeId);

    if (std::abs(timeDiff) > CYCLE_DURATION_SECONDS) {
        TRACELOG("[VRF_CONFIRM] seed:{} time difference is greater than {} seconds", receivedSeed, CYCLE_DURATION_SECONDS);
        return;
    }

    {
        DBReader dbReader;
        uint64_t top = 0;
        dbReader.getBlockTop(top);
        if (top >= global::ca::MIN_UNSTAKE_HEIGHT) {

            if(!validate_block_info(vrf, nodeId)){
                ERRORLOG("validateVRFConsensusInfo fail!!! seed:{}", receivedSeed);
                return;
            }
        }
    }

    // 创建临时对象用于序列化（排除签名字段）
    VRFConsensusInfo vrfForVerify;
    vrfForVerify.set_vrfseed(vrf.vrfseed());
    for(const auto& blockinfo : vrf.blockinfo())
    {
        auto* newBlockinfo = vrfForVerify.add_blockinfo();
        newBlockinfo->set_blockhash(blockinfo.blockhash());
        newBlockinfo->set_height(blockinfo.height());
    }
    
    // 序列化整个vrf结构（不包含签名字段）
    std::string vrfData = vrfForVerify.SerializeAsString();
    std::string vrfDataHash = Getsha256Hash(vrfData);
    
    // 对整个vrf结构进行验签
    if (ca_algorithm::VerifySign(sign, vrfDataHash) != 0) {
        ERRORLOG("VerifySign fail, addr:{}, seed:{}", nodeId, receivedSeed);

        // Record VRF verify failure for cumulative tracking (L3 trigger)
        DBReadWriter dbWriter;
        dbWriter.recordVRFFail(nodeId, std::stoull(receivedSeed));

        return;
    }

    if(!addVRFStructure(vrf, nodeId))
    {
        return;
    }
    //wbl test
//    DEBUGLOG("BroadcastVRF addr:{}, seed:{}", nodeId, receivedSeed);
    vrfBroadcastMessage(vrf);
}

void VRFConsensusNode::pruneOldData() {
    if (validatedVRfs.size() > MAX_VRFS_SIZE) {
        while (validatedVRfs.size() > MAX_VRFS_SIZE) {
            validatedVRfs.erase(validatedVRfs.begin());
        }
    }

    if (newValidatedVRfs.size() > MAX_VRFS_SIZE) {
        while (newValidatedVRfs.size() > MAX_VRFS_SIZE) {
            newValidatedVRfs.erase(newValidatedVRfs.begin());
        }
    }
}

bool VRFConsensusNode::addVRFStructure(const VRFConsensusInfo& vrfInfo, const std::string& nodeId) {
    std::unique_lock<std::shared_mutex> lock(mutex_);
    const std::string& seed = vrfInfo.vrfseed();
    const std::string& signature = vrfInfo.vrfsign().sign();
    auto it = validatedVRfs[seed].find(nodeId);
    if (it == validatedVRfs[seed].end())
    {
        VRFStructure vrf(seed, signature, nodeId);

        for(const auto& blockinfo : vrfInfo.blockinfo())
        {
            vrf.addHashForHeight(blockinfo.height(), blockinfo.blockhash());
        }

        validatedVRfs[seed][nodeId] = vrf;
        pruneOldData();
        //wbl test
  //      DEBUGLOG("validatedVRfs.second size:{}, vrfSeed:{}, id:{}", validatedVRfs[seed].size(), seed, nodeId);
        return true;
    }

    // Double-sign detection: same nodeId + same seed + different signature
    const std::string& existingSig = it->second.getSignature();
    if (existingSig != signature)
    {
        ERRORLOG("[SLASH] VRF double-sign detected! addr:{}, seed:{}, existing_sig_hash:{}, new_sig_hash:{}",
                 nodeId, seed,
                 it->second.getSignatureHash(),
                 Getsha256Hash(signature));

        // 构造 SlashEvidenceMsg 并发送给分发者
        SlashEvidenceMsg evidenceMsg;
        evidenceMsg.set_version("1.0");
        evidenceMsg.set_target_addr(nodeId);
        evidenceMsg.set_violation_type(SlashViolationType::DOUBLE_SIGN_VRF);
        
        // 构造证据数据（包含两个签名）
        nlohmann::json evidenceData;
        evidenceData["seed"] = seed;
        evidenceData["existing_sig_hash"] = it->second.getSignatureHash();
        evidenceData["new_sig_hash"] = Getsha256Hash(signature);
        evidenceData["signature_encoding"] = "hex";
        evidenceData["existing_sig_hex"] = BinaryToHexString(existingSig);
        evidenceData["new_sig_hex"] = BinaryToHexString(signature);
        evidenceData["detection_time"] = std::to_string(
            std::chrono::duration_cast<std::chrono::microseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count());
        
        std::string evidenceDataStr = evidenceData.dump();
        evidenceMsg.set_evidence_data(evidenceDataStr);
        evidenceMsg.set_evidence_hash(Getsha256Hash(evidenceDataStr));
        
        // 设置当前周期
        uint64_t currentTime = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(currentTime);
        evidenceMsg.set_period(period);
        
        // 设置报告者地址（本节点）
        std::string reporterAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
        evidenceMsg.set_reporter(reporterAddr);
        
        // 用本节点私钥签名
        CSign* sig = evidenceMsg.mutable_signature();
        std::string signData, pubKey;
        if (TxHelper::Sign(reporterAddr, evidenceMsg.evidence_hash(), signData, pubKey) == 0) {
            sig->set_sign(signData);
            sig->set_pub(pubKey);
            
            // Sending can call back into extractVRFData(), so release mutex_ first.
            lock.unlock();
            // 发送给分发者（带随机退避）
            SendSlashEvidenceToDispatcher(evidenceMsg);
        } else {
            ERRORLOG("[SLASH] Failed to sign evidence message");
        }
    }

    return false;
}


bool VRFConsensusNode::checkVRFExists(const std::string& seed, const std::string& nodeId) const {
    std::shared_lock<std::shared_mutex> lock(mutex_);
    auto it = validatedVRfs.find(seed);
    if (it != validatedVRfs.end()) {
        const auto& nodeMap = it->second;
        if (nodeMap.find(nodeId) != nodeMap.end()) {
            return true;
        }
    }
    return false;
}

void VRFConsensusNode::Process()
{
    VRFConsensusThread = std::thread(std::bind(&VRFConsensusNode::run, this));
    VRFConsensusThread.detach();
}

void VRFConsensusNode::run() {
    nodeStartTime_ = std::chrono::system_clock::now();
    std::stringstream ss;
    ss << std::this_thread::get_id();
    TRACELOG("[VRF_CONFIRM] VRFConsensusNode::run thread started, thread_id: {}", ss.str());
    while (true) {
        auto currentTime = std::chrono::system_clock::now();
        auto nextCycleStart = cycleStartTimestamp(currentTime);

        TRACELOG("[VRF_CONFIRM] Current Time: {}, nextCycleStart:{}", convertToReadableDate(currentTime), convertToReadableDate(nextCycleStart));

        std::this_thread::sleep_until(nextCycleStart);

        std::string vrfSeed = generateVRSeed(nextCycleStart);
        TRACELOG("[VRF_CONFIRM][PHASE1] start seed={}", vrfSeed);
        VRFConsensusInfo vrf;
        if (generateVRFStructure(vrfSeed, vrf) != 0) {
            ERRORLOG("[VRF_CONFIRM][PHASE1] GenerateVRFStructure fail, vrfSeed:{}", vrfSeed);
            continue;
        }

        std::string strFromAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
        {
            DBReader dbReader;
            uint64_t top = 0;
            dbReader.getBlockTop(top);
            if (top >= global::ca::MIN_UNSTAKE_HEIGHT) {

                if(validate_block_info(vrf, strFromAddr))
                {
                    addVRFStructure(vrf, strFromAddr);
                }
                else
                {
                    TRACELOG("[VRF_CONFIRM][PHASE1] I don't meet the qualifications. vrfSeed:{}", vrfSeed);
                    continue;
                }
            }

        }
        vrfBroadcastMessage(vrf);
        {
            std::unique_lock<std::shared_mutex> lock(mutex_);
            computeMaxHeightWithMinFrequency();
        }
        TRACELOG("[VRF_CONFIRM][PHASE1] end seed={}", vrfSeed);

        // ===== PHASE 2: Summary exchange (starts at PHASE1_DURATION seconds into cycle) =====
        auto phase2Start = nextCycleStart + std::chrono::seconds(global::ca::PHASE1_DURATION);
        std::this_thread::sleep_until(phase2Start);
        TRACELOG("[VRF_CONFIRM][PHASE2] start seed={}", vrfSeed);
        generateVRFSummary(vrfSeed);
        {
            std::shared_lock<std::shared_mutex> lock(mutex_);
            auto it = validatedSummaries.find(vrfSeed);
            size_t totalSummaries = (it != validatedSummaries.end()) ? it->second.size() : 0;
            TRACELOG("[VRF_CONFIRM][PHASE2] complete seed={} total_summaries={}", vrfSeed, totalSummaries);
        }

        // ===== PHASE 3: Consensus computation (starts at PHASE1_DURATION + PHASE2_DURATION seconds) =====
        auto phase3Start = nextCycleStart + std::chrono::seconds(global::ca::PHASE1_DURATION + global::ca::PHASE2_DURATION);
        std::this_thread::sleep_until(phase3Start);
        auto phase3TimeSec = std::chrono::duration_cast<std::chrono::seconds>(phase3Start.time_since_epoch()).count();
        int degradeLevel = computeDegradeLevel(static_cast<uint64_t>(phase3TimeSec));
        TRACELOG("[VRF_CONFIRM][PHASE3] start seed={} degrade_level={}", vrfSeed, degradeLevel);
        {
            std::unique_lock<std::shared_mutex> lock(mutex_);
            clockSkewNodes_.clear();
            if (isPartitioned(vrfSeed)) {
                TRACELOG("[VRF_CONFIRM][PHASE3] seed={} partition detected, skipping consensus", vrfSeed);
            } else {
                std::vector<std::string> consensusSet;
                computeConsensusSetInternal(vrfSeed, consensusSet);
                TRACELOG("[VRF_CONFIRM][PHASE3] diagnostic seed={} consensus_size={}", vrfSeed, consensusSet.size());
            }
        }
        TRACELOG("[VRF_CONFIRM][PHASE3] end seed={}", vrfSeed);

        TRACELOG("[VRF_CONFIRM] cycle complete seed={}", vrfSeed);
    }
}


void VRFConsensusNode::computeMaxHeightWithMinFrequency(const std::string& seed) {
    std::map<uint64_t, std::unordered_map<std::string, int>> heightHashCounts;
    std::map<std::string, std::set<std::string>> nodeHashes;

    // Check if there is enough validated VRFs data
    if (validatedVRfs.size() < 3) {
        //wbl test
        DEBUGLOG("Not enough validated VRFs data. size:{}", validatedVRfs.size());
        return;
    }

    // Extract data from the second last period
    auto it = std::prev(validatedVRfs.end(), 3);
    if(!seed.empty())
    {
        it = validatedVRfs.find(seed);
        if(it == validatedVRfs.end())
        {
            ERRORLOG("seed no found!!!, seed:{}", seed);
            return;
        }
    }
    //wbl test
    //DEBUGLOG("seed:{}", it->first);
    // Iterate over all nodes' data in that period
    for (const auto& nodePair : it->second) {
        //wbl test
   //     DEBUGLOG("11seed:{}, id:{}", it->first, nodePair.first);
        const auto& vrfStructure = nodePair.second;
        // Iterate over each height and its corresponding hash list
        for (const auto& heightHashesPair : vrfStructure.calculateHeightHashes()) {
            uint64_t height = heightHashesPair.first;
            const auto& hashes = heightHashesPair.second;
            // Count occurrences of each hash at each height
            for (const auto& hash : hashes) {
                heightHashCounts[height][hash]++;
                nodeHashes[nodePair.first].insert(hash);
            }
        }
    }

    if(nodeHashes.empty())
    {
        DEBUGLOG("nodeHashes.empty() == true");
        return;
    }

    std::unordered_map<uint64_t, std::map<std::string, double>> mostFrequentHashes;
    std::map<uint64_t, std::vector<double>> heightHashRatios;
    // Find the most frequent hash at each height
    for (const auto& heightPair : heightHashCounts) {
        uint64_t height = heightPair.first;
        const auto& hashCounts = heightPair.second;

        for (const auto& hash : hashCounts) {
            double ratio = static_cast<double>(hash.second) / it->second.size();
            mostFrequentHashes[height][hash.first] = ratio;
            heightHashRatios[height].push_back(ratio);
        }
    }

    // Calculate the average frequency for each height
    std::vector<std::pair<uint64_t, double>> averagedHeightRatios;
    for (const auto& heightRatioPair : heightHashRatios) {
        uint64_t height = heightRatioPair.first;
        const auto& ratios = heightRatioPair.second;
        double averageRatio = std::accumulate(ratios.begin(), ratios.end(), 0.0) / ratios.size();
        averagedHeightRatios.push_back({height, averageRatio});
    }

    // Calculate the weighted average frequency as the optimal frequency
    double totalWeightedFreq = 0.0;
    double totalWeight = 0.0;
    for (const auto& heightRatioPair : averagedHeightRatios) {
        totalWeightedFreq += heightRatioPair.second * heightRatioPair.first;
        totalWeight += heightRatioPair.first;
    }

    double optimalFrequency = (totalWeight != 0) ? (totalWeightedFreq / totalWeight) : 0.0;
//wbl test
//    DEBUGLOG("11seed:{}, Optimal Frequency:{}",it->first, optimalFrequency);

    std::set<std::string> optimalHashes;
    for (const auto& mostPair : mostFrequentHashes) {

        for(const auto& hashPair : mostPair.second) {
            //wbl test
//            DEBUGLOG("11seed:{}, height:{}, optimalHashes:{}, Ratio:{}",it->first, mostPair.first, hashPair.first.substr(0,6), hashPair.second);
            if (hashPair.second >= optimalFrequency) {
                optimalHashes.insert(hashPair.first);
            }
        }

    }

    for(const auto& hash : optimalHashes)
    {
        //wbl test
//        DEBUGLOG("11seed:{}, hash:{}",it->first, hash.substr(0,6));
    }
    DEBUGLOG("------------------------");
    std::unordered_map<std::string, int> nodeHashCount;
    // Count the number of optimal hashes each node has
    for (const auto& nodePair : nodeHashes) {
        nodeHashCount[nodePair.first] = 0;
        for (const auto& hash : nodePair.second) {
            //wbl test
//            DEBUGLOG("11seed:{}, id:{}, hash:{}",it->first, nodePair.first, hash.substr(0,6));
            if (optimalHashes.find(hash) != optimalHashes.end()) {
                nodeHashCount[nodePair.first]++;
            }
        }
    }

    double frequencyThreshold = 1.0;
    std::vector<std::string> qualifiedNodes;
    uint64_t validateNodeThreshold = it->second.size() * 0.55;
    DEBUGLOG("11seed:{}, size:{}, validateNodeThreshold:{}", it->first, it->second.size(), validateNodeThreshold);
    // Lower the frequency threshold by 0.1 until at least validateNodeThreshold are found
    do {
        qualifiedNodes.clear();
        for (const auto& nodeCountPair : nodeHashCount) {
            double frequency = static_cast<double>(nodeCountPair.second) / optimalHashes.size();
            //wbl test
//            DEBUGLOG("11seed:{}, nodeHashCount, hash:{}, count:{}, frequency:{}",it->first, nodeCountPair.first, nodeCountPair.second, frequency)
            if (frequency >= frequencyThreshold) {

                auto found = it->second.find(nodeCountPair.first);
                if (found != it->second.end()) {
                    found->second.addFrequency(frequency);
                    newValidatedVRfs[it->first].emplace(found->first, found->second);
                    //wbl test
 //                   DEBUGLOG("11seed:{}, id:{}, size:{}",it->first, found->first, newValidatedVRfs[it->first].size());
                }

                qualifiedNodes.push_back(nodeCountPair.first);
            }
        }
        frequencyThreshold = std::round(frequencyThreshold * 10.0) / 10.0;
        frequencyThreshold -= 0.1;
    } while (qualifiedNodes.size() < validateNodeThreshold && frequencyThreshold > 0);

    return;
}


bool VRFConsensusNode::extractVRFData(std::map<std::string, VRFStructure>& dataSource, uint64_t timestamp) {
    auto previousCycleTime = getPreviousCycleTime(timestamp);
    auto prevCycleTimeSec = std::chrono::duration_cast<std::chrono::seconds>(previousCycleTime.time_since_epoch()).count();
    std::string seed = std::to_string(prevCycleTimeSec);
    DEBUGLOG("seed:{}, previousCycleTime:{}", seed, convertToReadableDate(previousCycleTime));

    std::unique_lock<std::shared_mutex> lock(mutex_);

    auto it = newValidatedVRfs.find(seed);
    if (it == newValidatedVRfs.end() || it->second.empty()) {
        auto oldIt = validatedVRfs.find(seed);
        if (oldIt == validatedVRfs.end()) {
            return false;
        }

        computeMaxHeightWithMinFrequency(seed);
        it = newValidatedVRfs.find(seed);
        if(it != newValidatedVRfs.end())
        {
            DEBUGLOG("11seed:{}, AnewValidatedVRfs:{}", seed, newValidatedVRfs.size());
            dataSource.insert(it->second.begin(), it->second.end());
        }
        else
        {
            DEBUGLOG("11seed:{}, validatedVRfs:{}", seed, validatedVRfs.size());
            dataSource.insert(oldIt->second.begin(), oldIt->second.end());
        }
    } 
    else
    {
        DEBUGLOG("11seed:{}, BnewValidatedVRfs:{}, newSize:{}", seed, newValidatedVRfs.size(), it->second.size());
        dataSource.insert(it->second.begin(), it->second.end());
    }

    // VRF 确认协议：冷启动检查
    auto now = std::chrono::system_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - nodeStartTime_).count();
    if (elapsed < CYCLE_DURATION_SECONDS) {
        TRACELOG("[VRF_CONFIRM] cold_start elapsed={}s, using raw data size={}", elapsed, dataSource.size());
        return true;
    }

    // VRF 确认协议：分区检测
    if (isPartitioned(seed)) {
        TRACELOG("[VRF_CONFIRM][PARTITION] seed={} partition detected, returning empty", seed);
        dataSource.clear();
        return true;
    }

    // VRF 确认协议：时间驱动的多级降级
    int degradeLevel = computeDegradeLevel(timestamp);
    std::vector<std::string> consensusSet;
    if (degradeLevel >= 3) {
        TRACELOG("[VRF_CONFIRM][DEGRADE] level=3 seed={} fallback to raw data size={}", seed, dataSource.size());
    } else {
        computeConsensusSetWithLevel(seed, degradeLevel, consensusSet);
    }

    if (!consensusSet.empty()) {
        std::unordered_set<std::string> csSet(consensusSet.begin(), consensusSet.end());
        std::map<std::string, VRFStructure> filtered;
        for (auto& [addr, vrf] : dataSource) {
            if (csSet.count(addr)) {
                filtered.insert(std::make_pair(addr, std::move(vrf)));
            }
        }
        TRACELOG("[VRF_CONFIRM] extractVRFData seed={} level={} filtered={} original={}", seed, degradeLevel, filtered.size(), dataSource.size());
        dataSource = std::move(filtered);
    } else {
        TRACELOG("[VRF_CONFIRM] extractVRFData seed={} level={} no consensus set, using raw data size={}", seed, degradeLevel, dataSource.size());
    }

    return true;
}

void selectRandomNodes(const std::map<std::string, VRFStructure>& dataSource, std::vector<std::string>& nodes, size_t count) {
    
    std::string sumSeed;
	for(auto iter = dataSource.begin(); iter != dataSource.end(); ++iter){
		sumSeed += iter->second.getSignatureHash();
	}
	//生成32字节的种子
	std::string seed = Getsha256Hash(sumSeed); 

	//重排数据源
	std::vector<std::pair<std::string, VRFStructure>> datas = shuffleMap(dataSource, seed);
    for(auto & it : datas)
    {
        nodes.push_back(it.first);
        if (nodes.size() >= count) 
        {
            break;
        }
    }

    return;
}

double VRFConsensusNode::calculateStakeProbability(const std::string& nodeId) const {
    // VRF 白名单检查：白名单地址始终以 100% 概率进入准入池
    // 使用 unordered_set 实现 O(1) 查找，避免每节点线性扫描
    const auto& whitelist = MagicSingleton<Genesis>::GetInstance()->GetVRFWhitelist();
    if (whitelist.find(nodeId) != whitelist.end()) {
        return 1.0;
    }

    int64_t pledgeTime = ca_algorithm::GetPledgeTimeByAddr(nodeId, global::ca::StakeType::STAKE_TYPE_NODE);
    if (pledgeTime <= 0) {
        return 0.0;  // 未质押或查询失败
    }

    auto now = std::chrono::system_clock::now();
    auto now_sec = std::chrono::duration_cast<std::chrono::seconds>(now.time_since_epoch()).count();

    // 以指定的3月15日为基准：概率 = 0.50 + (当前时间 - 3月15日参考基准) / 86400 * 0.025
    double days_since_reference = static_cast<double>(now_sec - global::ca::kEntryPoolReferenceTimestamp) / 86400.0;
    if (days_since_reference < 0) days_since_reference = 0;

    double prob = global::ca::kEntryPoolInitialProb + days_since_reference * global::ca::kEntryPoolDailyIncrement;
    return std::min(prob, 1.0);
}

double VRFConsensusNode::computeVRFThreshold(
    const std::map<std::string, VRFStructure>& dataSource) const {
    std::string sumSeed;
    for (const auto& item : dataSource) {
        sumSeed += item.second.getSignatureHash();
    }
    std::string seed = Getsha256Hash(sumSeed);

    // 取第1字节 (前2个hex字符)
    unsigned int byteVal;
    std::stringstream ss;
    ss << std::hex << seed.substr(0, 2);
    ss >> byteVal;

    return static_cast<double>(byteVal) / 255.0;  // 0.0 ~ 1.0
}

bool VRFConsensusNode::extractPackagerVRFData(std::vector<std::string>& nodes, uint64_t timestamp) {
    auto previousCycleTime = getPreviousCycleTime(timestamp);
    auto prevCycleTimeSec = std::chrono::duration_cast<std::chrono::seconds>(previousCycleTime.time_since_epoch()).count();
    std::string seed = std::to_string(prevCycleTimeSec);
    DEBUGLOG("seed:{}, previousCycleTime:{}", seed, convertToReadableDate(previousCycleTime));
    std::cout << Sutil::Format("seed:%s, previousCycleTime:%s", seed, convertToReadableDate(previousCycleTime)) << std::endl;

    DBReader dbReader;  // For slashing state checks

    //::cout << "new:" << printfNewValidatedVRfs();
    //std::cout << "not new:" <<   printfValidatedVRfs();

    std::unique_lock<std::shared_mutex> lock(mutex_);
    std::map<std::string, VRFStructure> dataSource;
    auto it = newValidatedVRfs.find(seed);
    if (it == newValidatedVRfs.end() || it->second.empty()) {
        auto oldIt = validatedVRfs.find(seed);
        if (oldIt == validatedVRfs.end()) {
            ERRORLOG("oldIt == validatedVRfs.end()");
            return false;
        }

        computeMaxHeightWithMinFrequency(seed);
        it = newValidatedVRfs.find(seed);
        if(it != newValidatedVRfs.end())
        {
            DEBUGLOG("11seed:{}, AnewValidatedVRfs:{}", seed, newValidatedVRfs.size());
            dataSource.insert(it->second.begin(), it->second.end());
        }
        else
        {
            DEBUGLOG("11seed:{}, validatedVRfs:{}", seed, validatedVRfs.size());
            dataSource.insert(oldIt->second.begin(), oldIt->second.end());
        }
    } 
    else 
    {
        DEBUGLOG("11seed:{}, BnewValidatedVRfs:{}, newSize:{}", seed, newValidatedVRfs.size(), it->second.size());
        dataSource.insert(it->second.begin(), it->second.end());
    }

    // ===== 🆕 Stage1: 准入池过滤 =====
    {
        // 快速路径：全员白名单时 Stage 1 为无效计算，直接跳过
        const auto& whitelist = MagicSingleton<Genesis>::GetInstance()->GetVRFWhitelist();
        bool allWhitelisted = !whitelist.empty();
        for (const auto& item : dataSource) {
            if (whitelist.find(item.first) == whitelist.end()) {
                allWhitelisted = false;
                break;
            }
        }

        if (!allWhitelisted) {
            double vrfThreshold = computeVRFThreshold(dataSource);
            std::map<std::string, VRFStructure> entryPool;

            for (const auto& item : dataSource) {
                double stakeProb = calculateStakeProbability(item.first);
                DEBUGLOG("EntryPool node:{} stakeProb:{} vrfThreshold:{}",
                         item.first, stakeProb, vrfThreshold);
                // 使用 >= 避免 vrfThreshold == 1.0 时白名单节点被错误排除
                if (stakeProb >= vrfThreshold) {
                    entryPool.insert(item);
                }
            }

            if (entryPool.size() >= global::ca::kConsensus) {
                dataSource = std::move(entryPool);  // 替换为过滤后的准入池
                DEBUGLOG("EntryPool filter applied, size:{}", dataSource.size());
            } else {
                DEBUGLOG("EntryPool insufficient ({}), fallback to original dataSource size:{}",
                         entryPool.size(), dataSource.size());
                // 节点不足，直接放行所有质押节点（回退到旧逻辑）
            }
        } else {
            DEBUGLOG("All nodes whitelisted, skip Stage1 entry pool filter");
        }
    }
    // ===== Stage1 结束 =====

    lock.unlock();

    // ===== Stage2: Slashing filter — remove Jailed/Tombstoned nodes =====
    {
        std::map<std::string, VRFStructure> filteredSource;
        for (const auto& item : dataSource) {
            // Check Tombstoned (permanent ban)
            std::string tombstoneVal;
            if (DBStatus::DB_SUCCESS == dbReader.readData(std::string("slash_tombstone_") + item.first, tombstoneVal)) {
                DEBUGLOG("[SLASH] Filtering Tombstoned node:{} from packager selection", item.first);
                continue;
            }
            // Check Jailed (temporary ban)
            std::string jailVal;
            if (DBStatus::DB_SUCCESS == dbReader.readData(std::string("slash_jail_") + item.first, jailVal)) {
                DEBUGLOG("[SLASH] Filtering Jailed node:{} from packager selection", item.first);
                continue;
            }
            filteredSource.insert(item);
        }
        if (filteredSource.size() >= global::ca::kConsensus) {
            dataSource = std::move(filteredSource);
        } else {
            DEBUGLOG("[SLASH] Slashing filter would leave too few nodes ({}), keeping original {}",
                     filteredSource.size(), dataSource.size());
        }
    }
    // ===== Stage2 结束 =====

    // 根据 double 值升序排序 dataSource
    std::vector<std::pair<std::string, VRFStructure>> sortedData(dataSource.begin(), dataSource.end());
    std::sort(sortedData.begin(), sortedData.end(), [](const auto& a, const auto& b) {
        return a.second.getFrequency() < b.second.getFrequency();
    });

    double maxValue = 1.0;
    const size_t minNodes = global::ca::kConsensus;
    std::map<std::string, VRFStructure> filteredDataSource;

    while (filteredDataSource.size() < minNodes) {
        for (const auto& data : sortedData) {
            if (data.second.getFrequency() >= maxValue) {
                filteredDataSource.insert({data.first, data.second});
            }
        }
        maxValue = std::round(maxValue * 10.0) / 10.0;
        if (filteredDataSource.size() < minNodes) {
            filteredDataSource.clear();
            maxValue -= 0.1;
            if (maxValue < 0.0) {
                break;
            }
        }
    }

    if(dataSource.size() < global::ca::kConsensus)
    {
        ERRORLOG("dataSource.size(){} < global::ca::kConsensus",dataSource.size());
        return false;
    }

    // 使用筛选后的数据更新原始的 dataSource
    dataSource = std::move(filteredDataSource);

    selectRandomNodes(dataSource, nodes, global::ca::kConsensus);
    DEBUGLOG("seed:{}, maxValue:{}",seed, maxValue);
    for(const auto& id : nodes)
    {
        DEBUGLOG("id:{}", id);
    }
    return true;
}


std::string VRFConsensusNode::generateVRSeed(std::chrono::system_clock::time_point time) const {
    auto duration = time.time_since_epoch();
    auto seconds = std::chrono::duration_cast<std::chrono::seconds>(duration).count();
    seconds -= seconds % CYCLE_DURATION_SECONDS;  // 使用 CYCLE_DURATION_SECONDS
    return std::to_string(seconds);
}

std::chrono::system_clock::time_point VRFConsensusNode::cycleStartTimestamp(std::chrono::system_clock::time_point current_time) const {
    auto duration = current_time.time_since_epoch();
    auto seconds = std::chrono::duration_cast<std::chrono::seconds>(duration).count();
    seconds += CYCLE_DURATION_SECONDS - (seconds % CYCLE_DURATION_SECONDS);  // 使用 CYCLE_DURATION_SECONDS
    return std::chrono::system_clock::time_point(std::chrono::seconds(seconds));
}

std::chrono::system_clock::time_point VRFConsensusNode::getPreviousCycleTime(uint64_t timestamp) const {
    auto duration = std::chrono::microseconds(timestamp);
    auto seconds = std::chrono::duration_cast<std::chrono::seconds>(duration).count();
    seconds -= seconds % CYCLE_DURATION_SECONDS;  // 使用 CYCLE_DURATION_SECONDS
    seconds -= 2 * CYCLE_DURATION_SECONDS;  // 使用 CYCLE_DURATION_SECONDS
    return std::chrono::system_clock::time_point(std::chrono::seconds(seconds));
}

std::string VRFConsensusNode::printfValidatedVRfs()
{
    std::ostringstream oss;

    std::shared_lock<std::shared_mutex> lock(mutex_);
    if (validatedVRfs.empty()) {
        oss << "No validated VRFs available." << std::endl;
    } else {
        oss << "Validated VRFs:" << std::endl;
        oss << "==============================" << std::endl;
        for (const auto& pair : validatedVRfs) {
            oss << "Key: " << pair.first << std::endl;
            for (const auto& vrfKeyPair : pair.second) {
                oss << "  NodeId: " << vrfKeyPair.second.getAddress() << std::endl;
            }
            oss << "------------------------------" << std::endl;
        }
    }
    return oss.str();
}

std::string VRFConsensusNode::printfNewValidatedVRfs()
{
    std::ostringstream oss;

    std::shared_lock<std::shared_mutex> lock(mutex_);
    if (newValidatedVRfs.empty()) {
        oss << "No newValidated VRFs available." << std::endl;
    } else {
        oss << "newValidated VRFs:" << std::endl;
        oss << "==============================" << std::endl;
        for (const auto& pair : newValidatedVRfs) {
            oss << "Key: " << pair.first << std::endl;
            for (const auto& vrfKeyPair : pair.second) {
                oss << "  NodeId: " << vrfKeyPair.first << "     frequency:" << vrfKeyPair.second.getFrequency() << std::endl;
            }
            oss << "------------------------------" << std::endl;
        }
    }
    return oss.str();
}

int HandleVRFConsensusInfoReq(const std::shared_ptr<VRFConsensusInfo> &msg, const MsgData &msgData)
{
	Node node;
    if(!MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(msgData.fd, node))
    {
        //wbl test
   //     ERRORLOG("Invalid message fd:{}, node.address:{}", msgData.fd, node.address);
        return -1;
    }

    MagicSingleton<VRFConsensusNode>::GetInstance()->receiveVRRequest(*msg);
    return 0;
}

// ===== VRF 确认协议 — M2/M3 方法空实现 =====

void VRFConsensusNode::generateVRFSummary(const std::string& seed) {
    VRFSummary summary;
    summary.seed = seed;

    {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        auto it = validatedVRfs.find(seed);
        if (it == validatedVRfs.end()) {
            TRACELOG("[VRF_CONFIRM][PHASE2] no VRF data for seed={}", seed);
            return;
        }
        for (const auto& [nodeId, vrfStruct] : it->second) {
            summary.received_node_ids.push_back(nodeId);
        }
    }

    std::sort(summary.received_node_ids.begin(), summary.received_node_ids.end());

    VRFSummaryMsg msg;
    msg.set_seed(summary.seed);
    for (const auto& id : summary.received_node_ids) {
        msg.add_received_node_ids(id);
    }

    std::string serialized = msg.SerializeAsString();
    std::string pub;
    if (sign(serialized, summary.signature, pub) != 0) {
        ERRORLOG("[VRF_CONFIRM][PHASE2] sign summary failed seed={}", seed);
        return;
    }
    summary.pub_key = pub;

    {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        validatedSummaries[seed][MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr()] = summary;
        pruneSummaryData();
    }

    TRACELOG("[VRF_CONFIRM][PHASE2] generated summary seed={} node_count={}", seed, summary.received_node_ids.size());
    broadcastVRFSummary(summary);
}

void VRFConsensusNode::broadcastVRFSummary(const VRFSummary& summary) {
    auto msgPtr = std::make_shared<VRFSummaryMsg>();
    msgPtr->set_seed(summary.seed);
    for (const auto& id : summary.received_node_ids) {
        msgPtr->add_received_node_ids(id);
    }
    auto* signMsg = msgPtr->mutable_sign();
    signMsg->set_sign(summary.signature);
    signMsg->set_pub(summary.pub_key);

    const auto& public_node_list = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    for (const auto& node : public_node_list) {
        MagicSingleton<TaskPool>::GetInstance()->commitBroadcastRequest(
            [node, msgPtr]() {
                net_com::SendMessage(node, *msgPtr,
                    net_com::Compress::COMPRESS_TRUE,
                    net_com::Encrypt::ENCRYPT_FALSE,
                    net_com::Priority::kHighPriorityLevel2);
            }
        );
    }
}

void VRFConsensusNode::handleVRFSummaryMsg(const VRFSummaryMsg& msg, const std::string& fromNodeId) {
    const CSign& sign = msg.sign();
    std::string nodeId = GenerateAddr(sign.pub());

    std::string receivedSeed = msg.seed();
    auto receivedSeedTime = std::chrono::system_clock::from_time_t(std::stoll(receivedSeed));
    auto now = std::chrono::system_clock::now();
    auto nowSeconds = std::chrono::system_clock::to_time_t(now);
    auto adjustedNow = std::chrono::system_clock::from_time_t(nowSeconds);
    auto timeDiff = std::chrono::duration_cast<std::chrono::seconds>(adjustedNow - receivedSeedTime).count();

    if (std::abs(timeDiff) > CYCLE_DURATION_SECONDS * 2) {
        TRACELOG("[VRF_CONFIRM][PHASE2] summary seed too old from={} seed={} diff={}", nodeId, receivedSeed, timeDiff);
        return;
    }

    if (std::abs(timeDiff) > global::ca::CLOCK_SKEW_TOLERANCE && std::abs(timeDiff) <= CYCLE_DURATION_SECONDS * 2) {
        TRACELOG("[VRF_CONFIRM][CLOCK_SKEW] node={} skew={}s seed={}", nodeId, timeDiff, receivedSeed);
        std::unique_lock<std::shared_mutex> lock(mutex_);
        clockSkewNodes_.insert(nodeId);
    }

    VRFSummaryMsg msgForVerify;
    msgForVerify.set_seed(msg.seed());
    for (const auto& id : msg.received_node_ids()) {
        msgForVerify.add_received_node_ids(id);
    }

    std::string serialized = msgForVerify.SerializeAsString();
    std::string dataHash = Getsha256Hash(serialized);

    if (ca_algorithm::VerifySign(sign, dataHash) != 0) {
        ERRORLOG("[VRF_CONFIRM][PHASE2] VerifySign fail, addr:{}, seed:{}", nodeId, receivedSeed);
        return;
    }

    VRFSummary summary;
    summary.seed = receivedSeed;
    for (const auto& id : msg.received_node_ids()) {
        summary.received_node_ids.push_back(id);
    }
    summary.signature = sign.sign();
    summary.pub_key = sign.pub();

    {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        if (validatedSummaries[receivedSeed].find(nodeId) != validatedSummaries[receivedSeed].end()) {
            return;
        }
        auto vrfIt = validatedVRfs.find(receivedSeed);
        size_t maxExpected = (vrfIt != validatedVRfs.end()) ? vrfIt->second.size() : 0;
        if (maxExpected > 0 && msg.received_node_ids_size() > static_cast<int>(maxExpected * 2)) {
            TRACELOG("[VRF_CONFIRM][PHASE2] summary from={} has {} node_ids, expected <= {}, rejected",
                     nodeId, msg.received_node_ids_size(), maxExpected * 2);
            return;
        }
        validatedSummaries[receivedSeed][nodeId] = summary;
        pruneSummaryData();
    }

    TRACELOG("[VRF_CONFIRM][PHASE2] received summary from={} seed={} count={}", nodeId, receivedSeed, summary.received_node_ids.size());

    broadcastVRFSummary(summary);
}

int VRFConsensusNode::computeDynamicThreshold(int n) const {
    return computeDynamicThresholdInternal(n);
}

int VRFConsensusNode::computeDynamicThresholdInternal(int n) const {
    if (n <= 0) return 1;

    int naturalTier;
    if (n >= 200) naturalTier = 3;
    else if (n >= 50) naturalTier = 2;
    else if (n >= 20) naturalTier = 1;
    else naturalTier = 0;

    int tier = naturalTier;
    int margin = global::ca::HYSTERESIS_MARGIN;

    if (currentTier_ >= 0 && currentTier_ != naturalTier) {
        if (currentTier_ > naturalTier) {
            int boundary = (currentTier_ == 3) ? 200 : (currentTier_ == 2) ? 50 : 20;
            if (n > boundary + margin) tier = naturalTier;
            else tier = currentTier_;
        } else {
            int boundary = (currentTier_ == 0) ? 20 : (currentTier_ == 1) ? 50 : 200;
            if (n < boundary - margin) tier = naturalTier;
            else tier = currentTier_;
        }
    }

    currentTier_ = tier;

    double ratio;
    int maxAllow;
    switch (tier) {
        case 3: ratio = global::ca::THRESHOLD_RATIO_LARGE;  maxAllow = n / 3; break;
        case 2: ratio = global::ca::THRESHOLD_RATIO_MEDIUM; maxAllow = n / 4; break;
        case 1: ratio = global::ca::THRESHOLD_RATIO_SMALL;  maxAllow = n / 5; break;
        default: ratio = global::ca::THRESHOLD_RATIO_TINY;  maxAllow = std::max(n / 10, 1); break;
    }

    int threshold = static_cast<int>(std::ceil(n * ratio));
    return std::max(threshold, n - maxAllow);
}

void VRFConsensusNode::computeConsensusSet(const std::string& seed, std::vector<std::string>& consensusSet) {
    std::shared_lock<std::shared_mutex> lock(mutex_);
    computeConsensusSetInternal(seed, consensusSet);
}

void VRFConsensusNode::computeConsensusSetInternal(const std::string& seed, std::vector<std::string>& consensusSet) {
    auto it = validatedSummaries.find(seed);
    if (it == validatedSummaries.end() || it->second.empty()) {
        TRACELOG("[VRF_CONFIRM][PHASE3] no summaries for seed={}", seed);
        return;
    }

    const auto& summaryMap = it->second;
    int N = static_cast<int>(summaryMap.size());

    std::map<std::string, int> addrCounts;
    int skippedSkew = 0;
    for (const auto& [nodeId, summary] : summaryMap) {
        if (clockSkewNodes_.count(nodeId)) {
            skippedSkew++;
            continue;
        }
        for (const auto& addr : summary.received_node_ids) {
            addrCounts[addr]++;
        }
    }
    N -= skippedSkew;

    int threshold = computeDynamicThresholdInternal(N);
    int minConsensus = std::max(global::ca::kConsensus, global::ca::send_node_threshold);

    TRACELOG("[VRF_CONFIRM][PHASE3] seed={} N={} threshold={} unique_addrs={} skew_skipped={}",
             seed, N, threshold, addrCounts.size(), skippedSkew);

    for (const auto& [addr, count] : addrCounts) {
        if (count >= threshold) {
            consensusSet.push_back(addr);
        }
    }

    resolveBoundaryEntriesInternal(seed, threshold, addrCounts, consensusSet);

    std::sort(consensusSet.begin(), consensusSet.end());

    if (static_cast<int>(consensusSet.size()) < minConsensus) {
        TRACELOG("[VRF_CONFIRM][PHASE3] consensus_set too small seed={} size={} min={}, falling back to empty",
                 seed, consensusSet.size(), minConsensus);
        consensusSet.clear();
        return;
    }

    TRACELOG("[VRF_CONFIRM][PHASE3] consensus_set seed={} size={} members=[{}]",
             seed, consensusSet.size(),
             [&]() { std::string s; for (size_t i = 0; i < consensusSet.size(); i++) { if (i) s += ","; s += consensusSet[i]; } return s; }());
}

void VRFConsensusNode::resolveBoundaryEntries(const std::string& seed, int threshold,
                                               std::map<std::string, int>& addrCounts,
                                               std::vector<std::string>& consensusSet) {
    resolveBoundaryEntriesInternal(seed, threshold, addrCounts, consensusSet);
}

void VRFConsensusNode::resolveBoundaryEntriesInternal(const std::string& seed, int threshold,
                                                       const std::map<std::string, int>& addrCounts,
                                                       std::vector<std::string>& consensusSet) {
    int delta = global::ca::BOUNDARY_DELTA;
    int low = threshold - delta;
    if (low < 0) low = 0;

    std::unordered_set<std::string> inSet(consensusSet.begin(), consensusSet.end());

    std::vector<std::string> boundaryAddrs;
    for (const auto& [addr, count] : addrCounts) {
        if (count >= low && count < threshold) {
            boundaryAddrs.push_back(addr);
        }
    }

    if (boundaryAddrs.empty()) return;

    std::sort(boundaryAddrs.begin(), boundaryAddrs.end());

    std::string arbitrationSeed = Getsha256Hash(seed + "_" + std::to_string(std::stoll(seed) / CYCLE_DURATION_SECONDS));

    for (const auto& addr : boundaryAddrs) {
        std::string hash = Getsha256Hash(arbitrationSeed + addr);
        unsigned int lastByte = static_cast<unsigned char>(hash.back());
        if (lastByte % 2 == 0) {
            consensusSet.push_back(addr);
        }
    }
}

// ===== M4: 降级与异常处理 =====

int VRFConsensusNode::computeDegradeLevel(uint64_t timestamp) const {
    int64_t seconds = static_cast<int64_t>(timestamp);
    seconds -= seconds % CYCLE_DURATION_SECONDS;
    auto cycleStart = static_cast<uint64_t>(seconds);
    int64_t elapsed = static_cast<int64_t>(timestamp) - static_cast<int64_t>(cycleStart);

    if (elapsed < global::ca::LEVEL1_START) return 0;
    if (elapsed < global::ca::LEVEL2_START) return 1;
    if (elapsed < global::ca::LEVEL3_START) return 2;
    return 3;
}

void VRFConsensusNode::computeConsensusSetWithLevel(const std::string& seed, int degradeLevel,
                                                      std::vector<std::string>& consensusSet) {
    auto it = validatedSummaries.find(seed);
    if (it == validatedSummaries.end() || it->second.empty()) {
        TRACELOG("[VRF_CONFIRM][DEGRADE] level={} seed={} reason=no_summaries", degradeLevel, seed);
        return;
    }

    const auto& summaryMap = it->second;
    int N = static_cast<int>(summaryMap.size());

    std::map<std::string, int> addrCounts;
    int skippedSkew = 0;
    for (const auto& [nodeId, summary] : summaryMap) {
        if (clockSkewNodes_.count(nodeId)) {
            skippedSkew++;
            continue;
        }
        for (const auto& addr : summary.received_node_ids) {
            addrCounts[addr]++;
        }
    }
    N -= skippedSkew;

    int threshold = computeDynamicThresholdInternal(N);

    switch (degradeLevel) {
        case 0:
            break;
        case 1:
            threshold = std::max(1, static_cast<int>(threshold * 0.9));
            TRACELOG("[VRF_CONFIRM][DEGRADE] level=1 seed={} threshold={} (reduced 10%)", seed, threshold);
            break;
        case 2:
            threshold = std::max(N / 2, 1);
            TRACELOG("[VRF_CONFIRM][DEGRADE] level=2 seed={} threshold={} (loose)", seed, threshold);
            break;
        default:
            TRACELOG("[VRF_CONFIRM][DEGRADE] level=3 seed={} fallback to raw data", seed);
            return;
    }

    int minConsensus = std::max(global::ca::kConsensus, global::ca::send_node_threshold);

    for (const auto& [addr, count] : addrCounts) {
        if (count >= threshold) {
            consensusSet.push_back(addr);
        }
    }

    if (degradeLevel == 0) {
        resolveBoundaryEntriesInternal(seed, threshold, addrCounts, consensusSet);
    }

    std::sort(consensusSet.begin(), consensusSet.end());

    if (static_cast<int>(consensusSet.size()) < minConsensus) {
        TRACELOG("[VRF_CONFIRM][DEGRADE] level={} seed={} consensus_size={} < min={}, falling back",
                 degradeLevel, seed, consensusSet.size(), minConsensus);
        consensusSet.clear();
    }
}

bool VRFConsensusNode::isPartitioned(const std::string& seed) const {
    auto vrfIt = validatedVRfs.find(seed);
    auto sumIt = validatedSummaries.find(seed);

    if (vrfIt == validatedVRfs.end() || vrfIt->second.empty()) {
        return false;
    }
    if (sumIt == validatedSummaries.end() || sumIt->second.empty()) {
        return true;
    }

    int vrfCount = static_cast<int>(vrfIt->second.size());
    int summaryCount = static_cast<int>(sumIt->second.size());
    double coverage = static_cast<double>(summaryCount) / vrfCount;

    if (coverage < global::ca::PARTITION_COVERAGE_THRESHOLD) {
        TRACELOG("[VRF_CONFIRM][PARTITION] seed={} coverage={:.2f} vrf_count={} summary_count={}",
                 seed, coverage, vrfCount, summaryCount);
        return true;
    }
    return false;
}

void VRFConsensusNode::pruneSummaryData() {
    if (validatedSummaries.size() > static_cast<size_t>(MAX_VRFS_SIZE)) {
        while (validatedSummaries.size() > static_cast<size_t>(MAX_VRFS_SIZE)) {
            validatedSummaries.erase(validatedSummaries.begin());
        }
    }
}

int HandleVRFSummaryMsgReq(const std::shared_ptr<VRFSummaryMsg>& msg, const MsgData& msgData) {
    Node node;
    if(!MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(msgData.fd, node))
    {
        TRACELOG("[VRF_CONFIRM][PHASE2] HandleVRFSummaryMsgReq: node not found for fd={}", msgData.fd);
        return -1;
    }
    MagicSingleton<VRFConsensusNode>::GetInstance()->handleVRFSummaryMsg(*msg, node.address);
    return 0;
}
