#include "packager_dispatch.h"
#include "utils/timer.hpp"
#include "include/logging.h"
#include "dispatchtx.h"
#include <algorithm>

void packDispatch::Add(const std::string& contractHash, const std::vector<std::string>& dependentContracts, const CTransaction &tx)
{
    std::unique_lock<std::mutex> locker(packDispatchMutex);
	packDispatchDependent.time = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    packDispatchDependent.hash_dep.insert(std::make_pair(contractHash, dependentContracts));
	packDispatchDependent.hash_tx.insert(std::make_pair(contractHash, tx));
    DEBUGLOG("packDispatch Add ...");
}

void packDispatch::GetDependentData(std::map<uint32_t, std::map<std::string, CTransaction>>& dependentContractTxMap_, std::map<std::string, CTransaction> &nonContractTxMap_)
{
    //1.对依赖进行分组
    std::unique_lock<std::mutex> locker(packDispatchMutex);
    DEBUGLOG("DependencyGrouping");
    std::vector<std::set<std::string>> res;

	for (const auto& [key, values] : packDispatchDependent.hash_dep) {
		std::set<std::string> commonKeys;
		commonKeys.insert(key);

		for (const auto& [otherKey, otherValues] : packDispatchDependent.hash_dep) {
			if (key == otherKey)  continue;

            //检查是否有重复的元素
			if (MagicSingleton<DependencyManager>::GetInstance()->HasDuplicate(values, otherValues) == true)
			{
                //key为交易hash
				commonKeys.insert(otherKey);
			}
		}

		if (!commonKeys.empty()) {
			bool foundDuplicate = false;
			//往最终的容器插入的时候 要比较一个跟之前的是否有重复的  如果没有重复的那么就新建一个数组 有重复的就在原来的数组中插入
			for (auto& itemSet : res) {
                
				std::set<std::string> intersection;
				std::set_intersection(
					itemSet.begin(), itemSet.end(),
					commonKeys.begin(), commonKeys.end(),
					std::inserter(intersection, intersection.begin())
				);

				if (!intersection.empty()) {//说明跟之前的元素有相同的 那么就在原来的数据中插入
					foundDuplicate = true;
					itemSet.insert(commonKeys.begin(), commonKeys.end());
					break;
				}
			}
			//说明跟之前的元素没有相同的 那么就新建一个数组插入
			if (!foundDuplicate) {
				res.push_back(commonKeys);
			}
		}
	}

	
	int n = 1;
    for(const auto & hashContainer : res)
    {
        // 收集带时间戳的交易哈希
        std::vector<std::pair<uint64_t, std::string>> tx_with_timestamp;
        for(const auto & hash : hashContainer)
        {
            uint64_t tx_time = packDispatchDependent.hash_tx.at(hash).time();
            tx_with_timestamp.emplace_back(tx_time, hash);
        }

        // 按时间戳排序（时间戳相同时按哈希排序保证确定性）
        std::sort(tx_with_timestamp.begin(), tx_with_timestamp.end(),
                  [](const auto& a, const auto& b) {
                      if (a.first != b.first) return a.first < b.first;
                      return a.second < b.second;
                  });

        // 按时间戳顺序添加到map
        for(const auto& [timestamp, hash] : tx_with_timestamp)
        {
			//无依赖合约
			if(hashContainer.size() == 1)
			{
				nonContractTxMap_[hash] = packDispatchDependent.hash_tx.at(hash);
			}
			else
			{
				dependentContractTxMap_[n].emplace(hash, packDispatchDependent.hash_tx.at(hash));
			}
        }
		n++;
    }
    return ;
}
