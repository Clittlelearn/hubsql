﻿#include "ca/dispatchtx.h"
#include "include/logging.h"
#include "net.pb.h"
#include "net/peer_node.h"
#include "net/interface.h"
#include "utils/vrf_selection.h"
#include "utils/vrf_trace.h"
#include "utils/magic_singleton.h"
#include "ca/algorithm.h"
#include "ca/dispatch_snapshot_policy.h"
#include "db/db_api.h"
#include <nlohmann/json.hpp>
#include <algorithm>
#include <map>
#include <string>
#include <unordered_map>
#include <utility>
#include <random>

namespace {

constexpr char kStageDispatchContractPackagerCreate[] = "dispatch_contract_packager_create";

/**
 * @brief 从交易中提取预估Gas值
 * 
 * @param tx 交易对象
 * @return uint64_t 预估Gas值，如果未找到则返回0
 * 
 * 规则：
 * - 合约部署：从 vout[].addr == VirtualDeployContractBurnGas 的 value 获取
 * - 合约调用：从 vout[].addr == VirtualCallContractBurnGas 的 value 获取
 * - 普通交易：返回0（不受Gas过滤影响）
 */
uint64_t getTxEstimatedGas(const CTransaction& tx) {
    for (const auto& utxo : tx.utxos()) {
        for (const auto& vout : utxo.vout()) {
            // 合约部署使用 VirtualDeployContractBurnGas
            if (vout.addr() == global::ca::kVirtualDeploymentContractAddress) {
                return vout.value();
            }
            // 合约调用使用 VirtualCallContractBurnGas
            if (vout.addr() == global::ca::VIRTUAL_CALL_CONTRACT_ADDR) {
                return vout.value();
            }
        }
    }
    return 0;  // 没有找到预估Gas，返回0（保守处理）
}

std::string ShortTraceId(const std::string& value)
{
    if (value.empty())
    {
        return "unknown";
    }
    return value.size() <= 12 ? value : value.substr(0, 12);
}

std::string MakeContractPackagerRoundId(const std::string& allTxHashes, const uint64_t utcTime)
{
    return std::string("contract-batch:") + ShortTraceId(Getsha256Hash(allTxHashes)) + "@" + std::to_string(utcTime);
}

std::string FindDependencyRoot(std::unordered_map<std::string, std::string>& parent, const std::string& txHash)
{
    auto it = parent.find(txHash);
    if (it == parent.end())
    {
        parent.emplace(txHash, txHash);
        return txHash;
    }

    if (it->second == txHash)
    {
        return txHash;
    }

    it->second = FindDependencyRoot(parent, it->second);
    return it->second;
}

void UnionDependencyTx(std::unordered_map<std::string, std::string>& parent,
                       const std::string& left,
                       const std::string& right)
{
    const std::string leftRoot = FindDependencyRoot(parent, left);
    const std::string rightRoot = FindDependencyRoot(parent, right);
    if (leftRoot != rightRoot)
    {
        parent[rightRoot] = leftRoot;
    }
}

}  // namespace

ContractDispatcher::ContractDispatcher() = default;

ContractDispatcher::~ContractDispatcher() = default;

void ContractDispatcher::AddContractInfo(const std::string& contract_hash, const std::vector<std::string>& dependent_addresses) {
    MagicSingleton<DependencyManager>::GetInstance()->AddContractInfo(contract_hash, dependent_addresses);
}

void ContractDispatcher::AddContractMessageRequest(const std::string& contract_hash, const ContractTxMsgReq& msg) {
    MagicSingleton<DependencyManager>::GetInstance()->AddMessageRequest(contract_hash, msg);
}

void ContractDispatcher::AddContractRequest(const std::string& contract_hash, const std::vector<std::string>& dependent_contracts, const ContractTxMsgReq& msg) {
    MagicSingleton<DependencyManager>::GetInstance()->AddContractRequest(contract_hash, dependent_contracts, msg);
}

void ContractDispatcher::Process() {
    MagicSingleton<TimerProcessor>::GetInstance()->Start();
}

void ContractDispatcher::SetTimeValue(const uint64_t& new_value) {
    MagicSingleton<TimerProcessor>::GetInstance()->SetTimeValue(new_value);
}

void DependencyManager::AddContractInfo(const std::string& contract_hash, const std::vector<std::string>& dependent_contracts) {
    std::unique_lock<std::mutex> locker(dep_mutex_);
    contract_dep_cache_[contract_hash] = dependent_contracts;
    
    // 在添加依赖信息后立即广播这个依赖
    locker.unlock();
    // BroadcastAddedDependency(contract_hash, dependent_contracts);
}

void DependencyManager::AddMessageRequest(const std::string& contract_hash, const ContractTxMsgReq& msg) {
    std::unique_lock<std::mutex> locker(msg_mutex_);
    TxMsgReq txmsg = msg.txmsgreq();
    contract_msg_cache_[contract_hash] = txmsg;
}

void DependencyManager::AddContractRequest(const std::string& contract_hash, const std::vector<std::string>& dependent_addresses, const ContractTxMsgReq& msg) {
    {
        std::scoped_lock lock(dep_mutex_, msg_mutex_);
        contract_dep_cache_[contract_hash] = dependent_addresses;
        contract_msg_cache_[contract_hash] = msg.txmsgreq();
    }

    DEBUGLOG("Contract request cached atomically, tx_hash:{}, dependency_count:{}", contract_hash, dependent_addresses.size());
    // BroadcastAddedDependency(contract_hash, dependent_addresses);
}

std::vector<std::vector<TxMsgReq>> DependencyManager::GetDependentData() {
    std::unordered_map<std::string, std::vector<std::string>> dep_cache;
    std::unordered_map<std::string, TxMsgReq> msg_cache;
    {
        std::scoped_lock lock(dep_mutex_, msg_mutex_);
        dep_cache = contract_dep_cache_;
        msg_cache = contract_msg_cache_;
    }

    std::unordered_map<std::string, std::string> parent;
    for (const auto& [txHash, _] : dep_cache) {
        parent.emplace(txHash, txHash);
    }
    for (const auto& [txHash, _] : msg_cache) {
        parent.emplace(txHash, txHash);
    }

    // Build connected components by dependency address. Shared dependencies
    // and chained dependencies must be dispatched to the same contract packager
    // so they execute in one ordered contract-state context.
    std::unordered_map<std::string, std::string> dependency_owner;
    for (const auto& [txHash, dependencies] : dep_cache) {
        std::unordered_set<std::string> unique_dependencies;
        for (const auto& dependency : dependencies) {
            if (dependency.empty() || !unique_dependencies.insert(dependency).second) {
                continue;
            }

            auto owner = dependency_owner.find(dependency);
            if (owner == dependency_owner.end()) {
                dependency_owner.emplace(dependency, txHash);
            } else {
                UnionDependencyTx(parent, txHash, owner->second);
            }
        }
    }

    std::map<std::string, std::vector<std::pair<std::string, TxMsgReq>>> grouped_by_root;
    for (const auto& [txHash, txMsg] : msg_cache) {
        const std::string root = FindDependencyRoot(parent, txHash);
        grouped_by_root[root].emplace_back(txHash, txMsg);
    }

    std::vector<std::vector<TxMsgReq>> grouped_msgs;
    for (auto& [root, tx_entries] : grouped_by_root) {
        std::sort(tx_entries.begin(), tx_entries.end(), [](const auto& left, const auto& right) {
            return left.first < right.first;
        });

        std::vector<TxMsgReq> msg_vec;
        msg_vec.reserve(tx_entries.size());
        for (const auto& [_, txMsg] : tx_entries) {
            msg_vec.push_back(txMsg);
        }
        if (!msg_vec.empty()) {
            DEBUGLOG("Dependency group built, root:{}, tx_count:{}", root, msg_vec.size());
            grouped_msgs.push_back(msg_vec);
        }
    }
    return grouped_msgs;
}

std::vector<std::vector<TxMsgReq>> DependencyManager::GroupData(const std::vector<std::vector<TxMsgReq>>& tx_vectors) {
    constexpr int PARTS = 8;
    size_t size = tx_vectors.size();
    std::vector<std::vector<TxMsgReq>> grouped;
    if (size <= PARTS) {
        grouped = tx_vectors;
    } else {
        size_t per_part = size / PARTS;
        size_t remain = size % PARTS;
        size_t index = 0;
        for (int i = 0; i < PARTS; ++i) {
            std::vector<TxMsgReq> part;
            size_t end = index + per_part;
            for (size_t j = index; j < end; ++j) {
                part.insert(part.end(), tx_vectors[j].begin(), tx_vectors[j].end());
            }
            index = end;
            if (remain > 0) {
                size_t extra_end = index + remain;
                for (size_t j = index; j < extra_end; ++j) {
                    part.insert(part.end(), tx_vectors[j].begin(), tx_vectors[j].end());
                }
                index = extra_end;
                remain = 0;
            }
            grouped.push_back(std::move(part));
        }
    }
    return grouped;
}

bool DependencyManager::HasDuplicate(const std::vector<std::string>& vec1, const std::vector<std::string>& vec2) {
    std::unordered_set<std::string> dep_set(vec1.begin(), vec1.end());
    for (const auto& s : vec2) {
        if (dep_set.count(s) > 0) {
            return true;
        }
    }
    return false;
}

int MessageDispatcher::DistributionContractTransactionRequest(std::multimap<std::string, ContractDispatcher::MsgInfo>& distribution,
                                                              const std::vector<std::vector<TxMsgReq>>& grouped_data) {
    for (const auto& msg_container : grouped_data) {
        // 1. 解析所有交易
        std::vector<std::pair<CTransaction, TxMsgReq>> parsed_txs;
        for (const auto& tx_msg : msg_container) {
            CTransaction tx;
            if (!tx.ParseFromString(tx_msg.txmsginfo().tx())) {
                ERRORLOG("Failed to parse transaction");
                continue;
            }
            parsed_txs.emplace_back(tx, tx_msg);
        }

        if (parsed_txs.empty()) {
            WARNLOG("No valid transactions in group");
            continue;
        }

        // 2. 按时间排序（保证早的交易优先）
        std::sort(parsed_txs.begin(), parsed_txs.end(),
            [](const auto& a, const auto& b) { return a.first.time() < b.first.time(); });

        // 3. Gas过滤：累计Gas，抛弃超限的晚交易
        uint64_t total_gas = 0;
        uint64_t gas_limit = global::ca::kBlockGasLimit * global::ca::kGasLimitBufferRatio;
        std::vector<TxMsgReq> filtered_tx_msgs;
        std::multimap<uint64_t, std::string> tx_hash_time;

        for (const auto& [tx, tx_msg] : parsed_txs) {
            uint64_t tx_gas = getTxEstimatedGas(tx);
            if (total_gas + tx_gas > gas_limit) {
                WARNLOG("Gas limit exceeded, dropping tx: {}, total_gas={}, tx_gas={}, limit={}",
                        tx.hash(), total_gas, tx_gas, gas_limit);
                break;  // 抛弃这个及后面所有交易（已按时间排序）
            }
            total_gas += tx_gas;
            filtered_tx_msgs.push_back(tx_msg);
            tx_hash_time.emplace(tx.time(), tx.hash());
        }

        if (filtered_tx_msgs.empty()) {
            WARNLOG("All transactions in group dropped due to gas limit");
            continue;
        }

        DEBUGLOG("Gas filter: original_count={}, filtered_count={}, total_gas={}, limit={}",
                 parsed_txs.size(), filtered_tx_msgs.size(), total_gas, gas_limit);

        // 3.5 Insert EVIDENCE/PUNISHMENT system transactions (no gas accumulation)
        {
            auto evidenceTxs = MagicSingleton<SlashEvidencePool>::GetInstance()->buildEvidenceTransactions();
            auto punishmentTxs = MagicSingleton<SlashEvidencePool>::GetInstance()->buildPunishmentTransactions();

            for (auto& sysTx : evidenceTxs)
            {
                CTransaction tx;
                if (tx.ParseFromString(sysTx.txmsginfo().tx()))
                {
                    filtered_tx_msgs.push_back(sysTx);
                    tx_hash_time.emplace(tx.time(), tx.hash());
                }
            }
            for (auto& sysTx : punishmentTxs)
            {
                CTransaction tx;
                if (tx.ParseFromString(sysTx.txmsginfo().tx()))
                {
                    filtered_tx_msgs.push_back(sysTx);
                    tx_hash_time.emplace(tx.time(), tx.hash());
                }
            }

            if (!evidenceTxs.empty() || !punishmentTxs.empty())
            {
                DEBUGLOG("[SLASH] Inserted {} EVIDENCE + {} PUNISHMENT system transactions",
                         evidenceTxs.size(), punishmentTxs.size());
            }

            // MALICIOUS_REPORTING is reserved until it has deterministic on-chain payload verification.
        }

        // 4. 用过滤后的交易计算hash_concat（VRF输入）
        std::string hash_concat;
        for (const auto& [timestamp, hash] : tx_hash_time) {
            hash_concat += hash;
        }
        std::string input_hash = Getsha256Hash(hash_concat);
        uint64_t max_time = tx_hash_time.empty() ? 0 : tx_hash_time.rbegin()->first;

        // 5. VRF选择打包者
        std::string pack_addr;
        const std::string selectorAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
        int ret = FindContractPackNode(input_hash, max_time, pack_addr, selectorAddr);
        if (ret != 0) {
            ERRORLOG("Find pack node failed: {}", ret);
            continue;
        }

        // 6. 存储过滤后的交易
        ContractDispatcher::MsgInfo info;
        info.tx_msg_req = std::move(filtered_tx_msgs);
        distribution.emplace(pack_addr, info);
    }
    if (distribution.empty()) {
        ERRORLOG("Distribution map is empty");
        return -3;
    }
    return 0;
}

int MessageDispatcher::SendTransactionInfoRequest(const std::string& packager, std::vector<TxMsgReq>& tx_msgs) {
    // 关键日志：追踪分发者发送行为，用于分析多节点向同一打包者发送导致超限
    DEBUGLOG("DISPATCHER_SEND: To packager={}, tx_count={}", packager, tx_msgs.size());

    DEBUGLOG("=== SendTransactionInfoRequest START ===");
    DEBUGLOG("Sending transaction info request to packager: {}, tx_count: {}", packager, tx_msgs.size());
    ContractPackagerMsg msg;
    msg.set_version(ohi::GetVersion());


    // 解析所有交易并存储hash和时间戳，使用multimap自动按时间戳排序（支持相同时间戳）
    std::multimap<uint64_t, std::string> tx_hash_time;
    for (const auto& tx_msg : tx_msgs) {
        CTransaction tx;
        if (!tx.ParseFromString(tx_msg.txmsginfo().tx())) {
            ERRORLOG("Failed to parse transaction");
            return -1;
        }
        tx_hash_time.emplace(tx.time(), tx.hash());
    }
    
    // 按排序后的顺序连接hash
    std::string hash_concat;
    for (const auto& [timestamp, hash] : tx_hash_time) {
        hash_concat += hash;
    }
    std::string input_hash = Getsha256Hash(hash_concat);
    ERRORLOG("[DEBUG-VRF] DISPATCHER: tx_count={}, input_hash={}", tx_hash_time.size(), input_hash.substr(0, 16));
    
    // 将交易添加到消息中
    for (auto& msg_req : tx_msgs) {
        *msg.add_txmsgreq() = msg_req;
    }
    DEBUGLOG("Added {} transactions to ContractPackagerMsg", msg.txmsgreq_size());

    std::string owner = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    const uint64_t max_time = tx_hash_time.empty() ? 0 : tx_hash_time.rbegin()->first;
    std::vector<std::string> candidates;
    if (!MagicSingleton<VRFConsensusNode>::GetInstance()->extractPackagerVRFData(candidates, max_time)) {
        ERRORLOG("extractPackagerVRFData failed when building ContractPackagerMsg");
        return -2;
    }

    std::vector<std::string> selected;
    std::string selectionVrf;
    std::string error;
    const std::string roundId = MakeContractPackagerRoundId(input_hash, max_time);
    const std::string publicInput = Getsha256Hash(std::string("contract-packager-input-v1|") + std::to_string(max_time) + "|" + input_hash);
    const std::string inputHash = Getsha256Hash(publicInput);
    if (!ohi::vrf::BuildSelectionProof(ohi::vrf::kContractPackagerRole,
                                      owner,
                                      candidates,
                                      publicInput,
                                      1,
                                      selected,
                                      selectionVrf,
                                      &error)) {
        ohi::vrf::trace::LogCreateFailure("CONTRACT_PACKAGER", kStageDispatchContractPackagerCreate, roundId, owner, packager, error);
        ERRORLOG("BuildSelectionProof(contract_packager) failed, error: {}", error);
        return -3;
    }

    if (selected.size() != 1 || selected.front() != packager) {
        ohi::vrf::trace::LogCreateFailure("CONTRACT_PACKAGER", kStageDispatchContractPackagerCreate, roundId, owner, packager, "contract packager selection proof does not match the target packager");
        ERRORLOG("Contract packager selection proof does not match the target packager, expected:{}, actual:{}", packager, selected.empty() ? "" : selected.front());
        return -4;
    }

    ohi::vrf::SelectionProof proof;
    if (!ohi::vrf::ParseSelectionProof(selectionVrf, proof, &error)) {
        ohi::vrf::trace::LogCreateFailure("CONTRACT_PACKAGER", kStageDispatchContractPackagerCreate, roundId, owner, packager, std::string("failed to parse locally created proof: ") + error);
        ERRORLOG("ParseSelectionProof(contract_packager) failed, error: {}", error);
        return -5;
    }

    ohi::vrf::trace::LogCreate("CONTRACT_PACKAGER",
                              kStageDispatchContractPackagerCreate,
                              roundId,
                              owner,
                              packager,
                              selected,
                              candidates.size(),
                              inputHash,
                              proof);
    msg.set_selection_vrf(selectionVrf);

    if (owner == packager) {
        DEBUGLOG("Owner and packager are the same: {}", owner);
        auto send_txmsg = std::make_shared<ContractPackagerMsg>(msg);
        MsgData msgdata;
        handleContractPackagerMessage(send_txmsg, msgdata);
        return 0;
    }
    NetSendMessage<ContractPackagerMsg>(packager, msg, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
    return 0;
}

void TimerProcessor::Start() {
    running_ = true;
    timer_thread_ = std::thread(&TimerProcessor::ProcessingFunc, this);
    timer_thread_.detach();
}

void TimerProcessor::Stop() {
    running_ = false;
    timer_cv_.notify_all();
}

void TimerProcessor::SetTimeValue(uint64_t value) {
    std::unique_lock<std::mutex> lock(timer_mutex_);
    if (time_value_ == 0) {
        time_value_ = value;
    }
    timer_cv_.notify_all();
}

void TimerProcessor::ProcessingFunc() {
    DEBUGLOG("TimerProcessor::ProcessingFunc thread started");
    
    uint64_t time_baseline = 0;
    while (running_) {
        {
            std::unique_lock<std::mutex> lock(timer_mutex_);
            if (timer_cv_.wait_for(lock, std::chrono::seconds(1), [this]{ return !running_; })) {
                DEBUGLOG("TimerProcessor::ProcessingFunc thread exited: reason=running_ set to false");
                break;
            }
        }

        time_value_ += 1000000;

        if (time_baseline == 0) {
            time_baseline = MagicSingleton<TimeUtil>::GetInstance()->getTimestampPerUnit(time_value_);
        }

        if (time_value_ >= time_baseline + kContractWaitingTime) {
            auto dependent_data = MagicSingleton<DependencyManager>::GetInstance()->GetDependentData();
            if (dependent_data.empty()) {
                continue;
            }

            auto grouped_data = MagicSingleton<DependencyManager>::GetInstance()->GroupData(dependent_data);
            if (grouped_data.empty()) {
                ERRORLOG("+++++++++++++++++ grouped_data is empty");
                continue;
            }

            std::multimap<std::string, ContractDispatcher::MsgInfo> distribution;
            int ret = MagicSingleton<MessageDispatcher>::GetInstance()->DistributionContractTransactionRequest(distribution, grouped_data);
            if (ret != 0) {
                ERRORLOG("++++++++++++++++ distributionContractTransactionRequest error ret :{} ++++++++++++++++++", ret);
                continue;
            }

            std::vector<TxMsgReq> handedOffRequests;
            for (auto& item : distribution) {
                DEBUGLOG("Processing distribution item for packager: {}, Number of transactions: {}", item.first, item.second.tx_msg_req.size());
                DEBUGLOG("Sending transaction request to packager: {}", item.first);
                //增加 log 以查询打包者 和 tx hash
                DEBUGLOG("-0-0-0-0-0-0-0-0- send packager : {}, Number of "
                         "transactions: {} ",
                         item.first, item.second.tx_msg_req.size());
                std::cout << "-0-0-0-0-0-0-0-0- send packager " << item.first
                          << "number of transactions"
                          << item.second.tx_msg_req.size() << std::endl;
                for(auto & txmsg : item.second.tx_msg_req)
                {
                    CTransaction contractTx;
                    if (!contractTx.ParseFromString(txmsg.txmsginfo().tx()))
                    {
                        ERRORLOG("Failed to deserialize transaction body!");
                        continue;
                    }
                    DEBUGLOG("send packager : {} , tx hash : {}", item.first, contractTx.hash());
                }
                const int sendRet = MagicSingleton<MessageDispatcher>::GetInstance()->SendTransactionInfoRequest(
                    item.first, item.second.tx_msg_req);
                if (sendRet == 0)
                {
                    handedOffRequests.insert(handedOffRequests.end(), item.second.tx_msg_req.begin(),
                                             item.second.tx_msg_req.end());
                }
                else
                {
                    ERRORLOG("Contract dispatcher handoff failed, packager:{}, ret:{}, retained:{}",
                             item.first, sendRet, item.second.tx_msg_req.size());
                }
            }

            MagicSingleton<DependencyManager>::GetInstance()->RemoveProcessed(handedOffRequests);
            time_baseline = 0;
            time_value_ = 0;
        }
    }
    
    DEBUGLOG("TimerProcessor::ProcessingFunc thread exited: normal completion");
}

void DependencyManager::RemoveProcessed(const std::vector<TxMsgReq>& processed) {
    std::scoped_lock lock(dep_mutex_, msg_mutex_);
    size_t removed = 0;
    for (const auto& snapshotMsg : processed)
    {
        CTransaction snapshotTx;
        if (!snapshotTx.ParseFromString(snapshotMsg.txmsginfo().tx()) || snapshotTx.hash().empty())
            continue;
        const auto current = contract_msg_cache_.find(snapshotTx.hash());
        if (current == contract_msg_cache_.end() ||
            !dispatch_snapshot::CanRemove(snapshotMsg.SerializeAsString(), current->second.SerializeAsString(), true))
            continue;
        contract_msg_cache_.erase(current);
        contract_dep_cache_.erase(snapshotTx.hash());
        ++removed;
    }
    DEBUGLOG("Contract dispatcher snapshot removal, handed_off:{}, removed:{}, retained:{}",
             processed.size(), removed, contract_msg_cache_.size());
}

// std::map<std::string, std::vector<std::string>> DependencyManager::GetAllDependenciesWithTxHashes() {
//     // 创建依赖地址到交易哈希的映射
//     std::map<std::string, std::vector<std::string>> dependency_tx_map;
    
//     // 创建缓存的副本，避免在持有锁的同时进行耗时操作
//     std::unordered_map<std::string, std::vector<std::string>> dep_cache_copy;
//     std::unordered_map<std::string, TxMsgReq> msg_cache_copy;
//     std::unordered_map<std::string, std::vector<std::string>> dependency_tx_hashes_copy;
    
//     // 在单独的作用域内获取锁并创建副本
//     {
//         std::lock_guard<std::mutex> lock1(dep_mutex_);
//         std::lock_guard<std::mutex> lock2(msg_mutex_);
//         std::lock_guard<std::shared_mutex> lock3(dependency_tx_mutex_);
//         uint64_t now = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
//         PruneExpiredDependencyHashes(now);
//         PruneClearedDependencyHashes(now);
//         dep_cache_copy = contract_dep_cache_;
//         msg_cache_copy = contract_msg_cache_;
//         dependency_tx_hashes_copy = dependency_tx_hashes_;
//     }
    
//     // 首先从合约依赖缓存中获取依赖信息
//     for (const auto& [contract_hash, deps] : dep_cache_copy) {
//         // 获取该合约的交易信息
//         auto msg_it = msg_cache_copy.find(contract_hash);
//         if (msg_it != msg_cache_copy.end()) {
//             // 解析交易获取哈希
//             CTransaction tx;
//             if (tx.ParseFromString(msg_it->second.txmsginfo().tx())) {
//                 std::string tx_hash = tx.hash();
                
//                 // 将交易哈希添加到每个依赖地址的列表中
//                 for (const auto& dep_addr : deps) {
//                     if (!dep_addr.empty()) {
//                         dependency_tx_map[dep_addr].push_back(tx_hash);
//                         DEBUGLOG("Adding dependency from cache: {} -> {}", dep_addr, tx_hash);
//                     }
//                 }
//             }
//         }
//     }
    
//     // 然后从依赖交易哈希映射中获取依赖信息
//     for (const auto& [dep_addr, tx_hashes] : dependency_tx_hashes_copy) {
//         if (dep_addr.empty() || tx_hashes.empty()) {
//             continue;
//         }
        
//         // 合并交易哈希列表，避免重复
//         auto& existing_hashes = dependency_tx_map[dep_addr];
//         for (const auto& tx_hash : tx_hashes) {
//             if (!tx_hash.empty() && std::find(existing_hashes.begin(), existing_hashes.end(), tx_hash) == existing_hashes.end()) {
//                 existing_hashes.push_back(tx_hash);
//                 DEBUGLOG("Adding dependency from tx hashes map: {} -> {}", dep_addr, tx_hash);
//             }
//         }
//     }
    
//     DEBUGLOG("Total unique dependency addresses: {}", dependency_tx_map.size());
//     return dependency_tx_map;
// }

// std::set<std::string> DependencyManager::GetAllUniqueDependencies() const {
//     std::unique_lock<std::mutex> lock(dep_mutex_);
//     std::set<std::string> all_dependencies;
//     for (const auto& pair : contract_dep_cache_) {
//         all_dependencies.insert(pair.second.begin(), pair.second.end());
//     }
//     return all_dependencies;
// }

// void MessageDispatcher::BroadcastDependencies() {
//     // 获取依赖地址到交易哈希的映射
//     auto dependency_tx_map = MagicSingleton<DependencyManager>::GetInstance()->GetAllDependenciesWithTxHashes();
    
//     if (dependency_tx_map.empty()) {
//         DEBUGLOG("No dependencies to broadcast");
//         return;
//     }
    
//     DEBUGLOG("Broadcasting dependencies with transaction hashes");
//     ContractDependencyBroadcastMsg broadcast_msg;
//     broadcast_msg.set_version(ohi::GetVersion());
    
//     // 添加所有依赖信息到广播消息
//     for (const auto& [dep_addr, tx_hashes] : dependency_tx_map) {
//         if (tx_hashes.empty()) {
//             continue; // 跳过没有交易哈希的依赖
//         }
        
//         auto* dep_info = broadcast_msg.add_dependencies();
//         dep_info->set_dependencyaddress(dep_addr);
        
//         // 添加所有关联的交易哈希
//         for (const auto& tx_hash : tx_hashes) {
//             dep_info->add_txhashes(tx_hash);
//         }
        
//         DEBUGLOG("Adding dependency {} with {} transaction hashes", dep_addr, tx_hashes.size());
//     }
    
//     // 如果没有添加任何依赖信息，则不广播
//     if (broadcast_msg.dependencies_size() == 0) {
//         DEBUGLOG("@@@@ No valid dependencies to broadcast");
//         return;
//     }
    
//     std::string owner = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
//     std::string serialized = broadcast_msg.SerializeAsString();
//     std::string serialized_hash = Getsha256Hash(serialized);
//     std::string signature;
//     std::string pub;
    
//     if (TxHelper::Sign(owner, serialized_hash, signature, pub) == 0) {
//         CSign* sign = broadcast_msg.mutable_sign();
//         sign->set_sign(signature);
//         sign->set_pub(pub);
        
//         auto nodes = MagicSingleton<PeerNode>::GetInstance()->GetNodelist(NODE_ALL, true);
//         int broadcast_count = 0;
        
//         for (const auto& node : nodes) {
//             if (node.address != owner) {
//                 bool success = NetSendMessage(node.address, broadcast_msg, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::kPriorityLow0);
//                 if (success) {
//                     broadcast_count++;
//                 }
//             }
//         }
        
//         DEBUGLOG("Successfully broadcasted dependency information to {} nodes", broadcast_count);
//     } else {
//         ERRORLOG("Failed to sign broadcast message");
//     }
// }


// void DependencyManager::PruneClearedDependencyHashes(uint64_t now) {
//     for (auto it = cleared_dependency_hashes_.begin(); it != cleared_dependency_hashes_.end(); ) {
//         if (now >= it->second + kClearedDependencyRetention) {
//             it = cleared_dependency_hashes_.erase(it);
//         } else {
//             ++it;
//         }
//     }
// }

// void DependencyManager::RememberClearedDependencyHash(const std::string& tx_hash) {
//     if (tx_hash.empty()) {
//         return;
//     }

//     uint64_t now = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
//     PruneClearedDependencyHashes(now);
//     cleared_dependency_hashes_[tx_hash] = now;
// }

// bool DependencyManager::IsClearedDependencyHash(const std::string& tx_hash) const {
//     return cleared_dependency_hashes_.find(tx_hash) != cleared_dependency_hashes_.end();
// }

// void DependencyManager::RememberDependencyHash(const std::string& tx_hash, uint64_t now) {
//     if (tx_hash.empty()) {
//         return;
//     }

//     dependency_hash_times_[tx_hash] = now;
// }

// void DependencyManager::PruneExpiredDependencyHashes(uint64_t now) {
//     for (auto dep_it = dependency_tx_hashes_.begin(); dep_it != dependency_tx_hashes_.end(); ) {
//         auto& hashes = dep_it->second;
//         hashes.erase(std::remove_if(hashes.begin(), hashes.end(), [this, now, &dep_it](const std::string& tx_hash) {
//             auto time_it = dependency_hash_times_.find(tx_hash);
//             if (time_it == dependency_hash_times_.end()) {
//                 DEBUGLOG("@@@@ Prune dependency hash {} for {} because timestamp is missing", tx_hash, dep_it->first);
//                 return true;
//             }

//             if (now >= time_it->second + kDependencyHashTtl) {
//                 DEBUGLOG("@@@@ Prune expired dependency hash {} for {}", tx_hash, dep_it->first);
//                 dependency_hash_times_.erase(time_it);
//                 return true;
//             }

//             return false;
//         }), hashes.end());

//         if (hashes.empty()) {
//             dep_it = dependency_tx_hashes_.erase(dep_it);
//         } else {
//             ++dep_it;
//         }
//     }
// }

// void DependencyManager::BroadcastAddedDependency(const std::string& contract_hash, const std::vector<std::string>& dependent_addresses) {
//     if (dependent_addresses.empty()) {
//         DEBUGLOG("@@@@ No dependencies to broadcast for contract {}", contract_hash);
//         return;
//     }
    
//     DEBUGLOG("@@@@ Broadcasting added dependency for contract {} with {} addresses", contract_hash, dependent_addresses.size());
    
//     // 先本地存储依赖
//     {
//         std::unique_lock<std::shared_mutex> lock(dependency_tx_mutex_);
//         uint64_t now = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
//         PruneExpiredDependencyHashes(now);
//         PruneClearedDependencyHashes(now);
//         if (IsClearedDependencyHash(contract_hash)) {
//             DEBUGLOG("@@@@ Skip broadcasting cleared dependency tx hash {}", contract_hash);
//             return;
//         }

//         for (const auto& dep_addr : dependent_addresses) {
//             if (dep_addr.empty()) continue;
            
//             if (dependency_tx_hashes_.find(dep_addr) == dependency_tx_hashes_.end()) {
//                 dependency_tx_hashes_[dep_addr] = {};
//             }
            
//             auto& existing_hashes = dependency_tx_hashes_[dep_addr];
//             if (std::find(existing_hashes.begin(), existing_hashes.end(), contract_hash) == existing_hashes.end()) {
//                 existing_hashes.push_back(contract_hash);
//                 DEBUGLOG("@@@@ Locally added dependency {} with tx hash {}", dep_addr, contract_hash);
//             }
//             RememberDependencyHash(contract_hash, now);
//         }
//     }
    
//     ContractDependencyBroadcastMsg broadcast_msg;
//     broadcast_msg.set_version(ohi::GetVersion());
    
//     for (const auto& dep_addr : dependent_addresses) {
//         if (dep_addr.empty()) continue;
//         auto* dep_info = broadcast_msg.add_dependencies();
//         dep_info->set_dependencyaddress(dep_addr);
//         dep_info->add_txhashes(contract_hash);
//         DEBUGLOG("@@@@ Adding dependency {} with tx hash {}", dep_addr, contract_hash);
//     }
    
//     if (broadcast_msg.dependencies_size() == 0) {
//         DEBUGLOG("No valid dependencies to broadcast");
//         return;
//     }
    
//     std::string owner = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
//     std::string serialized = broadcast_msg.SerializeAsString();
//     std::string serialized_hash = Getsha256Hash(serialized);
//     std::string signature;
//     std::string pub;
    
//     if (TxHelper::Sign(owner, serialized_hash, signature, pub) == 0) {
//         CSign* sign = broadcast_msg.mutable_sign();
//         sign->set_sign(signature);
//         sign->set_pub(pub);
        
//         auto nodes = MagicSingleton<PeerNode>::GetInstance()->GetNodelist(NODE_ALL, true);
//         int broadcast_count = 0;
        
//         for (const auto& node : nodes) {
//             if (node.address != owner) {
//                 bool success = NetSendMessage(node.address, broadcast_msg, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::kPriorityLow0);
//                 if (success) {
//                     broadcast_count++;
//                 }
//             }
//         }
        
//         DEBUGLOG("@@@@ Successfully broadcasted added dependency to {} nodes", broadcast_count);
//     } else {
//         ERRORLOG("Failed to sign broadcast message");
//     }
// }


// int DependencyManager::HandleContractDependencyBroadcastMsg(const std::shared_ptr<ContractDependencyBroadcastMsg>& msg, const MsgData &msgData)
// {
//     DEBUGLOG("HandleContractDependencyBroadcastMsg");
//     if (!msg) {
//         ERRORLOG("ContractDependencyBroadcastMsg is null");
//         return -1;
//     }
    
//     if (!msg->has_sign())
//     {
//         ERRORLOG("ContractDependencyBroadcastMsg missing signature");
//         return -2;
//     }

//     if (0 != Util::IsVersionCompatible(msg->version()))
//     {
//         ERRORLOG("ContractDependencyBroadcastMsg version incompatible");
//         return -3;
//     }

//     // 验证签名
//     CSign sign = msg->sign();
//     std::string pub = sign.pub();
//     std::string signature = sign.sign();
    
//     if (pub.empty() || signature.empty()) {
//         ERRORLOG("ContractDependencyBroadcastMsg has empty public key or signature");
//         return -4;
//     }
    
//     ContractDependencyBroadcastMsg msg_copy = *msg;
//     msg_copy.clear_sign();
//     std::string message_hash = Getsha256Hash(msg_copy.SerializeAsString());
    
//     Account account;
//     if(MagicSingleton<AccountManager>::GetInstance()->getAccountPublicKeyByBytes(pub, account) == false){
//         ERRORLOG("ContractDependencyBroadcastMsg Get public key from bytes failed!");
//         return -5;
//     }

//     if(account.Verify(message_hash, signature) == false)
//     {
//         ERRORLOG("ContractDependencyBroadcastMsg Public key verify sign failed!");
//         return -6;
//     }

//     std::string sender = GenerateAddr(pub);
//     if (sender.empty())
//     {
//         ERRORLOG("ContractDependencyBroadcastMsg failed to get sender address");
//         return -7;
//     }
    
//     // 检查消息中是否包含依赖信息
//     if (msg->dependencies_size() == 0) {
//         DEBUGLOG("ContractDependencyBroadcastMsg from {} contains no dependencies", sender);
//         return 0;
//     }

//     // 存储广播的合约依赖
//     StoreBroadcastDependencies(*msg);
    
//     DEBUGLOG("Successfully processed ContractDependencyBroadcastMsg from {} with {} dependencies", 
//              sender, msg->dependencies_size());
//     return 0;
// }

// void DependencyManager::StoreBroadcastDependencies(const ContractDependencyBroadcastMsg& msg) {
//     std::unique_lock<std::shared_mutex> lock(dependency_tx_mutex_);
//     uint64_t now = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
//     PruneExpiredDependencyHashes(now);
//     PruneClearedDependencyHashes(now);
    
//     // 从消息签名中获取发送者地址
//     std::string sender;
//     if (msg.has_sign()) {
//         std::string pub = msg.sign().pub();
//         sender = GenerateAddr(pub);
//         if (sender.empty()) {
//             ERRORLOG("Failed to get sender address from public key");
//             return;
//         }
//     } else {
//         ERRORLOG("ContractDependencyBroadcastMsg has no signature");
//         return;
//     }
//     DEBUGLOG("@@@@ StoreBroadcastDependencies, sender: {}", sender);
   
//     // 存储广播的依赖
//     for (const auto& dep_info : msg.dependencies()) {
//         std::string dep_addr = dep_info.dependencyaddress();
//         if (dep_addr.empty()) {
//             ERRORLOG("Empty dependency address in broadcast message");
//             continue;
//         }
        
//         // 确保依赖地址在映射中存在，即使没有交易哈希
//         if (dependency_tx_hashes_.find(dep_addr) == dependency_tx_hashes_.end()) {
//             dependency_tx_hashes_[dep_addr] = {};
//         }
        
//         // 记录交易哈希信息
//         if (dep_info.txhashes_size() == 0) {
//             DEBUGLOG("@@@@ No transaction hashes for dependency address: {}", dep_addr);
//             continue;
//         }
        
//         // 合并新的交易哈希到现有列表中
//         auto& existing_hashes = dependency_tx_hashes_[dep_addr];
//         int new_hashes_count = 0;

//         DEBUGLOG("@@@@ Before storing, dependency {} has hashes size: {}", dep_addr, existing_hashes.size());

//         for (const auto& hash : dep_info.txhashes()) {
//             if (hash.empty()) {
//                 continue;
//             }

//             if (IsClearedDependencyHash(hash)) {
//                 DEBUGLOG("@@@@ Skip restored cleared dependency hash {} for dependency {}", hash, dep_addr);
//                 continue;
//             }
            
//             if (std::find(existing_hashes.begin(), existing_hashes.end(), hash) == existing_hashes.end()) {
//                 DEBUGLOG("@@@@ New transaction hash {} for dependency {}", hash, dep_addr);
//                 existing_hashes.push_back(hash);
//                 new_hashes_count++;
//             }
//             RememberDependencyHash(hash, now);
//         }
        
//         DEBUGLOG("@@@@ Stored broadcast dependency: {} from {} with {} new transaction hashes (total: {})", dep_addr, sender, new_hashes_count, existing_hashes.size());
//     }
// }

// bool DependencyManager::CanSendTransaction(const ContractTxMsgReq& msg) {
//     std::unique_lock<std::shared_mutex> dependency_lock(dependency_tx_mutex_);
//     uint64_t now = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
//     PruneExpiredDependencyHashes(now);
//     PruneClearedDependencyHashes(now);

//     // 如果没有依赖地址，直接返回可以发送
//     if (msg.txmsgreq().txmsginfo().contractstoragelist_size() == 0) {
//         DEBUGLOG("@@@@ No dependent addresses in message, can send transaction");
//         return true;
//     }
    
//     CTransaction contractTx;
// 	if (!contractTx.ParseFromString(msg.txmsgreq().txmsginfo().tx()))
// 	{
// 		ERRORLOG("Failed to deserialize transaction body!");
// 		return false;
// 	}

//     std::string tx_hash = contractTx.hash();
//     if (tx_hash.empty()) {
//         ERRORLOG("Transaction hash is empty in message");
//         return false; // 交易哈希为空，不能发送
//     }
    
//     bool can_send = true;
//     DBReader dbReader;
    
//     for (const auto& dependent_identifier : msg.txmsgreq().txmsginfo().contractstoragelist()) {
//         if (dependent_identifier.empty()) {
//             DEBUGLOG("Empty dependent address in message, skipping");
//             continue;
//         }
        
//         DEBUGLOG("@@@@ Checking dependency for address: {}", dependent_identifier);
        
//         // 添加调试信息：打印容器中所有的键
//         DEBUGLOG("@@@@ Current dependency_tx_hashes_ keys:");
//         for (const auto& pair : dependency_tx_hashes_) {
//             DEBUGLOG("@@@@   Key: '{}' (length: {})", pair.first, pair.first.length());
//         }
        
//         auto tx_hashes_it = dependency_tx_hashes_.find(dependent_identifier);
//         if (tx_hashes_it == dependency_tx_hashes_.end()) {
//             DEBUGLOG("@@@@ No transaction hashes found for dependency '{}' (length: {}), can send transaction", dependent_identifier, dependent_identifier.length());
//             continue;
//         }
        
//         if(!tx_hashes_it->second.empty()){
//             can_send = false;
//         }
//     }
    
//     DEBUGLOG("@@@@ Final decision for transaction {}: {}", tx_hash, can_send ? "can send" : "cannot send");
//     return can_send;
// }

// int HandleContractDependencyBroadcastMsg(const std::shared_ptr<ContractDependencyBroadcastMsg> &msg, const MsgData &msgData)
// {
//     DEBUGLOG("HandleContractDependencyBroadcastMsg");
//     if (!msg) {
//         ERRORLOG("Received null ContractDependencyBroadcastMsg");
//         return -1;
//     }
    
//     try {
//         MagicSingleton<DependencyManager>::GetInstance()->HandleContractDependencyBroadcastMsg(msg, msgData);
//         return 0;
//     } catch (const std::exception& e) {
//         ERRORLOG("Exception in HandleContractDependencyBroadcastMsg: {}", e.what());
//         return -2;
//     } catch (...) {
//         ERRORLOG("Unknown exception in HandleContractDependencyBroadcastMsg");
//         return -3;
//     }
// }

void EventManager::Subscribe(const std::string& event, Callback cb) {
    callbacks_[event].push_back(cb);
}

void EventManager::Publish(const std::string& event, const std::string& block_hash) {
    auto it = callbacks_.find(event);
    if (it != callbacks_.end()) {
        for (auto& cb : it->second) {
            cb(block_hash);
        }
    }
}

// DependencyManager::DependencyManager() {
//     MagicSingleton<EventManager>::GetInstance()->Subscribe("TransactionConfirmed", [this](const std::string& tx_hash) {
//         ClearDependency(tx_hash);
//     });
// }

// void DependencyManager::ClearDependency(const std::string& tx_hash) {
//     std::unique_lock<std::shared_mutex> lock(dependency_tx_mutex_);
//     RememberClearedDependencyHash(tx_hash);
//     dependency_hash_times_.erase(tx_hash);

//     // Log current dependencies before clearing
//     DEBUGLOG("@@@@ Before clearing dependency for transaction hash: {}", tx_hash);
//     for (auto it = dependency_tx_hashes_.begin(); it != dependency_tx_hashes_.end(); ) {
//         auto& hashes = it->second;
//         hashes.erase(std::remove(hashes.begin(), hashes.end(), tx_hash), hashes.end());
//         DEBUGLOG("@@@@ After erasing transaction hash {} from address {}, {} hashes remain", tx_hash, it->first, hashes.size());
//         if (hashes.empty()) {
//             DEBUGLOG("@@@@ Erased empty dependency list for address: {}", it->first);
//             it = dependency_tx_hashes_.erase(it);
//         } else {
//             ++it;
//         }
//     }
// }

// === SlashEvidencePool implementation ===

bool SlashEvidencePool::verifyEvidence(const SlashEvidenceMsg& msg)
{
    if (msg.target_addr().empty() || msg.reporter().empty() || msg.evidence_data().empty() || msg.evidence_hash().empty())
    {
        ERRORLOG("[SLASH] Evidence message missing required fields, reporter:{}", msg.reporter());
        return false;
    }

    std::string computedHash = ca_algorithm::CalculateSlashEvidenceHash(std::string(msg.evidence_data().begin(), msg.evidence_data().end()));
    if (computedHash != msg.evidence_hash())
    {
        ERRORLOG("[SLASH] Evidence hash mismatch: expected={}, got={}", msg.evidence_hash(), computedHash);
        return false;
    }

    if (!msg.has_signature() || ca_algorithm::VerifySign(msg.signature(), msg.evidence_hash()) != 0)
    {
        ERRORLOG("[SLASH] Evidence signature verification failed, reporter:{}, hash:{}",
                 msg.reporter(), msg.evidence_hash());
        return false;
    }

    const std::string signerAddr = GenerateAddr(msg.signature().pub());
    if (signerAddr != msg.reporter())
    {
        ERRORLOG("[SLASH] Evidence reporter mismatch, reporter:{}, signer:{}", msg.reporter(), signerAddr);
        return false;
    }

    return true;
}

void SlashEvidencePool::addEvidence(const SlashEvidenceMsg& msg)
{
    std::lock_guard<std::mutex> lock(pool_mutex_);
    if (!verifyEvidence(msg)) return;

    const std::string& evidenceHash = msg.evidence_hash();

    // P3-26: Track reporter stats
    const std::string& reporter = msg.reporter();
    auto& stats = reporterStats_[reporter];
    stats.totalReports++;
    if (stats.windowStart == 0) {
        stats.windowStart = msg.period();
    }

    auto it = pool_.find(evidenceHash);
    if (it != pool_.end())
    {
        // 检查是否已经收集过这个 reporter 的签名（按地址去重）
        const std::string signerAddr = GenerateAddr(msg.signature().pub());
        bool alreadySigned = false;
        for (const auto& existingSig : it->second.signatures) {
            if (GenerateAddr(existingSig.pub()) == signerAddr) {
                alreadySigned = true;
                break;
            }
        }
        
        if (!alreadySigned) {
            it->second.signatures.push_back(msg.signature());
            
            // 检查是否达到共识阈值
            if (!it->second.consensusReached && 
                it->second.signatures.size() >= global::ca::kSlashEvidenceQuorum) {
                it->second.consensusReached = true;
                INFOLOG("[SLASH] Evidence consensus reached: hash={}, signatures={}/{}", 
                        evidenceHash.substr(0, 16), 
                        it->second.signatures.size(), 
                        global::ca::kSlashEvidenceQuorum);
                
                // 更新所有已签名 reporter 的 validReports
                for (const auto& sig : it->second.signatures) {
                    std::string signerAddr = GenerateAddr(sig.pub());
                    auto& signerStats = reporterStats_[signerAddr];
                    signerStats.validReports++;
                }
            }
        }
        return;
    }

    // 新的证据
    EvidenceEntry entry;
    entry.evidence = msg;
    entry.signatures.push_back(msg.signature());
    entry.firstSeenPeriod = msg.period();
    entry.consensusReached = false;
    pool_[evidenceHash] = std::move(entry);
    
    DEBUGLOG("[SLASH] New evidence added: hash={}, reporter={}, signatures=1/{}", 
             evidenceHash.substr(0, 16), reporter, global::ca::kSlashEvidenceQuorum);
}

CTransaction SlashEvidencePool::buildEvidenceTx(const EvidenceEntry& entry)
{
    CTransaction tx;
    tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
    tx.set_type(static_cast<uint32_t>(global::ca::TxType::EVIDENCE));
    tx.set_identity(MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr());
    tx.set_time(std::chrono::duration_cast<std::chrono::microseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count());

    nlohmann::json data;
    data["target_addr"] = entry.evidence.target_addr();
    data["violation_type"] = SlashViolationType_Name(entry.evidence.violation_type());
    data["evidence_hash"] = entry.evidence.evidence_hash();
    data["evidence_data"] = std::string(entry.evidence.evidence_data().begin(), entry.evidence.evidence_data().end());
    tx.set_data(data.dump());

    for (const auto& sig : entry.signatures)
        tx.add_signature()->CopyFrom(sig);

    CTransaction txForHash = tx;
    txForHash.clear_hash();
    tx.set_hash(Getsha256Hash(txForHash.SerializeAsString()));
    return tx;
}

std::vector<TxMsgReq> SlashEvidencePool::buildEvidenceTransactions()
{
    std::vector<TxMsgReq> result;
    std::lock_guard<std::mutex> lock(pool_mutex_);
    DBReader dbReader;

    for (auto it = pool_.begin(); it != pool_.end(); )
    {
        const auto& [hash, entry] = *it;

        // 只构建已经达成共识的证据
        if (!entry.consensusReached) {
            ++it;
            continue;
        }

        // 幂等性检查：如果已经在链上，跳过
        if (DBStatus::DB_SUCCESS == dbReader.hasEvidenceOnChain(hash)) { it = pool_.erase(it); continue; }

        // 构建 EVIDENCE 交易（包含所有签名）
        CTransaction evidenceTx = buildEvidenceTx(entry);
        TxMsgReq txMsg;
        txMsg.set_version("1.0");
        auto* txMsgInfo = txMsg.mutable_txmsginfo();
        txMsgInfo->set_type(1);
        txMsgInfo->set_tx(evidenceTx.SerializeAsString());
        result.push_back(txMsg);

        INFOLOG("[SLASH] Built EVIDENCE tx: hash={}, signatures={}",
                hash.substr(0, 16), entry.signatures.size());

        // 构建完成后从池中移除
        it = pool_.erase(it);
    }
    return result;
}

CTransaction SlashEvidencePool::buildPunishmentTx(const std::string& targetAddr, const std::string& level, const std::string& violationType, const std::string& evidenceRefs)
{
    CTransaction tx;
    tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
    tx.set_type(static_cast<uint32_t>(global::ca::TxType::PUNISHMENT));
    tx.set_identity(MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr());
    tx.set_time(std::chrono::duration_cast<std::chrono::microseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count());

    uint32_t penaltyLevel = std::stoul(level);

    std::vector<std::string> stakeRefs;
    DBReader dbReader;
    if (DBStatus::DB_SUCCESS == dbReader.getStakeUtxoByAddr(targetAddr, "OHI", stakeRefs))
    {
        std::sort(stakeRefs.begin(), stakeRefs.end());
        stakeRefs.erase(std::unique(stakeRefs.begin(), stakeRefs.end()), stakeRefs.end());
    }

    nlohmann::json data;
    data["target_addr"] = targetAddr;
    data["penalty_level"] = penaltyLevel;
    data["violation_type"] = violationType;
    data["evidence_refs"] = evidenceRefs;
    data["punishment_id"] = ca_algorithm::BuildSlashPunishmentId(targetAddr, violationType, penaltyLevel, evidenceRefs);
    data["stake_refs"] = stakeRefs;
    tx.set_data(data.dump());

    CSign* sig = tx.add_signature();
    std::string signData, pubKey;
    CTransaction txForSign = tx;
    txForSign.clear_hash();
    txForSign.clear_signature();
    std::string txHash = Getsha256Hash(txForSign.SerializeAsString());
    TxHelper::Sign(tx.identity(), txHash, signData, pubKey);
    sig->set_sign(signData);
    sig->set_pub(pubKey);

    CTransaction txForHash = tx;
    txForHash.clear_hash();
    tx.set_hash(Getsha256Hash(txForHash.SerializeAsString()));
    return tx;
}

std::vector<TxMsgReq> SlashEvidencePool::buildPunishmentTransactions()
{
    std::vector<TxMsgReq> result;
    DBReader dbReader;
    std::vector<std::string> thresholdAddrs;
    if (DBStatus::DB_SUCCESS != dbReader.getThresholdExceededEntries(thresholdAddrs)) return result;

    for (const auto& addr : thresholdAddrs)
    {
        if (addr.empty()) continue;

        std::string level, violationType, evidenceRefs;
        if (DBStatus::DB_SUCCESS != dbReader.getThresholdDetail(addr, level, violationType, evidenceRefs)) continue;

        uint32_t penaltyLevel = 0;
        try { penaltyLevel = std::stoul(level); } catch (...) { continue; }
        std::string punishmentId = ca_algorithm::BuildSlashPunishmentId(addr, violationType, penaltyLevel, evidenceRefs);
        if (DBStatus::DB_SUCCESS == dbReader.hasPunishmentHistory(punishmentId)) continue;

        CTransaction punishmentTx = buildPunishmentTx(addr, level, violationType, evidenceRefs);
        TxMsgReq txMsg;
        txMsg.set_version("1.0");
        auto* txMsgInfo = txMsg.mutable_txmsginfo();
        txMsgInfo->set_type(1);
        txMsgInfo->set_tx(punishmentTx.SerializeAsString());
        result.push_back(txMsg);
        INFOLOG("[SLASH] Built PUNISHMENT tx for addr:{}, level:{}", addr, level);
    }
    return result;
}

void SlashEvidencePool::cleanup(uint64_t currentPeriod)
{
    std::lock_guard<std::mutex> lock(pool_mutex_);
    for (auto it = pool_.begin(); it != pool_.end(); )
    {
        if (currentPeriod > it->second.firstSeenPeriod + 6)
            it = pool_.erase(it);
        else
            ++it;
    }

    // P3-26: Also clean up old reporter stats (older than 1000 periods)
    for (auto it = reporterStats_.begin(); it != reporterStats_.end(); )
    {
        if (currentPeriod > it->second.windowStart + 1000)
            it = reporterStats_.erase(it);
        else
            ++it;
    }
}

std::vector<std::string> SlashEvidencePool::getMaliciousReporters()
{
    std::vector<std::string> malicious;
    std::lock_guard<std::mutex> lock(pool_mutex_);

    for (const auto& [addr, stats] : reporterStats_)
    {
        // P3-26: If valid rate < 10% AND total reports > 5, mark as malicious
        if (stats.totalReports > global::ca::kSlashAbuseMinReports)
        {
            double validRate = static_cast<double>(stats.validReports) / stats.totalReports;
            if (validRate < global::ca::kSlashAbuseThresholdRate)
            {
                ERRORLOG("[SLASH] Malicious reporter detected: addr={}, totalReports={}, validReports={}, validRate={:.2f}%",
                         addr, stats.totalReports, stats.validReports, validRate * 100);
                malicious.push_back(addr);
            }
        }
    }
    return malicious;
}

SlashEvidencePool::ReporterStats SlashEvidencePool::getReporterStats(const std::string& reporter)
{
    std::lock_guard<std::mutex> lock(pool_mutex_);
    auto it = reporterStats_.find(reporter);
    if (it != reporterStats_.end()) {
        return it->second;
    }
    return ReporterStats{0, 0, 0};
}

// === NodeSlashTracker implementation ===

void NodeSlashTracker::recordDisconnect(const std::string& addr)
{
    DBReadWriter dbWriter;
    uint64_t currentHour = std::chrono::duration_cast<std::chrono::hours>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    uint32_t count = 0;
    dbWriter.getDisconnectCount(addr, currentHour, count);
    count++;
    dbWriter.setDisconnectCount(addr, currentHour, count);
    if (count >= global::ca::kForfeitDisconnectCount)
        ERRORLOG("[SLASH] Node {} disconnects={} in current hour — L2 Forfeit threshold", addr, count);
}

bool NodeSlashTracker::isJailed(const std::string& addr)
{
    DBReader dbReader;
    return DBStatus::DB_SUCCESS == dbReader.isJailed(addr);
}

bool NodeSlashTracker::isTombstoned(const std::string& addr)
{
    DBReader dbReader;
    return DBStatus::DB_SUCCESS == dbReader.isTombstoned(addr);
}

double NodeSlashTracker::checkSignRate(const std::string& addr, uint64_t currentPeriod, uint32_t lookbackPeriods)
{
    DBReader dbReader;
    uint32_t signedCount = 0;
    uint32_t validPeriods = 0;

    for (uint64_t p = currentPeriod - lookbackPeriods; p < currentPeriod; ++p)
    {
        // Check if this node signed in period p
        std::vector<std::string> signAddrs;
        if (DBStatus::DB_SUCCESS == dbReader.getSignAddrByPeriod(p, signAddrs))
        {
            validPeriods++;
            if (std::find(signAddrs.begin(), signAddrs.end(), addr) != signAddrs.end())
            {
                signedCount++;
            }
        }
    }

    if (validPeriods < lookbackPeriods / 2) return -1.0; // Insufficient data
    return static_cast<double>(signedCount) / validPeriods;
}

// === Message handlers ===

// 独立验证违规事实（分发者不盲从其他节点）
static bool IndependentlyVerifyViolation(const SlashEvidenceMsg& msg)
{
    auto violationType = msg.violation_type();
    std::string evidenceDataStr(msg.evidence_data().begin(), msg.evidence_data().end());
    
    try {
        auto evidenceData = nlohmann::json::parse(evidenceDataStr);
        
        switch (violationType) {
            case SlashViolationType::DOUBLE_SIGN_VRF: {
                // 独立验证：检查 validatedVRfs 中是否存在冲突签名
                std::string seed = evidenceData.value("seed", "");
                std::string existingSig = evidenceData.value("existing_sig", "");
                std::string newSig = evidenceData.value("new_sig", "");
                
                // 如果两个签名都存在且不同，则验证通过
                if (!existingSig.empty() && !newSig.empty() && existingSig != newSig) {
                    DEBUGLOG("[SLASH] Independent verification passed: DOUBLE_SIGN_VRF for seed={}", seed);
                    return true;
                }
                ERRORLOG("[SLASH] Independent verification failed: DOUBLE_SIGN_VRF signatures not found or identical");
                return false;
            }
            
            case SlashViolationType::DOUBLE_SIGN_BLOCK: {
                // 独立验证：检查区块签名记录
                uint64_t height = evidenceData.value("height", 0);
                std::string existingBlockHash = evidenceData.value("existing_block_hash", "");
                std::string newBlockHash = evidenceData.value("new_block_hash", "");
                
                // 如果两个区块哈希都存在且不同，则验证通过
                if (!existingBlockHash.empty() && !newBlockHash.empty() && existingBlockHash != newBlockHash) {
                    DEBUGLOG("[SLASH] Independent verification passed: DOUBLE_SIGN_BLOCK at height={}", height);
                    return true;
                }
                ERRORLOG("[SLASH] Independent verification failed: DOUBLE_SIGN_BLOCK hashes not found or identical");
                return false;
            }
            
            case SlashViolationType::LOW_SIGN_RATE: {
                // 独立验证：检查链上签名统计数据
                double signRate = evidenceData.value("sign_rate", 1.0);
                uint32_t validPeriods = evidenceData.value("valid_periods", 0);
                
                // 如果有足够的数据且签名率低于阈值，则验证通过
                if (validPeriods >= 50 && signRate < global::ca::kJailLowThreshold) {
                    DEBUGLOG("[SLASH] Independent verification passed: LOW_SIGN_RATE rate={:.2f}%", signRate * 100);
                    return true;
                }
                ERRORLOG("[SLASH] Independent verification failed: LOW_SIGN_RATE insufficient data or rate too high");
                return false;
            }
            
            case SlashViolationType::MALICIOUS_REPORTING:
                ERRORLOG("[SLASH] MALICIOUS_REPORTING is reserved until deterministic payload verification is defined");
                return false;
            
            default:
                ERRORLOG("[SLASH] Unknown violation type: {}", static_cast<int>(violationType));
                return false;
        }
    } catch (const std::exception& e) {
        ERRORLOG("[SLASH] Failed to parse evidence data: {}", e.what());
        return false;
    }
}

int HandleSlashEvidenceMsg(const std::shared_ptr<SlashEvidenceMsg> &msg, const MsgData &msgData)
{
    if (!msg) return -1;
    
    // 1. 验证 reporter 签名有效性
    const CSign& sig = msg->signature();
    std::string evidenceHash = msg->evidence_hash();
    
    if (sig.sign().empty() || sig.pub().empty()) {
        ERRORLOG("[SLASH] Evidence message missing signature from reporter:{}", msg->reporter());
        return -1;
    }
    
    // 验证签名
    if (ca_algorithm::VerifySign(sig, evidenceHash) != 0) {
        ERRORLOG("[SLASH] Evidence signature verification failed from reporter:{}", msg->reporter());
        return -1;
    }
    
    // 2. 独立验证违规事实（不盲从其他节点）
    if (!IndependentlyVerifyViolation(*msg)) {
        ERRORLOG("[SLASH] Independent violation verification failed for evidence from reporter:{}", msg->reporter());
        return -1;
    }
    
    // 3. 验证通过，追加签名到 pool
    MagicSingleton<SlashEvidencePool>::GetInstance()->addEvidence(*msg);
    INFOLOG("[SLASH] Evidence accepted from reporter:{}, target:{}, type:{}", 
            msg->reporter(), msg->target_addr(), 
            SlashViolationType_Name(msg->violation_type()));
    
    return 0;
}

int HandleNodeOfflineNotice(const std::shared_ptr<NodeOfflineNotice> &msg, const MsgData &msgData)
{
    if (!msg) return -1;
    INFOLOG("[SLASH] Received NodeOfflineNotice from:{}, duration:{}s, reason:{}",
            msg->node_id(), msg->expected_offline_duration(), msg->reason());
    // Store in DB for offline tolerance tracking
    DBReadWriter dbWriter;
    std::string key = std::string("slash_offline_notice_") + msg->node_id();
    nlohmann::json notice;
    notice["node_id"] = msg->node_id();
    notice["duration"] = msg->expected_offline_duration();
    notice["online_time"] = msg->expected_online_time();
    notice["reason"] = msg->reason();
    dbWriter.writePendingSlashingEvidence(key, notice.dump());
    return 0;
}

// === 辅助函数：发送举证消息给当前分发者 ===

void SendSlashEvidenceToDispatcher(const SlashEvidenceMsg& evidence)
{
    // 1. 计算当前分发者
    uint64_t currentTime = std::chrono::duration_cast<std::chrono::microseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    std::string dispatcherAddr;
    if (calculatePackerByTime(currentTime, dispatcherAddr) != 0) {
        ERRORLOG("[SLASH] Failed to calculate current dispatcher, cannot send evidence");
        return;
    }
    
    // 2. 随机退避 (0~3000ms)
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, global::ca::kSlashEvidenceMaxDelayMs);
    int delayMs = dis(gen);
    
    INFOLOG("[SLASH] Sending evidence to dispatcher:{} after {}ms delay, target:{}, type:{}",
            dispatcherAddr, delayMs, evidence.target_addr(), 
            SlashViolationType_Name(evidence.violation_type()));
    
    // 3. 延迟后单播给分发者
    std::thread([evidence, dispatcherAddr, delayMs]() {
        std::this_thread::sleep_for(std::chrono::milliseconds(delayMs));
        
        // 使用 NetSendMessage 单播给分发者
        if (!NetSendMessage(dispatcherAddr, evidence)) {
            ERRORLOG("[SLASH] Failed to send evidence to dispatcher:{}", dispatcherAddr);
        } else {
            DEBUGLOG("[SLASH] Evidence sent to dispatcher:{}", dispatcherAddr);
        }
    }).detach();
}
