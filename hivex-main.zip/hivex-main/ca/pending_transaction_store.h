#ifndef OPENHIVE_PENDING_TRANSACTION_STORE_H
#define OPENHIVE_PENDING_TRANSACTION_STORE_H

#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

namespace pending_tx { class Reservations; }

namespace pending_tx
{
class Store
{
public:
    bool Persist(const std::string& id, const std::string& address, uint64_t nonce,
                 const std::vector<std::string>& utxos, const std::string& commitment = {},
                 uint64_t consensus_deadline = 0);
    bool Remove(const std::string& id);
    bool Replace(const std::string& old_id, const std::string& id, const std::string& address,
                 uint64_t nonce, const std::vector<std::string>& utxos, const std::string& commitment = {},
                 uint64_t consensus_deadline = 0);
    bool Restore(Reservations& reservations);
    bool PruneExpired(Reservations& reservations);
private:
    std::mutex mutex_;
    uint64_t last_prune_blocked_log_micros_ = 0;
};
} // namespace pending_tx
#endif
