﻿#include "ca.h"

#include <iostream>
#include <map>
#include <fstream>
#include <sstream>
#include <string>
#include <random>
#include <fcntl.h>
#include <filesystem>

#include "ca/global.h"
#include "ca/txhelper.h"
#include "ca/contract.h"
#include "ca/dispatchtx.h"
#include "ca/block_helper.h"
#include "ca/transaction.h"
#include "ca/sync_block.h"
#include "ca/advanced_menu.h"

#include "ca/double_spend_cache.h"
#include "ca/block_http_callback.h"
#include "ca/failed_transaction_cache.h"
#include "ca/vrf_consensus.h"
#include "ca/block_rate_probe.h"

#include "logging.h"
//#include "utils/qrcode.h"
#include <qrcodegen.hpp>
#include "utils/console.h"
#include "utils/tmp_log.h"
#include "utils/hex_code.h"
#include "utils/time_util.h"
#include "utils/account_manager.h"
#include "utils/magic_singleton.h"
#include "utils/contract_utils.h"
#include "utils/keystore.h"
#include "utils/base64.h"
#include "utils/pretty_print.h"

#include "net/api.h"
#include "net/epoll_mode.h"

#include "pb/interface.pb.h"
#include "pb/ca_protomsg.pb.h"
#include "google/protobuf/util/json_util.h"

#include "db/db_api.h"
#include "ca/evm/evm_manager.h"
#include "rpc/http_api.h"
#include "algorithm.h"
#include "common/genesis_helper.h"

#include "utils/file_manager.h"
#include "ca/transaction/trans.h"
#include "ca/transaction/stake.h"
#include "ca/transaction/unstake.h"
#include "ca/transaction/undelegating.h"
#include "ca/transaction/lock.h"
#include "ca/transaction/unlock.h"
#include "ca/transaction/vote.h"
#include "ca/pending_transaction_reservations.h"
#include "ca/pending_transaction_store.h"

bool bStopTx = false;
bool isCreateTx = false;
const static uint64_t input_limit = 500000;

std::atomic<int> perrnode_index1=0;
boost::threadpool::pool test_pool1;

int StartTimerTask()
{
    // Blocking thread
    global::ca::BLOCK_POOL_TIMER_INTERVAL.AsyncLoop(100, [](){ MagicSingleton<BlockHelper>::GetInstance()->Process(); });
    
    //SeekBlock Thread
    global::ca::SEEK_BLOCK_TIMER.AsyncLoop(3 * 1000, [](){ MagicSingleton<BlockHelper>::GetInstance()->SeekBlockThreadObject(); });
    
    //Start patch thread
    MagicSingleton<BlockHelper>::GetInstance()->SeekBlockThreadObject();

    // Block synchronization thread
    MagicSingleton<SyncBlock>::GetInstance()->ThreadStart();
    MagicSingleton<CheckBlocks>::GetInstance()->StartTimer();

    MagicSingleton<failedTransactionCache>::GetInstance()->_StartTimer();

    MagicSingleton<BlockStorage>::GetInstance();

    MagicSingleton<doubleSpendCache>::GetInstance();

    if (!MagicSingleton<pending_tx::Store>::GetInstance()->Restore(
            *MagicSingleton<pending_tx::Reservations>::GetInstance()))
    {
        ERRORLOG("failed to restore pending transaction reservations");
        return -1;
    }

    return 0;
}

bool CaInit()
{
    RegisterInterface();

    // Register interface with network layer
    RegisterCallback();
    

    // Register HTTP related interfaces
    if(MagicSingleton<Config>::GetInstance()->GetRpc())
    {
        subscribeToHttpCallbacks();
    }

    // Start timer task
    StartTimerTask();

    // NTP verification
    CheckNtpTime();

    MagicSingleton<TransactionCache>::GetInstance()->Process();

    MagicSingleton<ContractDispatcher>::GetInstance()->Process();

    MagicSingleton<VRFConsensusNode>::GetInstance()->Process();

    // 初始化区块上链率探测模块
    MagicSingleton<BlockRateProbe>::GetInstance();

    std::filesystem::create_directory(path_constants::CONTRACT_PATH);

    return true;
}

int CaEndTimerTaskV2()
{
    global::ca::DATABASE_TIMER.Cancel();
    global::ca::BLOCK_POOL_TIMER_INTERVAL.Cancel();
    global::ca::SEEK_BLOCK_TIMER.Cancel();
    return 0;
}

void CaCleanup()
{
    DEBUGLOG("start clean")
    CaEndTimerTaskV2();
    DEBUGLOG("start clean g_heartTimer")
    global::g_heartTimer.Cancel();
    DEBUGLOG("start clean failedTransactionCache")
    MagicSingleton<failedTransactionCache>::GetInstance()->StopTimer();
    DEBUGLOG("start clean BlockHelper")
    MagicSingleton<BlockHelper>::GetInstance()->stopSaveBlock();
    DEBUGLOG("start clean Benchmark")
    MagicSingleton<Benchmark>::GetInstance()->Clear();
    DEBUGLOG("start clean TransactionCache")
    MagicSingleton<TransactionCache>::GetInstance()->Stop();
    DEBUGLOG("start clean SyncBlock")
    MagicSingleton<SyncBlock>::GetInstance()->ThreadStop();
    DEBUGLOG("start clean BlockStorage")
    MagicSingleton<BlockStorage>::GetInstance()->StopTimer();
    DEBUGLOG("start clean doubleSpendCache")
    MagicSingleton<doubleSpendCache>::GetInstance()->StopTimer();
    DEBUGLOG("start clean EpollMode")
    MagicSingleton<EpollMode>::GetInstance()->EpollStop();
    DEBUGLOG("start clean BlockHttpCallbackHandler")
    MagicSingleton<BlockHttpCallbackHandler>::GetInstance()->Stop();
    DEBUGLOG("start clean PeerNode")
    MagicSingleton<PeerNode>::GetInstance()->stopNodesSwap();
    DEBUGLOG("start clean CheckBlocks")
    MagicSingleton<CheckBlocks>::GetInstance()->StopTimer();
    DEBUGLOG("start clean VRF" )
    MagicSingleton<VRF>::GetInstance()->StopTimer();
    DEBUGLOG("sleep")

    sleep(5);

    DEBUGLOG("start clean RocksDB")
    MagicSingleton<RocksDB>::GetInstance()->sestoryDB();

    DEBUGLOG("clean finish")
}

void HandleTransaction()
{
    std::cout << std::endl
              << std::endl;

    std::string txsNum;
    std::cout << "Please enter the number of transactions in the currency ([1] or [2] or [3]):" << std::endl;
    std::cin >> txsNum;
    std::regex pattern("^[0-3]+$");
    if (!std::regex_match(txsNum, pattern))
    {
        std::cout << "Invalid input, please enter a positive integer!" << std::endl;
        return;
    }

    int64_t times = std::stoll(txsNum);

    std::string _isGastrade = "0";
    std::cout << "Would you like to pay your handling fee separately ? [0] no  [1] yes :" << std::endl;
    std::cin >> _isGastrade;
    std::regex pattern1("^[0-1]+$");
    if (!std::regex_match(_isGastrade, pattern1))
    {
        std::cout << "Invalid input, please enter a positive integer!" << std::endl;
        return;
    }

    std::pair<std::string, std::string> gasTrade = {};
    if (CheckGasAssetsInput(_isGastrade, gasTrade) != 0)
    {
        return;
    }
    // 这里需要判断一下他是否真的有超过times个资产类型可以花费
    std::vector<TxHelper::TransTable> txAsset;
    for (int i = 0; i < times; ++i)
    {
        TxHelper::TransTable successfulTrade;
        std::string type;
        std::cout << "Please enter the type of asset you want to txAsset :" << std::endl;
        std::cin >> type;

        type = remove0xPrefix(type);
        if(times == 1 && type == gasTrade.second) {
            _isGastrade = "0";
            gasTrade = std::make_pair("","");
        }
        
        std::regex pattern3("[^\"\\s]*");
        if (!std::regex_match(type, pattern3))
        {
            std::cout << "Invalid input, please enter a string!" << std::endl;
            return;
        }
        successfulTrade.asset_type = type;

        std::string strFromAddr;
        std::cout << "input FromAddr :" << std::endl;
        std::cin >> strFromAddr;
        if (strFromAddr.substr(0, 2) == "0x")
        {
            strFromAddr = strFromAddr.substr(2);
        }
        successfulTrade.fromAddr.push_back(remove0xPrefix(strFromAddr));
        std::string strToAddr;
        std::cout << "input toAddress :" << std::endl;
        std::cin >> strToAddr;
        if (strToAddr.substr(0, 2) == "0x")
        {
            strToAddr = strToAddr.substr(2);
        }

        std::string strAmt;
        std::cout << "input amount :" << std::endl;
        std::cin >> strAmt;
        std::regex pattern("^\\d+(\\.\\d+)?$");
        if (!std::regex_match(strAmt, pattern))
        {
            std::cout << "input amount error ! " << std::endl;
            return;
        }
        std::string toAddr = remove0xPrefix(strToAddr);
        successfulTrade.toAddrAmount[toAddr] = (std::stod(strAmt) + global::ca::MIN_DOUBLE_CONSTANT_PRECISION) * global::ca::kDecimalNum;
        txAsset.push_back(successfulTrade);
    }
        std::string input;
        std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
        std::cin >> input;

        bool isFindUtxo = false;
        ;
        std::regex pattern5("^(0|1)$");
        if (!std::regex_match(input, pattern5))
        {
            std::cout << "Error in parameter input" << std::endl;
            return;
        }
        else
        {
            isFindUtxo = input == "1" ? true : false;
        }

        std::string txInfo;
        std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::getline(std::cin, txInfo);

        std::string encodedInfo = Base64Encode(txInfo);
        if (encodedInfo.size() > 1024)
        {
            std::cout << "The information entered exceeds the specified length" << std::endl;
            return;
        }



        DBReader dbReader;

        uint64_t top = 0;
        int retNum = transactionDiscoveryHeight(top);
        if(retNum != 0){
            ERRORLOG("transactionDiscoveryHeight error {}", retNum);
            return;
        }


        TxHelper::TransTable trans_info;
        

        TransforerTransParam param;
        param.tx_asset = txAsset;
        param.gas_tray = {gasTrade.first, gasTrade.second};
        param.encoded_info = encodedInfo;
        param.known_top = top;
       // param.height = top+1;
        param.is_find_utxo = false;
        param.is_gas_tray = _isGastrade == "1" ? true : false;
        
        TransforerTrans testTrans(param);


        auto ret = testTrans.trans();
        if (!ret.isOk())
        {
            ERRORLOG("TransforerTrans error {}", ret.error_message(true));
            std::cerr <<ret .error_message() << std::endl;
            return ;
        };

        auto siret=testTrans.signTx("");

        testTrans.print_debug_tx();

        if(!siret.isOk()){
            ERRORLOG("sign TransforerTrans tx error {}", siret.error_message(true));
            std::cerr << siret.error_message() << std::endl;
            return ;
        }

        auto msgret=testTrans.goMessage();

        if(!msgret.isOk()){
            ERRORLOG("goMessage stake tx error {}", msgret.error_message(true));
            
            std::cerr << msgret.error_message() << std::endl;
            return ;
        }


        // CTransaction outTx;
        // TxHelper::vrfAgentType needAgent;

        // int ret = TxHelper::createTransactionRequest(txAsset, gasTrade, std::stoi(_isGastrade), encodedInfo,top + 1, outTx, needAgent, isFindUtxo);
        // if (ret != 0)
        // {
        //     ERRORLOG("createTransactionRequest error!! ret:{}", ret);
        //     return;
        // }

        // TxMsgReq txMsg;
        // txMsg.set_version(ohi::GetVersion());
        // TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
        // txMsgInfo->set_type(0);
        // txMsgInfo->set_tx(outTx.SerializeAsString());
        // txMsgInfo->set_nodeheight(top);

        // uint64_t txUtxoLocalHeight;
        // ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
        // if (ret != 0)
        // {
        //     ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        //     return;
        // }

        // txMsgInfo->set_txutxoheight(txUtxoLocalHeight);
        
        // auto msg = std::make_shared<TxMsgReq>(txMsg);
        // std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

        // if (outTx.identity() == defaultAddr)
        // {
        //     ret = handleTransaction(msg, outTx);
        // }
        // else
        // {
        //     ret = DropShippingTransaction(msg, outTx, outTx.identity());
        // }

        // DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());

        // return;
   
}
void HandleStake()
{
    std::cout << std::endl
              << std::endl;

    Account account;
    MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(account);
    std::string strFromAddr = account.GetAddr();
    std::string fromAddr = remove0xPrefix(strFromAddr);
    std::cout << "stake addr: " <<addHexPrefix(strFromAddr) << std::endl;

    std::string _isGastrade;
    std::cout << "Would you like to pay your handling fee separately ? [0] no  [1] yes :" << std::endl;
    std::cin >> _isGastrade;
    std::regex pattern2("^[0-1]+$");
    if (!std::regex_match(_isGastrade, pattern2))
    {
        std::cout << "Invalid input, please enter a positive integer!" << std::endl;
        return;
    }

    std::pair<std::string,std::string> gasTrade = {};
    if (CheckGasAssetsInput(_isGastrade, gasTrade) != 0)
    {
        return;
    }

    std::string assetType;
    std::cout << "Please enter the type of asset you want to currency type :" << std::endl;
    std::cin >> assetType;
    assetType = remove0xPrefix(assetType);

    if(assetType == gasTrade.second){
        std::cout << "The asset type involved in the transaction cannot be used to pay gas alone!" << std::endl;
        return;
    }

    std::string stakeFeeStr;
    std::cout << "Please enter the amount to stake:" << std::endl;
    std::cin >> stakeFeeStr;
    std::regex pattern("^\\d+(\\.\\d+)?$");
    if (!std::regex_match(stakeFeeStr, pattern))
    {
        std::cout << "input stake amount error " << std::endl;
        return;
    }

    std::regex bonus("^([1-9]|1[0-9]|2[0-9]|3[0-5])$");
    std::cout <<"Please input the bonus pumping percentage to stake (1 - 35):" << std::endl;
    std::string rewardRankString;
    std::cin >> rewardRankString;
    if(!std::regex_match(rewardRankString,bonus))
    {
        std::cout << "input the bonus pumping percentage error" << std::endl;
        return;
    }
    
    double commissionRate = std::stold(rewardRankString) / 100;
    if(commissionRate < global::ca::MIN_COMMISSION_RATE || commissionRate > global::ca::MAX_COMMISSION_RATE)
    {
        std::cout << "input the bonus pumping percentage error" << std::endl;
        return;
    }
    std::cout << commissionRate << std::endl;
    
    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;;
    std::regex pattern1("^(0|1)$");
    if(!std::regex_match(input, pattern1))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }

    std::string txInfo;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txInfo);

    std::string encodedInfo = Base64Encode(txInfo);
    if(encodedInfo.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    TxHelper::stakeType stakeType = TxHelper::stakeType::STAKE_TYPE_NODE;

    uint64_t stakeAmount = std::stod(stakeFeeStr) * global::ca::kDecimalNum;

    DBReader dbReader;
    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }

    StakeTransParam param;
    param.addr = fromAddr;
    param.asset_type = assetType;
    param.amount = stakeAmount;
    param.reward_rank_string= rewardRankString;
    param.gas_tray.addr = gasTrade.first;
    param.gas_tray.asset_type = gasTrade.second;
    param.encoded_info = encodedInfo;
    param.is_gas_tray = _isGastrade == "1" ? true : false;

    StakeTrans stake(param);
    auto ret = stake.trans();
    if (!ret.isOk())
    {
        ERRORLOG("StakeTrans error {}", ret.error_message(true));
        std::cerr << ret.error_message() << std::endl;
        return ;
    };

    auto siret=stake.signTx(param.addr);

    if(!siret.isOk()){
        ERRORLOG("sign stake tx error {}", siret.error_message(true));
        
    std::cerr << siret.error_message() << std::endl; 
        return ;
    }

    stake.print_debug_tx();
    auto msgret=stake.goMessage();

    if(!msgret.isOk()){
        ERRORLOG("goMessage stake tx error {}", msgret.error_message(true));
        
        std::cerr << msgret.error_message() << std::endl;
        return ;
    }

    // CTransaction outTx;
    // std::vector<TxHelper::Utxo> outVin;
    // TxHelper::vrfAgentType needAgent;
    // if (TxHelper::CreateStakingTransaction(fromAddr,assetType,stakeAmount, top + 1,  stakeType, outTx, outVin,needAgent,
    //                                             gasTrade,std::stoi(_isGastrade), commissionRate, isFindUtxo, encodedInfo) != 0)
    // {
    //     return;
    // }

    // TxMsgReq txMsg;
    // txMsg.set_version(ohi::GetVersion());
    // TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    // txMsgInfo->set_type(0);
    // txMsgInfo->set_tx(outTx.SerializeAsString());
    // txMsgInfo->set_nodeheight(top);

    // uint64_t txUtxoLocalHeight;
    // auto ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    // if(ret != 0)
    // {
    //     ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
    //     return;
    // }

    // txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    // auto msg = std::make_shared<TxMsgReq>(txMsg);

    // std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

    // if(outTx.identity() == defaultAddr)
    // {
    //     ret = handleTransaction(msg,outTx);
    // }
    // else
    // {
    //     ret = DropShippingTransaction(msg, outTx, outTx.identity());
    // }

    // if (ret != 0)
    // {
    //     ret -= 100;
    // }

    // DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());
}

void HandleUnstake()
{
    std::cout << std::endl
              << std::endl;
    std::string _isGastrade = "0";
    std::cout << "Would you like to pay your handling fee separately ? [0] no  [1] yes :" << std::endl;
    std::cin >> _isGastrade;
    std::regex pattern2("^[0-1]+$");
    if (!std::regex_match(_isGastrade, pattern2))
    {
        std::cout << "Invalid input, please enter a positive integer!" << std::endl;
        return;
    }
    std::pair<std::string, std::string> gasTrade = {};
    if (CheckGasAssetsInput(_isGastrade, gasTrade) != 0)
    {
        return ;
    }



    std::string strFromAddr;
    std::cout << "Please enter unstake addr:" << std::endl;
    std::cin >> strFromAddr;
    if (strFromAddr.substr(0, 2) == "0x") 
    {
        strFromAddr = strFromAddr.substr(2);
    }

    std::string assetType;
    std::cout << "Please enter the type of asset you want to currency type :" << std::endl;
    std::cin >> assetType;
    assetType = remove0xPrefix(assetType);
    
    if(assetType == gasTrade.second){
        std::cout << "The asset type involved in the transaction cannot be used to pay gas alone!" << std::endl;
        return;
    }

    DBReader dbReader;
    std::vector<std::string> utxos;
    dbReader.getStakeUtxoByAddr(strFromAddr, assetType, utxos);
    std::reverse(utxos.begin(), utxos.end());
    std::cout << "-- Current pledge amount: -- " << std::endl;
    for (auto &utxo : utxos)
    {
        std::string txRaw;
        dbReader.getTransactionByHash(utxo, txRaw);
        CTransaction tx;
        tx.ParseFromString(txRaw);
        uint64_t value = 0;
        for(const auto & utxo: tx.utxos())
        {
            for (auto &vout : utxo.vout())
            {
                if (vout.addr() == global::ca::kTargetAddress)
                {
                    value = vout.value();
                    break;
                }
            }
        }
        std::cout << "utxo: " << utxo << " value: " << value << std::endl;
    }
    std::cout << std::endl;

    std::string utxo_hash_str;
    std::cout << "utxo:";
    std::cin >> utxo_hash_str;

    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;;
    std::regex pattern1("^(0|1)$");
    if(!std::regex_match(input, pattern1))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }


    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }

    std::string txInfo;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txInfo);

    std::string encodedInfo = Base64Encode(txInfo);
    if(encodedInfo.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }


    UnStakeParam param;
    param.addr = strFromAddr;
    param.assert_type = assetType;
    param.stake_utxo_hash = utxo_hash_str;
    param.gas_tray.addr = gasTrade.first;
    param.gas_tray.asset_type = gasTrade.second;
    param.encoded_info = encodedInfo;
    //param.height = top + 1;
    param.is_find_utxo = isFindUtxo;
    param.is_gas_tray = _isGastrade == "1" ? true : false;


    UnStake unstake(param);
    
    auto ret = unstake.trans();
    if (!ret.isOk())
    {
        ERRORLOG("UnStake error {}", ret.error_message(true));
        std::cerr << ret.error_message() << std::endl;
        return ;
    };

    auto siret = unstake.signTx("");
    if(!siret.isOk()){
        ERRORLOG("sign UnStake tx error {}", siret.error_message(true));
        std::cerr << siret.error_message() << std::endl;
        return ;
    }

    unstake.print_debug_tx();
    auto msgret = unstake.goMessage();
    if(!msgret.isOk()){
        ERRORLOG("goMessage UnStake tx error {}", msgret.error_message(true));
        std::cerr << msgret.error_message() << std::endl;
        return ;
    }
}

void handleDelegating()
{
    std::cout << std::endl
              << std::endl;
    std::cout << "AddrList:" << std::endl;
    MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();

    std::string _isGastrade;
    std::cout << "Would you like to pay your handling fee separately ? [0] no  [1] yes :" << std::endl;
    std::cin >> _isGastrade;
    std::regex pattern2("^[0-1]+$");
    if (!std::regex_match(_isGastrade, pattern2))
    {
        std::cout << "Invalid input, please enter a positive integer!" << std::endl;
        return;
    }

    std::pair<std::string,std::string> gasTrade = {};
    if (CheckGasAssetsInput(_isGastrade,gasTrade) != 0)
    {
        return ;
    }

    std::string strFromAddr;
    std::cout << "Please enter your addr:" << std::endl;
    std::cin >> strFromAddr;

    std::string fromAddr = remove0xPrefix(strFromAddr);

    if (!isValidAddress(fromAddr))
    {
        ERRORLOG("Input addr error!");
        std::cout << "Input addr error!" << std::endl;
        return;
    }

    std::string assetType;
    std::cout << "Please enter the type of asset you want to currency type :" << std::endl;
    std::cin >> assetType;
    assetType = remove0xPrefix(assetType);
    
    if(assetType == gasTrade.second){
        std::cout << "The asset type involved in the transaction cannot be used to pay gas alone!" << std::endl;
        return;
    }

    std::string strToAddr;
    std::cout << "Please enter the addr you want to delegate to:" << std::endl;
    std::cin >> strToAddr;
    std::string toAddr = remove0xPrefix(strToAddr);
    if (!isValidAddress(toAddr))
    {
        ERRORLOG("Input addr error!");
        std::cout << "Input addr error!" << std::endl;
        return;
    }

    std::string strDelegatingFee;
    std::cout << "Please enter the amount to delegate:" << std::endl;
    std::cin >> strDelegatingFee;
    std::regex pattern("^\\d+(\\.\\d+)?$");
    if (!std::regex_match(strDelegatingFee, pattern))
    {
        ERRORLOG("Input delegating fee error!");
        std::cout << "Input delegate fee error!" << std::endl;
        return;
    }
    
    TxHelper::delegateType delegateType = TxHelper::delegateType::kdelegateType_NetLicence;
    uint64_t delegateAmount = std::stod(strDelegatingFee) * global::ca::kDecimalNum;

    
    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;
    std::regex pattern1("^(0|1)$");
    if(!std::regex_match(input, pattern1))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }

    std::string txInfo;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txInfo);

    std::string encodedInfo = Base64Encode(txInfo);
    if(encodedInfo.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    DBReader dbReader;
    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }

    CTransaction outTx;
    std::vector<TxHelper::Utxo> outVin;
    DelegatingTransParam param;
    param.from_addr = fromAddr;
    param.to_addr = toAddr;
    param.encoded_info = encodedInfo;
    param.gas_tray.addr = gasTrade.first;
    param.gas_tray.asset_type = gasTrade.second;
    param.delegatinged_amount = delegateAmount;
    param.delegate_type = delegateType;
    param.is_gas_tray = std::stoi(_isGastrade);
    param.asset_type = assetType;
    param.is_find_utxo = isFindUtxo;
   // param.height = top;

    DelegatingTrans delegating(param);
    auto ret = delegating.trans();
    if (!ret.isOk())
    {
        ERRORLOG("DelegatingTrans error {}", ret.error_message(true));
        std::cerr << ret.error_message() << std::endl;
        return ;
    };

    auto siret=delegating.signTx(param.from_addr);

    if(!siret.isOk()){
        ERRORLOG("sign delegating tx error {}", siret.error_message(true));
        std::cerr << siret.error_message() << std::endl;
        return ;
    }
    delegating.print_debug_tx();
    auto msgret = delegating.goMessage();

    // std::ostringstream oss;
    // PrintTx(outTx, true,oss);
    // std::cout << oss.str() << std::endl;
    if (!msgret.isOk())
    {
        ERRORLOG("goMessage delegating tx error {}", msgret.error_message(true));
        std::cerr << msgret.error_message() <<  std::endl;
        return ;
    }
    // TxHelper::vrfAgentType needAgent;
    // int ret = TxHelper::CreateDelegatingTransaction(fromAddr, assetType, toAddr, delegateAmount, top + 1,  delegateType, outTx, 
    //                                                     outVin, needAgent, gasTrade, std::stoi(_isGastrade), isFindUtxo, encodedInfo);
    // if (ret != 0)
    // {
    //     ERRORLOG("Failed to create Delegating transaction! The error code is:{}", ret);
    //     return;
    // }

    // TxMsgReq txMsg;
    // txMsg.set_version(ohi::GetVersion());
    // TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    // txMsgInfo->set_type(0);
    // txMsgInfo->set_tx(outTx.SerializeAsString());
    // txMsgInfo->set_nodeheight(top);

    // uint64_t txUtxoLocalHeight;
    // ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    // if(ret != 0)
    // {
    //     ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
    //     return;
    // }

    // txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    // auto msg = std::make_shared<TxMsgReq>(txMsg);
    // std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    // if(outTx.identity() == defaultAddr)
    // {
    //     ret = handleTransaction(msg,outTx);
    // }
    // else
    // {
    //     ret = DropShippingTransaction(msg, outTx, outTx.identity());
    // }
    // if (ret != 0)
    // {
    //     ret -= 100;
    // }

    // DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());
}

void HandleUndelegating()
{
    std::cout << std::endl
              << std::endl;

    std::cout << "AddrList : " << std::endl;
    MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();

    std::string _isGastrade;
    std::cout << "Would you like to pay your handling fee separately ? [0] no  [1] yes :" << std::endl;
    std::cin >> _isGastrade;
    std::regex pattern2("^[0-1]+$");
    if (!std::regex_match(_isGastrade, pattern2))
    {
        std::cout << "Invalid input, please enter a positive integer!" << std::endl;
        return;
    }

    std::pair<std::string,std::string> gasTrade = {};
    if (CheckGasAssetsInput(_isGastrade,gasTrade) != 0)
    {
        return ;
    } 

    std::string strFromAddr;
    std::cout << "Please enter your addr:" << std::endl;
    std::cin >> strFromAddr;

    std::string fromAddr = remove0xPrefix(strFromAddr);
    if (!isValidAddress(fromAddr))
    {
        std::cout << "Input addr error!" << std::endl;
        return;
    }

    std::string assetType;
    std::cout << "Please enter the type of asset you want to currency :" << std::endl;
    std::cin >> assetType;
    assetType = remove0xPrefix(assetType);

    if(assetType == gasTrade.second){
        std::cout << "The asset type involved in the transaction cannot be used to pay gas alone!" << std::endl;
        return;
    }

    std::string strToAddr;
    std::cout << "Please enter the addr you want to withdraw from:" << std::endl;
    std::cin >> strToAddr;
    std::string toAddr = remove0xPrefix(strToAddr);
    if (!isValidAddress(toAddr))
    {
        std::cout << "Input addr error!" << std::endl;
        return;
    }

    DBReader dbReader;
    std::vector<std::string> utxos;
    dbReader.getDelegatingAddrUtxoByBonusAddr(toAddr, fromAddr, assetType, utxos);
    std::reverse(utxos.begin(), utxos.end());
    std::cout << "-- Current delegate amount: -- " << std::endl;
    for (auto &utxo : utxos)
    {
        std::cout << "utxo: " << utxo << std::endl;
    }
    std::cout << std::endl;

    std::string utxo_hash_str;
    std::cout << "Please enter the utxo you want to withdraw:";
    std::cin >> utxo_hash_str;

    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;;
    std::regex pattern1("^(0|1)$");
    if(!std::regex_match(input, pattern1))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }
    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }

    std::string txInfo;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txInfo);

    std::string encodedInfo = Base64Encode(txInfo);
    if(encodedInfo.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    UndelegatingTransParam param;
    param.from_addr = fromAddr;
    param.to_addr = toAddr;
    param.encoded_info = encodedInfo;
    param.asset_type = assetType;
    param.gas_tray.addr = gasTrade.first;
    param.gas_tray.asset_type = gasTrade.second;
    param.is_gas_tray = std::stoi(_isGastrade);
    param.utxo_hash = utxo_hash_str;
    param.is_find_utxo = isFindUtxo;

    UndelegatingTrans undelegating(param);
    auto ret = undelegating.trans();
    if (!ret.isOk())
    {
        ERRORLOG("UndelegatingTrans error {}", ret.error_message(true));
        std::cerr << ret.error_message() << std::endl;
        return ;
    };

    auto siret = undelegating.signTx(param.from_addr);
    if(!siret.isOk()){
        ERRORLOG("sign undelegating tx error {}", siret.error_message(true));
        std::cerr << siret.error_message() << std::endl;
        return ;
    }

    auto msgret = undelegating.goMessage();
    if(!msgret.isOk()){
        ERRORLOG("goMessage undelegating tx error {}", msgret.error_message(true));
         std::cerr << msgret.error_message() << std::endl;
        return ;
    }
}

void HandleBonus()
{
    CTransaction outTx;
    std::vector<TxHelper::Utxo> outVin;
    std::string strFromAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

    DBReader dbReader;
    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }
    
    // std::string _isGastrade;
    // std::cout << "Would you like to pay your handling fee separately ? [0] no  [1] yes :" << std::endl;
    // std::cin >> _isGastrade;
    // std::regex pattern2("^[0-1]+$");
    // if (!std::regex_match(_isGastrade, pattern2))
    // {
    //     std::cout << "Invalid input, please enter a positive integer!" << std::endl;
    //     return;
    // }


    // 添加if判断
    bool firstChoose = false;
    int64_t balance = 0;
    auto dbret = dbReader.getBalanceByAddr(strFromAddr, global::ca::ASSET_TYPE_OHI, balance);
    if (dbret != DBStatus::DB_SUCCESS && dbret != DBStatus::DB_NOT_FOUND)
    {
        ERRORLOG("db get top failed!!");
        return;
    }
   // bool firstChoose = false;
    std::string assetType;
    std::cout << "Please enter the type of asset you want to currency type :" << std::endl;
    std::cin >> assetType;
    assetType = remove0xPrefix(assetType);
    std::string assetTypeOHI;
    int ret = ca_algorithm::GetCanBeRevokeAssetType(assetTypeOHI);
    if (ret != 0)
    {
        ERRORLOG("Get Can BeRevoke AssetType fail!");
        return;
    }

    if(assetType.length() != 64)
    {
        if (assetType != global::ca::ASSET_TYPE_OHI)
        {
            std::cout << "Please confirm assettype is right";
            return;
        }
    }




    // std::pair<std::string, std::string> gasTrade = {};
    // if (CheckGasAssetsInput(_isGastrade,gasTrade) != 0)
    // {
    //     return ;
    // }

    

    if (balance == 0 && dbret == DBStatus::DB_NOT_FOUND)
	{
        std::cout << "You get zero Vote cannot pay by Vote" << std::endl;
        int ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
        if (ret != 0)
        {
            ERRORLOG("Description Failed to obtain the jump asset type");
            return;
        }
        firstChoose = true;
    }
	else
	{
		assetType = global::ca::ASSET_TYPE_OHI;
	}

    std::string _isGastrade;
    if(firstChoose == false)
    {
        std::cout << "Would you like to pay your handling fee separately ? [0] no  [1] yes :" << std::endl;
        std::cin >> _isGastrade;
        std::regex pattern2("^[0-1]+$");
        if (!std::regex_match(_isGastrade, pattern2))
        {
            std::cout << "Invalid input, please enter a positive integer!" << std::endl;
            return;
        }
    }else
    {
        std::cout << "First choose must point a asset to pay your handling fee" << std::endl;
        _isGastrade = "1";
    }

    std::pair<std::string, std::string> gasTrade = {};
    if (CheckGasAssetsInput(_isGastrade,gasTrade) != 0)
    {
        return ;
    }

    if(assetType == gasTrade.second && firstChoose == false)
    {
        std::cerr << "Gas asset type is same as asset type";
        return;
    }



    if(gasTrade.second == global::ca::ASSET_TYPE_OHI)
    {
        std::cout << "Gas assetType can't be Vote";
        return;
    }
    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;;
    std::regex pattern1("^(0|1)$");
    if(!std::regex_match(input, pattern1))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }



    std::string txInfo;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txInfo);

    std::string encodedInfo = Base64Encode(txInfo);
    if(encodedInfo.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    BonusTransParam param;
    param.addr = remove0xPrefix(strFromAddr);
    param.asset_type = assetType;
    param.encoded_info = encodedInfo;
    param.gas_tray.addr = gasTrade.first;
    param.gas_tray.asset_type = gasTrade.second;
    param.is_gas_tray = std::stoi(_isGastrade);
    param.first_choose = firstChoose;
    param.is_find_utxo = isFindUtxo;
    //param.height = top+1;

    BonusTrans bonus(param);
    auto ret_bool = bonus.trans();
    if (!ret_bool.isOk())
    {
        ERRORLOG("StakeTrans error {}", ret_bool.error_message(true));
        std::cerr << ret_bool.error_message() << std::endl;
        return ;
    };


    auto siret=bonus.signTx(param.addr);

    if(!siret.isOk()){
        ERRORLOG("sign bonus tx error {}", siret.error_message(true));
        std::cerr << siret.error_message() << std::endl;
        return ;
    }

    auto msgret=bonus.goMessage();


    if (!msgret.isOk())
    {
        ERRORLOG("goMessage bonus tx error {}", msgret.error_message(true));
        std::cerr << msgret.error_message() << std::endl;
        return ;
    }


    // TxHelper::vrfAgentType needAgent;
    // ret = TxHelper::CreateBonusTransaction(strFromAddr, assetType,top + 1, outTx, outVin,
    //                                            needAgent, gasTrade, std::stoi(_isGastrade), isFindUtxo, encodedInfo,firstChoose);
    // if (ret != 0)
    // {
    //     ERRORLOG("Failed to create bonus transaction! The error code is:{}", ret);
    //     return;
    // }

    // TxMsgReq txMsg;
    // txMsg.set_version(ohi::GetVersion());
    // TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    // txMsgInfo->set_type(0);
    // txMsgInfo->set_tx(outTx.SerializeAsString());
    // txMsgInfo->set_nodeheight(top);

    // uint64_t txUtxoLocalHeight;
    // ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    // if(ret != 0)
    // {
    //     ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
    //     return;
    // }

    // txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    // auto msg = std::make_shared<TxMsgReq>(txMsg);

    // std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    
    // if(outTx.identity() == defaultAddr)
    // {
    //     ret = handleTransaction(msg,outTx);
    // }
    // else
    // {
    //     ret = DropShippingTransaction(msg, outTx, outTx.identity());
    // }

    // if (ret != 0)
    // {
    //     ret -= 100;
    // }
    // DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());
}



void HandleTresury()
{
    CTransaction outTx;
    std::vector<TxHelper::Utxo> outVin;
    std::string strFromAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

    DBReader dbReader;
    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }

    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;;
    std::regex pattern1("^(0|1)$");
    if(!std::regex_match(input, pattern1))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }

    std::string txInfo;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txInfo);

    std::string encodedInfo = Base64Encode(txInfo);
    if(encodedInfo.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }


    FundTransParam param;
    param.addr = remove0xPrefix(strFromAddr);
    param.encoded_info = encodedInfo;
    param.is_find_utxo = isFindUtxo;
   // param.height = top;

    FundTrans fund(param);
    auto ret = fund.trans();
    if (!ret.isOk())
    {
        ERRORLOG("StakeTrans error {}", ret.error_message(true));
        std::cerr << ret.error_message() << std::endl;
        return ;
    };

    auto siret=fund.signTransaction(param.addr);

    if(!siret.isOk()){
        ERRORLOG("sign treasury tx error {}", siret.error_message(true));
         std::cerr << siret.error_message() << std::endl;
        return ;
    }

    auto msgret=fund.goMessage();

    fund.print_debug_tx();
    if (!msgret.isOk())
    {
        ERRORLOG("goMessage treasury tx error {}", msgret.error_message(true));
         std::cerr << msgret.error_message() << std::endl;
        return ;
    }
    // TxHelper::vrfAgentType needAgent;
    // int ret = TxHelper::CreateFundTransaction(strFromAddr, top + 1,  outTx, outVin,
    //                                                     needAgent ,gasTrade, std::stoi(_isGastrade),isFindUtxo, encodedInfo);
    // if (ret != 0)
    // {
    //     ERRORLOG("Failed to create bonus transaction! The error code is:{}", ret);
    //     return;
    // }

    // TxMsgReq txMsg;
    // txMsg.set_version(ohi::GetVersion());
    // TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    // txMsgInfo->set_type(0);
    // txMsgInfo->set_tx(outTx.SerializeAsString());
    // txMsgInfo->set_nodeheight(top);
    // txMsgInfo->set_txutxoheight(top);

    // auto msg = std::make_shared<TxMsgReq>(txMsg);

    // std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    
    // if(outTx.identity() == defaultAddr)
    // {
    //     ret = handleTransaction(msg,outTx);
    // }
    // else
    // {
    //     ret = DropShippingTransaction(msg, outTx, outTx.identity());
    // }

    // if (ret != 0)
    // {
    //     ret -= 100;
    // }
    // DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());
}

void handleAccountManager()
{
    MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();

    std::cout << std::endl
              << std::endl;
    while (true)
    {
        std::cout << "0.Exit" << std::endl;
        std::cout << "1. Set Default Account" << std::endl;
        std::cout << "2. Add Account" << std::endl;
        std::cout << "3. Remove " << std::endl;
        std::cout << "4. Export SeedKey" << std::endl;
        std::cout << "5. Change Account Password" << std::endl; 
        std::cout << "6. Export All Private Keys To File" << std::endl;

        std::string strKey;
        std::cout << "Please input your choice: " << std::endl;
        std::cin >> strKey;
        std::regex pattern("^[0-6]$"); 
        if (!std::regex_match(strKey, pattern))
        {
            std::cout << "Invalid input." << std::endl;
            continue;
        }
        int key = std::stoi(strKey);
        switch (key)
        {
        case 0:
            return;
        case 1:
            handle_set_default_account();
            break;
        case 2:
            GenKey();
            break;
        case 3:
            DeletePrivateKey();
            break;
        case 4:
            handleExportPrivateKey();
            break;
        case 5:
            HandleChangeAccountPassword();
            break;
        case 6:
            handleExportAllPrivateKeys();
            break;
        default:
            std::cout << "Invalid input." << std::endl;
            continue;
        }
    }
}

//更改账户密码
void HandleChangeAccountPassword()
{
    std::cout << "Enter the address of the account whose password you want to change:" << std::endl;
    std::string address;
    std::cin >> address;
    if (address.substr(0, 2) == "0x") 
    {
        address = address.substr(2); 
    }
    
    if(!isValidAddress(address))
    {
        std::cout << "The address entered is illegal" << std::endl;
        return;
    }
    
    // 检查账户是否存在
    if(!MagicSingleton<AccountManager>::GetInstance()->IsExist(address))
    {
        std::cout << "Account not found!" << std::endl;
        return;
    }
    
    // 获取当前密码
    std::string oldPassword = GetPasswordFromUser(false, "Enter current password: ");
    if(oldPassword.empty()) {
        std::cout << "Password cannot be empty." << std::endl;
        return;
    }
    
    // 获取新密码
    std::string newPassword = GetPasswordFromUser(true, "Enter new password: ");
    if(newPassword.empty()) {
        std::cout << "New password cannot be empty." << std::endl;
        return;
    }
    
    // 调用AccountManager的方法更改密码
    std::string errorMsg;
    int result = MagicSingleton<AccountManager>::GetInstance()->ChangeAccountPassword(
        address, oldPassword, newPassword, errorMsg);
    
    if(result != 0) {
        std::cout << "Failed to change password: " << errorMsg << std::endl;
        return;
    }
    
    std::cout << "Password changed successfully!" << std::endl;
}

void handle_set_default_account()
{
    std::string addr;
    std::cout << "Please enter the address you want to set :" << std::endl;
    std::cin >> addr;
    if (addr.substr(0, 2) == "0x") 
    {
        addr = addr.substr(2);
    }
    if(!isValidAddress(addr))
    {
        std::cout << "The address entered is illegal" <<std::endl;
        return;
    }

    Account oldAccount;
    if (MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(oldAccount) != 0)
    {
        ERRORLOG("not found DefaultKeyBs58Addr  in the _accountList");
        return;
    }

    if (MagicSingleton<AccountManager>::GetInstance()->SetDefaultAccount(addr) != 0)
    {
        ERRORLOG("Set DefaultKeyBs58Addr failed!");
        return;
    }

    Account newAccount;
    if (MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(newAccount) != 0)
    {
        ERRORLOG("not found DefaultKeyBs58Addr  in the _accountList");
        return;
    }

    if (!isValidAddress(oldAccount.GetAddr()) ||
        !isValidAddress(newAccount.GetAddr()))
    {
        return;
    }

    // update base 58 addr
    NodeAddrChangedReq req;
    req.set_version(ohi::GetVersion());

    NodeSign *oldSign = req.mutable_oldsign();
    oldSign->set_pub(oldAccount.GetPubStr());
    std::string oldSignature;
    if (!oldAccount.Sign(Getsha256Hash(newAccount.GetAddr()), oldSignature))
    {
        return;
    }
    oldSign->set_sign(oldSignature);

    NodeSign *newSign = req.mutable_newsign();
    newSign->set_pub(newAccount.GetPubStr());
    std::string newSignature;
    if (!newAccount.Sign(Getsha256Hash(oldAccount.GetAddr()), newSignature))
    {
        return;
    }
    newSign->set_sign(newSignature);

    MagicSingleton<PeerNode>::GetInstance()->SetSelfId(newAccount.GetAddr());
    MagicSingleton<PeerNode>::GetInstance()->SetSelfIdentity(newAccount.GetPubStr());
    std::vector<Node> publicNodes = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    for (auto &node : publicNodes)
    {
        net_com::SendMessage(node, req, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::kHighPriorityLevel2);
    }
    std::cout << "Set Default account success" << std::endl;
}

static std::string ReadFileIntoString(std::string filename)
{
	std::ifstream ifile(filename);
	std::ostringstream buf;
	char ch;
	while(buf&&ifile.get(ch))
    {
        buf.put(ch);
    }
	return buf.str();
}

static int LoopRead(const std::regex&& pattern, std::string_view input_name, std::string& input)
{
    if (input == "0")
    {
        input.clear();
    }
    else
    {
        while(!std::regex_match(input, pattern))
        {
            input.clear();
            std::cout << "invalid " <<  input_name << ", please enter again :(0 to skip, 1 to exit)" << std::endl;
            std::cin >> input;

            if (input == "0")
            {
                input.clear();
                return 0;
            }
            if (input == "1")
            {
                return -1;
            }
        }
    }
    if(input.size() > input_limit)
    {
        std::cout << "Input cannot exceed " << input_limit << " characters" << std::endl;
        return -2;
    }
    return 0;
}

static int LoopReadFile(std::string& input, std::string& output, const std::filesystem::path& filename = "")
{
    std::filesystem::path contract_path;
    bool raise_info = false;
    if (input == "0")
    {
        contract_path = std::filesystem::current_path() / "contract" / filename;
    }
    else
    {
        contract_path = input;
        raise_info = true;
    }

    if (raise_info)
    {
        while(!exists(contract_path))
        {
            input.clear();
            std::cout << contract_path << " doesn't exist! please enter again: (0 to skip, 1 to exit)" << std::endl;
            std::cin >> input;
            if (input == "0")
            {
                return 1;
            }
            if (input == "1")
            {
                return -1;
            }
            contract_path = input;
        }
    }
    else
    {
        if (!exists(contract_path))
        {
            return 1;
        }
    }

    output = ReadFileIntoString(contract_path.string());
    if(output.size() > input_limit)
    {
        std::cout << "Input cannot exceed " << input_limit << " characters" << std::endl;
        return -2;
    }
    return 0;
}

static int loop_read_json(std::string& input, nlohmann::json& output, const std::filesystem::path& filename = "")
{
    std::string content;
    int ret = LoopReadFile(input, content, filename);
    if (ret < 0)
    {
        return -1;
    }
    else if (ret > 0)
    {
        output = "";
        return 0;
    }

    try
    {
        output = nlohmann::json::parse(content);
        return 0;
    }
    catch (...)
    {
        std::cout << "json parse fail, enter 0 to skip : (other key to exit)";
        std::cin >> input;
        if (input == "0")
        {
            output = "";
            return 0;
        }
        else
        {
            return -1;
        }
    }

    return 0;
}

void DeployContract()
{
        std::cout << std::endl
              << std::endl;

    std::cout << "AddrList : " << std::endl;
    MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();

    std::string strFromAddr;
    std::cout << "Please enter your addr:" << std::endl;
    std::cin >> strFromAddr;
    if (strFromAddr.substr(0, 2) == "0x") 
    {
        strFromAddr = strFromAddr.substr(2);
    }
    if (!isValidAddress(strFromAddr))
    {
        std::cout << "Input addr error!" << std::endl;
        return;
    }

    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }

    uint32_t nContractType = 0;
    std::string _isGastrade;
    std::cout << "Would you like to pay your handling fee separately ? [0] no  [1] yes :" << std::endl;
    std::cin >> _isGastrade;

    std::regex pattern1("^[0-1]+$");
    if (!std::regex_match(_isGastrade, pattern1))
    {
        std::cout << "Invalid input, please enter a positive integer!" << std::endl;
        return;
    }

    std::pair<std::string, std::string> gasTrade ;
    if (std::stoi(_isGastrade))
    {
        std::string GAS_ASSET_TYPE;
        std::cout << "Please enter the type of asset you want to use to pay the gas:" << std::endl;
        std::cin >> GAS_ASSET_TYPE;
        //需要从数据块取出所有币种类型  判断支付gas的类型是否存在

        std::string source_gas_address;
        std::cout << "Please enter the fromaddr you want to use to pay the gas:" << std::endl;
        std::cin >> source_gas_address;
        if (source_gas_address.substr(0, 2) == "0x") 
        {
            source_gas_address = source_gas_address.substr(2);
        }
        if (!isValidAddress(source_gas_address))
        {
            std::cout << "Input addr error!" << std::endl;
            return;
        }

        gasTrade.first = source_gas_address;
        gasTrade.second = remove0xPrefix(GAS_ASSET_TYPE);
    }
    else
    {
        gasTrade.first = strFromAddr;
        // 原Proposal Gas默认使用Vote，现改为OHI
        gasTrade.second = global::ca::ASSET_TYPE_OHI;
    }

    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;
    std::regex pattern3("^(0|1)$");
    if(!std::regex_match(input, pattern3))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }

    std::string txInfo;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txInfo);

    std::string encodedInfo = Base64Encode(txInfo);
    if(encodedInfo.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    CTransaction outTx;
    TxHelper::vrfAgentType needAgent;
    std::vector<std::string> dirtyContract;
    int ret = 0;
    if(nContractType == 0)
    {
        std::string nContractPath;
        std::cout << "Please enter contract path : (enter 0 use default path ./contract/contract) " << std::endl;
        std::cin >> nContractPath;
        std::string code;
        if (LoopReadFile(nContractPath, code, "contract") != 0)
        {
            return;
        }

        if(code.empty())
        {
            return;
        }

        std::cout << "code :" << code << std::endl;
        std::string strInput;
        std::cout << "Please enter input data (enter 0 to skip):" << std::endl;
        std::cin >> strInput;

        if (strInput == "0")
        {
            strInput.clear();
        }
        else if(strInput.substr(0, 2) == "0x")
        {
            strInput = strInput.substr(2);
            code += strInput;
        }

        std::string transferContractString;
        uint64_t contractTransfer = 0;

        auto result = Evmone::latestContractAddress(strFromAddr);
        if (!result.has_value())
        {
            return;
        }
        std::string contractAddress = result.value();
        auto pret = TxHelper::createEvmDeployContractTransactionRequest(top + 1,
                                                           outTx, gasTrade, dirtyContract,
                                                           needAgent,
                                                           code, strFromAddr, contractTransfer, contractAddress, encodedInfo,isFindUtxo);
        if(pret != 0)
        {
            ERRORLOG("Failed to create DeployContract transaction! The error code is:{}", ret)
            return;
        }        
    }
    else
    {
        return;
    }

    // Prepare contract message
    ContractTxMsgReq ContractMsg;
    ContractMsg.set_version(ohi::GetVersion());
    TxMsgReq * txMsg = ContractMsg.mutable_txmsgreq();
	txMsg->set_version(ohi::GetVersion());
    TxMsgInfo * txMsgInfo = txMsg->mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(outTx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    if (ret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        return;
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    if(nContractType == 0)
    {
        for (const auto& addr : dirtyContract)
        {
            txMsgInfo->add_contractstoragelist(addr);
        }
    }

    // Transaction can be sent normally
    auto msg = std::make_shared<ContractTxMsgReq>(ContractMsg);
    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(needAgent==TxHelper::vrfAgentType::vrfAgentType_vrf )
    {
        ret = dropCallShippingRequest(msg,outTx);
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash())
    std::cout << "Transaction result : " << ret << std::endl;
}

void CallContract()
{

    std::cout << std::endl
              << std::endl;

    std::cout << "AddrList : " << std::endl;
    MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();

    std::string strFromAddr;
    std::cout << "Please enter your addr:" << std::endl;
    std::cin >> strFromAddr;
    if (strFromAddr.substr(0, 2) == "0x") 
    {
        strFromAddr = strFromAddr.substr(2);
    }
    if (!isValidAddress(strFromAddr))
    {
        std::cout << "Input addr error!" << std::endl;
        return;
    }

    uint32_t nContractType = 0;

    DBReader dataReader;
    std::vector<std::string> deployerList;
    dataReader.getEvmDeployerAddr(deployerList);

    std::cout << "=====================deployers======================" << std::endl;
    for(auto& deployer : deployerList)
    {
        std::cout << "deployer: " << "0x"+deployer << std::endl;
    }
    std::cout << "=====================deployers======================" << std::endl;
    std::string strToAddr;
    std::cout << "Please enter to addr:" << std::endl;
    std::cin >> strToAddr;
    if (strToAddr.substr(0, 2) == "0x") 
    {
        strToAddr = strToAddr.substr(2);
    }
    if(!isValidAddress(strToAddr))
    {
        std::cout << "Input addr error!" << std::endl;
        return;        
    }

    std::string contractAddress;
    if(nContractType == 0)
    {
        std::vector<std::string> contractAddresses;
        dataReader.getContractAddrByDeployerAddr(strToAddr, contractAddresses);
        std::cout << "=====================contract addresses=====================" << std::endl;
        for(auto& contractAddress: contractAddresses)
        {
            std::string code;
            if(dataReader.getContractCodeByContractAddr(contractAddress, code) != DBStatus::DB_SUCCESS)
            {
                continue;
            }
            std::cout << "contract address: " << "0x"+contractAddress << std::endl;
        }
        std::cout << "=====================contract addresses=====================" << std::endl;

        std::cout << "Please enter contract address:" << std::endl;
        std::cin >> contractAddress;
        if (contractAddress.substr(0, 2) == "0x") 
        {
            contractAddress = contractAddress.substr(2);
        }
    }

    std::string strInput, contract_function_name;
    if(nContractType == 0)
    {
        std::cout << "Please enter args:" << std::endl;
        std::cin >> strInput;
        if(strInput.substr(0, 2) == "0x")
        {
            strInput = strInput.substr(2);
        }
    }
    std::regex pattern("^\\d+(\\.\\d+)?$");
    std::string transferContractString;
    uint64_t contractTransfer;
    if(nContractType == 0)
    {
        std::cout << "input contract transfer amount :" << std::endl;
        std::cin >> transferContractString;
        if (!std::regex_match(transferContractString, pattern))
        {
            std::cout << "input contract transfer error ! " << std::endl;
            return;
        }
        contractTransfer = (std::stod(transferContractString) + global::ca::MIN_DOUBLE_CONSTANT_PRECISION) * global::ca::kDecimalNum;
    }

    // gas
    std::string _isGastrade;
    std::cout << "Would you like to pay your handling fee separately ? [0] no  [1] yes :" << std::endl;
    std::cin >> _isGastrade;

    std::regex pattern1("^[0-1]+$");
    if (!std::regex_match(_isGastrade, pattern1))
    {
        std::cout << "Invalid input, please enter a positive integer!" << std::endl;
        return;
    }

    std::pair<std::string, std::string> gasTrade ;
    if (std::stoi(_isGastrade))
    {
        std::string GAS_ASSET_TYPE;
        std::cout << "Please enter the type of asset you want to use to pay the gas:" << std::endl;
        std::cin >> GAS_ASSET_TYPE;
        //需要从数据块取出所有币种类型  判断支付gas的类型是否存在

        std::string source_gas_address;
        std::cout << "Please enter the fromaddr you want to use to pay the gas:" << std::endl;
        std::cin >> source_gas_address;

        if (source_gas_address.substr(0, 2) == "0x") 
        {
            source_gas_address = source_gas_address.substr(2);
        }
        if (!isValidAddress(source_gas_address))
        {
            std::cout << "Input addr error!" << std::endl;
            return;
        }

        gasTrade.first = source_gas_address;
        gasTrade.second = remove0xPrefix(GAS_ASSET_TYPE);
    }
    else
    {
        gasTrade.first = strFromAddr;
        // 原RevokeProposal Gas默认使用Vote，现改为OHI
        gasTrade.second = global::ca::ASSET_TYPE_OHI;
    }

    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;
    std::regex pattern4("^(0|1)$");
    if(!std::regex_match(input, pattern4))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }

    std::string txDescriptionData;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txDescriptionData);

    std::string encodedInfo = Base64Encode(txDescriptionData);
    if(encodedInfo.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }
    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }

    CTransaction outTx;

    int ret = 0;
    TxHelper::vrfAgentType needAgent;
    std::vector<std::string> dirtyContract;
    if (nContractType == 0)
    {
        ret = TxHelper::createEvmCallContractTransactionRequest(strFromAddr, strToAddr, strInput, encodedInfo, gasTrade,top + 1,
                                                         outTx, needAgent, contractTransfer,
                                                         dirtyContract,contractAddress, isFindUtxo,false,std::stoi(_isGastrade));
        if(ret != 0)
        {
            ERRORLOG("Create call contract transaction failed! ret:{}", ret);        
            return;
        }
    }
    else
    {
        return;
    }

    ContractTxMsgReq ContractMsg;
    ContractMsg.set_version(ohi::GetVersion());
    TxMsgReq * txMsg = ContractMsg.mutable_txmsgreq();
	txMsg->set_version(ohi::GetVersion());
    TxMsgInfo * txMsgInfo = txMsg->mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(outTx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);



    uint64_t txUtxoLocalHeight = top; 
    std::string inputPart = strInput.substr(0, 8);
    if(inputPart != "6e27d889"){
        ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
        if (ret != 0)
        {
            ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
            return;
        }
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    std::cout << "size = " << dirtyContract.size() << std::endl;
    for (const auto& addr : dirtyContract)
    {
        std::cout << "addr = " << "0x"+addr << std::endl;
        DEBUGLOG("contractstoragelist addr :",addr);
        txMsgInfo->add_contractstoragelist(addr);
    }


    {
        std::string fileName = "CallContract.txt";
        std::ofstream file;
        file.open(fileName);
        PrintTx(outTx, true, file);
        file.close();
    }

    // Transaction can be sent normally
    auto msg = std::make_shared<ContractTxMsgReq>(ContractMsg);
    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(needAgent==TxHelper::vrfAgentType::vrfAgentType_vrf)
    {
        ret = dropCallShippingRequest(msg,outTx);
    }
    
    std::cout << "Transaction result : " << ret << std::endl;
}

void handleExportPrivateKey()
{
    // 1 private key, 2 annotation, 3 QR code
    std::cout << std::endl
              << std::endl;
    
    std::string address;
    std::cout << "please input the addr you want to export" << std::endl;
    std::cin >> address;
    if (address.substr(0, 2) == "0x") 
    {
        address = address.substr(2); 
    }
    
    std::string fileName = address + ".txt";
    std::ofstream file;
    file.open(fileName);

    Account account;
    if(MagicSingleton<AccountManager>::GetInstance()->FindAccount(address, account) != 0)
    {
        std::cout << "Account not found!" << std::endl;
        return;
    }

    // 获取密码以解密keystore文件
    std::string password = GetPasswordFromUser(false, "Enter password: ");
    
    // 读取和解密keystore文件
    std::string keystoreFile = GetGlobalFileManager().GetKeystoreFilePath(address);
    std::ifstream inFile(keystoreFile);
    if(!inFile.is_open()) {
        std::cout << "Cannot open keystore file for this address." << std::endl;
        return;
    }
    
    std::string keystoreJson((std::istreambuf_iterator<char>(inFile)),
                            std::istreambuf_iterator<char>());
    inFile.close();
    
    // 使用KeystoreManager解密私钥
    KeystoreManager keystoreMgr;
    std::string privateKey;
    
    if(keystoreMgr.DecryptPrivateKey(keystoreJson, password, privateKey) != 0) {
        std::cout << "Incorrect password or corrupted keystore file." << std::endl;
        return;
    }

    file << "Please use Courier New font to view" << std::endl
         << std::endl;

    file << "address: " << "0x" + address << std::endl;
    std::cout << "address: " << "0x" + address << std::endl;

    std::string hexPrivateKey = Str2Hex(privateKey);
    std::cout << "prikey :" << hexPrivateKey << std::endl;
    file << "prikey :" << hexPrivateKey << std::endl;
    file << "QRCode:";
    std::cout << "QRCode:";

    // QRCode qrcode;
    // uint8_t qrcodeData[qrcode_getBufferSize(5)];
    // qrcode_initText(&qrcode, qrcodeData, 5, ECC_MEDIUM, hexPrivateKey.c_str());

    // file << std::endl
    //      << std::endl;
    // std::cout << std::endl
    //           << std::endl;

    // for (uint8_t y = 0; y < qrcode.size; y++)
    // {
    //     file << "        ";
    //     std::cout << "        ";
    //     for (uint8_t x = 0; x < qrcode.size; x++)
    //     {
    //         file << (qrcode_getModule(&qrcode, x, y) ? "\u2588\u2588" : "  ");
    //         std::cout << (qrcode_getModule(&qrcode, x, y) ? "\u2588\u2588" : "  ");
    //     }

    //     file << std::endl;
    //     std::cout << std::endl;
    // }
    using namespace qrcodegen;
    QrCode qr = QrCode::encodeText(hexPrivateKey.c_str(), QrCode::Ecc::MEDIUM);

    file << std::endl
         << std::endl;
    std::cout << std::endl
              << std::endl;

    for (int y = 0; y < qr.getSize(); y++)
    {
        file << "        ";
        std::cout << "        ";
        for (int x = 0; x < qr.getSize(); x++)
        {
            file << (qr.getModule(x, y) ? "\u2588\u2588" : "  ");
            std::cout << (qr.getModule(x, y) ? "\u2588\u2588" : "  ");
        }

        file << std::endl;
        std::cout << std::endl;
    }

    file << std::endl
         << std::endl
         << std::endl
         << std::endl
         << std::endl
         << std::endl;
    std::cout << std::endl
              << std::endl
              << std::endl
              << std::endl
              << std::endl
              << std::endl;


    CaConsole redColor(CONSOLE_COLOR_RED, CONSOLE_COLOR_BLACK, true);
    std::cout << redColor.Color() << "You can also view above in file:" << fileName << " of current directory." << redColor.Reset() << std::endl;
    return;
}

void handleExportAllPrivateKeys()
{
    std::vector<std::string> accountList;
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(accountList);

    if (accountList.empty())
    {
        std::cout << "No accounts found!" << std::endl;
        return;
    }

    // 获取统一密码
    std::string password = GetPasswordFromUser(false, "Enter password for all accounts: ");
    if (password.empty())
    {
        std::cout << "Password cannot be empty." << std::endl;
        return;
    }

    std::string fileName = "all_private_keys.txt";
    std::ofstream file(fileName);
    if (!file.is_open())
    {
        std::cout << "Cannot open file: " << fileName << std::endl;
        return;
    }

    file << "Please use Courier New font to view" << std::endl
         << std::endl;

    int successCount = 0;
    int failCount = 0;

    for (const auto &address : accountList)
    {
        Account account;
        if (MagicSingleton<AccountManager>::GetInstance()->FindAccount(address, account) != 0)
        {
            std::cout << "Account not found: 0x" << address << ", skipping." << std::endl;
            failCount++;
            continue;
        }

        // 读取并解密keystore文件
        std::string keystoreFile = GetGlobalFileManager().GetKeystoreFilePath(address);
        std::ifstream inFile(keystoreFile);
        if (!inFile.is_open())
        {
            std::cout << "Cannot open keystore file for 0x" << address << ", skipping." << std::endl;
            failCount++;
            continue;
        }

        std::string keystoreJson((std::istreambuf_iterator<char>(inFile)),
                                 std::istreambuf_iterator<char>());
        inFile.close();

        KeystoreManager keystoreMgr;
        std::string privateKey;

        if (keystoreMgr.DecryptPrivateKey(keystoreJson, password, privateKey) != 0)
        {
            std::cout << "Failed to decrypt keystore for 0x" << address << ", skipping." << std::endl;
            failCount++;
            continue;
        }

        std::string hexPrivateKey = Str2Hex(privateKey);

        file << "address: 0x" << address << std::endl;
        file << "prikey : " << hexPrivateKey << std::endl;
        file << std::endl;

        std::cout << "Exported: 0x" << address << std::endl;
        successCount++;
    }

    file.close();

    std::cout << std::endl;
    std::cout << "Export completed! Success: " << successCount << ", Failed: " << failCount << std::endl;
    std::cout << "You can view the result in file: " << fileName << " of current directory." << std::endl;
}

int GetChainHeight(unsigned int &chainHeight)
{
    DBReader dbReader;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        return -1;
    }
    chainHeight = top;
    return 0;
}

void net_register_callback()
{
    net_callback::register_chain_height_callback(GetChainHeight);
    net_callback::register_calculate_chain_height_callback(MagicSingleton<BlockHelper>::GetInstance()->getChainHeight);
}

/**
 * @description: Registering Callbacks
 * @param {*}
 * @return {*}
 */
void RegisterCallback()
{
    net_register_callback();
}

void TestCreateTx(const std::vector<std::string> &addrs, const int &sleepTime)
{
    if (addrs.size() < 2)
    {
        std::cout << "Insufficient number of accounts" << std::endl;
        return;
    }
#if 0
    isCreateTx = true;
    while (1)
    {
        if (bStopTx)
        {
            break;
        }
        int intPart = rand() % 10;
        double decPart = (double)(rand() % 100) / 100;
        double amount = intPart + decPart;
        std::string amountStr = std::to_string(amount);

        std::cout << std::endl << std::endl << std::endl << "=======================================================================" << std::endl;
        CreateTx("1vkS46QffeM4sDMBBjuJBiVkMQKY7Z8Tu", "18RM7FNtzDi41QEU5rAnrFdVaGBHvhTTH1", amountStr.c_str(), NULL, 6, "0.01");
        std::cout << "=====Transaction initiator:1vkS46QffeM4sDMBBjuJBiVkMQKY7Z8Tu" << std::endl;
        std::cout << "=====Transaction recipient:18RM7FNtzDi41QEU5rAnrFdVaGBHvhTTH1" << std::endl;
        std::cout << "=====Transaction amount:" << amountStr << std::endl;
        std::cout << "=======================================================================" << std::endl << std::endl << std::endl << std::endl;

        sleep(sleepTime);
    }
    isCreateTx = false;

#endif

#if 1
    isCreateTx = true;

    for (int i = 0; i < addrs.size(); i++)
    {
        if (bStopTx)
        {
            std::cout << "Close the deal!" << std::endl;
            break;
        }
        int intPart = rand() % 10;
        double decPart = (double)(rand() % 100) / 100;
        std::string amountStr = std::to_string(intPart  + decPart );


        std::string from, to;
        if (i >= addrs.size() - 1)
        {
            from = addrs[addrs.size() - 1];
            to = addrs[0];
            i = 0;
        }
        else
        {
            from = addrs[i];
            to = addrs[i + 1];
        }
        if (from != "")
        {
            if (!MagicSingleton<AccountManager>::GetInstance()->IsExist(from))
            {
                DEBUGLOG("Illegal account.");
                continue;
            }
        }
        else
        {
            DEBUGLOG("Illegal account. from addr is null !");
            continue;
        }

        std::cout << std::endl
                  << std::endl
                  << std::endl
                  << "=======================================================================" << std::endl;

        std::vector<std::string> fromAddr;
        fromAddr.emplace_back(from);
        std::map<std::string, int64_t> to_addr_amount;
        uint64_t amount = (stod(amountStr) + global::ca::MIN_DOUBLE_CONSTANT_PRECISION) * global::ca::kDecimalNum;
        if(amount == 0)
        {
            std::cout << "aomunt = 0" << std::endl;
            DEBUGLOG("aomunt = 0");
            continue;
        }
        to_addr_amount[to] = amount;



        DBReader dbReader;
        uint64_t top = 0;
        if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
        {
            ERRORLOG("db get top failed!!");
            continue;
        }

        CTransaction outTx;
        TxHelper::vrfAgentType needAgent;
        std::string encodedInfo = "";

        TxMsgReq txMsg;
        txMsg.set_version(ohi::GetVersion());
        TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
        txMsgInfo->set_type(0);
        txMsgInfo->set_tx(outTx.SerializeAsString());
        txMsgInfo->set_nodeheight(top);

        uint64_t txUtxoLocalHeight;
        int ret;
        ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
        if(ret != 0)
        {
            ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
            return;
        }

        txMsgInfo->set_txutxoheight(txUtxoLocalHeight);
        
        auto msg = std::make_shared<TxMsgReq>(txMsg);

        std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
        if(outTx.identity() == defaultAddr)
        {
            ret = handleTransaction(msg,outTx);
        }
        else
        {
            ret = DropShippingTransaction(msg, outTx, outTx.identity());
        }
        DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());

        std::cout << "=====Transaction initiator:" << from << std::endl;
        std::cout << "=====Transaction recipient:" << to << std::endl;
        std::cout << "=====Transaction amount:" << amountStr << std::endl;
        std::cout << "=======================================================================" << std::endl
                  << std::endl
                  << std::endl
                  << std::endl;

        usleep(sleepTime);
    }
    isCreateTx = false;
#endif
}

void ThreadStart()
{
    std::vector<std::string> addrs;
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(addrs);

    int sleepTime = 8;
    std::thread th(TestCreateTx, addrs, sleepTime);
    th.detach();
}

int CheckNtpTime()
{
    // Ntp check
    int64_t getNtpTime = MagicSingleton<TimeUtil>::GetInstance()->GetNtpTimestamp();
    int64_t getLocTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();

    int64_t tmpTime = abs(getNtpTime - getLocTime);

    std::cout << "UTC Time: " << MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(getLocTime) << std::endl;
    std::cout << "NTP Time: " << MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(getNtpTime) << std::endl;

    if (tmpTime <= 1000000)
    {
        DEBUGLOG("ntp timestamp check success");
        return 0;
    }
    else
    {
        DEBUGLOG("ntp timestamp check fail");
        std::cout << "time check fail" << std::endl;
        return -1;
    }
}

// // std::string deployContractRequest(void * arg,void *ack)
// {
//     deploy_contract_req * req=(deploy_contract_req *)arg;
//     contractAck *ack_t=(contractAck*)ack;

   
//     std::string strFromAddr = req->addr;
//     if (strFromAddr.substr(0, 2) == "0x") 
//     {
//         strFromAddr = strFromAddr.substr(2);
//     }

//     if (!isValidAddress(strFromAddr))
//     {
//         ack_t->code = -1;
//         ack_t->message = "Input addr error!";
//         errorL("Input addr error!");
//         return "-1";
//     }

//     DBReader dataReader;

//     uint64_t top = 0;
//     int retNum = transactionDiscoveryHeight(top);
//     if(retNum != 0){
//         ack_t->code = -2;
//         ack_t->message = "Created a deal height failed";
//         ERRORLOG("transactionDiscoveryHeight error {}", retNum);
//         return "-2";
//     }

//     ack_t->height = std::to_string(top);
//     DEBUGLOG("create deploy contract tx ,top : {}",top)
//     std::pair<std::string, std::string> gasTrade = req->gasTrade;
//     gasTrade.second = remove0xPrefix(gasTrade.second);

//     std::string firstParam = gasTrade.first;
//     if (firstParam.substr(0, 2) == "0x") {
//         firstParam = firstParam.substr(2);
//     }
//     gasTrade.first = firstParam;

//     std::string assetType;
//     int ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
//     if(ret != 0){
//         ack_t->code = -6;
//         ack_t->message  = "Get CanBeRevoke AssetType fail!";
//     }

//     std::string secondParam = gasTrade.second;
//     if (secondParam.empty()) {
//         gasTrade.second = assetType; 
//     }

//     uint32_t nContractType=std::stoi(req->nContractType);
//     nlohmann::json contract_info=nlohmann::json::parse(req->info);

//     bool is_find_utxo_flag = req->isFindUtxo;
    
//     CTransaction outTx;
//     TxHelper::vrfAgentType needAgent;
//     std::vector<std::string> dirtyContract;
//     std::string encodedInfo = Base64Encode(req->txInfo);
//     if(encodedInfo.size() > 1024){
//         ack_t->code = -3;
//         ack_t->message = "The information entered exceeds the specified length";
//         ERRORLOG("The information entered exceeds the specified length!");
//         return "-3";
//     }
//     if(nContractType == 0)
//     {
//         std::string code=req->contract;
//         std::string strInput=req->data;

//         if (strInput == "0")
//         {
//             strInput.clear();
//         }
//         else if(strInput.substr(0, 2) == "0x")
//         {
//             strInput = strInput.substr(2);
//             code += strInput;
//         }

//        Base64 base_;
//        std::string ownerEvmAddress = GenerateAddr(base_.Decode(req->pubstr.c_str(), req->pubstr.size()));
//         auto result = Evmone::latestContractAddress(strFromAddr);
//         if (!result.has_value())
//         {
//             ack_t->code = -4;
//             ack_t->message = "Get contractaddress failed!";
//             ERRORLOG("Get contractaddress failed!");
//             return "-4";
//         }

//         uint64_t contractTransfer = 0;
//         std::string contractAddress = result.value();
//         auto aret = TxHelper::createEvmDeployContractTransactionRequest(top + 1,
//                                                                outTx, gasTrade, dirtyContract,
//                                                                needAgent,
//                                                                code, strFromAddr, contractTransfer, contractAddress, encodedInfo, is_find_utxo_flag,true);
//         if (aret != 0)
//         {
//             ack_t->code = ret - 2000;
//             ack_t->message = "Failed to create DeployContract transaction!";
//             return "Failed to create DeployContract transaction!";
//         }        
//     }
//     else
//     {
//         ack_t->code = -5;
//         ack_t->message = "nContractType Invalid";
//         ERRORLOG("nContractType Invalid");
//         return "-5";
//     }

//     ContractTxMsgReq ContractMsg;
//     ContractMsg.set_version(ohi::GetVersion());
//     TxMsgReq * txMsg = ContractMsg.mutable_txmsgreq();
// 	txMsg->set_version(ohi::GetVersion());
//     TxMsgInfo * txMsgInfo = txMsg->mutable_txmsginfo();
//     txMsgInfo->set_type(0);
//     txMsgInfo->set_nodeheight(top);

//     uint64_t txUtxoLocalHeight;
//     ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
//     if (ret != 0)
//     {
//         ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
//         return "-5";
//     }

//     txMsgInfo->set_txutxoheight(txUtxoLocalHeight);
//     for (const auto& addr : dirtyContract)
//     {
//         txMsgInfo->add_contractstoragelist(addr);
//     }

//     std::string contractRequest;
//     std::string txJs;
//     google::protobuf::util::MessageToJsonString(ContractMsg,&contractRequest);
//     google::protobuf::util::MessageToJsonString(outTx,&txJs);
//     ack_t->contractJs=contractRequest;
//     ack_t->txJson=txJs;
//     return "0";
// }

// std::string rpcCallRequest(void * arg,void *ack)
// {
//     call_contract_req * req=(call_contract_req*)arg;
//     contractAck *ack_t = (contractAck*)ack;

//     bool isToChain=(req->istochain=="true" ? true:false);
//     std::string strFromAddr = req->addr;
//     if (strFromAddr.substr(0, 2) == "0x") 
//     {
//         strFromAddr = strFromAddr.substr(2);
//     }
//     if (!isValidAddress(strFromAddr))
//     {
//         ack_t->code = -1;
//         ack_t->message = "from addr error!";
// 	    ERRORLOG("Input addr error!");
//         return "from addr error!";
//     }

//     DBReader dataReader;
//     std::vector<std::string> deployerList;
//     std::string strToAddr=req->deployer;
//     if(strToAddr.substr(0,2) == "0x")
//     {
//         strToAddr = strToAddr.substr(2);
//     }
//     if(!isValidAddress(strToAddr))
//     {
//         ack_t->code = -2;
//         ack_t->message = "to addr error!";
//         ERRORLOG("to addr error!");
//         return "to addr error!"; 
//     }  

//     std::string strTxHash=req->deployutxo;
//     if(strTxHash.substr(0, 2) == "0x")
//     {
//         strTxHash = strTxHash.substr(2);
//     }

//     std::string strInput=req->args;
//     if(strInput.substr(0, 2) == "0x")
//     {
//         strInput = strInput.substr(2);
//     }

//     std::string _contractAddress =  req->contractAddress;
//     if(_contractAddress.substr(0, 2) == "0x")
//     {
//         _contractAddress = _contractAddress.substr(2);
//     }
   
//     std::regex pattern("^\\d+(\\.\\d+)?$");
//     std::string transferContractString=req->money;
    
//     if (!std::regex_match(transferContractString, pattern))
//     {
//         ack_t->code = -4;
//         ack_t->message = "money regex match error";
//         ERRORLOG("regex match error");
//         return "regex match error";
//     }
    
//     bool is_find_utxo_flag = req->isFindUtxo;

//     uint64_t contractTransfer = (std::stod(transferContractString) + global::ca::MIN_DOUBLE_CONSTANT_PRECISION) * global::ca::kDecimalNum;
//     uint64_t top = 0;
//     int retNum = transactionDiscoveryHeight(top);
//     if(retNum != 0){
//         ack_t->code = -5;
//         ack_t->message = "db get top failed!!";
//         ERRORLOG("transactionDiscoveryHeight get top failed ret :{}", retNum);
//         return "db get top failed!!";
//     }
//     ack_t->height = std::to_string(top);
//     DEBUGLOG("rpcCallRequest create tx top: {}", top);

//     std::string encodedInfo = Base64Encode(req->txInfo);
//     if(encodedInfo.size() > 1024){
//         ack_t->code = -6;
//         ack_t->message = "The information entered exceeds the specified length";
//         ERRORLOG("The information entered exceeds the specified length");
//         return "The information entered exceeds the specified length";
//     }

//     CTransaction outTx;
//     CTransaction tx;
//     std::string txRaw;
//     if (DBStatus::DB_SUCCESS != dataReader.getTransactionByHash(strTxHash, txRaw))
//     {
//         ack_t->code = -7;
//         ack_t->message = "get contract transaction failed!!";
//         ERRORLOG("get contract transaction failed!!");
//         return "get contract transaction failed!!";
//     }
//     if(!tx.ParseFromString(txRaw))
//     {
//         ack_t->code = -8;
//         ack_t->message = "contract transaction parse failed!!";
//         ERRORLOG("contract transaction parse failed!!");
//         return "contract transaction parse failed!!";
//     }

//     std::pair<std::string, std::string> gasTrade = req->gasTrade;
//     gasTrade.second = remove0xPrefix(gasTrade.second);

//     std::string firstParam = gasTrade.first;
//     if (firstParam.substr(0, 2) == "0x") {
//         firstParam = firstParam.substr(2);
//     }
//     gasTrade.first = firstParam;

//     std::string assetType;
//     int ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
//     if(ret != 0){
//         ack_t->code = -9;
//         ack_t->message  = "Get CanBeRevoke AssetType fail!";
//     }

//     std::string secondParam = gasTrade.second;
//     if (secondParam.empty()) {
//         gasTrade.second = assetType; 
//     }

//     nlohmann::json dataJson = nlohmann::json::parse(tx.data());
//     nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
//     int vmType = txInfo[Evmone::contractVmKeyName].get<int>();

//     TxHelper::vrfAgentType needAgent;
//     std::vector<std::string> dirtyContract;
//     if (vmType == global::ca::VmType::EVM)
//     {
       
//         Base64 base_;
//         std::string ownerEvmAddress = GenerateAddr(base_.Decode(req->pubstr.c_str(), req->pubstr.size()));
//         if(isToChain)
//         {
//             ret = TxHelper::createEvmCallContractTransactionRequest(strFromAddr, strToAddr, strInput, encodedInfo, gasTrade, top + 1,
//                                                              outTx, needAgent, contractTransfer,
//                                                              dirtyContract, _contractAddress, is_find_utxo_flag,true,req->isGasTrade);
//             if(ret != 0)
//             {
//                 ack_t->code = ret - 2000;
//                 ack_t->message = "Create call contract transaction failed!";
//                 ERRORLOG("Create call contract transaction failed! ret:{}", ret);        
//                 return "Create call contract transaction failed!";
//             }


//         }
//         else
//         {
//             ret = MagicSingleton<TxHelper>::GetInstance()->evmCallContractTransactionCreationRequest(strFromAddr, strToAddr,
//                                                                     strInput,encodedInfo,gasTrade,
//                                                                     top + 1,
//                                                                     outTx, needAgent,
//                                                                     contractTransfer,
//                                                                     dirtyContract,
//                                                                     _contractAddress,
//                                                                     is_find_utxo_flag,true);
//             if(ret != 0)
//             {
//                 ack_t->code = ret - 3000;
//                 ack_t->message = "Create call contract transaction failed!";
//                 ERRORLOG("Create call contract transaction failed! ret:{}", ret );        
//                 return "Create call contract transaction failed!";
//             }
//         }
//     }
//     else
//     {
// 	    ack_t->code = -10;
// 	    ack_t->message = "VmType is not EVM";
//         return "VmType is not EVM";
//     }

//     ContractTxMsgReq ContractMsg;
//     ContractMsg.set_version(ohi::GetVersion());
//     TxMsgReq * txMsg = ContractMsg.mutable_txmsgreq();
// 	txMsg->set_version(ohi::GetVersion());
//     TxMsgInfo * txMsgInfo = txMsg->mutable_txmsginfo();
//     txMsgInfo->set_type(0);
//     txMsgInfo->set_nodeheight(top);

//     uint64_t txUtxoLocalHeight = 0;
//     if(isToChain){
//         std::string inputPart = strInput.substr(0, 8);
//         if(inputPart != "6e27d889"){
//             ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
//             if (ret != 0)
//             {
//                 ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
//                 return "get_tx_utxo_height fail!";
//             }
//         }
//     }

//     std::cout << "size = " << dirtyContract.size() << std::endl;
//     for (const auto& addr : dirtyContract)
//     {
//         std::cout << "addr = " << "0x"+addr << std::endl;
//         txMsgInfo->add_contractstoragelist(addr);
//     }

//     txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

//     std::cout << "size = " << dirtyContract.size() << std::endl;
//     for (const auto &addr : dirtyContract)
//     {
//         std::cout << "addr = " << addHexPrefix(addr) << std::endl;
//         txMsgInfo->add_contractstoragelist(addr);
//     }

//     std::string txJsonString;
// 	std::string contract_json_string;
// 	google::protobuf::util::Status status =google::protobuf::util::MessageToJsonString(outTx,&txJsonString);
// 	status=google::protobuf::util::MessageToJsonString(ContractMsg,&contract_json_string);
// 	ack_t->contractJs=contract_json_string;
//     ack_t->txJson=txJsonString;
//     return "0";
    
// }



int SigTx(CTransaction &tx,const std::string & addr){
    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

    for (int i = 0; i < tx.utxos_size(); ++i)
    {
        int index = 0;
        auto utxo = tx.mutable_utxos(i);
        auto vin = utxo->mutable_vin();
        for (auto &owner : utxo->owner())
        {
            // vin sign
            if(utxo->vin_size() == 0)
            {
                continue;
            }
            auto vin_t = vin->Mutable(index);
            if (!vin_t->contractaddr().empty())
            {
                index++;
                continue;
            }

            std::string vinHashSerialized = Getsha256Hash(vin_t->SerializeAsString());
            std::string signature;
            std::string pub;

            std::string signAddr = "";
            if(!tx.rlp().empty()){
                signAddr = defaultAddr;
            }else{
                signAddr = addr;
            }

            if (TxHelper::Sign(signAddr, vinHashSerialized, signature, pub))
            {
                return -1;
            }

            CSign *vinSign = vin_t->mutable_vinsign();
            vinSign->set_sign(signature);
            vinSign->set_pub(pub);
            index++;
        }
        /// utxo sign
        CTxUtxos copyTransactionUtxo = *utxo;
        copyTransactionUtxo.clear_multisign();
        {
            std::string serializeTransactionUtxoRequest = Getsha256Hash(copyTransactionUtxo.SerializeAsString());
            std::string signature;
            std::string pub;

            std::string signAddr = "";
            if(!tx.rlp().empty()){
                signAddr = defaultAddr;
            }else{
                signAddr = addr;
            }

            if (TxHelper::Sign(signAddr, serializeTransactionUtxoRequest, signature, pub))
            {
                return -2;
            }

            CSign *multiSign = utxo->add_multisign();
            multiSign->set_sign(signature);
            multiSign->set_pub(pub);
        }
    }
    return 0;
}

void handleMultiDeployContract(const std::string &strFromAddr)
{
    if (!isValidAddress(strFromAddr))
    {
        std::cout << "Input addr error!" << std::endl;
        return;
    }

    DBReader dataReader;
    uint64_t top = 0;
	if (DBStatus::DB_SUCCESS != dataReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return ;
    }

    CTransaction outTx;
    TxHelper::vrfAgentType needAgent;
    std::vector<std::string> dirtyContract;
    std::string assetTypeS;
    int ret1 = ca_algorithm::GetCanBeRevokeAssetType(assetTypeS);
    if (ret1 != 0) {
        ERRORLOG("Get Can Be Revoke AssetType fail!");
        return; 
    }
    
    std::pair<std::string,std::string> gasTrade = {strFromAddr, assetTypeS};

    std::string nContractPath = "0";
    std::string code;
    int ret = LoopReadFile(nContractPath, code, "contract");
    if (ret != 0)
    {
        return;
    }

    if(code.empty())
    {
        return;
    }

    auto result = Evmone::latestContractAddress(strFromAddr);
    if (!result.has_value())
    {
        return;
    }
    std::string encodedInfo = "";
    uint64_t contractTransfer = 0;
    std::string contractAddress = result.value();
    auto aret = TxHelper::createEvmDeployContractTransactionRequest(top + 1,
                                                       outTx, gasTrade, dirtyContract,
                                                       needAgent,
                                                       code, strFromAddr, contractTransfer, contractAddress, encodedInfo);
    if(aret != 0)
    {
        ERRORLOG("Failed to create DeployContract transaction! The error code is:{}", ret);
        return;
    }
    
    ContractTxMsgReq ContractMsg;
    ContractMsg.set_version(ohi::GetVersion());
    TxMsgReq * txMsg = ContractMsg.mutable_txmsgreq();
	txMsg->set_version(ohi::GetVersion());
    TxMsgInfo * txMsgInfo = txMsg->mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(outTx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);
    uint64_t txUtxoLocalHeight;
    ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    if(ret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        return;
    }

    for (const auto& addr : dirtyContract)
    {
        txMsgInfo->add_contractstoragelist(addr);
    }

    auto msg = std::make_shared<ContractTxMsgReq>(ContractMsg);
    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(needAgent == TxHelper::vrfAgentType::vrfAgentType_vrf )
    {
        ret = dropCallShippingRequest(msg, outTx);
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());
    std::cout << "Transaction result : " << ret << std::endl;
}


void createAutomaticDeployContract()
{
    std::vector<std::string> accounts;
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(accounts);

    uint64_t time;
    std::cout << "please input time seconds >:";
    std::cin >> time;

    for(auto &fromAddr :accounts)
    {
        handleMultiDeployContract(fromAddr);
        sleep(time);
    }
}

void printJson()
{
    std::multimap<std::string,std::string> mDeployMap_;
    std::string fileName = "print_Delopy_addr_utxo.txt";
    std::ofstream filestream;
    filestream.open(fileName);
    if (!filestream)
    {
        std::cout << "Open file failed!" << std::endl;
        return;
    }

    DBReader dbReader;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return;
    }

    int InitialHeight = 0; 
    std::cout << "Please enter the initial height" << std::endl;
    std::cout << ">>>";
    std::cin >> InitialHeight;

    std::vector<std::string> localAddress;
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(localAddress);

    for(int i = InitialHeight ; i <= top ; ++i)
    {
        std::vector<std::string> hashes;
        if (DBStatus::DB_SUCCESS != dbReader.getBlockHashsByBlockHeight(i,hashes))
        {
            ERRORLOG("db get top failed!!");
            return;
        }

        for(auto &hash : hashes)
        {
            std::string blockStr;
            if (DBStatus::DB_SUCCESS != dbReader.getBlockByBlockHash(hash,blockStr))
            {
                ERRORLOG("db get top failed!!");
                return;
            }
            CBlock block;
            block.ParseFromString(blockStr);
            for(auto & ContractTx : block.txs())
            {
                if ((global::ca::TxType)ContractTx.type() != global::ca::TxType::DEPLOY)
                {
                    continue;
                }

                std::string fromAddr = ContractTx.utxos(0).owner(0);
                std::string contractAddress;
                try
                {
                    nlohmann::json dataJson = nlohmann::json::parse(ContractTx.data());
                    nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                    contractAddress = txInfo[Evmone::contractRecipientKeyNameStr].get<std::string>();
                }
                catch (const std::exception& e)
                {
                    std::cout << RED << "fail to parse contract address of tx " << ContractTx.hash() << RESET << std::endl;
                    continue;
                }

                for( auto & item : localAddress)
                {
                    if (item == fromAddr)
                    {
                        try
                        {
                            nlohmann::json dataJson = nlohmann::json::parse(ContractTx.data());
                            nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                            contractAddress = txInfo[Evmone::contractRecipientKeyNameStr].get<std::string>();
                        }
                        catch (const std::exception& e)
                        {
                            std::cout << RED << "fail to parse contract address of tx " << ContractTx.hash() << RESET << std::endl;
                            continue;
                        }
                        
                        std::cout << "export " << fromAddr << " deploy contract" << std::endl;
                        mDeployMap_.insert({fromAddr,contractAddress});
                    }
                }
            }
        }
    }

    std::string arg;
    std::cout << "print arg :";
    std::cin >> arg;
    nlohmann::json addr_utxo;
    for(auto & item : mDeployMap_)
    {
        nlohmann::json addr;
        addr["deployer"] =  item.first;
        addr["contractAddresses"] =  item.second;
        addr["arg"] = arg;
        addr["money"] = "0";
        addr_utxo["addr_utxo"].push_back(addr);
    }

    filestream << addr_utxo.dump();
    filestream.close();
}

std::string remove0xPrefix(std::string str) 
{
    if (str.length() > 2 && str.substr(0, 2) == "0x") {
        return str.substr(2);
    }
    return str;
}

std::string addHexPrefix(std::string hexStr) {
    if(hexStr.empty()) {
        return hexStr;
    }
  return "0x" + hexStr;
}


void HandleLock()
{
    std::cout << std::endl
              << std::endl;

    Account account;
    MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(account);
    std::string strFromAddr = account.GetAddr();
    std::string fromAddr = remove0xPrefix(strFromAddr);
    std::cout << "Lock addr: " << "0x"+ strFromAddr << std::endl;
    std::cout << "Please enter lock amount: " << std::endl;
    std::string lockAmountStr;
    std::cin >> lockAmountStr;
    std::regex pattern("^[1-9]\\d*$"); 
    if(!std::regex_match(lockAmountStr, pattern))
    {
        std::cout << "Input lockAmount error" << std::endl;
        return;
    }
    uint64_t lockAmount = std::stoull(lockAmountStr);
    if(lockAmount < global::ca::LOCK_AMOUNT)
    {
        std::cout << "Lock amount must be greater than or equal " << global::ca::LOCK_AMOUNT << std::endl;
        return;
    }

    std::string _isGastrade;
    std::cout << "Would you like to pay your handling fee separately ? [0] no  [1] yes :" << std::endl;
    std::cin >> _isGastrade;
    std::regex pattern2("^[0-1]+$");
    if (!std::regex_match(_isGastrade, pattern2))
    {
        std::cout << "Invalid input, please enter a positive integer!" << std::endl;
        return;
    }


    std::pair<std::string,std::string> gasTrade = {};
    if (CheckGasAssetsInput(_isGastrade,gasTrade) != 0)
    {
        return ;
    }

    if(global::ca::ASSET_TYPE_OHI == gasTrade.second){
        std::cout << "The asset type involved in the transaction cannot be used to pay gas alone!" << std::endl;
        return;
    }

    TxHelper::LockType lockType = TxHelper::LockType::kLock_Node;

    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;
    std::regex pattern1("^(0|1)$");
    if(!std::regex_match(input, pattern1))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }

    std::string txDescriptionData;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txDescriptionData);

    std::string encodedInfo = Base64Encode(txDescriptionData);
    if(encodedInfo.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    DBReader dbReader;
    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum); 
        return;
    }

    LockTrans::LockTransParam param;
    param.lock_addr = fromAddr;
    param.lock_amount = lockAmount *global::ca::kDecimalNum;
    param.lock_type = lockType;
    param.height=top+1;
    param.is_find_utxo = isFindUtxo;
    param.gas= {gasTrade.first, gasTrade.second};
    param.is_gas_tray = _isGastrade == "1" ? true : false;
    param.encoded_info = encodedInfo;   

    LockTrans lockt(param);

    auto ret = lockt.trans();
    if (!ret.isOk())
    {
        ERRORLOG("LockTrans error {}", ret.error_message(true));
        std::cerr << ret.error_message() << std::endl;
        return ;
    };

    auto siret=lockt.signTx("");

    if(!siret.isOk()){
        ERRORLOG("sign LockTrans tx error {}", siret.error_message(true));
        std::cerr << siret.error_message() << std::endl;
        return ;
    }
    lockt.print_debug_tx();

    auto msgret=lockt.goMessage();

    if(!msgret.isOk()){
        ERRORLOG("goMessage LockTrans tx error {}", msgret.error_message(true));
        std::cerr <<msgret.error_message() << std::endl;
        return ;
    }

    // CTransaction outTx;
    // std::vector<TxHelper::Utxo> outVin;
    // TxHelper::vrfAgentType needAgent;
    // if (TxHelper::createLockTransaction(fromAddr, lockAmount * global::ca::kDecimalNum, top + 1,  lockType, outTx, outVin,needAgent,gasTrade,std::stoi(_isGastrade),isFindUtxo, encodedInfo) != 0)
    // {
    //     return;
    // }

    // TxMsgReq txMsg;
    // txMsg.set_version(ohi::GetVersion());
    // TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    // txMsgInfo->set_type(0);
    // txMsgInfo->set_tx(outTx.SerializeAsString());
    // txMsgInfo->set_nodeheight(top);

    // uint64_t txUtxoLocalHeight;
    // auto ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    // if(ret != 0)
    // {
    //     ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
    //     return;
    // }

    // txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    // auto msg = std::make_shared<TxMsgReq>(txMsg);

    // std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

    // if(outTx.identity() == defaultAddr)
    // {
    //     ret = handleTransaction(msg,outTx);
    // }
    // else
    // {
    //     ret = DropShippingTransaction(msg, outTx, outTx.identity());
    // }

    // if (ret != 0)
    // {
    //     ret -= 100;
    // }

    // DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());
}   


//解投票质押菜单              
void HandleUnLock()
{
    std::cout << std::endl
              << std::endl;


    std::string _isGastrade;
    std::cout << "Would you like to pay your handling fee separately ? [0] no  [1] yes :" << std::endl;
    std::cin >> _isGastrade;
    std::regex pattern2("^[0-1]+$");
    if (!std::regex_match(_isGastrade, pattern2))
    {
        std::cout << "Invalid input, please enter a positive integer!" << std::endl;
        return;
    }

    std::pair<std::string,std::string> gasTrade = {};
    if (CheckGasAssetsInput(_isGastrade,gasTrade) != 0)
    {
        return;
    }

    if(global::ca::ASSET_TYPE_OHI == gasTrade.second){
        std::cout << "The asset type involved in the transaction cannot be used to pay gas alone!" << std::endl;
        return;
    }

    std::string strFromAddr;
    std::cout << "Please enter unLock addr:" << std::endl;
    std::cin >> strFromAddr;
    std::string fromAddr = remove0xPrefix(strFromAddr);

    DBReader dbReader;
    std::vector<std::string> stake_unspent_outputs;
    auto dbret = dbReader.getLockAddrUtxo(fromAddr, global::ca::ASSET_TYPE_OHI ,stake_unspent_outputs);
    if(dbret == DBStatus::DB_NOT_FOUND)
	{
		std::cout << "Please lock it first!" << std::endl;
		return;
	}
    if(dbret == DBStatus::DB_ERROR)
    {
        std::cout << "getLockAddrUtxo error" << std::endl;
        return;
    }

    std::reverse(stake_unspent_outputs.begin(), stake_unspent_outputs.end());
    std::cout << "-- Current pledge amount: -- " << std::endl;
    for (auto &utxo : stake_unspent_outputs)
    {
        std::string txRaw;
        dbReader.getTransactionByHash(utxo, txRaw);
        CTransaction tx;
        tx.ParseFromString(txRaw);
        uint64_t value = 0;
        for(const auto & utxo: tx.utxos())
        {
            for (auto &vout : utxo.vout())
            {
                if (vout.addr() == global::ca::VIRTUAL_LOCK_ADDRESS)
                {
                    value = vout.value();
                    break;
                }
            }
        }

        std::cout << "utxo: " << utxo << " value: " << value << std::endl;
    }

    std::cout << std::endl;

    std::string utxo_hash_str;
    std::cout << "utxo:";
    std::cin >> utxo_hash_str;

    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;
    std::regex _pattern("^(0|1)$");
    if(!std::regex_match(input, _pattern))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }

    std::string txDescriptionData;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txDescriptionData);

    std::string encodedInfo = Base64Encode(txDescriptionData);
    if(encodedInfo.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }

    UnlockTrans::UnlockTransParam param;
    param.lock_addr = fromAddr;
    param.utxo_hash = utxo_hash_str;
    param.height = top + 1;
    param.is_find_utxo = isFindUtxo;
    param.gas = {gasTrade.first, gasTrade.second};
    param.is_gas_tray = _isGastrade == "1" ? true : false;
    param.encoded_info = encodedInfo;

    UnlockTrans unlockt(param);

    auto ret = unlockt.trans();
    if (!ret.isOk())
    {
        ERRORLOG("UnlockTrans error {}", ret.error_message(true));
        std::cerr << ret.error_message() << std::endl;
        return ;
    };

    auto siret = unlockt.signTx("");
    if(!siret.isOk()){
        ERRORLOG("sign UnlockTrans tx error {}", siret.error_message(true));
        std::cerr << siret.error_message() << std::endl;
        return ;
    }

    unlockt.print_debug_tx();
    auto msgret = unlockt.goMessage();
    if(!msgret.isOk()){
        ERRORLOG("goMessage UnlockTrans tx error {}", msgret.error_message(true));
        std::cerr << msgret.error_message() << std::endl;
        return ;
    }
}      
   

//创世账号发起添加资产投票菜单
void HandleProposal()
{
    std::cout << std::endl
              << std::endl;

    Account account;
    MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(account);
    std::string strFromAddr = account.GetAddr();
    std::string fromAddr = remove0xPrefix(strFromAddr);
    std::cout << "Proposal addr: " << "0x"+strFromAddr << std::endl;
    if(strFromAddr != GetInitAccountAddr())
    {
        std::cout << "The default account is not the genesis account" << std::endl;
        return;
    }

    std::pair<std::string,std::string> gasTrade = {};
    std::string gasAssetype = global::ca::ASSET_TYPE_OHI;
    std::string source_gas_address = GetInitAccountAddr();
    
    gasTrade.first = remove0xPrefix(source_gas_address);
    gasTrade.second = gasAssetype;

    std::cout << "Please enter the asset name:" << std::endl;
    std::string assetName;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, assetName);
    std::regex const patternName("^[0-9A-Za-z]+$");
    if (!std::regex_match(assetName, patternName))
    {
        std::cout << "input assetName error " << std::endl;
        return;
    }
    if(assetName.size() > 1024)
    {
        std::cout << "The asset name cannot exceed 1024 bytes" << std::endl;
        return;
    }

    ca_algorithm::Trim(assetName);
    std::cout << "Asset name: " << assetName << std::endl;

    DBReader dataReader;
    auto taskType = global::ca::CrossChainTxType::Null;
    std::string contractAddr;
    std::string crossChainInvestmentContractAddr;

    std::cout << "Is cross-contract to native chain asset transfer executable? (1 means yes, 0 means no)" << std::endl;
    std::string isCross;
    std::cin >> isCross;
    std::regex pattern1("^(0|1)$");
    if(!std::regex_match(isCross, pattern1))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    if(isCross == "1")
    {
        taskType = global::ca::CrossChainTxType::EnteringMore;
        std::cout << "Please enter cross chain contract addr: " << std::endl;
        std::cin >> contractAddr;
        std::cout << "Contract addr: " << contractAddr << std::endl;
        contractAddr = remove0xPrefix(contractAddr);
        std::string deployUtxoInfo;
        auto dbRet = dataReader.getContractDeployUtxoByContractAddr(contractAddr, deployUtxoInfo);
        if(dbRet != DBStatus::DB_SUCCESS || deployUtxoInfo.empty())
        {
            std::cout << "Contract address not found" << std::endl;
            return;
        }
        std::cout << "Deploy utxo: " << deployUtxoInfo << std::endl;
    }

    std::cout << "Is cross-chain investment executable? (1 means yes, 0 means no)" << std::endl;
    std::string isInvest;
    std::cin >> isInvest;
    if(!std::regex_match(isInvest, pattern1))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    if(isInvest == "1")
    {
        taskType = taskType == global::ca::CrossChainTxType::EnteringMore ? global::ca::CrossChainTxType::Both : global::ca::CrossChainTxType::CrossChainInvestment;
        std::cout << "Please enter cross chain investment contract addr: " << std::endl;
        std::cin >> crossChainInvestmentContractAddr;
        crossChainInvestmentContractAddr = remove0xPrefix(crossChainInvestmentContractAddr);
        std::string deployUtxoInfo;
        auto dbRet = dataReader.getContractDeployUtxoByContractAddr(crossChainInvestmentContractAddr, deployUtxoInfo);
        if(dbRet != DBStatus::DB_SUCCESS || deployUtxoInfo.empty())
        {
            std::cout << "Contract address not found" << std::endl;
            return;
        }
        std::cout << "Deploy utxo: " << deployUtxoInfo << std::endl;
    }

    if(taskType == global::ca::CrossChainTxType::Null)
    {
        std::cout << "No cross-chain transactions are included in this proposal" << std::endl;
        return;
    }
    if(contractAddr == crossChainInvestmentContractAddr)
    {
        std::cout << "The cross chain investment contract address cannot be the same as the cross chain transfer contract address" << std::endl;
        return;
    }

    std::cout << "Please enter peer chain token addr: " << std::endl;
    std::string peerChainTokenAddr;
    std::cin >> peerChainTokenAddr;
    const std::regex patternToken(R"(^(0x[0-9a-fA-F]{64}|[0-9a-fA-F]{64})$)");
    if (!std::regex_match(peerChainTokenAddr, patternToken))
    {
        std::cout << "input peerChainTokenAddr error" << std::endl;
        return;
    }
    peerChainTokenAddr = remove0xPrefix(peerChainTokenAddr);

    std::cout << "Please enter exchange rate: (Keep up to 8 decimal places)" << std::endl;
    std::string exchangeRate;
    std::cin >> exchangeRate;
    //小数位最多为8位
    const std::regex pattern(R"(\b\d+(\.\d{1,8})?\b)");
    if (!std::regex_match(exchangeRate, pattern))
    {
        std::cout << "input exchangeRate error " << std::endl;
        return;
    }
    std::cout << "exchange rate: " << exchangeRate << std::endl;
    std::cout.unsetf(std::cout.fixed);

    std::string identifier;
    std::cout << "Please enter the identifier, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, identifier);

    std::string encodeIdentifier = Base64Encode(identifier);
    std::cout << "identifier: " << encodeIdentifier << std::endl;
    if(encodeIdentifier.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    std::string title;
    std::cout << "Please enter the title, no more than 1 kb" << std::endl;
    std::getline(std::cin, title);
    std::string encodeItile = Base64Encode(title);
    std::cout << "title: " << encodeItile << std::endl;
    if(encodeItile.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    std::cout << "Please enter Minimum number of votes" << std::endl;
    std::string strMinVote;
    std::cin >> strMinVote;
    std::regex pattern3("^[1-9]\\d*$"); 
    if(!std::regex_match(strMinVote, pattern3))
    {
        std::cout << "Input Minimum error" << std::endl;
        return;
    }
    uint64_t minVote = std::stoull(strMinVote);

    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;
    if(!std::regex_match(input, pattern1))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }

    std::string txDescriptionData;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txDescriptionData);

    std::string encodedInfo = Base64Encode(txDescriptionData);
    if(encodedInfo.size() > 1024)
    {
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    std::cout << "Please enter proposal duration (hours, Keep one decimal place):" << std::endl;
    std::string duration;
    std::cin >> duration;
    // 正则表达式匹配浮点数的模式，保留一位小数
    const std::regex pattern2(R"(-?\d+(\.\d)?\b)");
    if (!std::regex_match(duration, pattern2))
    {
        std::cout << "input duration error " << std::endl;
        return;
    }
    double time = 0;
    try 
    {
        time = std::stod(duration);
    } 
    catch (const std::invalid_argument& e) 
    {
        std::cout << "input duration error " << std::endl;
        return;
    }
    std::cout << "proposal: " << time << std::endl;

    uint64_t  beginTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    uint64_t  endTime = beginTime + time * 3600 * 1000000;
    
    std::cout << "Begin time:\t" << MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(beginTime) << std::endl;
    std::cout << "End time:\t" << MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(endTime) << std::endl;

    if(endTime - beginTime < global::ca::KVoteCycle)
    {
        std::cout << "Voting cycle is too short" << std::endl;
        return;
    }


    DBReader dbReader;
    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }
    CTransaction outTx;
    TxHelper::vrfAgentType needAgent;
    int propRet = TxHelper::CreateProposalTransaction(fromAddr, top + 1, outTx, needAgent, gasTrade, encodeIdentifier, encodeItile, peerChainTokenAddr, beginTime, endTime, assetName, exchangeRate, contractAddr, crossChainInvestmentContractAddr, taskType, minVote, isFindUtxo, txDescriptionData);
    if (propRet != 0)
    {
        ERRORLOG("CreateProposalTransaction failed, ret={}", propRet);
        return;
    }

    TxMsgReq txMsg;
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(outTx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    auto ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    if(ret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        return;
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    auto msg = std::make_shared<TxMsgReq>(txMsg);

    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(outTx.identity() == defaultAddr)
    {
        ret = handleTransaction(msg,outTx);
    }
    else
    {
        ret = DropShippingTransaction(msg, outTx, outTx.identity());
    }

    if (ret != 0)
    {
        ret -= 100;
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());
}

//创世账号发撤销资产投票菜单  
void revokeProposalRequest()
{
    std::cout << std::endl
              << std::endl;
    std::map<std::string, TxHelper::ProposalInfo> assetMap;
    int ret = ca_algorithm::fetchAvailableAssetType(assetMap);
    if(ret != 0)
    {
        ERRORLOG("GetVoteAssetType error, error num: {}", ret);
        std::cout << "There are no assets available" << std::endl;
        return;
    }

    std::ostringstream oss;
    for(const auto& t: assetMap)
    {
        ret = ca_algorithm::canBeRevoked(t.first);
        if(ret != 0)
        {
            continue;
        }
        
        oss << "hash: 0x" << t.first << "\tProposal type, asset name: " << t.second.Name << "  exchange rate: " << t.second.ExchangeRate << "  ContractAddr: 0x" << t.second.ContractAddr
            << "  begin time: " << MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(t.second.BeginTime) 
            << "  end time: "  << MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(t.second.EndTime) << std::endl;
    }
    std::cout << oss.str();

    if(oss.str().empty())
    {
        std::cout << "There are no assets available" << std::endl;
        return;
    }

    Account account;
    MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(account);
    std::string strFromAddr = account.GetAddr();
    std::string fromAddr = remove0xPrefix(strFromAddr);
    std::cout << "\nRevoke proposal addr: " << "0x"+strFromAddr << std::endl;
    if(fromAddr != GetInitAccountAddr())
    {
        std::cout << "The default account is not the genesis account" << std::endl;
        return;
    }

    std::pair<std::string,std::string> gasTrade = {};
    std::string source_gas_address = GetInitAccountAddr();
    gasTrade.first = remove0xPrefix(source_gas_address);
    // 原RevokeProposal Gas默认使用Vote，现改为OHI
    gasTrade.second = global::ca::ASSET_TYPE_OHI;

    std::cout << "Input revoke proposal hash: " << std::endl;
    std::string hash;
    std::cin >> hash;
    hash = remove0xPrefix(hash);
    auto find = assetMap.find(hash);
    if(find == assetMap.end())
    {
        std::cout << "input revoke proposal hash error " << std::endl;
        return;
    }

    std::cout << "Please enter Minimum number of votes" << std::endl;
    std::string strMinVote;
    std::cin >> strMinVote;
    std::regex pattern3("^[1-9]\\d*$"); 
    if(!std::regex_match(strMinVote, pattern3))
    {
        std::cout << "Input Minimum error" << std::endl;
        return;
    }
    uint64_t minVote = std::stoull(strMinVote);

    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;
    std::regex pattern1("^(0|1)$");
    if(!std::regex_match(input, pattern1))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }

    std::string txDescriptionData;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txDescriptionData);

    std::string encodedInfo = Base64Encode(txDescriptionData);
    if(encodedInfo.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    std::cout << "Please enter proposal duration (hours, Keep one decimal place):" << std::endl;
    std::string duration;
    std::cin >> duration;
    // 正则表达式匹配浮点数的模式，保留一位小数
    const std::regex pattern2("^[-+]?[0-9]*\\.?[0-9]?[0-9]?$");
    if (!std::regex_match(duration, pattern2))
    {
        std::cout << "input duration error " << std::endl;
        return;
    }
    double time = 0;
    try 
    {
        time = std::stod(duration);
    } 
    catch (const std::invalid_argument& e) 
    {
        std::cout << "input duration error " << std::endl;
        return;
    }
    std::cout << "proposal: " << time << std::endl;

    uint64_t  beginTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    uint64_t  endTime = beginTime + time * 3600 * 1000000;
    std::cout << "Begin time:\t" << MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(beginTime) << std::endl;
    std::cout << "End time:\t" << MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(endTime) << std::endl;

    if(endTime - beginTime < global::ca::KVoteCycle)
    {
        std::cout << "Voting cycle is too short" << std::endl;
        return;
    }

    DBReader dbReader;
    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }
    CTransaction outTx;
    TxHelper::vrfAgentType needAgent;
    if (TxHelper::CreateRevokeProposalTransaction(fromAddr, top + 1, outTx, needAgent, gasTrade, beginTime, endTime, hash, minVote, isFindUtxo, encodedInfo) != 0)
    {
        return;
    }

    TxMsgReq txMsg;
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(outTx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    if(ret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        return;
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    auto msg = std::make_shared<TxMsgReq>(txMsg);

    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(outTx.identity() == defaultAddr)
    {
        ret = handleTransaction(msg,outTx);
    }
    else
    {
        ret = DropShippingTransaction(msg, outTx, outTx.identity());
    }
    if (ret != 0)
    {
        ret -= 100;
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash()); 
}


//投票菜单                    
void HandleVote()
{
    std::cout << std::endl
              << std::endl;
    std::map<std::string, TxHelper::VoteInfo> voteAsset;
    int ret = ca_algorithm::GetVoteAssetType(voteAsset);
    if(ret != 0)
    {
        ERRORLOG("GetVoteAssetType error, error num: {}", ret);
        std::cout << "There are currently no types to vote on" << std::endl;
        return;
    }
    if(voteAsset.empty())
    {
        std::cout << "There are currently no types to vote on" << std::endl;
        return;
    }

    for(const auto& t : voteAsset)
    {
        std::stringstream oss;
        if(t.second.TxType == (uint32_t)global::ca::TxType::PROPOSAL)
        {
            oss << "Proposal type, vote hash: 0x" << t.first;
        }
        else
        {
            oss << "Revoke proposal type, vote hash: 0x" << t.first << "  proposal hash: " << t.second.ProposalHash;
        }
        oss << "  asset name: " << t.second.AssetName << "  exchange rate: " << t.second.ExchangeRate << "  ContractAddr: " << t.second.ContractAddr
            << "  begin time: " << t.second.BeginTime << " end time: " << t.second.EndTime << "  min vote num: " << t.second.MIN_VOTE_NUM;

        std::cout << oss.str() << std::endl;
    }

    Account account;
    MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(account);
    std::string strFromAddr = account.GetAddr();
    std::string fromAddr = remove0xPrefix(strFromAddr);
    std::cout << "Vote addr: " << "0x"+ strFromAddr << std::endl;

    std::cout << "Input vote hash: " << std::endl;
    std::string voteHash;
    std::cin >> voteHash;
    voteHash = remove0xPrefix(voteHash);
    auto find = voteAsset.find(voteHash);
    if(find == voteAsset.end())
    {
        std::cout << "input vote hash error " << std::endl;
        return;
    }
    global::ca::TxType voteTxType = (global::ca::TxType)find->second.TxType;

    std::cout << "input vote type   ( Against  0, Approve  1 ): " << std::endl;
    std::string voteType;
    std::cin >> voteType;
    const std::regex pattern("^[01]$");
    if (!std::regex_match(voteType, pattern))
    {
        std::cout << "input vote type error " << std::endl;
        return;
    }
    int pollType = std::stoi(voteType);

    std::pair<std::string,std::string> gasTrade = {};

    std::string source_gas_address;
    std::cout << "Please enter the fromaddr to pay the gas:" << std::endl;
    std::cin >> source_gas_address;
    
    gasTrade.first = remove0xPrefix(source_gas_address);
    // 原Vote交易Gas默认使用Vote，现改为OHI
    gasTrade.second = global::ca::ASSET_TYPE_OHI;

    std::string input;
    std::cout << "Whether to look for network-wide utxo status (1 means yes, 0 means no)" << std::endl;
    std::cin >> input;

    bool isFindUtxo = false;
    std::regex _pattern("^(0|1)$");
    if(!std::regex_match(input, _pattern))
    {
        std::cout << "Error in parameter input" << std::endl;
        return;
    }
    else
    {
        isFindUtxo = input == "1" ? true : false;
    }

    std::string txDescriptionData;
    std::cout << "Enter a description of the transaction, no more than 1 kb" << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, txDescriptionData);

    std::string encodedInfo = Base64Encode(txDescriptionData);
    if(encodedInfo.size() > 1024){
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    DBReader dbReader;
    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }



   VoteTrans::VoteTransParam param;

    param.vote_hash = voteHash;
    param.addr = fromAddr;
    param.is_find_utxo = isFindUtxo;
    param.gas = {gasTrade.first, gasTrade.second};
    param.is_gas_tray = true;
    param.vote_type = pollType;
    param.tx_type = voteTxType;
    param.encoded_info = encodedInfo;

    VoteTrans votet(param);

    auto vret = votet.trans();
    if (!vret.isOk())
    {
        ERRORLOG("VoteTrans error {}", vret.error_message(true));
        std::cerr << vret.error_message() << std::endl;
        return ;
    };

    auto siret=votet.signTx("");

    if(!siret.isOk()){
        ERRORLOG("sign VoteTrans tx error {}", siret.error_message(true));
        std::cerr << siret.error_message() << std::endl;
        return ;
    }

    votet.print_debug_tx();

    auto msgret=votet.goMessage();

    if(!msgret.isOk()){
        ERRORLOG("goMessage VoteTrans tx error {}", msgret.error_message(true));
        std::cerr << msgret.error_message() << std::endl;
        return ;
    }


    // CTransaction outTx;
    // TxHelper::vrfAgentType needAgent;
    // int vret=TxHelper::CreateVoteTransaction(fromAddr, top + 1, outTx, needAgent, gasTrade, voteHash, pollType, voteTxType, isFindUtxo, encodedInfo);
    // if ( vret!= 0)
    // {
    //     ERRORLOG("CreateVoteTransaction error {}",  vret);
    //     return;
    // }

    // votet.print_debug_tx(&outTx);

    // TxMsgReq txMsg;
    // txMsg.set_version(ohi::GetVersion());
    // TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    // txMsgInfo->set_type(0);
    // txMsgInfo->set_tx(outTx.SerializeAsString());
    // txMsgInfo->set_nodeheight(top);

    // uint64_t txUtxoLocalHeight;
    // ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    // if(ret != 0)
    // {
    //     ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
    //     return;
    // }

    // txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    // auto msg = std::make_shared<TxMsgReq>(txMsg);

    // std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    // if(outTx.identity() == defaultAddr)
    // {
    //     ret = handleTransaction(msg,outTx);
    // }
    // else
    // {
    //     ret = DropShippingTransaction(msg, outTx, outTx.identity());
    // }

    // if (ret != 0)
    // {
    //     ret -= 100;
    // }

    // DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash()); 
}


int transactionDiscoveryHeight(uint64_t &top)
{
    if(!BlockHelper::getChainHeight(top)){
        ERRORLOG("getChainHeight get top failed!!")
        return -1;
    }
    
    DEBUGLOG("current top: {}", top);
    DBReader dbReader;
    uint64_t nodeSelfHeight = 0;
    auto status = dbReader.getBlockTop(nodeSelfHeight);
    if (DBStatus::DB_SUCCESS != status)
    {
        DEBUGLOG("getBlockTop fail!!!");
        return -2;
    }
    
    if(nodeSelfHeight >= top){
        return 0;
    }

    std::vector<std::string> pledgeAddr;

    std::vector<Node> nodelist = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    for (const auto &node : nodelist)
    {
        bool canReward= VerifyBonusAddr(node.address);

        //int64_t stakeTime = ca_algorithm::GetPledgeTimeByAddr(node.address, global::ca::StakeType::STAKE_TYPE_NODE);
        if (canReward)
        {
            pledgeAddr.push_back(node.address);
        }
    }
    
    uint64_t endSyncHeight_ = nodeSelfHeight -3;
    std::string msgId;
    if (!dataMgrPtr.CreateWait(90, pledgeAddr.size() * 0.8, msgId))
    {
        return -3;
    }
    for (auto &nodeId : pledgeAddr)
    {
        if(!dataMgrPtr.AddResNode(msgId, nodeId))
        {
            ERRORLOG("transactionDiscoveryHeight AddResNode error");
            return -4;
        }
        DEBUGLOG("Find the transaction height to {}", nodeId);
        sendSyncGetHeightHashRequest(nodeId, msgId, nodeSelfHeight, endSyncHeight_);
    }
    std::vector<std::string> retDatas;
    if (!dataMgrPtr.WaitData(msgId, retDatas))
    {
        if(retDatas.size() < pledgeAddr.size() * 0.5)
        {
            ERRORLOG("wait sync block hash time out send:{} recv:{}", pledgeAddr.size(), retDatas.size());
            return -5;
        }
    }

    uint64_t successCounter = 0;
    SyncGetHeightHashAck ack;
    std::map<std::string, std::set<std::string>> syncBlockHashList;
    for (auto &retData : retDatas)
    {
        ack.Clear();
        if (!ack.ParseFromString(retData))
        {
            continue;
        }
        if(ack.code() != 0)
        {
            continue;
        }
        successCounter++;
        for (auto &key : ack.block_hashes())
        {
            auto it = syncBlockHashList.find(key);
            if (syncBlockHashList.end() == it)
            {
                syncBlockHashList.insert(std::make_pair(key, std::set<std::string>()));
            }
            auto &value = syncBlockHashList.at(key);
            value.insert(ack.self_node_id());
        }
    }
    
    if(successCounter < (size_t)(retDatas.size() * global::ca::kByzantineFaultToleranceThreshold))
    {
        ERRORLOG("ret data error successCounter:{}, (uint32_t)(retDatas * global::ca::kByzantineFaultToleranceThreshold):{}, retDatas.size():{}", successCounter, (size_t)(retDatas.size() * global::ca::kByzantineFaultToleranceThreshold), retDatas.size());
        return -6;
    }
    
    size_t verifyNum = successCounter * global::ca::kHighConfidenceThreshold;
    std::vector<std::string> hashes;
    std::string strblock;
    CBlock block;
    uint64_t highestHeight = 0;
    for (auto &syncBlockHash : syncBlockHashList)
    {
        strblock.clear();
        auto res = dbReader.getBlockByBlockHash(syncBlockHash.first, strblock);
        if(DBStatus::DB_NOT_FOUND != res)
        {
            continue;
        }
        if (syncBlockHash.second.size() < verifyNum)
        {
            continue;
        }
        
        hashes.push_back(syncBlockHash.first);

        if(!block.ParseFromString(strblock)){
            return -7;
        }
        highestHeight = highestHeight > block.height() ? highestHeight :  block.height();
    }
    top = highestHeight;
    DEBUGLOG("transactionDiscoveryHeight top : {}", top);
    return 0;
}

void DeletePrivateKey()
{
    // 首先显示当前所有账户列表
    std::cout << "Current accounts:" << std::endl;
    MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();
    std::cout << std::endl;

    // 询问是否删除多个账户
    std::cout << "Do you want to delete multiple accounts? (y/n): " << std::endl;
    std::string multipleChoice;
    std::cin >> multipleChoice;
    bool deleteMultiple = (multipleChoice == "y" || multipleChoice == "Y");

    if (deleteMultiple) {
        // 删除多个账户的逻辑
        std::cout << "Enter addresses to delete (comma separated, e.g., addr1,addr2): " << std::endl;
        std::string addressInput;
        std::cin >> addressInput;
        
        // 分割地址字符串
        std::vector<std::string> addresses;
        std::stringstream ss(addressInput);
        std::string addr;
        while (std::getline(ss, addr, ',')) {
            // 移除可能的"0x"前缀
            if (addr.substr(0, 2) == "0x") {
                addr = addr.substr(2);
            }
            addresses.push_back(addr);
        }
        
        if (addresses.empty()) {
            std::cout << "No valid addresses entered." << std::endl;
            return;
        }

        // 确认删除
        std::cout << "Are you sure you want to delete these " << addresses.size() << " account(s)? (Y/N): ";
        std::string confirm;
        std::cin >> confirm;
        
        if (confirm != "Y" && confirm != "y") {
            std::cout << "Operation cancelled." << std::endl;
            return;
        }

        // 执行删除
        int successCount = 0;
        for (const auto& address : addresses) {
            if (!isValidAddress(address)) {
                std::cout << "Address format error: " << address << std::endl;
                continue;
            }
            
            if (!MagicSingleton<AccountManager>::GetInstance()->IsExist(address)) {
                std::cout << "Account not found: " << address << std::endl;
                continue;
            }
            
            // 检查是否为默认账户
            Account defaultAccount;
            MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(defaultAccount);
            if (address == defaultAccount.GetAddr()) {
                std::cout << "Cannot delete default account: " << address << std::endl;
                std::cout << "Please set another account as default first." << std::endl;
                continue;
            }
            
            // 删除账户
            int deleteResult = MagicSingleton<AccountManager>::GetInstance()->DeleteAccount(address);
            if (deleteResult != 0 && deleteResult != 1) {
                std::cout << "Failed to delete account: " << address << std::endl;
                
                // 区分不同的错误类型
                if (deleteResult == -1) {
                    std::cout << "Error: Cannot delete default account." << std::endl;
                } else if (deleteResult == -2) {
                    std::cout << "Error: Account not found." << std::endl;
                } else if (deleteResult == -3) {
                    std::cout << "Error: Failed to remove account from list." << std::endl;
                } else if (deleteResult == -4) {
                    std::cout << "Error: Failed to delete keystore file." << std::endl;
                } else {
                    std::cout << "Error: Unknown error (code: " << deleteResult << ")" << std::endl;
                }
                continue;
            }
            
            // 处理keystore文件删除
            std::string keystoreFile = GetGlobalFileManager().GetKeystoreFilePath(address);
            if (deleteResult == 1) {
                // 账户成功删除但keystore文件已不存在
                std::cout << "Account deleted but keystore file was not found: 0x" << address << std::endl;
                successCount++;
            } else {
                std::cout << "Account and keystore deleted successfully: 0x" << address << std::endl;
                successCount++;
            }
        }
        
        std::cout << std::endl << "Successfully deleted " << successCount << " out of " << addresses.size() << " accounts." << std::endl;
    } else {
        // 删除单个账户的逻辑
        std::string addr;
        std::cout << "Please enter the address you want to remove: " << std::endl;
        std::cin >> addr;
        
        // 移除可能的"0x"前缀
        if (addr.substr(0, 2) == "0x") {
            addr = addr.substr(2); 
        }
        
        // 验证地址格式
        if (!isValidAddress(addr)) {
            std::cout << "The address format is invalid." << std::endl;
            return;
        }
        
        // 检查账户是否存在
        if (!MagicSingleton<AccountManager>::GetInstance()->IsExist(addr)) {
            std::cout << "Account not found!" << std::endl;
            return;
        }
        
        // 检查是否为默认账户
        Account defaultAccount;
        MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(defaultAccount);
        if (addr == defaultAccount.GetAddr()) {
            std::cout << "This is your default account. Are you sure to delete it? (Y/N): ";
            std::string defaultConfirm;
            std::cin >> defaultConfirm;
            
            if (defaultConfirm != "Y" && defaultConfirm != "y") {
                std::cout << "Operation cancelled." << std::endl;
                return;
            }
            
            std::cout << "WARNING: Deleting your default account may affect system operation!" << std::endl;
            std::cout << "Please consider setting another account as default first." << std::endl;
        }
        
        // 最终确认
        std::cout << "Are you sure you want to delete account 0x" << addr << "? (Y/N): ";
        std::string confirm;
        std::cin >> confirm;
        
        if (confirm != "Y" && confirm != "y") {
            std::cout << "Operation cancelled." << std::endl;
            return;
        }
        
        // 执行删除
        int deleteResult = MagicSingleton<AccountManager>::GetInstance()->DeleteAccount(addr);
        if (deleteResult != 0 && deleteResult != 1) {
            std::cout << "Failed to delete account!" << std::endl;
            
            // 区分不同的错误类型
            if (deleteResult == -1) {
                std::cout << "Error: Cannot delete default account." << std::endl;
                std::cout << "Please set another account as default first." << std::endl;
            } else if (deleteResult == -2) {
                std::cout << "Error: Account not found." << std::endl;
            } else if (deleteResult == -3) {
                std::cout << "Error: Failed to remove account from list." << std::endl;
            } else if (deleteResult == -4) {
                std::cout << "Error: Failed to delete keystore file." << std::endl;
            } else {
                std::cout << "Error: Unknown error (code: " << deleteResult << ")" << std::endl;
            }
            return;
        }
        
        // 处理成功情况
        if (deleteResult == 1) {
            // 账户成功删除但keystore文件已不存在
            std::cout << "Account deleted but keystore file was not found: 0x" << addr << std::endl;
        } else {
            std::cout << "Account and keystore deleted successfully: 0x" << addr << std::endl;
        }
    }
}

void GenKey()
{
    // 创建文件夹
    GetGlobalFileManager().EnsureDirectoryExists(path_constants::KEYSTORE_PATH);

    std::cout << "Please enter the number of accounts to be generated: " << std::endl;
    int num = 0;
    std::cin >> num;
    if (num <= 0)
    {
        return;
    }

    bool use_different_passwords = false;
    std::string commonPassword;
    bool useMultiThreading = false;
    const int THREAD_THRESHOLD = 10; // 超过10个账户时考虑多线程
    const int MAX_THREADS = 8;      // 最大线程数

    // 只有当要生成多个账户时才询问是否使用相同密码
    if (num > 1) {
        std::cout << "Use the same password for all accounts? (1/0): " << std::endl;
        std::string choice;
        std::cin >> choice;
        // 输入1=使用相同密码, 输入0=使用不同密码
        use_different_passwords = (choice != "1");
        
        // 如果使用相同密码并且账户数量足够多，询问是否使用多线程
        if (!use_different_passwords && num >= THREAD_THRESHOLD) {
            std::cout << "Use multi-threading to speed up account generation? (1/0): " << std::endl;
            std::cin >> choice;
            useMultiThreading = (choice == "1");
        }
    }
    
    // 如果使用相同密码或只生成一个账户，先获取一次密码
    if (!use_different_passwords) {
        std::cout << "Please set a password to encrypt your private keys" << std::endl;
        commonPassword = GetPasswordFromUser(true, "Enter password: ");
        if (commonPassword.empty()) {
            std::cout << "Password cannot be empty." << std::endl;
            return;
        }
    }
    
    if (useMultiThreading && !use_different_passwords && num > 1) {
        // 多线程模式
        std::cout << "Generating " << num << " accounts using multi-threading..." << std::endl;
        
        // 创建线程安全的进度计数器和结果存储
        std::atomic<int> progress(0);
        std::mutex resultMutex;
        std::vector<std::pair<std::string, std::string>> results; // 存储地址和错误信息的对
        results.resize(num);
        
        // 计算线程数
        int numThreads = std::min(MAX_THREADS, num);
        int accountsPerThread_ = num / numThreads;
        int remainingAccounts = num % numThreads;
        
        // 创建线程池
        std::vector<std::thread> threads;
        
        // 线程函数
        auto generateAccounts = [&](int startIdx, int count) {
            for (int i = 0; i < count; i++) {
                int idx = startIdx + i;
                if (idx >= num) break;
                
                // 创建账户
                Account acc(true);
                std::string address = acc.GetAddr();
                
                // 将账户信息保存到结果向量
                std::string errorMsg;
                
                try {
                    // 加密私钥并保存
                    KeystoreManager keystoreMgr;
                    std::string keystoreJson;
                    
                    if (keystoreMgr.EncryptPrivateKey(acc.GetPriStr(), address, commonPassword, keystoreJson) != 0) {
                        errorMsg = "Failed to encrypt private key";
                    } else {
                        // 保存到keystore文件
                        std::string keystoreFile = GetGlobalFileManager().GetKeystoreFilePath(address);
                        std::ofstream outFile(keystoreFile);
                        if (!outFile.is_open()) {
                            errorMsg = "Failed to create keystore file";
                        } else {
                            outFile << keystoreJson;
                            outFile.close();
                            
                            // 将账户添加到账户管理器
                            {
                                std::lock_guard<std::mutex> lock(resultMutex);
                                MagicSingleton<AccountManager>::GetInstance()->AddAccount(acc);
                            }
                        }
                    }
                } catch (const std::exception& e) {
                    errorMsg = std::string("Exception: ") + e.what();
                }
                
                // 存储结果
                {
                    std::lock_guard<std::mutex> lock(resultMutex);
                    results[idx] = std::make_pair(address, errorMsg);
                }
                
                // 更新进度
                int current = ++progress;
                {
                    std::lock_guard<std::mutex> lock(resultMutex);
                    DisplayProgressBar(current, num, 50);
                }
            }
        };
        
        // 启动线程
        int startIdx = 0;
        for (int i = 0; i < numThreads; i++) {
            int count = accountsPerThread_ + (i < remainingAccounts ? 1 : 0);
            threads.emplace_back(generateAccounts, startIdx, count);
            startIdx += count;
        }
        
        // 等待所有线程完成
        for (auto& t : threads) {
            if (t.joinable()) {
                t.join();
            }
        }
        
        std::cout << std::endl; // 换行，进度条结束
        
        // 显示生成结果
        int successCount = 0;
        for (int i = 0; i < num; i++) {
            const auto& result = results[i];
            if (result.second.empty()) {
                std::cout << "Generated and encrypted account " << (i+1) << ": 0x" << result.first << std::endl;
                successCount++;
            } else {
                std::cout << "Failed to generate account " << (i+1) << ": " << result.second << std::endl;
            }
        }
        
        std::cout << "\nAccount generation summary:" << std::endl;
        std::cout << "- Total accounts: " << num << std::endl;
        std::cout << "- Successfully generated: " << successCount << std::endl;
        std::cout << "- Failed: " << (num - successCount) << std::endl;
    } else {
        // 单线程模式
        for (int i = 0; i != num; ++i)
        {
            Account acc(true);
            MagicSingleton<AccountManager>::GetInstance()->AddAccount(acc);
            
            // 将私钥保存到keystore文件
            std::string address = acc.GetAddr();
            KeystoreManager keystoreMgr;
            std::string keystoreJson;
            
            // 如果为每个账户使用不同密码，则获取当前账户的密码
            std::string password = commonPassword;
            if (use_different_passwords) {
                std::cout << "Please set a password for account " << i+1 << " (0x" << address << ")" << std::endl;
                password = GetPasswordFromUser(true, "Enter password: ");
                if (password.empty()) {
                    std::cout << "Password cannot be empty. Skipping this account." << std::endl;
                    MagicSingleton<AccountManager>::GetInstance()->DeleteAccount(address);
                    continue;
                }
            }
            
            if (keystoreMgr.EncryptPrivateKey(acc.GetPriStr(), address, password, keystoreJson) != 0) {
                std::cout << "Failed to encrypt private key for account " << i+1 << "!" << std::endl;
                // 导入失败，删除已添加的账户
                MagicSingleton<AccountManager>::GetInstance()->DeleteAccount(address);
                continue;
            }
            
            // 保存到keystore文件
            std::string keystoreFile = GetGlobalFileManager().GetKeystoreFilePath(address);
            std::ofstream outFile(keystoreFile);
            if (!outFile.is_open()) {
                std::cout << "Failed to create keystore file for account " << i+1 << "!" << std::endl;
                MagicSingleton<AccountManager>::GetInstance()->DeleteAccount(address);
                continue;
            }
            
            outFile << keystoreJson;
            outFile.close();
            
            std::cout << "Generated and encrypted account " << i+1 << ": 0x" << address << std::endl;
        }
    }
}
#include "utils/keystore.h"
#include "utils/hex_code.h"
