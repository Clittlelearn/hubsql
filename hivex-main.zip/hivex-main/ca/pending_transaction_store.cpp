#include "ca/pending_transaction_store.h"

#include "ca/pending_transaction_reservations.h"
#include "ca/block_helper.h"
#include "db/db_api.h"
#include "include/logging.h"
#include "net/peer_node.h"
#include "utils/magic_singleton.h"
#include <algorithm>
#include <chrono>
#include <nlohmann/json.hpp>

namespace pending_tx
{
namespace {
uint64_t NowMicros()
{
    return std::chrono::duration_cast<std::chrono::microseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
}
constexpr uint64_t kReservationTtlMicros = 30ULL * 60 * 1000 * 1000;
constexpr uint64_t kConsensusExpiryGraceMicros = 30ULL * 1000 * 1000;

bool AllReservedInputsRemainUnspent(const nlohmann::json& record)
{
    try
    {
        const std::string address = record.at("address").get<std::string>();
        for (const auto& key : record.at("utxos").get<std::vector<std::string>>())
        {
            const auto index_separator = key.rfind('_');
            if (index_separator == std::string::npos) return false;
            const auto hash_separator = key.rfind('_', index_separator - 1);
            if (hash_separator == std::string::npos) return false;
            const std::string asset = key.substr(0, hash_separator);
            const std::string hash = key.substr(hash_separator + 1, index_separator - hash_separator - 1);
            std::string value;
            if (asset.empty() || hash.empty() ||
                DBReader().getUtxoValueByUtxoHashes(hash, address, asset, value) != DBStatus::DB_SUCCESS)
                return false;
        }
    }
    catch (...) { return false; }
    return true;
}
}
bool Store::Persist(const std::string& id, const std::string& address, uint64_t nonce,
                    const std::vector<std::string>& utxos, const std::string& commitment,
                    uint64_t consensus_deadline)
{
    std::unique_lock<std::mutex> lock(mutex_);
    DBReadWriter db("pending_tx_persist");
    std::string raw;
    nlohmann::json records = nlohmann::json::object();
    const auto status = db.getPendingTransactionReservations(raw);
    if (status == DBStatus::DB_SUCCESS) records = nlohmann::json::parse(raw, nullptr, false);
    else if (status != DBStatus::DB_NOT_FOUND) return false;
    if (!records.is_object()) return false;
    records[id] = nlohmann::json{{"id", id}, {"address", address}, {"nonce", nonce}, {"utxos", utxos},
                                 {"expires_at", NowMicros() + kReservationTtlMicros}};
    records[id]["commitment"] = commitment;
    records[id]["consensus_deadline"] = consensus_deadline;
    return db.setPendingTransactionReservations(records.dump()) == DBStatus::DB_SUCCESS &&
           db.transactionCommit() == DBStatus::DB_SUCCESS;
}

bool Store::Remove(const std::string& id)
{
    std::lock_guard<std::mutex> lock(mutex_);
    DBReadWriter db("pending_tx_remove");
    std::string raw;
    if (db.getPendingTransactionReservations(raw) == DBStatus::DB_NOT_FOUND) return true;
    auto records = nlohmann::json::parse(raw, nullptr, false);
    if (!records.is_object()) return false;
    records.erase(id);
    return db.setPendingTransactionReservations(records.dump()) == DBStatus::DB_SUCCESS &&
           db.transactionCommit() == DBStatus::DB_SUCCESS;
}

bool Store::Replace(const std::string& old_id, const std::string& id, const std::string& address,
                    uint64_t nonce, const std::vector<std::string>& utxos, const std::string& commitment,
                    uint64_t consensus_deadline)
{
    std::lock_guard<std::mutex> lock(mutex_);
    DBReadWriter db("pending_tx_replace");
    std::string raw;
    nlohmann::json records = nlohmann::json::object();
    const auto status = db.getPendingTransactionReservations(raw);
    if (status == DBStatus::DB_SUCCESS) records = nlohmann::json::parse(raw, nullptr, false);
    else if (status != DBStatus::DB_NOT_FOUND) return false;
    if (!records.is_object()) return false;
    if (!old_id.empty()) records.erase(old_id);
    records[id] = nlohmann::json{{"id", id}, {"address", address}, {"nonce", nonce}, {"utxos", utxos},
                                 {"expires_at", NowMicros() + kReservationTtlMicros}};
    records[id]["commitment"] = commitment;
    records[id]["consensus_deadline"] = consensus_deadline;
    return db.setPendingTransactionReservations(records.dump()) == DBStatus::DB_SUCCESS &&
           db.transactionCommit() == DBStatus::DB_SUCCESS;
}

bool Store::Restore(Reservations& reservations)
{
    std::lock_guard<std::mutex> lock(mutex_);
    DBReader db;
    std::string raw;
    const auto status = db.getPendingTransactionReservations(raw);
    if (status == DBStatus::DB_NOT_FOUND) return true;
    if (status != DBStatus::DB_SUCCESS) return false;
    const auto records = nlohmann::json::parse(raw, nullptr, false);
    if (!records.is_object()) return false;
    try {
        for (const auto& item : records.items()) {
            const auto& record = item.value();
            if (item.key().rfind("draft_", 0) == 0 && record.value("expires_at", 0ULL) <= NowMicros()) continue;
            if (reservations.ReserveExact(record.at("id"), record.at("address"), record.at("nonce"),
                                          record.at("utxos").get<std::vector<std::string>>(),
                                          record.value("commitment", std::string{})) != ReserveResult::kOk) return false;
        }
    } catch (...) { return false; }
    return true;
}

bool Store::PruneExpired(Reservations& reservations)
{
    std::unique_lock<std::mutex> lock(mutex_);
    const uint64_t now = NowMicros();
    DBReadWriter db("pending_tx_prune");
    std::string raw;
    const auto status = db.getPendingTransactionReservations(raw);
    if (status == DBStatus::DB_NOT_FOUND) return true;
    if (status != DBStatus::DB_SUCCESS) return false;
    auto records = nlohmann::json::parse(raw, nullptr, false);
    if (!records.is_object()) return false;
    std::vector<std::string> expired;
    bool has_formal_expired = false;
    for (const auto& item : records.items())
        if (item.key().rfind("draft_", 0) == 0 &&
            item.value().value("expires_at", 0ULL) <= now) expired.push_back(item.key());
        else if (item.key().rfind("draft_", 0) != 0)
        {
            const uint64_t deadline = item.value().value("consensus_deadline", 0ULL);
            if (deadline != 0 && deadline <= now &&
                now - deadline >= kConsensusExpiryGraceMicros) has_formal_expired = true;
        }
    if (has_formal_expired &&
        !MagicSingleton<PeerNode>::GetInstance()->GetNodelist().empty())
    {
        uint64_t local_top = 0;
        uint64_t network_top = 0;
        const bool local_height_available =
            DBReader().getBlockTop(local_top) == DBStatus::DB_SUCCESS;
        const bool network_height_available = BlockHelper::getChainHeight(network_top);
        if (local_height_available && network_height_available && local_top >= network_top)
        {
            for (const auto& item : records.items())
            {
                if (item.key().rfind("draft_", 0) == 0) continue;
                const uint64_t deadline = item.value().value("consensus_deadline", 0ULL);
                if (deadline == 0 || deadline > now ||
                    now - deadline < kConsensusExpiryGraceMicros) continue;
                std::string tx_raw;
                const auto tx_status = DBReader().getTransactionByHash(item.key(), tx_raw);
                if (tx_status == DBStatus::DB_SUCCESS ||
                    (tx_status == DBStatus::DB_NOT_FOUND && AllReservedInputsRemainUnspent(item.value())))
                    expired.push_back(item.key());
            }
        }
        else if (last_prune_blocked_log_micros_ == 0 ||
                 now - last_prune_blocked_log_micros_ >= 30ULL * 1000 * 1000)
        {
            WARNLOG("PENDING_PRUNE_WAIT reason:chain_not_caught_up, local_height_available:{}, "
                    "network_height_available:{}, local_top:{}, network_top:{}",
                    local_height_available, network_height_available, local_top, network_top);
            last_prune_blocked_log_micros_ = now;
        }
    }
    if (expired.empty()) return true;
    for (const auto& id : expired) records.erase(id);
    const bool committed = db.setPendingTransactionReservations(records.dump()) == DBStatus::DB_SUCCESS &&
                           db.transactionCommit() == DBStatus::DB_SUCCESS;
    lock.unlock();
    if (!committed) return false;
    for (const auto& id : expired) reservations.Release(id);
    return true;
}
} // namespace pending_tx
