#include "ca/contract_nonce_policy.h"

#include <algorithm>
#include <limits>
#include <set>

namespace contract_nonce
{
ValidationResult ValidateCanonicalSequence(
    std::vector<Entry> entries,
    const std::map<std::string, uint64_t>& committed_nonces,
    std::map<std::string, uint64_t>* expected_nonces)
{
    std::sort(entries.begin(), entries.end(), [](const Entry& lhs, const Entry& rhs) {
        if (lhs.time != rhs.time)
        {
            return lhs.time < rhs.time;
        }
        return lhs.tx_hash < rhs.tx_hash;
    });

    std::set<std::string> tx_hashes;
    std::map<std::string, uint64_t> next_nonce = committed_nonces;
    for (const auto& entry : entries)
    {
        if (!tx_hashes.insert(entry.tx_hash).second)
        {
            return ValidationResult::kDuplicateTransaction;
        }
        const uint64_t expected = next_nonce[entry.address];
        if (entry.nonce != expected)
        {
            return ValidationResult::kNonceMismatch;
        }
        if (expected_nonces != nullptr)
        {
            (*expected_nonces)[entry.tx_hash] = expected;
        }
        ++next_nonce[entry.address];
    }
    return ValidationResult::kOk;
}

BatchReadiness ClassifyCanonicalBatch(
    std::vector<Entry> entries,
    const std::map<std::string, uint64_t>& committed_nonces,
    uint64_t max_nonce_gap,
    std::map<std::string, uint64_t>* missing_nonces)
{
    if (missing_nonces != nullptr) missing_nonces->clear();
    std::sort(entries.begin(), entries.end(), [](const Entry& lhs, const Entry& rhs) {
        if (lhs.time != rhs.time) return lhs.time < rhs.time;
        return lhs.tx_hash < rhs.tx_hash;
    });

    std::set<std::string> hashes;
    std::map<std::string, uint64_t> previous;
    std::map<std::string, uint64_t> first;
    for (const auto& entry : entries)
    {
        if (entry.tx_hash.empty() || entry.address.empty() || !hashes.insert(entry.tx_hash).second)
            return BatchReadiness::kInvalidSequence;
        const auto prior = previous.find(entry.address);
        if (prior == previous.end()) first.emplace(entry.address, entry.nonce);
        else
        {
            if (prior->second == std::numeric_limits<uint64_t>::max() || entry.nonce != prior->second + 1)
                return BatchReadiness::kInvalidSequence;
        }
        previous[entry.address] = entry.nonce;
    }

    bool waiting = false;
    for (const auto& [address, first_nonce] : first)
    {
        const auto committed = committed_nonces.find(address);
        const uint64_t chain_nonce = committed == committed_nonces.end() ? 0 : committed->second;
        if (first_nonce < chain_nonce) return BatchReadiness::kNonceConflict;
        if (first_nonce > chain_nonce)
        {
            if (first_nonce - chain_nonce > max_nonce_gap) return BatchReadiness::kGapLimitExceeded;
            waiting = true;
            if (missing_nonces != nullptr) (*missing_nonces)[address] = chain_nonce;
        }
    }
    return waiting ? BatchReadiness::kWaitingNonce : BatchReadiness::kReady;
}

bool SharesAccount(const std::vector<std::string>& accounts,
                   const std::set<std::string>& blocked_accounts)
{
    return std::any_of(accounts.begin(), accounts.end(), [&blocked_accounts](const std::string& address) {
        return blocked_accounts.count(address) != 0;
    });
}
} // namespace contract_nonce
