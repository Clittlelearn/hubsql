/**
 * *****************************************************************************
 * @file        block_rate_probe.h
 * @brief       区块上链率探测模块
 *               用于统计新区块在全网质押节点中的传播情况
 * @author
 * @date        2026-06-06
 * @copyright   mm
 * *****************************************************************************
 */

#ifndef CA_BLOCK_RATE_PROBE_HEADER
#define CA_BLOCK_RATE_PROBE_HEADER

#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <mutex>
#include <shared_mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include "net/msg_queue.h"
#include "utils/timer.hpp"

/**
 * @brief 单次区块探测的结果记录
 */
struct ProbeResult
{
    std::string hash;                       // 被探测的区块哈希
    uint64_t    create_time = 0;            // 区块接收时间（Unix时间戳，秒）
    bool        confirmed   = false;        // 是否已确认上链（任意一次 rate >= 0.8 即为 true）
    uint32_t    probe_count = 0;            // 实际执行的探测次数
    std::vector<double> rates;              // 每次探测的上链率（按时间顺序排列）

    ProbeResult() = default;
    ProbeResult(const std::string& h, uint64_t t)
        : hash(h), create_time(t) {}
};

// 前向声明（定义在 block_rate_probe.proto 生成的 pb 文件中）
class BlockRateProbeReq;
class BlockRateProbeAck;

/**
 * @class BlockRateProbe
 * @brief 区块上链率探测单例类
 *
 * 使用方式：
 *   MagicSingleton<BlockRateProbe>::GetInstance()->AddBlock(hash);
 *
 * 探测流程：
 *   1. AddBlock() 被调用时，注册区块并启动定时探测任务
 *   2. 分别在 T+5s、T+10s、T+20s 执行探测
 *   3. 每次探测：
 *      a. 获取当前全网质押节点列表
 *      b. 向所有质押节点发送 BlockRateProbeReq
 *      c. 收集响应，统计 exist=true 的节点数
 *      d. 计算上链率 rate = exist_count / total_pledge_count
 *      e. 若 rate >= 0.8，标记 confirmed=true，取消后续探测
 */
class BlockRateProbe
{
public:
    BlockRateProbe();
    ~BlockRateProbe();

    BlockRateProbe(const BlockRateProbe&) = delete;
    BlockRateProbe& operator=(const BlockRateProbe&) = delete;
    BlockRateProbe(BlockRateProbe&&) = delete;
    BlockRateProbe& operator=(BlockRateProbe&&) = delete;

    /**
     * @brief 添加需要探测上链率的区块
     *        仅当配置项 enable_block_rate_probe 为 true 时生效
     *
     * @param hash 区块哈希值
     */
    void AddBlock(const std::string& hash);

    /**
     * @brief 根据区块哈希获取最新一次探测的上链率
     *
     * @param hash 区块哈希值
     * @return double 最新一次探测的上链率，若无记录返回 -1.0
     */
    double GetRateByHash(const std::string& hash);

    /**
     * @brief 获取全部缓存的探测结果
     *
     * @param results 输出参数，用于接收所有已缓存的探测结果
     */
    void GetAllResults(std::vector<ProbeResult>& results);

private:
    /**
     * @brief 清理过期的定时器
     */
    void _CleanupExpiredTimers();

    /**
     * @brief 对指定区块执行一次探测
     *
     * @param hash       区块哈希
     * @param probeIndex 探测序号（0=第一次，1=第二次，2=第三次）
     */
    void _DoProbe(const std::string& hash, uint32_t probeIndex);

    /**
     * @brief 获取当前全网质押节点地址列表
     *        参考 CheckBlocks::fetchPledgeAddress() 实现
     *
     * @param pledgeAddr 输出参数，质押节点地址列表
     * @return int 0=成功，非0=失败
     */
    int _fetchPledgeAddress(std::vector<std::string>& pledgeAddr);

    /**
     * @brief 向所有质押节点发送探测请求
     *
     * @param nodeIds    目标节点ID列表
     * @param blockHash  区块哈希
     * @param msgId      消息标识
     */
    void _sendProbeRequests(const std::vector<std::string>& nodeIds,
                            const std::string& blockHash,
                            const std::string& msgId);

    /**
     * @brief 计算单次探测的上链率并更新结果
     *
     * @param hash             区块哈希
     * @param probeIndex       探测序号
     * @param totalNodeCount   质押节点响应总数
     * @param existCount       拥有区块的节点数
     */
    void _updateProbeResult(const std::string& hash,
                            uint32_t probeIndex,
                            uint64_t requiredResponses,
                            uint64_t existCount);

    /**
     * @brief 取消指定区块的后续未执行探测任务
     *
     * @param hash 区块哈希
     */
    void _cancelPendingProbes(const std::string& hash);

private:
    // --- 配置 ---
    static constexpr size_t kMaxCacheSize = 5000;      // 最大缓存记录数
    static constexpr uint32_t kProbeWaitTimeoutSec = 10; // 每次探测等待响应超时（秒）

    // --- 缓存结构 ---
    // 使用 deque 维护插入顺序，实现 O(1) 淘汰最旧记录
    std::deque<std::string> _hashQueue;
    // 使用 unordered_map 实现 O(1) 查询
    std::unordered_map<std::string, ProbeResult> _resultMap;

    // --- 定时器管理 ---
    // 为每个待探测的区块存储定时器（最多3个：T+5s, T+10s, T+20s）
    // key=hash, value=定时器列表（索引0=5秒，索引1=10秒，索引2=20秒）
    std::unordered_map<std::string, std::vector<std::shared_ptr<CTimer>>> _timers;

    // --- 线程安全 ---
    mutable std::shared_mutex _rwMutex;   // 读写锁，保护缓存和定时器映射
    std::mutex _timerMutex;               // 保护定时器操作

    // --- 消息标识计数器 ---
    std::atomic<uint64_t> _msgIdCounter{0};
};

// ==================== 网络消息处理函数 ====================

/**
 * @brief 发送区块上链率探测请求
 *
 * @param nodeId    目标节点ID
 * @param msgId     消息标识
 * @param blockHash 区块哈希
 */
void sendBlockRateProbeRequest(const std::string& nodeId,
                               const std::string& msgId,
                               const std::string& blockHash);

/**
 * @brief 发送区块上链率探测响应
 *
 * @param nodeId    目标节点ID
 * @param msgId     消息标识
 * @param blockHash 区块哈希
 * @param exist     本节点是否拥有该区块
 */
void sendBlockRateProbeAcknowledgment(const std::string& nodeId,
                                      const std::string& msgId,
                                      const std::string& blockHash,
                                      bool exist);

/**
 * @brief 处理收到的 BlockRateProbeReq 消息
 *        查询本地区块数据库，回复是否存在该区块
 *
 * @param msg     请求消息
 * @param msgdata 消息元数据
 * @return int 0=成功，非0=失败
 */
int handleBlockRateProbeRequest(const std::shared_ptr<BlockRateProbeReq>& msg,
                                const MsgData& msgdata);

/**
 * @brief 处理收到的 BlockRateProbeAck 消息
 *        收集探测响应结果
 *
 * @param msg     响应消息
 * @param msgdata 消息元数据
 * @return int 0=成功，非0=失败
 */
int handleBlockRateProbeAcknowledge(const std::shared_ptr<BlockRateProbeAck>& msg,
                                    const MsgData& msgdata);

#endif // CA_BLOCK_RATE_PROBE_HEADER
