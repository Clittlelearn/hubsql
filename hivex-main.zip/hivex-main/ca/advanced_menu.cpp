﻿#include "advanced_menu.h"

#include <map>
#include <regex>
#include <thread>
#include <chrono>
#include <ostream>
#include <fstream>
#include <vector>
#include <iomanip>

#include "ca/ca.h"
#include "ca/global.h"
#include "ca/contract.h"
#include "ca/txhelper.h"
#include "ca/interface.h"
#include "ca/algorithm.h"

#include "ca/transaction.h"
#include "ca/transaction/trans.h"
#include "ca/block_helper.h"
#include "ca/block_monitor.h"
#include "main/menu.h"
#include "ca/dispatchtx.h"
#include "ca/pressure_retry_policy.h"

#ifdef ENABLE_TX_TESTS
#include "tests/test_runner.h"
#endif

#include "common/genesis.h"
#include "net/api.h"
#include "net/peer_node.h"

#include "include/scope_guard.h"
#include "include/logging.h"

#include "openssl/crypto.h"
#include "utils/file_manager.h"
#include "utils/genesis_block.h"
#include "utils/tmp_log.h"
#include "utils/console.h"
#include "utils/time_util.h"
#include "utils/contract_utils.h"
#include "utils/bench_mark.h"
#include "utils/magic_singleton.h"
#include "utils/account_manager.h"
#include "utils/keccak_cryopp.hpp"
#include "utils/hex_code.h"
#include "utils/version.h"
#include "utils/base64.h"
#include "utils/pretty_print.h"

#include "db/db_api.h"
#include "ca/evm/evm_manager.h"
#include "openssl/rand.h"

constexpr size_t MAX_BATCH_SIZE = 990;
const static uint64_t inputLimitFirst = 500000;
struct contractJob{
    std::string fromAddr;
    std::string deployer;
    std::string contractAddresses;
    std::string arg;
    std::string tip;
    std::string money;
};

std::vector<contractJob> jobs;
std::atomic<int> jobs_index=0;
std::atomic<int> errNodeIndex=0;
boost::threadpool::pool test_pool;

void readContractJson(const std::string & file_name){
    std::ifstream file(file_name);
    std::stringstream buffer;  
    buffer << file.rdbuf();  
    std::string contents(buffer.str());
    if(contents.empty()){
        errorL("no data");
        return;
    }
    nlohmann::json json_object;
    try {
       json_object=nlohmann::json::parse(contents);
    } catch (std::exception & e) {
       errorL(e.what());
       return;
    }

    if(!json_object.is_array()){
        errorL("not a array");
       return;
    }
    try{
       for(auto &aitem:json_object){
            contractJob job;
            job.deployer=aitem["deployer"];
            job.contractAddresses=aitem["contractAddresses"];
            job.arg=aitem["arg"];
            job.money=aitem["money"];
            jobs.push_back(job);
       }
    }catch(std::exception & e){
        errorL("wath:%s",e.what());
       return;
    }
}

namespace
{
uint64_t SteadyNowMicros()
{
    return std::chrono::duration_cast<std::chrono::microseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

bool WaitForPressureRetry(uint64_t observedTop, uint64_t deadlineMicros)
{
    const uint64_t fallbackDeadline = SteadyNowMicros() +
        std::chrono::duration_cast<std::chrono::microseconds>(
            pressure_retry::kFallbackRetryInterval).count();
    while (pressure_retry::CanRetry(SteadyNowMicros(), deadlineMicros))
    {
        std::this_thread::sleep_for(pressure_retry::kHeightPollInterval);
        uint64_t currentTop = 0;
        if (DBReader().getBlockTop(currentTop) == DBStatus::DB_SUCCESS && currentTop != observedTop)
            return true;
        if (SteadyNowMicros() >= fallbackDeadline) return true;
    }
    return false;
}
}

void invokeContractWithRetry(contractJob job, uint64_t retryDeadlineMicros){
    

    infoL("fromAddr:%s",job.fromAddr);
    infoL("deployer:%s",job.deployer);
    infoL("deployutxo:%s",job.contractAddresses);
    infoL("money:%s",job.money);
    infoL("arg:%s",job.arg);

    std::string strFromAddr=job.fromAddr;

    if (!isValidAddress(strFromAddr))
    {
        std::cout << "Input addr error!" << std::endl;
        return;
    }
    DBReader dataReader;

    std::string strToAddr=job.deployer;
    if(!isValidAddress(strToAddr))
    {
        std::cout << "Input addr error!" << std::endl;
        return;        
    }

    std::string _contractAddresses=job.contractAddresses;
    std::string strInput=job.arg;
    if(strInput.substr(0, 2) == "0x")
    {
        strInput = strInput.substr(2);
    }

    
    std::regex pattern("^\\d+(\\.\\d+)?$");

    std::string transferContractString=job.money;
    if (!std::regex_match(transferContractString, pattern))
    {
        std::cout << "input contract transfer error ! " << std::endl;
        return;
    }
    uint64_t contractTransfer = (std::stod(transferContractString) + global::ca::MIN_DOUBLE_CONSTANT_PRECISION) * global::ca::kDecimalNum;
    int ret = 0;
    std::string assetTypeS;
    ret = ca_algorithm::GetCanBeRevokeAssetType(assetTypeS);
    if(ret != 0){
        ERRORLOG("Get Can BeRevoke AssetType fail!");\
        return;
    }
    
    std::pair<std::string, std::string> gasTrade = {strFromAddr, assetTypeS};
    TxHelper::vrfAgentType needAgent;
    std::string encodedInfo = "";
    Account launchAccount;
    if(MagicSingleton<AccountManager>::GetInstance()->FindAccount(strFromAddr, launchAccount) != 0)
    {
        ERRORLOG("Failed to find account {}", strFromAddr);
        return;
    }

    uint64_t top = 0;
    CTransaction outTx;
    std::vector<std::string> dirtyContract;
    uint32_t retryCount = 0;
    while (true)
    {
        if (DBStatus::DB_SUCCESS != dataReader.getBlockTop(top))
        {
            ERRORLOG("db get top failed!!");
            return;
        }
        outTx.Clear();
        dirtyContract.clear();
        ret = TxHelper::createEvmCallContractTransactionRequest(
            strFromAddr, strToAddr, strInput, encodedInfo, gasTrade, top + 1,
            outTx, needAgent, contractTransfer, dirtyContract, _contractAddresses, false);
        if (ret != TxHelper::kWaitingPendingUtxo) break;
        if (!pressure_retry::CanRetry(SteadyNowMicros(), retryDeadlineMicros))
        {
            INFOLOG("PENDING_UTXO_WAIT pressure task expired, address:{}, retries:{}",
                    strFromAddr, retryCount);
            return;
        }
        ++retryCount;
        INFOLOG("PENDING_UTXO_WAIT pressure task queued, address:{}, retry:{}, top:{}",
                strFromAddr, retryCount, top);
        if (!WaitForPressureRetry(top, retryDeadlineMicros))
        {
            INFOLOG("PENDING_UTXO_WAIT pressure task expired, address:{}, retries:{}",
                    strFromAddr, retryCount);
            return;
        }
    }
    if (ret != 0)
    {
        ERRORLOG("Contract pressure task creation failed, address:{}, ret:{}", strFromAddr, ret);
        return;
    }



    ContractTxMsgReq ContractMsg;
    ContractMsg.set_version(ohi::GetVersion());
    TxMsgReq * txMsg = ContractMsg.mutable_txmsgreq();
	txMsg->set_version(ohi::GetVersion());
    TxMsgInfo * txMsgInfo = txMsg->mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(outTx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    if (ret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        return;
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    std::cout << "size = " << dirtyContract.size() << std::endl;
    for (const auto &addr : dirtyContract)
    {
        std::cout << "addr = " << addHexPrefix(addr) << std::endl;
        txMsgInfo->add_contractstoragelist(addr);
    }

    auto msg = std::make_shared<ContractTxMsgReq>(ContractMsg);
    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(needAgent == TxHelper::vrfAgentType::vrfAgentType_vrf)
    {
        ret = dropCallShippingRequest(msg,outTx);
        MagicSingleton<BlockMonitor>::GetInstance()->dropshippingTxVec(outTx.hash());
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());
}

void invokeContract(contractJob job)
{
    invokeContractWithRetry(std::move(job), 0);
}

std::string ReadFileIntoString(std::string filename)
{
	std::ifstream ifile(filename);
	std::ostringstream buf;
	char ch;
	while(buf&&ifile.get(ch))
    {
        buf.put(ch);
    }
	return buf.str();
}

int LoopReadFile(std::string& input, std::string& output, const std::filesystem::path& filename = "")
{
    std::filesystem::path contract_path;
    bool raise_info = false;
    if (input == "0")
    {
        contract_path = std::filesystem::current_path() / "contract" / filename;
    }
    else
    {
        contract_path = input;
        raise_info = true;
    }

    if (raise_info)
    {
        while(!exists(contract_path))
        {
            input.clear();
            std::cout << contract_path << " doesn't exist! please enter again: (0 to skip, 1 to exit)" << std::endl;
            std::cin >> input;
            if (input == "0")
            {
                return 1;
            }
            if (input == "1")
            {
                return -1;
            }
            contract_path = input;
        }
    }
    else
    {
        if (!exists(contract_path))
        {
            return 1;
        }
    }

    output = ReadFileIntoString(contract_path.string());
    if(output.size() > inputLimitFirst)
    {
        std::cout << "Input cannot exceed " << inputLimitFirst << " characters" << std::endl;
        return -2;
    }
    return 0;
}

void HandleMultiDeployContract1(const std::string &strFromAddr)
{
    if (!isValidAddress(strFromAddr))
    {
        std::cout << "Input addr error!" << std::endl;
        return;
    }

    DBReader dataReader;
    uint64_t top = 0;
	if (DBStatus::DB_SUCCESS != dataReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return ;
    }

    CTransaction outTx;
    TxHelper::vrfAgentType needAgent;
    std::vector<std::string> dirtyContract;
    std::string assetTypeS;
    int ret1 = ca_algorithm::GetCanBeRevokeAssetType(assetTypeS);
    if (ret1 != 0) {
        ERRORLOG("Get Can Be Revoke AssetType fail!");
        return; 
    }
    
    std::pair<std::string,std::string> gasTrade = {strFromAddr, assetTypeS};

    std::string nContractPath = "0";
    std::string code;
    int ret = LoopReadFile(nContractPath, code, "contract");
    if (ret != 0)
    {
        return;
    }

    if(code.empty())
    {
        return;
    }

    auto result = Evmone::latestContractAddress(strFromAddr);
    if (!result.has_value())
    {
        return;
    }
    std::string encodedInfo = "";
    uint64_t contractTransfer = 0;
    std::string contractAddress = result.value();
    auto tret = TxHelper::createEvmDeployContractTransactionRequest(top + 1,
                                                       outTx, gasTrade, dirtyContract,
                                                       needAgent,
                                                       code, strFromAddr, contractTransfer, contractAddress, encodedInfo);
    if(tret != 0)
    {
        ERRORLOG("Failed to create DeployContract transaction! The error code is:{}", ret);
        return;
    }
    
    ContractTxMsgReq ContractMsg;
    ContractMsg.set_version(ohi::GetVersion());
    TxMsgReq * txMsg = ContractMsg.mutable_txmsgreq();
	txMsg->set_version(ohi::GetVersion());
    TxMsgInfo * txMsgInfo = txMsg->mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(outTx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);
    uint64_t txUtxoLocalHeight;
    int aret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    if(aret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        return;
    }

    for (const auto& addr : dirtyContract)
    {
        txMsgInfo->add_contractstoragelist(addr);
    }

    auto msg = std::make_shared<ContractTxMsgReq>(ContractMsg);
    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(needAgent == TxHelper::vrfAgentType::vrfAgentType_vrf )
    {
        ret = dropCallShippingRequest(msg, outTx);
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());
    std::cout << "Transaction result : " << ret << std::endl;
}

void CreateAutomaticMultDeployContract()
{
    std::vector<std::string> acccountlist;
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(acccountlist);
    errNodeIndex=0;
    int time_s;
    std::string fromAddr;
    std::cout << "time_s:" ;
    std::cin >>  time_s;
    std::cout << "second:";
    long long _second;
    std::cin >> _second;
    std::cout << "hom much:";
    long long _much;
    std::cin >> _much;
    int oneSecond=0;
    while(time_s){
        oneSecond++;
        std::cout <<"xxx x" << std::endl;
        fromAddr = acccountlist[errNodeIndex];
        test_pool.schedule(boost::bind(HandleMultiDeployContract1, fromAddr));
        std::thread th=std::thread(HandleMultiDeployContract1,fromAddr);
        th.detach();
        errNodeIndex=++errNodeIndex%acccountlist.size();
        if(errNodeIndex == 0)
            break;
        ::usleep(_second *1000 *1000 / _much);
        if(oneSecond == _much){
            time_s--;
            oneSecond=0;
        }
    }
}


void contact_thread_test(){
    readContractJson("contract.json");
    std::vector<std::string> acccountlist;
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(acccountlist);

    jobs_index=0;
    errNodeIndex=0;
    int time_s;
    std::cout << "time_s:" ;
    std::cin >>  time_s;
    std::cout << "second:";
    long long _second;
    std::cin >> _second;
    std::cout << "hom much:";
    long long _much;
    std::cin >> _much;

    // 记录起始区块高度
    int64_t _tpsStartHeight = 0;
    {
        DBReader dbReader;
        uint64_t top = 0;
        if (DBStatus::DB_SUCCESS == dbReader.getBlockTop(top))
        {
            _tpsStartHeight = static_cast<int64_t>(top);
            std::cout << "[TPS] 合约测试起始高度: " << _tpsStartHeight << std::endl;
        }
    }

    const int originalTimeSeconds = time_s;
    std::vector<std::thread> pressureWorkers;
    pressureWorkers.reserve(static_cast<size_t>(time_s) * static_cast<size_t>(_much));
    int oneSecond=0;
    while(time_s){
        oneSecond++;
        std::cout <<"hhh h" << std::endl;
        jobs[jobs_index].fromAddr=acccountlist[errNodeIndex];
        std::cout << "----errNodeIndex :" << errNodeIndex << "------fromaddr :" << acccountlist[errNodeIndex]<<std::endl;
        const uint64_t retryDeadline = SteadyNowMicros() +
            std::chrono::duration_cast<std::chrono::microseconds>(pressure_retry::kMaxWait).count();
        pressureWorkers.emplace_back(invokeContractWithRetry, jobs[jobs_index], retryDeadline);
        jobs_index=++jobs_index%jobs.size();
        errNodeIndex=++errNodeIndex%acccountlist.size();
        ::usleep(_second *1000 *1000 / _much);
        if(oneSecond == _much){
            time_s--;
            oneSecond=0;
        }
    }

    std::cout << "循环已停止" << std::endl;
    for (auto &worker : pressureWorkers)
        if (worker.joinable()) worker.join();
    std::cout << "[TPS] 所有发送及pending重试任务已结束" << std::endl;

    // 清空输入缓冲区，避免影响菜单
    std::cin.clear();
    std::cin.ignore(1024, '\n');

    // 记录结束高度并生成TPS报告
    if (_tpsStartHeight > 0)
    {
        DBReader dbReader;
        uint64_t top = 0;
        if (DBStatus::DB_SUCCESS == dbReader.getBlockTop(top))
        {
            int64_t _tpsEndHeight = static_cast<int64_t>(top);
            std::cout << "[TPS] 合约测试结束高度: " << _tpsEndHeight << std::endl;
            // 预期交易数 = 总时长(time_s) × 每秒发笔数(_much)
            int64_t expectedTx = static_cast<int64_t>(originalTimeSeconds) * _much;
            // 测试标签: 33_t{总时长}s_m{每秒笔数}_s{间隔微秒}
            std::string testTag = "33_t" + std::to_string(originalTimeSeconds) + "s_m"
                                + std::to_string(_much) + "_s" + std::to_string(_second);
            generateTpsReport(_tpsStartHeight + 1, _tpsEndHeight, expectedTx, testTag);
        }
    }
}

   
void MenuAdvanced()
{
    #ifndef NDEBUG
	PrintBasicInfo();
    while (true)
    {
        
        std::cout << std::endl;
        std::cout << "1.Ca" << std::endl;
        std::cout << "2.Net" << std::endl;
        std::cout << "0.Exit" << std::endl;

        std::string strKey;
        std::cout << "please input your choice:";
        std::cin >> strKey;

        std::regex pattern("[0-3]");
        if (!std::regex_match(strKey, pattern))
        {
            std::cout << "Input invalid." << std::endl;
            return;
        }
        int key = std::stoi(strKey);
        switch (key)
        {
        case 0:
            return;
        case 1:
            MenuCa();
            break;
        case 2:
            MenuNet();
            break;
        default:
            std::cout << "Invalid input." << std::endl;
            continue;
        }
        sleep(1);
        
    }
    #endif
}

void MenuCa()
{
    while (true)
    {
        std::cout << std::endl;
        std::cout << std::endl;
        std::cout << "1.See which addr have been delegatinged." << std::endl;
        std::cout << "2.Calculate pledge yield." << std::endl;
        std::cout << "3.Obtain block information through transaction hash" << std::endl;
        std::cout << "4.tps" << std::endl;
        std::cout << "5.Check the address and amount of the delegatingee account" << std::endl;
        std::cout << "6.View block info." << std::endl;
        std::cout << "7.Rollback block." << std::endl;
        std::cout << "8. Stake List" << std::endl;
        std::cout << "9. View Exchequer" << std::endl;
        std::cout << "11.Test." << std::endl;
        std::cout << "0.Exit." << std::endl;

        std::cout << "AddrList : " << std::endl;
        MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();

        std::string strKey;
        std::cout << "please input your choice:";
        std::cin >> strKey;

        std::regex pattern("^[0-9]|([1][0-9])$");
        if (!std::regex_match(strKey, pattern))
        {
            std::cout << "Input invalid." << std::endl;
            return;
        }
        int key = std::stoi(strKey);
        switch (key)
        {
        case 0:
            return;
        case 1:
        {
            auto ret = fetchBonusAddressInfo();
            std::cout << "ret :" << ret << std::endl;
            break;
        }
        case 2:
        {
            std::map<std::string, uint64_t> values;
            const std::string bonusAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
            uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
            
            auto ret = ca_algorithm::CalcBonusValue(curTime, bonusAddr, values, true);
            std::cout << "ret :" << ret << std::endl;
            break;
        }
        case 3:
            getBlockInfoByTxHash();
            break;
        case 4:
            TpsCount();
            break;
        case 5:
            Get_DelegatingedNodeBlance();
            break;
        case 6:
            menuBlockInfo();
            break;
        case 7:
            RollBack();
            break;
        case 8:
            GetStakeList();
            break;
        case 9:
            fetchExchequer();
            break;
        case 11:
            MenuTest();
            break;
        default:
            std::cout << "Invalid input." << std::endl;
            continue;
        }
    }
}

void RollBack()
{
    MagicSingleton<BlockHelper>::GetInstance()->RollbackTest();
}

void GetStakeList()
{
    DBReader dbReader;
    std::vector<std::string> addResses;
    dbReader.getStakeAddr(addResses);
    std::cout << "StakeList :" << std::endl;
    for (auto &it : addResses)
    {
        double timp = 0.0;
        ca_algorithm::GetCommissionPercentage(it, timp);
        std::cout << "addr: " << "0x"+it << "\tbonus pumping: " << timp << std::endl;
    }
}

void fetchExchequer(){
    std::map<std::string, TxHelper::ProposalInfo> assetMap;
    int ret = ca_algorithm::fetchAvailableAssetType(assetMap);
	if(ret != 0){
		ERRORLOG("Get available asset fail! ret : {}",ret);
		return;
	}
    DBReader dbReader; 
    uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(curTime);
    TxHelper::ProposalInfo null;
    assetMap.insert({global::ca::ASSET_TYPE_OHI,null});
    int choice;
    std::cout << "Enter 0 to see today and 1 to see yesterday: ";
    std::cin >> choice;
    if (choice == 1){
        period = period - 1;
    }
    std::map<std::string,uint64_t> assetTypeAmount;
    for(const auto& _assetType : assetMap){
        uint64_t gasAmount = 0;
        auto result = dbReader.getGasAmountByPeriod(period,_assetType.first,gasAmount);
        if(result != DBStatus::DB_SUCCESS && result != DBStatus::DB_NOT_FOUND){
            ERRORLOG("GetGasamountbyTimeType error!");
            return ;
        }
        if(gasAmount != 0){
            assetTypeAmount.insert({_assetType.first,gasAmount});
        }
    }
    if (assetTypeAmount.empty()) {
        std::cout << "assetTypeAmount is empty." << std::endl;
    }
    for(const auto& _assetType : assetTypeAmount){
        std::cout << "Asset Type: " << _assetType.first << ", Amount: " << _assetType.second << std::endl;
    }
}

int fetchBonusAddressInfo()
{
    DBReader dbReader;
    std::multimap<std::string, std::string> delegatingAddr_currency;
    std::vector<std::string> stake_addresses_list;
    dbReader.getStakeAddr(stake_addresses_list);
    std::ofstream outFile("getbonusaddrinfo.txt", std::ios::trunc);
    for (auto &bonusAddr : stake_addresses_list)
    {
        usleep(1);
        delegatingAddr_currency.clear();
        std::cout << YELLOW << "BonusAddr: " << addHexPrefix(bonusAddr) << RESET << std::endl;
        outFile << "BonusAddr: " << addHexPrefix(bonusAddr) << std::endl;
        auto ret = dbReader.getDelegatingAddrAndAssetTypeByBonusAddr(bonusAddr, delegatingAddr_currency);
        if (ret != DBStatus::DB_SUCCESS && ret != DBStatus::DB_NOT_FOUND)
        {
            return -1;
        }

        uint64_t sumdelegateAmount = 0;
        std::cout << "DelegatingAddr:" << std::endl;
        outFile << "DelegatingAddr:" << std::endl;
        for (auto &[delegatingAddr, currency] : delegatingAddr_currency)
        {
            std::cout << addHexPrefix(delegatingAddr) << " currency: " << currency << std::endl;
            outFile << addHexPrefix(delegatingAddr) << " currency: " << currency << std::endl;
            std::vector<std::string> utxos;
            ret = dbReader.getDelegatingAddrUtxoByBonusAddr(bonusAddr, delegatingAddr, currency, utxos);
            if (ret != DBStatus::DB_SUCCESS && ret != DBStatus::DB_NOT_FOUND)
            {
                return -2;
            }

            uint64_t delegateAmount = 0;
            for (const auto &hash : utxos)
            {
                std::string txRaw;
                if (dbReader.getTransactionByHash(hash, txRaw) != DBStatus::DB_SUCCESS)
                {
                    return -3;
                }
                CTransaction tx;
                if (!tx.ParseFromString(txRaw))
                {
                    return -4;
                }
                for(const auto & utxo : tx.utxos())
                {
                    for (int i = 0; i < utxo.vout_size(); i++)
                    {
                        if (utxo.vout(i).addr() == global::ca::kVirtualDelegatingAddr)
                        {
                            delegateAmount += utxo.vout(i).value();
                            break;
                        }
                    }
                }
            }
            sumdelegateAmount += delegateAmount;
        }
        std::cout << "total delegating amount :" << sumdelegateAmount << std::endl;
        outFile << "total delegating amount :" << sumdelegateAmount << std::endl;
    }
    return 0;
}

#pragma region netMenu
void MenuNet()
{
    while (true)
    {
        std::cout << std::endl;
        std::cout << "1.Send message To user." << std::endl;
        std::cout << "2.Show my K bucket." << std::endl;
        std::cout << "3.Kick out node." << std::endl;
        std::cout << "4.Test echo." << std::endl;
        std::cout << "5.Broadcast sending Messages." << std::endl;
        std::cout << "6.Print req and ack." << std::endl;
        std::cout << "7.Print buffers." << std::endl;
        std::cout << "8.Big data send to user." << std::endl;
        std::cout << "9.Show my ID." << std::endl;
        std::cout << "0.Exit" << std::endl;

        std::string strKey;
        std::cout << "please input your choice:";
        std::cin >> strKey;

        std::regex pattern("^[0-9]|([1][0])$");
        if (!std::regex_match(strKey, pattern))
        {
            std::cout << "Input invalid." << std::endl;
            return;
        }
        int key = std::stoi(strKey);
        switch (key)
        {
        case 0:
            return;
        case 1:
            SendMessageToUser();
            break;
        case 2:
            displayKBuckets();
            break;
        case 3:
            kickOutNode();
            break;
        case 4:
            TestEcho();
            break;
        case 5:
            net_com::testBroadcastMessage();
            break;
        case 6:
            printRequestAndAcknowledgment();
            break;
        case 7:
            MagicSingleton<bufferControl>::GetInstance()->printBuffers();
            break;
        case 8:
            net_com::sendBigDataForTest();
            break;
        case 9:
            printf("MyID : %s\n", addHexPrefix(MagicSingleton<PeerNode>::GetInstance()->GetAddress()).c_str());
            break;
        default:
            std::cout << "Invalid input." << std::endl;
            continue;
        }
    }
}

void SendMessageToUser()
{
    if (net_com::sendOneMessageRequest() == 0){
        DEBUGLOG("send one msg Succ.");
    }else{
        DEBUGLOG("send one msg Fail.");
    }
        
}

void displayKBuckets()
{
    std::cout << "The K bucket is being displayed..." << std::endl;
    auto nodeList = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    MagicSingleton<PeerNode>::GetInstance()->Print(nodeList);
}

void kickOutNode()
{
    std::string id;
    std::cout << "input id:" << std::endl;
    std::cin >> id;
    MagicSingleton<PeerNode>::GetInstance()->DeleteNode(id);
    std::cout << "Kick out node succeed!" << std::endl;
}

void TestEcho()
{
    
    std::string message;
    std::cout << "please input message:" << std::endl;
    std::cin >> message;
    std::stringstream ss;
    ss << message << "_" << std::to_string(MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp());

    EchoReq echoReq;
    echoReq.set_id(MagicSingleton<PeerNode>::GetInstance()->GetSelfId());
    echoReq.set_message(ss.str());
    bool isSucceed = net_com::BroadCastMessage(echoReq, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::kPriorityLow0);
    if (isSucceed == false)
    {
        ERRORLOG(":broadcast EchoReq failed!");
        return;
    }
}

void printRequestAndAcknowledgment()
{
    double total = .0f;
    std::cout << "------------------------------------------" << std::endl;
    for (auto &item : global::requestCountMap)
    {
        total += (double)item.second.second;
        std::cout.precision(3);
        std::cout << item.first << ": " << item.second.first << " size: " << (double)item.second.second / 1024 / 1024 << " MB" << std::endl;
    }
    std::cout << "------------------------------------------" << std::endl;
    std::cout << "Total: " << total / 1024 / 1024 << " MB" << std::endl;
}

void menuBlockInfo()
{
    while (true)
    {
        DBReader reader;
        uint64_t top = 0;
        reader.getBlockTop(top);

        std::cout << std::endl;
        std::cout << "Height: " << top << std::endl;
        std::cout << "1.Get the total number of transactions \n"
                     "2.Get transaction block details\n"
                     "5.Get device password \n"
                     "6.Set device password\n"
                     "7.Get device private key\n"
                     "0.Exit \n";

        std::string strKey;
        std::cout << "please input your choice:";
        std::cin >> strKey;

        std::regex pattern("^[0-7]$");
        if (!std::regex_match(strKey, pattern))
        {
            std::cout << "Input invalid." << std::endl;
            return;
        }
        int key = std::stoi(strKey);
        switch (key)
        {
        case 0:
            return;
           

        case 2:
            retrieveTransactionBlockInfo(top);
            break;
       

        default:
            std::cout << "Invalid input." << std::endl;
            continue;
        }

        sleep(1);
    }
}

void retrieveTransactionBlockInfo(uint64_t &top)
{
    auto amount = std::to_string(top);
    std::string inputStart, inputEnd;
    uint64_t start, end;

    std::cout << "amount: " << amount << std::endl;
    std::cout << "pleace input start: ";
    std::cin >> inputStart;
    if (inputStart == "a" || inputStart == "pa")
    {
        inputStart = "0";
        inputEnd = amount;
    }
    else
    {
        if (std::stoul(inputStart) > std::stoul(amount))
        {
            std::cout << "input > amount" << std::endl;
            return;
        }
        std::cout << "pleace input end: ";
        std::cin >> inputEnd;
        if (std::stoul(inputStart) < 0 || std::stoul(inputEnd) < 0)
        {
            std::cout << "params < 0!!" << std::endl;
            return;
        }
        if (std::stoul(inputStart) > std::stoul(inputEnd))
        {
            inputStart = inputEnd;
        }
        if (std::stoul(inputEnd) > std::stoul(amount))
        {
            inputEnd = std::to_string(top);
        }
    }
    start = std::stoul(inputStart);
    end = std::stoul(inputEnd);

    std::cout << "Print to screen[0] or file[1] ";
    uint64_t nType = 0;
    std::cin >> nType;
    if (nType == 0)
    {
        printRocksdbInfo(start, end, true, std::cout);
    }
    else if (nType == 1)
    {
        std::string fileName = "print_block_" + std::to_string(start) + "_" + std::to_string(end) + ".txt";
        std::ofstream filestream;
        filestream.open(fileName);
        if (!filestream)
        {
            std::cout << "Open file failed!" << std::endl;
            return;
        }
        printRocksdbInfo(start, end, true, filestream);
    }
}

void MenuTest()
{
    while (true)
    {
        std::cout << std::endl;
        std::cout << "2. Output the block in database" << std::endl;
        std::cout << "3. PrintAllAccount" << std::endl;
        std::cout << "4. Query balance according to utxo" << std::endl;
        std::cout << "5. Imitate create tx" << std::endl;
        std::cout << "6. Create multi thread automatic transaction" << std::endl;
        std::cout << "7. Create multi thread automatic stake transaction" << std::endl;
        std::cout << "8. Multi transaction" << std::endl;
        std::cout << "9. Automatic Delegating" << std::endl;
        std::cout << "10. The TxTransaction By Node" << std::endl;
        std::cout << "11. Print Signable Verification Nodes" << std::endl;
        std::cout << "12. Generate account addresses that EVM can." << std::endl;
        std::cout << "13. Query all stake addresses" << std::endl;
        std::cout << "14. Automatic disordered transaction (simplified version)" << std::endl;
        std::cout << "15. get TX data." << std::endl;
        std::cout << "17. Benchmark" << std::endl;
        std::cout << "18. Benchmark Clear" << std::endl;
        std::cout << "19. Benchmark automatic write" << std::endl;
        std::cout << "20. print_benchmark_summary_handle_tx" << std::endl;
        std::cout << "21. Get simple transaction count" << std::endl;
        std::cout << "22. MultiTx" << std::endl;
        std::cout << "23. Get reward amount" << std::endl;
        std::cout << "24. Get CacheSize" << std::endl;
        std::cout << "25. Clear Cache" << std::endl;
        std::cout << "26. Get CacheSize to file" << std::endl;
        std::cout << "27. destroy all cache object" << std::endl;
        std::cout << "28. Base 64 verify" << std::endl;
        std::cout << "29. test new addr " << std::endl;
        std::cout << "30. generate evm addr" << std::endl;
        std::cout << "31. test Delegate" << std::endl;
        std::cout << "32. test many to one delegate" << std::endl;
        std::cout << "33. test contracl pool" << std::endl;
        std::cout << "34. Check the success rate of automatic transactions" << std::endl;
        std::cout << "35. Open Log" << std::endl;
        std::cout << "36. Close Log" << std::endl;
        std::cout << "37. deploy contract" << std::endl;
        std::cout << "38. The contract data is exported to json" << std::endl;
        std::cout << "39. Multi account transaction" << std::endl;
        std::cout << "40. Multi deploy contract" << std::endl;
        std::cout << "41. Get all transaction records of the account" << std::endl;
        std::cout << "42. Test sign." << std::endl;
        std::cout << "43. Test bonus time." << std::endl;
        std::cout << "44. View all bonus info." << std::endl;
        std::cout << "45. Export and test contract" << std::endl;
#ifdef ENABLE_TX_TESTS
        std::cout << "46. Transaction Tests" << std::endl;
#endif
        std::cout << "0. Exit" << std::endl;
        std::string strKey;
        std::cout << "please input your choice:";
        std::cin >> strKey;
#ifdef ENABLE_TX_TESTS
        std::regex pattern("^([0-9]|[1-3][0-9]|4[0-6])$");
#else
        std::regex pattern("^([0-9]|[1-3][0-9]|4[0-5])$");
#endif

        if (!std::regex_match(strKey, pattern))
        {
            std::cout << "Input invalid." << std::endl;
            return;
        }
        int key = std::stoi(strKey);
        switch (key)
        {
        case 0:
            return;
        case 2:
            printDatabaseBlock();
            break;
        case 3:
            MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();
            break;
        case 4:
            {
                std::string address = "";
                std::cout << "please input address:";
                std::cin >> address;

                std::map<std::string, TxHelper::ProposalInfo> assetMap;
                int ret = ca_algorithm::fetchAvailableAssetType(assetMap);
                for(auto& item : assetMap){
                    uint64_t amount = 0;
                    get_balance_by_utxo(address, item.first, amount);    
                    std::cout << "assetType :" << item.first << std::endl;
                    std::cout << "amount :" << amount << std::endl;
                    std::cout << "=========================================" << std::endl;
                }

                uint64_t amount = 0;
                get_balance_by_utxo(address, global::ca::ASSET_TYPE_OHI, amount);    
                std::cout << "assetType :" << global::ca::ASSET_TYPE_OHI << std::endl;
                std::cout << "amount :" << amount << std::endl;
            }
            break;
        case 5:
            MockTransactionStruct();
            break;
        case 6:
            createMultiThreadAutoTransaction();
            break;
        case 7:
            createMultiThreadAutoStakeTransaction();
            break;
        case 8:
            MultiTransaction();
            break;
        case 9:
            AutoDelegation();
            break;
        case 10:
            CreateNodeAutomaticTransferTransaction();
            break;
        case 11:
            printAndVerifyNode();
            break;
        case 12:
            TestAddressMapping();
            break;
        case 13:
            get_all_pledge_addresses();
            break;
        case 14:
            AutoTx();
            break;
        case 15:
            PrintTxData();
            break;
        case 17:
            MagicSingleton<Benchmark>::GetInstance()->PrintBenchmarkSummary(false);
            break;
        case 18:
            MagicSingleton<Benchmark>::GetInstance()->Clear();
            break;
        case 19:
            print_benchmark_to_file();
            break;
        case 20:
            MagicSingleton<Benchmark>::GetInstance()->print_benchmark_summary_handle_tx(true);
            break;
        case 21:
            MagicSingleton<Benchmark>::GetInstance()->printTxCount();
            break;
        case 22:
            MultiTx();
            break;
        case 23:
            GetRewardAmount();
            break;
        case 24:
            PrintCache(0);
            break;
        case 25:
            PrintCache(1);
            break;
        case 26:
            PrintCache(2);
            break;
        case 27:
            TestSign();
            break;
        case 28:
            {
                std::string encode = "MFYwEAYHKoZIzj0CAQYFK4EEAAoDQgAEsQJ6nc6l3rrxrBJ74IBzH5xAHDEq6fMsOV1cOXVNgCVPVjb7FzP3k / JTDGMz7dFsPqgiSos14Xg7NkxYRLOxww ==";
                std::string ownerAddr = GenerateAddr(Base64Decode(encode));
                std::cout << ownerAddr << std::endl;
                break;
            }
            case 29: {
              uint64_t top = 0;
              int retNum = transactionDiscoveryHeight(top);
              if (retNum != 0) {
                return ;
              }
              
              // 让用户输入交易类型
              int txType = -1;
              std::cout << "请输入交易类型 (-1 表示全部): ";
              std::cin >> txType;
              
              // 让用户输入自定义数据
              nlohmann::json customData;
              std::cout << "是否添加自定义数据? (y/n): ";
              char addCustomData;
              std::cin >> addCustomData;
              
              if (addCustomData == 'y' || addCustomData == 'Y') {
                std::string key, value;
                std::cout << "输入自定义数据 (输入 'done' 结束):" << std::endl;
                while (true) {
                  std::cout << "Key: ";
                  std::cin >> key;
                  if (key == "done") break;
                  std::cout << "Value: ";
                  std::cin >> value;
                  customData[key] = value;
                }
              }
              
              std::ofstream file("filename.md");
              if (!file.is_open()) {
                std::cerr << "无法打开文件: " << "filename.md" << std::endl;
                return ;
              }
              
              std::string stake = ThreadTest::PrintDelegatingBlock(top, false, txType, customData);
              file << stake;
              file.close();
              return ;
              break;
            }
            case 30:
            break;
        case 31:
            TestsHandleDelegating();
            break;
        case 32:
            testManToOneDelegate();
            break;
        case 33:
            contact_thread_test();
            break;
        case 34:
            {
                MagicSingleton<BlockMonitor>::GetInstance()->transactionSuccessRateChecker();
                break;
            }
        case 35:
            OpenLog();
            break;
        case 36:
            CloseLog();
            break;
        case 37:
            createAutomaticDeployContract();
            break;
        case 38:
            printJson();
            break;
        case 39:
            MultiAccountTransactionEntity();
            break;
        case 40:
            CreateAutomaticMultDeployContract();
            break;
        case 41:
            {
                std::string address = "";
                std::cout << "Please input address: " << std::endl;
                std::cin >> address;
                GetAllTransactionRecordsOfTheAccount(address);
            }
            break;
        case 42:
            {
            DebugEthSignatureDemo();
            break;
            }
        case 43:
            {
                int i = 0;
                DBReader dbReader;
                std::vector<std::string> signatureAddresses;
                for (i = 0; DBStatus::DB_SUCCESS != dbReader.getSignAddrByPeriod(i, signatureAddresses); i++)
                {   
                }
                std::cout << i << std::endl;
            }	
            break;
        case 44:
            GetBonusTransactionStatistics();
            break;
#ifdef ENABLE_TX_TESTS
        case 46:
            showTransactionTestMenu();
            break;
#endif
        default:
            std::cout << "Invalid input." << std::endl;
            continue;
        }

        sleep(1);
    }
}

void PrintTxData()
{
    std::string hash;
    std::cout << "TX hash: ";
    std::cin >> hash;

    DBReader dbReader;

    CTransaction tx;
    std::string TxRaw;
    auto ret = dbReader.getTransactionByHash(hash, TxRaw);
    if (ret != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("getTransactionByHash failed!");
        return;
    }
    if (!tx.ParseFromString(TxRaw))
    {
        ERRORLOG("Transaction Parse failed!");
        return;
    }

    nlohmann::json dataJson = nlohmann::json::parse(tx.data());
    std::string data = dataJson.dump(4);
    std::cout << data << std::endl;
}



void ProcessBatch(const std::set<std::string>& batch, uint64_t amt, const std::vector<std::string>& assetType, std::pair<std::string, std::string>& gasTrade, bool isFindUtxo, uint64_t top,const std::string Addr) {
    std::map<std::string, int64_t> to_addr_amount;
    for (const auto &addr : batch) {
        std::string ss = remove0xPrefix(addr);
        to_addr_amount[ss] = (amt + global::ca::MIN_DOUBLE_CONSTANT_PRECISION) * global::ca::kDecimalNum;
    }

    std::vector<TxHelper::TransTable> txAsset;
    for (const auto &asset : assetType) {
        txAsset.emplace_back(TxHelper::TransTable{asset, {Addr}, to_addr_amount});
    }

    std::string txInfo = "";
    std::string encodedInfo = Base64Encode(txInfo);
    if (encodedInfo.size() > 1024) {
        std::cout << "The information entered exceeds the specified length" << std::endl;
        return;
    }

    CTransaction outTx;
    TxHelper::vrfAgentType needAgent;
    int ret = TxHelper::createTransactionRequest(txAsset, gasTrade, false, encodedInfo, top + 1, outTx, needAgent, isFindUtxo);
    if (ret != 0) {
        ERRORLOG("createTransactionRequest error!!");
        return;
    }

    TxMsgReq txMsg;
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo* txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(outTx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    if (ret != 0) {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        return;
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    auto msg = std::make_shared<TxMsgReq>(txMsg);

    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if (outTx.identity() == defaultAddr) {
        ret = handleTransaction(msg, outTx);
    } else {
        ret = DropShippingTransaction(msg, outTx, outTx.identity());
    }
    DEBUGLOG("Transaction result, ret:{}  txHash: {}, identity:{}", ret, outTx.hash(), outTx.identity());
    std::this_thread::sleep_for(std::chrono::seconds(8));
}

void MultiTx() {
    std::cout << std::endl;
    std::cout << std::endl;
    std::cout << "1.Import the txt file." << std::endl;
    std::cout << "2.Import all accounts in the cert directory." << std::endl;
    std::string strKey;
    std::cout << "please input your choice:";
    std::cin >> strKey;

    std::regex pattern("^[1-2]");
    if (!std::regex_match(strKey, pattern)) {
        std::cout << "Input invalid." << std::endl;
        return;
    }
    int key = std::stoi(strKey);

    std::set<std::string> toAddrs;

    if (key == 1) {
        std::ifstream fin("toaddr.txt", std::ifstream::binary);
        if (!fin.is_open()) {
            std::cout << "open file error" << std::endl;
            return;
        }
        std::string Addr;
        while (getline(fin, Addr)) {
            if (Addr[Addr.length() - 1] == '\r') {
                Addr = Addr.substr(0, Addr.length() - 1);
            }
            toAddrs.insert(Addr);
        }
        fin.close();
    } else if (key == 2) {
        std::string path = "./keystore";
        try {
            for (const auto& entry : std::filesystem::directory_iterator(path)) {
                std::string filename = entry.path().filename().string();
                // Remove ".json" suffix if present
                const std::string jsonSuffix = ".json";
                if (filename.size() >= jsonSuffix.size() &&
                    filename.compare(filename.size() - jsonSuffix.size(), jsonSuffix.size(), jsonSuffix) == 0) {
                    filename = filename.substr(0, filename.size() - jsonSuffix.size());
                }
                toAddrs.insert(filename);
            }
        } catch (const std::filesystem::filesystem_error& e) {
            std::cerr << "File system error: " << e.what() << std::endl;
        }
    }

    Account account;
    MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(account);
    std::string strFromAddr = account.GetAddr();
    std::string fromAddr = remove0xPrefix(strFromAddr);
    std::cout << "default addr: " << "0x" + strFromAddr << std::endl;

    std::string Addr;
    std::cout << "input Addr>:";
    std::cin >> Addr;
    auto find = toAddrs.find(Addr);
    if (find != toAddrs.end()) {
        toAddrs.erase(find);
    }
    Addr = remove0xPrefix(Addr);
    find = toAddrs.find(Addr);
    if (find != toAddrs.end()) {
        toAddrs.erase(find);
    }

    std::cout << "================" << std::endl;
    for (auto &z : toAddrs) {
        std::cout << "toaddr:" << z << std::endl;
    }

    uint64_t amt = 0;
    std::cout << "input amount>:";
    std::cin >> amt;

    std::string _isGastrade = "0";
    std::pair<std::string, std::string> gasTrade = {};
    std::string assetTypeS;
    int ret = ca_algorithm::GetCanBeRevokeAssetType(assetTypeS);
    if(ret != 0){
        ERRORLOG("Get Can BeRevoke AssetType fail!");\
        return;
    }

    std::vector<std::string> assetType = {assetTypeS};

    uint64_t top = 0;
    DBReader dbReader;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top)) {
        ERRORLOG("db get top failed!!");
        return;
    }
    std::mutex batchMutex;
    size_t batchSize = 0;
    std::set<std::string> batch;
    for (const auto &addr : toAddrs)
    {
        batch.insert(addr);
        batchSize++;
        if (batchSize >= MAX_BATCH_SIZE) 
        {
            {
                ProcessBatch(batch, amt, assetType, gasTrade, false, top, Addr);
            }
            batch.clear();
            batchSize = 0;
        }
    }
    
    // Process any remaining addresses
    if (!batch.empty()) 
    {
        ProcessBatch(batch, amt, assetType, gasTrade, false, top, Addr);
    }
}

void testaddr2()
{    
    while(true)
    {
        std::cout << "isValidAddress: " << std::endl;
        std::string addr;
        std::cin>>addr;
        if (addr.substr(0, 2) == "0x") 
        {
            addr = addr.substr(2);
        }
        if (!isValidAddress(addr))
        {
            std::cout << "Input addr error!" << std::endl;
            return;
        }
    }
}


void getContractAddr()
{
    // std::cout << std::endl
    //           << std::endl;

    // std::cout << "AddrList : " << std::endl;
    // MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();

    // std::string strFromAddr;
    // std::cout << "Please enter your addr:" << std::endl;
    // std::cin >> strFromAddr;
    // if (!isValidAddress(strFromAddr))
    // {
    //     std::cout << "Input addr error!" << std::endl;
    //     return;
    // }

    // DBReader dbReader;
    // std::vector<std::string> deployerList;
    // dbReader.getEvmDeployerAddr(deployerList);
    // std::cout << "=====================deployers=====================" << std::endl;
    // for(auto& deployer : deployerList)
    // {
    //     std::cout << "deployer: " << deployer << std::endl;
    // }
    // std::cout << "=====================deployers=====================" << std::endl;
    // std::string strToAddr;
    // std::cout << "Please enter to addr:" << std::endl;
    // std::cin >> strToAddr;
    // if(!isValidAddress(strToAddr))
    // {
    //     std::cout << "Input addr error!" << std::endl;
    //     return;
    // }

    // std::vector<std::string> deployedUtxos;
    // dbReader.GetDeployUtxoByDeployerAddr(strToAddr, deployedUtxos);
    // std::cout << "=====================deployed utxos=====================" << std::endl;
    // for(auto& deployUtxoInfo : deployedUtxos)
    // {
    //     std::cout << "deployed utxo: " << deployUtxoInfo << std::endl;
    // }
    // std::cout << "=====================deployed utxos=====================" << std::endl;
    // std::string strTxHash;
    // std::cout << "Please enter tx hash:" << std::endl;
    // std::cin >> strTxHash;


    // 兼容以太坊：使用 sender+nonce RLP 规则生成预测地址示例
    // std::string addr = evm_utils::ToChecksumAddress(evm_utils::GenerateContractAddrEth(strToAddr, 0));


    // std::cout << addr << std::endl;
}

static bool benchmarkAtomicWriteSwitch = false;
void print_benchmark_to_file()
{
    if(benchmarkAtomicWriteSwitch)
    {
        benchmarkAtomicWriteSwitch = false;
        std::cout << "benchmark automic write has stoped" << std::endl;
        return;
    }
    std::cout << "enter write time interval (unit second) :";
    int interval = 0;
    std::cin >> interval;
    if(interval <= 0)
    {
         std::cout << "time interval less or equal to 0" << std::endl;
         return;
    }
    benchmarkAtomicWriteSwitch = true;
    auto benchmarkAtomicWriteThread = std::thread(
            [interval]()
            {
                while (benchmarkAtomicWriteSwitch)
                {
                    MagicSingleton<Benchmark>::GetInstance()->PrintBenchmarkSummary(true);
                    MagicSingleton<Benchmark>::GetInstance()->print_benchmark_summary_handle_tx(true);
                    sleep(interval);
                }
            }
    );
    benchmarkAtomicWriteThread.detach();
    return;
}

void get_balance_by_utxo()
{
    std::cout << "Inquiry address:";
    std::string addr;
    std::cin >> addr;
    if (addr.substr(0, 2) == "0x") 
    {
        addr = addr.substr(2);
    }
    std::string assetType;
    std::cout << "Please enter the type of asset you want to currency type :" << std::endl;
    std::cin >> assetType;

    DBReader reader;
    
    if (assetType == global::ca::ASSET_TYPE_OHI)
    {
        int64_t balance = 0;
        auto ret = reader.getBalanceByAddr(addr, assetType, balance);
        if (ret == DBStatus::DB_SUCCESS)
        {
            std::cout << "address: " << addHexPrefix(addr) 
                      << " Vote asset balance: " << balance << std::endl;
        }
        else
        {
            std::cout << "address: " << addHexPrefix(addr) 
                      << " Vote asset balance: 0" << std::endl;
        }
        return;
    }
    
    std::vector<std::string> utxoHashesList;
    reader.getUtxoHashsByAddress(addr, assetType, utxoHashesList);

    auto utxoOutput = [addr, utxoHashesList, &reader](std::ostream &stream)
    {
        stream << "account:" << addHexPrefix(addr) << " utxo list " << std::endl;

        uint64_t total = 0;
        for (auto i : utxoHashesList)
        {
            std::string txRaw;
            reader.getTransactionByHash(i, txRaw);

            CTransaction tx;
            tx.ParseFromString(txRaw);

            uint64_t value = 0;
            for(const auto & utxo : tx.utxos())
            {
                for (int j = 0; j < utxo.vout_size(); j++)
                
                {
                    CTxOutput txout = utxo.vout(j);
                    if (txout.addr() != addr)
                    {
                        continue;
                    }
                    value += txout.value();
                }
            }
            stream << i << " : " << value << std::endl;
            total += value;
        }

        stream << "address: " << addHexPrefix(addr) << " UTXO total: " << utxoHashesList.size() << " UTXO gross value:" << total << std::endl;
    };

    if (utxoHashesList.size() < 10)
    {
        utxoOutput(std::cout);
    }
    else
    {
        std::string fileName = "utxo_" + addr + ".txt";
        std::ofstream file(fileName);
        if (!file.is_open())
        {
            ERRORLOG("Open file failed!");
            return;
        }
        utxoOutput(file);
        file.close();
    }
}

int MockTransactionStruct()
{
    std::cout << "=== Testing Dynamic Genesis Block Generation ===" << std::endl;
    
    const auto & genesisInstance = MagicSingleton<Genesis>::GetInstance();
    
    // Display current configuration information
    std::cout << "Network Type: " << Genesis::NetworkTypeToString(genesisInstance->GetNetworkType()) << std::endl;
    std::cout << "Network Name: " << genesisInstance->GetNetworkName() << std::endl;
    std::cout << "Genesis Account: " << genesisInstance->GetInitAccountAddr() << std::endl;
    std::cout << "Genesis Time: " << genesisInstance->GetGenesisTime() << std::endl;
    std::cout << "Asset Types:" << std::endl;

    std::cout << "  " << "MM: " << ": " << genesisInstance->GetInitialBalanceOHI() << std::endl;


    // Generate the genesis block
    CBlock block;
    if (!GenesisBlock::GenerateGenesisBlock(block))
    {
        std::cout << "Failed to generate genesis block!" << std::endl;
        return -1;
    }
    
    CBlock dbBlock;
    {
        DBReader dbReader;
        std::string hash;
        std::string blockRaw;

        if (DBStatus::DB_SUCCESS != dbReader.getBlockHashByBlockHeight(0, hash))
        {
            ERRORLOG("Get Block Hash error.");
            return -2;
        }

        if (DBStatus::DB_SUCCESS != dbReader.getBlockByBlockHash(hash,blockRaw))
        {
            ERRORLOG("Get Block Raw error.");
            return -3;
        }
        dbBlock.ParseFromString(blockRaw);
    }

    if (dbBlock.hash() != block.hash())
    {
        std::cout << "Genesis block generated and validated failed!" << std::endl;
        return -4;
    }
    
    std::cout << "Genesis block generated and validated successfully!" << std::endl;
    
    std::cout << "Block Hash: " << block.hash() << std::endl;
    std::cout << "Block Height: " << block.height() << std::endl;
    std::cout << "Block Time: " << block.time() << std::endl;
    std::cout << "Transaction Count: " << block.txs_size() << std::endl;
    
    if (block.txs_size() > 0)
    {
        const CTransaction& tx = block.txs(0);
        std::cout << "Genesis Transaction Hash: " << tx.hash() << std::endl;
        std::cout << "Genesis Transaction UTXO Count: " << tx.utxos_size() << std::endl;
        
        for (int i = 0; i < tx.utxos_size(); ++i)
        {
            const CTxUtxos& utxo = tx.utxos(i);
            std::cout << "  UTXO " << i << " Asset Type: " << utxo.assettype() << std::endl;
            if (utxo.vout_size() > 0)
            {
                std::cout << "  UTXO " << i << " Value: " << utxo.vout(0).value() << std::endl;
                std::cout << "  UTXO " << i << " Address: " << utxo.vout(0).addr() << std::endl;
            }
        }
    }
    
    // Generate a hexadecimal string
    std::string hex = Str2Hex(block.SerializeAsString());
    std::cout << std::endl << "Genesis Block Raw Data:" << std::endl;
    std::cout << hex << std::endl;

    return 0;
}

void MultiAccountTransactionEntity()
{
    std::vector<std::string> Accouncstr;
    Account account;
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(Accouncstr);
    MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(account);
    std::string strAccount = account.GetAddr();
    auto it = std::remove(Accouncstr.begin(), Accouncstr.end(), strAccount);
    Accouncstr.erase(it, Accouncstr.end());
    
    std::string _isGastrade = "0";
    std::pair<std::string, std::string> gasTrade = {};
    std::vector<std::string> assetType = {};
    
    int i = -1; 
    while (true) {
        std::cout << "1. Transfer Vote assets" << std::endl;
        std::cout << "2. Transfer OHI assets" << std::endl;
        std::cout << ">>>";
        std::cin >> i;

        if (i == 1) {
            assetType.push_back(global::ca::ASSET_TYPE_OHI);
            break; 
        } 
        else if (i == 2) {
            std::string assetTypeS;
            int ret = ca_algorithm::GetCanBeRevokeAssetType(assetTypeS);
            if (ret != 0) {
                ERRORLOG("Get Can Be Revoke AssetType fail!");
                return; 
            }
            assetType.push_back(assetTypeS);
            break;
        } 
        else {
            std::cout << "Error! Please enter 1 or 0." << std::endl; 
        }
    }

    uint64_t amt = 0;
    std::cout << "input amount>:";
    std::cin >> amt;

    uint64_t top = 0;
    DBReader dbReader;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return;
    }
    std::mutex batchMutex;
    size_t batchSize = 0;
    std::set<std::string> batch;
    for (const auto &addr : Accouncstr)
    {
        batch.insert(addr);
        batchSize++;
        if (batchSize >= MAX_BATCH_SIZE)
        {
            {
                ProcessBatch(batch, amt, assetType, gasTrade, false, top, strAccount);
            }
            batch.clear();
            batchSize = 0;
        }
    }

    // Process any remaining addresses
    if (!batch.empty())
    {
        ProcessBatch(batch, amt, assetType, gasTrade, false, top, strAccount);
    }
}

void get_all_pledge_addresses()
{
    DBReader reader;
    std::vector<std::string> addressVec;
    reader.getStakeAddr(addressVec);

    auto allPledgeOutputs = [addressVec](std::ostream &stream)
    {
        stream << std::endl
               << "---- Pledged address start ----" << std::endl;
        for (auto &addr : addressVec)
        {
            uint64_t pledgeamount = 0;
            SearchStake(addr, pledgeamount, global::ca::StakeType::STAKE_TYPE_NODE);
            stream << addHexPrefix(addr) << " : " << pledgeamount << std::endl;
        }
        stream << "---- Number of pledged addresses:" << addressVec.size() << " ----" << std::endl
               << std::endl;
        stream << "---- Pledged address end  ----" << std::endl
               << std::endl;
    };

    if (addressVec.size() <= 10)
    {
        allPledgeOutputs(std::cout);
    }
    else
    {
        std::string fileName = "all_pledge.txt";

        std::cout << "output to a file" << fileName << std::endl;

        std::ofstream fileStream;
        fileStream.open(fileName);
        if (!fileStream)
        {
            std::cout << "Open file failed!" << std::endl;
            return;
        }

        allPledgeOutputs(fileStream);

        fileStream.close();
    }
}

void AutoTx()
{
    if (isCreateTx)
    {
        int i = 0;
        std::cout << "1. Close the transaction" << std::endl;
        std::cout << "0. Continue trading" << std::endl;
        std::cout << ">>>" << std::endl;
        std::cin >> i;
        if (i == 1)
        {
            bStopTx = true;
        }
        else if (i == 0)
        {
            return;
        }
        else
        {
            std::cout << "Error!" << std::endl;
            return;
        }
    }
    else
    {
        bStopTx = false;
        std::vector<std::string> addrs;

        MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();
        MagicSingleton<AccountManager>::GetInstance()->GetAccountList(addrs);

        double sleepTime = 0;
        std::cout << "Interval time (seconds):";
        std::cin >> sleepTime;
        sleepTime *= 1000000;
        std::thread th(TestCreateTx, addrs, (int)sleepTime);
        th.detach();
        return;
    }
}

void getBlockInfoByTxHash()
{
    DBReader reader;

    std::cout << "Tx Hash : ";
    std::string txHash;
    std::cin >> txHash;

    std::string blockHash;
    reader.getBlockHashByTransactionHash(txHash, blockHash);

    if (blockHash.empty())
    {
        std::cout << RED << "Error : getBlockHashByTransactionHash failed !" << RESET << std::endl;
        return;
    }

    std::string blockStr;
    reader.getBlockByBlockHash(blockHash, blockStr);
    CBlock block;
    block.ParseFromString(blockStr);

    std::cout << GREEN << "Block Hash : " << blockHash << RESET << std::endl;
    std::cout << GREEN << "Block height : " << block.height() << RESET << std::endl;
}

void GetTxHashByHeight(int64_t start, int64_t end, std::ofstream& filestream,
                       global::ca::TxType txTypeFilter = global::ca::TxType::UNKNOWN)
{
    int64_t localStart = start;
    int64_t localEnd = end;

    if (localEnd < localStart)
    {
        std::cout << "input invalid" << std::endl;
        return;
    }
    
    if (!filestream)
    {
        std::cout << "Open file failed!" << std::endl;
        return;
    }
    filestream << "TPS_INFO:" << std::endl;
    if (txTypeFilter != global::ca::TxType::UNKNOWN)
    {
        filestream << "Tx type filter >: " << static_cast<int32_t>(txTypeFilter) << std::endl;
    }

    const auto countMatchingTransactions = [txTypeFilter](const CBlock& block)
    {
        uint64_t count = 0;
        for (const auto& tx : block.txs())
        {
            if (txTypeFilter == global::ca::TxType::UNKNOWN ||
                static_cast<global::ca::TxType>(tx.type()) == txTypeFilter)
            {
                ++count;
            }
        }
        return count;
    };

    DBReader dbReader;
    uint64_t txTotal = 0;
    uint64_t blockTotal = 0;
    for (int64_t i = localEnd; i >= localStart; --i)
    {

        std::vector<std::string> block_hashes_temp;
        if (DBStatus::DB_SUCCESS != dbReader.getBlockHashsByBlockHeight(i, block_hashes_temp))
        {
            ERRORLOG("(GetTxHashByHeight) getBlockHashsByBlockHeight  Failed!!");
            return;
        }

        int txHashCounter = 0;
        for (auto &blockhash : block_hashes_temp)
        {
            std::string blockstr;
            dbReader.getBlockByBlockHash(blockhash, blockstr);
            CBlock block;
            block.ParseFromString(blockstr);
            txHashCounter += static_cast<int>(countMatchingTransactions(block));
        }
        txTotal += txHashCounter;
        blockTotal += block_hashes_temp.size();
        filestream  << "Height >: " << i << " Blocks >: " << block_hashes_temp.size() << " Txs >: " << txHashCounter  << std::endl;
        for(auto &blockhash : block_hashes_temp)
        {
            std::string blockstr;
            dbReader.getBlockByBlockHash(blockhash, blockstr);
            CBlock block;
            block.ParseFromString(blockstr);
            std::string block_hash_temporary = block.hash();
            block_hash_temporary = block_hash_temporary.substr(0,6);
            int hash_size_temp = static_cast<int>(countMatchingTransactions(block));
            filestream << " BlockHash: " << block_hash_temporary << " TxHashSize: " << hash_size_temp << std::endl;
        }
    }

    filestream  << "Total block sum >:" << blockTotal  << std::endl;
    filestream  << "Total tx sum >:" << txTotal   << std::endl;
    std::vector<std::string> startHashes;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockHashsByBlockHeight(localStart, startHashes))
    {
        ERRORLOG("getBlockHashsByBlockHeight fail  top = {} ", localStart);
        return;
    }

    //Take out the blocks at the starting height and sort them from the smallest to the largest in time
    std::vector<CBlock> startBlocks;
    for (auto &hash : startHashes)
    {
        std::string blockStr;
        dbReader.getBlockByBlockHash(hash, blockStr);
        CBlock block;
        block.ParseFromString(blockStr);
        startBlocks.push_back(block);
    }
    std::sort(startBlocks.begin(), startBlocks.end(), [](const CBlock &x, const CBlock &y)
              { return x.time() < y.time(); });

    std::vector<std::string> endHashes;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockHashsByBlockHeight(localEnd, endHashes))
    {
        ERRORLOG("getBlockHashsByBlockHeight fail  top = {} ", localEnd);
        return;
    }

    //Take out the blocks at the end height and sort them from small to large in time
    std::vector<CBlock> endBlocks;
    for (auto &hash : endHashes)
    {
        std::string blockStr;
        dbReader.getBlockByBlockHash(hash, blockStr);
        CBlock block;
        block.ParseFromString(blockStr);
        endBlocks.push_back(block);
    }
    std::sort(endBlocks.begin(), endBlocks.end(), [](const CBlock &x, const CBlock &y)
              { return x.time() < y.time(); });

    float timeDiff = 0;
    if (endBlocks[endBlocks.size() - 1].time() - startBlocks[0].time() != 0)
    {
        timeDiff = float(endBlocks[endBlocks.size() - 1].time() - startBlocks[0].time()) / float(1000000);
    }
    else
    {
        timeDiff = 1;
    }
    uint64_t transmissionCount = txTotal ;
    float tps = float(transmissionCount) / float(timeDiff);
    filestream << "TPS : " << tps << std::endl;
}




void generateTpsReport(int64_t start, int64_t end, int64_t expectedTx, const std::string& testTag)
{
    // Contract transactions remain valid for 30 seconds.  Leave a small
    // propagation margin so the report does not sample exactly at expiry.
    const bool isContractPoolReport = testTag.rfind("33_", 0) == 0;
    const bool isAutoTransactionReport = testTag.rfind("6_", 0) == 0;
    const global::ca::TxType txTypeFilter =
        isContractPoolReport ? global::ca::TxType::CALL :
        isAutoTransactionReport ? global::ca::TxType::TX :
                                  global::ca::TxType::UNKNOWN;
    const auto settlementWait = std::chrono::seconds(isContractPoolReport ? 35 : 10);
    std::cout << "[TPS] 等待" << settlementWait.count() << "秒确保交易上链完成..." << std::endl;
    std::this_thread::sleep_for(settlementWait);

    // 重新获取结束高度，包含延迟期间上链的区块
    {
        DBReader dbReader;
        uint64_t top = 0;
        if (DBStatus::DB_SUCCESS == dbReader.getBlockTop(top))
        {
            end = static_cast<int64_t>(top);
            std::cout << "[TPS] 重新获取结束高度: " << end << std::endl;
        }
    }

    std::string StartW = std::to_string(start);
    std::string EndW = std::to_string(end);
    std::string fileName;
    if (!testTag.empty())
    {
        fileName = "TPS_INFO_" + testTag + "_" + StartW + "_" + EndW + ".txt";
    }
    else
    {
        fileName = "TPS_INFO_" + StartW + "_" + EndW + ".txt";
    }
    std::ofstream filestream;
    filestream.open(fileName);
    if (!filestream.is_open())
    {
        std::cout << "[TPS] Failed to open file: " << fileName << std::endl;
        return;
    }

    // The chain may not advance before the sender stops.  Only decide whether
    // the range is empty after the settlement wait and the final height read.
    if (end < start)
    {
        std::cout << "[TPS] No new blocks after settlement: start=" << start
                  << " end=" << end << std::endl;
        filestream << "TPS_INFO:" << std::endl;
        filestream << "Total block sum >:0" << std::endl;
        filestream << "Total tx sum >:0" << std::endl;
        filestream << "TPS : 0" << std::endl;
    }
    else
    {
        GetTxHashByHeight(start, end, filestream, txTypeFilter);
    }
    filestream.close();

    std::cout << "[TPS] 报告文件已生成: " << fileName << std::endl;

    // 如果提供了预期交易数，计算并追加成功率
    if (expectedTx > 0)
    {
        // 读回文件获取实际交易总数
        std::ifstream readStream(fileName);
        int64_t actualTx = 0;
        bool foundActualTx = false;
        if (readStream.is_open())
        {
            const std::string totalTxMarker = "Total tx sum >:";
            std::string line;
            while (std::getline(readStream, line))
            {
                size_t pos = line.find(totalTxMarker);
                if (pos != std::string::npos)
                {
                    std::string numStr = line.substr(pos + totalTxMarker.size());
                    // 去掉前导空格
                    size_t firstDigit = numStr.find_first_not_of(" \t");
                    if (firstDigit != std::string::npos)
                    {
                        numStr = numStr.substr(firstDigit);
                    }
                    try
                    {
                        actualTx = std::stoll(numStr);
                        foundActualTx = true;
                    }
                    catch (...)
                    {
                    }
                    break;
                }
            }
            readStream.close();
        }

        if (foundActualTx)
        {
            double successRate = static_cast<double>(actualTx) / static_cast<double>(expectedTx) * 100.0;
            std::ofstream appendStream(fileName, std::ios::app);
            if (appendStream.is_open())
            {
                appendStream << "Expected Tx   >: " << expectedTx << std::endl;
                appendStream << "Success Rate  >: " << std::fixed << std::setprecision(2) << successRate << "%" << std::endl;
                appendStream.close();
            }
            std::cout << "[TPS] 预期交易数: " << expectedTx
                      << ", 实际交易数: " << actualTx
                      << ", 成功率: " << std::fixed << std::setprecision(2) << successRate << "%" << std::endl;
        }
    }
}

void TpsCount(){
    int64_t start = 0;
    int64_t end = 0;
    std::cout << "Please input start height:";
    std::cin >> start;

    std::cout << "Please input end height:";
    std::cin >> end;

    generateTpsReport(start, end);
}

void Get_DelegatingedNodeBlance()
{
    std::string addr;
    std::cout << "Please enter the address you need to inquire: " << std::endl;
    std::cin >> addr;
    if (addr.substr(0, 2) == "0x") 
    {
        addr = addr.substr(2);
    }

    int ret = 0;
    int size = 0;
    std::string errMessage = "success";
    do
    {
        DBReader dbReader;
        std::multimap<std::string, std::string> addresses_assetType;
        auto status = dbReader.getDelegatingAddrAndAssetTypeByBonusAddr(addr, addresses_assetType);
        if (status != DBStatus::DB_SUCCESS && status != DBStatus::DB_NOT_FOUND)
        {
            errMessage = "Database abnormal, Get delegating addrs by node failed!";
            ret = -1;
            break;
        }
        if (addresses_assetType.size() + 1 > 999)
        {
            errMessage = "The account number to be delegatinged have been delegatinged by 999 people!";
            ret = -2;
            break;
        }

        for (auto &[delegatingAddr, assetType] : addresses_assetType)
        {
            std::vector<std::string> utxos;
            if (dbReader.getDelegatingAddrUtxoByBonusAddr(addr, delegatingAddr, assetType, utxos) != DBStatus::DB_SUCCESS)
            {
                errMessage = "Get bonus addr delegating addr utxo failed!";
                ret = -3;
                break;
            }

            for (const auto &utxo : utxos)
            {
                std::string strTx;
                if (dbReader.getTransactionByHash(utxo, strTx) != DBStatus::DB_SUCCESS)
                {
                    errMessage = "Get transaction failed!";
                    ret = -4;
                    break;
                }

                CTransaction tx;
                if (!tx.ParseFromString(strTx))
                {
                    errMessage = "Failed to parse transaction body!";
                    ret = -5;
                    break;
                }
                for(auto &txUtxo : tx.utxos())
                {
                    for(auto &vout: txUtxo.vout()){
                        if (vout.addr() == global::ca::kVirtualDelegatingAddr)
                        {
                            ++size;
                            std::cout << "addr: " << delegatingAddr << "\tassetType: " << assetType << "\tvalue: " << std::to_string(vout.value()) << std::endl;
                            break;
                        }
                    }
                }
            }
        }
    } while(0);
    
    std::cout << "size: " << size << "\tcode: " << ret << "\tmessage: " <<  errMessage << std::endl;
    return;
}
void printDatabaseBlock()
{
    DBReader dbReader;
    std::string str = PrintBlocks(100, false);
    std::cout << str << std::endl;
}

void ThreadTest::testCreateTransactionMessage(const std::string &from, const std::string &to, bool isAmount, const double amount, std::string asset_type)
{
    std::cout << "from:" << addHexPrefix(from) << std::endl;
    std::cout << "to:" << addHexPrefix(to) << std::endl;

    uint64_t startTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    bool Initiate = false;
    ON_SCOPE_EXIT{
        if(!Initiate)
        {
            MagicSingleton<Benchmark>::GetInstance()->clearTransactionInitiateMap();
        }
    };

    std::string _isGastrade = "0";
    std::pair<std::string,std::string> gasTrade = {};
    if (CheckGasAssetsInput(_isGastrade,gasTrade) != 0)
    {
        return ;
    }

    std::vector<TxHelper::TransTable> txAsset;
    std::string amountStr = "";
    if (isAmount)
    {
        amountStr = std::to_string(amount);
    }else{
        int intPart = 0;
        double decPart = (double)(rand() % 10) / 10000;
        amountStr = std::to_string(intPart + decPart);
    }

    if (amountStr == "0")
    {
        std::cout << "amount = 0" << std::endl;
        DEBUGLOG("amount = 0");
        return;
    }

    if("default" != asset_type)
    {
        TxHelper::TransTable sucTrade3;
        sucTrade3.asset_type = remove0xPrefix(asset_type);
        sucTrade3.fromAddr.push_back(from);
        sucTrade3.toAddrAmount[to] = (std::stod(amountStr) + global::ca::MIN_DOUBLE_CONSTANT_PRECISION) * global::ca::kDecimalNum;
        txAsset.push_back(sucTrade3);
    }
    else
    {
        TxHelper::TransTable sucTrade3;
        sucTrade3.asset_type = global::ca::ASSET_TYPE_OHI;
        sucTrade3.fromAddr.push_back(from);
        sucTrade3.toAddrAmount[to] = (std::stod(amountStr) + global::ca::MIN_DOUBLE_CONSTANT_PRECISION) * global::ca::kDecimalNum;
        txAsset.push_back(sucTrade3);
        std::string assetType;
        int ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
        if(ret != 0){
            ERRORLOG("Get Can BeRevoke AssetType fail!");
            return;
        }
    
        TxHelper::TransTable sucTrade1;
        sucTrade1.asset_type = assetType;
        sucTrade1.fromAddr.push_back(from);
        sucTrade1.toAddrAmount[to] = (std::stod(amountStr) + global::ca::MIN_DOUBLE_CONSTANT_PRECISION) * global::ca::kDecimalNum;
        txAsset.push_back(sucTrade1);
    }


    DBReader dbReader;

    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if (retNum != 0) {
      ERRORLOG("transactionDiscoveryHeight error {}", retNum);
      return;
    }

    TxHelper::TransTable trans_info;

    TransforerTransParam param;
    param.tx_asset = txAsset;
    param.gas_tray = {gasTrade.first, gasTrade.second};
    param.encoded_info = "";
    // param.height = top+1;
    param.is_find_utxo = false;
    param.is_gas_tray = _isGastrade == "1" ? true : false;

    TransforerTrans testTrans(param);

    auto ret = testTrans.trans();
    if (!ret.isOk()) {
      ERRORLOG("TransforerTrans error {}", ret.error_message(true));
      std::cerr << ret.error_message() << std::endl;
      return;
    };

    auto siret = testTrans.signTx("");

    testTrans.print_debug_tx();

    if (!siret.isOk()) {
      ERRORLOG("sign TransforerTrans tx error {}", siret.error_message(true));
      std::cerr << siret.error_message() << std::endl;
      return;
    }

    auto msgret = testTrans.goMessage();

    if (!msgret.isOk()) {
      ERRORLOG("goMessage stake tx error {}", msgret.error_message(true));

      std::cerr << msgret.error_message() << std::endl;
      return;
    }

    // CTransaction outTx;
    // TxHelper::vrfAgentType needAgent;
    // std::string encodedInfo = "";
    // int ret = TxHelper::createTransactionRequest(txAsset, gasTrade, std::stoi(_isGastrade), encodedInfo,top + 1, outTx, needAgent,false);
    // if (ret != 0)
    // {
    //     ERRORLOG("createTransactionRequest error!! ret:{}", ret);
    //     return;
    // }
    
    // TxMsgReq txMsg;
    // txMsg.set_version(ohi::GetVersion());
    // TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    // txMsgInfo->set_type(0);
    // txMsgInfo->set_tx(outTx.SerializeAsString());
    // txMsgInfo->set_nodeheight(top);

    // uint64_t txUtxoLocalHeight;
    // ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    // if(ret != 0)
    // {
    //     ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
    //     return;
    // }

    // txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    // auto msg = std::make_shared<TxMsgReq>(txMsg);
    // std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    // if (outTx.identity() == defaultAddr)
    // {
    //     MagicSingleton<BlockMonitor>::GetInstance()->addDoHandleTransactionVector(outTx.hash());
    //     ret = handleTransaction(msg,outTx);
    // }
    // else
    // {
    //     MagicSingleton<BlockMonitor>::GetInstance()->dropshippingTxVec(outTx.hash());
    //     ret = DropShippingTransaction(msg, outTx, outTx.identity());
    // }
    
    global::ca::TxNumber++;
    DEBUGLOG("Transaction result, txHash:{}, TxNumber:{}, package:{}",
              testTrans.getTx()->hash(),
             global::ca::TxNumber, testTrans.getTx()->identity());
    Initiate = true;
    MagicSingleton<Benchmark>::GetInstance()->addTransactionInitiateMap(startTime, MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp());
    
    std::cout << "=====Transaction initiator:" << addHexPrefix(from) << std::endl;
    std::cout << "=====Transaction recipient:" << addHexPrefix(to) << std::endl;
    std::cout << "=====Transaction amount:" << amountStr << std::endl;
    std::cout << "=======================================================================" << std::endl
              << std::endl
              << std::endl;
}

bool stopTx2 = true;
bool isCreateTransaction_2 = false;
static int i = -1;

void ThreadTest::setStopTransmissionFlag(const bool &flag)
{
    stopTx2 = flag;
}

void ThreadTest::stopTxFlag(bool &flag)
{
   flag =  stopTx2 ;
}

void ThreadTest::TestCreateTx(uint32_t tranNum, std::vector<std::string> addrs_,int timeout, std::string asset_type)
{
    DEBUGLOG("TestCreateTx start at {}", MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp());
    Cycliclist<std::string> addrs;

    for (auto &U : addrs_)
    {
        addrs.push_back(U);
    }

    if(addrs.isEmpty())
    {
        std::cout << "account list is empty" << std::endl;
        return;
    }
    auto iter=addrs.begin();
    while (stopTx2==false)
    {
        MagicSingleton<Benchmark>::GetInstance()->transactionInitiateBatchSize(tranNum);
        for (int i = 0; i < tranNum; i++)
        {
           
            std::string from = iter->data;
            iter++;
            std::string to = iter->data;
            std::thread th(ThreadTest::testCreateTransactionMessage, from, to,false,0, asset_type);
            th.detach();
            
        }
        sleep(timeout);
    }
}

void CreateNodeAutomaticTransferTransaction()
{
    std::vector<Node> pubNodeList_ =
        MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    std::vector<std::string> Accouncstr;
    for (auto &s : pubNodeList_)
    {
        Accouncstr.push_back(s.address);
    }
    Account account;
    MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(account);
    std::string strAccount = account.GetAddr();
    auto it = std::remove(Accouncstr.begin(), Accouncstr.end(), strAccount);
    Accouncstr.erase(it, Accouncstr.end());
    uint64_t amt = 0;
    std::cout << "input amount>:";
    std::cin >> amt;

    std::string _isGastrade = "0";
    std::pair<std::string, std::string> gasTrade = {};
    std::string assetTypeS;
    int ret = ca_algorithm::GetCanBeRevokeAssetType(assetTypeS);
    if(ret != 0){
        ERRORLOG("Get Can BeRevoke AssetType fail!");\
        return;
    }
    
    std::vector<std::string> assetType = {assetTypeS};

    uint64_t top = 0;
    DBReader dbReader;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return;
    }

    std::mutex batchMutex;
    size_t batchSize = 0;
    std::set<std::string> batch;
    for (const auto &addr : Accouncstr)
    {
        batch.insert(addr);
        batchSize++;
        if (batchSize >= MAX_BATCH_SIZE)
        {
            {
                ProcessBatch(batch, amt, assetType, gasTrade, false, top, strAccount);
            }
            batch.clear();
            batchSize = 0;
        }
    }

    // Process any remaining addresses
    if (!batch.empty())
    {
        ProcessBatch(batch, amt, assetType, gasTrade, false, top, strAccount);
    }
}

void createMultiThreadAutoTransaction()
{
    int time_s = 0;
    std::cout << "tx_total time_s(seconds):";
    std::cin >> time_s;

    int intervalSeconds = 0;
    std::cout << "second:";
    std::cin >> intervalSeconds;

    int frequency = 0;
    std::cout << "frequency:";
    std::cin >> frequency;

    std::string asset_type;
    std::cout << "Input assert type (input default send two types of transactions):";
    std::cin >> asset_type;

    std::vector<std::string> addrs;
    MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(addrs);

    // 记录起始区块高度
    int64_t startHeight = 0;
    {
        DBReader dbReader;
        uint64_t top = 0;
        if (DBStatus::DB_SUCCESS == dbReader.getBlockTop(top))
        {
            startHeight = static_cast<int64_t>(top);
            std::cout << "[TPS] 多线程自动交易起始高度: " << startHeight << std::endl;
        }
    }

    // 停止之前的线程（如果有）
    stopTx2 = true;
    std::this_thread::sleep_for(std::chrono::milliseconds(500));

    // 启动新线程
    stopTx2 = false;
    std::thread th(ThreadTest::TestCreateTx, frequency, addrs, intervalSeconds, asset_type);
    th.detach();

    std::cout << "多线程自动交易运行中，持续 " << time_s << " 秒..." << std::endl;

    // 等待指定时长
    std::this_thread::sleep_for(std::chrono::seconds(time_s));

    // 停止线程
    stopTx2 = true;
    std::cout << "交易已停止，等待剩余交易完成..." << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(3));

    // 记录结束高度并生成TPS报告
    {
        DBReader dbReader;
        uint64_t top = 0;
        if (DBStatus::DB_SUCCESS == dbReader.getBlockTop(top))
        {
            int64_t endHeight = static_cast<int64_t>(top);
            std::cout << "[TPS] 多线程自动交易结束高度: " << endHeight << std::endl;
            if (startHeight > 0)
            {
                int64_t expectedTx = static_cast<int64_t>(time_s) * frequency /
                                     (intervalSeconds > 0 ? intervalSeconds : 1);
                // 测试标签: 6_t{总时长}s_f{每批发笔数}_i{间隔秒}
                std::string testTag = "6_t" + std::to_string(time_s) + "s_f"
                                    + std::to_string(frequency) + "_i"
                                    + std::to_string(intervalSeconds) + "s";
                generateTpsReport(startHeight + 1, endHeight, expectedTx, testTag);
            }
        }
    }
}

void test_create_stake(const std::string &from,const std::string & assetType)
{
    TxHelper::stakeType stakeType = TxHelper::stakeType::STAKE_TYPE_NODE;
    uint64_t stakeAmount = 100000  * global::ca::kDecimalNum ;

    DBReader data_reader;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != data_reader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return;
    }
    CTransaction outTx;
    TxHelper::vrfAgentType needAgent;
    std::vector<TxHelper::Utxo> outVin;  
    std::string encodedInfo = "";
    std::pair<std::string,std::string> gasTrade = {};  
    if (TxHelper::CreateStakingTransaction(from,assetType,stakeAmount, top + 1,  stakeType, outTx, outVin, needAgent, 
                                                gasTrade, false,global::ca::MIN_COMMISSION_RATE, false, encodedInfo) != 0)
    {

        return;
    }
    std::cout << " from: " << addHexPrefix(from) << " amout: " << stakeAmount << std::endl;
    TxMsgReq txMsg;
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo * txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(outTx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    auto ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    if(ret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        return;
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    auto msg = std::make_shared<TxMsgReq>(txMsg);
    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(outTx.identity() == defaultAddr)
    {
        ret = handleTransaction(msg,outTx);
    }
    else
    {
        ret = DropShippingTransaction(msg, outTx, outTx.identity());
    }

    if (ret != 0)
    {
        ret -= 100;
    }
    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());
}


void createMultiThreadAutoStakeTransaction()
{
    std::vector<std::string> addrs;

    MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(addrs);
    
    ca_algorithm::GetAllMappedAssets();
    std::string assetTypeOHI;
    std::cout << "Please enter the type of asset you want to currency type :" << std::endl;
    std::cin >> assetTypeOHI;
    for (int i = 0; i < addrs.size(); ++i)
    {
        std::thread th(test_create_stake, addrs[i],assetTypeOHI);
        th.detach();
    }
}

void testCreateDelegatingRequest(const std::string &strFromAddr, const std::string &strToAddr, const std::string &amountStr,const std::string & assetType)
{
    /////////////////////////////////////////

    std::string _isGastrade = "0";

    std::pair<std::string,std::string> gasTrade = {};
    if (CheckGasAssetsInput(_isGastrade,gasTrade) != 0)
    {
        return ;
    }

    std::string fromAddr = remove0xPrefix(strFromAddr);

    if (!isValidAddress(fromAddr))
    {
        ERRORLOG("Input addr error!");
        std::cout << "Input addr error!" << std::endl;
        return;
    }

    std::string toAddr = remove0xPrefix(strToAddr);
    if (!isValidAddress(toAddr))
    {
        ERRORLOG("Input addr error!");
        std::cout << "Input addr error!" << std::endl;
        return;
    }
    
    TxHelper::delegateType delegateType = TxHelper::delegateType::kdelegateType_NetLicence;
    uint64_t delegateAmount = std::stod(amountStr) * global::ca::kDecimalNum;

    
    std::string input = "";
    bool isFindUtxo = false;
    std::string txInfo = "";


    DBReader dbReader;
    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }

    CTransaction outTx;
    std::vector<TxHelper::Utxo> outVin;
    DelegatingTransParam param;
    param.from_addr = fromAddr;
    param.to_addr = toAddr;
    param.encoded_info = txInfo;
    param.gas_tray.addr = gasTrade.first;
    param.gas_tray.asset_type = gasTrade.second;
    param.delegatinged_amount = delegateAmount;
    param.delegate_type = delegateType;
    param.is_gas_tray = std::stoi(_isGastrade);
    param.asset_type = remove0xPrefix(assetType);
    param.is_find_utxo = isFindUtxo;

    DelegatingTrans delegating(param);
    auto ret = delegating.trans();
    if (!ret.isOk())
    {
        ERRORLOG("DelegatingTrans error {}", ret.error_message(true));
        std::cerr << ret.error_message() << std::endl;
        return ;
    };

    auto siret=delegating.signTx(param.from_addr);

    if(!siret.isOk()){
        ERRORLOG("sign delegating tx error {}", siret.error_message(true));
        std::cerr << siret.error_message() << std::endl;
        return ;
    }
    delegating.print_debug_tx();
    auto msgret = delegating.goMessage();


    if (!msgret.isOk())
    {
        ERRORLOG("goMessage delegating tx error {}", msgret.error_message(true));
        std::cerr << msgret.error_message() <<  std::endl;
        return ;
    }
}

void AutoDelegation()
{

    std::cout << "input aummot: ";
    std::string amount;
    std::cin >> amount;
    ca_algorithm::GetAllMappedAssets();
    std::string assetTypeOHI;
    std::cout << "Please enter the type of asset you want to currency type :" << std::endl;
    std::cin >> assetTypeOHI;

    std::vector<std::string> addrs;

    MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(addrs);

    int i = 0;
    while (i < addrs.size())
    {
        std::string from;
        std::string to;
        from = addrs[i];
        if ((i + 1) >= addrs.size())
        {
            i = 0;
        }
        else
        {
            i += 1;
        }

        to = addrs[i];

        if (from != "")
        {
            if (!MagicSingleton<AccountManager>::GetInstance()->IsExist(from))
            {
                DEBUGLOG("Illegal account.");
                return;
            }
        }
        else
        {
            DEBUGLOG("Illegal account. from addr is null !");
            return;
        }
        std::thread th(testCreateDelegatingRequest, from, to, amount,assetTypeOHI);
        th.detach();
        if (i == 0)
        {
            return;
        }
        sleep(1);
    }
}

void printAndVerifyNode()
{
    std::vector<Node> nodelist = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();

    std::vector<Node> resultNode;
    for (const auto &node : nodelist)
    {
        int ret = CheckNodeValidity(node.address);
        if(ret == 0){
            resultNode.push_back(node);
        }
    }

    std::string fileName = "verify_node.txt";
    std::ofstream filestream;
    filestream.open(fileName);
    if (!filestream)
    {
        std::cout << "Open file failed!" << std::endl;
        return;
    }

    filestream << "------------------------------------------------------------------------------------------------------------" << std::endl;
    for (auto &i : resultNode)
    {
        filestream
            << "  addr(" << addHexPrefix(i.address) << ")"
            << std::endl;
    }
    filestream << "------------------------------------------------------------------------------------------------------------" << std::endl;
    filestream << "PeerNode size is: " << resultNode.size() << std::endl;
}

void GetRewardAmount()
{
    int64_t startHeight = 0;
    int64_t endHeight = 0;
    std::string addr;
    std::cout << "Please input start height:";
    std::cin >> startHeight;
    std::cout << "Please input end height:";
    std::cin >> endHeight;
    if(endHeight < startHeight)
    {
        std::cout<< "input invalid" << std::endl;
        return ;
    } 
    std::cout << "Please input the address：";
    std::cin >> addr;
    if (addr.substr(0, 2) == "0x") 
    {
        addr = addr.substr(2);
    }
    
    if(!isValidAddress(addr))
    {
        std::cout<< "Input addr error!" <<std::endl;
        return ; 
    }
    DBReader dbReader;
 
    uint64_t txTotall = 0;
    uint64_t claimAmount=0;
    for(int64_t i = startHeight; i <= endHeight; ++i)
    {
        std::vector<std::string> block_hashs;
        if(DBStatus::DB_SUCCESS != dbReader.getBlockHashsByBlockHeight(i,block_hashs)) 
        {
            ERRORLOG("(GetTxHashByHeight) GETBlockHashsByBlockHeight  Failed!!");
            return;
        }
        std::vector<CBlock> blocks;
        for(auto &blockhash : block_hashs)
        {
            std::string blockstr;
            if(DBStatus::DB_SUCCESS !=   dbReader.getBlockByBlockHash(blockhash,blockstr)) 
            {
            ERRORLOG("(getBlockByBlockHash) getBlockByBlockHash Failed!!");
            return;
            }
            CBlock block;
            block.ParseFromString(blockstr);
            blocks.push_back(block);
        }
            std::sort(blocks.begin(),blocks.end(),[](CBlock &a,CBlock &b){
                return a.time()<b.time();
            });
             
                for(auto & block :blocks)
                {
                   time_t s =(time_t)(block.time()/1000000);
                   struct tm * gmDate;
                   gmDate = localtime(&s);
                   std::cout<< gmDate->tm_year + 1900 << "-" << gmDate->tm_mon + 1 << "-" << gmDate->tm_mday << " "  << gmDate->tm_hour << ":" << gmDate->tm_min << ":" << gmDate->tm_sec << "(" << time << ")"<< std::endl;
                    for(auto tx : block.txs())
                    {
                        if((global::ca::TxType)tx.type() == global::ca::TxType::BONUS )
                        {
                            std::map< std::string,uint64_t> kmap;
                            try 
                            {
                                nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                                nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                                claimAmount = txInfo["bonusAmount"].get<uint64_t>();
                            }
                            catch(...)
                            {
                                ERRORLOG(RED "JSON failed to parse data field!" RESET);
                                
                            } 
                            for(auto & utxo : tx.utxos())   
                            {                   
                                 for(const auto & owner : utxo.owner())
                                { 
                                    if(owner != addr)
                                    {
                                         for(auto &vout : utxo.vout())
                                        { 
                                            if(vout.addr() != owner && vout.addr() != "VirtualBurnGas")
                                            {
                                                kmap[vout.addr()]=vout.value();
                                                txTotall += vout.value();
                                            }
                                        }
                                    }
                                }
                            }
                            for(auto it = kmap.begin(); it != kmap.end();++it)
                            {
                                    std::cout << "reward addr:" << addHexPrefix(it->first) << "reward amount" << it->second <<std::endl;   
                            }
                            if(claimAmount!=0)
                            {
                                std::cout << "self node reward addr:" << addHexPrefix(addr) <<"self node reward amount:" << claimAmount-txTotall; 
                                std::cout << "total reward amount"<< claimAmount;
                            }
                        }
                    }
                }   
        }
}

void TestsHandleDelegating()
{
    std::cout << std::endl
              << std::endl;
    std::cout << "AddrList:" << std::endl;
    MagicSingleton<AccountManager>::GetInstance()->PrintAllAccount();

    Account account;
    MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(account);
    std::string strFromAddr = account.GetAddr();

    std::cout << "Please enter your addr:" << std::endl;
    std::cout << addHexPrefix(strFromAddr) << std::endl;
    if (!isValidAddress(strFromAddr))
    {
        ERRORLOG("Input addr error!");
        std::cout << "Input addr error!" << std::endl;
        return;
    }

    std::cout << "Please enter the addr you want to delegate to:" << std::endl;
    std::cout << addHexPrefix(strFromAddr) << std::endl;
    if (!isValidAddress(strFromAddr))
    {
        ERRORLOG("Input addr error!");
        std::cout << "Input addr error!" << std::endl;
        return;
    }
    ca_algorithm::GetAllMappedAssets();
    std::string assetTypeOHI;
    std::cout << "Please enter the type of asset you want to currency type :" << std::endl;
    std::cin >> assetTypeOHI;
    

    std::string strDelegatingFee = "700000";
    std::cout << "Please enter the amount to delegate:" << std::endl;
    std::cout << strDelegatingFee << std::endl;
    std::regex pattern("^\\d+(\\.\\d+)?$");
    if (!std::regex_match(strDelegatingFee, pattern))
    {
        ERRORLOG("Input delegating fee error!");
        std::cout << "Input delegate fee error!" << std::endl;
        return;
    }
    
    TxHelper::delegateType delegateType = TxHelper::delegateType::kdelegateType_NetLicence;
    uint64_t delegateAmount = std::stod(strDelegatingFee) * global::ca::kDecimalNum;

    DBReader dbReader;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return;
    }

    CTransaction outTx;
    std::vector<TxHelper::Utxo> outVin;
    TxHelper::vrfAgentType needAgent;
    std::pair<std::string,std::string> gasTrade = {};  
    std::string encodedInfo = "";
    int ret = TxHelper::CreateDelegatingTransaction(strFromAddr, assetTypeOHI, strFromAddr, delegateAmount, top + 1,  delegateType, outTx,
                                                        outVin, needAgent, gasTrade, 0, false, encodedInfo);
    if (ret != 0)
    {
        ERRORLOG("Failed to create Delegating transaction! The error code is:{}", ret);
        return;
    }

    TxMsgReq txMsg;
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(outTx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    if(ret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        return;
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    auto msg = std::make_shared<TxMsgReq>(txMsg);
    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(outTx.identity() == defaultAddr)
    {
        ret = handleTransaction(msg,outTx);
    }
    else
    {
        ret = DropShippingTransaction(msg, outTx, outTx.identity());
    }
    if (ret != 0)
    {
        ret -= 100;
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());
}



void TestHandleDelegatingMoreToOne(std::string strFromAddr, std::string strToAddr, std::string strDelegatingFee)
{
    TxHelper::delegateType delegateType = TxHelper::delegateType::kdelegateType_NetLicence;
    uint64_t delegateAmount = std::stod(strDelegatingFee) * global::ca::kDecimalNum;

    DBReader dbReader;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return;
    }

    CTransaction outTx;
    std::vector<TxHelper::Utxo> outVin;
    TxHelper::vrfAgentType needAgent;
    std::pair<std::string,std::string> gasTrade = {};  
    std::string encodedInfo = "";
    std::string assetTypeOHI;
    int ret = ca_algorithm::GetCanBeRevokeAssetType(assetTypeOHI);
    if (ret != 0)
    {
        ERRORLOG("Get Can BeRevoke AssetType fail!");
    }

    ret = TxHelper::CreateDelegatingTransaction(strFromAddr, assetTypeOHI, strToAddr, delegateAmount, top + 1,  delegateType, outTx, 
                                                        outVin, needAgent, gasTrade, 0, false, encodedInfo);
    if (ret != 0)
    {
        ERRORLOG("Failed to create Delegating transaction! The error code is:{}", ret);
        return;
    }

    TxMsgReq txMsg;
    txMsg.set_version(ohi::GetVersion());
    TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
    txMsgInfo->set_type(0);
    txMsgInfo->set_tx(outTx.SerializeAsString());
    txMsgInfo->set_nodeheight(top);

    uint64_t txUtxoLocalHeight;
    ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
    if(ret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        return;
    }

    txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

    auto msg = std::make_shared<TxMsgReq>(txMsg);
    std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
    if(outTx.identity() == defaultAddr)
    {
        ret = handleTransaction(msg,outTx);
    }
    else
    {
        ret = DropShippingTransaction(msg, outTx, outTx.identity());
    }
    if (ret != 0)
    {
        ret -= 100;
    }

    DEBUGLOG("Transaction result,ret:{}  txHash:{}", ret, outTx.hash());
}

void testManToOneDelegate()
{
    uint32_t num = 0;
    std::cout << "plase inter delegate num: " << std::endl;
    std::cin >> num; 

    std::vector<std::string> _list;
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(_list);

    if(num > _list.size())
    {
        std::cout << "error: Account num < " << num << std::endl;
        return;
    }   

    std::string strToAddr;
    std::cout << "Please enter the addr you want to delegate to:" << std::endl;
    std::cin >> strToAddr;
    if (strToAddr.substr(0, 2) == "0x") 
    {
        strToAddr = strToAddr.substr(2);
    }
    if (!isValidAddress(strToAddr))
    {
        ERRORLOG("Input addr error!");
        std::cout << "Input addr error!" << std::endl;
        return;
    }

    std::string strDelegatingFee;
    std::cout << "Please enter the amount to delegate:" << std::endl;
    std::cin >> strDelegatingFee;
    std::regex pattern("^\\d+(\\.\\d+)?$");
    if (!std::regex_match(strDelegatingFee, pattern))
    {
        ERRORLOG("Input delegating fee error!");
        std::cout << "Input delegate fee error!" << std::endl;
        return;
    }

    DBReadWriter dbReader;
    std::set<std::string> pledgeAddr;

    std::vector<std::string> stakeAddr;
    auto status = dbReader.getStakeAddr(stakeAddr);
    if (DBStatus::DB_SUCCESS != status && DBStatus::DB_NOT_FOUND != status)
    {
        std::cout << "getStakeAddr error" << std::endl;
        return;
    }

    for(const auto& addr : stakeAddr)
    {
        if(VerifyBonusAddr(addr))
        {
            continue;
        }
        pledgeAddr.insert(addr);
    }

    int successNum = 0;
    int testNum = 0;
    for(int i = 0; successNum != num; ++i)
    {
        std::string fromAddr;
        try
        {
            fromAddr = _list.at(i);
        }
        catch (const std::exception&)
        {
            break;
        }

        if (!isValidAddress(fromAddr))
        {
            ERRORLOG("fromAddr addr error!");
            std::cout << "fromAddr addr error! : " << addHexPrefix(fromAddr) << std::endl;
            continue;
        }

        auto it = pledgeAddr.find(fromAddr);
        if(it != pledgeAddr.end())
        {
            ++testNum;
            continue;
        }

        TestHandleDelegatingMoreToOne(fromAddr, strToAddr, strDelegatingFee);  
        ++successNum;
    }

    std::cout << "testNum: " << testNum << std::endl;
}

void OpenLog()
{
    Config::Log log = {};
    MagicSingleton<Config>::GetInstance()->GetLog(log);
    MagicSingleton<Log>::GetInstance()->LogInit(log.path,log.console,"debug");
}

void CloseLog()
{

    Config::Log log = {};
    MagicSingleton<Config>::GetInstance()->GetLog(log);
    MagicSingleton<Log>::GetInstance()->LogDeinit();
    std::string tmpString = "logs";
    if(std::filesystem::remove_all(tmpString))
    {
        std::cout<< "File deleted successfully" <<std::endl;
    }
    else
    {
        std::cout << "Failed to delete the file"<<std::endl;    
    }
}

void TestSign()
{
    Account account(true);
    std::string vinHashSerialized = Getsha256Hash("1231231asdfasdf");
	std::string signature;
	std::string pub;

    if(MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(account) == -1)
    {
        std::cout <<"get account error";
    }
	if (account.Sign(vinHashSerialized, signature) == true)
	{
		std::cout << "tx sign true !" << std::endl;
	}
    if(account.Verify(vinHashSerialized,signature) == true)
    {
        std::cout << "tx verify true" << std::endl;
    }
}

// void MultiTransaction()
// {
//     int addrCount = 0;

//     std::vector<TxHelper::TransTable> txAsset;
//     TxHelper::TransTable successfulTrade;
//     std::string type;
//     std::cout << "Please enter the type of asset you want to txAsset :" << std::endl;
//     std::cin >> type;
//     successfulTrade.asset_type = remove0xPrefix(type);

//     std::cout << "Number of initiator accounts:";
//     std::cin >> addrCount;

//     std::vector<std::string> fromAddr;
//     for (int i = 0; i < addrCount; ++i)
//     {
//         std::string addr;
//         std::cout << "Initiating account" << i + 1 << ": ";
//         std::cin >> addr;
//         addr = remove0xPrefix(addr);
//         successfulTrade.fromAddr.push_back(addr);
//     }

//     std::cout << "Number of receiver accounts:";
//     std::cin >> addrCount;

//     std::map<std::string, int64_t> toAddr;
//     for (int i = 0; i < addrCount; ++i)
//     {
//         std::string addr;
//         double amt = 0;
//         std::cout << "Receiving account" << i + 1 << ": ";
//         std::cin >> addr;
//         if (addr.substr(0, 2) == "0x")
//         {
//             addr = addr.substr(2);
//         }
//         std::cout << "amount : ";
//         std::cin >> amt;
//         successfulTrade.toAddrAmount.insert(make_pair(remove0xPrefix(addr), amt * global::ca::kDecimalNum));
//     }

//     txAsset.push_back(successfulTrade);

//     DBReader dbReader;
//     uint64_t top = 0;
//     if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
//     {
//         ERRORLOG("db get top failed!!");
//         return;
//     }

//     TxMsgReq txMsg;
//     TxHelper::vrfAgentType needAgent;
//     CTransaction outTx;
//     std::pair<std::string, std::string> gasTrade = {};
//     std::string encodedInfo = "";
//     int ret = TxHelper::createTransactionRequest(txAsset, gasTrade, 0, encodedInfo, top + 1, outTx, needAgent, false);
//     if (ret != 0)
//     {
//         ERRORLOG("createTransactionRequest error!!");
//         return;
//     }
//     uint64_t txUtxoHeight;
//     ret = TxHelper::get_tx_utxo_height(outTx, txUtxoHeight);

//     if (ret != 0)
//     {
//         ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
//         return;
//     }

//     txMsg.set_version(ohi::GetVersion());
//     TxMsgInfo *txMsgInfo = txMsg.mutable_txmsginfo();
//     txMsgInfo->set_type(0);
//     txMsgInfo->set_tx(outTx.SerializeAsString());
//     txMsgInfo->set_nodeheight(top);

//     uint64_t txUtxoLocalHeight;
//     ret = TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight);
//     if (ret != 0)
//     {
//         ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
//         return;
//     }

//     txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

//     auto msg = std::make_shared<TxMsgReq>(txMsg);

//     std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
//     if (outTx.identity() == defaultAddr)
//     {
//         ret = handleTransaction(msg, outTx);
//     }
//     else
//     {
//         ret = DropShippingTransaction(msg, outTx, outTx.identity());
//     }
//     DEBUGLOG("Transaction result, ret:{}  txHash: {}", ret, outTx.hash());
// }

void MultiTransaction()
{
    std::cout << "===== 批量交易功能 =====" << std::endl;
    
    // 1. 读取文件
    std::string filename = "multTx";
    
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cout << "文件 multTx 不存在，正在自动生成默认文件..." << std::endl;
        
        // 自动生成默认的 multTx 文件
        // 获取默认地址
        std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
        if (defaultAddr.empty()) {
            std::cout << "错误: 无法获取默认地址！" << std::endl;
            return;
        }
        
        // 获取资产类型
        DBReader db;
        std::vector<std::string> assetTypes;
        auto dbRet = db.getAssetType(assetTypes);
        if(dbRet != DBStatus::DB_SUCCESS) {
            ERRORLOG("GetCanBeRevokeAssetType getAssetType error, {}", dbRet);
            std::cout << "错误: 无法获取资产类型！" << std::endl;
            return;
        }
        
        if(assetTypes.empty()) {
            ERRORLOG("GetCanBeRevokeAssetType assetTypes is empty");
            std::cout << "错误: 资产类型列表为空！" << std::endl;
            return;
        }
        
        std::string assetType = assetTypes.at(0);
        int ret = ca_algorithm::AssetTypeIsOHI(assetType);
        if(ret != 0) {
            std::cout << "警告: 资产类型可能不是OHI类型，但将继续执行" << std::endl;
        }
        
        // 创建默认的 multTx 文件
        std::ofstream outFile(filename);
        if (!outFile.is_open()) {
            std::cout << "错误: 无法创建 multTx 文件！" << std::endl;
            return;
        }
        
        // 写入默认配置
        outFile << "sender:" << std::endl;
        outFile << defaultAddr << std::endl;
        outFile << std::endl;
        outFile << "receiver:" << std::endl;
        outFile << defaultAddr << " 100" << std::endl;
        outFile << std::endl;
        outFile << "assettype:" << std::endl;
        outFile << assetType << std::endl;
        outFile.close();
        
    }

    // 2. 解析文件内容
    std::string assetType;
    std::vector<std::string> senders;
    std::vector<std::pair<std::string, uint64_t>> receivers; // <地址, 金额>
    
    std::string line;
    bool isSenderSection = false;
    bool isReceiverSection = false;
    bool isAssetTypeSection = false;
    
    while (std::getline(file, line)) {
        // 去除首尾空格
        line.erase(0, line.find_first_not_of(" \t"));
        line.erase(line.find_last_not_of(" \t") + 1);
        
        if (line == "sender:") {
            isSenderSection = true;
            isReceiverSection = false;
            isAssetTypeSection = false;
            continue;
        }
        else if (line == "receiver:") {
            isSenderSection = false;
            isReceiverSection = true;
            isAssetTypeSection = false;
            continue;
        }
        else if (line == "assettype:") {
            isSenderSection = false;
            isReceiverSection = false;
            isAssetTypeSection = true;
            continue;
        }
        
        if (isSenderSection && !line.empty()) {
            senders.push_back(line);
        }
        else if (isReceiverSection && !line.empty()) {
            // 解析 receiver 地址和金额
            std::istringstream iss(line);
            std::string addr;
            uint64_t amount;
            if (iss >> addr >> amount) {
                receivers.emplace_back(addr, amount);
            }
        }
        else if (isAssetTypeSection && !line.empty()) {
            assetType = line;
            break; // 只读取第一个 assetType
        }
    }
    
    file.close();
    
    // 检查必要的参数
    if (assetType.empty()) {
        std::cout << "资产类型未指定！" << std::endl;
        return;
    }
    if (senders.empty()) {
        std::cout << "发送方地址未指定！" << std::endl;
        return;
    }
    if (receivers.empty()) {
        std::cout << "接收方地址未指定！" << std::endl;
        return;
    }


    // 这里需要判断一下他是否真的有超过times个资产类型可以花费
    TxHelper::TransTable successfulTrade;

    std::string type = remove0xPrefix(assetType);

    for (int i = 0; i < senders.size(); i++) {
      if (senders[0].substr(0, 2) == "0x") {
        senders[0] = senders[0].substr(2);
      }
      successfulTrade.fromAddr.push_back(remove0xPrefix(senders[0]));
    }
    successfulTrade.asset_type = type;
    
    std::vector<TxHelper::TransTable> txAsset;
    // 转账账户选择选项
    std::cout << "\n请选择转账模式: " << std::endl;
    std::cout << "1. 对节点账户进行转账" << std::endl;
    std::cout << "2. 对根目录账户进行转账" << std::endl;
    std::cout << "3. 对自定义账户进行转账" << std::endl;
    std::cout << "请输入选项: ";
    int accountMode;
    std::cin >> accountMode;
    
    switch (accountMode) {
    case 1: {
      std::vector<Node> nodeList =
          MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
      std::cout << "请输入统一转账金额" << std::endl;
      uint64_t amount;
      std::cin >> amount;
      for (int i = 0; i < nodeList.size(); i++) {
            std::string strToAddr = nodeList[i].address;
            if (strToAddr.substr(0, 2) == "0x")
            {
                strToAddr = strToAddr.substr(2);
            }
            if (strToAddr == remove0xPrefix(senders[0])) {
              continue;
            }
            std::string toAddr = remove0xPrefix(strToAddr);
            successfulTrade.toAddrAmount[toAddr] = (amount + global::ca::MIN_DOUBLE_CONSTANT_PRECISION) * global::ca::kDecimalNum;
        }
        break;
    }
    case 2: {
      std::vector<std::string> list;
      MagicSingleton<AccountManager>::GetInstance()->GetAccountList(list);
      std::cout << "请输入统一转账金额" << std::endl;
      uint64_t amount;
      std::cin >> amount;
      for (int i = 0; i < list.size(); i++) {
        std::string strToAddr = list[i];
        if (strToAddr.substr(0, 2) == "0x") {
            strToAddr = strToAddr.substr(2);
        }
        if (strToAddr == remove0xPrefix(senders[0])) {
          continue;
        }
        std::string toAddr = remove0xPrefix(strToAddr);
        successfulTrade.toAddrAmount[toAddr] =
            (amount + global::ca::MIN_DOUBLE_CONSTANT_PRECISION) *
            global::ca::kDecimalNum;
      }
        break;
        }
        case 3: {
            
        for(int i= 0;i<receivers.size();i++)
        {
            std::string strToAddr = receivers[i].first;
            if (strToAddr.substr(0, 2) == "0x")
            {
                strToAddr = strToAddr.substr(2);
            }

            uint64_t amount = receivers[i].second;
            std::string toAddr = remove0xPrefix(strToAddr);
            successfulTrade.toAddrAmount[toAddr] = (amount + global::ca::MIN_DOUBLE_CONSTANT_PRECISION) * global::ca::kDecimalNum;
        }
            break;
        }
        default: {
            // 默认使用第一个账户
            std::cout << "选项无效，即将返回" << std::endl;
            return;
            break;
        }
    }
    


    txAsset.push_back(successfulTrade);



    bool isFindUtxo = false;

    std::string txInfo = "";
    std::string encodedInfo = Base64Encode(txInfo);



    DBReader dbReader;

    uint64_t top = 0;
    int retNum = transactionDiscoveryHeight(top);
    if(retNum != 0){
        ERRORLOG("transactionDiscoveryHeight error {}", retNum);
        return;
    }


    TxHelper::TransTable trans_info;
    

    TransforerTransParam param;
    param.tx_asset = txAsset;
    param.gas_tray = {"", ""};
    param.encoded_info = encodedInfo;
    // param.height = top+1;
    param.is_find_utxo = false;
    param.is_gas_tray = false;
    
    TransforerTrans testTrans(param);


    auto ret = testTrans.trans();
    if (!ret.isOk())
    {
        ERRORLOG("TransforerTrans error {}", ret.error_message(true));
        std::cerr <<ret .error_message() << std::endl;
        return ;
    };

    auto siret=testTrans.signTx("");

    testTrans.print_debug_tx();

    if(!siret.isOk()){
        ERRORLOG("sign TransforerTrans tx error {}", siret.error_message(true));
        std::cerr << siret.error_message() << std::endl;
        return ;
    }

    auto msgret=testTrans.goMessage();

    if(!msgret.isOk()){
        ERRORLOG("goMessage stake tx error {}", msgret.error_message(true));
        
        std::cerr << msgret.error_message() << std::endl;
        return ;
    }
}

void GetAllTransactionRecordsOfTheAccount(const std::string& address){

    uint64_t top = 0;
    DBReader dbReader;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return;
    }

    struct info{
        std::map<std::string,uint64_t> assetType_Amount;
        std::map<std::string,uint64_t> TotalRevenue;
        std::map<std::string,uint64_t> TotalConsumption;

        std::vector<std::string> toaddrList;
        std::string time;
        std::string Fromaddr;
        std::string Toaddr;
        int txType;
        uint64_t BlockHeight;
        std::string BlockHash;
        std::string txHash;
        std::string CallType;
    };

    std::map<std::string,std::vector<info>> AvailableInfo;

    info tmpInit;
    tmpInit.assetType_Amount[""] = 0;
    tmpInit.toaddrList={};
    tmpInit.time = "";
    tmpInit.Fromaddr = "";
    tmpInit.txType = 0;    
    tmpInit.BlockHeight = 99999999;
    tmpInit.BlockHash = "";
    tmpInit.txHash = "";
    AvailableInfo[address].push_back(tmpInit);
    // std::map<std::string, TxHelper::ProposalInfo> availableAssetType_ProposalInfo;
    // ca_algorithm::fetchAvailableAssetType(availableAssetType_ProposalInfo);

    for (uint64_t i = 0; i <= top; ++i)
    {
        std::vector<std::string> blockHashs;
        if (dbReader.getBlockHashsByBlockHeight(i, blockHashs) != DBStatus::DB_SUCCESS) {
            continue;
        }

        if (blockHashs.empty()) {
            continue;
        }

        for (size_t j = 0; j < blockHashs.size(); ++j) {
            std::string strHeader;
            if (dbReader.getBlockByBlockHash(blockHashs[j], strHeader) != DBStatus::DB_SUCCESS) {
                continue;
            }
            CBlock block;
            if (!block.ParseFromString(strHeader)) {
                continue;
            }

            for(const auto& tx: block.txs())
            {
                for(const auto& utxo: tx.utxos())
                {
                    std::string assetType = utxo.assettype();
                    if(utxo.owner(0) == address)
                    {
                        //说明交易发起方为address
                        auto it = AvailableInfo.find(address);
                        if (it == AvailableInfo.end() || it->second.empty())
                        {
                            continue;
                        }

                        info* tmp = &it->second.back();
                        tmp->toaddrList.clear();
                        for(int i = 0; i < utxo.vout_size();++i)
                        {
                            CTxOutput txout = utxo.vout(i);
                            /*因为有解质押 解投资 解锁定 申领 这些当owner为交易发起方的时候
                              vout中会有给owner的资产，所以当addr！=owner的时候 是owner的花费；
                              当vout中addr==owner的时候 是owner的收入；
                            */
                            if(txout.addr() != address)
                            {
                                //总消耗
                                tmp->TotalConsumption[assetType] += txout.value();


                                tmp->assetType_Amount[assetType] -= txout.value();
                                tmp->toaddrList.push_back(txout.addr());
                            }
                            else
                            {
                                /*vout中owner剩余的资产也在其中  需要去除
                                  如果是解质押 解投资 解锁定 申领vout格式相同 中间的vout为给自己剩余的资产
                                  第一个vout为当初质押 投资 锁定 的资产
                                  最后一个为gas花费
                                  fund交易类型需要特殊判断
                                */
                                if((global::ca::TxType)tx.type() == global::ca::TxType::UNSTAKE
                                || (global::ca::TxType)tx.type() == global::ca::TxType::UNDELEGATE
                                || (global::ca::TxType)tx.type() == global::ca::TxType::UNLOCK
                                || (global::ca::TxType)tx.type() == global::ca::TxType::BONUS)
                                {
                                    //先把倒数第二个自己花费剩余的资产去除 其余是给自己的奖励
                                    if(i == utxo.vout_size() - 2 )
                                    {
                                        DEBUGLOG("nothing to do");
                                        //不处理
                                    }
                                    else
                                    {
                                        //真正给自己的奖励 或当初质押 锁定 投资 的资产
                                        tmp->assetType_Amount[assetType] += txout.value();

                                        //总收入
                                        tmp->TotalRevenue[assetType] += txout.value();
                                    }
                                }
                                else if((global::ca::TxType)tx.type() == global::ca::TxType::FUND)
                                {
                                    tmp->assetType_Amount[assetType] += txout.value();

                                    //总收入
                                    tmp->TotalRevenue[assetType] += txout.value();
                                }
                                else if((global::ca::TxType)tx.type() == global::ca::TxType::CALL)
                                {
                                    nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                                    nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();

                                    if (ca_algorithm::GetFlowTxType(txInfo) == ca_algorithm::FlowTxType::FlowInTx)
                                    {
                                        tmp->assetType_Amount[assetType] += txout.value();

                                        //总收入
                                        tmp->TotalRevenue[assetType] += txout.value();
                                    }
                                }
                            }
                        }

                        tmp->time = MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(tx.time());
                        tmp->Fromaddr = utxo.owner(0);
                        tmp->txType = (int)tx.type();    
                        tmp->BlockHeight = block.height();
                        tmp->BlockHash = block.hash();
                        tmp->txHash = tx.hash();
                        
                        try 
                        {
                            nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                            nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                            ca_algorithm::FlowTxType type = ca_algorithm::GetFlowTxType(txInfo);
                            if (type == ca_algorithm::FlowTxType::FlowInTx)
                            {
                                tmp->CallType = "FlowInTx";
                            }
                            else if (type == ca_algorithm::FlowTxType::FlowOutTx)
                            {
                                tmp->CallType = "FlowOutTx";
                            }
                            else
                            {
                                tmp->CallType = "";
                            }
                        }
                        catch (nlohmann::json::parse_error& e) 
                        {
                            ERRORLOG("Failed to parse transaction data: %s", e.what());
                            continue;
                        }

                        AvailableInfo[address].push_back(*tmp);

                    }
                    else
                    {
                        auto it = AvailableInfo.find(address);
                        if (it == AvailableInfo.end() || it->second.empty()) {
                            continue;
                        }

                        info* tmp = &it->second.back();
                        bool flag = false;
                        for(int i = 0; i < utxo.vout_size();++i){
                            CTxOutput txout = utxo.vout(i);

                            if(txout.addr() == address){
                                tmp->assetType_Amount[assetType] += txout.value();

                                //总收入
                                tmp->TotalRevenue[assetType] += txout.value();
                                flag = true;
                            }   
                        }

                        if(flag){
                            tmp->time = MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(tx.time());
                            tmp->Fromaddr = utxo.owner(0);
                            tmp->txType = (int)tx.type();
                            tmp->BlockHeight = block.height();
                            tmp->BlockHash = block.hash();
                            tmp->txHash = tx.hash();
                            AvailableInfo[address].push_back(*tmp); 
                        }
                    }
                }
            }
        }
    }

    auto txTypeName = [](int t) -> const char* {
            switch ((global::ca::TxType)t) {
                case global::ca::TxType::UNKNOWN: return "UNKNOWN";
                case global::ca::TxType::GENESIS: return "GENESIS";
                case global::ca::TxType::TX: return "TX";
                case global::ca::TxType::STAKE: return "STAKE";
                case global::ca::TxType::UNSTAKE: return "UNSTAKE";
                case global::ca::TxType::DELEGATE: return "DELEGATE";
                case global::ca::TxType::UNDELEGATE: return "UNDELEGATE";
                case global::ca::TxType::DECLARATION: return "DECLARATION";
                case global::ca::TxType::DEPLOY: return "DEPLOY";
                case global::ca::TxType::CALL: return "CALL";
                case global::ca::TxType::LOCK: return "LOCK";
                case global::ca::TxType::UNLOCK: return "UNLOCK";
                case global::ca::TxType::PROPOSAL: return "PROPOSAL";
                case global::ca::TxType::REVOKEPROPOSAL: return "REVOKEPROPOSAL";
                case global::ca::TxType::VOTE: return "VOTE";
                case global::ca::TxType::FUND: return "FUND";
                case global::ca::TxType::BONUS: return "BONUS";
                default: return "UNKNOWN";
            }
        };

    /* ---------- 将 AvailableInfo 中所有信息按清晰格式打印到文件 ---------- */
    {
        std::string filename = "transaction_records_" + address + ".txt";
        std::ofstream outFile(filename, std::ios::trunc);
        if (!outFile.is_open()) {
            ERRORLOG("Open file failed: {}", filename);
            return;
        }

        outFile << "============================================================\n"
                << "Transaction Records for Address: " << address << "\n"
                << "============================================================\n\n";

        auto it = AvailableInfo.find(address);
        if (it == AvailableInfo.end() || it->second.empty()) {
            outFile << "No transaction records found.\n";
            outFile.close();
            return;
        }

        int index = 1;
        for (const auto& rec : it->second) {
            outFile << "--------------------------------------------------------\n"
                    << "Record #" << index++ << "\n"
                    << "--------------------------------------------------------\n"
                    << "Time        : " << rec.time << "\n"
                    << "From Addr   : " << rec.Fromaddr << "\n"
                    << "To Addr     : ";
                    for (const auto& addr : rec.toaddrList)
                    outFile << addr << " ";
                    outFile << "\n"
                    << "Tx Type     : " << rec.txType << " (" << txTypeName(rec.txType) << ")\n"
                    << "Block Height: " << rec.BlockHeight << "\n"
                    << "Block Hash  : " << rec.BlockHash << "\n"
                    << "Tx Hash     : " << rec.txHash << "\n";

            if (!rec.assetType_Amount.empty()) {
                outFile << "Asset Changes:\n";
                for (const auto& [asset, amt] : rec.assetType_Amount)
                    outFile << "  " << asset << " : " << amt << "\n";
            } else {
                outFile << "Asset Changes: None\n";
            }

            if (!rec.TotalRevenue.empty()) {
                outFile << "Total Revenue:\n";
                for (const auto& [asset, amt] : rec.TotalRevenue)
                    outFile << "  " << asset << " : " << amt << "\n";
            } else {
                outFile << "Total Revenue: None\n";
            }

            if (!rec.TotalConsumption.empty()) {
                outFile << "Total Consumption:\n";
                for (const auto& [asset, amt] : rec.TotalConsumption)
                    outFile << "  " << asset << " : " << amt << "\n";
            } else {
                outFile << "Total Consumption: None\n";
            }
            outFile << "\n";
        }

        outFile << "========================  End  ===========================\n";
        outFile.close();
        std::cout << "Transaction records have been written to: " << filename << std::endl;
    }


    /* ---------- 余额前后对比（新增，不改原有代码） ---------- */
    {
        auto it = AvailableInfo.find(address);
        if (it == AvailableInfo.end() || it->second.empty()) return;

        /* 1. 按 txHash 聚合，每组只取第一条记录用于排序 */
        std::unordered_map<std::string, const info*> firstOfTx;
        for (const auto& rec : it->second) {
            if (rec.txHash.empty()) continue;
            if (firstOfTx.find(rec.txHash) == firstOfTx.end())
                firstOfTx[rec.txHash] = &rec;
        }
        std::vector<const info*> ordered;
        ordered.reserve(firstOfTx.size());
        for (auto& kv : firstOfTx) ordered.push_back(kv.second);
        std::sort(ordered.begin(), ordered.end(),
                [](const info* a, const info* b) {
                    if (a->BlockHeight != b->BlockHeight)
                        return a->BlockHeight < b->BlockHeight;
                    return a->time < b->time;
                });

        /* 2. 计算并输出余额变化 */
        std::string filename = "balance_change_by_tx_" + address + ".txt";
        std::ofstream outFile(filename, std::ios::trunc);
        if (!outFile.is_open()) { ERRORLOG("Open file failed: {}", filename); return; }

        outFile << "============================================================\n"
                << "Balance Change by Tx for Address: " << address << "\n"
                << "============================================================\n\n";

        std::map<std::string, int64_t> prev;          // 上一笔余额（按资产）
        int index = 1;
        for (const info* rec : ordered) {
            outFile << "Tx#" << index++ << "  " << rec->txHash << "\n"
                    << "Time        : " << rec->time << "\n"
                    << "Tx Type     : " << rec->txType << " (" << txTypeName(rec->txType) << ")\n"
                    << "Call Type   : " << rec->CallType << "\n"
                    << "Block Height: " << rec->BlockHeight << "\n"
                    << "Block Hash  : " << rec->BlockHash << "\n"
                    << "Tx Hash     : " << rec->txHash << "\n";
                    



            std::set<std::string> assets;
            for (const auto& kv : rec->assetType_Amount) assets.insert(kv.first);

            bool hasChange = false;
            for (const auto& asset : assets) {
                int64_t cur = 0;
                auto it = rec->assetType_Amount.find(asset);
                if (it != rec->assetType_Amount.end()) cur = it->second;

                int64_t old = prev.count(asset) ? prev[asset] : 0;
                int64_t delta = cur - old;          // 相对于上一笔的变动
                if (delta > 0) {
                    outFile << "  " << asset << " : +" << delta
                            << "  (余额 " << old << " -> " << cur << ")\n";
                } else if (delta < 0) {
                    outFile << "  " << asset << " : " << delta
                            << "  (余额 " << old << " -> " << cur << ")\n";
                } else {
                    outFile << "  " << asset << " : 0"
                            << "  (余额 " << old << " -> " << cur << ")\n";
                }
                prev[asset] = cur;                  // 更新上一笔余额
                hasChange = true;
            }
            if (!hasChange) outFile << "  无资产变动\n";
            outFile << "\n";
        }

        outFile << "========================  End  ===========================\n";
        outFile.close();
        std::cout << "Balance change by Tx has been written to: " << filename << std::endl;
    }
    
}


std::string ThreadTest::PrintDelegatingBlock(int num, bool preHashEnabled, int txTypeFilter, const nlohmann::json& customData) {
  DBReader dbRead;
  uint64_t top = 0;
  int retNum = transactionDiscoveryHeight(top);
  if (retNum != 0) {
    return "FAILED_TO_GET_HEIGHT";
  }
  
  std::stringstream stream;
  
  // 从当前高度开始，向前打印指定数量的区块
  uint64_t startHeight = top > num ? top - num : 0;
  
  // Markdown 文档头部
  stream << "# Delegating Block Report" << std::endl;
  stream << "\n";
  stream << "## Overview" << std::endl;
  stream << "- **Block Range**: " << startHeight << " to " << top << std::endl;
  stream << "- **Filtered Transaction Type**: " << txTypeFilter << std::endl;
  stream << "- **Report Generated**: " << MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now().time_since_epoch()).count()) << std::endl;
  
  // 自定义数据
  if (!customData.empty()) {
    stream << "\n";
    stream << "## Custom Data" << std::endl;
    stream << "| Key | Value |" << std::endl;
    stream << "|-----|-------|" << std::endl;
    for (auto& [key, value] : customData.items()) {
      stream << "| " << key << " | " << value.dump() << " |" << std::endl;
    }
  }
  
  stream << "\n";
  stream << "## Block Details" << std::endl;
  stream << "\n";
  
  for (uint64_t height = startHeight; height <= top; height++) {
    std::vector<std::string> blockHashList;
    if (DBStatus::DB_SUCCESS != dbRead.getBlockHashsByBlockHeight(height, blockHashList)) {
      continue;
    }

    for (auto &blockHash : blockHashList) {
      std::string blockData;
      if (DBStatus::DB_SUCCESS != dbRead.getBlockByBlockHash(blockHash, blockData)) {
        continue;
      }

      CBlock block;
      if (!block.ParseFromString(blockData)) {
        continue;
      }
      

      
      int txCount = 0;
      for (int i = 0; i < block.txs_size(); i++) {
        CTransaction tx = block.txs(i);
        
        // 根据传入的类型过滤交易
        if (txTypeFilter != -1 && tx.type() != (uint32_t)txTypeFilter) {
          continue;
        }
        // 区块信息
        stream << "### Block " << block.height() << std::endl;
        stream << "\n";
        stream << "| Field | Value |" << std::endl;
        stream << "|-------|-------|" << std::endl;
        stream << "| Height | " << block.height() << " |" << std::endl;
        stream << "| Hash | " << blockHash << " |" << std::endl;
        stream << "| Merkle Root | " << block.merkleroot() << " |" << std::endl;
        stream << "| Previous Hash | " << block.prevhash() << " |" << std::endl;
        stream << "| Time | " << block.time() << " |" << std::endl;
        stream << "| Transaction Count | " << block.txs_size() << " |"
               << std::endl;
        stream << "\n";



        txCount++;
        stream << "##### Transaction " << txCount << std::endl;
        stream << "\n";
        stream << "| Field | Value |" << std::endl;
        stream << "|-------|-------|" << std::endl;
        stream << "| Hash | " << tx.hash() << " |" << std::endl;
        stream << "| Type | " << tx.type() << " |" << std::endl;
        stream << "| Identity | " << tx.identity() << " |" << std::endl;
        stream << "\n";
        
        // 解析tx.data中的JSON内容
        stream << "###### Transaction Data" << std::endl;
        stream << "\n";
        try {
          nlohmann::json txData = nlohmann::json::parse(tx.data());
          stream << "| Key | Value |" << std::endl;
          stream << "|-----|-------|" << std::endl;
          
          // 遍历JSON对象的所有键值对
          for (auto& [key, value] : txData.items()) {
            stream << "| " << key << " | " << value.dump() << " |" << std::endl;
          }
        } catch (const nlohmann::json::parse_error& e) {
          stream << "*Failed to parse JSON: " << e.what() << "*" << std::endl;
          stream << "*Original data: " << tx.data() << "*" << std::endl;
        }
        stream << "\n";

        // 处理UTXO信息
        stream << "###### UTXOs" << std::endl;
        stream << "\n";
        int utxoIndex = 0;
        for (auto utxo : tx.utxos()) {
          utxoIndex++;
          stream << "##### UTXO " << utxoIndex << std::endl;
          stream << "\n";
          
          // 所有者信息
          stream << "**Owners:** " << std::endl;
          for (size_t addrIndex = 0; addrIndex < utxo.owner_size(); addrIndex++) {
            stream << "- " << utxo.owner(addrIndex) << std::endl;
          }
          stream << "\n";
          
          // 输出信息
          stream << "**Outputs:** " << std::endl;
          stream << "| Index | Value |" << std::endl;
          stream << "|-------|-------|" << std::endl;
          for (int j = 0; j < utxo.vout_size(); j++) {
            const CTxOutput &vout = utxo.vout(j);
            stream << "| " << j << " | " << vout.value() << " |" << std::endl;
          }
          stream << "\n";
        }
      }
      
      if (txCount == 0) {
      }
    }
  }
  
  // 文档尾部
  stream << "## End of Report" << std::endl;
  stream << "Generated on " << MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now().time_since_epoch()).count()) << std::endl;
  
  return stream.str();
}



// 申领交易统计函数
void GetBonusTransactionStatistics()
{
    std::cout << "========================================" << std::endl;
    std::cout << "Bonus Transaction Statistics" << std::endl;
    std::cout << "========================================" << std::endl;

    int64_t startHeight = 0;
    int64_t endHeight = 0;

    std::cout << "Please input start height: ";
    std::cin >> startHeight;
    std::cout << "Please input end height: ";
    std::cin >> endHeight;

    if(endHeight < startHeight)
    {
        std::cout << "Invalid input: end height must be >= start height" << std::endl;
        return;
    }

    DBReader dbReader;

    // 存储每笔申领交易的详细信息
    struct BonusTransactionDetail {
        std::string txHash;
        std::string initiator;  // 发起人
        uint64_t blockHeight;
        std::string blockHash;
        std::string time;
        std::string assetType;
        // std::map<std::string, uint64_t> recipients;  // 分红者及其获得的资产
        uint64_t totalAmount;  // 总申领金额
        std::pair<std::string,uint64_t> gasAmount;    // gas费用
    };

    std::vector<BonusTransactionDetail> allBonusTransactions;

    // 统计每个用户获得的总分红 (用户地址 -> (资产类型 -> 总金额))
    std::map<std::string, std::map<std::string, uint64_t>> userTotalBonus;

    // 统计所有用户的总分红 (资产类型 -> 总金额)
    std::map<std::string, uint64_t> globalTotalBonus;

    std::cout << "\nScanning blocks from height " << startHeight << " to " << endHeight << "..." << std::endl;

    int bonusTransactionCount = 0;

    // 遍历区块高度
    for(int64_t height = startHeight; height <= endHeight; ++height)
    {
        std::vector<std::string> blockHashes;
        if(DBStatus::DB_SUCCESS != dbReader.getBlockHashsByBlockHeight(height, blockHashes))
        {
            continue;
        }

        // 遍历该高度的所有区块
        for(const auto& blockHash : blockHashes)
        {
            std::string blockStr;
            if(DBStatus::DB_SUCCESS != dbReader.getBlockByBlockHash(blockHash, blockStr))
            {
                continue;
            }

            CBlock block;
            if(!block.ParseFromString(blockStr))
            {
                continue;
            }

            // 遍历区块中的所有交易
            for(const auto& tx : block.txs())
            {
                // 只处理申领交易
                if((global::ca::TxType)tx.type() != global::ca::TxType::BONUS)
                {
                    continue;
                }

                bonusTransactionCount++;

                BonusTransactionDetail detail;
                detail.txHash = tx.hash();
                detail.blockHeight = block.height();
                detail.blockHash = block.hash();
                detail.totalAmount = 0;
                detail.gasAmount ={global::ca::ASSET_TYPE_OHI,0};

                // 格式化时间
                time_t timestamp = (time_t)(tx.time() / 1000000);
                struct tm* timeInfo = localtime(&timestamp);
                char timeBuffer[80];
                strftime(timeBuffer, sizeof(timeBuffer), "%Y-%m-%d %H:%M:%S", timeInfo);
                detail.time = std::string(timeBuffer);

                // // 从交易数据中解析总申领金额
                // bool  isfirstChoose = false;
                try {
                    nlohmann::json dataJson = nlohmann::json::parse(tx.data());
                    nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                    detail.totalAmount = txInfo["bonusAmount"].get<uint64_t>();
                } catch(...) {
                    ERRORLOG("Failed to parse bonus transaction data");
                }

                // 遍历交易的UTXO
                for(const auto& utxo : tx.utxos())
                {
                    for(int i = 0; i < utxo.vout_size(); ++i){
                        auto vout = utxo.vout(i);
                        std::string addr = vout.addr();
                        uint64_t value = vout.value();

                        if(utxo.gas() == 1){
                            if(addr == global::ca::VIRTUAL_BURN_GAS_ADDR)
                            {
                                detail.gasAmount = {utxo.assettype(),value};
                                // continue;
                            }
                        }else{
                            detail.assetType =  utxo.assettype();
                            if(addr == global::ca::VIRTUAL_BURN_GAS_ADDR)
                            {
                                detail.gasAmount = {utxo.assettype(),value};
                                // continue;
                            }
                        }
                        // // if(utxo.gas() == 1){
                        // //     // 跳过虚拟燃烧地址（gas费用）
                        // //     if(addr == global::ca::VIRTUAL_BURN_GAS_ADDR)
                        // //     {
                        // //         detail.gasAmount = {utxo.assettype(),value};
                        // //     }
                        // //     break;
                        // // }else{
                        //     // 跳过虚拟燃烧地址（gas费用）
                        //     if(addr == global::ca::VIRTUAL_BURN_GAS_ADDR)
                        //     {
                        //         detail.gasAmount = {utxo.assettype(),value};
                        //         continue;
                        //     }
                            
                        //     detail.assetType = utxo.assettype();
                            
                        //     // }
                            
                    }
                    // 获取发起人（owner）
                    if(utxo.owner_size() > 0)
                    {
                        detail.initiator = utxo.owner(0);
                    }
                    globalTotalBonus[detail.assetType] += detail.totalAmount;
                }

                allBonusTransactions.push_back(detail);
            }
        }
    }

    std::cout << "\n========================================" << std::endl;
    std::cout << "Total Bonus Transactions Found: " << bonusTransactionCount << std::endl;
    std::cout << "========================================\n" << std::endl;

    // 显示每笔申领交易的详细信息
    int index = 1;
    for(const auto& detail : allBonusTransactions)
    {
        std::cout << "----------------------------------------" << std::endl;
        std::cout << "Bonus Transaction #" << index++ << std::endl;
        std::cout << "----------------------------------------" << std::endl;
        std::cout << "Tx Hash       : " << detail.txHash << std::endl;
        std::cout << "Block Height  : " << detail.blockHeight << std::endl;
        std::cout << "Block Hash    : " << detail.blockHash << std::endl;
        std::cout << "Time          : " << detail.time << std::endl;
        std::cout << "Initiator     : " << detail.initiator << std::endl;
        std::cout << "Asset Type    : " << detail.assetType << std::endl;
        std::cout << "Total Amount  : " << detail.totalAmount << std::endl;
        std::cout << "Gas assetType : " << detail.gasAmount.first <<  "      Gas Amount :"<< detail.gasAmount.second << std::endl;
        // std::cout << "\nRecipients and Amounts:" << std::endl;

        // for(const auto& [addr, amount] : detail.recipients)
        // {
        //     std::cout << "  " << addr << " : " << amount << std::endl;
        // }
        // std::cout << std::endl;
    }

    // // 显示每个用户的总分红统计
    // std::cout << "\n========================================" << std::endl;
    // std::cout << "User Total Bonus Summary" << std::endl;
    // std::cout << "========================================" << std::endl;

    // for(const auto& [user, assetMap] : userTotalBonus)
    // {
    //     std::cout << "\nUser: " << user << std::endl;
    //     for(const auto& [assetType, totalAmount] : assetMap)
    //     {
    //         std::cout << "  Asset Type: " << assetType << " | Total Bonus: " << totalAmount << std::endl;
    //     }
    // }

    // 显示全局总分红统计
    std::cout << "\n========================================" << std::endl;
    std::cout << "Global Total Bonus Summary" << std::endl;
    std::cout << "========================================" << std::endl;

    for(const auto& [assetType, totalAmount] : globalTotalBonus)
    {
        std::cout << "Asset Type: " << assetType << " | Total Bonus: " << totalAmount << std::endl;
    }

    std::cout << "\n========================================" << std::endl;
    std::cout << "Statistics Complete" << std::endl;
    std::cout << "========================================" << std::endl;
}

void exportAndTestContract(){
    // Part 1: Collect deploy contract data from DB (merged from printJson)
    std::vector<std::string> localAddress;
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(localAddress);

    jobs.clear();
    jobs_index = 0;
    errNodeIndex = 0;

    DBReader dbReader;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return;
    }

    int InitialHeight = 0;
    std::cout << "Please enter the initial height" << std::endl;
    std::cout << ">>>";
    std::cin >> InitialHeight;

    std::string arg;
    std::cout << "print arg :";
    std::cin >> arg;

    for(int i = InitialHeight; i <= top; ++i)
    {
        std::vector<std::string> hashes;
        if (DBStatus::DB_SUCCESS != dbReader.getBlockHashsByBlockHeight(i, hashes))
            continue;

        for(auto &hash : hashes)
        {
            std::string blockStr;
            if (DBStatus::DB_SUCCESS != dbReader.getBlockByBlockHash(hash, blockStr))
                continue;

            CBlock block;
            block.ParseFromString(blockStr);
            for(auto &ContractTx : block.txs())
            {
                if ((global::ca::TxType)ContractTx.type() != global::ca::TxType::DEPLOY)
                    continue;

                std::string fromAddr = ContractTx.utxos(0).owner(0);
                std::string contractAddress;
                try
                {
                    nlohmann::json dataJson = nlohmann::json::parse(ContractTx.data());
                    nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
                    contractAddress = txInfo[Evmone::contractRecipientKeyNameStr].get<std::string>();
                }
                catch (const std::exception& e)
                {
                    continue;
                }

                for(auto &item : localAddress)
                {
                    if (item == fromAddr)
                    {
                        contractJob job;
                        job.deployer = fromAddr;
                        job.contractAddresses = contractAddress;
                        job.arg = arg;
                        job.money = "0";
                        jobs.push_back(job);
                        break;
                    }
                }
            }
        }
    }

    if (jobs.empty())
    {
        std::cout << "No deploy contracts found from local accounts." << std::endl;
        return;
    }

    std::cout << "Found " << jobs.size() << " deploy contracts." << std::endl;

    // Part 2: Test contracts (merged from contact_thread_test)
    std::vector<std::string> acccountlist;
    MagicSingleton<AccountManager>::GetInstance()->GetAccountList(acccountlist);

    int time_s;
    std::cout << "time_s:";
    std::cin >> time_s;
    std::cout << "second:";
    long long _second;
    std::cin >> _second;
    std::cout << "hom much:";
    long long _much;
    std::cin >> _much;
    int oneSecond = 0;
    while(time_s)
    {
        oneSecond++;
        std::cout << "hhh h" << std::endl;
        jobs[jobs_index].fromAddr = acccountlist[errNodeIndex];
        test_pool.schedule(boost::bind(invokeContract, jobs[jobs_index]));
        std::thread th = std::thread(invokeContract, jobs[jobs_index]);
        th.detach();
        jobs_index = ++jobs_index % jobs.size();
        errNodeIndex = ++errNodeIndex % acccountlist.size();
        ::usleep(_second * 1000 * 1000 / _much);
        if(oneSecond == _much)
        {
            time_s--;
            oneSecond = 0;
        }
    }
}
