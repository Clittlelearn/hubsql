#ifndef OPENHIVE_CONTRACT_WAITING_STORE_H
#define OPENHIVE_CONTRACT_WAITING_STORE_H

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

#include "pb/ca_protomsg.pb.h"

namespace contract_waiting
{
struct Limits
{
    size_t max_batches_per_account = 16;
    size_t max_transactions = 4096;
    size_t max_bytes = 64U * 1024U * 1024U;
    uint64_t ttl_micros = 10ULL * 60ULL * 1000ULL * 1000ULL;
};

struct Record
{
    std::string id;
    ContractPackagerMsg message;
    std::vector<std::string> accounts;
    uint64_t created_at = 0;
    uint64_t expires_at = 0;
};

enum class EnqueueResult
{
    kOk,
    kAlreadyExists,
    kAccountCapacity,
    kGlobalTransactionCapacity,
    kGlobalByteCapacity,
    kStorageError,
    kInvalid,
};

class Store
{
public:
    EnqueueResult Enqueue(const Record& record, const Limits& limits);
    bool Load(std::vector<Record>& records) const;
    bool Remove(const std::string& id);
    bool PruneExpired(uint64_t now_micros, std::vector<std::string>* removed_ids = nullptr);
};
} // namespace contract_waiting
#endif
