/**
 * *****************************************************************************
 * @file        network_ca_impl.h
 * @brief       CA layer implementation of network interface (NET-017)
 * @date        2026-06-25
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef CA_NETWORK_CA_IMPL_H
#define CA_NETWORK_CA_IMPL_H

#include "net/ca_interface.h"

// Implementation of INetworkCAInterface for CA layer
class NetworkCAImpl : public INetworkCAInterface {
public:
    int GetCanBeRevokeAssetType(std::string& assetType) override;
    int getBonusAmount(const std::string& bonusAddr, uint64_t& delegateAmount) override;
    void RecordDisconnect(const std::string& addr) override;
};

#endif // CA_NETWORK_CA_IMPL_H
