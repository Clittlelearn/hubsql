#include "ca/pending_transaction_reservations.h"
#include <limits>

namespace pending_tx
{
std::string Reservations::UtxoKey(const std::string& asset_type, const std::string& hash, uint32_t index)
{
    return asset_type + "_" + hash + "_" + std::to_string(index);
}

ReserveResult Reservations::Reserve(const std::string& tx_hash, const std::string& address,
                                    uint64_t confirmed_nonce, const std::vector<std::string>& input_utxos,
                                    uint64_t* nonce_out)
{
    if (tx_hash.empty() || address.empty() || nonce_out == nullptr) return ReserveResult::kInvalidRequest;
    std::lock_guard<std::mutex> lock(mutex_);
    if (records_.count(tx_hash) != 0) return ReserveResult::kNonceConflict;
    std::set<std::string> unique_utxos;
    for (const auto& utxo : input_utxos) {
        if (utxo.empty() || !unique_utxos.insert(utxo).second || reserved_utxos_.count(utxo) != 0)
            return ReserveResult::kUtxoConflict;
    }
    auto& nonces = reserved_nonces_[address];
    uint64_t nonce = confirmed_nonce;
    while (nonces.count(nonce) != 0) {
        if (nonce == std::numeric_limits<uint64_t>::max()) return ReserveResult::kNonceConflict;
        ++nonce;
    }
    nonces.insert(nonce);
    for (const auto& utxo : input_utxos) reserved_utxos_[utxo] = tx_hash;
    records_.emplace(tx_hash, Record{address, nonce, input_utxos, {}});
    *nonce_out = nonce;
    return ReserveResult::kOk;
}

ReserveResult Reservations::ReserveExact(const std::string& reservation_id, const std::string& address,
                                         uint64_t nonce, const std::vector<std::string>& input_utxos,
                                         const std::string& commitment)
{
    if (reservation_id.empty() || address.empty()) return ReserveResult::kInvalidRequest;
    std::lock_guard<std::mutex> lock(mutex_);
    if (records_.count(reservation_id) != 0 || reserved_nonces_[address].count(nonce) != 0)
        return ReserveResult::kNonceConflict;
    std::set<std::string> unique_utxos;
    for (const auto& utxo : input_utxos) {
        if (utxo.empty() || !unique_utxos.insert(utxo).second || reserved_utxos_.count(utxo) != 0)
            return ReserveResult::kUtxoConflict;
    }
    reserved_nonces_[address].insert(nonce);
    for (const auto& utxo : input_utxos) reserved_utxos_[utxo] = reservation_id;
    records_.emplace(reservation_id, Record{address, nonce, input_utxos, commitment});
    return ReserveResult::kOk;
}

bool Reservations::SetCommitment(const std::string& reservation_id, const std::string& commitment)
{
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = records_.find(reservation_id);
    if (it == records_.end() || commitment.empty()) return false;
    it->second.commitment = commitment;
    return true;
}

ReserveResult Reservations::ReserveOrAdoptExact(const std::string& transaction_id, const std::string& address,
                                                uint64_t nonce, const std::vector<std::string>& input_utxos,
                                                const std::string& commitment, std::string* adopted_id)
{
    if (transaction_id.empty() || address.empty()) return ReserveResult::kInvalidRequest;
    std::lock_guard<std::mutex> lock(mutex_);
    const std::set<std::string> requested_utxos(input_utxos.begin(), input_utxos.end());
    if (requested_utxos.size() != input_utxos.size()) return ReserveResult::kUtxoConflict;
    const auto same_id = records_.find(transaction_id);
    if (same_id != records_.end()) {
        const std::set<std::string> existing_utxos(same_id->second.utxos.begin(), same_id->second.utxos.end());
        if (same_id->second.address != address || same_id->second.nonce != nonce ||
            existing_utxos != requested_utxos || same_id->second.commitment.empty() ||
            same_id->second.commitment != commitment) return ReserveResult::kNonceConflict;
        if (adopted_id != nullptr) adopted_id->clear();
        return ReserveResult::kOk;
    }
    for (auto it = records_.begin(); it != records_.end(); ++it) {
        if (it->second.address != address || it->second.nonce != nonce) continue;
        const std::set<std::string> existing_utxos(it->second.utxos.begin(), it->second.utxos.end());
        if (existing_utxos != requested_utxos || it->second.commitment.empty() ||
            it->second.commitment != commitment) return ReserveResult::kNonceConflict;
        const std::string old_id = it->first;
        Record record = it->second;
        records_.erase(it);
        records_.emplace(transaction_id, std::move(record));
        for (const auto& utxo : input_utxos) reserved_utxos_[utxo] = transaction_id;
        if (adopted_id != nullptr) *adopted_id = old_id;
        return ReserveResult::kOk;
    }
    if (reserved_nonces_[address].count(nonce) != 0) return ReserveResult::kNonceConflict;
    for (const auto& utxo : input_utxos)
        if (utxo.empty() || reserved_utxos_.count(utxo) != 0) return ReserveResult::kUtxoConflict;
    reserved_nonces_[address].insert(nonce);
    for (const auto& utxo : input_utxos) reserved_utxos_[utxo] = transaction_id;
    records_.emplace(transaction_id, Record{address, nonce, input_utxos, commitment});
    return ReserveResult::kOk;
}

bool Reservations::Release(const std::string& tx_hash)
{
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = records_.find(tx_hash);
    if (it == records_.end()) return false;
    reserved_nonces_[it->second.address].erase(it->second.nonce);
    for (const auto& utxo : it->second.utxos) reserved_utxos_.erase(utxo);
    records_.erase(it);
    return true;
}

bool Reservations::Confirm(const std::string& tx_hash) { return Release(tx_hash); }

uint64_t Reservations::PendingNonce(const std::string& address, uint64_t confirmed_nonce) const
{
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = reserved_nonces_.find(address);
    if (it == reserved_nonces_.end()) return confirmed_nonce;
    uint64_t nonce = confirmed_nonce;
    while (it->second.count(nonce) != 0) {
        if (nonce == std::numeric_limits<uint64_t>::max()) return nonce;
        ++nonce;
    }
    return nonce;
}

std::set<std::string> Reservations::ReservedUtxos(const std::vector<std::string>& candidates) const
{
    std::set<std::string> reserved;
    std::lock_guard<std::mutex> lock(mutex_);
    for (const auto& candidate : candidates)
        if (!candidate.empty() && reserved_utxos_.count(candidate) != 0) reserved.insert(candidate);
    return reserved;
}
} // namespace pending_tx
