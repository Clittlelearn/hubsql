#ifndef _VRF_CONSENSUS_H_
#define _VRF_CONSENSUS_H_

#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <mutex>
#include <shared_mutex>
#include <chrono>
#include <map>
#include <set>
#include <memory>

#include "pb/ca_protomsg.pb.h"
#include "net/msg_queue.h"

const int CYCLE_DURATION_SECONDS = 15;
#define MAX_VRFS_SIZE 10

struct VRFSummary {
    std::string seed;
    std::vector<std::string> received_node_ids;
    std::string signature;
    std::string pub_key;
};
class VRFStructure {
public:
    VRFStructure() = default;
    VRFStructure(const std::string& seed, const std::string& signature, const std::string& nodeId);

    std::string getAddress() const;
    std::string getSignature() const;
    std::string getSignatureHash() const;
    std::string getSeed() const;
    double getFrequency() const;
    std::map<uint64_t, std::vector<std::string>> calculateHeightHashes() const;

    void addHashForHeight(uint64_t height, const std::string& hash);
    void addFrequency(const double frequency);
private:
    std::string seed;
    std::string signature;
    std::string nodeId;
    std::string signatureHash;
    double frequency;

    std::map<uint64_t, std::vector<std::string>> height_hashes;

};

class VRFConsensusNode {
public:
    void Process();
    int sign(const std::string& data, std::string& signature, std::string& pub);
    int generateVRFStructure(const std::string& seed, VRFConsensusInfo& vrf);
    void vrfBroadcastMessage(const VRFConsensusInfo& vrf);
    void receiveVRRequest(const VRFConsensusInfo& vrf);
    void run();
    bool extractVRFData(std::map<std::string, VRFStructure>& dataSource, uint64_t timestamp);
    bool extractPackagerVRFData(std::vector<std::string>& nodes, uint64_t timestamp);
    double calculateStakeProbability(const std::string& nodeId) const;
    double computeVRFThreshold(const std::map<std::string, VRFStructure>& dataSource) const;
    bool checkVRFExists(const std::string& seed, const std::string& nodeId) const;
    bool addVRFStructure(const VRFConsensusInfo& vrfInfo, const std::string& nodeId);

    
    void computeMaxHeightWithMinFrequency(const std::string& seed = "") ;

    std::string printfValidatedVRfs();
    std::string printfNewValidatedVRfs();

    void generateVRFSummary(const std::string& seed);
    void broadcastVRFSummary(const VRFSummary& summary);
    void handleVRFSummaryMsg(const VRFSummaryMsg& msg, const std::string& fromNodeId);
    void computeConsensusSet(const std::string& seed, std::vector<std::string>& consensusSet);
    int computeDynamicThreshold(int n) const;
    void resolveBoundaryEntries(const std::string& seed, int threshold,
                                std::map<std::string, int>& addrCounts,
                                std::vector<std::string>& consensusSet);
private:
    int computeDynamicThresholdInternal(int n) const;
    void computeConsensusSetInternal(const std::string& seed, std::vector<std::string>& consensusSet);
    void computeConsensusSetWithLevel(const std::string& seed, int degradeLevel, std::vector<std::string>& consensusSet);
    void resolveBoundaryEntriesInternal(const std::string& seed, int threshold,
                                        const std::map<std::string, int>& addrCounts,
                                        std::vector<std::string>& consensusSet);
    int computeDegradeLevel(uint64_t timestamp) const;
    bool isPartitioned(const std::string& seed) const;

    void pruneOldData();
    void pruneSummaryData();
    std::string generateVRSeed(std::chrono::system_clock::time_point time) const;
    std::chrono::system_clock::time_point cycleStartTimestamp(std::chrono::system_clock::time_point current_time) const;
    std::chrono::system_clock::time_point getPreviousCycleTime(uint64_t timestamp) const;
    bool validate_block_info(const VRFConsensusInfo& vrfInfo, const std::string& nodeId) const;

    std::map<std::string, std::map<std::string, VRFStructure>> validatedVRfs;
    std::map<std::string, std::map<std::string, VRFStructure>> newValidatedVRfs;
    std::map<std::string, std::map<std::string, VRFSummary>> validatedSummaries;
    std::set<std::string> clockSkewNodes_;
    mutable int currentTier_ = -1;
    std::chrono::system_clock::time_point nodeStartTime_;
    mutable std::shared_mutex mutex_;
    std::thread VRFConsensusThread;
};

int HandleVRFConsensusInfoReq(const std::shared_ptr<VRFConsensusInfo>& msg, const MsgData& msgData);
int HandleVRFSummaryMsgReq(const std::shared_ptr<VRFSummaryMsg>& msg, const MsgData& msgData);

#endif // _VRF_CONSENSUS_H_