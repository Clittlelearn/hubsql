#include <iostream>
#include <vector>
#include <iomanip>
#include <stdexcept>
#include <cmath>
#include <string>

#include "logging.h"
#include "global.h"

// EIP-1559 Gas费计算器
// 使用 int64_t 定点数（毫单位，×1000），确保跨平台确定性
// 3位小数精度：1.0 = 1000 milli-fee

class EIP1559FeeCalculator {
public:
    // 精度常量
    static constexpr int64_t FEE_SCALE = 1000;  // 毫单位倍率
    static constexpr int64_t MAX_FEE_MILLI = static_cast<int64_t>(global::ca::KTargetGasPrice) * 2 * FEE_SCALE; // 120,000,000

    // 字符串转毫单位（支持 "10.5" → 10500）
    // 使用纯整数运算，避免 std::stod 的浮点精度风险
    static int64_t feeFromString(const std::string& fee_str) {
        size_t decimal_pos = fee_str.find('.');
        if (decimal_pos == std::string::npos) {
            // 整数: "10" → 10000
            return std::stoll(fee_str) * FEE_SCALE;
        }
        
        // 带小数: "10.5" → 10500
        std::string int_part_str = fee_str.substr(0, decimal_pos);
        std::string frac_part_str = fee_str.substr(decimal_pos + 1);
        
        // 处理负数
        bool is_negative = false;
        if (!int_part_str.empty() && int_part_str[0] == '-') {
            is_negative = true;
            int_part_str.erase(0, 1);
        }
        
        // 补齐或截断到3位小数
        if (frac_part_str.length() < 3) {
            frac_part_str.append(3 - frac_part_str.length(), '0');
        } else if (frac_part_str.length() > 3) {
            frac_part_str = frac_part_str.substr(0, 3);
        }
        
        int64_t int_value = std::stoll(int_part_str);
        int64_t frac_value = std::stoll(frac_part_str);
        
        int64_t result = int_value * FEE_SCALE + frac_value;
        return is_negative ? -result : result;
    }

    // 毫单位转字符串（10500 → "10.5"）
    // 使用纯整数运算，避免 double 除法精度损失
    static std::string feeToString(int64_t fee_milli) {
        bool is_negative = false;
        if (fee_milli < 0) {
            is_negative = true;
            fee_milli = -fee_milli;
        }
        
        int64_t int_part = fee_milli / FEE_SCALE;
        int64_t frac_part = fee_milli % FEE_SCALE;
        
        if (frac_part == 0) {
            return is_negative ? "-" + std::to_string(int_part) : std::to_string(int_part);
        }
        
        // 格式化小数部分，补齐到3位
        std::string frac_str = std::to_string(frac_part);
        while (frac_str.length() < 3) {
            frac_str.insert(0, "0");
        }
        
        // 去除末尾零
        while (frac_str.length() > 0 && frac_str.back() == '0') {
            frac_str.pop_back();
        }
        
        std::string result = std::to_string(int_part) + "." + frac_str;
        return is_negative ? "-" + result : result;
    }

    // 计算新的基础费用 - 增长时向上取整，降低时向下取整
    // 参数单位为毫（milli-fee），返回值为毫
    static int64_t calculateNewFee(int64_t old_fee_milli, int64_t actual_gas, int64_t target_gas) {

        DEBUGLOG("old_fee_milli : {}, actual_gas : {}, target_gas: {}", old_fee_milli, actual_gas, target_gas);

        // 参数验证
        if (old_fee_milli < 0) {
            throw std::invalid_argument("old_fee_milli must be non-negative");
        }
        if (actual_gas < 0) {
            throw std::invalid_argument("actual_gas must be non-negative");
        }
        if (target_gas <= 0) {
            throw std::invalid_argument("target_gas must be positive");
        }

        // 计算公式（全部使用整数运算）
        // adjustment_milli = (actual_gas - target_gas) * 1000 / (target_gas * 8)
        int64_t adjustment_milli = (actual_gas - target_gas) * FEE_SCALE / (target_gas * 8);

        // new_fee_exact_milli = old_fee_milli * (1000 + adjustment_milli) / 1000
        int64_t new_fee_exact_milli = old_fee_milli * (FEE_SCALE + adjustment_milli) / FEE_SCALE;

        DEBUGLOG("new_fee_exact_milli : {}", new_fee_exact_milli);

        // 增长时向上取整到整千，降低时向下取整到整千
        int64_t new_fee_milli;
        if (actual_gas > target_gas) {
            // 增长时向上取整：(x + 999) / 1000 * 1000
            new_fee_milli = ((new_fee_exact_milli + FEE_SCALE - 1) / FEE_SCALE) * FEE_SCALE;
        } else if (actual_gas < target_gas) {
            // 降低时向下取整：x / 1000 * 1000
            new_fee_milli = (new_fee_exact_milli / FEE_SCALE) * FEE_SCALE;
        } else {
            // 相等时保持不变
            new_fee_milli = new_fee_exact_milli;
        }
        DEBUGLOG("new_fee_milli : {}", new_fee_milli);

        // 确保费用非负且不超过上界
        new_fee_milli = std::max(new_fee_milli, (int64_t)0);
        new_fee_milli = std::min(new_fee_milli, MAX_FEE_MILLI);

        return new_fee_milli;
    }

    // 模拟多轮费用变化
    static std::vector<int64_t> simulateFeeChanges(int64_t initial_fee_milli,
                                                   int64_t actual_gas,
                                                   int64_t target_gas,
                                                   int rounds) {
        if (rounds < 0) {
            throw std::invalid_argument("rounds must be non-negative");
        }

        std::vector<int64_t> fees;
        int64_t current_fee_milli = initial_fee_milli;

        for (int i = 0; i <= rounds; i++) {
            fees.push_back(current_fee_milli);
            if (i < rounds) { // 最后一轮不需要再计算
                current_fee_milli = calculateNewFee(current_fee_milli, actual_gas, target_gas);
            }
        }

        return fees;
    }
};

// 打印费用变化表格
inline void printFeeTable(const std::vector<int64_t>& fees, const std::string& phase_name) {
    std::cout << "\n=== " << phase_name << " ===" << std::endl;
    std::cout << std::setw(6) << "Round" << std::setw(14) << "Fee" << std::setw(15) << "Change %" << std::endl;
    std::cout << std::string(35, '-') << std::endl;

    for (size_t i = 0; i < fees.size(); i++) {
        double change_percent = 0.0;
        if (i > 0 && fees[i-1] != 0) {
            change_percent = ((static_cast<double>(fees[i]) - static_cast<double>(fees[i-1])) / static_cast<double>(fees[i-1])) * 100.0;
        }

        double fee_display = static_cast<double>(fees[i]) / EIP1559FeeCalculator::FEE_SCALE;
        std::cout << std::setw(6) << i
                  << std::setw(14) << std::fixed << std::setprecision(4) << fee_display
                  << std::setw(14) << std::setprecision(2) << change_percent << "%" << std::endl;
    }
}

inline void testFormula() {
    try {
        using F = EIP1559FeeCalculator;

        // 测试参数
        const int64_t initial_fee_milli = 100 * F::FEE_SCALE;  // 100.0
        const int64_t target_gas = 500000;
        const int rounds = 10;

        std::cout << "EIP-1559 Fee Adjustment Simulation (Integer Fixed-Point)" << std::endl;
        std::cout << "Initial Fee: " << initial_fee_milli / F::FEE_SCALE << std::endl;
        std::cout << "Target Gas: " << target_gas << std::endl;
        std::cout << "Rounds: " << rounds << std::endl;
        std::cout << "Rounding: CEIL when growing, FLOOR when reducing" << std::endl;

        // 第一阶段：增长（网络拥堵）
        int64_t congestion_gas = 1000000; // actual_gas > target_gas
        auto growth_fees = F::simulateFeeChanges(
            initial_fee_milli, congestion_gas, target_gas, rounds);
        printFeeTable(growth_fees, "GROWTH PHASE (Congestion) - CEIL");

        // 第二阶段：降低（网络空闲）
        int64_t idle_gas = 250000; // actual_gas < target_gas
        int64_t fee_after_growth_milli = growth_fees.back();
        auto reduction_fees = F::simulateFeeChanges(
            fee_after_growth_milli, idle_gas, target_gas, rounds);
        printFeeTable(reduction_fees, "REDUCTION PHASE (Idle) - FLOOR");

        // 总结
        std::cout << "\n=== SUMMARY ===" << std::endl;
        std::cout << "Initial Fee: " << static_cast<double>(initial_fee_milli) / F::FEE_SCALE << std::endl;
        std::cout << "Fee after " << rounds << " growth rounds: "
                  << std::fixed << std::setprecision(4) << static_cast<double>(growth_fees.back()) / F::FEE_SCALE << std::endl;
        std::cout << "Fee after " << rounds << " reduction rounds: "
                  << std::fixed << std::setprecision(4) << static_cast<double>(reduction_fees.back()) / F::FEE_SCALE << std::endl;

        double total_change_percent = ((static_cast<double>(reduction_fees.back()) - static_cast<double>(initial_fee_milli)) / static_cast<double>(initial_fee_milli)) * 100.0;
        std::cout << "Net change after full cycle: "
                  << std::fixed << std::setprecision(2) << total_change_percent << "%" << std::endl;

        // 测试边界条件
        std::cout << "\n=== BOUNDARY TESTS ===" << std::endl;

        // 测试1: actual_gas = target_gas (费用应该不变)
        int64_t test1 = F::calculateNewFee(100 * F::FEE_SCALE, target_gas, target_gas);
        std::cout << "Test 1 (actual_gas = target_gas): " << static_cast<double>(test1) / F::FEE_SCALE << " (expected: 100.0)" << std::endl;

        // 测试2: actual_gas = 0 (最大降幅，向下取整)
        int64_t test2 = F::calculateNewFee(100 * F::FEE_SCALE, 0, target_gas);
        std::cout << "Test 2 (actual_gas = 0): " << static_cast<double>(test2) / F::FEE_SCALE << " (expected: 87.0 - floored from 87.5)" << std::endl;

        // 测试3: 费用不会变成负数
        int64_t test3 = F::calculateNewFee(0, congestion_gas, target_gas);
        std::cout << "Test 3 (old_fee = 0): " << static_cast<double>(test3) / F::FEE_SCALE << " (expected: 0.0)" << std::endl;

        // 测试4: 增长时向上取整
        int64_t test4 = F::calculateNewFee(100 * F::FEE_SCALE, 600000, target_gas);
        std::cout << "Test 4 (growth with ceil): " << static_cast<double>(test4) / F::FEE_SCALE << " (expected: 103.0 - ceiled from 102.5)" << std::endl;

        // 测试5: 上界限制
        int64_t test5 = F::calculateNewFee(F::MAX_FEE_MILLI, 1200000, target_gas);
        std::cout << "Test 5 (upper bound): " << static_cast<double>(test5) / F::FEE_SCALE << " (expected: " << static_cast<double>(F::MAX_FEE_MILLI) / F::FEE_SCALE << " - capped)" << std::endl;

        // 测试6: feeFromString / feeToString 往返
        std::string s1 = "10.5";
        int64_t m1 = F::feeFromString(s1);
        std::string s2 = F::feeToString(m1);
        std::cout << "Test 6 (string roundtrip): \"" << s1 << "\" -> " << m1 << " -> \"" << s2 << "\" (expected: 10500, \"10.5\")" << std::endl;

        // 测试7: 边界值测试
        int64_t test7a = F::feeFromString("0");
        std::cout << "Test 7a (feeFromString \"0\"): " << test7a << " (expected: 0)" << std::endl;
        
        int64_t test7b = F::feeFromString("120000");
        std::cout << "Test 7b (feeFromString \"120000\"): " << test7b << " (expected: 120000000)" << std::endl;
        
        std::string test7c = F::feeToString(F::MAX_FEE_MILLI);
        std::cout << "Test 7c (feeToString MAX): \"" << test7c << "\" (expected: \"120000\")" << std::endl;

    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }
}
