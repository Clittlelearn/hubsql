﻿#ifndef ADDRESS_STATUS_CACHE_H
#define ADDRESS_STATUS_CACHE_H
#include <string>
#include <cstdint>
#include <shared_mutex>
#include <map>
#include <set>

namespace ohi { namespace utils{

    class InvestedEntityInfo
    {
        public:
            std::string asset;
            uint64_t time;
            uint64_t amount;
            std::string hash;

            auto operator <=> (const InvestedEntityInfo&) const = default;
    };

    // 被投资实体（被哪些账号投资）
    class InvestedEntity
    {
        public:
            std::string addr;
            std::set<InvestedEntityInfo> info;

            auto operator <=> (const InvestedEntity&) const = default;
    };


    class InvestorPortfolioInfo
    {
        public:
            std::string asset;
            uint64_t time;
            uint64_t amount;
            std::string hash;

            auto operator <=> (const InvestorPortfolioInfo&) const = default;
    };


    // 投资者组合（我投了哪些账号）
    class InvestorPortfolio
    {
        public:
            std::string addr;
            std::set<InvestorPortfolioInfo> info;

            auto operator <=> (const InvestorPortfolio&) const = default;
    };


    class StakeInfo
    {
        public:
            uint64_t amount{0}; //  质押量
            uint64_t time{0}; // 质押时间
            std::string hash; // 质押哈希
    };

    class LockInfo
    {
        public:
            uint64_t amount{0}; //  锁定量
            uint64_t time{0}; // 锁定时间
            std::string hash; // 锁定哈希
    };

    class AddressStatus
    {
        public:
            enum class StatusType : int
            {
                IsBonusClaimed = 0, // 当前是否可以进行申领
                IsDelegated = 1,    // 是否投资别人
                IsLocked = 2,       // 是否锁定
                IsQualified = 3,    // 是否成为资格节点
                CanReward = 4,      // 是否有资格领取（当前时间）
                IsStaked = 5        // 是否质押
            };




            class Status 
            {
                private:
                    int64_t status; 

                public:
                    Status() : status(0) {}

                    void setStatus(StatusType type, bool value) 
                    {
                        int index = static_cast<int>(type);
                        if (value) 
                        {
                            status |= (1ULL << index); // true
                        }
                        else
                        {
                            status &= ~(1ULL << index); // false
                        }
                    }

                    bool getStatus(StatusType type) const 
                    {
                        int index = static_cast<int>(type);
                        if (index < 0 || index >= 64) 
                        {
                            return false;
                        }
                        return (status & (1ULL << index)) != 0; // true or false
                    }

                    void toggleStatus(StatusType type) 
                    {
                        int index = static_cast<int>(type);
                        if (index < 0 || index >= 64) 
                        {
                            return;
                        }
                        status ^= (1ULL << index); // toggle 
                    }
                };
        public:
            bool is_expired{true};

            std::string address; // 地址
            StakeInfo stake_info;
            LockInfo lock_info;
            
            // 被某个地址投资以及时间，金额，hash等信息
            std::set<InvestedEntity> invested_entity;
            // 投资给某个地址以及时间，金额，hash等信息
            std::set<InvestorPortfolio> investor_portfolio;

            // Status checkAddrStatus() const;
            Status status;

        public:
            
    };


    class AddressStatusCache
    {
        public:
            int getAddressStatus(const std::string & addr, AddressStatus & address_status);
            int markExpired(const std::string & addr);

        public:
            bool isBonusClaimed(const std::string & addr)  { 
                AddressStatus st;
                getAddressStatus(addr, st);
                return st.status.getStatus(AddressStatus::StatusType::IsBonusClaimed); 
            }
            bool isDelegated(const std::string & addr)  { 
                AddressStatus st;
                getAddressStatus(addr, st);
                return st.status.getStatus(AddressStatus::StatusType::IsDelegated); 
            }
            bool isLocked(const std::string & addr)  { 
                AddressStatus st;
                getAddressStatus(addr, st);     
                return st.status.getStatus(AddressStatus::StatusType::IsLocked); 
            }
            bool isQualified(const std::string & addr)  {
                AddressStatus st;
                getAddressStatus(addr, st);     
                return st.status.getStatus(AddressStatus::StatusType::IsQualified); 
            }
            bool canReward(const std::string & addr)  {
                AddressStatus st;
                getAddressStatus(addr, st);     
                return st.status.getStatus(AddressStatus::StatusType::CanReward); 
            }
            bool isStaked(const std::string & addr)  {
                AddressStatus st;
                getAddressStatus(addr, st);     
                return st.status.getStatus(AddressStatus::StatusType::IsStaked); 
            }

        private:
            std::shared_mutex mutex_;
            std::map<std::string, AddressStatus> address_status_map_;

    };

}
}


#endif //ADDRESS_STATUS_CACHE_H