#include "ca/contract_waiting_store.h"

#include <algorithm>
#include <map>
#include <nlohmann/json.hpp>
#include <set>

#include "db/db_api.h"
#include "utils/base64.h"

namespace contract_waiting
{
namespace
{
bool DecodeRecords(const std::string& raw, nlohmann::json& records)
{
    records = nlohmann::json::parse(raw, nullptr, false);
    return records.is_object();
}

bool DecodeRecord(const nlohmann::json& value, Record& record)
{
    try
    {
        record.id = value.at("id").get<std::string>();
        record.accounts = value.at("accounts").get<std::vector<std::string>>();
        record.created_at = value.at("created_at").get<uint64_t>();
        record.expires_at = value.at("expires_at").get<uint64_t>();
        return !record.id.empty() && record.message.ParseFromString(Base64Decode(value.at("message").get<std::string>()));
    }
    catch (...) { return false; }
}
} // namespace

EnqueueResult Store::Enqueue(const Record& record, const Limits& limits)
{
    if (record.id.empty() || record.message.txmsgreq_size() == 0 || record.accounts.empty() ||
        record.expires_at <= record.created_at) return EnqueueResult::kInvalid;
    DBReadWriter db("contract_waiting_enqueue");
    std::string raw;
    nlohmann::json records = nlohmann::json::object();
    const auto status = db.getContractWaitingBatches(raw);
    if (status == DBStatus::DB_SUCCESS && !DecodeRecords(raw, records)) return EnqueueResult::kStorageError;
    if (status != DBStatus::DB_SUCCESS && status != DBStatus::DB_NOT_FOUND) return EnqueueResult::kStorageError;
    if (records.contains(record.id)) return EnqueueResult::kAlreadyExists;

    size_t total_transactions = record.message.txmsgreq_size();
    size_t total_bytes = record.message.ByteSizeLong();
    std::map<std::string, size_t> account_batches;
    for (const auto& item : records.items())
    {
        Record existing;
        if (!DecodeRecord(item.value(), existing)) return EnqueueResult::kStorageError;
        total_transactions += existing.message.txmsgreq_size();
        total_bytes += existing.message.ByteSizeLong();
        for (const auto& account : existing.accounts) ++account_batches[account];
    }
    if (total_transactions > limits.max_transactions) return EnqueueResult::kGlobalTransactionCapacity;
    if (total_bytes > limits.max_bytes) return EnqueueResult::kGlobalByteCapacity;
    for (const auto& account : record.accounts)
        if (++account_batches[account] > limits.max_batches_per_account) return EnqueueResult::kAccountCapacity;

    records[record.id] = nlohmann::json{{"id", record.id},
                                        {"message", Base64Encode(record.message.SerializeAsString())},
                                        {"accounts", record.accounts},
                                        {"created_at", record.created_at},
                                        {"expires_at", record.expires_at}};
    return db.setContractWaitingBatches(records.dump()) == DBStatus::DB_SUCCESS &&
                   db.transactionCommit() == DBStatus::DB_SUCCESS
               ? EnqueueResult::kOk : EnqueueResult::kStorageError;
}

bool Store::Load(std::vector<Record>& out) const
{
    DBReader db;
    std::string raw;
    const auto status = db.getContractWaitingBatches(raw);
    if (status == DBStatus::DB_NOT_FOUND) return true;
    if (status != DBStatus::DB_SUCCESS) return false;
    nlohmann::json records;
    if (!DecodeRecords(raw, records)) return false;
    for (const auto& item : records.items())
    {
        Record record;
        if (!DecodeRecord(item.value(), record)) return false;
        out.push_back(std::move(record));
    }
    std::sort(out.begin(), out.end(), [](const Record& lhs, const Record& rhs) {
        if (lhs.created_at != rhs.created_at) return lhs.created_at < rhs.created_at;
        return lhs.id < rhs.id;
    });
    return true;
}

bool Store::Remove(const std::string& id)
{
    DBReadWriter db("contract_waiting_remove");
    std::string raw;
    const auto status = db.getContractWaitingBatches(raw);
    if (status == DBStatus::DB_NOT_FOUND) return true;
    nlohmann::json records;
    if (status != DBStatus::DB_SUCCESS || !DecodeRecords(raw, records)) return false;
    records.erase(id);
    return db.setContractWaitingBatches(records.dump()) == DBStatus::DB_SUCCESS &&
           db.transactionCommit() == DBStatus::DB_SUCCESS;
}

bool Store::PruneExpired(uint64_t now_micros, std::vector<std::string>* removed_ids)
{
    DBReadWriter db("contract_waiting_prune");
    std::string raw;
    const auto status = db.getContractWaitingBatches(raw);
    if (status == DBStatus::DB_NOT_FOUND) return true;
    nlohmann::json records;
    if (status != DBStatus::DB_SUCCESS || !DecodeRecords(raw, records)) return false;
    std::vector<std::string> expired;
    for (const auto& item : records.items())
        if (item.value().value("expires_at", 0ULL) <= now_micros) expired.push_back(item.key());
    if (expired.empty()) return true;
    for (const auto& id : expired) records.erase(id);
    if (db.setContractWaitingBatches(records.dump()) != DBStatus::DB_SUCCESS ||
        db.transactionCommit() != DBStatus::DB_SUCCESS) return false;
    if (removed_ids != nullptr) *removed_ids = std::move(expired);
    return true;
}
} // namespace contract_waiting
