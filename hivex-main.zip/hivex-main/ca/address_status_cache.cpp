﻿#include "address_status_cache.h"
#include "utils/account_manager.h"
#include "utils/magic_singleton.h"
#include "utils/time_util.h"
#include "include/logging.h"
#include "ca/algorithm.h"
#include "db/db_api.h"
#include "pb/transaction.pb.h"
#include "utils/string_util.h"
#include "ca/global.h"
#include "include/logging.h"

// namespace ohi { namespace utils{

int ohi::utils::AddressStatusCache::getAddressStatus(const std::string & addr, AddressStatus & address_status)
{
    if (! isValidAddress(addr))
    {
        return -1;
    }

    std::unique_lock<std::shared_mutex> lock(mutex_);

    if (address_status_map_[addr].is_expired == false)
    {
        auto it = address_status_map_.find(addr);
        if (it == address_status_map_.end())
        {
            return -2;
        }
        
        address_status = it->second;
        return 0;
    }
    
    address_status.address = addr;

    enum class GetTxType{
        Stake,
        Lock,
        Invest,
    };

    struct GetTxsAddrInfo{
        std::string addr;
        uint64_t amount{0};
        uint64_t time{0};
        std::string hash;
    };

    auto getTxs = [](const std::string & hash, GetTxType getTxType, GetTxsAddrInfo & info)->int{

        global::ca::TxType TX_TYPE;
        std::string TYPE_KEY;
        std::string TYPE_VALUE;
        std::string VIRTUAL_ADDR;

        if (getTxType == GetTxType::Stake)
        {
            TX_TYPE = global::ca::TxType::STAKE;
            TYPE_KEY = "stakeType";
            TYPE_VALUE = global::ca::STAKE_TYPE_NET;
            VIRTUAL_ADDR = global::ca::kTargetAddress;
        }
        else if (getTxType == GetTxType::Lock)
        {
            TX_TYPE = global::ca::TxType::LOCK;
            TYPE_KEY = "lockType";
            TYPE_VALUE = global::ca::kLockTypeNet;
            VIRTUAL_ADDR = global::ca::VIRTUAL_LOCK_ADDRESS;
        }
        else if (getTxType == GetTxType::Invest)
        {
            TX_TYPE = global::ca::TxType::DELEGATE;
            TYPE_KEY = "delegateType";
            TYPE_VALUE = global::ca::kdelegateTypeNormal;
            VIRTUAL_ADDR = global::ca::kVirtualDelegatingAddr;
        }
        else
        {
            return -1;
        }
        
        DBReader dbreader;
        std::string tx_raw;
        if (DBStatus::DB_SUCCESS != dbreader.getTransactionByHash(hash, tx_raw))
        {
            return -2;
        }

        CTransaction tx;
        if (! tx.ParseFromString(tx_raw))
        {
            return -3;
        }

        if ((global::ca::TxType)tx.type() != TX_TYPE)
        {
            return -4;
        }

        try
        {
            const std::string TxInfo = "txInfo";
            nlohmann::json data_json = nlohmann::json::parse(tx.data());
            if (!(data_json.contains(TxInfo) &&  data_json[TxInfo].is_object()))
            {
                throw;
            }

            nlohmann::json txInfo_json = data_json[TxInfo].get<nlohmann::json>();
            if (!(txInfo_json.contains(TYPE_KEY) && txInfo_json[TYPE_KEY].is_string()))
            {
                throw;
            }
            
            std::string type_value;
            txInfo_json[TYPE_KEY].get_to(type_value);

            if (type_value != TYPE_VALUE)
            {
                throw;
            }
        }
        catch(...)
        {
            return -5;
        }

        if (tx.utxos().size() != 1)
        {
            return -6;
        }

        auto utxo = tx.utxos().at(0);

        for(auto &vout : utxo.vout())
        {
            if (vout.addr() == VIRTUAL_ADDR)
            {
                info.amount = vout.value();
                info.time = tx.time();
                info.hash = tx.hash();
                break; // 目前只有一个tx和一个utxo，直接返回
            }
        }
        
        return 0;
    };
    

    DBReader db_reader;
    
    // 查找质押情况
    int ret = 0;
    {
        std::string assetType;
        ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
        if (ret != 0)
        {
            return -10 - ret;
        }

        std::vector<std::string> utxos;
        db_reader.getStakeUtxoByAddr(addr, assetType, utxos);

        if (utxos.size() == 1)
        {
            GetTxsAddrInfo info;
            std::string hash = utxos[0];
            ret = getTxs(hash, GetTxType::Stake, info);
            if (ret != 0)
            {
                return -20 - ret;
            }

            address_status.stake_info.amount = info.amount;
            address_status.stake_info.time = info.time;
            address_status.stake_info.hash = info.hash;
        }
    }

    {
        // 查找锁定情况
        std::vector<std::string> utxos;
        // 原硬编码字符串"Vote"，现统一使用ASSET_TYPE_OHI
        db_reader.getLockAddrUtxo(addr, global::ca::ASSET_TYPE_OHI, utxos);

        if (utxos.size() == 1)
        {
            GetTxsAddrInfo info;
            std::string hash = utxos[0];
            ret = getTxs(hash, GetTxType::Lock, info);
            if (ret != 0)
            {
                return -30 - ret;
            }

            address_status.lock_info.amount = info.amount;
            address_status.lock_info.time = info.time;
            address_status.lock_info.hash = info.hash;
        }
    }


    // 查询被某个地址投资以及时间，金额，hash等信息
    {
        std::multimap<std::string, std::string> delegating_addr_assetType;
        db_reader.getDelegatingAddrAndAssetTypeByBonusAddr(addr, delegating_addr_assetType);
        for (const auto & [delegating_addr, asset] : delegating_addr_assetType)
        {
            std::vector<std::string> utxos;
            if (DBStatus::DB_SUCCESS != db_reader.getDelegatingAddrUtxoByBonusAddr(addr, delegating_addr, asset, utxos))
            {
                continue;
            }

            if (utxos.size() == 1)
            {
                GetTxsAddrInfo info;
                std::string hash = utxos[0];
                ret = getTxs(hash, GetTxType::Invest, info);
                if (ret != 0)
                {
                    return -40 - ret;
                }
                                
                InvestedEntityInfo invested_entity_info;
                invested_entity_info.amount = info.amount;
                invested_entity_info.asset = asset;
                invested_entity_info.hash = info.hash;
                invested_entity_info.time = info.time;
                
                InvestedEntity invested_entity;
                invested_entity.addr = delegating_addr;
                invested_entity.info.insert(invested_entity_info);

                address_status.invested_entity.insert(invested_entity);
            }
        }
    }

    // 查询投资给某个地址以及时间，金额，hash等信息
    {
        std::multimap<std::string, std::string> bonusaddr_asset;
        db_reader.getBonusAddrAndAssetTypeByDelegatingAddr(addr, bonusaddr_asset);
        
        for (const auto & [bonus_addr, asset_type] : bonusaddr_asset)
        {
            std::vector<std::string> utxos;
            db_reader.getDelegatingAddrUtxoByBonusAddr(bonus_addr, addr, asset_type, utxos);

            if (utxos.size() == 1)
            {
                GetTxsAddrInfo info;
                std::string hash = utxos[0];
                ret = getTxs(hash, GetTxType::Invest, info);
                if (ret != 0)
                {
                    return -50 - ret;
                }
                            
                InvestorPortfolioInfo investor_portfolio_info;
                investor_portfolio_info.amount = info.amount;
                investor_portfolio_info.asset = asset_type;
                investor_portfolio_info.hash = info.hash;
                investor_portfolio_info.time = info.time;

                InvestorPortfolio investor_portfolio;
                investor_portfolio.addr = bonus_addr;
                investor_portfolio.info.insert(investor_portfolio_info);

                address_status.investor_portfolio.insert(investor_portfolio);
            }
        }
    }

    // 更新状态
    {
        
        // 判断stake
        bool isStaked = address_status.stake_info.amount >= global::ca::MIN_STAKE_AMOUNT && address_status.stake_info.time != 0;
        address_status.status.setStatus(AddressStatus::StatusType::IsStaked, isStaked);
        
        bool not_min_delegating_amount = false;
        uint64_t sum_delegate_amount = 0;
        for (const auto & i : address_status.invested_entity)
        {
            for (const auto & j : i.info)
            {
                if (j.amount < global::ca::kMinDelegatingAmt)
                {
                    not_min_delegating_amount = true;
                    break;
                }
                sum_delegate_amount += j.amount;
            }
        }

        // 判断IsQualified
        bool IsQualified = sum_delegate_amount >= global::ca::kMinKGetBonusDelegatingAmt && 
                        ! not_min_delegating_amount && 
                        isStaked;
        address_status.status.setStatus(AddressStatus::StatusType::IsQualified, IsQualified);
        
        
        // 判断IsDelegated
        bool isDelegated = address_status.investor_portfolio.size() != 0;
        address_status.status.setStatus(AddressStatus::StatusType::IsDelegated, isDelegated);

        // 判断IsLocked
        DBReader dbReader;
        std::vector<std::string> utxos;

        bool isLocked = DBStatus::DB_SUCCESS == dbReader.getLockAddrUtxo(address_status.address, global::ca::ASSET_TYPE_OHI, utxos);
        address_status.status.setStatus(AddressStatus::StatusType::IsLocked, isLocked);

        // 判断CanReward
        uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
        uint64_t zeroTime = MagicSingleton<TimeUtil>::GetInstance()->GetMorningTime(curTime)*1000000;

        bool CanReward = curTime > (zeroTime + (uint64_t) 60 * 60 * 1000000) && IsQualified;
        address_status.status.setStatus(AddressStatus::StatusType::CanReward, CanReward);
        

        // 判断IsBonusClaimed
        bool IsBonusClaimed = false;
        utxos.clear();
        uint64_t period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(curTime);
        if(DBStatus::DB_SUCCESS == dbReader.getBonusUtxoByPeriod(period, utxos))
        {
            //std::cout << "isbonusClaimed" << std::endl;            
            IsBonusClaimed = true;
        }
        for (const auto & utxo : utxos)
        {
            std::string strTx;
            CTransaction tx;
            if (dbReader.getTransactionByHash(utxo, strTx) != DBStatus::DB_SUCCESS)
            {
                continue;
            }	
            if(!tx.ParseFromString(strTx))
            {
                continue;
            }

            global::ca::TxType txType = (global::ca::TxType)tx.type();
            if (txType != global::ca::TxType::BONUS)
            {
                continue;
            }
            
            for(const auto& claimUtxo : tx.utxos())
            {
                if(claimUtxo.gas() == 1)
                {
                    continue;
                }
                std::string ClaimAddr = GenerateAddr(claimUtxo.vin(0).vinsign().pub());
                DEBUGLOG("ClaimAddr {}", ClaimAddr);
                DEBUGLOG("address_status.address {}", address_status.address);
                if (address_status.address == ClaimAddr)
                {
                    DEBUGLOG("360 IsBonusClaimed{}", IsBonusClaimed);
                    IsBonusClaimed = false;
                    break;
                }
            }
            DEBUGLOG("365 IsBonusClaimed{}", IsBonusClaimed);
            if (IsBonusClaimed == false)
            {
                // 只有一次质押因此只有一个utxo
                break;
            }
        }

        IsBonusClaimed = IsBonusClaimed && CanReward;
        address_status.status.setStatus(AddressStatus::StatusType::IsBonusClaimed, IsBonusClaimed);
    
    }

    // 更新状态
    address_status.is_expired = false;
    address_status_map_[addr] = address_status;
    return 0;
}

int ohi::utils::AddressStatusCache::markExpired(const std::string & addr)
{
    if (! isValidAddress(addr))
    {
        return -1;
    }

    std::unique_lock<std::shared_mutex> lock(mutex_);
    address_status_map_[addr].is_expired = true;

    return 0;
}
