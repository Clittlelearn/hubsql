#include "ca/pending_transaction_draft.h"

#include "ca/pending_transaction_reservations.h"
#include "ca/pending_transaction_policy.h"
#include "ca/pending_transaction_store.h"
#include "utils/magic_singleton.h"
#include "utils/sha256.h"
#include <atomic>

namespace pending_tx
{
namespace { std::atomic<uint64_t> g_draft_sequence{0}; }

std::string CanonicalCommitment(CTransaction tx)
{
    tx.clear_hash();
    tx.clear_signature();
    tx.clear_selection_vrf();
    tx.clear_identity();
    // Draft reservations are created before local/RPC signing.  Bind the
    // complete transaction intent and input set, but not signatures that do
    // not exist until the finalized transaction is returned by the signer.
    for (int utxoIndex = 0; utxoIndex < tx.utxos_size(); ++utxoIndex)
    {
        auto* utxo = tx.mutable_utxos(utxoIndex);
        utxo->clear_multisign();
        for (int vinIndex = 0; vinIndex < utxo->vin_size(); ++vinIndex)
            utxo->mutable_vin(vinIndex)->clear_vinsign();
    }
    return Getsha256Hash(tx.SerializeAsString());
}

uint64_t ConsensusDeadline(const CTransaction& tx)
{
    return ConsensusDeadline(tx.time(), tx.type());
}

bool FinalizeReservedTransaction(const CTransaction& tx)
{
    if (tx.hash().empty() || tx.utxos_size() == 0 || tx.utxos(0).owner_size() == 0) return false;
    const std::string address = tx.utxos(0).owner(0);
    std::vector<std::string> utxos;
    for (const auto& txUtxo : tx.utxos())
        for (const auto& vin : txUtxo.vin())
            for (const auto& prevout : vin.prevout())
                utxos.push_back(txUtxo.assettype() + "_" + prevout.hash() + "_" + std::to_string(prevout.n()));

    const std::string commitment = CanonicalCommitment(tx);
    std::string adopted;
    if (MagicSingleton<Reservations>::GetInstance()->ReserveOrAdoptExact(
            tx.hash(), address, tx.nonce(), utxos, commitment, &adopted) != ReserveResult::kOk)
        return false;
    if (MagicSingleton<Store>::GetInstance()->Replace(
            adopted, tx.hash(), address, tx.nonce(), utxos, commitment, ConsensusDeadline(tx)))
        return true;

    // The transaction has not been handed to the network yet.  On a
    // persistence failure, fail closed and remove the in-memory adoption so a
    // restart cannot expose a different memory/disk pending view.
    MagicSingleton<Reservations>::GetInstance()->Release(tx.hash());
    if (!adopted.empty()) MagicSingleton<Store>::GetInstance()->Remove(adopted);
    return false;
}

DraftGuard::~DraftGuard()
{
    if (!active_) return;
    MagicSingleton<Reservations>::GetInstance()->Release(id_);
    MagicSingleton<Store>::GetInstance()->Remove(id_);
}

bool DraftGuard::Begin(const CTransaction& tx, uint64_t confirmed_nonce)
{
    if (active_ || tx.utxos_size() == 0 || tx.utxos(0).owner_size() == 0) return false;
    address_ = tx.utxos(0).owner(0);
    for (const auto& utxo : tx.utxos())
        for (const auto& vin : utxo.vin())
            for (const auto& prevout : vin.prevout()) utxos_.push_back(utxo.assettype() + "_" + prevout.hash() + "_" + std::to_string(prevout.n()));
    id_ = "draft_" + address_ + "_" + std::to_string(tx.time()) + "_" + std::to_string(g_draft_sequence.fetch_add(1));
    if (MagicSingleton<Reservations>::GetInstance()->Reserve(id_, address_, confirmed_nonce, utxos_, &nonce_) != ReserveResult::kOk)
        return false;
    active_ = true;
    CTransaction committed_tx = tx;
    committed_tx.set_nonce(nonce_);
    commitment_ = CanonicalCommitment(committed_tx);
    if (!MagicSingleton<Reservations>::GetInstance()->SetCommitment(id_, commitment_) ||
        !MagicSingleton<Store>::GetInstance()->Persist(id_, address_, nonce_, utxos_, commitment_)) {
        MagicSingleton<Reservations>::GetInstance()->Release(id_);
        active_ = false;
        return false;
    }
    return true;
}

bool DraftGuard::Finalize(const CTransaction& tx)
{
    const std::string& transaction_hash = tx.hash();
    if (!active_ || transaction_hash.empty()) return false;
    if (tx.nonce() != nonce_ || CanonicalCommitment(tx) != commitment_) return false;
    std::string adopted;
    if (MagicSingleton<Reservations>::GetInstance()->ReserveOrAdoptExact(
            transaction_hash, address_, nonce_, utxos_, commitment_, &adopted) != ReserveResult::kOk || adopted != id_)
        return false;
    if (!MagicSingleton<Store>::GetInstance()->Replace(id_, transaction_hash, address_, nonce_, utxos_, commitment_,
                                                       ConsensusDeadline(tx))) {
        MagicSingleton<Reservations>::GetInstance()->Release(transaction_hash);
        MagicSingleton<Store>::GetInstance()->Remove(id_);
        active_ = false;
        return false;
    }
    id_ = transaction_hash;
    active_ = false;
    return true;
}
} // namespace pending_tx
