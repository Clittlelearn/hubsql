/**
 * *****************************************************************************
 * @file        block_rate_probe.cpp
 * @brief       区块上链率探测模块实现
 * @author
 * @date        2026-06-06
 * @copyright   mm
 * *****************************************************************************
 */

#include "ca/block_rate_probe.h"

#include "ca/ca.h"
#include "ca/check_blocks.h"
#include "ca/global.h"
#include "ca/transaction.h"          // VerifyBonusAddr
#include "common/config.h"
#include "common/global_data.h"
#include "db/db_api.h"
#include "include/logging.h"
#include "net/interface.h"
#include "net/peer_node.h"
#include "pb/block_rate_probe.pb.h"
#include "utils/magic_singleton.h"
#include "utils/time_util.h"

// ==================== BlockRateProbe 实现 ====================

BlockRateProbe::BlockRateProbe()
{
    INFOLOG("BlockRateProbe initialized");
}

BlockRateProbe::~BlockRateProbe()
{
    // 收集所有待取消的定时器（锁内），然后释放锁再取消，避免 join 时持有锁导致死锁
    std::vector<std::shared_ptr<CTimer>> timersToCancel;
    {
        std::unique_lock<std::shared_mutex> lock(_rwMutex);
        for (auto& [hash, timerList] : _timers)
        {
            for (auto& timer : timerList)
            {
                if (timer)
                {
                    timersToCancel.push_back(timer);
                }
            }
        }
        _timers.clear();
    }
    // 锁外取消定时器
    for (auto& timer : timersToCancel)
    {
        timer->Cancel();
    }
    DEBUGLOG("BlockRateProbe destroyed");
}

void BlockRateProbe::AddBlock(const std::string& hash)
{
    // 检查配置开关
    if (!MagicSingleton<Config>::GetInstance()->GetEnableBlockRateProbe())
    {
        DEBUGLOG("BlockRateProbe is disabled, skip AddBlock for hash: {}", hash.substr(0, 8));
        return;
    }

    if (hash.empty())
    {
        ERRORLOG("AddBlock called with empty hash");
        return;
    }

    std::unique_lock<std::shared_mutex> lock(_rwMutex);

    // 检查是否已在缓存中（避免重复添加）
    auto it = _resultMap.find(hash);
    if (it != _resultMap.end())
    {
        DEBUGLOG("Block {} already in probe cache, skip", hash.substr(0, 8));
        return;
    }

    // 创建新的探测记录
    uint64_t now = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    ProbeResult result(hash, now);

    // 淘汰机制：超过最大缓存数时删除最早记录
    if (_hashQueue.size() >= kMaxCacheSize)
    {
        const std::string& oldestHash = _hashQueue.front();
        _resultMap.erase(oldestHash);
        _hashQueue.pop_front();

        // 取消被淘汰记录的定时器
        auto timerIt = _timers.find(oldestHash);
        if (timerIt != _timers.end())
        {
            for (auto& timer : timerIt->second)
            {
                if (timer)
                {
                    timer->Cancel();
                }
            }
            _timers.erase(timerIt);
        }
        DEBUGLOG("Evicted oldest probe record: {}", oldestHash.substr(0, 8));
    }

    // 插入新记录
    _hashQueue.push_back(hash);
    _resultMap[hash] = result;

    INFOLOG("AddBlock for hash: {}, create_time: {}", hash.substr(0, 8), now);

    // 创建三个延时探测任务的定时器
    // 探测时间点：T+5s, T+10s, T+20s
    static const uint32_t kProbeDelaysSec[] = {5, 10, 20};

    std::vector<std::shared_ptr<CTimer>> timerList;
    for (uint32_t i = 0; i < 3; ++i)
    {
        auto timer = std::make_shared<CTimer>("BlockRateProbe_" + hash.substr(0, 8) + "_" + std::to_string(i));
        int delayMs = static_cast<int>(kProbeDelaysSec[i] * 1000);

        // 捕获 hash 和 probeIndex，按绝对时间点执行
        bool ok = timer->AsyncOnce(delayMs, [this, hash, i]() {
            this->_DoProbe(hash, i);
        });

        if (ok)
        {
            timerList.push_back(timer);
            DEBUGLOG("Scheduled probe {} for hash {} at T+{}s", i + 1, hash.substr(0, 8), kProbeDelaysSec[i]);
        }
        else
        {
            ERRORLOG("Failed to schedule probe {} for hash {}", i + 1, hash.substr(0, 8));
        }
    }

    _timers[hash] = std::move(timerList);
}

void BlockRateProbe::_DoProbe(const std::string& hash, uint32_t probeIndex)
{
    DEBUGLOG("_DoProbe start: hash={}, probeIndex={}", hash.substr(0, 8), probeIndex);

    // 检查配置开关
    if (!MagicSingleton<Config>::GetInstance()->GetEnableBlockRateProbe())
    {
        DEBUGLOG("BlockRateProbe disabled during probe, skip");
        return;
    }

    // 加读锁检查当前状态
    {
        std::shared_lock<std::shared_mutex> readLock(_rwMutex);
        auto it = _resultMap.find(hash);
        if (it == _resultMap.end())
        {
            DEBUGLOG("Probe record for hash {} not found, may have been evicted", hash.substr(0, 8));
            return;
        }
        // 如果已确认，取消后续探测
        if (it->second.confirmed)
        {
            DEBUGLOG("Block {} already confirmed, skip probe {}", hash.substr(0, 8), probeIndex);
            return;
        }
    }

    // 获取当前质押节点列表（每次探测实时获取，不缓存）
    std::vector<std::string> pledgeAddr;
    int ret = _fetchPledgeAddress(pledgeAddr);
    if (ret != 0)
    {
        ERRORLOG("_fetchPledgeAddress failed, ret={}, skip probe {}", ret, probeIndex);
        return;
    }

    if (pledgeAddr.empty())
    {
        WARNLOG("No pledge nodes available for probe");
        return;
    }

    uint64_t totalNodeCount = pledgeAddr.size();

    // 创建等待组，用于收集响应
    // 需要至少 80% 的节点返回数据才能计算
    std::string msgId;
    uint32_t requiredResponses = static_cast<uint32_t>(totalNodeCount * global::ca::kHighConfidenceThreshold);
    if (requiredResponses < 1) requiredResponses = 1;

    if (!dataMgrPtr.CreateWait(kProbeWaitTimeoutSec, requiredResponses, msgId))
    {
        ERRORLOG("CreateWait failed for probe {}", probeIndex);
        return;
    }

    // 注册期望响应的节点
    for (const auto& nodeId : pledgeAddr)
    {
        dataMgrPtr.AddResNode(msgId, nodeId);
    }

    // 向所有质押节点发送探测请求
    _sendProbeRequests(pledgeAddr, hash, msgId);

    // 等待收集响应
    std::vector<std::string> retDatas;
    if (!dataMgrPtr.WaitData(msgId, retDatas))
    {
        if (retDatas.empty())
        {
            WARNLOG("No responses received for probe {}, hash={}", probeIndex, hash.substr(0, 8));
        }
        // 即使 WaitData 返回 false（超时），仍然使用已收到的数据进行统计
        DEBUGLOG("WaitData returned with {} responses for probe {}", retDatas.size(), probeIndex);
    }

    // 统计拥有区块的节点数
    uint64_t existCount = 0;
    for (const auto& data : retDatas)
    {
        BlockRateProbeAck ack;
        if (!ack.ParseFromString(data))
        {
            DEBUGLOG("Failed to parse BlockRateProbeAck from received data");
            continue;
        }
        if (ack.exist())
        {
            ++existCount;
        }
    }

    // 更新探测结果并判断是否确认上链
    _updateProbeResult(hash, probeIndex, requiredResponses, existCount);

    DEBUGLOG("_DoProbe end: hash={}, probeIndex={}, existCount={}/{}, rate={:.2f}%",
             hash.substr(0, 8), probeIndex, existCount, requiredResponses,
             (requiredResponses > 0) ? (100.0 * existCount / requiredResponses) : 0.0);
}

int BlockRateProbe::_fetchPledgeAddress(std::vector<std::string>& pledgeAddr)
{
    pledgeAddr.clear();

    // 获取当前在线节点列表
    std::vector<Node> nodelist = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    if (nodelist.empty())
    {
        WARNLOG("No nodes in nodelist");
        return -1;
    }

    // 筛选出有效的质押节点（与 CheckBlocks::fetchPledgeAddress 逻辑一致）
    for (const auto& node : nodelist)
    {
        bool canReward = VerifyBonusAddr(node.address);
        if (canReward)
        {
            pledgeAddr.push_back(node.address);
        }
    }

    if (pledgeAddr.empty())
    {
        WARNLOG("No pledge addresses found in nodelist");
        return -2;
    }

    DEBUGLOG("Fetched {} pledge nodes", pledgeAddr.size());
    return 0;
}

void BlockRateProbe::_sendProbeRequests(const std::vector<std::string>& nodeIds,
                                         const std::string& blockHash,
                                         const std::string& msgId)
{
    for (const auto& nodeId : nodeIds)
    {
        sendBlockRateProbeRequest(nodeId, msgId, blockHash);
    }
}

void BlockRateProbe::_updateProbeResult(const std::string& hash,
                                         uint32_t probeIndex,
                                         uint64_t requiredResponses,
                                         uint64_t existCount)
{
    double rate = (requiredResponses > 0)
                  ? (static_cast<double>(existCount) / static_cast<double>(requiredResponses))
                  : 0.0;

    std::unique_lock<std::shared_mutex> lock(_rwMutex);
    auto it = _resultMap.find(hash);
    if (it == _resultMap.end())
    {
        DEBUGLOG("ProbeResult for hash {} not found during update", hash.substr(0, 8));
        return;
    }

    ProbeResult& result = it->second;

    // 如果已确认，跳过后续更新
    if (result.confirmed)
    {
        return;
    }

    // 记录本次探测结果
    result.rates.push_back(rate);
    result.probe_count = static_cast<uint32_t>(result.rates.size());

    INFOLOG("Probe {} for hash {}: rate={:.2f}% ({} exist / {} total)",
            probeIndex + 1, hash.substr(0, 8), rate * 100.0, existCount, requiredResponses);

    // 判定是否成功上链：rate >= 0.8
    if (rate >= global::ca::kHighConfidenceThreshold)
    {
        result.confirmed = true;
        INFOLOG("Block {} confirmed on-chain at probe {} with rate={:.2f}%",
                hash.substr(0, 8), probeIndex + 1, rate * 100.0);

        // 标记 confirmed 后，后续定时器回调在 _DoProbe 入口检测到 confirmed=true 会自动跳过
    }
}

void BlockRateProbe::_cancelPendingProbes(const std::string& hash)
{
    std::lock_guard<std::mutex> timerLock(_timerMutex);
    std::shared_lock<std::shared_mutex> rwLock(_rwMutex);

    auto it = _timers.find(hash);
    if (it != _timers.end())
    {
        // 取消所有定时器（已执行完毕的 Cancel 是无害的）
        for (auto& timer : it->second)
        {
            if (timer)
            {
                timer->Cancel();
            }
        }
        DEBUGLOG("Cancelled pending probes for hash {}", hash.substr(0, 8));
    }
}

double BlockRateProbe::GetRateByHash(const std::string& hash)
{
    std::shared_lock<std::shared_mutex> lock(_rwMutex);
    auto it = _resultMap.find(hash);
    if (it == _resultMap.end())
    {
        DEBUGLOG("GetRateByHash: hash {} not found", hash.substr(0, 8));
        return -1.0;
    }

    const ProbeResult& result = it->second;
    if (result.rates.empty())
    {
        return -1.0;
    }

    // 返回最新一次探测的上链率
    return result.rates.back();
}

void BlockRateProbe::GetAllResults(std::vector<ProbeResult>& results)
{
    std::shared_lock<std::shared_mutex> lock(_rwMutex);
    results.clear();
    results.reserve(_resultMap.size());

    // 按插入顺序返回（使用 _hashQueue 维护顺序）
    for (const auto& hash : _hashQueue)
    {
        auto it = _resultMap.find(hash);
        if (it != _resultMap.end())
        {
            results.push_back(it->second);
        }
    }
}

void BlockRateProbe::_CleanupExpiredTimers()
{
    std::lock_guard<std::mutex> timerLock(_timerMutex);
    std::shared_lock<std::shared_mutex> rwLock(_rwMutex);

    // 遍历并移除已失效的定时器（对应的区块记录已被淘汰）
    auto timerIt = _timers.begin();
    while (timerIt != _timers.end())
    {
        if (_resultMap.find(timerIt->first) == _resultMap.end())
        {
            for (auto& timer : timerIt->second)
            {
                if (timer)
                {
                    timer->Cancel();
                }
            }
            timerIt = _timers.erase(timerIt);
        }
        else
        {
            ++timerIt;
        }
    }
}

// ==================== 网络消息处理函数 ====================

void sendBlockRateProbeRequest(const std::string& nodeId,
                                const std::string& msgId,
                                const std::string& blockHash)
{
    BlockRateProbeReq req;
    req.set_self_node_id(MagicSingleton<PeerNode>::GetInstance()->GetSelfId());
    req.set_msg_id(msgId);
    req.set_block_hash(blockHash);

    NetSendMessage<BlockRateProbeReq>(nodeId, req,
        net_com::Compress::COMPRESS_TRUE,
        net_com::Encrypt::ENCRYPT_FALSE,
        net_com::Priority::PRIORITY_HIGH_LEVEL_1);
}

void sendBlockRateProbeAcknowledgment(const std::string& nodeId,
                                       const std::string& msgId,
                                       const std::string& blockHash,
                                       bool exist)
{
    BlockRateProbeAck ack;
    ack.set_self_node_id(MagicSingleton<PeerNode>::GetInstance()->GetSelfId());
    ack.set_msg_id(msgId);
    ack.set_block_hash(blockHash);
    ack.set_exist(exist);

    NetSendMessage<BlockRateProbeAck>(nodeId, ack,
        net_com::Compress::COMPRESS_TRUE,
        net_com::Encrypt::ENCRYPT_FALSE,
        net_com::Priority::PRIORITY_HIGH_LEVEL_1);
}

int handleBlockRateProbeRequest(const std::shared_ptr<BlockRateProbeReq>& msg,
                                 const MsgData& msgdata)
{
    // 验证请求节点身份
    if (!PeerNode::verifyPeerNodeIdRequest(msgdata.fd, msg->self_node_id()))
    {
        ERRORLOG("verifyPeerNodeIdRequest failed for BlockRateProbeReq from fd:{}", msgdata.fd);
        return -1;
    }

    const std::string& blockHash = msg->block_hash();
    bool exist = false;

    // 查询本地区块数据库，判断是否拥有该区块
    DBReader dbReader;
    std::string blockRaw;
    auto ret = dbReader.getBlockByBlockHash(blockHash, blockRaw);
    if (DBStatus::DB_SUCCESS == ret)
    {
        exist = true;
    }
    else if (DBStatus::DB_NOT_FOUND != ret)
    {
        ERRORLOG("DB error when querying block hash {}: {}", blockHash.substr(0, 8), static_cast<int>(ret));
        // 数据库错误时，仍回复 exist=false
    }

    DEBUGLOG("BlockRateProbe request for hash {}, exist={}", blockHash.substr(0, 8), exist);

    // 回复 Ack
    sendBlockRateProbeAcknowledgment(msg->self_node_id(), msg->msg_id(), blockHash, exist);

    return 0;
}

int handleBlockRateProbeAcknowledge(const std::shared_ptr<BlockRateProbeAck>& msg,
                                     const MsgData& msgdata)
{
    // 验证响应节点身份
    if (!PeerNode::verifyPeerNodeIdRequest(msgdata.fd, msg->self_node_id()))
    {
        ERRORLOG("verifyPeerNodeIdRequest failed for BlockRateProbeAck from fd:{}", msgdata.fd);
        return -1;
    }

    DEBUGLOG("BlockRateProbe ack from {}, hash={}, exist={}",
             msg->self_node_id().substr(0, 8), msg->block_hash().substr(0, 8), msg->exist());

    // 将响应数据添加到等待组
    dataMgrPtr.waitDataToAdd(msg->msg_id(), msg->self_node_id(), msg->SerializeAsString());

    return 0;
}
