#ifndef OPENHIVE_CA_PRESSURE_RETRY_POLICY_H
#define OPENHIVE_CA_PRESSURE_RETRY_POLICY_H

#include <algorithm>
#include <chrono>
#include <cstdint>

namespace pressure_retry
{
inline constexpr auto kMaxWait = std::chrono::seconds(10);
inline constexpr auto kHeightPollInterval = std::chrono::milliseconds(100);
inline constexpr auto kFallbackRetryInterval = std::chrono::seconds(1);

inline bool CanRetry(uint64_t now_micros, uint64_t deadline_micros)
{
    return deadline_micros != 0 && now_micros < deadline_micros;
}

inline uint64_t RemainingMicros(uint64_t now_micros, uint64_t deadline_micros)
{
    return CanRetry(now_micros, deadline_micros) ? deadline_micros - now_micros : 0;
}
} // namespace pressure_retry

#endif // OPENHIVE_CA_PRESSURE_RETRY_POLICY_H
