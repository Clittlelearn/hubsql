﻿#ifndef CA_GLOBAL_HEADER
#define CA_GLOBAL_HEADER
#include <boost/multiprecision/cpp_bin_float.hpp>

#include <unordered_set>

#include "pb/ca_protomsg.pb.h"
#include "utils/timer.hpp"

namespace global{
    namespace ca{

        
        
        // consensus
        static const int kConsensus = 3;

        // VRF 确认协议 — 阶段时间分配（秒）
        const int PHASE1_DURATION = 6;   // VRF 广播
        const int PHASE2_DURATION = 4;   // 摘要交换
        const int PHASE3_DURATION = 2;   // 共识计算
        const int BUFFER_DURATION   = 3;  // 缓冲

        // VRF 确认协议 — 降级时间（秒，从周期起点计算）
        const int LEVEL1_START = 15;
        const int LEVEL2_START = 20;
        const int LEVEL3_START = 25;

        // VRF 确认协议 — 自适应阈值比例
        constexpr double THRESHOLD_RATIO_LARGE  = 2.0 / 3.0;   // N ≥ 200
        constexpr double THRESHOLD_RATIO_MEDIUM = 3.0 / 4.0;   // 50 ≤ N < 200
        constexpr double THRESHOLD_RATIO_SMALL  = 4.0 / 5.0;   // 20 ≤ N < 50
        constexpr double THRESHOLD_RATIO_TINY   = 9.0 / 10.0;  // N < 20

        // VRF 确认协议 — 档位切换滞后区间
        const int HYSTERESIS_MARGIN = 5;

        // VRF 确认协议 — 边界裁决缓冲
        const int BOUNDARY_DELTA = 2;

        // VRF 确认协议 — 分区检测阈值
        constexpr double PARTITION_COVERAGE_THRESHOLD = 0.60;

        // VRF 确认协议 — 时钟偏差容忍（秒）
        const int CLOCK_SKEW_TOLERANCE = 2;
        // 准入池概率参数
        constexpr double kEntryPoolInitialProb = 0.50;    // 质押初始概率 50%
        constexpr double kEntryPoolDailyIncrement = 0.025; // 每日递增 2.5%
        // 3月15日参考基准时间 (UTC+0 秒级Unix时间戳)
        // 概率 = 0.50 + (当前时间 - 此基准) / 86400 * 0.025, 上限1.0
        constexpr int64_t kEntryPoolReferenceTimestamp = 1741996800; // 2026-03-15 00:00:00 UTC
        //static const int randomNodeGroup = 1; 
        const int send_node_threshold = 5; //The threshold at which a block stream is sent
        const int KReSend_node_threshold = 5;
        const uint32_t MIN_SYNC_QUAL_NODES = 3;

        const int TX_TIMEOUT_MIN = 30;
                                       
        // timer
        static CTimer BLOCK_POOL_TIMER_INTERVAL("blockpool");
        static CTimer SEEK_BLOCK_TIMER("SeekBlock");
        static CTimer DATABASE_TIMER("database");
        // mutex
        static std::mutex bonusMutex;
        static std::mutex kDelegatingMutex;
        static std::mutex BURN_MUTEX;
        static std::mutex LOCK_MUTEX;

        // ca
        const uint64_t kDecimalNum = 100000000;
        const double   MIN_DOUBLE_CONSTANT_PRECISION = 0.000000005;
        const uint32_t LOCK_AMOUNT = 1;//1000;
        // 锁定/质押/投资 释放等待时间（微秒）
       // const uint64_t LOCK_RELEASE_WAIT_TIME = (uint64_t)1000000 * 60 * 60 * 24 * 30;    // 锁定解压等待时间: 30天
       // const uint64_t STAKE_RELEASE_WAIT_TIME = (uint64_t)1000000 * 60 * 60 * 24 * 30;   // 质押解压等待时间: 30天
       // const uint64_t DELEGATE_RELEASE_WAIT_TIME = (uint64_t)1000000 * 60 * 60 * 24;     // 投资解压等待时间: 1天

        const uint64_t LOCK_RELEASE_WAIT_TIME = (uint64_t)1000;    // 锁定解压等待时间: 30天
        const uint64_t STAKE_RELEASE_WAIT_TIME = (uint64_t)1000;   // 质押解压等待时间: 30天
        const uint64_t DELEGATE_RELEASE_WAIT_TIME = (uint64_t)1000;     // 投资解压等待时间: 1天

        const uint64_t DEV_RELEASE_WAIT_TIME = (uint64_t)1000000 * 60;                     // Dev网络解压等待时间: 1分钟
        const uint64_t MIN_STAKE_AMOUNT = (uint64_t)((double)3500 * kDecimalNum);
        const uint64_t kMinKGetBonusDelegatingAmt = (uint64_t)((double)500000 * kDecimalNum);
        const uint64_t kMinDelegatingAmt = (uint64_t)((double)500 * kDecimalNum);
        const uint64_t KInvestmentCap=(uint64_t)3500000*kDecimalNum;
        const uint64_t kMaximum_number_of_investments=1000;
        //const std::string GENESIS_SIGN = "Genesis";
        //const std::string kTxSign = "Tx";
        const std::string kTargetAddress = "VirtualStake";
        const std::string kVirtualDelegatingAddr = "VirtualDelegating";
        const std::string VIRTUAL_BURN_GAS_ADDR = "VirtualBurnGas";
        const std::string STAKE_TYPE_NET = "Net";
        const std::string kdelegateTypeNormal = "Normal";
        const uint64_t MIN_UNSTAKE_HEIGHT = 500;
        const uint64_t VOTE_CIRCULATION = 100000000000000000;
        const std::string
            kVirtualDeploymentContractAddress = "VirtualDeployContractBurnGas";
        const std::string VIRTUAL_CALL_CONTRACT_ADDR = "VirtualCallContractBurnGas";
        const std::string kVirtualCallFlowOutAddr = "VirtualCallFlowOutBurnGas";
        const std::string kLockTypeNet = "LockNet";
        const std::string VIRTUAL_LOCK_ADDRESS = "LockVirtualStake";
		
        const uint64_t KtxTimeout = 10 * 1000000ull;

        // Fund / Bonus 领取时间常量（微秒）
        // const uint64_t kFundClaimLockPeriod = (uint64_t)1000000 * 60 * 60 * 24;       // Fund 领取：锁定资产需持有满 24 小时
        // const uint64_t kClaimDailyWindowStartOffset = (uint64_t)60 * 60 * 1000000;     // Fund/Bonus 每日领取窗口：凌晨 1:00 (UTC) 之后
        // const uint64_t kClaimTxTimeFutureTolerance = (uint64_t)10 * 1000000;           // Fund/Bonus 交易时间未来容错：10 秒


        const uint64_t kFundClaimLockPeriod = (uint64_t)1000000;       // Fund 领取：锁定资产需持有满 24 小时
        const uint64_t kClaimDailyWindowStartOffset = (uint64_t) 1000000;     // Fund/Bonus 每日领取窗口：凌晨 1:00 (UTC) 之后
        const uint64_t kClaimTxTimeFutureTolerance = (uint64_t)10 * 1000000;           // Fund/Bonus 交易时间未来容错：10 秒

        const double MAX_COMMISSION_RATE = 0.35;
        const double MIN_COMMISSION_RATE = 0.05;

        const uint64_t KTargetGasPrice = 60000; //为最大Gasfee的一半
        
        // 原 assetType_MM，重命名为 ASSET_TYPE_OHI（OHI资产）
        const  std::string ASSET_TYPE_OHI = "OHI";//hash

        enum class StakeType
        {
            STAKE_TYPE_UNKNOWN = 0,
            STAKE_TYPE_NODE = 1
        };

        enum TxIndependence:int{
            TX_INDEPENDENCE_FALSE = 0,
            TX_INDEPENDENCE_TRUE = 1,
            TX_INDEPENDENCE_NAN=2
        };
        enum UtxoGasType:int{
            UTXO_GAS_TYPE_FALSE = 0,
            UTXO_GAS_TYPE_TRUE = 1
        };
        
        // Transacatione Type
        enum class TxType:int32_t
        {
           // kGenesisTxType = -1,
            UNKNOWN = -1, // unknown 
            GENESIS,// god tx !!!
            TX, //normal transaction 1
            STAKE, //stake 2 
            UNSTAKE, //unstake 3
            DELEGATE, //delegating 4 
            UNDELEGATE, //Undelegate 5
            DECLARATION, //declaration 6
            DEPLOY, //部署合约 7
            CALL,  //调用合约 8
            LOCK,            //锁定  锁定后有投票权限 9
            UNLOCK,          //解除锁定 10
            PROPOSAL,        //提案 11
            REVOKEPROPOSAL,    //撤销提案 12 
            VOTE,              //投票 13 
            FUND = 98,  //领取国库奖励交易
            BONUS = 99,//bonus 14
            PUNISHMENT = 100, // 惩罚交易（涉及质押金扣减和资金转移）
            EVIDENCE = 101    // 举证交易（仅链上记录，无资金转移）
        };

        // Sync
        enum class SaveType
        {
            SyncNormal,
            SyncFromZero,
            Broadcast,
            Unknow
        };

        enum class blockMean
        {
            Normal,
            processByPreHash,
            ByUtxo
        };
        const uint64_t hashRangeSum = 100;
        const uint64_t sumHashRange = 1000;

        namespace DoubleSpend {
            const int SingleBlock = -66;
            const int DoubleBlock = -99;
        };

        const uint32_t KVoteCycle = 10 * 60 * 1000000; //10 分钟
        const uint32_t KVrfVoteBeginTime = 10 * 1000000; //10 秒
        const boost::multiprecision::cpp_bin_float_100 KLowestExchangeRate("1e-8"); //汇率的最小值
        
        //投票类型
        enum class VoteType
        {
            Against = 0, //反对
            Approve = 1,  //赞成
            Count // 特殊的枚举元素，用于标记枚举元素的个数
        };

        //提案中包含的跨链交易类型
        enum class CrossChainTxType
        {
            EnteringMore = 0,           //仅包含越入越出
            CrossChainInvestment = 1,   //仅包含跨链投资
            Both = 2,                   //包含越入越出和跨链投资
            Null = 3,                   //不包含任何跨链交易
        };

        //提案信息版本
        const uint8_t KProposalInfoVersion = 0;
        //撤销提案信息版本
        const uint8_t KRevokeProposalInfoVersion = 0;

        // contract
        enum VmType {
            EVM
        };
        //test
        static std::atomic<uint64_t> TxNumber{0};
        const uint32_t CURRENT_TRANSACTION_VERSION = 0;
        const uint32_t kCurrentBlockVersion = 0;


        // 多数判定阈值 — 简单多数，用于分叉方向初步判定
        constexpr double kForkMajorityThreshold = 0.51;
        // 拜占庭容错阈值 — 2/3 以上节点一致，用于区块/交易/UTXO 的共识验证
        constexpr double kByzantineFaultToleranceThreshold = 0.66;
        // 链高度百分位 — 选取第 75 百分位的高度作为链共识高度
        constexpr double kChainHeightPercentile = 0.75;
        // 高置信度阈值 — 用于从零同步等关键安全场景
        constexpr double kHighConfidenceThreshold = 0.80;

        // Gas limit for block execution (30 million, same as Ethereum)
        const uint64_t kBlockGasLimit = 30000000;
        // const uint64_t kBlockGasLimit = 100000;

        // Gas buffer ratio (90% of gas limit for safety margin)
        const double kGasLimitBufferRatio = 0.9;

        // === Slashing mechanism constants ===

        // Offline tolerance (unit: number of 10s VRF periods)
        constexpr uint64_t kSlashWatchdogPeriods = 360;            // Watchdog period: 1 hour
        constexpr uint64_t kSlashSoftOfflinePeriods = 8640;        // Soft offline threshold: 24 hours
        constexpr uint64_t kSlashArchivePeriods = 60480;           // Archive threshold: 7 days

        // L1 — Jailing
        constexpr uint64_t kJailConsecutiveAbsentPeriods = 8640;   // Consecutive absence trigger: 24 hours
        constexpr double kJailLowThreshold = 0.50;                  // Low signing rate threshold (50% of average)
        constexpr uint32_t kJailConsecutiveLowPeriods = 2;          // Consecutive low-signing periods
        constexpr uint64_t kJailAutoReleasePeriods = 100;           // Auto-release after N periods
        constexpr uint64_t kJailManualReleasePeriods = 5;           // Manual release requires N consecutive normal periods

        // L2 — Forfeit
        constexpr uint64_t kForfeitJailPeriods = 2880;             // Jailed beyond threshold: 8 hours
        constexpr uint32_t kForfeitDisconnectCount = 10;            // Disconnects per hour threshold

        // L3 — Slashing (stake deduction)
        constexpr double kSlashRateFirst = 0.01;                    // First deduction: 1%
        constexpr double kSlashRateSecond = 0.03;                   // Second deduction: 3%
        constexpr double kSlashRateThird = 0.05;                    // Third+ deduction: 5%
        constexpr uint32_t kSlashVRFFailCount = 5;                  // Cumulative VRF verify failure count
        constexpr double kSlashInvalidBlockThreshold = 0.66;        // 66% nodes report invalid

        // L4 — Tombstoning
        // Evidence collection
        constexpr uint64_t kSlashEvidenceMaxDelayMs = 3000;         // Max backoff delay (ms)
        constexpr uint32_t kSlashEvidenceQuorum = kConsensus;       // Evidence consensus threshold follows block consensus
        constexpr uint32_t kSlashEvidenceMaxPerPeriod = 20;         // Max evidence per period
        constexpr uint64_t kSlashEvidenceDedupWindow = 60000;       // Evidence dedup window (ms)
        constexpr uint64_t kSlashDispatcherAckTimeout = 5000;       // Dispatcher ACK timeout (ms)

        // Abuse prevention
        constexpr double kSlashAbuseThresholdRate = 0.10;           // Valid report rate below 10% is suspicious
        constexpr uint32_t kSlashAbuseMinReports = 5;               // Min reports before abuse check

        // Punishment thresholds (number of EVIDENCE txs to trigger PUNISHMENT)
        constexpr uint32_t kPunishmentThresholdL3 = 3;              // 3 EVIDENCE txs → L3
        constexpr uint32_t kPunishmentThresholdL4 = 5;              // 5 EVIDENCE txs → L4
    }
}


#endif

