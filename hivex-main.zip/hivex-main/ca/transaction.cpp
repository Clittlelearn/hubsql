﻿#include "ca/transaction.h"

#include <cstdint>
#include <cstring>
#include <set>
#include <mutex>
#include <iostream>
#include <sstream>
#include <shared_mutex>
#include <google/protobuf/repeated_field.h>

#include "ca.h"
#include "ca/global.h"
#include "ca/txhelper.h"
#include "ca/algorithm.h"
#include "ca/dispatchtx.h"
#include "ca/block_helper.h"
#include "ca/transaction_cache.h"
#include "ca/confirmed_exclusion_verifier.h"
#include "ca/failed_transaction_cache.h" 
#include "ca/resend_reconnect_node.h"
#include "ca/bonus_addr_cache.h"


#include "common/genesis_helper.h"
#include "utils/vrf.hpp"
#include "utils/console.h"
#include "utils/tmp_log.h"
#include "utils/time_util.h"
#include "utils/return_ack.h"
#include "utils/string_util.h"
#include "utils/cycliclist.hpp"
#include "utils/bench_mark.h"
#include "utils/account_manager.h"
#include "utils/magic_singleton.h"
#include "utils/vrf_selection.h"
#include "utils/vrf_trace.h"

#include "net/interface.h"
#include "net/unregister_node.h"

#include "db/db_api.h"

#include "include/logging.h"
#include "include/scope_guard.h"

#include "pb/interface.pb.h"
#include "pb/ca_protomsg.pb.h"

#include "mpt/trie.h"
#include "utils/contract_utils.h"
#include "ca/evm/evmEnvironment.h"
#include "ca/evm/evm_manager.h"
#include "common/global_data.h"
#include <boost/multiprecision/cpp_dec_float.hpp>
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/algorithm/string.hpp>
#include "ca/address_status_cache.h"

namespace {

// Legacy carrier prefix used by older nodes that smuggled the selection proof
// through tx.signature(i). New transactions use CTransaction.selection_vrf.
constexpr char kTxSelectionCarrierPrefix[] = "mm-ecvrf-selection-json:v1:";
constexpr char kTraceTxPackagerWorkflow[] = "TX_PACKAGER";
constexpr char kTraceContractDispatcherWorkflow[] = "CONTRACT_DISPATCHER";
constexpr char kTraceContractPackagerWorkflow[] = "CONTRACT_PACKAGER";
constexpr char kTraceBlockValidatorWorkflow[] = "BLOCK_VALIDATOR";
constexpr char kStageTxRequestCreate[] = "tx_request_create";
constexpr char kStageTxRequestHandle[] = "tx_request_handle";
constexpr char kStageTxPostAttachCheck[] = "tx_post_attach_check";
constexpr char kStageContractRequestCreate[] = "contract_request_create";
constexpr char kStageContractRequestHandle[] = "contract_request_handle";
constexpr char kStageBlockFlowCreate[] = "block_flow_create";
constexpr char kStageBlockFlowVerify[] = "block_flow_verify";
constexpr char kStageBlockBroadcastVerify[] = "block_broadcast_verify";

std::string BuildNormalTxSelectionInput(const CTransaction& tx);

std::string ShortTraceId(const std::string& value)
{
	if (value.empty())
	{
		return "unknown";
	}
	return value.size() <= 12 ? value : value.substr(0, 12);
}

std::string MakeTxRoundId(const CTransaction& tx, const std::string& prefix)
{
	const std::string base = tx.hash().empty() ? Getsha256Hash(BuildNormalTxSelectionInput(tx)) : tx.hash();
	return prefix + ":" + ShortTraceId(base);
}

std::string MakeContractPackagerRoundId(const std::string& allTxHashes, const uint64_t utcTime)
{
	return std::string("contract-batch:") + ShortTraceId(Getsha256Hash(allTxHashes)) + "@" + std::to_string(utcTime);
}

std::string MakeBlockRoundId(const CBlock& cblock)
{
	const std::string base = cblock.hash().empty()
		? Getsha256Hash(cblock.prevhash() + "|" + std::to_string(cblock.height()) + "|" + std::to_string(cblock.time()))
		: cblock.hash();
	return std::string("block:") + ShortTraceId(base) + "#" + std::to_string(cblock.height());
}

std::string JoinAddressesForTrace(const std::vector<std::string>& addresses)
{
	if (addresses.empty())
	{
		return "-";
	}

	std::ostringstream oss;
	for (std::size_t i = 0; i < addresses.size(); ++i)
	{
		if (i != 0)
		{
			oss << ",";
		}
		oss << addresses[i];
	}
	return oss.str();
}

std::string GetLocalVerifierTraceAddr()
{
	const std::string addr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
	return addr.empty() ? "-" : addr;
}

std::string BuildNormalTxSelectionInput(const CTransaction& tx)
{
	std::string all_hashes;
	for (const auto& txUtxo : tx.utxos())
	{
		for (int i = 0; i < txUtxo.vin_size(); ++i)
		{
			const auto& vin = txUtxo.vin(i);
			for (int j = 0; j < vin.prevout_size(); ++j)
			{
				all_hashes += vin.prevout(j).hash();
			}
		}
	}
	all_hashes += std::to_string(tx.time());
	return std::string("tx-packager-input-v1|") + all_hashes;
}

std::string BuildLegacyNormalTxSelectionSeed(const CTransaction& tx)
{
	std::string all_hashes;
	for (const auto& txUtxo : tx.utxos())
	{
		for (int i = 0; i < txUtxo.vin_size(); ++i)
		{
			const auto& vin = txUtxo.vin(i);
			for (int j = 0; j < vin.prevout_size(); ++j)
			{
				all_hashes += vin.prevout(j).hash();
			}
		}
	}
	all_hashes += std::to_string(tx.time());
	return all_hashes;
}

std::string BuildContractDispatcherInput(const CTransaction& tx)
{
	CTransaction copy = tx;
	copy.clear_identity();
	copy.clear_hash();
	copy.clear_rlp();
	copy.clear_signature();
	copy.clear_selection_vrf();
	for (int utxoIndex = 0; utxoIndex < copy.utxos_size(); ++utxoIndex)
	{
		auto* utxo = copy.mutable_utxos(utxoIndex);
		if (utxo == nullptr)
		{
			continue;
		}

		// Dispatcher selection should bind to the public contract transaction
		// content, not to node-local vin/utxo endorsements that are attached
		// afterwards by SigTx/addVerifySign.
		utxo->clear_multisign();
		for (int vinIndex = 0; vinIndex < utxo->vin_size(); ++vinIndex)
		{
			utxo->mutable_vin(vinIndex)->clear_vinsign();
		}
	}
	return Getsha256Hash(std::string("contract-dispatcher-input-v1|") + copy.SerializeAsString());
}

std::string BuildContractPackagerInput(const std::string& allTxHashes, const uint64_t utcTime)
{
	return Getsha256Hash(std::string("contract-packager-input-v1|") + std::to_string(utcTime) + "|" + allTxHashes);
}

std::string BuildBlockValidatorInput(const CBlock& cblock, const std::string& packagerAddr)
{
	CBlock copy = cblock;
	copy.clear_signature();
	copy.clear_hash();
	return Getsha256Hash(std::string("block-validator-input-v1|") + packagerAddr + "|" + copy.SerializeAsString());
}

std::vector<std::string> MapKeysToVector(const std::map<std::string, VRFStructure>& dataSource)
{
	std::vector<std::string> candidates;
	candidates.reserve(dataSource.size());
	for (const auto& item : dataSource)
	{
		candidates.push_back(item.first);
	}
	return candidates;
}

bool LegacyFindValidationNodesByTime(const uint64_t blockTime, const std::string& addr, std::vector<std::string>& validationAddrs)
{
	std::map<std::string, VRFStructure> dataSource;
	if(!MagicSingleton<VRFConsensusNode>::GetInstance()->extractVRFData(dataSource, blockTime)){
		return false;
	}

	std::string sumSeed;
	for(auto iter = dataSource.begin(); iter != dataSource.end(); ++iter){
		sumSeed += iter->second.getSignatureHash();
	}
	std::string seed = Getsha256Hash(sumSeed);
	std::vector<std::pair<std::string, VRFStructure>> datas = shuffleMap(dataSource, seed);

	auto it = std::find_if(datas.begin(), datas.end(), [&](const auto& pair) {
        return pair.first == addr;
    });
    if (it == datas.end()) {
		return false;
    }
	std::string randomSeed = it->second.getSignatureHash();
	datas.erase(it);

	validationAddrs = random_selection(datas, global::ca::send_node_threshold - 1, randomSeed);
	if(validationAddrs.empty()){
		return false;
	}

	validationAddrs.push_back(addr);
	return true;
}

std::set<std::string> CollectTxOwnerAddrs(const CTransaction& tx)
{
	std::set<std::string> owners;
	for (const auto& utxo : tx.utxos())
	{
		for (const auto& owner : utxo.owner())
		{
			if (!owner.empty())
			{
				owners.insert(owner);
			}
		}
	}
	return owners;
}

std::set<std::string> CollectTxEndorsementSigners(const CTransaction& tx)
{
	std::set<std::string> signers;
	for (const auto& utxo : tx.utxos())
	{
		for (const auto& multiSign : utxo.multisign())
		{
			if (!multiSign.pub().empty())
			{
				signers.insert(GenerateAddr(multiSign.pub()));
			}
		}
		for (const auto& vin : utxo.vin())
		{
			if (!vin.vinsign().pub().empty())
			{
				signers.insert(GenerateAddr(vin.vinsign().pub()));
			}
		}
	}
	for (const auto& signature : tx.signature())
	{
		if (!signature.pub().empty())
		{
			signers.insert(GenerateAddr(signature.pub()));
		}
	}
	return signers;
}

bool IsSelectionSelectorAllowed(const CTransaction& tx, const std::string& selectorAddr)
{
	const auto owners = CollectTxOwnerAddrs(tx);
	if (owners.find(selectorAddr) != owners.end())
	{
		return true;
	}

	// MetaMask/eth_sendRawTransaction users authorize the EVM payload with the
	// RLP signature, but their wallet key is not loaded in the node's
	// AccountManager and cannot produce the project ECVRF proof. For raw EVM
	// transactions, the node that wraps and endorses the transaction is allowed
	// to act as the VRF selector, and verifiers can see that endorsement on the
	// transaction itself.
	if (!tx.rlp().empty())
	{
		const auto signers = CollectTxEndorsementSigners(tx);
		return signers.find(selectorAddr) != signers.end();
	}

	return false;
}

bool ExtractTxSelectionProof(const CTransaction& tx, std::string& selectionVrf)
{
	if (!tx.selection_vrf().empty())
	{
		selectionVrf = tx.selection_vrf();
		return true;
	}

	for (int i = 1; i < tx.signature_size(); ++i)
	{
		const auto& signature = tx.signature(i).sign();
		if (boost::starts_with(signature, kTxSelectionCarrierPrefix))
		{
			selectionVrf = signature.substr(std::strlen(kTxSelectionCarrierPrefix));
			return true;
		}
	}
	return false;
}

bool AttachTxSelectionProof(CTransaction& tx, const std::string& selectionVrf)
{
	if (selectionVrf.empty())
	{
		return true;
	}

	std::string existing;
	if (ExtractTxSelectionProof(tx, existing))
	{
		return existing == selectionVrf;
	}

	ohi::vrf::SelectionProof parsedProof;
	std::string error;
	if (!ohi::vrf::ParseSelectionProof(selectionVrf, parsedProof, &error))
	{
		ERRORLOG("ParseSelectionProof failed: {}", error);
		return false;
	}

	tx.set_selection_vrf(selectionVrf);
	return true;
}

bool VerifyTxPackagerSelectionProofJson(const CTransaction& tx, const std::string& selectionVrf, std::string* error = nullptr, const std::string& traceStage = "")
{
	const std::string roundId = MakeTxRoundId(tx, "tx");
	const std::string input = BuildNormalTxSelectionInput(tx);
	const std::string inputHash = Getsha256Hash(input);
	std::vector<std::string> candidates;
	if (!MagicSingleton<VRFConsensusNode>::GetInstance()->extractPackagerVRFData(candidates, tx.time()))
	{
		if (error != nullptr)
		{
			*error = "failed to extract transaction packager candidate set";
		}
			ohi::vrf::trace::LogVerifyFailure(kTraceTxPackagerWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), tx.identity(), "failed to extract transaction packager candidate set");
		return false;
	}

	std::vector<std::string> selected;
	ohi::vrf::SelectionProof proof;
	if (!ohi::vrf::VerifySelectionProof(ohi::vrf::kTxPackagerRole,
										 selectionVrf,
										 candidates,
										 input,
										 1,
										 selected,
										 &proof,
										 error))
	{
		ohi::vrf::trace::LogVerifyFailure(kTraceTxPackagerWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), tx.identity(), error != nullptr ? *error : "transaction packager proof verification failed");
		return false;
	}

	if (selected.size() != 1 || selected.front() != tx.identity())
	{
		if (error != nullptr)
		{
			*error = "transaction packager proof selected a different target node";
		}
		ohi::vrf::trace::LogVerifyFailure(kTraceTxPackagerWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), tx.identity(), "transaction packager proof selected a different target node");
		return false;
	}

	if (!IsSelectionSelectorAllowed(tx, proof.selector_addr))
	{
		if (error != nullptr)
		{
			*error = "transaction packager proof selector is neither a transaction owner nor a raw transaction endorser";
		}
		ohi::vrf::trace::LogVerifyFailure(kTraceTxPackagerWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), tx.identity(), "transaction packager proof selector is neither a transaction owner nor a raw transaction endorser");
		return false;
	}

	ohi::vrf::trace::LogVerifySuccess(kTraceTxPackagerWorkflow,
									 traceStage,
									 roundId,
									 GetLocalVerifierTraceAddr(),
									 tx.identity(),
									 selected,
									 candidates.size(),
									 inputHash,
									 proof);
	return true;
}

bool VerifyContractDispatcherSelectionProofJson(const CTransaction& tx, const std::string& selectionVrf, std::string* error = nullptr, const std::string& traceStage = "")
{
	const std::string roundId = MakeTxRoundId(tx, "contract-tx");
	const std::string input = BuildContractDispatcherInput(tx);
	const std::string inputHash = Getsha256Hash(input);
	std::map<std::string, VRFStructure> dataSource;
	if (!MagicSingleton<VRFConsensusNode>::GetInstance()->extractVRFData(dataSource, tx.time()))
	{
		if (error != nullptr)
		{
			*error = "failed to extract contract dispatcher candidate set";
		}
			ohi::vrf::trace::LogVerifyFailure(kTraceContractDispatcherWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), tx.identity(), "failed to extract contract dispatcher candidate set");
		return false;
	}

	std::vector<std::string> selected;
	ohi::vrf::SelectionProof proof;
	if (!ohi::vrf::VerifySelectionProof(ohi::vrf::kContractDispatcherRole,
										 selectionVrf,
										 MapKeysToVector(dataSource),
										 input,
										 1,
										 selected,
										 &proof,
										 error))
	{
		ohi::vrf::trace::LogVerifyFailure(kTraceContractDispatcherWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), tx.identity(), error != nullptr ? *error : "contract dispatcher proof verification failed");
		return false;
	}

	if (selected.size() != 1 || selected.front() != tx.identity())
	{
		if (error != nullptr)
		{
			*error = "contract dispatcher proof selected a different dispatcher";
		}
		ohi::vrf::trace::LogVerifyFailure(kTraceContractDispatcherWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), tx.identity(), "contract dispatcher proof selected a different dispatcher");
		return false;
	}

	if (!IsSelectionSelectorAllowed(tx, proof.selector_addr))
	{
		if (error != nullptr)
		{
			*error = "contract dispatcher proof selector is neither a transaction owner nor a raw transaction endorser";
		}
		ohi::vrf::trace::LogVerifyFailure(kTraceContractDispatcherWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), tx.identity(), "contract dispatcher proof selector is neither a transaction owner nor a raw transaction endorser");
		return false;
	}

	ohi::vrf::trace::LogVerifySuccess(kTraceContractDispatcherWorkflow,
									 traceStage,
									 roundId,
									 GetLocalVerifierTraceAddr(),
									 tx.identity(),
									 selected,
									 dataSource.size(),
									 inputHash,
									 proof);
	return true;
}

bool BuildTxPackagerSelectionProofJson(const CTransaction& tx, std::string& selectionVrf, std::string* error = nullptr, const std::string& traceStage = "")
{
	const std::string roundId = MakeTxRoundId(tx, "tx");
	const std::string selectorAddr = TxHelper::SelectLocalSelectionSigner(tx);
	if (selectorAddr.empty())
	{
		if (error != nullptr)
		{
			*error = "no local transaction owner account is available to sign the transaction packager proof";
		}
		ohi::vrf::trace::LogCreateFailure(kTraceTxPackagerWorkflow, traceStage, roundId, selectorAddr, tx.identity(), "no local transaction owner account is available to sign the transaction packager proof");
		return false;
	}

	std::vector<std::string> candidates;
	if (!MagicSingleton<VRFConsensusNode>::GetInstance()->extractPackagerVRFData(candidates, tx.time()))
	{
		if (error != nullptr)
		{
			*error = "failed to extract transaction packager candidate set";
		}
			ohi::vrf::trace::LogCreateFailure(kTraceTxPackagerWorkflow, traceStage, roundId, selectorAddr, tx.identity(), "failed to extract transaction packager candidate set");
		return false;
	}

	const std::string input = BuildNormalTxSelectionInput(tx);
	const std::string inputHash = Getsha256Hash(input);
	std::vector<std::string> selected;
	if (!ohi::vrf::BuildSelectionProof(ohi::vrf::kTxPackagerRole,
											selectorAddr,
											candidates,
											input,
											1,
											selected,
											selectionVrf,
											error))
	{
		ohi::vrf::trace::LogCreateFailure(kTraceTxPackagerWorkflow, traceStage, roundId, selectorAddr, tx.identity(), error != nullptr ? *error : "transaction packager proof creation failed");
		return false;
	}

	if (selected.size() != 1 || selected.front() != tx.identity())
	{
		if (error != nullptr)
		{
			*error = "locally generated transaction packager proof does not match tx.identity";
		}
		ohi::vrf::trace::LogCreateFailure(kTraceTxPackagerWorkflow, traceStage, roundId, selectorAddr, tx.identity(), "locally generated transaction packager proof does not match tx.identity");
		return false;
	}

	ohi::vrf::SelectionProof proof;
	std::string parseError;
	if (!ohi::vrf::ParseSelectionProof(selectionVrf, proof, &parseError))
	{
		ohi::vrf::trace::LogCreateFailure(kTraceTxPackagerWorkflow, traceStage, roundId, selectorAddr, tx.identity(), std::string("failed to parse locally created proof: ") + parseError);
		if (error != nullptr)
		{
			*error = std::string("failed to parse locally created transaction packager proof: ") + parseError;
		}
		return false;
	}

	ohi::vrf::trace::LogCreate(kTraceTxPackagerWorkflow,
							  traceStage,
							  roundId,
							  selectorAddr,
							  tx.identity(),
							  selected,
							  candidates.size(),
							  inputHash,
							  proof);
	return true;
}

bool BuildContractDispatcherSelectionProofJson(const CTransaction& tx, std::string& selectionVrf, std::string* error = nullptr, const std::string& traceStage = "")
{
	const std::string roundId = MakeTxRoundId(tx, "contract-tx");
	const std::string selectorAddr = TxHelper::SelectLocalSelectionSigner(tx);
	if (selectorAddr.empty())
	{
		if (error != nullptr)
		{
			*error = "no local transaction owner account is available to sign the contract dispatcher proof";
		}
		ohi::vrf::trace::LogCreateFailure(kTraceContractDispatcherWorkflow, traceStage, roundId, selectorAddr, tx.identity(), "no local transaction owner account is available to sign the contract dispatcher proof");
		return false;
	}

	std::map<std::string, VRFStructure> dataSource;
	if (!MagicSingleton<VRFConsensusNode>::GetInstance()->extractVRFData(dataSource, tx.time()))
	{
		if (error != nullptr)
		{
			*error = "failed to extract contract dispatcher candidate set";
		}
			ohi::vrf::trace::LogCreateFailure(kTraceContractDispatcherWorkflow, traceStage, roundId, selectorAddr, tx.identity(), "failed to extract contract dispatcher candidate set");
		return false;
	}

	const std::string input = BuildContractDispatcherInput(tx);
	const std::string inputHash = Getsha256Hash(input);
	std::vector<std::string> selected;
	if (!ohi::vrf::BuildSelectionProof(ohi::vrf::kContractDispatcherRole,
											selectorAddr,
											MapKeysToVector(dataSource),
											input,
											1,
											selected,
											selectionVrf,
											error))
	{
		ohi::vrf::trace::LogCreateFailure(kTraceContractDispatcherWorkflow, traceStage, roundId, selectorAddr, tx.identity(), error != nullptr ? *error : "contract dispatcher proof creation failed");
		return false;
	}

	if (selected.size() != 1 || selected.front() != tx.identity())
	{
		const std::string reason = "locally generated contract dispatcher proof does not match tx.identity, selected:" +
								   JoinAddressesForTrace(selected) + ", tx.identity:" + tx.identity();
		if (error != nullptr)
		{
			*error = reason;
		}
		ohi::vrf::trace::LogCreateFailure(kTraceContractDispatcherWorkflow, traceStage, roundId, selectorAddr, tx.identity(), reason);
		return false;
	}

	ohi::vrf::SelectionProof proof;
	std::string parseError;
	if (!ohi::vrf::ParseSelectionProof(selectionVrf, proof, &parseError))
	{
		ohi::vrf::trace::LogCreateFailure(kTraceContractDispatcherWorkflow, traceStage, roundId, selectorAddr, tx.identity(), std::string("failed to parse locally created proof: ") + parseError);
		if (error != nullptr)
		{
			*error = std::string("failed to parse locally created contract dispatcher proof: ") + parseError;
		}
		return false;
	}

	ohi::vrf::trace::LogCreate(kTraceContractDispatcherWorkflow,
							  traceStage,
							  roundId,
							  selectorAddr,
							  tx.identity(),
							  selected,
							  dataSource.size(),
							  inputHash,
							  proof);
	return true;
}

bool BuildContractPackagerSelectionProofJson(const std::string& allTxHashes,
											 const uint64_t utcTime,
											 const std::string& expectedTargetAddr,
											 std::string& selectionVrf,
											 std::string* error = nullptr,
											 const std::string& traceStage = "")
{
	const std::string roundId = MakeContractPackagerRoundId(allTxHashes, utcTime);
	const std::string selectorAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
	if (selectorAddr.empty())
	{
		if (error != nullptr)
		{
			*error = "default account is empty";
		}
		ohi::vrf::trace::LogCreateFailure(kTraceContractPackagerWorkflow, traceStage, roundId, selectorAddr, expectedTargetAddr, "default account is empty");
		return false;
	}

	std::vector<std::string> candidates;
	if (!MagicSingleton<VRFConsensusNode>::GetInstance()->extractPackagerVRFData(candidates, utcTime))
	{
		if (error != nullptr)
		{
			*error = "failed to extract contract packager candidate set";
		}
			ohi::vrf::trace::LogCreateFailure(kTraceContractPackagerWorkflow, traceStage, roundId, selectorAddr, expectedTargetAddr, "failed to extract contract packager candidate set");
		return false;
	}

	const std::string input = BuildContractPackagerInput(allTxHashes, utcTime);
	const std::string inputHash = Getsha256Hash(input);
	std::vector<std::string> selected;
	if (!ohi::vrf::BuildSelectionProof(ohi::vrf::kContractPackagerRole,
											selectorAddr,
											candidates,
											input,
											1,
											selected,
											selectionVrf,
											error))
	{
		ohi::vrf::trace::LogCreateFailure(kTraceContractPackagerWorkflow, traceStage, roundId, selectorAddr, expectedTargetAddr, error != nullptr ? *error : "contract packager proof creation failed");
		return false;
	}

	if (selected.size() != 1 || selected.front() != expectedTargetAddr)
	{
		if (error != nullptr)
		{
			*error = "locally generated contract packager proof does not match the target packager";
		}
		ohi::vrf::trace::LogCreateFailure(kTraceContractPackagerWorkflow, traceStage, roundId, selectorAddr, expectedTargetAddr, "locally generated contract packager proof does not match the target packager");
		return false;
	}

	ohi::vrf::SelectionProof proof;
	std::string parseError;
	if (!ohi::vrf::ParseSelectionProof(selectionVrf, proof, &parseError))
	{
		ohi::vrf::trace::LogCreateFailure(kTraceContractPackagerWorkflow, traceStage, roundId, selectorAddr, expectedTargetAddr, std::string("failed to parse locally created proof: ") + parseError);
		if (error != nullptr)
		{
			*error = std::string("failed to parse locally created contract packager proof: ") + parseError;
		}
		return false;
	}

	ohi::vrf::trace::LogCreate(kTraceContractPackagerWorkflow,
							  traceStage,
							  roundId,
							  selectorAddr,
							  expectedTargetAddr,
							  selected,
							  candidates.size(),
							  inputHash,
							  proof);
	return true;
}

bool VerifyContractPackagerSelectionProofJson(const std::string& allTxHashes,
											  const uint64_t utcTime,
											  const std::string& expectedTargetAddr,
											  const std::string& expectedSelectorAddr,
											  const std::string& selectionVrf,
											  std::string* error = nullptr,
											  const std::string& traceStage = "")
{
	const std::string roundId = MakeContractPackagerRoundId(allTxHashes, utcTime);
	std::vector<std::string> candidates;
	if (!MagicSingleton<VRFConsensusNode>::GetInstance()->extractPackagerVRFData(candidates, utcTime))
	{
		if (error != nullptr)
		{
			*error = "failed to extract contract packager candidate set";
		}
			ohi::vrf::trace::LogVerifyFailure(kTraceContractPackagerWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), expectedTargetAddr, "failed to extract contract packager candidate set");
		return false;
	}

	const std::string input = BuildContractPackagerInput(allTxHashes, utcTime);
	const std::string inputHash = Getsha256Hash(input);
	std::vector<std::string> selected;
	ohi::vrf::SelectionProof proof;
	if (!ohi::vrf::VerifySelectionProof(ohi::vrf::kContractPackagerRole,
											 selectionVrf,
											 candidates,
											 input,
											 1,
											 selected,
											 &proof,
											 error))
	{
		ohi::vrf::trace::LogVerifyFailure(kTraceContractPackagerWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), expectedTargetAddr, error != nullptr ? *error : "contract packager proof verification failed");
		return false;
	}

	if (selected.size() != 1 || selected.front() != expectedTargetAddr)
	{
		if (error != nullptr)
		{
			*error = "contract packager proof selected a different target packager";
		}
		ohi::vrf::trace::LogVerifyFailure(kTraceContractPackagerWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), expectedTargetAddr, "contract packager proof selected a different target packager");
		return false;
	}

	if (!expectedSelectorAddr.empty() && proof.selector_addr != expectedSelectorAddr)
	{
		if (error != nullptr)
		{
			*error = "contract packager proof selector does not match the dispatcher identity";
		}
		ohi::vrf::trace::LogVerifyFailure(kTraceContractPackagerWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), expectedTargetAddr, "contract packager proof selector does not match the dispatcher identity");
		return false;
	}

	ohi::vrf::trace::LogVerifySuccess(kTraceContractPackagerWorkflow,
									 traceStage,
									 roundId,
									 GetLocalVerifierTraceAddr(),
									 expectedTargetAddr,
									 selected,
									 candidates.size(),
									 inputHash,
									 proof);
	return true;
}

bool BuildBlockValidatorSelectionProofJson(const CBlock& cblock,
											   const std::string& packagerAddr,
											   std::vector<std::string>& validationAddrs,
											   std::string& selectionVrf,
											   std::string* error = nullptr,
											   const std::string& traceStage = "")
{
	const std::string roundId = MakeBlockRoundId(cblock);
	std::map<std::string, VRFStructure> dataSource;
	if (!MagicSingleton<VRFConsensusNode>::GetInstance()->extractVRFData(dataSource, cblock.time()))
	{
		if (error != nullptr)
		{
			*error = "failed to extract block validator candidate set";
		}
			ohi::vrf::trace::LogCreateFailure(kTraceBlockValidatorWorkflow, traceStage, roundId, packagerAddr, packagerAddr, "failed to extract block validator candidate set");
		return false;
	}

	std::vector<std::string> candidates = MapKeysToVector(dataSource);
	candidates.erase(std::remove(candidates.begin(), candidates.end(), packagerAddr), candidates.end());
	const std::size_t validatorCount = static_cast<std::size_t>(global::ca::send_node_threshold - 1);
	const std::string input = BuildBlockValidatorInput(cblock, packagerAddr);
	const std::string inputHash = Getsha256Hash(input);

	std::vector<std::string> selected;
	if (!ohi::vrf::BuildSelectionProof(ohi::vrf::kBlockValidatorRole,
											packagerAddr,
											candidates,
											input,
											validatorCount,
											selected,
											selectionVrf,
											error))
	{
		ohi::vrf::trace::LogCreateFailure(kTraceBlockValidatorWorkflow, traceStage, roundId, packagerAddr, packagerAddr, error != nullptr ? *error : "block validator proof creation failed");
		return false;
	}

	validationAddrs = selected;
	validationAddrs.push_back(packagerAddr);
	ohi::vrf::SelectionProof proof;
	std::string parseError;
	if (!ohi::vrf::ParseSelectionProof(selectionVrf, proof, &parseError))
	{
		ohi::vrf::trace::LogCreateFailure(kTraceBlockValidatorWorkflow, traceStage, roundId, packagerAddr, JoinAddressesForTrace(validationAddrs), std::string("failed to parse locally created proof: ") + parseError);
		if (error != nullptr)
		{
			*error = std::string("failed to parse locally created block validator proof: ") + parseError;
		}
		return false;
	}

	ohi::vrf::trace::LogCreate(kTraceBlockValidatorWorkflow,
							  traceStage,
							  roundId,
							  packagerAddr,
							  JoinAddressesForTrace(validationAddrs),
							  validationAddrs,
							  candidates.size(),
							  inputHash,
							  proof);
	return true;
}

bool VerifyBlockValidatorSelectionProofJson(const CBlock& cblock,
											const std::string& packagerAddr,
											const std::vector<std::string>& getValidationAddrs,
											const std::string& selectionVrf,
											std::string* error = nullptr,
												const std::string& traceStage = "")
{
	const std::string roundId = MakeBlockRoundId(cblock);
	std::map<std::string, VRFStructure> dataSource;
	if (!MagicSingleton<VRFConsensusNode>::GetInstance()->extractVRFData(dataSource, cblock.time()))
	{
		if (error != nullptr)
		{
			*error = "failed to extract block validator candidate set";
		}
			ohi::vrf::trace::LogVerifyFailure(kTraceBlockValidatorWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), JoinAddressesForTrace(getValidationAddrs), "failed to extract block validator candidate set");
		return false;
	}

	std::vector<std::string> candidates = MapKeysToVector(dataSource);
	candidates.erase(std::remove(candidates.begin(), candidates.end(), packagerAddr), candidates.end());
	const std::size_t validatorCount = static_cast<std::size_t>(global::ca::send_node_threshold - 1);
	const std::string input = BuildBlockValidatorInput(cblock, packagerAddr);
	const std::string inputHash = Getsha256Hash(input);

	std::vector<std::string> selected;
	ohi::vrf::SelectionProof proof;
	if (!ohi::vrf::VerifySelectionProof(ohi::vrf::kBlockValidatorRole,
											 selectionVrf,
											 candidates,
											 input,
											 validatorCount,
											 selected,
											 &proof,
											 error))
	{
		ohi::vrf::trace::LogVerifyFailure(kTraceBlockValidatorWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), JoinAddressesForTrace(getValidationAddrs), error != nullptr ? *error : "block validator proof verification failed");
		return false;
	}

	if (proof.selector_addr != packagerAddr)
	{
		if (error != nullptr)
		{
			*error = "block validator proof selector does not match the block packager";
		}
		ohi::vrf::trace::LogVerifyFailure(kTraceBlockValidatorWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), JoinAddressesForTrace(getValidationAddrs), "block validator proof selector does not match the block packager");
		return false;
	}

	std::vector<std::string> expected = selected;
	expected.push_back(packagerAddr);
	std::vector<std::string> actual = getValidationAddrs;
	std::sort(expected.begin(), expected.end());
	std::sort(actual.begin(), actual.end());
	if (expected != actual)
	{
		ohi::vrf::trace::LogVerifyFailure(kTraceBlockValidatorWorkflow, traceStage, roundId, GetLocalVerifierTraceAddr(), JoinAddressesForTrace(getValidationAddrs), "block validator proof selected a different validator set");
		return false;
	}

	ohi::vrf::trace::LogVerifySuccess(kTraceBlockValidatorWorkflow,
									 traceStage,
									 roundId,
									 GetLocalVerifierTraceAddr(),
									 JoinAddressesForTrace(getValidationAddrs),
									 expected,
									 candidates.size(),
									 inputHash,
									 proof);
	return true;
}

}  // namespace


int get_balance_by_utxo(const std::string & address, const std::string & assetType, uint64_t &balance)
{
	
	if (address.size() == 0)
	{
		return -1;
	}

	DBReader dbReader;
	std::vector<std::string> addr_utxo_hashes;
	if(DBStatus::DB_SUCCESS != dbReader.getUtxoHashsByAddress(address, assetType, addr_utxo_hashes))
	{
		ERRORLOG("getUtxoHashsByAddress failed! address :{}, assetType:{}",address,assetType);
		return -2;
	}

	std::sort(addr_utxo_hashes.begin(), addr_utxo_hashes.end());
	addr_utxo_hashes.erase(std::unique(addr_utxo_hashes.begin(), addr_utxo_hashes.end()), addr_utxo_hashes.end()); 

	for (const auto &utxoHash : addr_utxo_hashes)
	{
		std::string addressBalance;
		if (DBStatus::DB_SUCCESS != dbReader.getUtxoValueByUtxoHashes(utxoHash, address, assetType, addressBalance))
		{
			return -3;
		}
		uint64_t stakeValue = 0;
		std::string underline = "_";
		std::vector<std::string> utxoValues;

		if(addressBalance.find(underline) != std::string::npos)
		{
			StringUtil::SplitString(addressBalance, "_", utxoValues);
			
			for(int i = 0; i < utxoValues.size(); ++i)
			{
				stakeValue += std::stol(utxoValues[i]);
			}

			balance += stakeValue;
		}
		else
		{
			balance +=  std::stol(addressBalance);
		}
	}
	return 0;
}


bool txConsensusCheckStatus(const CTransaction &tx)
{
	bool isStake = false, isDelegating = false, isBonus = false;
	global::ca::TxType txType = (global::ca::TxType)tx.type();
	switch (txType) {
		case global::ca::TxType::STAKE:
			isStake = true;
			break;
		case global::ca::TxType::DELEGATE:
			isDelegating = true;
			break;
		case global::ca::TxType::BONUS:
			isBonus = true;
			break;
		default:
			break;
	}

	bool isAccountInitialized = false;
	std::set<std::string> transactionOwners = TxHelper::getTransactionOwner(tx);
	if (transactionOwners.size() == 1 && transactionOwners.end() != find(transactionOwners.begin(), transactionOwners.end(), GetInitAccountAddr()))
	{
		isAccountInitialized = true;
	}

	DBReader dbReader;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return true;
    }

	return ((isStake || isDelegating || isAccountInitialized) && (top < global::ca::MIN_UNSTAKE_HEIGHT));
}

TransactionType GetTransactionType(const CTransaction &tx)
{
	if (tx.type() == (uint32_t)global::ca::TxType::GENESIS)
	{
		return kTransactionTypeGenesis;
	}
	return kTransactionTypeTx;
	// if (tx.type() == (uint32_t)global::ca::TxType::TX)
	// {
	// 	return kTransactionTypeTx;
	// }
	// return TRANSACTION_TYPE_UNKNOWN;
}

bool checkTop(int top)
{
	uint64_t mytop = 0;
	DBReader dbReader;
	dbReader.getBlockTop(mytop);

	if (top < (int)mytop - 9)
	{
		ERRORLOG("checkTop fail other top:{} my top:{}", top, (int)mytop);
		return false;
	}
	else if (top > (int)mytop + 1)
	{
		ERRORLOG("checkTop fail other top:{} my top:{}", top, (int)mytop);
		return false;
	}
	else
	{
		return true;
	}
}

int VerifyTxIdentity(const CBlock& block, const std::string& traceStage = "")
{
	for (auto &tx : block.txs())
	{
		std::string selectionVrf;
		const bool hasSelectionProof = ExtractTxSelectionProof(tx, selectionVrf);
		bool isProxy = true;
		for(auto &utxo:tx.utxos())
		{
			for(const auto& sig : utxo.multisign())
			{
				if(GenerateAddr(sig.pub()) == tx.identity())
				{
					isProxy = false;
					break;
				}
			}
		}

		// RFC 9381 proof verification must not depend on the legacy "proxy
		// transaction" heuristic. When the transaction carries a selection proof,
		// every block-flow verifier should validate it, even if the selected
		// packager/dispatcher is also one of the original signers.
		if(isProxy || hasSelectionProof)
		{
			global::ca::TxType txType = (global::ca::TxType)tx.type();
			if(global::ca::TxType::CALL == txType || global::ca::TxType::DEPLOY == txType)
			{
				auto ret = ContractVerifier(tx, selectionVrf, traceStage);
				if(ret != 0)
				{
					ERRORLOG("ContractVerifier fail!!! ,txHash:{}, ret:{}",tx.hash(), ret);
					return -2;
				}
			}
			else
			{
				auto ret = VerifyBlockPackager(tx, traceStage);
				if(ret != 0)
				{
					ERRORLOG("VerifyBlockPackager fail!!! ,txHash:{}, ret:{}",tx.hash(), ret);
					return -1;
				}
			}
		}
	}
	return 0;
}

int handleBuildBlockBroadcastMessage(const std::shared_ptr<BuildBlockBroadcastMsg> &msg, const MsgData &msgData)
{
	if (0 != Util::IsVersionCompatible(msg->version()))
	{
		ERRORLOG("handleBuildBlockBroadcastMessage IsVersionCompatible");
		return -1;
	}

	std::string serBlock = msg->blockraw();
	CBlock block;
	if (!block.ParseFromString(serBlock))
	{
		ERRORLOG("handleBuildBlockBroadcastMessage block ParseFromString failed");
		return -2;
	}
	
	if(!MagicSingleton<BlockManager>::GetInstance()->addBlock(block.hash()))
	{
		DEBUGLOG("Block repetition, blockHash:{}", block.hash());
		return 0;
	}
    DEBUGLOG("handleBuildBlockBroadcastMessage: addBlock{}", block.hash().substr(0, 6));
	
	DBReader reader;
	uint64_t newTop = 0;
	static const uint64_t block_pool_cache_height = 10000;
	if (reader.getBlockTop(newTop) == DBStatus::DB_SUCCESS)
	{
		if (block.height() >= newTop && block.height() - newTop > block_pool_cache_height)
		{
			return -3;
		}
	}

	if(ca_algorithm::verifyPreSaveBlock_(block) != 0)
	{
		ERRORLOG("Verify PreSave Block fail!");
		return -4;
	}

	bool isVerify = false;
	
	for (auto &tx : block.txs())
	{
		bool transactionConsensusStatus = txConsensusCheckStatus(tx);
		if(!transactionConsensusStatus)
		{
			isVerify = true;
			break;
		}
	}
	DEBUGLOG("isVerify:{}, top:{}", isVerify, newTop);
	if(isVerify && newTop >= global::ca::MIN_UNSTAKE_HEIGHT)
	{
		for (auto &sign : block.signature())
		{
			//Verification of Delegating and pledge
			bool canReward = VerifyBonusAddr(GenerateAddr(sign.pub()));
			//int64_t stakeTime = ca_algorithm::GetPledgeTimeByAddr(GenerateAddr(sign.pub()), global::ca::StakeType::STAKE_TYPE_NODE);
			if (!canReward)
			{
				//ERRORLOG("id:{}, stakeTime:{}, ret:{}", GenerateAddr(sign.pub()),stakeTime, ret );
				return -5;
			}
		}
	}

    std::future<int> taskResults = std::async(std::launch::async, [block] {
        return VerifyTxIdentity(block, kStageBlockBroadcastVerify);
    });

	int ret = VerifyBlockSign(block);
	if (ret != 0)
	{
		ERRORLOG("VerifyBlockSign fail, ret: {}", ret);
		return -6;
	}
	// Build-block broadcast needs the full validator flow set, not only the
	// final signatures recorded in the block. The final block stores
	// `kConsensus` signatures, while the validator flow may contain
	// `send_node_threshold` nodes.
	std::vector<std::string> getValidationAddrs(msg->verifyaddrs().begin(), msg->verifyaddrs().end());

	std::string defalutAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
	bool isVerified = false;
	for (auto &sign : block.signature())
	{
		std::string signAddr = GenerateAddr(sign.pub());
		if(signAddr == defalutAddr)
		{
			isVerified = true;
		}
		if (getValidationAddrs.empty())
		{
			// Backward-compatible fallback for historical broadcasts that do
			// not carry the full validator flow set.
			getValidationAddrs.push_back(signAddr);
		}
	}

	//区块签名节点 在快流转的时候 已经验证过了 这就不需要验证了
	if(!isVerified)
	{
		std::string packagerAddr = GenerateAddr(block.signature(0).pub());
		ret = VerifyBlockSignatureNodeSelection(block, packagerAddr, getValidationAddrs, msg->validator_vrf(), kStageBlockBroadcastVerify);
		if (ret != 0)
		{
			ERRORLOG("handleBuildBlockBroadcastMessage, VerifyBlockSignatureNodeSelection ret : {}", ret);
			return -6;
		}

		// 验证分发者的VRF证明（dispatcher_vrf）
		if (!msg->dispatcher_vrf().empty()) {
			DEBUGLOG("handleBuildBlockBroadcastMessage: 开始验证 dispatcher_vrf");

			// --- Partial Block: 还原原始交易集合 T ---
			std::multimap<uint64_t, std::string> full_tx_map; // time -> hash (multimap handles duplicates safely)
			
			// 1. 添加区块内的交易
			for (const auto& tx : block.txs()) {
				full_tx_map.emplace(tx.time(), tx.hash());
			}

			// 2. 如果有 ExclusionProof，添加被剔除的交易
			if (msg->has_exclusion_proof()) {
				const auto& proof = msg->exclusion_proof();

				// 安全检查 1: 签名验证
				// 需要创建一个不含签名的临时 proof 来验证（因为签名时是对不含签名的 proof 数据签名的）
				std::string proofData = confirmed_exclusion::SigningPayload(proof);
				std::string pubKey = block.signature(0).pub();

				// 构建临时的 CSign 对象用于验证
				CSign tempSign;
				tempSign.set_sign(proof.packager_signature());
				tempSign.set_pub(pubKey);

				if (ca_algorithm::VerifySign(tempSign, proofData) != 0) {
				    ERRORLOG("handleBuildBlockBroadcastMessage: ExclusionProof 签名无效!");
				    return -20;
				}
				DEBUGLOG("handleBuildBlockBroadcastMessage: ExclusionProof 签名验证通过");
				if (proof.reason_type() != EXCLUSION_REASON_UNSPECIFIED &&
					proof.reason_type() != EXCLUSION_BLOCK_GAS_LIMIT &&
					proof.reason_type() != EXCLUSION_ALREADY_CONFIRMED) {
					ERRORLOG("handleBuildBlockBroadcastMessage: unknown exclusion reason type");
					return -23;
				}
				if (proof.reason_type() == EXCLUSION_ALREADY_CONFIRMED) {
					std::string proofError;
					if (!confirmed_exclusion::VerifyConfirmedProof(block, proof, msg->dispatcher_vrf(), &proofError)) {
						ERRORLOG("handleBuildBlockBroadcastMessage: confirmed exclusion invalid: {}", proofError);
						return -24;
					}
				}

				// 安全检查 2: 时间序公平性检查 (防三明治攻击)
				if (proof.reason_type() != EXCLUSION_ALREADY_CONFIRMED && !block.txs().empty() && proof.excluded_txs_size() > 0) {
				    uint64_t max_included_time = 0;
				    uint64_t min_included_time = UINT64_MAX;
				    for(const auto& tx : block.txs()) {
				        if (tx.time() > max_included_time) max_included_time = tx.time();
				        if (tx.time() < min_included_time) min_included_time = tx.time();
				    }
				    uint64_t min_excluded_time = UINT64_MAX;
				    uint64_t max_excluded_time = 0;
				    for(const auto& ex_tx : proof.excluded_txs()) {
				        if (ex_tx.time() < min_excluded_time) min_excluded_time = ex_tx.time();
				        if (ex_tx.time() > max_excluded_time) max_excluded_time = ex_tx.time();
				    }

				    ERRORLOG("[DEBUG-TIMING-Broadcast] 时间序检查: included_txs=[{},{}], excluded_txs=[{},{}], tx_count={}, excluded_count={}",
				        min_included_time, max_included_time, min_excluded_time, max_excluded_time,
				        block.txs_size(), proof.excluded_txs_size());

				    if (min_excluded_time < max_included_time) {
				        ERRORLOG("handleBuildBlockBroadcastMessage: 时间序公平性检查失败! ExcludedTxTime({}) < IncludedTxTime({})", min_excluded_time, max_included_time);
				        return -21;
				    }
				}

				// 安全检查 3: 数学验证 (防 DDoS)
				if (proof.reason() == "BLOCK_GAS_LIMIT_EXCEEDED") {
				    if (proof.cumulative_gas_before() > global::ca::kBlockGasLimit) {
				        ERRORLOG("handleBuildBlockBroadcastMessage: 数学验证失败! cumulative_gas_before({}) > limit", proof.cumulative_gas_before());
				        return -22;
				    }
				    DEBUGLOG("handleBuildBlockBroadcastMessage: 数学验证通过 (Gas Limit Exceeded)");
				}

				// 将剔除的交易加入 map
				for (const auto& ex_tx : proof.excluded_txs()) {
				    full_tx_map.emplace(ex_tx.time(), ex_tx.hash());
				}
			}

			// --- 构建 input_hash ---
			std::string hash_concat;
			for (const auto& [timestamp, hash] : full_tx_map) {
				hash_concat += hash;
			}
			std::string input_hash = Getsha256Hash(hash_concat);

			// 关键修复：使用完整交易集合的最大时间戳（分发者VRF使用的max_time）
			// 而不是block.time()（打包者计算的区块时间）
			const uint64_t max_tx_time = full_tx_map.empty() ? 0 : full_tx_map.rbegin()->first;

			// 验证分发者选择证明（使用 max_tx_time 而不是 block.time()）
			std::string error;
			if (!VerifyContractPackagerSelectionProofJson(input_hash, max_tx_time,
															packagerAddr, "",
															msg->dispatcher_vrf(), &error, kStageBlockBroadcastVerify)) {
				ERRORLOG("handleBuildBlockBroadcastMessage: dispatcher_vrf 验证失败");
				ERRORLOG("  error: {}", error);
				return -8;
			}

			DEBUGLOG("handleBuildBlockBroadcastMessage: dispatcher_vrf 验证成功 (包含 {} 笔原始交易)", full_tx_map.size());
		} else {
			DEBUGLOG("handleBuildBlockBroadcastMessage: dispatcher_vrf 为空，跳过验证");
		}
	}

	try {
		int ret = taskResults.get();
		if (ret != 0) {
			return -7;
		}
	} catch (const std::exception& e) {
		std::cerr << e.what() << '\n';
		return -1;
	}

	DEBUGLOG("handleBuildBlockBroadcastMessage begin, block Height:{},hash:{},msg->type:{}", block.height(),block.hash().substr(0,6),msg->type());

	std::set<std::string> level1Nodes(msg->castaddrs().begin(), msg->castaddrs().end());
	if(level1Nodes.find(MagicSingleton<PeerNode>::GetInstance()->GetSelfId()) != level1Nodes.end())
	{
		MagicSingleton<BlockHelper>::GetInstance()->AddBroadcastBlock(block, true);
	}
	else
	{
		MagicSingleton<BlockHelper>::GetInstance()->AddBroadcastBlock(block);
	}

	return 0;
}


int verifyTxUtxoHeight(const CTransaction &tx, const uint64_t& txUtxoHeight)
{
	uint64_t txUtxoLocalHeight;
    auto ret = TxHelper::get_tx_utxo_height(tx, txUtxoLocalHeight);
    if(ret != 0)
    {
        ERRORLOG("get_tx_utxo_height fail!!! ret = {}", ret);
        return -1;
    }

	if(txUtxoHeight != txUtxoLocalHeight)
	{
		ERRORLOG("txUtxoHeight({}) != txUtxoLocalHeight({})", txUtxoHeight, txUtxoLocalHeight);
		return -2;
	}
	return 0;
}

int HandleTx(const std::shared_ptr<TxMsgReq> &msg, const MsgData &msgData)
{
	MagicSingleton<Benchmark>::GetInstance()->add_agent_transaction_receive_map(msg);

	std::string defaultaddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
	
	CTransaction tempTx;
	if (!tempTx.ParseFromString(msg->txmsginfo().tx()))
	{
		ERRORLOG("Failed to deserialize transaction body!");
		return -1;
	}

	//说明我不是被选择打包的节点
	if(defaultaddr != tempTx.identity())
	{	
		//尝试在自己的节点列表里看是否链接
		Node node;
		if(MagicSingleton<PeerNode>::GetInstance()->FindNode(tempTx.identity(),node))
		{
			bool sRet = NetSendMessage<TxMsgReq>(tempTx.identity(), *msg, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
			if (sRet == false)
			{
				return -2;
			}

			DEBUGLOG("Already forwarded to the packager");
			return 0;
		}
		else
		{
			DEBUGLOG("I am not a packager and I am not connected to it");
			return -3;
		}
	}

	CTransaction tx;
	int ret = handleTransaction(msg, tx);	
	if (ret != 0)
	{
		ERRORLOG("trasaction {} turnover fail {}", tx.hash(), ret);
	}
	return ret;
}


int contractTransactionRequest( const std::shared_ptr<ContractTxMsgReq>& msg, const MsgData& msgdata )
{
	DEBUGLOG("=== contractTransactionRequest START ===");
	
	if (0 != Util::IsVersionCompatible(msg->version()))
	{
		ERRORLOG("Incompatible version!");
		return -1;
	}

	CTransaction contractTx;
	if (!contractTx.ParseFromString(msg->mutable_txmsgreq()->txmsginfo().tx()))
	{
		ERRORLOG("Failed to deserialize transaction body!");
		return -2;
	}
	DEBUGLOG("contractTx hash: {}, identity: {}", contractTx.hash().substr(0, 16), contractTx.identity());

	//说明我不是被选择打包的节点
	std::string defaultaddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
	if(defaultaddr != contractTx.identity())
	{
		DEBUGLOG("I am not the contract packager (identity: {}), forwarding...", contractTx.identity());
		//尝试在自己的节点列表里看是否链接
		Node node;
		if(MagicSingleton<PeerNode>::GetInstance()->FindNode(contractTx.identity(), node))
		{
			bool sRet = NetSendMessage<ContractTxMsgReq>(contractTx.identity(), *msg, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
			if (sRet == false)
			{
				ERRORLOG("Failed to forward contract transaction to packager {}", contractTx.identity());
				return -3;
			}
			DEBUGLOG("Already forwarded to the contract packager {}", contractTx.identity());
			return 0;
		}else
		{
			ERRORLOG("I am not a contract packager and I am not connected to it");
			return -4;
		}
	}

	DEBUGLOG("I am the contract packager, verifying...");
	int ret =  ContractVerifier(contractTx, "", kStageContractRequestHandle);
	if(ret != 0)
	{
		ERRORLOG("ContractVerifier error ret :{}", ret);
		return -6;
	}

	if (TxHelper::addVerifySign(defaultaddr, contractTx) != 0)
	{
		ERRORLOG("Add verify sign fail for contract tx, txHash:{}", contractTx.hash());
		return -7;
	}

	msg->mutable_txmsgreq()->mutable_txmsginfo()->set_tx(contractTx.SerializeAsString());

	uint64_t nowTime =  MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	DEBUGLOG("nowTime - (tx time) = {}" ,(nowTime - contractTx.time()));

	MagicSingleton<ContractDispatcher>::GetInstance()->SetTimeValue(contractTx.time());

	std::vector<std::string> dependentAddress(msg->mutable_txmsgreq()->txmsginfo().contractstoragelist().begin(), msg->mutable_txmsgreq()->txmsginfo().contractstoragelist().end());
	MagicSingleton<ContractDispatcher>::GetInstance()->AddContractRequest(contractTx.hash(), dependentAddress, *msg);
    DEBUGLOG("@@@@@ Dispenser : txhash = {}  ", contractTx.hash());
	DEBUGLOG("=== contractTransactionRequest END ===");

	return 0;
}



int handleTransaction(const std::shared_ptr<TxMsgReq> &msg, CTransaction &outTx)
{
	// Judge whether the version is compatible
	if (0 != Util::IsVersionCompatible(msg->version()))
	{
		ERRORLOG("Incompatible version!");
		return -1;
	}
	
	uint64_t nodeHeight = msg->txmsginfo().nodeheight();
	uint64_t txUtxoHeight = nodeHeight;

	CTransaction tx;
	if (!tx.ParseFromString(msg->txmsginfo().tx()))
	{
		ERRORLOG("Failed to deserialize transaction body!");
		return -2;
	}
	
	DBReader dbReader;
    uint64_t top = 0;
    if (DBStatus::DB_SUCCESS != dbReader.getBlockTop(top))
    {
        ERRORLOG("db get top failed!!");
        return -3;
    }

	TxHelper::vrfAgentType type;
	global::ca::TxType txType = (global::ca::TxType)tx.type();
	bool isContractTx = false;
	if(global::ca::TxType::CALL == txType || global::ca::TxType::DEPLOY == txType)
	{
		isContractTx = true;
        if (nodeHeight != top)
        {
            DEBUGLOG("sender height {} doesn't consistent with current height {}, contract execute may fail, tx: {}", nodeHeight, top, tx.hash())
        }
	}

	bool isFund = false;
	if(global::ca::TxType::FUND == txType){
		isFund = true;
		if (nodeHeight != top)
        {
            DEBUGLOG("sender height {} doesn't consistent with current height {}, contract execute may fail, tx: {}", nodeHeight, top, tx.hash())
        }
	}

	int64_t nowTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	int ret = verifyTransactionTimeoutRequest(tx);
	if(!isContractTx && !isFund)
	{
		txUtxoHeight = msg->txmsginfo().txutxoheight();
		ret = verifyTxUtxoHeight(tx, txUtxoHeight);
		if (ret != 0)
		{
			ERRORLOG("verifyTxUtxoHeight fail!!!, ret = {}", ret);
			return -6;
		}
		if(txUtxoHeight > top && ret == 0)
		{
			DEBUGLOG("TTT txUtxoHeight:{} > top:{}, repeat commit tx, txhash:{}",txUtxoHeight, top, tx.hash());
			MagicSingleton<failedTransactionCache>::GetInstance()->Add(txUtxoHeight, *msg);
			return -4;
		}

		ret = verifyTxUtxoHeight(tx, txUtxoHeight);
		if(ret != 0)
		{
			ERRORLOG("verifyTxUtxoHeight fail!!!, ret = {}", ret);
			return -5;
		}
	}
	else
	{
		if(nodeHeight > top && ret == 0)
		{
			DEBUGLOG("TTT nodeHeight:{} > top:{}, repeat commit tx, txhash:{}",nodeHeight, top, tx.hash());
			MagicSingleton<failedTransactionCache>::GetInstance()->Add(nodeHeight, *msg);
			return -6;
		}
	}
	if(ret != 0)
	{
		ERRORLOG("tx timeout:{}", nowTime - (int64_t)tx.time());
		return -7;
	}
	
	DEBUGLOG("Start handleTransaction txHash:{}",tx.hash().substr(0,6));

	ON_SCOPE_EXIT
	{
		outTx = tx;
	};

	MagicSingleton<Benchmark>::GetInstance()->setByTxHash(tx.hash(), &nowTime, 1);

	// Judge whether the txUtxoHeight is reasonable
	if (!checkTop(nodeHeight))
	{
		ERRORLOG("Unreasonable nodeHeight!, txHeight:{}, selfTop:{}", nodeHeight, top);
		return -8;
	}

	//seek_prehash
	MagicSingleton<BlockStorage>::GetInstance()->commitLookupTask(top);
	if (msg->txmsginfo().type() != 0)
	{
		ERRORLOG("type Error!");
		return -9;
	}

	if (!isContractTx && msg->selection_vrf().empty())
	{
		DEBUGLOG("=== handleTransaction: selection_vrf 为空，生成 VRF 证明 ===");
		std::string selectionVrf;
		std::string error;
		if (!BuildTxPackagerSelectionProofJson(tx, selectionVrf, &error, kStageTxRequestCreate))
		{
			ERRORLOG("BuildTxPackagerSelectionProofJson failed before local handling, txHash:{}, error:{}", tx.hash(), error);
			return -10;
		}
		msg->set_selection_vrf(selectionVrf);
		DEBUGLOG("=== handleTransaction: selection_vrf 生成成功, size: {} ===", selectionVrf.size());
	}

	ret = verifyTransactionMessageRequest(*msg);
	if (ret != 0)
	{
		ERRORLOG("Verify fail ret{}",ret);
		return ret -10000;
	}
	std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
	if (!isContractTx && !msg->selection_vrf().empty() && !AttachTxSelectionProof(tx, msg->selection_vrf()))
	{
		ERRORLOG("AttachTxSelectionProof failed, txHash:{}", tx.hash());
		return -11;
	}
	if (TxHelper::addVerifySign(defaultAddr, tx) != 0)
	{
		ERRORLOG("Add verify sign fail");
		return -10;
	}
	msg->mutable_txmsginfo()->set_tx(tx.SerializeAsString());

	//Gets the type of transaction initiated
	if(isContractTx)
	{
		type = TxHelper::vrfAgentType_vrf;
	}
	else 
	{
		TxHelper::getTransactionStartIdentity(nodeHeight + 1, tx.time(), type);
	}
	
	if (type == TxHelper::vrfAgentType::vrfAgentType_vrf)
	{

		DEBUGLOG("addTransactionVerificationInfo txHash : {}", tx.hash());
		if(!isContractTx)
		{
			ret = VerifyBlockPackager(tx, kStageTxPostAttachCheck);
			if(ret != 0)
			{
				return -12;
			}
		}
		else
		{
			ret = ContractVerifier(tx, "", kStageTxPostAttachCheck);
		}

		if (ret != 0)
		{
			ERRORLOG("TTT I am not a transaction issuing node = {} , tx hash = {}, ret = {}", defaultAddr, tx.hash(), ret);
			return -13;
		}
	}

	ret = MagicSingleton<TransactionCache>::GetInstance()->AddCache(tx, msg);
	if (ret != 0)
	{
		ERRORLOG("add to TransactionCache fail");
		return -14;
	}
	DEBUGLOG("End handleTransaction txHash:{}",tx.hash().substr(0,6));
	return 0;
}

int ContractVerifier(const CTransaction& tx, const std::string& selectionVrf, const std::string& traceStage)
{
	DEBUGLOG("=== ContractVerifier START ===");
	DEBUGLOG("tx hash = {}, tx time: {}", tx.hash(), tx.time());
	
	// 新增：VRF验证
	if (!selectionVrf.empty()) {
		DEBUGLOG("=== 使用 VRF 验证路径 ===");
		std::string error;
		if (!VerifyTxPackagerSelectionProofJson(tx, selectionVrf, &error)) {
			ERRORLOG("=== VerifyTxPackagerSelectionProofJson 验证失败 ===");
			ERRORLOG("  tx hash: {}", tx.hash());
			ERRORLOG("  selectionVrf size: {}", selectionVrf.size());
			ERRORLOG("  error: {}", error);
			return -5;
		}
		DEBUGLOG("=== VerifyTxPackagerSelectionProofJson 验证成功 ===");
	} else {
		DEBUGLOG("=== 使用旧的时间计算路径 (calculatePackerByTime) ===");
		std::string targetAddr;
		int ret = calculatePackerByTime(tx.time(), targetAddr);
		if (ret != 0) {
			ERRORLOG("calculatePackerByTime ret : {}", ret);
			return -4;
		}

		if (tx.identity() != targetAddr) {
			ERRORLOG("Issuing node = {} not equal target node = {}", targetAddr, tx.identity());
			return -4;
		}
		DEBUGLOG("tx.identity() = {} matches targetAddr = {}", tx.identity(), targetAddr);
	}
	
	return 0;
}


std::vector<std::pair<std::string, VRFStructure>>  shuffleMap(const std::map<std::string, VRFStructure>& original_map, const std::string& seed)
{
	std::vector<std::string> keys;
	keys.reserve(original_map.size());

	for (const auto& pair : original_map) {
		keys.push_back(pair.first);
	}
	std::hash<std::string> hash_fn;
    std::seed_seq seed_seq{hash_fn(seed)};

	std::mt19937 _generator(seed_seq);
	std::shuffle(keys.begin(), keys.end(), _generator);

   std::vector<std::pair<std::string, VRFStructure>> random_container;
    for (const auto& key : keys) {
        DEBUGLOG("key {}", key);
        random_container.emplace_back(key, original_map.at(key));
    }

	return random_container;
}

uint64_t getStake(const std::string& addr) {

	uint64_t amount = 0;
	SearchStake(addr, amount, global::ca::StakeType::STAKE_TYPE_NODE);

	uint64_t delegateAmount = 0;
	MagicSingleton<ohi::ca::BonusAddrCache>::GetInstance()->getAmount(addr, delegateAmount);
	
	uint64_t stakeAmount = 0;
	stakeAmount = amount + delegateAmount;
    return stakeAmount;
}

int GetStakeAmountByTime(const std::string& address, const uint64_t& time, uint64_t& total)
{
	DBReader dbReader;

	std::string assetType;
    int ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
    if(ret != 0){
        ERRORLOG("Get Can BeRevoke AssetType fail!");
    }

	std::vector<std::string> utxos;
	auto status = dbReader.getStakeUtxoByAddr(address, assetType, utxos);
	if (DBStatus::DB_SUCCESS != status)
	{
		return -1;
	}

	for (auto &item : utxos)
	{
		std::string txRawData;
		if (DBStatus::DB_SUCCESS != dbReader.getTransactionByHash(item, txRawData))
		{
			continue;
		}
		CTransaction utxoTx;
		utxoTx.ParseFromString(txRawData);
		if(utxoTx.time() > time)
		{
			DEBUGLOG("tx time {}, input time {}", utxoTx.time(), time);
			continue;
		}
		nlohmann::json data = nlohmann::json::parse(utxoTx.data());
		nlohmann::json txInfo = data["txInfo"].get<nlohmann::json>();
		std::string txStakeTypeNet = txInfo["stakeType"].get<std::string>();

		if (txStakeTypeNet != global::ca::STAKE_TYPE_NET)
		{
			continue;
		}
				
		for (auto &utxo : utxoTx.utxos())
        {
		for (int i = 0; i < utxo.vout_size(); i++)
		{
			CTxOutput txout = utxo.vout(i);
			if (txout.addr() == global::ca::kTargetAddress)
			{
				total += txout.value();
			}
		}
		}
	}
	return 0;
}

int GetdelegateAmountByTime(const std::string& bonusAddr, const uint64_t& time, uint64_t& delegateAmount)
{
	// std::vector<std::string> addrs;
	DBReader dbReader;
	std::multimap<std::string, std::string> delegatingAddr_assetType;
    auto ret = dbReader.getDelegatingAddrAndAssetTypeByBonusAddr(bonusAddr, delegatingAddr_assetType);
    if (ret != DBStatus::DB_SUCCESS && ret != DBStatus::DB_NOT_FOUND)
    {
        DEBUGLOG("DBStatus is {}",ret);
        return -1;
    }

    for (auto & [addr, assetType ] : delegatingAddr_assetType)
    {
        std::vector<std::string> utxos;
        ret = dbReader.getDelegatingAddrUtxoByBonusAddr(bonusAddr, addr, assetType, utxos);
        if (ret != DBStatus::DB_SUCCESS && ret != DBStatus::DB_NOT_FOUND)
        {
            DEBUGLOG("DBStatus is {}",ret);
            return -2;
        }

        for (const auto &hash : utxos)
        {
            std::string strTx;
			ret = dbReader.getTransactionByHash(hash, strTx);
			if (ret != DBStatus::DB_SUCCESS)
			{
				return -3;
			}

            CTransaction tx;
            if (!tx.ParseFromString(strTx))
            {
                DEBUGLOG("parseFromString error");
                return -4;
            }
			
			if(tx.time() > time)
			{
				DEBUGLOG("tx time {}, input time {}", tx.time(), time);
				continue;
			}
			for (auto &utxo : tx.utxos())
			{
				for (int i = 0; i < utxo.vout_size(); i++)
				{
					if (utxo.vout(i).addr() == global::ca::kVirtualDelegatingAddr)
					{
						delegateAmount += utxo.vout(i).value();
						break;
					}
				}
			}
        }
    }
	return 0;
}

int64_t GetStakedelegateAmountByTime(const std::string& address, const uint64_t& time)
{
	uint64_t stakeAmount = 0;

	GetStakeAmountByTime(address, time, stakeAmount);

	uint64_t delegateAmount = 0;
	GetdelegateAmountByTime(address, time, delegateAmount);

	
    return stakeAmount + delegateAmount;
}

template<typename RandomEngine>
void shuffleInput(std::vector<std::pair<std::string, VRFStructure>>& input, RandomEngine& engine) {
    // 将unordered_map转换为vector进行打乱
    std::shuffle(input.begin(), input.end(), engine);
}

std::vector<std::string> random_selection(std::vector<std::pair<std::string, VRFStructure>>& input, int numSelections, std::string seed) {
    std::vector<std::string> selected_elements;
    if (input.size() < numSelections) {
        return selected_elements;
    }
    selected_elements.reserve(numSelections);

    std::string sumSeed = seed;
    

    // 计算总权重
    uint64_t totalWeight = 0;
    for (const auto& pair : input) {
		time_t  time_seconds = std::stoll(pair.second.getSeed());
		// 将时间戳转换成UTC时间(以微秒为单位)
		x_uint64_t timeUtcMicros = static_cast<x_uint64_t>(time_seconds) * 1000000;
		auto amount = GetStakedelegateAmountByTime(pair.first, timeUtcMicros);
		DEBUGLOG("input id:{}, amount:{}", pair.first, amount);
		totalWeight += amount;
    }

    // 随机选择 numSelections 个元素
    for (int i = 0; i < numSelections; ++i) {
        std::hash<std::string> hash_fn;
        std::seed_seq seed_seq{hash_fn(sumSeed)};
        std::mt19937_64 gen(seed_seq);
        std::uniform_int_distribution<uint64_t> dis(0, totalWeight);

        uint64_t randomWeight = dis(gen);
        uint64_t cumulativeWeight = 0;
		DEBUGLOG("totalWeight:{}, randomWeight:{}", totalWeight, randomWeight);
        auto it = input.begin();
        for (; it != input.end(); ++it) {
			time_t  time_seconds = std::stoll(it->second.getSeed());
			x_uint64_t timeUtcMicros = static_cast<x_uint64_t>(time_seconds) * 1000000;
			auto amount = GetStakedelegateAmountByTime(it->first, timeUtcMicros);
		
            cumulativeWeight += amount;
			DEBUGLOG("id:{}, cumulativeWeight:{}", it->first, cumulativeWeight);
            if (cumulativeWeight >= randomWeight) {
                break;
            }
        }

        if (it != input.end()) {
            selected_elements.push_back(it->first);
            sumSeed += it->second.getSignatureHash();

			time_t  time_seconds = std::stoll(it->second.getSeed());
			x_uint64_t timeUtcMicros = static_cast<x_uint64_t>(time_seconds) * 1000000;
			auto amount = GetStakedelegateAmountByTime(it->first, timeUtcMicros);
            totalWeight -= amount;
            input.erase(it);
        }
		shuffleInput(input, gen);
    }

    return selected_elements;
}

int find_validation_nodes(const CBlock& cblock, const std::string &addr, std::vector<std::string>& validationAddrs, std::string* selectionVrf){
	std::string localSelectionVrf;
	std::string error;
	if(!BuildBlockValidatorSelectionProofJson(cblock, addr, validationAddrs, localSelectionVrf, &error, kStageBlockFlowCreate)){
		ERRORLOG("BuildBlockValidatorSelectionProofJson failed, error: {}", error);
		return -1;
	}

	if (selectionVrf != nullptr)
	{
		*selectionVrf = std::move(localSelectionVrf);
	}
	return 0;
}

int VerifyBlockSignatureNodeSelection(const CBlock& cblock, const std::string& packagerAddr, const std::vector<std::string>& getValidationAddrs, const std::string& selectionVrf, const std::string& traceStage){
	if(getValidationAddrs.empty() || packagerAddr.empty())
	{
		return -1;
	}

	//验证本地时间不能大于块时间超过 10s
    auto localTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	uint64_t timeDiff = (localTime > cblock.time()) ? (localTime - cblock.time()) : (cblock.time() - localTime);
	
	if(timeDiff > global::ca::KtxTimeout){
		return -2;
	}

	if (selectionVrf.empty())
	{
		// Compatibility fallback: historical blocks may not carry the new VRF
		// proof yet, so they are checked with the legacy deterministic rule.
		std::vector<std::string> foundValidationAddrs;
		if (!LegacyFindValidationNodesByTime(cblock.time(), packagerAddr, foundValidationAddrs))
		{
			return -3;
		}

		std::vector<std::string> expected = foundValidationAddrs;
		std::vector<std::string> actual = getValidationAddrs;
		std::sort(expected.begin(), expected.end());
		std::sort(actual.begin(), actual.end());
		if (expected == actual)
		{
			return 0;
		}

		// Historical BuildBlockBroadcastMsg only carried the final block
		// signatures, not the full validator flow set. In that case accept the
		// signed addresses as long as they form a consensus-sized subset of the
		// expected validator flow selection.
		if (actual.size() == static_cast<std::size_t>(cblock.signature_size()) &&
			actual.size() >= static_cast<std::size_t>(global::ca::kConsensus) &&
			std::includes(expected.begin(), expected.end(), actual.begin(), actual.end()))
		{
			return 0;
		}

		return -4;
	}

	std::string error;
	if (!VerifyBlockValidatorSelectionProofJson(cblock, packagerAddr, getValidationAddrs, selectionVrf, &error, traceStage))
	{
		ERRORLOG("VerifyBlockValidatorSelectionProofJson failed, error: {}", error);
		return -5;
	}

	return 0;
}

int SearchNodeToSendMsg(BlockMsg &msg, const CBlock& cblock)
{
	std::string defalutAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
	//找验证节点 
	std::vector<std::string> validationAddrs;
	std::string validatorVrf;
	int ret = find_validation_nodes(cblock, defalutAddr, validationAddrs, &validatorVrf);
	if(ret != 0){
		ERRORLOG("find_validation_nodes fail, ret: {}", ret);
		return -1;
	}
	msg.set_validator_vrf(validatorVrf);

	std::vector<std::string> needSend;
	for(const auto addr : validationAddrs)
	{
		msg.add_verifyaddrs(addr);
		if(addr == defalutAddr)
		{
			continue;
		}

		Node node;
		if(!MagicSingleton<PeerNode>::GetInstance()->FindNode(addr,node))
		{
			needSend.push_back(addr);
		}
	}

	MagicSingleton<BlockStorage>::GetInstance()->AddBlockStatus(cblock.hash(), cblock, validationAddrs);
	
	MagicSingleton<VRF>::GetInstance()->addVerificationNodes(cblock.hash(), validationAddrs);

	for (auto &addr : validationAddrs)
	{
		std::string dbgSerialized = msg.SerializeAsString();
		WARNLOG("[DEBUG] Sending BlockMsg to {}, serialized size: {}, has_exclusion_proof: {}, blockHash:{}", 
		        addr, dbgSerialized.size(), msg.has_exclusion_proof(), cblock.hash().substr(0,6));
		NetSendMessage<BlockMsg>(addr, msg, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
	}

	if(!needSend.empty())
	{
		DEBUGLOG("Start Send To Another Node");
		ret = MagicSingleton<ResendReconnectNode>::GetInstance()->sendToAnotherNodeRequest(msg,needSend);
		if(ret != 0)
		{
			ERRORLOG("Search Node To Reconnect node fail! ret : {}",ret);
			return ret;
		}
	}
	
	return 0;
}

int SearchStake(const std::string &address, uint64_t &stakeamount, global::ca::StakeType stakeType)
{
	DBReader dbReader;

	std::string assetType;
    int ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
    if(ret != 0){
        ERRORLOG("Get Can BeRevoke AssetType fail!");
    }

	std::vector<std::string> utxos;
	DEBUGLOG("address is Search StakeItem{}", address);
	auto status = dbReader.getStakeUtxoByAddr(address, assetType, utxos);
	if (DBStatus::DB_SUCCESS != status)
	{
		ERRORLOG("getStakeAddrUtxo fail dbStatus:{}", status);
		return -1;
	}
	uint64_t total = 0;
	for (auto &item : utxos)
	{
		std::string txRawData;
		if (DBStatus::DB_SUCCESS != dbReader.getTransactionByHash(item, txRawData))
		{
			ERRORLOG("DBGetTransactionBy hash error");
			continue;
		}
		CTransaction utxoTx;
		utxoTx.ParseFromString(txRawData);
		nlohmann::json data = nlohmann::json::parse(utxoTx.data());
		nlohmann::json txInfo = data["txInfo"].get<nlohmann::json>();
		std::string txStakeTypeNet = txInfo["stakeType"].get<std::string>();

		if (stakeType == global::ca::StakeType::STAKE_TYPE_NODE && txStakeTypeNet != global::ca::STAKE_TYPE_NET)
		{
			ERRORLOG("getStakeAddrUtxo fail txStakeTypeNet:{}", txStakeTypeNet);
			continue;
		}

		for (const auto &utxo : utxoTx.utxos())
		{
			for (int i = 0; i < utxo.vout_size(); i++)
			{
				CTxOutput txout = utxo.vout(i);
				if (txout.addr() == global::ca::kTargetAddress)
				{
					total += txout.value();
				}
			}
		}
	}
	stakeamount = total;
	return 0;
}

int get_block_packager(std::string &packager, const std::string & txData, const uint64_t txTime, const std::string& selectorAddr)
{
	std::vector<std::string> dataSource;

	if(!MagicSingleton<VRFConsensusNode>::GetInstance()->extractPackagerVRFData(dataSource, txTime)){
		ERRORLOG("getblock packager -1");
		return -1;
	}
	for(auto addr: dataSource){
		DEBUGLOG("get_block_packager addr:{} , time:{}", addr, txTime);
	}

	if (dataSource.empty()) {
		ERRORLOG("getblock packager -2");
		return -2;
    }

	if (!selectorAddr.empty())
	{
		// New path: the transaction initiator proves how the packager was chosen
		// from the public candidate set visible at txTime.
		std::vector<std::string> selected;
		std::string selectionVrf;
		std::string error;
		if (!ohi::vrf::BuildSelectionProof(ohi::vrf::kTxPackagerRole,
											 selectorAddr,
											 dataSource,
											 std::string("tx-packager-input-v1|") + txData,
											 1,
											 selected,
											 selectionVrf,
											 &error))
		{
			ERRORLOG("BuildSelectionProof(tx_packager) failed, error: {}", error);
			return -3;
		}

		if (selected.size() != 1)
		{
			ERRORLOG("Unexpected tx packager selection result size: {}", selected.size());
			return -4;
		}

		packager = selected.front();
		return 0;
	}

	std::hash<std::string> hash_fn;
	std::seed_seq seed_seq{hash_fn(txData)};
	std::mt19937_64 rng(seed_seq);

    std::uniform_int_distribution<int> dist(0, dataSource.size() - 1);

    int randomIndex = dist(rng);
    packager = dataSource[randomIndex];

	std::cout << "randomIndex: " << randomIndex << std::endl;
	std::cout << "packager: " << "0x"+ packager << std::endl;
	return 0;
}

int VerifyBlockPackager(const CTransaction& tx, const std::string& traceStage)
{
	std::string selectionVrf;
	if (ExtractTxSelectionProof(tx, selectionVrf))
	{
		// Preferred path for new transactions: verify the carried RFC 9381 proof
		// instead of recomputing the old pseudo-random selection rule.
		std::string error;
		if (!VerifyTxPackagerSelectionProofJson(tx, selectionVrf, &error, traceStage))
		{
			ERRORLOG("VerifyTxPackagerSelectionProofJson failed, txHash:{}, error:{}", tx.hash(), error);
			return -10;
		}
		return 0;
	}

	DEBUGLOG("verify hash: {}", BuildLegacyNormalTxSelectionSeed(tx));
	std::vector<std::string> dataSource;
	int ret = 0;
	ON_SCOPE_EXIT
	{
		if(ret != 0){
			for(auto addr : dataSource){
				DEBUGLOG("extractPackagerVRFData addr:{} , time:{}", addr, tx.time());
			}
		}
	};

	if(!MagicSingleton<VRFConsensusNode>::GetInstance()->extractPackagerVRFData(dataSource, tx.time())){
		ret = -1;
		return -1;
	}

	if (dataSource.empty()) {
		ret = -2;
        return -2;
    }
	
	std::hash<std::string> hash_fn;
	std::seed_seq seed_seq{hash_fn(BuildLegacyNormalTxSelectionSeed(tx))};
	std::mt19937_64 rng(seed_seq);

    std::uniform_int_distribution<int> dist(0, dataSource.size() - 1);

    int randomIndex = dist(rng);
    std::string packager = dataSource[randomIndex];
	if(tx.identity() != packager)
	{	
		ret = -3;
		ERRORLOG("txhash:{}, txIdentity:{} ,packager:{}, randomIndex:{}",tx.hash(), tx.identity(), packager, randomIndex);
		return -3;
	}
	return 0;
}




int calculatePackerByTime(const uint64_t& txTime, std::string& packager)
{
	std::map<std::string, VRFStructure> dataSource;
	if(!MagicSingleton<VRFConsensusNode>::GetInstance()->extractVRFData(dataSource, txTime)){
		return -1;
	}

	std::string sumSeed;
	for(auto iter = dataSource.begin(); iter != dataSource.end(); ++iter){
		sumSeed += iter->second.getSignatureHash();
	}
	//生成32字节的种子
	std::string seed = Getsha256Hash(sumSeed); 

	std::vector<std::string> targetAddrs;
	for (const auto& pair : dataSource) {
    	targetAddrs.push_back(pair.first);
	}

	// 使用 seed 初始化随机数生成器
    std::seed_seq seq(seed.begin(), seed.end());
    std::mt19937 gen(seq);

    // 创建一个均匀分布的随机数生成器
    std::uniform_int_distribution<> dis(0, targetAddrs.size() - 1);

    // 随机选择一个 targetAddrs 中的元素
    int randomIndex = dis(gen);
    packager = targetAddrs[randomIndex];

	return 0;
}


int get_contract_distribution_manager(const CTransaction& tx, std::string& packager, const std::string& selectorAddr)
{
	(void)selectorAddr;
	const int ret = calculatePackerByTime(tx.time(), packager);
	if (ret != 0)
	{
		ERRORLOG("calculatePackerByTime failed for contract dispatcher, ret:{}, txTime:{}", ret, tx.time());
		return ret;
	}
	DEBUGLOG("get_contract_distribution_manager legacy dispatcher:{} , tx time:{}", packager, MagicSingleton<TimeUtil>::GetInstance()->FormatUTCTimestamp(tx.time()));
	return 0;
}

int verifyTransactionMessageRequest(const TxMsgReq &msg)
{
	CTransaction tx;
	if (!tx.ParseFromString(msg.txmsginfo().tx()))
	{
		ERRORLOG("Failed to deserialize transaction body!");
		return -1;
	}

	int ret = ca_algorithm::memoryVerificationTransactionRequest(tx);
	if (ret != 0)
	{
		ERRORLOG("Verify MemTransactionTx fail ret: {}", ret);
		return ret -= 1000;
	}
	ret = ca_algorithm::verifyTransactionRequest(tx, msg.txmsginfo().nodeheight() + 1);
	if (ret < 0)
	{
		ERRORLOG("Verify TransactionTx fail ret: {}", ret);
		ret -= 2000;
		ERRORLOG("The error code for verifying the transaction body in memory is:{}", ret);
		return ret;
	}

	// Judge whether it is a stake transaction
	bool isStakeTx = false;
	bool isDelegatingTransaction = false;
	bool isBonus = false;
	bool isUnStake = false;
	bool isUndelegating = false;
	bool isTransactionLocked = false; 
	bool isUnLock = false;
	bool isContractTx = false;
	global::ca::TxType txType = global::ca::TxType::UNKNOWN;

	try
	{
		txType = (global::ca::TxType)tx.type();

		if (txType == global::ca::TxType::STAKE)
		{
			isStakeTx = true;
		}
		if (txType == global::ca::TxType::DELEGATE)
		{
			isDelegatingTransaction = true;
		}
		if (txType == global::ca::TxType::BONUS)
		{
			isBonus = true;
		}
		if (txType == global::ca::TxType::UNSTAKE)
		{
			isUnStake = true;
		}
		if (txType == global::ca::TxType::UNDELEGATE)
		{
			isUndelegating = true;
		}
		if (txType == global::ca::TxType::LOCK)
		{
			isTransactionLocked = true;
		}
		if (txType == global::ca::TxType::UNLOCK)
		{
			isUnLock = true;
		}
		if (txType == global::ca::TxType::CALL || txType == global::ca::TxType::DEPLOY)
		{
			isContractTx = true;
		}
	}
	catch (...)
	{
		return -2;
	}

	// Judge whether it is a transaction initiated by the initial account number
	bool isInitAccountTx_ = false;
	for(const auto& utxo : tx.utxos())
	{
		if(isInitAccountTx_ == true)
		{
			break;
		}
		for (auto &vin : utxo.vin())
		{
			if (GenerateAddr(vin.vinsign().pub()) == GetInitAccountAddr())
			{
				isInitAccountTx_ = true;
				break;
			}
		}

		if(!tx.data().empty())
		{
			nlohmann::json dataJson = nlohmann::json::parse(tx.data());
			if (dataJson.contains("txInfo")) 
			{
				nlohmann::json txInfoJson = dataJson["txInfo"].get<nlohmann::json>();
				//越入
				ca_algorithm::FlowTxType flowTxType = ca_algorithm::GetFlowTxType(txInfoJson);
				if (flowTxType == ca_algorithm::FlowTxType::FlowInTx && utxo.vout_size() == 2 && utxo.vin_size() == 0 && tx.utxos_size() == 1)
				{
					if(utxo.vout(0).addr() == GetInitAccountAddr())
					{
						isInitAccountTx_ = true;
						break;
					}
				}
			}
		}
	}


	std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
	if (!isContractTx && !isDelegatingTransaction && !isStakeTx && !isInitAccountTx_ && !isTransactionLocked)
	{
		// If it is unpledged, it is directly judged whether he has pledged or not
		if (isUnStake)
		{
			uint64_t amount = 0;
			if (SearchStake(defaultAddr, amount, global::ca::StakeType::STAKE_TYPE_NODE) != 0)
			{
				ERRORLOG("verifyTransactionMessageRequest stake is error");
				return -3;
			}

			if (amount < global::ca::MIN_STAKE_AMOUNT)
			{
				ERRORLOG("stake amount less than MIN_STAKE_AMOUNT");
				return -4;
			}

			int64_t stakeTime = ca_algorithm::GetPledgeTimeByAddr(defaultAddr, global::ca::StakeType::STAKE_TYPE_NODE);
			if (stakeTime <= 0)
			{
				return ret - 5000;
			}
		}
		else if (isUndelegating) // If it is to solve the investment, directly judge whether he has invested
		{
			bool isSponsorNodeFlag = tx.signature().empty() || GenerateAddr(tx.signature(0).pub()) == defaultAddr;
			if (isSponsorNodeFlag || (isSponsorNodeFlag && isBonus))
			{
				bool canReward = VerifyBonusAddr(defaultAddr);
				if (!canReward)
				{
					DEBUGLOG("not a verify node");
					return ret - 4000;
				}
			}
		}
		else
		{
			int ret = CheckNodeValidity(defaultAddr);
            if(ret != 0){
                ERRORLOG("shouldUseAgent Check Verify Node Qualification fail, ret {}", ret);
				return -8;
            }
		}
	}

	std::string selectionVrf = msg.selection_vrf();
	std::string embeddedSelectionVrf;
	const bool hasEmbeddedSelectionVrf = ExtractTxSelectionProof(tx, embeddedSelectionVrf);
	if (!isContractTx && !selectionVrf.empty() && hasEmbeddedSelectionVrf && embeddedSelectionVrf != selectionVrf)
	{
		ERRORLOG("selection vrf mismatch between TxMsgReq and CTransaction payload, txHash:{}", tx.hash());
		return -9;
	}
	if (!isContractTx && selectionVrf.empty() && hasEmbeddedSelectionVrf)
	{
		selectionVrf = embeddedSelectionVrf;
	}

	if (isContractTx)
	{
		int ret = ContractVerifier(tx, "", kStageContractRequestHandle);
		if (ret != 0)
		{
			ERRORLOG("contract dispatcher legacy verification failed, txHash:{}, ret:{}", tx.hash(), ret);
			return -9;
		}
	}
	else if (!selectionVrf.empty())
	{
		std::string error;
		if (!VerifyTxPackagerSelectionProofJson(tx, selectionVrf, &error, kStageTxRequestHandle))
		{
			ERRORLOG("selection vrf verification failed, txHash:{}, error:{}", tx.hash(), error);
			return -9;
		}
	}

	return 0;
}

int IsQualifiedToUnstake(const std::string &fromAddr,
						 const std::string &utxoHash,
						 uint64_t &stakedAmount,
						 const std::string& assetType)
{
	// Query whether the account number has stake assets
	DBReader dbReader;
	std::vector<std::string> addresses;
	if (dbReader.getStakeAddr(addresses) != DBStatus::DB_SUCCESS)
	{
		ERRORLOG(RED "Get all stake address failed!" RESET);
		return -1;
	}
	if (std::find(addresses.begin(), addresses.end(), fromAddr) == addresses.end())
	{
		ERRORLOG(RED "The account number has not staked assets!" RESET);
		return -2;
	}


	//质押时判断交易类型必须是S类型
	if(ca_algorithm::AssetTypeIsOHI(assetType) != 0) return -199;

	int ret =  ca_algorithm::GetAssetTypeIsValid(assetType);
	if(ret != 0){
		ERRORLOG("GetAssetTypeIsValid error, error num:{}", ret);
		return -198;
	}

	// Query whether the utxo to be de stake is in the staked utxo
	std::vector<std::string> utxos;
	if (dbReader.getStakeUtxoByAddr(fromAddr, assetType, utxos) != DBStatus::DB_SUCCESS)
	{
		ERRORLOG(RED "Get stake utxo from address failed!" RESET);
		return -3;
	}
	if (std::find(utxos.begin(), utxos.end(), utxoHash) == utxos.end())
	{
		ERRORLOG(RED "The utxo to be de staked is not in the staked utxo!" RESET);
		return -4;
	}

	// Check whether the stake exceeds 30 days
	if (isMoreThan30DaysForUnstake(utxoHash) != true)
	{
		ERRORLOG(RED "The staked utxo is not more than 30 days" RESET);
		return -5;
	}

	std::string stakeTransaction;
	if (DBStatus::DB_SUCCESS != dbReader.getTransactionByHash(utxoHash, stakeTransaction))
	{
		ERRORLOG(RED "Stake tx not found!" RESET);
		return -6;
	}

	CTransaction StakeTx;
	if (!StakeTx.ParseFromString(stakeTransaction))
	{
		ERRORLOG(RED "Failed to parse transaction body!" RESET);
		return -7;
	}
	for (const auto &utxo : StakeTx.utxos())
	{
		for (int i = 0; i < utxo.vout_size(); i++)
		{
			if (utxo.vout(i).addr() == global::ca::kTargetAddress)
			{
				stakedAmount = utxo.vout(i).value();
				break;
			}
		}
	}

	if (stakedAmount == 0)
	{
		ERRORLOG(RED "Stake value is zero!" RESET);
		return -8;
	}

	// uint64_t height = 0;
	// transactionDiscoveryHeight(height);
	// if (height < global::ca::MIN_UNSTAKE_HEIGHT) {
    //       SetRpcError("-108", "UnStake is lower than the height!");
    //       ERRORLOG("UnStake is lower than the height!");
    //       return -9;
	// }
    return 0;
}

int IsQualifiedToUnLock(const std::string& fromAddr, const std::string& utxoHash, uint64_t& lockedAmount , const std::string& assetType)
{
	DBReader dbReader;
	std::vector<std::string> addresses;
	if (dbReader.getLockAddr(addresses) != DBStatus::DB_SUCCESS)
	{
		ERRORLOG(RED "Get all lock address failed!" RESET);
		return -1;
	}
	if (std::find(addresses.begin(), addresses.end(), fromAddr) == addresses.end())
	{
		ERRORLOG(RED "The account number has not locked assets!" RESET);
		return -2;
	}

	std::vector<std::string> utxos;
	if (dbReader.getLockAddrUtxo(fromAddr, assetType, utxos) != DBStatus::DB_SUCCESS)
	{
		ERRORLOG(RED "Get lock utxo from address failed!" RESET);
		return -3;
	}
	if (std::find(utxos.begin(), utxos.end(), utxoHash) == utxos.end())
	{
		ERRORLOG(RED "The utxo to be de locked is not in the locked utxo!" RESET);
		return -4;
	}

	if (isMoreThan30DaysForUnstake(utxoHash) != true)
	{
		ERRORLOG(RED "The locked utxo is not more than 30 days" RESET);
		return -5;
	}

	std::string stakeTransaction;
	if (DBStatus::DB_SUCCESS != dbReader.getTransactionByHash(utxoHash, stakeTransaction))
	{
		ERRORLOG(RED "Lock tx not found!" RESET);
		return -6;
	}

	CTransaction stakeTx;
	if (!stakeTx.ParseFromString(stakeTransaction))
	{
		ERRORLOG(RED "Failed to parse transaction body!" RESET);
		return -7;
	}
	for(const auto &utxo : stakeTx.utxos())
	{	
		for (int i = 0; i < utxo.vout_size(); i++)
		{
			if (utxo.vout(i).addr() == global::ca::VIRTUAL_LOCK_ADDRESS)
			{
				lockedAmount = utxo.vout(i).value();
				break;
			}
		}
	}
	
	if (lockedAmount < global::ca::LOCK_AMOUNT * global::ca::kDecimalNum)
	{
		ERRORLOG("Lock value error, lockedAmount:{}: ", lockedAmount);
		return -8;
	}

	return 0;
}


int evaluateBonusEligibility(const std::string& BonusAddr, const uint64_t& txTime, bool checkAnomaly)
{
	DBReader dbReader;
	uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	uint64_t zeroTime = MagicSingleton<TimeUtil>::GetInstance()->GetMorningTime(curTime)*1000000;//Convert to subtle
	uint64_t errorTime = curTime + global::ca::kClaimTxTimeFutureTolerance;
	if(checkAnomaly) 
	{
		if(txTime > errorTime || txTime < (zeroTime + global::ca::kClaimDailyWindowStartOffset))
		{
			return -1;
		}
	}
	else
	{
		if(txTime > errorTime)
		{
			return -2;
		}
	}

	std::vector<std::string> utxos;
	uint64_t Period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(txTime);
	auto status =  dbReader.getBonusUtxoByPeriod(Period, utxos);
	if (status != DBStatus::DB_SUCCESS && status != DBStatus::DB_NOT_FOUND)
	{
		return -3;
	}
	
	if(status == DBStatus::DB_SUCCESS)
	{
		std::string strTx;
		CTransaction Claimtx;
		
		for(auto utxo = utxos.rbegin(); utxo != utxos.rend(); utxo++)
		{
			if (dbReader.getTransactionByHash(*utxo, strTx) != DBStatus::DB_SUCCESS)
			{
				MagicSingleton<BlockHelper>::GetInstance()->pushMissUtxo(*utxo);
				return -4;
			}	
			if(!Claimtx.ParseFromString(strTx))
			{
				return -5;
			}
			for(const auto& claimUtxo : Claimtx.utxos())
			{
				if(claimUtxo.gas() == global::ca::UtxoGasType::UTXO_GAS_TYPE_TRUE)
				{
					continue;
				}
				std::string ClaimAddr = GenerateAddr(claimUtxo.vin(0).vinsign().pub());
				if(BonusAddr == ClaimAddr)
				{
					return -6;
				}
			}
		}
	}

	// The total number of delegatingors must be more than 10 before they can apply for it
	auto ret = CheckNodeValidity(BonusAddr);
	if(ret != 0)
	{
		ERRORLOG("CheckNodeValidity fail, code: {}", ret);
		return -7;
	}
	
	return 0;
}


int CheckFundQualificationAndGetRewardAmount(const std::string& FundAddr, const uint64_t& txTime,uint64_t& lockedAmonut, bool checkAnomaly)
{
	DBReader dbReader;
	uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	uint64_t zeroTime = MagicSingleton<TimeUtil>::GetInstance()->GetMorningTime(curTime)*1000000;//Convert to subtle
	uint64_t errorTime = curTime + global::ca::kClaimTxTimeFutureTolerance;
	if(checkAnomaly) 
	{
		if(txTime > errorTime || txTime < (zeroTime + global::ca::kClaimDailyWindowStartOffset))
		{
			return -1;
		}
	}
	else
	{
		if(txTime > errorTime)
		{
			return -2;
		}
	}

	//判断一下在这个周期内是否已经申领过前一日的国库奖励
	std::vector<std::string> fundUtxos;
	uint64_t Period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(txTime);
	auto status =  dbReader.getFundUtxoByPeriod(Period, fundUtxos);
	if(status != DBStatus::DB_SUCCESS && status != DBStatus::DB_NOT_FOUND)
	{
		ERRORLOG("getBonusUtxoByPeriod fail.");
		return -3;
	}

	if(status == DBStatus::DB_SUCCESS)
	{
		std::string strTx;
		CTransaction fundTx;
		
		for(auto utxo = fundUtxos.rbegin(); utxo != fundUtxos.rend(); utxo++)
		{
			if (dbReader.getTransactionByHash(*utxo, strTx) != DBStatus::DB_SUCCESS)
			{
				MagicSingleton<BlockHelper>::GetInstance()->pushMissUtxo(*utxo);
				return -4;
			}	
			if(!fundTx.ParseFromString(strTx))
			{
				return -5;
			}

			if(FundAddr == fundTx.utxos(0).owner(0)){
				return -6;
			}
		}
	}
	
	//如果没有申领过前一日的国库奖励 获取已经满足24h的锁定的资产总额是多少
	std::vector<std::string> utxos;
	auto ret = dbReader.getLockAddrUtxo(FundAddr, global::ca::ASSET_TYPE_OHI,utxos);
	if(ret != DBStatus::DB_SUCCESS)
	{
		ERRORLOG("fromaddr not lock!");
	}

	uint64_t totalValue = 0;
	for (auto &utxo : utxos) {
        
        std::string txRaw;
        if(DBStatus::DB_SUCCESS != dbReader.getTransactionByHash(utxo, txRaw))
        {
            return -8;
			ERRORLOG("get transaction error.");
        }
        CTransaction tx;
        if(!tx.ParseFromString(txRaw))
        {
			ERRORLOG("prase transaction error.");
			return -9;
        }

		if ((txTime - tx.time()) < global::ca::kFundClaimLockPeriod)
		{
			ERRORLOG("The asset lock time does not exceed 24 hours.");
		}

        for(const auto & txUtxo : tx.utxos())
        {
            for (auto &vout : txUtxo.vout()) 
            {
                if (vout.addr() == global::ca::VIRTUAL_LOCK_ADDRESS) 
                {
                    totalValue += vout.value();
                }
            }
        }
    }
	lockedAmonut = totalValue;

	return 0;
}

int CheckDelegatingQualification(const std::string& fromAddr, const std::string& toAddr, const std::string& assetType, uint64_t delegateAmount)
{
	// Each delegatingor can only delegating once

	// if(assetType == global::ca::ASSET_TYPE_OHI)
	// {
	// 	SetRpcError("-10", "The asset type is " + global::ca::ASSET_TYPE_OHI);
	// 	ERRORLOG(RED "The asset type is Vote!" RESET);
	// 	return -10;
	// }

	DBReader dbReader;
	std::multimap<std::string, std::string> bonusAddr_assetType;
	auto status = dbReader.getBonusAddrAndAssetTypeByDelegatingAddr(fromAddr, bonusAddr_assetType);
	if (status == DBStatus::DB_SUCCESS && !bonusAddr_assetType.empty())
	{
		ERRORLOG(RED "The delegatingor have already delegatinged in a node!" RESET);
		return -1;
	}

	// Each delegatingor shall not delegating less than 99 yuan
	if (delegateAmount < global::ca::kMinDelegatingAmt)
	{
		ERRORLOG(RED "The Delegating amount is less than 35" RESET);
		return -2;
	}




	// The node to be delegatinged must have spent 999 to access the Internet
	// int64_t stakeTime = ca_algorithm::GetPledgeTimeByAddr(toAddr, global::ca::StakeType::STAKE_TYPE_NODE);
	bool isStake=MagicSingleton<ohi::utils::AddressStatusCache>::GetInstance()->isStaked(toAddr);
	if (isStake == false)
	{
        
		ERRORLOG(RED "The account to be delegatinged has not spent 500 to access the Internet!" RESET);
		return -3;
	}

	// The node to be delegatinged can only be delegatinged by 999 people at most
	std::vector<std::string> addresses;
	std::multimap<std::string, std::string> addresses_assetType;
	status = dbReader.getDelegatingAddrAndAssetTypeByBonusAddr(toAddr, addresses_assetType);
	if (status != DBStatus::DB_SUCCESS && status != DBStatus::DB_NOT_FOUND)
	{
		ERRORLOG(RED "Get delegating addrs by node failed!" RESET);
		return -4;
	}
	if (addresses_assetType.size() > global::ca::kMaximum_number_of_investments)
	{
		ERRORLOG(RED "The account number to be delegatinged have been delegatinged by 9999 people!" RESET);
		return -5;
	}
   
	// The node to be delegatinged can only be be delegatinged 100000 at most
	uint64_t sumdelegateAmount = 0;

	for (auto &[delegatingAddr, assetType] : addresses_assetType)
	{
		std::vector<std::string> utxos;
		if (dbReader.getDelegatingAddrUtxoByBonusAddr(toAddr, delegatingAddr, assetType, utxos) != DBStatus::DB_SUCCESS)
		{
			ERRORLOG("getDelegatingAddrUtxoByBonusAddr failed!");
			return -6;
		}

		for (const auto &utxo : utxos)
		{
			std::string strTx;
			if (dbReader.getTransactionByHash(utxo, strTx) != DBStatus::DB_SUCCESS)
			{
				ERRORLOG("getTransactionByHash failed!");
				return -7;
			}

			CTransaction tx;
			if (!tx.ParseFromString(strTx))
			{
				ERRORLOG("Failed to parse transaction body!");
				return -8;
			}
			for(auto &txUtxo : tx.utxos())
			{
				for(auto &vout: txUtxo.vout()){
					if (vout.addr() == global::ca::kVirtualDelegatingAddr)
					{
						sumdelegateAmount += vout.value();
						break;
					}
				}
			}
		}
	}
	if (sumdelegateAmount + delegateAmount > global::ca::KInvestmentCap)
	{
		ERRORLOG(RED "The total amount delegatinged in a single node will be more than 3500000!" RESET);
		return -9;
	}
	return 0;
}

int IsQualifiedToUndelegating(const std::string &fromAddr, const std::string &assetType, const std::string &toAddr,
							  const std::string &utxoHash, uint64_t &delegatingedAmount)
{
	// Query whether the account has delegatinged assets to node

	// if(assetType == global::ca::ASSET_TYPE_OHI)
	// {
	// 	SetRpcError("-10", "The asset type is " + global::ca::ASSET_TYPE_OHI);
	// 	ERRORLOG(RED "The asset type is Vote!" RESET);
	// 	return -10;
	// }

	DBReader dbReader;
	std::multimap<std::string, std::string> bonusAddr_assetType;
	if (dbReader.getBonusAddrAndAssetTypeByDelegatingAddr(fromAddr, bonusAddr_assetType) != DBStatus::DB_SUCCESS)
	{
		ERRORLOG("getBonusAddrAndAssetTypeByDelegatingAddr failed!");
		return -1;
	}

	auto find_iter = std::find_if(bonusAddr_assetType.begin(), bonusAddr_assetType.end(), [&toAddr, &assetType](const auto & p){return p.first == toAddr && p.second == assetType;});
	if (find_iter == bonusAddr_assetType.end())
	{
		ERRORLOG(RED "The account has not delegatinged assets to node!" RESET);
		return -2;
	}
	// Query whether the utxo to Undelegating is in the utxos that have been delegatinged
	std::vector<std::string> utxos;
	if (dbReader.getDelegatingAddrUtxoByBonusAddr(toAddr, fromAddr, assetType, utxos) != DBStatus::DB_SUCCESS)
	{
		ERRORLOG("getDelegatingAddrUtxoByBonusAddr failed!");
		return -3;
	}
	if (std::find(utxos.begin(), utxos.end(), utxoHash) == utxos.end())
	{
		ERRORLOG(RED "The utxo to Undelegating is not in the utxos that have been delegatinged!" RESET);
		return -4;
	}

	// Query whether the investment exceeds one day
	if (IsMoreThan1DayForUndelegating(utxoHash) != true)
	{
		ERRORLOG(RED "The delegatinged utxo is not more than 1 day!" RESET);
		return -5;
	}

	// The amount to be divested must be greater than 0
	std::string strDelegatingTx;
	if (DBStatus::DB_SUCCESS != dbReader.getTransactionByHash(utxoHash, strDelegatingTx))
	{
		ERRORLOG("Delegating tx not found!");
		return -6;
	}
	CTransaction delegatingedTx;
	if (!delegatingedTx.ParseFromString(strDelegatingTx))
	{
		ERRORLOG("Failed to parse transaction body!");
		return -7;
	}

	nlohmann::json dataJson = nlohmann::json::parse(delegatingedTx.data());
	nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();
	std::string delegatinged_addr = txInfo["bonusAddr"].get<std::string>();
	if (toAddr != delegatinged_addr)
	{
		ERRORLOG(RED "The node to be Undelegatinged is not delegatinged!" RESET);
		return -8;
	}

	for(const auto & utxo : delegatingedTx.utxos())
	{
		for (int i = 0; i < utxo.vout_size(); i++)
		{
			if (utxo.vout(i).addr() == global::ca::kVirtualDelegatingAddr)
			{
				delegatingedAmount = utxo.vout(i).value();
				break;
			}
		}
	}
	if (delegatingedAmount == 0)
	{
		ERRORLOG(RED "The delegatinged value is zero!" RESET);
		return -9;
	}

	return 0;


}


// Check time of the unstake, unstake time must be more than 30 days
bool isMoreThan30DaysForUnstake(const std::string &utxo)
{
	DBReader dbReader;

	std::string strTransaction;
	DBStatus status = dbReader.getTransactionByHash(utxo, strTransaction);
	if (status != DBStatus::DB_SUCCESS)
	{
		return false;
	}

	CTransaction utxoStakingAmount;
	utxoStakingAmount.ParseFromString(strTransaction);
	uint64_t nowTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	uint64_t DAYS30 = global::ca::STAKE_RELEASE_WAIT_TIME;
	if (MagicSingleton<Genesis>::GetInstance()->GetNetworkType() == Genesis::NetworkType::Dev)
	{
		DAYS30 = global::ca::DEV_RELEASE_WAIT_TIME;
	}

	return (nowTime - utxoStakingAmount.time()) >= DAYS30;
}

// Check time of the redeem, redeem time must be more than 1 day,
bool IsMoreThan1DayForUndelegating(const std::string &utxo)
{
	DBReader dbReader;

	std::string strTransaction;
	DBStatus status = dbReader.getTransactionByHash(utxo, strTransaction);
	if (status != DBStatus::DB_SUCCESS)
	{
		return -1;
	}
	CTransaction utxoStakingAmount;
	utxoStakingAmount.ParseFromString(strTransaction);
	uint64_t nowTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
	uint64_t DAY = global::ca::DELEGATE_RELEASE_WAIT_TIME;
	if (MagicSingleton<Genesis>::GetInstance()->GetNetworkType() == Genesis::NetworkType::Dev)
	{
		DAY = global::ca::DEV_RELEASE_WAIT_TIME;
	}
	return (nowTime - utxoStakingAmount.time()) >= DAY;
}

bool VerifyBonusAddr(const std::string &BonusAddr)
{
	// uint64_t delegateAmount;
	// auto ret = MagicSingleton<ohi::ca::BonusAddrCache>::GetInstance()->getAmount(BonusAddr, delegateAmount);
	// if (ret < 0)
	// {
	// 	DEBUGLOG("ret:",ret);
	// 	return -99;
	// }
	// return delegateAmount >= global::ca::kMinDelegatingAmt ? 0 : -99;

	//ohi::utils::AddressStatus st;

	// Slashing L4: Tombstoned nodes are permanently banned
	DBReader dbReader;
	std::string tombstoneVal;
	if (DBStatus::DB_SUCCESS == dbReader.readData(std::string("slash_tombstone_") + BonusAddr, tombstoneVal))
	{
		return false;  // Permanently banned
	}

	return  MagicSingleton< ohi::utils::AddressStatusCache>::GetInstance()->canReward(BonusAddr);
}

int GetDelegatingAmountAndDuration(const std::string &bonusAddr, const uint64_t &curTime, const uint64_t &zeroTime, std::multimap<std::string, std::pair<uint64_t, uint64_t>> &mpDelegatingAddr2Amount)
{
	DBReadWriter dbWriter;
	std::string strTx;
	CTransaction tx;
	std::vector<std::string> addresses;

	time_t t = curTime;
	t = t / 1000000;
	struct tm *tm = gmtime(&t);
	tm->tm_hour = 23;
	tm->tm_min = 59;
	tm->tm_sec = 59;
	uint64_t endTime = mktime(tm);
	endTime *= 1000000;

	uint64_t delegateAmount = 0;
	uint64_t delegateAmountDay = 0;
	std::multimap<std::string, std::string> addresses_assetType;

	if (dbWriter.getDelegatingAddrAndAssetTypeByBonusAddr(bonusAddr, addresses_assetType) != DBStatus::DB_SUCCESS)
	{
		return -1;
	}
	for (auto &[delegatingAddr, currency] : addresses_assetType)
	{
		std::vector<std::string> utxos;
		if (dbWriter.getDelegatingAddrUtxoByBonusAddr(bonusAddr, delegatingAddr, currency, utxos) != DBStatus::DB_SUCCESS)
		{
			return -2;
		}

		if(utxos.size() > 1 || utxos.size() <= 0)
		{
			return -3;
		}

		delegateAmount = 0;
		delegateAmountDay = 0;
		for (const auto &hash : utxos)
		{
			tx.Clear();
			if (dbWriter.getTransactionByHash(hash, strTx) != DBStatus::DB_SUCCESS)
			{
				return -4;
			}
			if (!tx.ParseFromString(strTx))
			{
				return -5;
			}
			if(curTime <= tx.time())
			{
				return -6;
			}
			if(curTime - tx.time() <= 24ull * 60 * 60 * 1000000)
			{
				DEBUGLOG("Delegating time is less than 24 hours, waiting time:{}", (curTime - tx.time()) / (60ull * 60 * 1000000));
				break;
			}
			if (tx.time() >= zeroTime && tx.time() <= endTime)
			{
				for(const auto &utxo : tx.utxos())
				{
					for (int i = 0; i < utxo.vout_size(); i++)
					{
						if (utxo.vout(i).addr() == global::ca::kVirtualDelegatingAddr)
						{
							delegateAmountDay += utxo.vout(i).value();
							delegateAmount += utxo.vout(i).value();
							break;
						}
					}
				}
			}
			else
			{
				for(const auto &utxo : tx.utxos())
				{
					for (int i = 0; i < utxo.vout_size(); i++)
					{
						if (utxo.vout(i).addr() == global::ca::kVirtualDelegatingAddr)
						{
							delegateAmount += utxo.vout(i).value();
							break;
						}
					}
				}
				break;
			}
		}
		delegateAmount = (delegateAmount - delegateAmountDay);
		if (delegateAmount == 0)
		{
			continue;
		}
		mpDelegatingAddr2Amount.insert({delegatingAddr, {delegateAmount, 0}});

	}

	/*
	  1.获取所有可用资产类型 
	  2.通过资产类型获取跨链投资合约地址 （数据库）
	  3.获取跨链投资合约部署人 （数据库）
	  4.调用跨链投资合约的std::string calldataGetToken = evm_utils::EncodeFunctionCall("originToken", {});
		std::string calldataGetInvestments = evm_utils::EncodeFunctionCall("getInvestmentsByRecipient", {{address,bonusAddr}});
		函数，获取跨链投资合约中该地址的所有投资信息*/
	std::map<std::string, TxHelper::ProposalInfo> assetMap;
	int ret  = ca_algorithm::fetchAvailableAssetType(assetMap);
	if(ret != 0){
		ERRORLOG("fetchAvailableAssetType failed, ret:{}", ret);
		return -1;
	}

	for(auto &[assetType, proposalInfo] : assetMap)
	{
		std::string crossChainInvestmentContractAddr;
		ret =  ca_algorithm::GetCrossChainInvestmentContractAddrByAssetType(assetType, crossChainInvestmentContractAddr);
		if(ret != 0){
			DEBUGLOG("assetType not support, ret:{}", ret);
			continue;
		}

		std::string deployUtxo;
		auto DBStatus_ret = dbWriter.getContractDeployUtxoByContractAddr(crossChainInvestmentContractAddr, deployUtxo);
		if (DBStatus_ret != DBStatus::DB_SUCCESS || deployUtxo.empty())
		{
			ERRORLOG("Contract address not found ret:{}", ret);
			return -2;
		}

		std::string txRaw;
		if (dbWriter.getTransactionByHash(deployUtxo, txRaw) != DBStatus::DB_SUCCESS) {
			ERRORLOG("getTransactionByHash error");
			return -2;
		}

		CTransaction tx;
		if (!tx.ParseFromString(txRaw)) {
			ERRORLOG("ParseFromString error");
			return -3;
		}

		std::string deployeraddr;
		for(const auto &utxo : tx.utxos())
		{
			deployeraddr = utxo.owner(0);
		}

		uint64_t top = 0;
		if(dbWriter.getBlockTop(top) != DBStatus::DB_SUCCESS){
			ERRORLOG("getBlockTop error");
			return -4;
		}

		std::string calldataGetInvestments = evm_utils::EncodeFunctionCall("getInvestmentsByRecipient", {{"address",bonusAddr}});
		std::string output = "";
		ret = ca_algorithm::GetVitrualDelegateInfo(bonusAddr,deployeraddr,calldataGetInvestments,top,0,crossChainInvestmentContractAddr,output);
		if(ret != 0){
			ERRORLOG("GetVitrualDelegateInfo failed, ret:{}", ret);
			return -5;
		}


		std::vector<evm_utils::InvestmentViewDecoded> investments;
		ret = evm_utils::ParseGetInvestmentsByRecipientOutputHex(output, investments);
		if (ret != 0)
		{
			ERRORLOG("parse investments failed: {}", ret);
		}
		else
		{
			// 聚合同一受益人地址的全部有效投资金额，避免同一 beneficiary 拥有多条分散记录
			std::map<std::string, uint64_t> beneficiary2Amount;
			for (const auto& it : investments)
			{
				// 时间统一（秒 -> 微秒）
				uint64_t ts_micros = 0;
				if (!evm_utils::SecondsStringToMicrosU64(it.timestamp_dec, ts_micros)) {
					ERRORLOG("bad timestamp_dec: {}", it.timestamp_dec);
					continue;
				}

				if(curTime <= ts_micros)
				{
					return -6;
				}
				if(curTime - ts_micros <= 24ull * 60 * 60 * 1000000)
				{
					DEBUGLOG("Delegating time is less than 24 hours, waiting time:{}", (curTime - ts_micros) / (60ull * 60 * 1000000));
					// 小于24小时的不计入，继续处理下一条
					continue;
				}

				// 使用纯整数计算：amount(chain_1e8) = (amount_1e18 * ExchangeRate * 1e8) / (10^{rateDecimal} * 10^{tokenDecimal})
				// 其中 tokenDecimal 固定为 18（EVM 常见精度），ExchangeRate 解析为整数 rateInt 和小数位数 rateDecimal
				boost::multiprecision::cpp_int numPart;
				try {
					numPart = boost::multiprecision::cpp_int(it.amount_dec);
				} catch (...) {
					ERRORLOG("bad amount_dec: {}", it.amount_dec);
					continue;
				}

				std::string ExchangeRate = proposalInfo.ExchangeRate;
				boost::trim(ExchangeRate);
				boost::multiprecision::cpp_int rateInt;
				int rateDecimal = 0;
				size_t pos = ExchangeRate.find('.')
				;
				if (pos != std::string::npos)
				{
					std::string integerPart = ExchangeRate.substr(0, pos);
					std::string fractionalPart = ExchangeRate.substr(pos + 1);
					// 去掉小数部分末尾的 0
					auto end = fractionalPart.find_last_not_of('0');
					if (end == std::string::npos) {
						fractionalPart.clear();
					} else {
						fractionalPart.erase(end + 1);
					}
					rateDecimal = fractionalPart.length();
					rateInt = boost::multiprecision::cpp_int(integerPart + fractionalPart);
				}
				else
				{
					rateInt = boost::multiprecision::cpp_int(ExchangeRate);
				}

				int tokenDecimal = 8;
				boost::multiprecision::cpp_int decimalNumBig = (tokenDecimal == 0)
					? boost::multiprecision::cpp_int(1)
					: boost::multiprecision::pow(boost::multiprecision::cpp_int(10), tokenDecimal);

				boost::multiprecision::cpp_int numerator = numPart * rateInt * global::ca::kDecimalNum;
				boost::multiprecision::cpp_int denominator = boost::multiprecision::pow(boost::multiprecision::cpp_int(10), rateDecimal) * decimalNumBig;
				if (denominator == 0) {
					ERRORLOG("invalid denominator when converting amount");
					continue;
				}
				boost::multiprecision::cpp_int amountTemp = numerator / denominator;
				static const boost::multiprecision::cpp_int kMaxUint64(static_cast<std::string>("18446744073709551615"));
				uint64_t amount_val = 0;
				if (amountTemp < 0 || amountTemp > kMaxUint64)
				{
					DEBUGLOG("Amount overflow: {}", amountTemp.str());
					continue;
				}
				amount_val = static_cast<uint64_t>(amountTemp);

				// 当天内(零点到23:59:59)的投资不计入有效金额
				if (ts_micros >= zeroTime && ts_micros <= endTime)
				{
					continue;
				}


				//去除前导0
				std::string __beneficiary_trim;
				{
					__beneficiary_trim = it.beneficiary_hex;
					size_t __pos = __beneficiary_trim.find_first_not_of('0');
					if (__pos == std::string::npos) {
						__beneficiary_trim = "0";
					} else if (__pos > 0) {
						__beneficiary_trim.erase(0, __pos);
					}

				}

				__beneficiary_trim = evm_utils::ToChecksumAddress(__beneficiary_trim);

				beneficiary2Amount[__beneficiary_trim] += amount_val;
			}

			for (const auto& kv : beneficiary2Amount)
			{
				if (kv.second < global::ca::kMinDelegatingAmt) { continue; }
				mpDelegatingAddr2Amount.insert({kv.first, {kv.second, 0}});
			}
		}

		/*解析此时的output
		output数据：
			0000000000000000000000000000000000000000000000000000000000000020
			0000000000000000000000000000000000000000000000000000000000000002
			2fa10208584ab97aafad98c32de6e5c674ab8b51dc4b6210c66ea04b8b791035
			0000000000000000000000000000000000000000000000c328093e61ee400000
			0000000000000000000000000000000000000000000000000000000068b657ca
			a2133dcba8fb4b2563c920eddf6cd61c9536b2ac6138960568977f23a09b9902
			0000000000000000000000000000000000000000000000c328093e61ee400000
			0000000000000000000000000000000000000000000000000000000068b65842

		解析结果：
			第一笔投资：
			发送者：0x2fa10208584ab97aafad98c32de6e5c674ab8b51dc4b6210c66ea04b8b791035
			金额：3600（原始值：3600000000000000000000）
			时间戳：1756780490（对应日期：2025-09-02 02:34:50 UTC）

			第二笔投资：
			发送者：0xa2133dcba8fb4b2563c920eddf6cd61c9536b2ac6138960568977f23a09b9902
			金额：3600（原始值：3600000000000000000000，与第一笔相同）
			时间戳：1756780610（对应日期：2025-09-02 02:36:50 UTC）*/
	}

	if (mpDelegatingAddr2Amount.empty())
	{
		return -7;
	}
	return 0;
}

int getLockedAmountAsOfTodayStart(const uint64_t &curTime, uint64_t &totalLockedAmount)
{
	DBReader dbReader;
	uint64_t lockedAmount = 0;

	{
		std::lock_guard<std::mutex> lock(global::ca::LOCK_MUTEX);
		auto ret = dbReader.getTotalLockedAmonut(totalLockedAmount);
		if(ret != DBStatus::DB_SUCCESS  && ret != DBStatus::DB_NOT_FOUND){
			ERRORLOG("Get total locked amount failed!");
			return -1;
		}else{
			DEBUGLOG("totalLockedAmount : {}",totalLockedAmount);
		}	

		uint64_t Period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(curTime);
		ret = dbReader.getTotalLockedAmountByPeriod(Period, lockedAmount);
		if(ret != DBStatus::DB_SUCCESS  && ret != DBStatus::DB_NOT_FOUND){
			ERRORLOG("Get locked amount by period failed!");
			return -2;
		}else{
			DEBUGLOG("lockedAmount : {}",lockedAmount);
		}
		DEBUGLOG("lockedAmount : {}, totalLockedAmount : {}",lockedAmount,totalLockedAmount);
	}

	if(lockedAmount > totalLockedAmount){
		ERRORLOG("The locked assets on that day are greater than the total locked assets!");
		return -3;
	}

	totalLockedAmount -= lockedAmount;

	return 0;
}



int getTotalCirculationAsOfTodayStart(const uint64_t& curTime, uint64_t &totalCirculation)
{
	DBReader dbReader;
	uint64_t Period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(curTime);
	uint64_t totalTodayclaimAmount = 0;
	std::vector<std::string> utxos;

	{
		std::lock_guard<std::mutex> lock(global::ca::bonusMutex);
		auto ret = dbReader.getTotalCirculation(totalCirculation);
		if(ret != DBStatus::DB_SUCCESS  && ret != DBStatus::DB_NOT_FOUND){
			ERRORLOG("Get total circulation failed!");
			return -1;
		}else{
			DEBUGLOG("totalCirculation : {}",totalCirculation);
		}	

		ret = dbReader.getBonusUtxoByPeriod(Period, utxos);
		if(ret != DBStatus::DB_SUCCESS && ret != DBStatus::DB_NOT_FOUND){
			ERRORLOG("Get bonus utxo by period failed!");
			return -2;
		}

		for(auto utxo : utxos){
			CTransaction tx;
			std::string strHeader;
			if (DBStatus::DB_SUCCESS != dbReader.getTransactionByHash(utxo, strHeader)) 
			{
				ERRORLOG("Get transaction by hash failed!");
				return -4;
			}

			try {
				if (!tx.ParseFromString(strHeader))
				{
					ERRORLOG("Deserialization transaction failed");
					return -3;
				}

				nlohmann::json dataJson = nlohmann::json::parse(tx.data());
				nlohmann::json txInfoJson = dataJson["txInfo"].get<nlohmann::json>();
				uint64_t claimAmount = txInfoJson["bonusAmount"].get<uint64_t>();
				totalTodayclaimAmount += claimAmount;
			} catch (const std::exception& e) {
				ERRORLOG("Exception caught: {}", e.what());
				return -5;
			}

		}
	
	}

	totalCirculation -= totalTodayclaimAmount;
	
	return 0;
}


int GetTotalDelegatingYesterday(const uint64_t &curTime, uint64_t &totaldelegating)
{
	DBReadWriter dbWriter;
	std::vector<std::string> utxos;
	std::string strTx;
	CTransaction tx;
	{
		std::lock_guard<std::mutex> lock(global::ca::kDelegatingMutex);
		auto ret = dbWriter.getTotalDelegatingAmount(totaldelegating);
		if (DBStatus::DB_SUCCESS != ret)
		{
			if (DBStatus::DB_NOT_FOUND != ret)
			{
				return -301;
			}
			else
			{
				totaldelegating = 0;
			}
		}
		uint64_t Period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(curTime);
		ret = dbWriter.getDelegatingUtxoByPeriod(Period, utxos);
		if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
		{
			return -302;
		}
	}
	uint64_t Delegating_Vout_amount = 0;
	uint64_t TotalDelegatingDay = 0;
	for (auto utxo = utxos.rbegin(); utxo != utxos.rend(); utxo++)
	{
		Delegating_Vout_amount = 0;
		if (dbWriter.getTransactionByHash(*utxo, strTx) != DBStatus::DB_SUCCESS)
		{
			return -303;
		}
		if (!tx.ParseFromString(strTx))
		{
			return -304;
		}
		for(const auto& utxo : tx.utxos())
		{
			for (auto &vout : utxo.vout())
			{
				if (vout.addr() == global::ca::kVirtualDelegatingAddr)
				{
					Delegating_Vout_amount += vout.value();
					break;
				}
			}
		}
		TotalDelegatingDay += Delegating_Vout_amount;
	}
	totaldelegating -= TotalDelegatingDay;
	return 0;
}

int getTotalBurnAmountForYesterday(const uint64_t &curTime, uint64_t &Totalburn)
{
	DBReadWriter dbWriter;
	uint64_t burnAmountDay = 0;
	{
		std::lock_guard<std::mutex> lock(global::ca::BURN_MUTEX);
		if (DBStatus::DB_SUCCESS != dbWriter.getTotalBurnAmount(Totalburn))
		{
			return -201;
		}
		uint64_t Period = MagicSingleton<TimeUtil>::GetInstance()->GetPeriod(curTime);
		auto ret = dbWriter.getBurnAmountByPeriod(Period, burnAmountDay);
		if (DBStatus::DB_SUCCESS != ret && DBStatus::DB_NOT_FOUND != ret)
		{
			return -202;
		}
	}
	DEBUGLOG("burnAmountDay:{}, Totalburn:{}", burnAmountDay, Totalburn);
	if(burnAmountDay > Totalburn)
	{
		return -203;	
	}
	Totalburn -= burnAmountDay;
	return 0;
}

void notifyNodeHeightChangeRequest()
{
	nodeHeightChangedMessage();
}

std::map<int32_t, std::string> GetMultiSignTxReqCode()
{
	std::map<int32_t, std::string> errInfo = {
		std::make_pair(0, ""),
		std::make_pair(-1, ""),
		std::make_pair(-2, ""),
		std::make_pair(-3, ""),
		std::make_pair(-4, ""),
		std::make_pair(-5, ""),
		std::make_pair(-6, ""),
	};

	return errInfo;
}

int AddBlockSign(CBlock &block)
{
	CBlock cblock = block;
	cblock.clear_signature();
	std::string serializedBlockHash = Getsha256Hash(cblock.SerializeAsString());
	std::string signature;
	std::string pub;
	std::string defalutaddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
	if (TxHelper::Sign(defalutaddr, serializedBlockHash, signature, pub) != 0)
	{
		ERRORLOG("Block flow signature failed");
		return -1;
	}

	CSign *cblocksign = block.add_signature();
	cblocksign->set_sign(signature);
	cblocksign->set_pub(pub);
	return 0;
}

int VerifyBlockSign(const CBlock &block)
{
	CBlock cblock = block;
	cblock.clear_signature();
	std::string serializedBlockHash = Getsha256Hash(cblock.SerializeAsString());
	for (auto &blockSignatureRequest : block.signature())
	{
		std::string pub = blockSignatureRequest.pub();
		std::string sign = blockSignatureRequest.sign();

		if (pub.size() == 0 || sign.size() == 0 || serializedBlockHash.size() == 0)
		{
			ERRORLOG("block flow info fail!");
			return -1;
		}

        Account account;
        if(MagicSingleton<AccountManager>::GetInstance()->getAccountPublicKeyByBytes(pub, account) == false){
			ERRORLOG(RED "Get public key from bytes failed!" RESET);
			return -2;
        }

        if(account.Verify(serializedBlockHash, sign) == false)
        {
			ERRORLOG(RED "Public key verify sign failed!" RESET);
			return -3;
        }
	}

	return 0;
}

int HandleBlock(const std::shared_ptr<BlockMsg> &msg, const MsgData &msgData)
{
	Node node;
    if(!MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(msgData.fd, node))
    {
        ERRORLOG("Invalid message ");
        return -1;
    }

	int  ret = MagicSingleton<ResendReconnectNode>::GetInstance()->DecisionBlock(*msg);
	if(ret != 0)
	{
		if(ret == 1)
		{
			DEBUGLOG("is resend ...");
			return 0;
		}
		return ret;
	}

	ret = handleBlock(msg, &node);
	if (ret != 0)
	{
		CBlock cblock;
	    if (!cblock.ParseFromString(msg->block()))
	    {
		    ERRORLOG("fail to serialization!!");   
	    }
		DEBUGLOG("handleBlock failed The error code is {} , block hash :{} ", ret, cblock.hash().substr(0, 6));
	}

	return ret;
}


int handleBlock(const std::shared_ptr<BlockMsg> &msg, Node *node)
{
	// Verify the version
	if (0 != Util::IsVersionCompatible(msg->version()))
	{
		ERRORLOG("Incompatible version!");
		return -1;
	}

	std::string defaultAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
	CBlock cblock;
	if (!cblock.ParseFromString(msg->block()))
	{
		ERRORLOG("fail to serialization!!");
		return -2;
	}

	int verifyCount = cblock.signature_size();
	if (verifyCount == 2 && defaultAddr == GenerateAddr(cblock.signature(0).pub()))
	{
		//验证 回执的人 是不是选的人
		std::vector<std::string> signatureNodes;
		auto blockSignAddress = GenerateAddr(cblock.signature(1).pub());

		if(MagicSingleton<VRF>::GetInstance()->getBlockFlowSignNodes(cblock.hash(), signatureNodes,blockSignAddress,true))
		{
			if(signatureNodes.empty()){
				return -3;
			}

			auto iter = std::find(signatureNodes.begin(), signatureNodes.end(), blockSignAddress);
			if (iter == signatureNodes.end())
			{
				ERRORLOG("Validation node not found = {} block hash = {}", blockSignAddress, cblock.hash());
				return -4;
			}

			if (MagicSingleton<BlockStorage>::GetInstance()->UpdateBlock(*msg))
			{
				ERRORLOG("UpdataBlock fail");
				return -5;
			}
		}else //说明已经收到过了 什么都不做
		{
			DEBUGLOG("already added! addr : {}",blockSignAddress);
		}

	}
	else
	{
		int ret = VerifyBlockSign(cblock);
		if (ret != 0)
		{
			ERRORLOG("VerifyBlockSign fail, ret: {}", ret);
			return -6;
		}

		// Block flow plus signature
		ret = AddBlockSign(cblock);
		if (ret != 0)
		{
			ERRORLOG("Add Block Sign fail");
			return ret -= 20;
		}

		BlockStatus blockStatus;
		ret = MagicSingleton<BlockHelper>::GetInstance()->verifyFlowedBlockStatus(cblock, &blockStatus, &*msg);
		DEBUGLOG("verifyFlowedBlockStatus blockHash:{}, ret:{}", cblock.hash().substr(0,6), ret);
		if (ret != 0)
		{
			if(verifyCount != 0)
			{
				blockStatus.set_blockhash(cblock.hash());
				blockStatus.set_status(ret);
				blockStatus.set_id(MagicSingleton<PeerNode>::GetInstance()->GetSelfId());
				std::string packagerAddr = GenerateAddr(cblock.signature(0).pub());
				if(packagerAddr != defaultAddr)
				{
					DEBUGLOG("AAAC protocolBlockStatus, packagerAddr:{}, ret:{}, blockHash:{}", packagerAddr, ret, cblock.hash().substr(0,6));
					protocolBlockStatus(blockStatus, packagerAddr);
				}
			}
			
			ERRORLOG("Verify Flowed Block fail BlockHash:{} , ret:{} ", cblock.hash().substr(0,6), ret);
			return -7;
		}

		msg->set_block(cblock.SerializeAsString());
		if (verifyCount == 0)
		{
			auto S = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
			// VRF looks for nodes to send block flows
			ret = SearchNodeToSendMsg(*msg, cblock);
			if (ret != 0)
			{
				ERRORLOG("Search Node To SendMsg fail, ret :{}", ret);
				return -10;
			}
			if (MagicSingleton<BlockStorage>::GetInstance()->AddBlock(*msg))
			{
				ERRORLOG("Add Block  fail)");
				return -9;
			}
			auto E = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
			uint64_t node_search_duration = E - S;
    		MagicSingleton<Benchmark>::GetInstance()->setByBlockHash(cblock.hash(), &node_search_duration, 7, &E);
		}
		else if (verifyCount == 1)
		{
			std::string packagerAddr = GenerateAddr(cblock.signature(0).pub());

			// 新增：验证分发者的VRF证明（dispatcher_vrf）
			if (!msg->dispatcher_vrf().empty()) {
				DEBUGLOG("=== 开始验证 dispatcher_vrf ===");

				// --- Partial Block: 还原原始交易集合 T ---
				std::multimap<uint64_t, std::string> full_tx_map;
				for (const auto& tx : cblock.txs()) {
					full_tx_map.emplace(tx.time(), tx.hash());
				}

				if (msg->has_exclusion_proof()) {
					const auto& proof = msg->exclusion_proof();

					// 签名验证：需要创建一个不含签名的临时 proof 来验证
					// （因为签名时是对不含签名的 proof 数据签名的）
					std::string proofData = confirmed_exclusion::SigningPayload(proof);
					std::string pubKey = cblock.signature(0).pub();

					CSign tempSign;
					tempSign.set_sign(proof.packager_signature());
					tempSign.set_pub(pubKey);

					if (ca_algorithm::VerifySign(tempSign, proofData) != 0) {
					    ERRORLOG("handleBlock: ExclusionProof 签名无效!");
					    return -20;
					}
					if (proof.reason_type() != EXCLUSION_REASON_UNSPECIFIED &&
						proof.reason_type() != EXCLUSION_BLOCK_GAS_LIMIT &&
						proof.reason_type() != EXCLUSION_ALREADY_CONFIRMED) {
						ERRORLOG("handleBlock: unknown exclusion reason type");
						return -23;
					}
					if (proof.reason_type() == EXCLUSION_ALREADY_CONFIRMED) {
						std::string proofError;
						if (!confirmed_exclusion::VerifyConfirmedProof(cblock, proof, msg->dispatcher_vrf(), &proofError)) {
							ERRORLOG("handleBlock: confirmed exclusion invalid: {}", proofError);
							return -24;
						}
					}

					// 时间序公平性检查
					if (proof.reason_type() != EXCLUSION_ALREADY_CONFIRMED && !cblock.txs().empty() && proof.excluded_txs_size() > 0) {
					    uint64_t max_included_time = 0;
					    for(const auto& tx : cblock.txs()) {
					        if (tx.time() > max_included_time) max_included_time = tx.time();
					    }
					    uint64_t min_excluded_time = UINT64_MAX;
					    for(const auto& ex_tx : proof.excluded_txs()) {
					        if (ex_tx.time() < min_excluded_time) min_excluded_time = ex_tx.time();
					    }

					    if (min_excluded_time < max_included_time) {
					        ERRORLOG("handleBlock: 时间序公平性检查失败! min_excluded_time={} < max_included_time={}", min_excluded_time, max_included_time);
					        return -21;
					    }
					}

					// 数学验证
					if (proof.reason() == "BLOCK_GAS_LIMIT_EXCEEDED") {
					    if (proof.cumulative_gas_before() > global::ca::kBlockGasLimit) {
					        ERRORLOG("handleBlock: 数学验证失败! cumulative_gas_before={}", proof.cumulative_gas_before());
					        return -22;
					    }
					}

					// 添加被剔除的交易（用于构建完整的input_hash和max_time）
					for (const auto& ex_tx : proof.excluded_txs()) {
					    full_tx_map.emplace(ex_tx.time(), ex_tx.hash());
					}
				}

				// 关键修复：使用还原后的完整交易集合的最大时间戳（分发者VRF使用的max_time）
				// 而不是cblock.time()（打包者计算的区块时间），两者可能不同
				const uint64_t max_tx_time = full_tx_map.empty() ? 0 : full_tx_map.rbegin()->first;

				// 构建 input_hash（按时间戳排序后拼接）
				std::string hash_concat;
				for (const auto& [timestamp, hash] : full_tx_map) {
					hash_concat += hash;
				}
				std::string input_hash = Getsha256Hash(hash_concat);

				ERRORLOG("[DEBUG-VRF] handleBlock: full_tx_map.size={}, block.txs.size={}, excluded_txs.size={}, max_tx_time={}, cblock.time={}, input_hash={}",
					full_tx_map.size(), cblock.txs_size(),
					msg->has_exclusion_proof() ? msg->exclusion_proof().excluded_txs_size() : 0,
					max_tx_time, cblock.time(), input_hash.substr(0, 16));

				// 验证（使用 max_tx_time 而不是 cblock.time()）
				std::string error;
				if (!VerifyContractPackagerSelectionProofJson(input_hash, max_tx_time,
															packagerAddr, "",
															msg->dispatcher_vrf(), &error, kStageBlockFlowVerify)) {
					ERRORLOG("handleBlock: dispatcher_vrf 验证失败: {}", error);
                                        return -22;
				} else {
					DEBUGLOG("=== dispatcher_vrf 验证成功 ===");
				}
			} else {
				DEBUGLOG("=== dispatcher_vrf 为空，跳过验证 ===");
			}

			std::future<int> taskResults = std::async(std::launch::async, [cblock] {
				return VerifyTxIdentity(cblock, kStageBlockFlowVerify);
			});

			std::vector<std::string> getValidationAddrs(msg->verifyaddrs().begin(), msg->verifyaddrs().end());
			int ret = VerifyBlockSignatureNodeSelection(cblock, packagerAddr, getValidationAddrs, msg->validator_vrf(), kStageBlockFlowVerify);
			if(ret != 0)
			{
				ERRORLOG("VerifyBlockSignatureNodeSelection ret :{}", ret);
				return -11;
			}

			std::map<std::string, CTransaction> txidentyVrfMap;
			std::vector<std::string> verifySign;
			for (auto &tx : cblock.txs())
			{
				bool isProxy = true;
				for(auto &utxo:tx.utxos())
				{
					for (const auto &sig : utxo.multisign())
					{
						if(GenerateAddr(sig.pub()) == tx.identity())
						{
							isProxy = false;
							break;
						}
					}
				}
				if(isProxy)
				{
					txidentyVrfMap[tx.hash()] = tx;
				}
				
				// Whether to find the vrf logo
				if (GetTransactionType(tx) != kTransactionTypeTx)
				{
					continue;
				}

				global::ca::TxType txType = (global::ca::TxType)tx.type();
				if(global::ca::TxType::CALL != txType && global::ca::TxType::DEPLOY != txType)
				{
					if(packagerAddr != tx.identity())
					{
						ERRORLOG("Relay Node Error, cblock.sign(0):{}, tx.identity:{}", packagerAddr, tx.identity());
						return -17;
					}
				}

				if(verifyTransactionTimeoutRequest(tx) != 0)
				{
					ERRORLOG("time out tx hash = {}, blockHash:{}",tx.hash(), cblock.hash().substr(0,6));
					return -18;
				}
			}

			try {
				int ret = taskResults.get();
				if (ret != 0) {
					return -19;
				}
			} catch (const std::exception& e) {
				std::cerr << e.what() << '\n';
				return -20;
			}


			uint64_t height = cblock.height();
			uint64_t txsize = cblock.txs().size();
			MagicSingleton<Benchmark>::GetInstance()->setByBlockHash(cblock.hash(), &height, 4, &txsize);
			// send to origin node
			if (defaultAddr != packagerAddr && cblock.signature_size() == 2)
			{
				// 说明是别人代发 给我的 不是创建交易者发我的
				if(node != nullptr && packagerAddr != node->address)
				{
					DEBUGLOG("ReSend to : {}, blockHash:{}", node->address, cblock.hash().substr(0,6));
					NetSendMessage<BlockMsg>(node->address, *msg, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
				}
				else
				{
					DEBUGLOG("handleBlock NetSendMessage<BlockMsg> {}, blockHash:{}", packagerAddr, cblock.hash().substr(0,6));
					NetSendMessage<BlockMsg>(packagerAddr, *msg, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
				}
			}
		}
		else
		{
			ERRORLOG("unknow type !");
			return -21;
		}
	}
	return 0;
}

int DropShippingTransaction(const std::shared_ptr<TxMsgReq> &txMsg, const CTransaction &tx)
{
	if (txMsg != nullptr && txMsg->selection_vrf().empty())
	{
		std::string selectionVrf;
		std::string error;
		if (!BuildTxPackagerSelectionProofJson(tx, selectionVrf, &error, kStageTxRequestCreate))
		{
			ERRORLOG("BuildTxPackagerSelectionProofJson failed, txHash:{}, error:{}", tx.hash(), error);
			return -2;
		}
		txMsg->set_selection_vrf(selectionVrf);
	}

	uint64_t handleTransactionHeight = txMsg->txmsginfo().nodeheight();

	bool sRet = NetSendMessage<TxMsgReq>(tx.identity(), *txMsg, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_TRUE, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
	if (sRet == false)
	{
		return -1;
	}
	return 0;
}

int DropShippingTransaction(const std::shared_ptr<TxMsgReq> &txMsg, const CTransaction &tx, const std::string& addr)
{
	if (txMsg != nullptr && txMsg->selection_vrf().empty())
	{
		std::string selectionVrf;
		std::string error;
		if (!BuildTxPackagerSelectionProofJson(tx, selectionVrf, &error, kStageTxRequestCreate))
		{
			ERRORLOG("BuildTxPackagerSelectionProofJson failed, txHash:{}, error:{}", tx.hash(), error);
			return -3;
		}
		txMsg->set_selection_vrf(selectionVrf);
	}

	Node node;
	if(MagicSingleton<PeerNode>::GetInstance()->FindNode(tx.identity(),node))
	{
		std::cout << "addr:" << addr << std::endl;
		bool sRet = NetSendMessage<TxMsgReq>(addr, *txMsg, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_TRUE, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
		if (sRet == false)
		{
			return -1;
		}
	}else
	{
		std::vector<Node> nodelist =  MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
		std::random_shuffle(nodelist.begin(),nodelist.end()); 

		std::vector<Node> identity = getRandomElements(nodelist,1);
		if(identity.size()<=0){
			std::cout << "identify is null" << std::endl;
			return -1;
		}
		std::cout << "addr:" << identity[0].address << std::endl;
		bool sRet = NetSendMessage<TxMsgReq>(identity[0].address, *txMsg, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_TRUE, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
		if (sRet == false)
		{
			return -2;
		}

		DEBUGLOG("HandleTx send another node is : {}",identity[0].address);
	}

	return 0;
}

int dropCallShippingRequest(const std::shared_ptr<ContractTxMsgReq> & Msg,const CTransaction &tx)
{
	uint64_t handleTransactionHeight = Msg->mutable_txmsgreq()->txmsginfo().nodeheight();

	std::string defalutAddr = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
	if(tx.identity() == defalutAddr)
	{
    	MsgData msgData;
		std::cout << "addr:" << defalutAddr << std::endl;
    	int ret = contractTransactionRequest( Msg,  msgData );
		if(ret != 0)
		{
			ERRORLOG("contractTransactionRequest ret :{}" , ret);
			return -1;
		}
	}

	Node node;
	if(MagicSingleton<PeerNode>::GetInstance()->FindNode(tx.identity(),node))
	{
		std::cout << "addr:" << tx.identity() << std::endl;
		bool sRet = NetSendMessage<ContractTxMsgReq>(tx.identity(), *Msg, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_TRUE, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
		DEBUGLOG("CallContract send id :{}, send tx hash :{} ", tx.identity(), tx.hash());
		if (sRet == false)
		{
			return -2;
		}
	}
	else
	{
		std::vector<Node> nodelist =  MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
		std::random_shuffle(nodelist.begin(),nodelist.end());

		std::vector<Node> identity = getRandomElements(nodelist,1);
		if (identity.empty()) {
			ERRORLOG("No available nodes to send contract transaction, nodelist size:{}", nodelist.size());
			return -5;
		}
		std::cout << "addr:" << identity[0].address << std::endl;
		bool sRet = NetSendMessage<ContractTxMsgReq>(identity[0].address, *Msg, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_TRUE, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
		if (sRet == false)
		{
			return -5;
		}

		DEBUGLOG(" contractTransactionRequest send another node is : {}, tx hash: {}",identity[0].address, tx.hash());
	}

	return 0;
}

int verifyTransactionTimeoutRequest(const CTransaction &tx)
{
    const int64_t kContractTimeoutPeriod = global::ca::KtxTimeout * 3;
    uint64_t nowTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    int64_t expireTime = 0;
    if ((global::ca::TxType)tx.type() != global::ca::TxType::CALL && (global::ca::TxType)tx.type() != global::ca::TxType::DEPLOY)
    {
        expireTime = global::ca::KtxTimeout;
    }
    else
    {
        expireTime = kContractTimeoutPeriod;
    }

	if(tx.time() + expireTime <= nowTime || tx.time() >= nowTime + expireTime)
	{
		return -1;
	}
	return 0;
}

int CalculateGas(const CTxUtxos &utxo, const uint64_t gasSize, uint64_t &gas)
{

	uint64_t utxoSize = 0;
	// if (txType == global::ca::GENESIS_SIGN || txType == global::ca::kTxSign)
	// {

		for (auto &vin : utxo.vin())
		{
			utxoSize += vin.prevout().size() * 64;
		}

		gas = 0;
		gas += utxo.owner_size() * 34;
		gas += utxoSize;
		gas += utxo.vout_size() * 34;
		gas += gasSize;
	//}

	DEBUGLOG("utxoSize : {}, voutSize : {}, gasSize : {}, utxo.owner_size():{}",utxoSize,utxo.vout_size(),gasSize,utxo.owner_size());

	gas *= 1;
	if(gas == 0)
	{
		ERRORLOG("gas = 0 !");
		return -1;
	}

	return 0;

}

int GenerateGas(const CTxUtxos &utxo,  const uint64_t voutSize, const uint64_t gasSize,uint64_t &gas)
{
	uint64_t utxoSize = 0;
	

		for (auto &vin : utxo.vin())
		{
			utxoSize += vin.prevout().size() * 64;
		}

		gas = 0;
		gas += utxo.owner_size() * 34;
		gas += utxoSize;
		gas += voutSize * 34;
		gas += gasSize;

	

	DEBUGLOG("utxoSize : {}, voutSize : {}, gasSize : {}, utxo.owner_size():{}",utxoSize,voutSize,gasSize,utxo.owner_size());

	gas *= 1;

	if (gas == 0)
	{
		ERRORLOG(" gas = 0 !");
		return -1;
	}
	return 0;
}

int precalculatedGas(const CTransaction &tx, const uint64_t voutSize, uint64_t &gas)
{
	TransactionType txType = GetTransactionType(tx);
	if (txType == kTransactionTypeGenesis || txType == kTransactionTypeTx)
	{
		gas += voutSize * 34;
		gas += tx.data().size() + tx.note().size();
		gas += tx.reserve0().size() + tx.reserve1().size();
	}
	
	return 0;
}

int fetchContractRootHash(const std::string& contractAddress, std::string& rootHash, contractDataContainer* contractDataStorage)
{
	if(contractDataStorage != nullptr)
	{
		if(contractDataStorage->get(contractAddress + "_" + "rootHash", rootHash))
		{
			return 0;
		}
	}

    DBReader data_reader;
    std::string prevTxHash;
    int ret = data_reader.getLatestUtxoByContractAddr(contractAddress, prevTxHash);
    if(ret != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("getLatestUtxoByContractAddr failed!");
        return -1;
    }

    std::string prevBlockHash;
    ret = data_reader.getBlockHashByTransactionHash(prevTxHash, prevBlockHash);
    if(ret != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("getBlockHashByTransactionHash failed!, pretxhash: {}", prevTxHash);
        return -2;
    }

    std::string blockRaw;
    ret = data_reader.getBlockByBlockHash(prevBlockHash, blockRaw);
    if(ret != DBStatus::DB_SUCCESS)
    {
        ERRORLOG("getBlockByBlockHash failed!");
        return -3;
    }

    CBlock Prevblock;
    if(!Prevblock.ParseFromString(blockRaw))
    {
        ERRORLOG("parse failed!");
        return -4;
    }

    bool isContractDeploymentEnabled = false;
    for (const auto& tx : Prevblock.txs())
    {
        if (tx.hash() == prevTxHash &&
            (global::ca::TxType)tx.type() == global::ca::TxType::DEPLOY
            )
        {

            isContractDeploymentEnabled = true;
            break;
        }
    }
    try
    {
        nlohmann::json prevData = nlohmann::json::parse(Prevblock.data());
        auto found = prevData.find(prevTxHash);
        if (found == prevData.end())
        {
            return -5;
        }
        nlohmann::json BlocktxInfo = found.value();
        nlohmann::json jPrevStorage = BlocktxInfo[Evmone::storageKeyForContract];
        if(!jPrevStorage.is_null())
        {
            if(isContractDeploymentEnabled)
            {
				std::string txRaw;
				if(data_reader.getTransactionByHash(prevTxHash, txRaw) != DBStatus::DB_SUCCESS)
				{
					ERRORLOG("getTransactionByHash failed!");
					return -4;
				}
				CTransaction deployTx;
				if(!deployTx.ParseFromString(txRaw))
				{
					ERRORLOG("Transaction Parse failed!");
					return -5;
				}

				nlohmann::json dataJson = nlohmann::json::parse(deployTx.data());
				nlohmann::json txInfo = dataJson["txInfo"].get<nlohmann::json>();

				std::string transientContractAddr_ = txInfo[Evmone::contractRecipientKeyNameStr].get<std::string>();
				DEBUGLOG("transientContractAddr_:{}", transientContractAddr_);
                rootHash = jPrevStorage[transientContractAddr_ + "_" + "rootHash"].get<std::string>();
            }
            else
            {
                rootHash = jPrevStorage[contractAddress + "_" + "rootHash"].get<std::string>();
            }
        }

    }
    catch(...)
    {
        ERRORLOG("Parsing failed!");
        return -6;
    }
    return 0;
}

bool isContractBlocked(const CBlock & block)
{
    for (const auto& tx : block.txs())
    {
        if ((global::ca::TxType)tx.type() == global::ca::TxType::CALL || (global::ca::TxType)tx.type() == global::ca::TxType::DEPLOY)
        {
            return true;
        }
    }
    return false;
}

static std::string CalculationPackNode(const std::string seed, const std::vector<std::string> &targetAddrs)
{
	// 使用 seed 初始化随机数生成器
    std::seed_seq seq(seed.begin(), seed.end());
    std::mt19937 gen(seq);

    // 创建一个均匀分布的随机数生成器
    std::uniform_int_distribution<> dis(0, targetAddrs.size() - 1);

    // 随机选择一个 targetAddrs 中的元素
    int randomIndex = dis(gen);
  
	return targetAddrs[randomIndex];
}

int FindContractPackNode(const std::string & allTxHashes, const uint64_t& utcTime, std::string &targetAddr, const std::string& selectorAddr)
{
	DEBUGLOG("FindContractPackNode seed:{} , time: {}",allTxHashes, utcTime);
	std::vector<std::string> dataSource;
	if(!MagicSingleton<VRFConsensusNode>::GetInstance()->extractPackagerVRFData(dataSource, utcTime)){
		return -1;
	}

	if(dataSource.empty()){
		ERRORLOG("extractPackagerVRFData is empty");
		return -2;
	}

	if (!selectorAddr.empty())
	{
		// Dispatcher selects the contract packager with an RFC 9381 proof bound
		// to the sorted transaction batch hash and the batch time window.
		std::vector<std::string> selected;
		std::string selectionVrf;
		std::string error;
		if (!ohi::vrf::BuildSelectionProof(ohi::vrf::kContractPackagerRole,
											 selectorAddr,
											 dataSource,
											 BuildContractPackagerInput(allTxHashes, utcTime),
											 1,
											 selected,
											 selectionVrf,
											 &error))
		{
			ERRORLOG("BuildSelectionProof(contract_packager) failed, error: {}", error);
			return -3;
		}

		if (selected.size() != 1)
		{
			ERRORLOG("Unexpected contract packager selection result size: {}", selected.size());
			return -4;
		}

		targetAddr = selected.front();
		return 0;
	}

	targetAddr = CalculationPackNode(allTxHashes, dataSource);
	return 0;
}


int ContractPackVerifier(const std::string& seed, const uint64_t& time, const std::string& targetAddr, const std::string& selectionVrf, const std::string& expectedSelectorAddr, const std::string& traceStage)
{
	DEBUGLOG("ContractPackVerifier targetAddr : {}", targetAddr);

	if (!selectionVrf.empty())
	{
		// New contract block path: verify the dispatcher's proof directly. This
		// is stronger than inferring the dispatcher from a time-based heuristic.
		std::string error;
		if (!VerifyContractPackagerSelectionProofJson(seed, time, targetAddr, expectedSelectorAddr, selectionVrf, &error, traceStage))
		{
			ERRORLOG("VerifyContractPackagerSelectionProofJson failed, error: {}", error);
			return -4;
		}
		return 0;
	}
	
	std::string packAddr;
	auto ret = FindContractPackNode(seed, time, packAddr);
	if(ret != 0)
	{
		ERRORLOG("FindContractPackNode ret :{}", ret);
		return -2;
	}

	if(packAddr != targetAddr)
	{
		ERRORLOG("ContractPackVerifier The current address {} , not equal contract package address : {} ", targetAddr, packAddr);
		return -3;
	}

	return 0;
}


std::string GetContractAddr(const CTransaction & tx)
{
	{
		nlohmann::json txInfo;
		try
		{
			nlohmann::json dataJson = nlohmann::json::parse(tx.data());
			txInfo = dataJson["txInfo"].get<nlohmann::json>();
            return txInfo[Evmone::contractRecipientKeyNameStr].get<std::string>();
		}
		catch(...)
        {
            ERRORLOG(RED "JSON failed to parse data field!" RESET);
            return "";
        }
	}
	
	return "";
}

std::set<std::string> get_contract_pre_hash(const CBlock & block)
{
	std::set<std::string> preHashKeyList;

	{
		nlohmann::json blockData;
		try
		{
			blockData = nlohmann::json::parse(block.data());

			for(auto& tx :block.txs())
            {
				nlohmann::json txInfo;
				auto txHash = tx.hash();
				for (const auto&[key, value] : blockData.items())
				{
					if (key == txHash)
					{
						txInfo = value;
						break;
					}
				}

				for(auto &it : txInfo[Evmone::contractPreHashKey].items())
				{
					if(it.key() == "") continue;
					preHashKeyList.insert(it.key());
				}

			}
			
            return preHashKeyList;
		}
		catch(...)
        {
            ERRORLOG(RED "get_contract_pre_hash JSON failed to parse data field!" RESET);
        }
	}

	preHashKeyList.clear();
    return preHashKeyList;
}

std::string GetPackager(const CBlock & block)
{
    return GenerateAddr(block.signature(0).pub());
}


int processCheckContractPreHashRequest(const std::shared_ptr<CheckContractPreHashReq> &msg, const MsgData &msgData)
{
	DEBUGLOG("processCheckContractPreHashRequest");
	CheckContractPreHashAck ack;
	ack.set_msg_id(msg->msg_id());
	ack.set_self_node_id(MagicSingleton<PeerNode>::GetInstance()->GetSelfId());

	bool isOk = true;
	for (const auto &it : msg->contract_pre_hash())
	{
		DBReader dbReader;
		std::string preHash;
		auto ret = dbReader.getLatestUtxoByContractAddr(it.contract_addr(), preHash);
		if (ret != DBStatus::DB_SUCCESS)
		{
			ERRORLOG("getLatestUtxoByContractAddr fail, ret:{}", ret);
			isOk = false;
			break;
		}
		if (preHash != it.prev_tx_hash())
		{
			DEBUGLOG("getLatestUtxoByContractAddr preHash:{} != it.prev_tx_hash():{}", preHash, it.prev_tx_hash());
			isOk = false;
			break;
		}
	}

	if (!isOk)
	{
		ack.set_contract_pre_hash_ok(false);
	}
	else
	{
		ack.set_contract_pre_hash_ok(true);
	}
	NetSendMessage<CheckContractPreHashAck>(msg->self_node_id(), ack, net_com::Priority::PRIORITY_HIGH_LEVEL_1);
	return 0;
}

int handleContractPreHashAck(const std::shared_ptr<CheckContractPreHashAck> &msg, const MsgData &msgData)
{
	DEBUGLOG("handleContractPreHashAck");
	if (!PeerNode::verifyPeerNodeIdRequest(msgData.fd, msg->self_node_id()))
	{
		ERRORLOG("verifyPeerNodeIdRequest error");
		return -1;
	}

	dataMgrPtr.waitDataToAdd(msg->msg_id(), msg->self_node_id(), msg->SerializeAsString());
	return 0;
}

int CheckNodeValidity(const std::string &addr)
{
        // uint64_t delegateAmount = 0;
        // int ret =
        // MagicSingleton<ohi::ca::BonusAddrCache>::GetInstance()->getAmount(addr,
        // delegateAmount); if (ret < 0)
        // {
        // 	return -1;
        // }
        // 
	// std::string assetType;
	// int ret = ca_algorithm::GetCanBeRevokeAssetType(assetType);
    // if(ret != 0){
    //     ERRORLOG("Get Can BeRevoke AssetType fail!");
	// 	return -2;
    // }
	// uint64_t stakeAmount;
	// if (SearchStake(addr, stakeAmount, global::ca::StakeType::STAKE_TYPE_NODE) != 0)
	// {
	// 	ERRORLOG("verifyTransactionMessageRequest stake is error");
	// 	return -3;
	// }

	// if(delegateAmount < global::ca::kMinKGetBonusDelegatingAmt)
	// {
	// 	ERRORLOG("delegateAmount: {}", delegateAmount);
	// 	return -4;
	// }

	
	// if(stakeAmount < global::ca::MIN_STAKE_AMOUNT)
	// {
	// 	ERRORLOG("stakeAmount: {}", stakeAmount);
	// 	return -5;
	// }

	ohi::utils::AddressStatus st;
	MagicSingleton< ohi::utils::AddressStatusCache>::GetInstance()->getAddressStatus(addr,st);
         if(st.status.getStatus(
            ohi::utils::AddressStatus::StatusType::CanReward))
			{
				DEBUGLOG("stakeAmount: {}", addr);
				return 0;
			}
			else{
				ERRORLOG("addr: {}", addr);
				return -1;
			}
}

int CheckGasAssetsInput(std::string &_isGasAssets, std::pair<std::string, std::string> &gasAssets)
{
    if(std::stoi(_isGasAssets))
    {
        std::string gasAssetTypeEnum;
        std::cout << "Please enter the type of asset you want to use to pay the gas:" << std::endl;
        std::cin >> gasAssetTypeEnum;

		std::regex pattern2("[^\"\\s]*");
        if (!std::regex_match(gasAssetTypeEnum, pattern2))
        {
            std::cout << "Invalid input, please enter a string!" << std::endl;
            return -1;
        }
        std::string gasSourceAddress;
        std::cout << "Please enter the fromaddr to pay the gas:" << std::endl;
        std::cin >> gasSourceAddress;

        gasAssets.first = remove0xPrefix(gasSourceAddress);
        
        if(!isValidAddress(gasAssets.first))
        {
            std::cerr << "Invalid gasTrade from address format. Please try again." << std::endl;
            return -2;
        }
        gasAssets.second = remove0xPrefix(gasAssetTypeEnum);
        return 0;
    }
    return 0;
}

int CheckGasAssetsQualification(const std::pair<std::string, std::string> &gasAssets, const uint64_t &height)
{
	std::vector<std::string> gasTradeFromAddress;
	gasTradeFromAddress.push_back(gasAssets.first);
	int ret = TxHelper::Check(gasTradeFromAddress, gasAssets.second, height);
	if (ret != 0)
	{
		ERRORLOG(RED "Check parameters failed! The error code is {}." RESET, ret);
		ret -= 600;
		return ret;
	}
	return 0;
}
