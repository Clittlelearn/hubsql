#ifndef OPENHIVE_CA_UTXO_SELECTION_POLICY_H
#define OPENHIVE_CA_UTXO_SELECTION_POLICY_H

#include <algorithm>
#include <cstdint>
#include <vector>

namespace utxo_selection
{

template <typename Utxo>
bool CanonicalLess(const Utxo& lhs, const Utxo& rhs)
{
    if (lhs.value != rhs.value) return lhs.value > rhs.value;
    if (lhs.addr != rhs.addr) return lhs.addr < rhs.addr;
    if (lhs.hash != rhs.hash) return lhs.hash < rhs.hash;
    return lhs.n < rhs.n;
}

template <typename Utxo>
void CanonicalSort(std::vector<Utxo>& utxos)
{
    std::sort(utxos.begin(), utxos.end(), CanonicalLess<Utxo>);
}

} // namespace utxo_selection

#endif // OPENHIVE_CA_UTXO_SELECTION_POLICY_H
