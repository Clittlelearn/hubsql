#!/bin/bash
# GMP Source Installation Script
# Version: 1.3
# Description: Automates GMP installation from source including download, compilation, installation and cleanup
# Supported systems: Linux (Debian/Ubuntu, RHEL/CentOS), macOS
# Usage: ./install_gmp.sh [version] [install-path]

# ===== Global Configuration =====
DEFAULT_VERSION="6.3.0"                  # Default GMP version
DEFAULT_PREFIX="/usr/local"              # Default installation path
BUILD_OPTIONS="--enable-cxx"            # Enable C++ support
PARALLEL_JOBS=$(nproc)                   # Parallel compilation jobs
TAR_FILE=""                               # Source archive filename
SOURCE_DIR=""                             # Temporary source directory
DOWNLOAD_URL=""                           # Download URL

# ===== Function: Detect GCC version and set appropriate CFLAGS =====
# GCC >= 15 defaults to C23, which breaks GMP 6.3.0 configure tests.
# Force C17 for GCC >= 15; leave default for older GCC.
get_gmp_cflags() {
    local gcc_version
    gcc_version=$(gcc -dumpversion 2>/dev/null | cut -d. -f1)
    if [[ -n "$gcc_version" ]] && (( gcc_version >= 15 )); then
        echo "-std=gnu17"
    else
        echo ""
    fi
}

# ===== Function: Check if GMP is already installed =====
check_gmp_installed() {
    echo "[Check] Checking if GMP is already installed..."
    
    # Check for header files
    local gmp_header_found=false
    local header_paths=(
        "/usr/include/gmp.h"
        "/usr/local/include/gmp.h"
        "/usr/include/x86_64-linux-gnu/gmp.h"
        "${DEFAULT_PREFIX}/include/gmp.h"
    )
    
    for path in "${header_paths[@]}"; do
        if [[ -f "$path" ]]; then
            echo "  ✓ Found header file: $path"
            gmp_header_found=true
            break
        fi
    done
    
    # Check for library files
    local gmp_lib_found=false
    if command -v ldconfig &>/dev/null; then
        if ldconfig -p 2>/dev/null | grep -q libgmp.so; then
            echo "  ✓ Found GMP library (via ldconfig)"
            gmp_lib_found=true
        fi
    fi
    
    # If ldconfig is not available, check common library paths
    if [[ "$gmp_lib_found" == false ]]; then
        local library_paths=(
            "/usr/lib64/libgmp.so"
            "/usr/lib/libgmp.so"
            "/usr/lib/x86_64-linux-gnu/libgmp.so"
            "/usr/local/lib/libgmp.so"
            "${DEFAULT_PREFIX}/lib/libgmp.so"
        )
        
        for path in "${library_paths[@]}"; do
            if [[ -f "$path" ]] || [[ -L "$path" ]]; then
                echo "  ✓ Found library file: $path"
                gmp_lib_found=true
                break
            fi
        done
    fi
    
    # Check pkg-config
    if command -v pkg-config &>/dev/null; then
        if pkg-config --exists gmp 2>/dev/null; then
            echo "  ✓ Found GMP (via pkg-config)"
            gmp_lib_found=true
        fi
    fi
    
    # Return result
    if [[ "$gmp_header_found" == true && "$gmp_lib_found" == true ]]; then
        echo "[Check] GMP is already installed"
        return 0
    else
        echo "[Check] GMP is not installed or installation is incomplete"
        if [[ "$gmp_header_found" == false ]]; then
            echo "  ✗ GMP header file not found"
        fi
        if [[ "$gmp_lib_found" == false ]]; then
            echo "  ✗ GMP library file not found"
        fi
        return 1
    fi
}

# ===== Function: Detect operating system =====
detect_os() {
    echo "[System] Detecting operating system..."
    
    if [[ -f /etc/os-release ]]; then
        source /etc/os-release
        OS_NAME="$ID"
        OS_VERSION="$VERSION_ID"
        echo "  ➤ OS: $NAME $VERSION"
    elif [[ -f /etc/redhat-release ]]; then
        OS_NAME="rhel"
        if grep -q "CentOS" /etc/redhat-release; then
            OS_NAME="centos"
        fi
        OS_VERSION=$(grep -oE '[0-9]+\.[0-9]+' /etc/redhat-release | head -1)
        echo "  ➤ OS: $(cat /etc/redhat-release)"
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS_NAME="macos"
        OS_VERSION=$(sw_vers -productVersion)
        echo "  ➤ OS: macOS $OS_VERSION"
    else
        OS_NAME="unknown"
        OS_VERSION="unknown"
        echo "  ⚠ Unable to identify operating system"
    fi
}

# ===== Function: Special handling for CentOS 7 =====
handle_centos7_gmp() {
    echo "[Special] Detected CentOS 7, checking system GMP..."
    
    # Check if GMP development package is already installed via system package manager
    if command -v rpm &>/dev/null; then
        if rpm -q gmp-devel &>/dev/null; then
            echo "  ✓ gmp-devel already installed via yum"
            if check_gmp_installed; then
                echo "  ✓ GMP is fully installed, skipping compilation"
                return 0
            else
                echo "  ⚠ gmp-devel installed but detection failed, attempting to fix..."
                # Try running ldconfig to update cache
                if command -v ldconfig &>/dev/null; then
                    sudo ldconfig
                fi
                if check_gmp_installed; then
                    echo "  ✓ Fix successful, GMP is now available"
                    return 0
                fi
            fi
        fi
    fi
    
    # If not installed via package manager, check if GMP exists
    if check_gmp_installed; then
        echo "  ✓ GMP is already installed, skipping compilation"
        return 0
    fi
    
    # If neither RPM package nor GMP detected, install from source
    echo "  ➤ Installing GMP on CentOS 7..."
    
    # Set variables
    local version="6.3.0"
    TAR_FILE="gmp-${version}.tar.xz"
    DOWNLOAD_URL="https://gmplib.org/download/gmp/$TAR_FILE"
    SOURCE_DIR="/tmp/gmp-${version}-src"
    
    # Install dependencies
    if command -v yum &>/dev/null; then
        echo "  ➤ Installing build dependencies..."
        sudo yum groupinstall -y "Development Tools"
        sudo yum install -y m4 wget xz
    fi
    
    # Download source code
    echo "  ➤ Downloading GMP ${version}..."
    if ! wget -q --show-progress "$DOWNLOAD_URL" -O "$TAR_FILE"; then
        echo "  ✗ Download failed: $DOWNLOAD_URL"
        return 1
    fi
    
    # Extract source code
    echo "  ➤ Extracting source code..."
    mkdir -p "$SOURCE_DIR"
    if ! tar -xf "$TAR_FILE" -C "$SOURCE_DIR" --strip-components=1; then
        echo "  ✗ Extraction failed"
        rm -f "$TAR_FILE"
        return 1
    fi
    rm -f "$TAR_FILE"
    
    # Compile and install
    GMP_CFLAGS=$(get_gmp_cflags)
    echo "  ➤ Compiling and installing GMP (CFLAGS: ${GMP_CFLAGS:-default})..."
    cd "$SOURCE_DIR" || return 1

    if ! CFLAGS="${GMP_CFLAGS}" ./configure --prefix=/usr/local --enable-cxx; then
        echo "  ✗ Configuration failed"
        return 1
    fi
    
    if ! make -j$(nproc); then
        echo "  ✗ Compilation failed"
        return 1
    fi
    
    echo "  ➤ Running tests..."
    if ! make check; then
        echo "  ⚠ Tests failed, but continuing with installation"
    fi
    
    echo "  ➤ Installing to system..."
    if ! sudo make install; then
        echo "  ✗ Installation failed"
        return 1
    fi
    
    # Update library cache
    echo "  ➤ Updating library cache..."
    sudo ldconfig
    
    # Cleanup
    cd /tmp
    rm -rf "$SOURCE_DIR"
    
    echo "  ✓ GMP installation completed"
    return 0
}

# ===== Function: Regular installation process =====
install_gmp_regular() {
    local version="${1:-$DEFAULT_VERSION}"
    local prefix="${2:-$DEFAULT_PREFIX}"
    
    echo "[Regular] Installing GMP version: $version, path: $prefix"
    
    # Set variables
    TAR_FILE="gmp-${version}.tar.xz"
    DOWNLOAD_URL="https://gmplib.org/download/gmp/$TAR_FILE"
    SOURCE_DIR="/tmp/gmp-${version}-src"
    
    # Install dependencies
    install_dependencies
    
    # Download source code
    echo "[1/6] Downloading GMP $version..."
    if ! wget -q --show-progress "$DOWNLOAD_URL" -O "$TAR_FILE"; then
        echo "Error: Download failed, please check version or network connection: $DOWNLOAD_URL"
        exit 1
    fi
    
    # Extract source code
    echo "[2/6] Extracting source code..."
    mkdir -p "$SOURCE_DIR"
    if ! tar -xf "$TAR_FILE" -C "$SOURCE_DIR" --strip-components=1; then
        echo "Error: Extraction failed"
        rm -f "$TAR_FILE"
        exit 1
    fi
    rm -f "$TAR_FILE"
    
    # Compile and install
    echo "[3/6] Configuring build..."
    cd "$SOURCE_DIR" || exit 1
    GMP_CFLAGS=$(get_gmp_cflags)
    echo "  CFLAGS: ${GMP_CFLAGS:-default}"
    if ! CFLAGS="${GMP_CFLAGS}" ./configure --prefix="$prefix" $BUILD_OPTIONS; then
        echo "Error: Configuration failed"
        exit 1
    fi
    
    echo "[4/6] Compiling source (using $PARALLEL_JOBS jobs)..."
    if ! make -j "$PARALLEL_JOBS"; then
        echo "Error: Compilation failed"
        exit 1
    fi
    
    echo "[5/6] Running test suite..."
    if ! make check; then
        echo "Warning: Tests failed, continue installation? (y/N)"
        read -r response
        if [[ ! "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
            exit 1
        fi
    fi
    
    echo "[6/6] Installing to $prefix..."
    if ! sudo make install; then
        echo "Error: Installation failed"
        exit 1
    fi
    
    # Post-install configuration
    post_install "$prefix"
    
    # Cleanup
    cd /tmp
    rm -rf "$SOURCE_DIR"
    
    echo "✓ GMP $version installation completed"
}

# ===== Function: Install dependencies =====
install_dependencies() {
    echo "[Dependencies] Installing system dependencies..."
    if command -v apt-get &>/dev/null; then
        # Debian/Ubuntu
        sudo apt-get update
        sudo apt-get install -y build-essential m4 libtool wget
    elif command -v yum &>/dev/null; then
        # RHEL/CentOS
        sudo yum groupinstall -y "Development Tools"
        sudo yum install -y m4 libtool wget
    elif command -v brew &>/dev/null && [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        brew install m4 libtool wget
    else
        echo "Warning: Unable to automatically install dependencies, ensure the following are installed: gcc, make, m4, libtool, wget"
    fi
}

# ===== Function: Post-install configuration =====
post_install() {
    local prefix="$1"
    echo "[Post-install] Updating linker cache..."
    
    # Update ldconfig
    if command -v ldconfig &>/dev/null; then
        if [[ "$prefix" != "/usr" && "$prefix" != "/usr/local" ]]; then
            echo "$prefix/lib" | sudo tee /etc/ld.so.conf.d/gmp.conf >/dev/null
        fi
        sudo ldconfig
    fi
    
    # Verify installation
    verify_installation "$prefix"
}

# ===== Function: Verify installation =====
verify_installation() {
    local prefix="$1"
    echo "[Verification] Verifying GMP installation..."
    
    # Create test program
    cat << 'EOF' > /tmp/verify_gmp.c
#include <gmp.h>
#include <stdio.h>
int main() {
    mpz_t a, b, c;
    mpz_init(a);
    mpz_init(b);
    mpz_init(c);
    mpz_set_str(a, "1234567890", 10);
    mpz_set_str(b, "9876543210", 10);
    mpz_add(c, a, b);
    gmp_printf("GMP test: %Zd + %Zd = %Zd\n", a, b, c);
    mpz_clear(a);
    mpz_clear(b);
    mpz_clear(c);
    printf("✓ GMP installation successful\n");
    return 0;
}
EOF
    
    # Compile test program
    local compile_cmd="gcc /tmp/verify_gmp.c"
    
    # Add library paths
    if [[ "$prefix" != "/usr" ]]; then
        compile_cmd="$compile_cmd -I$prefix/include -L$prefix/lib"
    fi
    compile_cmd="$compile_cmd -lgmp -o /tmp/verify_gmp"
    
    if ! eval $compile_cmd 2>/dev/null; then
        echo "  ⚠ Failed to compile test program, trying default paths..."
        # Try using pkg-config
        if command -v pkg-config &>/dev/null; then
            if pkg-config --exists gmp; then
                gcc /tmp/verify_gmp.c $(pkg-config --cflags --libs gmp) -o /tmp/verify_gmp
            fi
        fi
    fi
    
    # Run test
    if [[ -f /tmp/verify_gmp ]]; then
        LD_LIBRARY_PATH="$prefix/lib:$LD_LIBRARY_PATH" /tmp/verify_gmp
        rm -f /tmp/verify_gmp
    else
        echo "  ⚠ Unable to compile test program, but installation may be complete"
    fi
    
    rm -f /tmp/verify_gmp.c
}

# ===== Main program =====
main() {
    echo "========================================"
    echo "        GMP Installation Script v1.3"
    echo "========================================"
    
    # Detect operating system
    detect_os
    
    # Check if GMP is already installed
    if check_gmp_installed; then
        echo "✓ GMP is already installed, skipping installation"
        echo "If you need to reinstall, please uninstall existing version first"
        exit 0
    fi
    
    # Special handling for CentOS 7
    if [[ "$OS_NAME" == "centos" ]] && [[ "$OS_VERSION" == "7"* ]]; then
        echo "[System] Detected CentOS 7, using special handling process"
        if handle_centos7_gmp; then
            echo "✓ CentOS 7 GMP installation completed"
            exit 0
        else
            echo "⚠ CentOS 7 special handling failed, falling back to regular installation"
        fi
    fi
    
    # Regular installation process
    local version="${1:-$DEFAULT_VERSION}"
    local prefix="${2:-$DEFAULT_PREFIX}"
    
    install_gmp_regular "$version" "$prefix"
    
    echo "========================================"
    echo "    GMP Installation Completed!"
    echo "========================================"
    echo "Verify installation with:"
    echo "  pkg-config --modversion gmp"
    echo "  or compile a test program: gcc -lgmp your_program.c"
    echo ""
}

# Execute main program
main "$@"