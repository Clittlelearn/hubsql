#include "utils/uerror/ecode.h"
#include "errorn/ca/error.def.h"
#include "errorn/global/error.def.h"
#include "errorn/contract/error.def.h"
#include "errorn/error_module.h"



// #define EXP_ERROR(a,b) b,
//    ERROR_MESSAGE_MACRO_DF(CT,CA_ERRORS GOLBA_ERROR CONTRACT_ERROR);
// #undef EXP_ERROR

// #define EXP_ERROR(a,b) a,
//     ERROR_ENUM_MACRO_DF(CT,ERROR_MOUDLE,CONTRACT,CA_ERRORS GOLBA_ERROR CONTRACT_ERROR);
// #undef EXP_ERROR


// ERROR_SERIALIZER_MACRO_DF(CT)