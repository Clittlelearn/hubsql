#include "epoll_mode.h"
#include "./global.h"
#include "../utils/console.h"
#include "metrics.h"
#include "network_policy.h"

EpollMode::EpollMode()
{
    this->_listenThread = NULL;
}

EpollMode::~EpollMode()
{
    if (NULL != this->_listenThread)
    {
        delete this->_listenThread;
        this->_listenThread = NULL;
    }
}

bool EpollMode::InitListen()
{
    this->epollFd = epoll_create(MAXEPOLLSIZE);
    if (this->epollFd < 0)
    {
        ERRORLOG("EpollMode error");
        return false;
    }
    this->fdServerMain = net_tcp::initialize_listen_server(kServerMainPort, 1000);
    this->EpollLoop(this->fdServerMain, EPOLLIN | EPOLLOUT | EPOLLET);
    return true;
}

void EpollMode::EpollWork(EpollMode *epmd)
{
    epmd->InitListen();
    global::listen_thread_inited = true;
    global::conditionListenThread.notify_all();
    epmd->EpollLoop();
}

bool EpollMode::EPOL_MODE_START()
{
    this->_listenThread = new std::thread(EpollMode::EpollWork, this);
    this->_listenThread->detach();
    return true;
}

int EpollMode::EpollLoop()
{
    INFOLOG("EpollMode working");
    int nfds, n;
    // NET-016: Use sockaddr_storage to support both IPv4 and IPv6
    struct sockaddr_storage cliaddr;
    socklen_t socklen = sizeof(struct sockaddr_storage);
    struct epoll_event events[MAXEPOLLSIZE];
    struct rlimit rt;
    u32 u32_ip;
    u16 u16_port;
    std::string clientAddrStr;  // NET-016: String representation of client address
    int eFd;
    MsgData data;
    //Sets the maximum number of files allowed to be opened per process
    rt.rlim_max = rt.rlim_cur = MAXEPOLLSIZE;
    if (setrlimit(RLIMIT_NOFILE, &rt) == -1)
    {
        ERRORLOG("setrlimit error");
    }
    INFOLOG("epoll loop EPOL_MODE_START success!");
    while (haltListening)
    {

        //Wait for something to happen
        nfds = epoll_wait(this->epollFd, events, MAXEPOLLSIZE, 1 * 1000);
        if (nfds == -1)
        {
            continue;
        }
        //Handle all events
        for (n = 0; n < nfds; ++n)
        {
            if (events[n].events & EPOLLERR)
            {
                int status, err;
                socklen_t len;
                err = 0;
                len = sizeof(err);
                eFd = events[n].data.fd;
                status = getsockopt(eFd, SOL_SOCKET, SO_ERROR, &err, &len);
                //Connection failed
                if (status == 0)
                {
                    MagicSingleton<PeerNode>::GetInstance()->delete_by_fd(eFd);
                }
            }
            //Handle primary connection listening
            if (events[n].data.fd == this->fdServerMain)
            {
                int connFd = 0;
                int lisFd = events[n].data.fd;

                while (true)
                {
                    socklen = sizeof(cliaddr);
                    connFd = net_tcp::Accept(lisFd, (struct sockaddr *)&cliaddr, &socklen);
                    if (connFd <= 0)
                    {
                        break;
                    }

                    // NET-016: Extract address based on address family. Dual-stack
                    // sockets report IPv4 clients as IPv4-mapped IPv6 addresses.
                    if (cliaddr.ss_family == AF_INET) {
                        struct sockaddr_in* ipv4 = (struct sockaddr_in*)&cliaddr;
                        u32_ip = ipv4->sin_addr.s_addr;
                        u16_port = ntohs(ipv4->sin_port);
                        char buf[INET_ADDRSTRLEN];
                        inet_ntop(AF_INET, &ipv4->sin_addr, buf, sizeof(buf));
                        clientAddrStr = buf;
                    } else if (cliaddr.ss_family == AF_INET6) {
                        struct sockaddr_in6* ipv6 = (struct sockaddr_in6*)&cliaddr;
                        u16_port = ntohs(ipv6->sin6_port);
                        if (IN6_IS_ADDR_V4MAPPED(&ipv6->sin6_addr)) {
                            struct in_addr mapped4;
                            memcpy(&mapped4.s_addr, &ipv6->sin6_addr.s6_addr[12], sizeof(mapped4.s_addr));
                            u32_ip = mapped4.s_addr;
                            char buf[INET_ADDRSTRLEN];
                            inet_ntop(AF_INET, &mapped4, buf, sizeof(buf));
                            clientAddrStr = buf;
                        } else {
                            u32_ip = 0;
                            char buf[INET6_ADDRSTRLEN];
                            inet_ntop(AF_INET6, &ipv6->sin6_addr, buf, sizeof(buf));
                            clientAddrStr = buf;
                        }
                    } else {
                        ERRORLOG("Unknown address family: {}", cliaddr.ss_family);
                        close(connFd);
                        continue;
                    }
                    
                    // NET-001: Connection rate limiting and limits check
                    auto peerNode = MagicSingleton<PeerNode>::GetInstance();
                    auto nodeList = peerNode->GetNodelist();
                    const auto networkPolicy = GetCurrentNetworkConnectionPolicy();

                    if (networkPolicy.requirePublicAddress && !IsPublicNetworkAddress(clientAddrStr))
                    {
                        WARNLOG("Connection rejected: non-public source {} is not allowed on this network",
                                clientAddrStr);
                        NetworkMetrics::Instance().total_connections_rejected++;
                        close(connFd);
                        continue;
                    }
                    
                    // Check global connection limit
                    if (nodeList.size() >= networkPolicy.maxPeerConnections)
                    {
                        WARNLOG("Connection rejected: global limit reached ({}/{})",
                                 nodeList.size(), networkPolicy.maxPeerConnections);
                        NetworkMetrics::Instance().total_connections_rejected++;
                        close(connFd);
                        continue;
                    }
                    
                    if (networkPolicy.enforcePerIpLimit)
                    {
                        int ipCount = 0;
                        for (const auto& node : nodeList)
                        {
                            if (node.getPublicAddrStr() == clientAddrStr)
                            {
                                ipCount++;
                            }
                        }
                        if (ipCount >= kMaxConnectionsPerIP)
                        {
                            WARNLOG("Connection rejected: per-IP limit reached for {} ({}/{})",
                                     clientAddrStr, ipCount, kMaxConnectionsPerIP);
                            NetworkMetrics::Instance().total_connections_rejected++;
                            close(connFd);
                            continue;
                        }
                    }
                    
                    // NET-014: IPv4 /16 diversity applies to public network modes only.
                    if (networkPolicy.enforceSubnet16Limit && u32_ip != 0)
                    {
                        const uint16_t newSubnet = Ipv4Subnet16(u32_ip);
                        int subnetCount = 0;
                        for (const auto& node : nodeList)
                        {
                            if (node.publicIp == 0 || !IsPublicNetworkAddress(node.getPublicAddrStr()))
                            {
                                continue;
                            }
                            if (Ipv4Subnet16(node.publicIp) == newSubnet)
                            {
                                subnetCount++;
                            }
                        }
                        if (subnetCount >= kMaxConnectionsPerSubnet16)
                        {
                            WARNLOG("Connection rejected: subnet /16 limit reached for {} ({}/{})",
                                     IpPort::IpSz(u32_ip), subnetCount, kMaxConnectionsPerSubnet16);
                            NetworkMetrics::Instance().total_connections_rejected++;
                            close(connFd);
                            continue;
                        }
                    }
                    
                    // NET-014: Check inbound/outbound ratio
                    int inboundCount = 0;
                    int outboundCount = 0;
                    for (const auto& node : nodeList)
                    {
                        if (node.connKind == PASSIV) inboundCount++;
                        else if (node.connKind == dataRateToOutput) outboundCount++;
                    }
                    const int totalConnections = static_cast<int>(nodeList.size());
                    const bool exceedsInboundRatio =
                        (inboundCount + 1) * 100 >
                        (totalConnections + 1) * kMaxInboundRatio;
                    if (networkPolicy.enforceInboundRatio &&
                        outboundCount >= kMinOutboundConnections && exceedsInboundRatio)
                    {
                        WARNLOG("Connection rejected: inbound ratio limit reached (inbound:{}, outbound:{}, total:{} > {}%)",
                                 inboundCount + 1, outboundCount, totalConnections + 1, kMaxInboundRatio);
                        NetworkMetrics::Instance().total_connections_rejected++;
                        close(connFd);
                        continue;
                    }
                    
                    // Simple rate limiting: check if we're accepting too fast
                    static std::atomic<int> recentAccepts{0};
                    static std::atomic<std::chrono::steady_clock::time_point> lastReset{
                        std::chrono::steady_clock::now()};
                    
                    auto now = std::chrono::steady_clock::now();
                    if (now - lastReset.load() > std::chrono::seconds(1))
                    {
                        recentAccepts = 0;
                        lastReset = now;
                    }
                    
                    if (recentAccepts++ >= kMaxNewConnectionsPerSecond)
                    {
                        WARNLOG("Connection rejected: rate limit exceeded ({}/s)",
                                 kMaxNewConnectionsPerSecond);
                        NetworkMetrics::Instance().total_connections_rejected++;
                        close(connFd);
                        continue;
                    }

                    // Connection accepted, proceed with setup
                    NetworkMetrics::Instance().total_connections_accepted++;
                    net_tcp::setFdNonBlocking(connFd);
                    //Turn off all signals
                    int value = 1;
                    setsockopt(connFd, SOL_SOCKET, MSG_NOSIGNAL, &value, sizeof(value));

                    // Configure TCP keepalive
                    int enable = 1;
                    int idle = 60;      // Start probing after 60 seconds idle
                    int interval = 10;  // Probe every 10 seconds
                    int count = 5;      // 5 failures = connection dead
                    setsockopt(connFd, SOL_SOCKET, SO_KEEPALIVE, &enable, sizeof(enable));
                    setsockopt(connFd, IPPROTO_TCP, TCP_KEEPIDLE, &idle, sizeof(idle));
                    setsockopt(connFd, IPPROTO_TCP, TCP_KEEPINTVL, &interval, sizeof(interval));
                    setsockopt(connFd, IPPROTO_TCP, TCP_KEEPCNT, &count, sizeof(count));

                    auto self = peerNode->GetSelfNode();
                    DEBUGLOG(YELLOW "u32_ip({}),u16_port({}),self.publicIp({}),self.local_ip({})" RESET, IpPort::IpSz(u32_ip), u16_port, IpPort::IpSz(self.publicIp), IpPort::IpSz(self.listenIp));

                    if (!clientAddrStr.empty() && IpPort::IsIPv6(clientAddrStr))
                    {
                        MagicSingleton<bufferControl>::GetInstance()->AddBuffer(clientAddrStr, u16_port, connFd);
                    }
                    else
                    {
                        MagicSingleton<bufferControl>::GetInstance()->AddBuffer(u32_ip, u16_port, connFd);
                    }
                    MagicSingleton<EpollMode>::GetInstance()->EpollLoop(connFd, EPOLLIN | EPOLLOUT | EPOLLET);
                }
                if (connFd == -1)
                {
                    if (errno != EAGAIN && errno != ECONNABORTED && errno != EPROTO && errno != EINTR)
                        ERRORLOG("accept");
                }
                continue;
            }
            if (events[n].events & EPOLLIN)
            {
                eFd = events[n].data.fd;
                this->DeleteEpollEvent(eFd);
                u32_ip = IpPort::get_peer_nip_info(eFd);
                u16_port = IpPort::GetPeerPort(eFd);
                if(u16_port == kServerMainPort)
                {
                     u16_port = IpPort::GetConnectPort(eFd);
                }

                data.ip = u32_ip;
                data.addr = IpPort::get_peer_addr_str(eFd);
                if (u32_ip != 0) data.addr.clear();
                data.port = u16_port;
                data.type = E_READ;
                data.fd = eFd;
                global::queueReader.Push(data);
            }
            if (events[n].events & EPOLLOUT)
            {
                eFd = events[n].data.fd;
                u32_ip = IpPort::get_peer_nip_info(eFd);
                u16_port = IpPort::GetPeerPort(eFd);
                if(u16_port == kServerMainPort)
                {
                     u16_port = IpPort::GetConnectPort(eFd);
                }
                
                std::string peerAddr = IpPort::get_peer_addr_str(eFd);
                bool isempty = (u32_ip == 0 && !peerAddr.empty())
                    ? MagicSingleton<bufferControl>::GetInstance()->IsCacheEmpty(peerAddr, u16_port)
                    : MagicSingleton<bufferControl>::GetInstance()->IsCacheEmpty(u32_ip, u16_port);
                if(isempty){
                    continue;
                }
                MsgData send;
                send.type = E_WRITE;
                send.fd = eFd;
                send.ip = u32_ip;
                if (u32_ip == 0) send.addr = peerAddr;
                send.port = u16_port;
                global::queue_write_counter.Push(send);
            }
        }
    }
    return 0;
}

bool EpollMode::EpollLoop(int fd, int state)
{
    struct epoll_event ev;
    memset(&ev, 0, sizeof(ev));
    ev.events = state;
    ev.data.fd = fd;

    int ret = epoll_ctl(this->epollFd, EPOLL_CTL_ADD, fd, &ev);

    if (0 != ret)
    {
        return false;
    }
    return true;
}

bool EpollMode::DeleteEpollEvent(int fd)
{
    int ret = epoll_ctl(this->epollFd, EPOLL_CTL_DEL, fd, NULL);
    if (0 != ret)
    {
        return false;
    }
    return true;
}
