#include "./peer_node.h"

#include <sys/time.h>
#include <chrono>
#include <bitset>
#include <algorithm>

#include "./ip_port.h"
#include "./api.h"
#include "./epoll_mode.h"
#include "./global.h"
#include "./connection_attempt.h"
#include "./network_policy.h"
#include "./key_exchange.h"
#include "./unregister_node.h"

#include "../include/logging.h"
#include "../utils/contract_utils.h"
#include "../utils/console.h"
#include "../net/unregister_node.h"
#include "../net/global.h"
#include "../common/config.h"
#include "metrics.h"

namespace {
std::vector<NodeEndpoint> buildEndpointCandidates(const Node& node)
{
	std::vector<NodeEndpoint> endpoints = node.endpoints;
	if (endpoints.empty())
	{
		std::string addr = node.getPublicAddrStr();
		if (!addr.empty() && node.listenPort != 0)
		{
			IpVersion family = IpPort::IsIPv6(addr) ? IpVersion::IPv6 : IpVersion::IPv4;
			endpoints.push_back(NodeEndpoint{addr, static_cast<uint16_t>(node.listenPort), family, 0});
		}
	}
	std::sort(endpoints.begin(), endpoints.end(), [](const NodeEndpoint& left, const NodeEndpoint& right) {
		return left.priority < right.priority;
	});
	return endpoints;
}

uint32_t endpointIp4(const NodeEndpoint& endpoint)
{
	if (endpoint.family == IpVersion::IPv6 || IpPort::IsIPv6(endpoint.addr))
	{
		return 0;
	}
	uint32_t ip = IpPort::IpNum(endpoint.addr);
	return ip == static_cast<uint32_t>(-1) ? 0 : ip;
}

std::vector<std::vector<NodeEndpoint>> buildConfiguredServerEndpointGroups()
{
	auto configServerEndpointGroups = MagicSingleton<Config>::GetInstance()->GetServerEndpointGroups();
	std::vector<std::vector<NodeEndpoint>> serverEndpointGroups;
	for (auto & group: configServerEndpointGroups)
	{
		std::vector<NodeEndpoint> endpoints;
		for (auto & endpoint: group.endpoints)
		{
			uint16_t endpointPort = static_cast<uint16_t>(endpoint.port);
			IpVersion family = endpoint.family == 6 ? IpVersion::IPv6 : (endpoint.family == 4 ? IpVersion::IPv4 : IpVersion::Unknown);
			endpoints.push_back(NodeEndpoint{endpoint.addr, endpointPort, family, endpoint.priority});
		}
		if (!endpoints.empty())
		{
			serverEndpointGroups.push_back(endpoints);
		}
	}
	return serverEndpointGroups;
}

bool endpointMatches(const NodeEndpoint& left, const NodeEndpoint& right)
{
	return left.port == right.port &&
	       EndpointAddressesEquivalent(left.addr, right.addr);
}

bool nodeMatchesEndpoint(const Node& node, const NodeEndpoint& endpoint)
{
	for (const auto& nodeEndpoint : node.endpoints)
	{
		if (endpointMatches(nodeEndpoint, endpoint))
		{
			return true;
		}
	}
	return node.IsConnected() && node.listenPort == endpoint.port &&
	       EndpointAddressesEquivalent(node.getPublicAddrStr(), endpoint.addr);
}

bool endpointMatchesSelf(const NodeEndpoint& endpoint, const Node& selfNode)
{
	const auto matches = [&](const std::string& address, uint32_t port) {
		return port != 0 && endpoint.port == port &&
		       EndpointAddressesEquivalent(endpoint.addr, address);
	};
	for (const auto& selfEndpoint : selfNode.endpoints)
	{
		if (endpointMatches(selfEndpoint, endpoint)) return true;
	}
	if (matches(selfNode.getListenAddrStr(), selfNode.listenPort) ||
	    matches(selfNode.getPublicAddrStr(), selfNode.publicPort) ||
	    matches(global::g_localIp, selfNode.listenPort))
	{
		return true;
	}
	for (const auto& configured : MagicSingleton<Config>::GetInstance()->GetEndpoints())
	{
		const uint32_t port = configured.port != 0 ? configured.port : selfNode.listenPort;
		if (matches(configured.addr, port)) return true;
	}
	return false;
}

std::vector<std::vector<NodeEndpoint>> disconnectedServerEndpointGroups(
	const std::vector<std::vector<NodeEndpoint>>& serverEndpointGroups)
{
	std::vector<std::vector<NodeEndpoint>> disconnected;
	const auto nodeList = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
	const Node selfNode = MagicSingleton<PeerNode>::GetInstance()->GetSelfNode();
	for (const auto& group : serverEndpointGroups)
	{
		if (std::any_of(group.begin(), group.end(), [&](const NodeEndpoint& endpoint) {
			return endpointMatchesSelf(endpoint, selfNode);
		}))
		{
			continue;
		}
		const bool connected = std::any_of(group.begin(), group.end(), [&](const NodeEndpoint& endpoint) {
			return std::any_of(nodeList.begin(), nodeList.end(), [&](const Node& node) {
				return node.IsConnected() && nodeMatchesEndpoint(node, endpoint);
			});
		});
		if (!connected) disconnected.push_back(group);
	}
	return disconnected;
}


}

bool PeerNode::Add(const Node& node)
{
	uint64_t chainHeight = 0;
	if(!net_callback::onCalculateChainHeight(chainHeight))
	{
		return false;
	}

	std::unique_lock<std::shared_mutex> lck(mutexForNodes);
	if(node.address.size() == 0)
	{
		return false;
	} 
	if (_nodeMap.size() >= GetCurrentNetworkConnectionPolicy().maxPeerConnections)
	{
		return false;
	}
	if(MagicSingleton<Config>::GetInstance()->_Verify(node) != 0)
	{
		return false;
	}
	auto itr = _nodeMap.find(node.address);
	if (itr != _nodeMap.end())
	{
		return false;
	}
	DEBUGLOG("PeerNode::Add ip:{}, publicport:{}, fd:{}",node.getPublicAddrStr(), node.publicPort, node.fd);
	this->_nodeMap[node.address] = node;
	
	// QUAL-001: Maintain reverse index
	_fdToAddress[node.fd] = node.address;

	// FEAT-001: Update connection metrics
	NetworkMetrics::Instance().active_connections++;
	if (node.connKind == PASSIV) {
		NetworkMetrics::Instance().inbound_connections++;
	} else if (node.connKind == dataRateToOutput) {
		NetworkMetrics::Instance().outbound_connections++;
	}

	return true;
}

bool PeerNode::Update(const Node & node)
{
	uint64_t chainHeight = 0;
	if(!net_callback::onCalculateChainHeight(chainHeight))
	{
		return false;
	}

	{
		std::unique_lock<std::shared_mutex> lck(mutexForNodes);
		auto itr = this->_nodeMap.find(node.address);
		if (itr == this->_nodeMap.end())
		{
			return false;
		}
		
		if (itr->second.connKind != node.connKind)
		{
			if (itr->second.connKind == PASSIV)
				NetworkMetrics::Instance().inbound_connections--;
			else if (itr->second.connKind == dataRateToOutput)
				NetworkMetrics::Instance().outbound_connections--;

			if (node.connKind == PASSIV)
				NetworkMetrics::Instance().inbound_connections++;
			else if (node.connKind == dataRateToOutput)
				NetworkMetrics::Instance().outbound_connections++;
		}
		
		// A peer can have more than one live fd during simultaneous
		// inbound/outbound reconnects. Keep existing fd bindings and add
		// the latest fd as another valid path for identity verification.
		if (node.fd > 0) {
			_fdToAddress[node.fd] = node.address;
		}
		
		Node merged = node;
		if (merged.fd <= 0) {
			merged.fd = itr->second.fd;
		}
		this->_nodeMap[node.address] = merged;
	}

	return true;
}

bool PeerNode::AddOrUpdate(Node node)
{
	std::unique_lock<std::shared_mutex> lck(mutexForNodes);
	
	if (node.address.empty()) {
		return false;
	}

	// Do not erase an older fd for the same peer. Inbound and outbound
	// connections can coexist briefly and both must pass identity checks.
	if (node.fd > 0) {
		_fdToAddress[node.fd] = node.address;
	}

	auto it = _nodeMap.find(node.address);
	if (it != _nodeMap.end()) {
		Node merged = node;
		if (merged.fd <= 0) {
			merged.fd = it->second.fd;
		}
		this->_nodeMap[node.address] = merged;
	} else {
		this->_nodeMap[node.address] = node;
	}

	return true;
}

void PeerNode::DeleteNode(std::string Addr)
{
	DEBUGLOG("DeleteNode addr:{}", Addr);
	std::unique_lock<std::shared_mutex> lck(mutexForNodes);
	auto nodeIt = _nodeMap.find(Addr);
	
	if (nodeIt != _nodeMap.end())
	{
		// FEAT-001: Update connection metrics before removing
		NetworkMetrics::Instance().active_connections--;
		NetworkMetrics::Instance().total_disconnects++;
		if (nodeIt->second.connKind == PASSIV) {
			NetworkMetrics::Instance().inbound_connections--;
		} else if (nodeIt->second.connKind == dataRateToOutput) {
			NetworkMetrics::Instance().outbound_connections--;
		}

		int fd = nodeIt->second.fd;
		
		// QUAL-001: Remove from reverse index
		_fdToAddress.erase(fd);
		
		if(fd > 0)
		{
			MagicSingleton<ConnectionAttemptManager>::GetInstance()->ReleaseFd(fd, "node_deleted");
			MagicSingleton<KeyExchangeManager>::GetInstance()->removeKey(fd);
			MagicSingleton<EpollMode>::GetInstance()->DeleteEpollEvent(fd);
			close(fd);
		}	
		u32 ip = nodeIt->second.publicIp;
		u16 port = nodeIt->second.publicPort;
		const std::string addr = nodeIt->second.getPublicAddrStr();
		bool deleted = false;
		if (!addr.empty())
		{
			deleted = MagicSingleton<bufferControl>::GetInstance()->DeleteBuffer(addr, port);
		}
		if(!deleted && !MagicSingleton<bufferControl>::GetInstance()->DeleteBuffer(ip, port))
		{
			ERRORLOG(RED "DeleteBuffer ERROR ip:({}), port:({}) " RESET, addr, port);
		}

		MagicSingleton<UnregisterNode>::GetInstance()->deleteSplitNodeList(nodeIt->first);			
		nodeIt = _nodeMap.erase(nodeIt);
	}
	else
	{
		DEBUGLOG("Not found  {} in _nodeMap", Addr);
	}
}

void PeerNode::CloseFd(int fd)
{
	delete_by_fd(fd);
}

void PeerNode::delete_by_fd(int fd)
{
	if (fd <= 0)
	{
		return;
	}

	MagicSingleton<ConnectionAttemptManager>::GetInstance()->ReleaseFd(fd, "socket_closed");
	MagicSingleton<KeyExchangeManager>::GetInstance()->removeKey(fd);
	std::unique_lock<std::shared_mutex> lck(mutexForNodes);
	
	auto fdIt = _fdToAddress.find(fd);
	if (fdIt == _fdToAddress.end()) {
		MagicSingleton<bufferControl>::GetInstance()->DeleteBuffer(fd);
		MagicSingleton<EpollMode>::GetInstance()->DeleteEpollEvent(fd);
		close(fd);
		removeFdMutex(fd);
		return;
	}
	
	const std::string address = fdIt->second;
	auto nodeIt = _nodeMap.find(address);
	_fdToAddress.erase(fdIt);

	bool hasOtherFd = false;
	int replacementFd = -1;
	for (const auto& item : _fdToAddress)
	{
		if (item.second == address)
		{
			hasOtherFd = true;
			replacementFd = item.first;
			break;
		}
	}

	MagicSingleton<bufferControl>::GetInstance()->DeleteBuffer(fd);
	MagicSingleton<EpollMode>::GetInstance()->DeleteEpollEvent(fd);
	close(fd);
	removeFdMutex(fd);

	if (nodeIt == _nodeMap.end()) {
		return;
	}

	if (hasOtherFd)
	{
		if (nodeIt->second.fd == fd)
		{
			nodeIt->second.fd = replacementFd;
		}
		DEBUGLOG("Delete fd only, keep node addr:{}, replacement_fd:{}", address, replacementFd);
		return;
	}

	// FEAT-001: Update connection metrics before removing the last fd for this node.
	NetworkMetrics::Instance().active_connections--;
	NetworkMetrics::Instance().total_disconnects++;
	if (nodeIt->second.connKind == PASSIV) {
		NetworkMetrics::Instance().inbound_connections--;
	} else if (nodeIt->second.connKind == dataRateToOutput) {
		NetworkMetrics::Instance().outbound_connections--;
	}

	MagicSingleton<UnregisterNode>::GetInstance()->deleteSplitNodeList(nodeIt->first);
	_nodeMap.erase(nodeIt);
}


void PeerNode::Print(std::vector<Node> & nodeList)
{
	std::cout << std::endl;
	std::cout << "------------------------------------------------------------------------------------------------------------" << std::endl;
	for (auto& i : nodeList)
	{
		i.Print();
	}
	std::cout << "------------------------------------------------------------------------------------------------------------" << std::endl;
	std::cout << "PeerNode size is: " << nodeList.size() << std::endl;
}

void PeerNode::Print(const Node & node)
{
	std::cout << "---------------------------------- node info --------------------------------------------------------------------------" << std::endl;
	
	std::cout << "publicIp: " << node.getPublicAddrStr() << std::endl;
	std::cout << "localIp: " << node.getListenAddrStr() << std::endl;
	std::cout << "publicPort: " << node.publicPort << std::endl;
	std::cout << "localPort: " << node.listenPort << std::endl;
	std::cout << "connKind: " << node.connKind << std::endl;
	std::cout << "fd: " << node.fd << std::endl;
	std::cout << "pulse: " << node.pulse << std::endl;
	std::cout << "address: " << node.address << std::endl;
	std::cout << "chainHeight: " << node.height << std::endl;

	std::cout << "---------------------------------- end --------------------------------------------------------------------------" << std::endl;
}

std::string PeerNode::NodelistInfo(std::vector<Node> & nodeList)
{
	std::ostringstream oss;	
	oss << std::endl;
	oss << "------------------------------------------------------------------------------------------------------------" << std::endl;
	for (auto& i : nodeList)
	{
		oss << i.InfoStr();
	}
	oss << "------------------------------------------------------------------------------------------------------------" << std::endl;
	oss << "PeerNode size is: " << nodeList.size() << std::endl;
	return oss.str();
}



bool PeerNode::locateNodeByFd(int fd, Node &node)
{
	std::shared_lock<std::shared_mutex> lck(mutexForNodes);
	
	// QUAL-001: O(1) lookup using reverse index
	auto fdIt = _fdToAddress.find(fd);
	if (fdIt == _fdToAddress.end()) {
		return false;
	}
	
	auto nodeIt = _nodeMap.find(fdIt->second);
	if (nodeIt == _nodeMap.end()) {
		return false;
	}
	
	node = nodeIt->second;
	return true;
}

bool PeerNode::BindFdToAddress(int fd, const std::string& address)
{
	if (fd <= 0 || address.empty())
	{
		return false;
	}

	std::unique_lock<std::shared_mutex> lck(mutexForNodes);
	auto nodeIt = _nodeMap.find(address);
	if (nodeIt == _nodeMap.end())
	{
		return false;
	}

	_fdToAddress[fd] = address;
	if (nodeIt->second.fd <= 0)
	{
		nodeIt->second.fd = fd;
	}
	return true;
}

bool PeerNode::verifyPeerNodeIdRequest(const int fd, const std::string &peerId)
{
	Node node;
    if(!MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(fd, node))
    {
        WARNLOG("Invalid message peerNode_id:{}, node.address:{}", peerId, node.address);
        return false;
    }
    if(peerId != node.address)
    {
        WARNLOG("Invalid message peerNode_id:{}, node.address:{}", peerId, node.address);
        return false;
    }
	return true;
}

// find node
bool PeerNode::FindNode(std::string const &Addr, Node &x)
{
	std::shared_lock<std::shared_mutex> lck(mutexForNodes);

	std::string strId = Addr;
	auto it = _nodeMap.find(strId);
	if (it != _nodeMap.end())
	{
		x = it->second;
		return true;
	}
	return false;
}

std::vector<Node> PeerNode::GetNodelist(NodeType type, bool mustAlive)
{
	std::shared_lock<std::shared_mutex> lck(mutexForNodes);
	std::vector<Node> rst;
	auto cb = _nodeMap.cbegin(), ce = _nodeMap.cend();
	for (; cb != ce; ++cb)
	{
		if(type == NODE_ALL || (type == NODE_PUBLIC))
		{
			if(mustAlive)
			{
				if(cb->second.IsConnected())
				{
					rst.push_back(cb->second);
				}
			}else{
				rst.push_back(cb->second);
			}
		}
	}
	return rst;
}
void PeerNode::GetNodelist(std::map<std::string, bool>& nodeAddrs, NodeType type, bool mustAlive)
{
	std::shared_lock<std::shared_mutex> lck(mutexForNodes);
	auto cb = _nodeMap.cbegin(), ce = _nodeMap.cend();
	for (; cb != ce; ++cb)
	{
		if(type == NODE_ALL || (type == NODE_PUBLIC))
		{
			if(mustAlive)
			{
				if(cb->second.IsConnected())
				{
					nodeAddrs[cb->first] = false;
				}
			}else{
				nodeAddrs[cb->first] = false;
			}
		}
	}
	return;
}

uint64_t PeerNode::GetNodelistSize()
{
	std::shared_lock<std::shared_mutex> lck(mutexForNodes);
	return _nodeMap.size();
}

// Refresh threads
extern std::atomic<int> node_list_refresh_time;
bool PeerNode::initNodeListRefreshThread()
{
	_refreshThread = std::thread(std::bind(&PeerNode::refreshNodeListThread, this));
	_refreshThread.detach();
	return true;
}

//Network nodes swap threads
bool PeerNode::nodelistSwitchThread()
{
	nodeSwitchThread = std::thread(std::bind(&PeerNode::switchNodeListThread, this));
	nodeSwitchThread.detach();
	return true;
}

void PeerNode::switchNodeListThread()
{
	std::stringstream ss;
    ss << std::this_thread::get_id();
	INFOLOG("switchNodeListThread started, thread_id: {}", ss.str());

	auto serverEndpointGroups = buildConfiguredServerEndpointGroups();
	auto pendingEndpointGroups = disconnectedServerEndpointGroups(serverEndpointGroups);
	bool bootstrapCompleted = pendingEndpointGroups.empty();
	int normalSyncElapsed = 0;
	int bootstrapElapsed = 0;
	int bootstrapRetryDelay = kServerEndpointRetryInitialSeconds;

	do
	{
		sleep(kServerEndpointRetryTickSeconds);
		if(!nodesSwapEnd)
		{
			DEBUGLOG("switchNodeListThread exiting due to nodesSwapEnd=false, thread_id: {}", ss.str());
			return;
		}

		normalSyncElapsed += kServerEndpointRetryTickSeconds;
		bootstrapElapsed += kServerEndpointRetryTickSeconds;

		if (bootstrapCompleted)
		{
			pendingEndpointGroups = disconnectedServerEndpointGroups(serverEndpointGroups);
			if (!pendingEndpointGroups.empty())
			{
				bootstrapCompleted = false;
				bootstrapElapsed = 0;
				bootstrapRetryDelay = kServerEndpointRetryInitialSeconds;
				WARNLOG("Configured server endpoint groups disconnected pending:{} total:{}",
				        pendingEndpointGroups.size(), serverEndpointGroups.size());
			}
		}

		if (!bootstrapCompleted && bootstrapElapsed >= bootstrapRetryDelay)
		{
			pendingEndpointGroups = disconnectedServerEndpointGroups(serverEndpointGroups);
			if (pendingEndpointGroups.empty())
			{
				bootstrapCompleted = true;
				INFOLOG("Server endpoint bootstrap completed groups:{}", serverEndpointGroups.size());
			}
			else
			{
				const size_t pendingBefore = pendingEndpointGroups.size();
				MagicSingleton<UnregisterNode>::GetInstance()->startRegistrationNode(pendingEndpointGroups);
				pendingEndpointGroups = disconnectedServerEndpointGroups(serverEndpointGroups);
				bootstrapCompleted = pendingEndpointGroups.empty();
				if (bootstrapCompleted)
				{
					INFOLOG("Server endpoint bootstrap connected all groups total:{}", serverEndpointGroups.size());
				}
				else if (pendingEndpointGroups.size() < pendingBefore)
				{
					bootstrapRetryDelay = kServerEndpointRetryInitialSeconds;
				}
				else
				{
					bootstrapRetryDelay = std::min(bootstrapRetryDelay * 2, kServerEndpointRetryMaxSeconds);
				}
			}
			bootstrapElapsed = 0;
		}

		if (normalSyncElapsed >= global::node_list_refresh_time)
		{
			MagicSingleton<UnregisterNode>::GetInstance()->syncStartNode();
			normalSyncElapsed = 0;
		}
	} while (true);
}

//Thread functions
void PeerNode::refreshNodeListThread()
{
	std::stringstream ss;
    ss << std::this_thread::get_id();
	INFOLOG("refreshNodeListThread started, thread_id: {}", ss.str());
	std::lock_guard<std::mutex> lck(global::mutex_listen_thread);
	while(!global::listen_thread_inited)
	{
		global::conditionListenThread.wait(global::mutex_listen_thread);
	}
	auto serverEndpointGroups = buildConfiguredServerEndpointGroups();
	MagicSingleton<UnregisterNode>::GetInstance()->startRegistrationNode(serverEndpointGroups);
	DEBUGLOG("refreshNodeListThread exiting normally, thread_id: {}", ss.str());
}

int PeerNode::ConnectNode(Node & node)
{
	if (node.fd > 0)
	{
		return -1;
	}

	net_com::ANALYSIS_CONNECTION_KIND(node);

	std::vector<NodeEndpoint> candidates = buildEndpointCandidates(node);
	if (candidates.empty())
	{
		ERRORLOG("ConnectNode failed: node {} has no endpoint", node.address);
		return -2;
	}

	for (const auto& endpoint : candidates)
	{
		if (!endpoint.isValid())
		{
			continue;
		}

		u16 connectPort = 0;
		int cfd = 0;
		uint32_t ip4 = endpointIp4(endpoint);
		if (ip4 != 0)
		{
			cfd = net_com::InitConnection(ip4, endpoint.port, connectPort);
		}
		else
		{
			cfd = net_com::InitConnection(endpoint.addr, endpoint.port, connectPort);
		}

		if (cfd <= 0)
		{
			DEBUGLOG("ConnectNode endpoint failed addr:{} listen_port:{} ret:{}", endpoint.addr, endpoint.port, cfd);
			continue;
		}

			node.fd = cfd;
		node.publicPort = connectPort;
		node.listenPort = endpoint.port;
		node.setConnectedEndpoint(NodeEndpoint{endpoint.addr, connectPort, endpoint.family, endpoint.priority});
		if (ip4 != 0)
		{
			node.publicIp = ip4;
			MagicSingleton<bufferControl>::GetInstance()->AddBuffer(ip4, connectPort, cfd);
		}
		else
		{
			node.publicIp = 0;
			MagicSingleton<bufferControl>::GetInstance()->AddBuffer(endpoint.addr, connectPort, cfd);
		}
		MagicSingleton<EpollMode>::GetInstance()->EpollLoop(cfd, EPOLLIN | EPOLLET | EPOLLOUT);
		return 0;
	}

	return -2;
}

int PeerNode::DisconnectNode(Node & node)
{
	if (node.fd <= 0) return -1;
	delete_by_fd(node.fd);
	node.fd = -1;
	return 0;
}

int PeerNode::DisconnectNode(uint32_t ip, uint16_t port, int fd)
{
	if (fd <= 0) return -1;
	delete_by_fd(fd);
	return 0;
}

//Get the ID
const std::string PeerNode::GetSelfId()
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	return _currNode.address;
}

//Get pub
const std::string PeerNode::GetSelfPub()
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	return _currNode.pub;
}

// Set the ID
void PeerNode::SetSelfId(const std::string &Addr)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	_currNode.address = Addr;
}

// Set the node ID
void PeerNode::SetSelfIdentity(const std::string & identity)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	_currNode.identity = identity;
}

//Set the node name
void PeerNode::SetSelfName(const std::string &name)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	_currNode.name = name;
}

//Set the node logo
void PeerNode::set_user_logo(const std::string &logo)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	_currNode.logo = logo;
}

// Set the IP
void PeerNode::set_self_ip_public(const u32 publicIp)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	_currNode.publicIp = publicIp;
}

void PeerNode::set_self_addr_public(const std::string& publicAddr)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	_currNode.setPublicAddr(publicAddr);
}

void PeerNode::add_self_endpoint(const NodeEndpoint& endpoint)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	_currNode.addEndpoint(endpoint.addr, endpoint.port, endpoint.family, endpoint.priority);
}

// Set the IP
void PeerNode::set_self_ip_listen(const u32 listenIp)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	_currNode.listenIp = listenIp;
}

void PeerNode::set_self_addr_listen(const std::string& listenAddr)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	_currNode.setListenAddr(listenAddr);
}


//Set the port
void PeerNode::setPublicSelfPort(const u16 portPublic)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	_currNode.publicPort = portPublic;
}


// Set the port
void PeerNode::configureSelfPortForListening(const u16 portListen)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	_currNode.listenPort = portListen;
}

void PeerNode::SetSelfHeight(u32 height)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
    _currNode.SetHeight(height);
}

void PeerNode::SetSelfHeight()
{
	if (net_callback::chain_height_handler)
	{
		uint32_t height = 0;
		int ret = net_callback::chain_height_handler(height);
		if (ret >= 0)
		{
            SetSelfHeight(height);
		}
	}
	else
	{
		INFOLOG("Set self chain height: callback empty!!!");
	}
}

void PeerNode::SetSelfVer(const std::string & ver)
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	_currNode.ver = ver;
}

u32 PeerNode::get_self_chain_height_newest()
{
	// Update to newest chain height
    SetSelfHeight();
	return _currNode.height;
}


// Own node
const Node PeerNode::GetSelfNode()
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	return _currNode;
}


// Get the  address
const std::string PeerNode::GetAddress()
{
	std::lock_guard<std::mutex> lck(mutexForCurrent);
	return _currNode.address;
}

int PeerNode::UpdateAddress(const std::string &oldPub, const std::string & newPub)
{
	if (oldPub.size() == 0 || newPub.size() == 0)
	{
		return -1;
	}
	
	std::string oldAddr = GenerateAddr(oldPub);
	std::string newAddr = GenerateAddr(newPub);
	
	Node node;
	if (!FindNode(oldAddr, node))
	{
		return -2;
	}
	
	node.address = newAddr;
	node.identity = newPub;

	DeleteNode(oldAddr);
	if (!Add(node))
	{
		return -3;
	}
	return 0;
}

// NET-006: Schedule a node for reconnection
void PeerNode::scheduleReconnect(const Node& node) {
    // Check reputation before scheduling
    if (node.peer_stats.total_score < kReconnectMinReputation) {
        DEBUGLOG("NET-006: Node {} reputation too low ({:.2f}), skip reconnect", 
                 node.address, node.peer_stats.total_score);
        return;
    }
    
    std::lock_guard<std::mutex> lock(reconnectMutex);
    
    auto it = reconnectQueue.find(node.address);
    if (it == reconnectQueue.end()) {
        ReconnectEntry entry;
        entry.node_info = node;
        entry.attempt_count = 0;
        entry.next_attempt = std::chrono::steady_clock::now() + 
                            std::chrono::milliseconds(kReconnectBaseDelayMs);
        reconnectQueue[node.address] = entry;
        INFOLOG("NET-006: Scheduled reconnect for node {}", node.address);
    }
}

// NET-006: Process pending reconnections (called from heartbeat timer)
void PeerNode::processReconnects() {
    std::lock_guard<std::mutex> lock(reconnectMutex);
    
    auto now = std::chrono::steady_clock::now();
    static int reconnectsThisSecond = 0;
    static std::chrono::steady_clock::time_point lastReset = now;
    
    // Reset counter every second
    if (now - lastReset > std::chrono::seconds(1)) {
        reconnectsThisSecond = 0;
        lastReset = now;
    }
    
    for (auto it = reconnectQueue.begin(); it != reconnectQueue.end(); ) {
        auto& entry = it->second;
        
        // Check if it's time to reconnect
        if (now < entry.next_attempt) {
            ++it;
            continue;
        }
        
        // Check max attempts
        if (entry.attempt_count >= kMaxReconnectAttempts) {
            DEBUGLOG("NET-006: Node {} exceeded max reconnect attempts, removing", 
                     entry.node_info.address);
            it = reconnectQueue.erase(it);
            continue;
        }
        
        // Check global rate limit
        if (reconnectsThisSecond >= kMaxReconnectsPerSecond) {
            ++it;
            continue;
        }
        
        // Attempt reconnection
        entry.attempt_count++;
        reconnectsThisSecond++;
        
        INFOLOG("NET-006: Reconnecting to node {} (attempt {}/{})", 
                entry.node_info.address, entry.attempt_count, kMaxReconnectAttempts);
        
        Node node = entry.node_info;
        int ret = ConnectNode(node);
        
        if (ret == 0) {
            INFOLOG("NET-006: Reconnected to node {}", node.address);
            it = reconnectQueue.erase(it);
        } else {
            // Full Jitter exponential backoff
            int64_t expDelay = kReconnectBaseDelayMs * (1LL << std::min(entry.attempt_count, 20));
            int64_t cap = std::min(expDelay, (int64_t)kReconnectMaxDelayMs);
            std::mt19937 rng(std::random_device{}());
            std::uniform_int_distribution<int64_t> dist(0, cap);
            int64_t delay = dist(rng);
            
            entry.next_attempt = now + std::chrono::milliseconds(delay);
            DEBUGLOG("NET-006: Reconnect failed, next attempt in {}ms", delay);
            ++it;
        }
    }
}
