﻿#include "net_version.h"

namespace ohi {
    
    // NET-013: Semantic versioning (major.minor.patch)
    const std::string GetNetVersion()
    {
        return "0.1.0";
    }

}
