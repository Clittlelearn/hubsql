/**
 * *****************************************************************************
 * @file        metrics.h
 * @brief       Network metrics collection and export (NET-019)
 * @date        2026-06-25
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef NET_METRICS_HEADER
#define NET_METRICS_HEADER

#include <atomic>
#include <string>
#include <unordered_map>
#include <mutex>

class NetworkMetrics {
public:
    // Connection metrics
    std::atomic<int> active_connections{0};
    std::atomic<int> inbound_connections{0};
    std::atomic<int> outbound_connections{0};
    std::atomic<uint64_t> total_connections_accepted{0};
    std::atomic<uint64_t> total_connections_rejected{0};
    std::atomic<uint64_t> total_disconnects{0};
    
    // Message metrics
    std::atomic<uint64_t> messages_received{0};
    std::atomic<uint64_t> messages_sent{0};
    std::atomic<uint64_t> bytes_received{0};
    std::atomic<uint64_t> bytes_sent{0};
    std::atomic<uint64_t> messages_dropped_dedup{0};
    std::atomic<uint64_t> messages_dropped_rate_limit{0};
    
    // Queue metrics
    std::atomic<int> read_queue_size{0};
    std::atomic<int> work_queue_size{0};
    std::atomic<int> write_queue_size{0};
    
    // Per-type message counts
    mutable std::mutex type_mutex;
    std::unordered_map<std::string, std::atomic<uint64_t>> messages_by_type;
    
    // Singleton access
    static NetworkMetrics& Instance() {
        static NetworkMetrics instance;
        return instance;
    }
    
    // Increment per-type message count
    void incrementMessageType(const std::string& type) {
        std::lock_guard<std::mutex> lock(type_mutex);
        if (messages_by_type.find(type) == messages_by_type.end()) {
            messages_by_type.emplace(type, 0);
        }
        messages_by_type[type]++;
    }
    
    // Export metrics in Prometheus format
    std::string exportPrometheus() const {
        std::string output;
        
        // Connection metrics
        output += "# HELP openhive_network_connections_active Active peer connections\n";
        output += "# TYPE openhive_network_connections_active gauge\n";
        output += "openhive_network_connections_active " + std::to_string(active_connections.load()) + "\n\n";
        
        output += "# HELP openhive_network_connections_inbound Inbound connections\n";
        output += "# TYPE openhive_network_connections_inbound gauge\n";
        output += "openhive_network_connections_inbound " + std::to_string(inbound_connections.load()) + "\n\n";
        
        output += "# HELP openhive_network_connections_outbound Outbound connections\n";
        output += "# TYPE openhive_network_connections_outbound gauge\n";
        output += "openhive_network_connections_outbound " + std::to_string(outbound_connections.load()) + "\n\n";
        
        // Message metrics
        output += "# HELP openhive_network_messages_total Total messages processed\n";
        output += "# TYPE openhive_network_messages_total counter\n";
        output += "openhive_network_messages_total{direction=\"received\"} " + std::to_string(messages_received.load()) + "\n";
        output += "openhive_network_messages_total{direction=\"sent\"} " + std::to_string(messages_sent.load()) + "\n\n";
        
        output += "# HELP openhive_network_bytes_total Total bytes transferred\n";
        output += "# TYPE openhive_network_bytes_total counter\n";
        output += "openhive_network_bytes_total{direction=\"received\"} " + std::to_string(bytes_received.load()) + "\n";
        output += "openhive_network_bytes_total{direction=\"sent\"} " + std::to_string(bytes_sent.load()) + "\n\n";
        
        output += "# HELP openhive_network_messages_dropped Dropped messages\n";
        output += "# TYPE openhive_network_messages_dropped counter\n";
        output += "openhive_network_messages_dropped{reason=\"dedup\"} " + std::to_string(messages_dropped_dedup.load()) + "\n";
        output += "openhive_network_messages_dropped{reason=\"rate_limit\"} " + std::to_string(messages_dropped_rate_limit.load()) + "\n\n";
        
        // Queue metrics
        output += "# HELP openhive_network_queue_size Current queue sizes\n";
        output += "# TYPE openhive_network_queue_size gauge\n";
        output += "openhive_network_queue_size{queue=\"read\"} " + std::to_string(read_queue_size.load()) + "\n";
        output += "openhive_network_queue_size{queue=\"work\"} " + std::to_string(work_queue_size.load()) + "\n";
        output += "openhive_network_queue_size{queue=\"write\"} " + std::to_string(write_queue_size.load()) + "\n\n";
        
        // Per-type metrics
        output += "# HELP openhive_network_messages_by_type Messages by type\n";
        output += "# TYPE openhive_network_messages_by_type counter\n";
        std::lock_guard<std::mutex> lock(type_mutex);
        for (const auto& [type, count] : messages_by_type) {
            output += "openhive_network_messages_by_type{type=\"" + type + "\"} " + std::to_string(count.load()) + "\n";
        }
        
        return output;
    }
    
private:
    NetworkMetrics() = default;
    ~NetworkMetrics() = default;
    NetworkMetrics(const NetworkMetrics&) = delete;
    NetworkMetrics& operator=(const NetworkMetrics&) = delete;
};

#endif // NET_METRICS_HEADER
