#include "connection_attempt.h"

#include <algorithm>
#include <sstream>

#include "key_exchange.h"
#include "network_policy.h"
#include "peer_node.h"
#include "include/logging.h"
#include "utils/magic_singleton.h"

bool ConnectionAttemptManager::IsTerminal(ConnectionAttemptState state)
{
    return state == ConnectionAttemptState::Registered ||
           state == ConnectionAttemptState::Closed;
}

void ConnectionAttemptManager::PurgeClosedLocked()
{
    const auto cutoff = std::chrono::steady_clock::now() - std::chrono::seconds(60);
    for (auto it = attempts_.begin(); it != attempts_.end();)
    {
        if (it->second.state == ConnectionAttemptState::Closed &&
            it->second.closedAt != std::chrono::steady_clock::time_point{} &&
            it->second.closedAt < cutoff)
            it = attempts_.erase(it);
        else
            ++it;
    }
}

bool ConnectionAttemptManager::CreateOutbound(const std::string& roundId,
                                              const std::string& attemptId,
                                              const std::string& groupKey,
                                              const Node& originalNode)
{
    if (!IsValidConnectionAttemptId(attemptId)) return false;
    std::lock_guard<std::mutex> lock(mutex_);
    PurgeClosedLocked();
    if (attempts_.count(attemptId) != 0) return false;
    if (!groupKey.empty())
    {
        auto group = groupToAttempt_.find(groupKey);
        if (group != groupToAttempt_.end())
        {
            auto existing = attempts_.find(group->second);
            if (existing != attempts_.end() && !IsTerminal(existing->second.state))
                return false;
        }
    }
    ConnectionAttempt attempt;
    attempt.roundId = roundId;
    attempt.attemptId = attemptId;
    attempt.groupKey = groupKey;
    attempt.originalNode = originalNode;
    attempts_.emplace(attemptId, attempt);
    if (!groupKey.empty()) groupToAttempt_[groupKey] = attemptId;
    return true;
}

bool ConnectionAttemptManager::CreateInbound(const std::string& attemptId, int fd)
{
    if (!IsValidConnectionAttemptId(attemptId) || fd <= 0) return false;
    std::lock_guard<std::mutex> lock(mutex_);
    PurgeClosedLocked();
    auto bound = fdToAttempt_.find(fd);
    if (bound != fdToAttempt_.end()) return false;
    auto [it, inserted] = attempts_.emplace(attemptId, ConnectionAttempt{});
    if (!inserted) return false;
    it->second.attemptId = attemptId;
    it->second.fd = fd;
    it->second.state = ConnectionAttemptState::KeyExchanging;
    fdToAttempt_[fd] = attemptId;
    return true;
}

bool ConnectionAttemptManager::Transition(const std::string& attemptId,
                                          ConnectionAttemptState expected,
                                          ConnectionAttemptState next)
{
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = attempts_.find(attemptId);
    if (it == attempts_.end() || it->second.state != expected) return false;
    it->second.state = next;
    return true;
}

bool ConnectionAttemptManager::SetConnectedFd(const std::string& attemptId, int fd)
{
    if (fd <= 0) return false;
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = attempts_.find(attemptId);
    if (it == attempts_.end() || it->second.state != ConnectionAttemptState::Connecting)
        return false;
    auto bound = fdToAttempt_.find(fd);
    if (bound != fdToAttempt_.end() && bound->second != attemptId) return false;
    it->second.fd = fd;
    it->second.state = ConnectionAttemptState::TcpConnected;
    fdToAttempt_[fd] = attemptId;
    return true;
}

bool ConnectionAttemptManager::MarkRegisterSent(const std::string& attemptId)
{
    return Transition(attemptId, ConnectionAttemptState::KeyEstablished,
                      ConnectionAttemptState::RegisterSent);
}

bool ConnectionAttemptManager::ValidateStateFd(const std::string& attemptId,
                                                ConnectionAttemptState state, int fd) const
{
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = attempts_.find(attemptId);
    return it != attempts_.end() && it->second.state == state && it->second.fd == fd;
}

bool ConnectionAttemptManager::ValidatePendingAck(const std::string& roundId,
                                                  const std::string& attemptId,
                                                  int fd) const
{
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = attempts_.find(attemptId);
    return it != attempts_.end() && it->second.roundId == roundId &&
           it->second.fd == fd && it->second.state == ConnectionAttemptState::RegisterSent;
}

bool ConnectionAttemptManager::MarkRegistered(const std::string& roundId,
                                              const std::string& attemptId,
                                              int fd)
{
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = attempts_.find(attemptId);
    if (it == attempts_.end() || it->second.fd != fd) return false;
    if (!roundId.empty())
    {
        if (!it->second.roundId.empty() && it->second.roundId != roundId) return false;
        it->second.roundId = roundId;
    }
    const bool outbound = it->second.state == ConnectionAttemptState::RegisterSent;
    const bool inbound = it->second.state == ConnectionAttemptState::KeyEstablished;
    if (!outbound && !inbound) return false;
    it->second.state = ConnectionAttemptState::Registered;
    return true;
}

void ConnectionAttemptManager::CleanupFd(int fd)
{
    if (fd <= 0) return;
    MagicSingleton<KeyExchangeManager>::GetInstance()->removeKey(fd);
    MagicSingleton<PeerNode>::GetInstance()->delete_by_fd(fd);
}

bool ConnectionAttemptManager::CloseAttempt(const std::string& attemptId,
                                            const std::string& reason)
{
    int fd = -1;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = attempts_.find(attemptId);
        if (it == attempts_.end() || IsTerminal(it->second.state) ||
            it->second.state == ConnectionAttemptState::Closing)
            return false;
        it->second.state = ConnectionAttemptState::Closing;
        it->second.closeReason = reason;
        fd = it->second.fd;
        if (fd > 0) fdToAttempt_.erase(fd);
    }
    CleanupFd(fd);
    {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = attempts_.find(attemptId);
        if (it != attempts_.end())
        {
            it->second.fd = -1;
            it->second.state = ConnectionAttemptState::Closed;
            it->second.closedAt = std::chrono::steady_clock::now();
            if (!it->second.groupKey.empty())
            {
                auto group = groupToAttempt_.find(it->second.groupKey);
                if (group != groupToAttempt_.end() && group->second == attemptId)
                    groupToAttempt_.erase(group);
            }
        }
    }
    INFOLOG("Connection attempt closed attempt_id:{} fd:{} reason:{}", attemptId, fd, reason);
    return true;
}

void ConnectionAttemptManager::ReleaseFd(int fd, const std::string& reason)
{
    if (fd <= 0) return;
    std::lock_guard<std::mutex> lock(mutex_);
    auto binding = fdToAttempt_.find(fd);
    if (binding == fdToAttempt_.end()) return;
    auto attempt = attempts_.find(binding->second);
    fdToAttempt_.erase(binding);
    if (attempt == attempts_.end()) return;
    attempt->second.fd = -1;
    attempt->second.closeReason = reason;
    attempt->second.state = ConnectionAttemptState::Closed;
    attempt->second.closedAt = std::chrono::steady_clock::now();
    if (!attempt->second.groupKey.empty())
    {
        auto group = groupToAttempt_.find(attempt->second.groupKey);
        if (group != groupToAttempt_.end() && group->second == attempt->first)
            groupToAttempt_.erase(group);
    }
}

void ConnectionAttemptManager::ClosePendingRound(const std::string& roundId,
                                                 const std::string& reason)
{
    std::vector<std::string> pending;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        for (const auto& [id, attempt] : attempts_)
        {
            if (attempt.roundId == roundId && !IsTerminal(attempt.state))
                pending.push_back(id);
        }
    }
    for (const auto& id : pending) CloseAttempt(id, reason);
}

bool ConnectionAttemptManager::HasActiveGroup(const std::string& groupKey) const
{
    std::lock_guard<std::mutex> lock(mutex_);
    auto group = groupToAttempt_.find(groupKey);
    if (group == groupToAttempt_.end()) return false;
    auto attempt = attempts_.find(group->second);
    return attempt != attempts_.end() && !IsTerminal(attempt->second.state);
}

bool ConnectionAttemptManager::Get(const std::string& attemptId,
                                   ConnectionAttempt& attempt) const
{
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = attempts_.find(attemptId);
    if (it == attempts_.end()) return false;
    attempt = it->second;
    return true;
}

std::string ConnectionAttemptStateName(ConnectionAttemptState state)
{
    switch (state)
    {
        case ConnectionAttemptState::Created: return "created";
        case ConnectionAttemptState::Connecting: return "connecting";
        case ConnectionAttemptState::TcpConnected: return "tcp_connected";
        case ConnectionAttemptState::KeyExchanging: return "key_exchanging";
        case ConnectionAttemptState::KeyEstablished: return "key_established";
        case ConnectionAttemptState::RegisterSent: return "register_sent";
        case ConnectionAttemptState::Registered: return "registered";
        case ConnectionAttemptState::Closing: return "closing";
        case ConnectionAttemptState::Closed: return "closed";
    }
    return "unknown";
}

std::string BootstrapEndpointGroupKey(const Node& node)
{
    std::vector<std::string> keys;
    for (const auto& endpoint : node.endpoints)
    {
        keys.push_back(NormalizeEndpointAddress(endpoint.addr) + ":" +
                       std::to_string(endpoint.port));
    }
    std::sort(keys.begin(), keys.end());
    std::ostringstream output;
    for (const auto& key : keys) output << key << ';';
    return output.str();
}
