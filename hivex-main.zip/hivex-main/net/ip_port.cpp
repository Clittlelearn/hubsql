#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <regex>
#include <netdb.h> 
#include <stdlib.h>
#include <unistd.h>
#include "../utils/util.h"
#include "./ip_port.h"
#include "./peer_node.h"
#include "./network_policy.h"
#include "../../include/logging.h"
#include "common/genesis.h"

#include "utils/magic_singleton.h"



//Ip /Get Local IP
bool IpPort::GetLocalHostIp(std::string & localHostIp)
{
	struct ifaddrs* ifAddrPtr = NULL;
	struct ifaddrs* addressPtrCopy = NULL;
	if(getifaddrs(&ifAddrPtr) != 0)
	{
		std::cout << "Please fill in the IP address in the configuration file" << std::endl;
		return false;
	}
	addressPtrCopy = ifAddrPtr;

	void* tmpAddrPtr = NULL;
	char localIpStr[IP_LEN] = {0};

	while (ifAddrPtr != NULL)
	{
		if (ifAddrPtr->ifa_addr != NULL && ifAddrPtr->ifa_addr->sa_family == AF_INET)
		{
			tmpAddrPtr = &((struct sockaddr_in*)ifAddrPtr->ifa_addr)->sin_addr;
			inet_ntop(AF_INET, tmpAddrPtr, localIpStr, IP_LEN);
			INFOLOG("Get local ip");
			INFOLOG("==========={}==============", localIpStr);
			
			u32 local_ip = IpPort::IpNum(localIpStr);
			if (htonl(INADDR_LOOPBACK) != local_ip 
				&& htonl(INADDR_BROADCAST) != local_ip 
				&& IpPort::IsLocalIp(local_ip)
				)
			{
				INFOLOG("==========={}==============", localIpStr);
				INFOLOG("Belong local IP");

				localHostIp = localIpStr;
				freeifaddrs(addressPtrCopy);
				return true;
			}
		}
		ifAddrPtr = ifAddrPtr->ifa_next;
	}
	freeifaddrs(addressPtrCopy);
	return false;
}

u32 IpPort::IpNum(const char* szIp)
{
	u32 numIp = inet_addr(szIp);
	return numIp;
}
u32 IpPort::IpNum(const std::string& szIp)
{
	u32 numIp = inet_addr(szIp.c_str());
	return numIp;
}

const char* IpPort::IpSz(const u32 numIp)
{
	struct in_addr addr = {0};
	memcpy(&addr, &numIp, sizeof(u32));
	const char* szIp = inet_ntoa(addr);
	return szIp;
}

bool IpPort::IsValidIp(std::string const& strIp)
{
	try
	{
		std::string pattern = "^(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])\\.(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\.(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\.(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)$";
		std::regex re(pattern);
		bool rst = std::regex_search(strIp, re);
		return rst;
	}
	catch (std::regex_error const& e)
	{
		DEBUGLOG("IsValidIp e{})", e.what());
	}
	return false;
}

bool IpPort::IsLocalIp(std::string const& strIp)
{
	if (false == IsValidIp(strIp))
		return false;

	try
	{
		std::string pattern{ "^(127\\.0\\.0\\.1)|(localhost)|(10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})|(172\\.((1[6-9])|(2\\d)|(3[01]))\\.\\d{1,3}\\.\\d{1,3})|(192\\.168\\.\\d{1,3}\\.\\d{1,3})$" };
		std::regex re(pattern);
		bool rst = std::regex_search(strIp, re);
		return rst;
	}
	catch (std::regex_error const& e)
	{
		DEBUGLOG("IsValidIp e({})", e.code());
	}
	return false;
}

bool IpPort::IsLocalIp(u32 u32_ip)
{
	std::string strIp = IpSz(u32_ip);
	return IsLocalIp(strIp);
}

bool IpPort::IsPublicIp(std::string const& strIp)
{
	if (false == IsValidIp(strIp))
		return false;

	return false == IsLocalIp(strIp);
}

bool IpPort::IsPublicIp(u32 u32_ip)
{
	std::string strIp = IpSz(u32_ip);
	return IsPublicIp(strIp);
}

bool IpPort::IsValidPort(u16 u16_port)
{
	return u16_port > 0 && u16_port <= 65535;
}

u32 IpPort::get_peer_nip_info(int sockConn)
{
	struct sockaddr_storage sa { 0 };
	socklen_t len = sizeof(sa);
	if (!getpeername(sockConn, (struct sockaddr*)&sa, &len))
	{
		if (sa.ss_family == AF_INET)
		{
			auto* ipv4 = (struct sockaddr_in*)&sa;
			return ipv4->sin_addr.s_addr;
		}
		if (sa.ss_family == AF_INET6)
		{
			auto* ipv6 = (struct sockaddr_in6*)&sa;
			if (IN6_IS_ADDR_V4MAPPED(&ipv6->sin6_addr))
			{
				u32 ip = 0;
				memcpy(&ip, &ipv6->sin6_addr.s6_addr[12], sizeof(ip));
				return ip;
			}
		}
	}
	else
	{
		DEBUGLOG("get_peer_nip_info getpeername fail.");
	}

	return 0;
}

u16 IpPort::GetPeerPort(int sockConn)
{
	struct sockaddr_storage sa { 0 };
	socklen_t len = sizeof(sa);
	if (!getpeername(sockConn, (struct sockaddr*)&sa, &len))
	{
		if (sa.ss_family == AF_INET)
		{
			auto* ipv4 = (struct sockaddr_in*)&sa;
			return ntohs(ipv4->sin_port);
		}
		if (sa.ss_family == AF_INET6)
		{
			auto* ipv6 = (struct sockaddr_in6*)&sa;
			return ntohs(ipv6->sin6_port);
		}
	}
	else
	{
		DEBUGLOG("GetPeerPort getpeername fail.");
	}

	return 0;
}

//Gets the local address on the connection represented by sockfd
u16 IpPort::GetConnectPort(int conFd)
{
	struct sockaddr_storage clientAddr { 0 };
    socklen_t clientAddrLen = sizeof(clientAddr);
	if(!getsockname(conFd, (struct sockaddr*)&clientAddr, &clientAddrLen))
	{
		if (clientAddr.ss_family == AF_INET)
		{
			auto* ipv4 = (struct sockaddr_in*)&clientAddr;
			return ntohs(ipv4->sin_port);
		}
		if (clientAddr.ss_family == AF_INET6)
		{
			auto* ipv6 = (struct sockaddr_in6*)&clientAddr;
			return ntohs(ipv6->sin6_port);
		}
	}
	else
	{
		DEBUGLOG("GetConnectPort getsockname fail.");
	} 
	return 0;
}

bool IpPort::IsLan(std::string const &ipString)
{
	const auto networkType = MagicSingleton<Genesis>::GetInstance()->GetNetworkType();
	const auto policy = GetNetworkConnectionPolicy(networkType);
	return policy.requirePublicAddress && !IsPublicNetworkAddress(ipString);
}

// === NET-016: IPv6 support methods ===

bool IpPort::IsValidIPv6(std::string const& strIp)
{
	struct in6_addr addr;
	return inet_pton(AF_INET6, strIp.c_str(), &addr) == 1;
}

bool IpPort::IsIPv6(std::string const& strIp)
{
	return IsValidIPv6(strIp);
}

bool IpPort::IsLocalIPv6(std::string const& strIp)
{
	if (!IsValidIPv6(strIp))
		return false;

	// Check for IPv6 private/local addresses
	// ::1 (loopback)
	if (strIp == "::1") return true;

	// fc00::/7 (unique local address)
	struct in6_addr addr;
	inet_pton(AF_INET6, strIp.c_str(), &addr);
	if (addr.s6_addr[0] == 0xfc || addr.s6_addr[0] == 0xfd) return true;

	// fe80::/10 (link-local)
	if (addr.s6_addr[0] == 0xfe && (addr.s6_addr[1] & 0xc0) == 0x80) return true;

	return false;
}

bool IpPort::IsPublicIPv6(std::string const& strIp)
{
	if (!IsValidIPv6(strIp))
		return false;
	return !IsLocalIPv6(strIp);
}

std::string IpPort::get_peer_addr_str(int sockConn)
{
	struct sockaddr_storage sa;
	socklen_t len = sizeof(sa);
	if (!getpeername(sockConn, (struct sockaddr*) & sa, &len))
	{
		if (sa.ss_family == AF_INET)
		{
			struct sockaddr_in* ipv4 = (struct sockaddr_in*)&sa;
			char buf[INET_ADDRSTRLEN];
			inet_ntop(AF_INET, &ipv4->sin_addr, buf, sizeof(buf));
			return std::string(buf);
		}
		else if (sa.ss_family == AF_INET6)
		{
			struct sockaddr_in6* ipv6 = (struct sockaddr_in6*)&sa;
			if (IN6_IS_ADDR_V4MAPPED(&ipv6->sin6_addr))
			{
				struct in_addr mapped4;
				memcpy(&mapped4.s_addr, &ipv6->sin6_addr.s6_addr[12], sizeof(mapped4.s_addr));
				char buf[INET_ADDRSTRLEN];
				inet_ntop(AF_INET, &mapped4, buf, sizeof(buf));
				return std::string(buf);
			}
			char buf[INET6_ADDRSTRLEN];
			inet_ntop(AF_INET6, &ipv6->sin6_addr, buf, sizeof(buf));
			return std::string(buf);
		}
	}
	else
	{
		DEBUGLOG("get_peer_addr_str getpeername fail.");
	}
	return "";
}

bool IpPort::IsLanAddr(std::string const& ipString)
{
	return IsLan(ipString);
}
