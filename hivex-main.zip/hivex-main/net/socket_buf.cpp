#include "socket_buf.h"

#include "../net/global.h"
#include "../utils/util.h"
#include "../utils/console.h"
#include "logging.h"

std::unordered_map<int, std::shared_ptr<std::mutex>> fileDescriptorSetMutex;
std::mutex mu;
std::shared_ptr<std::mutex> fdMutex(int fd)
{
	std::lock_guard<std::mutex> lck(mu);
    auto search = fileDescriptorSetMutex.find(fd);
    if (search != fileDescriptorSetMutex.end())
    {
        return search->second;
    }
    else
    {
        auto fd_mutex = std::make_shared<std::mutex>();
        fileDescriptorSetMutex.emplace(fd, fd_mutex);
        return fd_mutex;
    }
}

// Removing the map entry must not destroy a mutex still held by a write thread.
// fdMutex returns shared_ptr so in-flight users keep the mutex alive.
void removeFdMutex(int fd)
{
    std::lock_guard<std::mutex> lck(mu);
    fileDescriptorSetMutex.erase(fd);
}

int mutex_size()
{
    std::lock_guard<std::mutex> lck(mu);
    return fileDescriptorSetMutex.size();
}



std::string g_emptystr;

void SocketBuf::VerifyCache(size_t current_message_length)
{
    if (current_message_length > 100*1000*1000)
    {
        SocketBuf::CorrectCache();
    }
}

void SocketBuf::CorrectCache()
{  
    if(this->_cache.size() < sizeof(uint32_t))
    {
        this->_cache.clear();
        return;
    }
    const char * ptr = this->_cache.data();
    bool find = false;
    size_t i;
    for(i = 0 ; i <= this->_cache.size() - sizeof(uint32_t); i++)
    {
        int32_t tmpFlag = *((uint32_t*)(ptr + i));
        if(tmpFlag == END_FLAG)
        {
            find = true;
            break;
        }
    }
    if(find)
    {
        this->_cache.erase(0, i+4);
    }
    else
    {
        this->_cache.clear();
    }
}

bool SocketBuf::add_data_to_read_buffer(char *data, size_t len)
{
	std::lock_guard<std::mutex> lck(mutexForRead);
    if (data == NULL || len == 0)
    {
        ERRORLOG("add_data_to_read_buffer error: data == NULL or len == 0");
        return false;
    }

    std::string tmp(data, len);
    this->_cache += tmp;
	size_t current_message_length = 0;
    if (this->_cache.size() >= 4)
    {
        memcpy(&current_message_length, this->_cache.data(), 4);  //The total length of the current message
        
        SocketBuf::VerifyCache(current_message_length);

        while (this->_cache.size() >= (size_t)(4 + current_message_length))
        {
            this->_cache.erase(0, 4);  //this leak! 
            std::string readData = this->_cache.substr(0, current_message_length);

            if (readData.size() < sizeof(uint32_t) * 3)
            {
                SocketBuf::CorrectCache();
                return false;
            }
            uint32_t checkSum = Util::adler32((unsigned char *)readData.data(), readData.size() - sizeof(uint32_t) * 3);
            uint32_t packCheckSum = *((uint32_t *)(this->_cache.data() + readData.size() - sizeof(uint32_t) * 3));
            
            if(checkSum != packCheckSum)
            {
                CorrectCache();
                return false;    
            }
            this->_cache.erase(0, current_message_length);

            this->sendPacketToMessageQueue(readData);

            if (this->_cache.size() < 4)
                break;
            memcpy(&current_message_length, this->_cache.data(), 4);
            SocketBuf::VerifyCache(current_message_length);
        }
        
        if(this->_cache.capacity() > this->_cache.size() * 20)
        {
            this->_cache.shrink_to_fit();
        }
    }
    return true;
}

bool SocketBuf::sendPacketToMessageQueue(const std::string& data)
{
    MsgData sendData;
    
    std::pair<uint16_t, uint32_t> portAndIpInfoItem = net_data::convertDataPackPortAndIpToInt(this->portAndIp);
    sendData.type = E_WORK;
    sendData.fd = this->fd;
    if (!this->addr.empty())
    {
        sendData.addr = this->addr;
        sendData.ip = 0;
        sendData.port = this->port;
    }
    else
    {
        sendData.ip = portAndIpInfoItem.second;
        sendData.port = portAndIpInfoItem.first;
    }
    sendData.data = data;
    Pack::apartPackData(sendData.pack, data.data(), data.size());
    return global::queue_work.Push(sendData);
}

void SocketBuf::printfCache()
{
	std::lock_guard<std::mutex> lck(mutexForRead);

    DEBUGLOG("fd: {}", this->fd);
    DEBUGLOG("portAndIp: {}", this->portAndIp);
    DEBUGLOG("_transactionCache: {}", this->_cache.c_str());
    DEBUGLOG("sendCache： {}", this->_sendCache.c_str());
}

std::string SocketBuf::GetSendMsg()
{
    std::lock_guard<std::mutex> lck(sendMutex);
    return this->_sendCache;
}

bool SocketBuf::isSendCacheEmpty()
{
    std::lock_guard<std::mutex> lck(sendMutex);
    return this->_sendCache.size() == 0;
}

bool SocketBuf::PushSendMsg(const std::string& data)
{
	std::lock_guard<std::mutex> lck(sendMutex);
	
	// NET-008: Check send buffer hard limit
	if (_sendCache.size() + data.size() > kMaxSendBufferSize)
	{
		ERRORLOG("Send buffer exceeds hard limit: {} + {} > {}", 
		         _sendCache.size(), data.size(), kMaxSendBufferSize);
		return false;
	}
	
	// NET-010: Check soft limit for backpressure
	if (_sendCache.size() + data.size() > kSendBufferSoftLimit)
	{
		_backpressureActive = true;
		DEBUGLOG("Send buffer exceeds soft limit: {} bytes, backpressure active", 
		         _sendCache.size() + data.size());
	}
	
    this->_sendCache += data;
    return true;
}

void SocketBuf::popAndSendMessageRequest(int n)
{
	std::lock_guard<std::mutex> lck(sendMutex);
    if((int)_sendCache.size() >= n)
    {
        this->_sendCache.erase(0 ,n);
    }
    else
    {
        this->_sendCache.erase(0 ,_sendCache.size());
    }
    
    // NET-010: Update write success time and clear backpressure
    _lastWriteSuccess = std::chrono::steady_clock::now();
    if (_sendCache.size() < kSendBufferSoftLimit) {
        _backpressureActive = false;
    }
}

std::string bufferControl::writeBufferQueue(uint64_t portAndIp)
{
    auto itr = this->_BufferMap.find(portAndIp);
    if(itr == this->_BufferMap.end())
    {
        return g_emptystr;
    }
    return itr->second->GetSendMsg();
}

bool bufferControl::addReadBufferToQueue(uint64_t portAndIp, char *buf, socklen_t len)
{
    auto port_ip = net_data::convertDataPackPortAndIpToString(portAndIp);
    if (buf == NULL || len == 0)
    {
        ERRORLOG("addReadBufferToQueue error buf == NULL or len == 0");
        return false;
    }

    std::map<uint64_t,std::shared_ptr<SocketBuf>>::iterator itr;
    {
        std::lock_guard<std::mutex> lck(_mutex);

        itr = this->_BufferMap.find(portAndIp);
        if (itr == this->_BufferMap.end())
        {
            DEBUGLOG("no key portAndIp is {}", portAndIp);
            return false;
        }
    }
	
    return itr->second->add_data_to_read_buffer(buf, len);
}

bool bufferControl::addReadBufferToQueue(uint32_t ip, uint16_t port, char *buf, socklen_t len)
{
    uint64_t portAndIp = net_data::dataPackPortAndIp(port, ip);
    return this->addReadBufferToQueue(portAndIp, buf, len);
}

bool bufferControl::AddBuffer(uint64_t portAndIp, const int fd)
{

    if (portAndIp == 0 || fd <= 0)
    {
        return false;
    }

	std::lock_guard<std::mutex> lck(_mutex);

    auto itr = this->_BufferMap.find(portAndIp);
    if (itr != this->_BufferMap.end())
    {
        return false;
    }
    std::shared_ptr<SocketBuf> tmp(new SocketBuf());
    tmp->fd = fd;
    tmp->portAndIp = portAndIp;
    this->_BufferMap[portAndIp] = tmp;

    return true;
}

bool bufferControl::AddBuffer(uint32_t ip, uint16_t port, const int fd)
{
    uint64_t portAndIp = net_data::dataPackPortAndIp(port, ip);
    return this->AddBuffer(portAndIp, fd);
}

void bufferControl::printBuffers()
{
	std::lock_guard<std::mutex> lck(_mutex);
    DEBUGLOG("************************** printBuffers b **************************");
    for(auto i : this->_BufferMap)
    { 
        i.second->printfCache();
    }
    DEBUGLOG("************************** printBuffers e **************************");
}

bool bufferControl::DeleteBuffer(uint32_t ip, uint16_t port)
{
    DEBUGLOG("DeleteBuffer ip:({}),port:({})",IpPort::IpSz(ip),port);
    uint64_t portAndIp = net_data::dataPackPortAndIp(port, ip);
    return this->DeleteBuffer(portAndIp);
}
bool bufferControl::DeleteBuffer(uint64_t portAndIp)
{
    if (portAndIp == 0)
    {
        return false;
    }

	std::lock_guard<std::mutex> lck(_mutex);

    auto itr = this->_BufferMap.find(portAndIp);
    if(itr != this->_BufferMap.end())
    {
        this->_BufferMap.erase(portAndIp);
        return true;
    }
    return false;
}

bool bufferControl::DeleteBuffer(const int fd)
{
    if (fd <= 0)
    {
        return false;
    }

    std::lock_guard<std::mutex> lck(_mutex);

    auto addrIter = std::find_if(_BufferMapByAddr.begin(), _BufferMapByAddr.end(), [fd](auto & i){
        return i.second->fd == fd;
    });
    if (addrIter != _BufferMapByAddr.end())
    {
        _BufferMapByAddr.erase(addrIter);
        return true;
    }

    auto iter = std::find_if(_BufferMap.begin(), _BufferMap.end(), [fd](auto & i){
        return i.second->fd == fd;
    });

    if (iter == _BufferMap.end())
    {
        return false;
    }
    
    std::pair<uint16_t, uint32_t> pair = net_data::convertDataPackPortAndIpToInt(iter->second->portAndIp);
    _BufferMap.erase(iter);
    return true;
}

void bufferControl::PopAndWriteBufferQueue(uint64_t portAndIp, int n)
{
    if (portAndIp == 0)
    {
        ERRORLOG("PopAndWriteBufferQueue error portAndIp == 0 portAndIp: {}", portAndIp);
    }

	std::lock_guard<std::mutex> lck(_mutex);

    auto itr = this->_BufferMap.find(portAndIp);
    if(itr != this->_BufferMap.end())
    {
        itr->second->popAndSendMessageRequest(n);
        return ;
    }
    DEBUGLOG(" portAndIp is not exist in map, portAndIp: {}", portAndIp);    
}

bool bufferControl::IsExists(uint64_t portAndIp)
{
	std::lock_guard<std::mutex> lck(_mutex);

	auto itr = this->_BufferMap.find(portAndIp);
	if (itr == this->_BufferMap.end())
	{
		DEBUGLOG(RED "no key portAndIp is {}" RESET , portAndIp);
		return false;
	}
	return true;
}


bool bufferControl::IsExists(uint32_t ip, uint16_t port)
{
	uint64_t portAndIp = net_data::dataPackPortAndIp(port, ip);
	return IsExists(portAndIp);
}

std::shared_ptr<SocketBuf> bufferControl::GetSocketBuf(uint32_t ip, uint16_t port)
{
    std::lock_guard<std::mutex> lck(_mutex);

    uint64_t portAndIp = net_data::dataPackPortAndIp(port, ip);
    auto iter = _BufferMap.find(portAndIp);
    if (iter == _BufferMap.end())
    {
        return std::shared_ptr<SocketBuf>();
    }
    
    return iter->second;
}

bool bufferControl::addWritePack_(uint64_t portAndIp, const std::string iosMsg)
{
	if (iosMsg.size() == 0)
	{
		ERRORLOG("add_write_buffer_queue error msg.size == 0");
		return false;
	}

	std::lock_guard<std::mutex> lck(_mutex);

	auto itr = this->_BufferMap.find(portAndIp);
	if (itr == this->_BufferMap.end())
	{
		DEBUGLOG("no key portAndIp is {}", portAndIp);
		return false;
	}
	
	// NET-008: Handle send buffer limit
	if (!itr->second->PushSendMsg(iosMsg))
	{
		ERRORLOG("Send buffer full for portAndIp {}", portAndIp);
		return false;
	}
	
	return true;
}

bool bufferControl::addWritePack_(uint32_t ip, uint16_t port, const std::string iosMsg)
{
	uint64_t portAndIp = net_data::dataPackPortAndIp(port, ip);
	return addWritePack_(portAndIp, iosMsg);
}


bool bufferControl::IsCacheEmpty(uint32_t ip, uint16_t port)
{
    uint64_t portAndIp = net_data::dataPackPortAndIp(port, ip);
    auto itr = this->_BufferMap.find(portAndIp);
    if(itr == this->_BufferMap.end())
    {
        return true;
    }
    return itr->second->isSendCacheEmpty();
}

// === NET-016: New IPv4/IPv6 dual-stack interface implementations ===

bool bufferControl::addReadBufferToQueue(const std::string& addr, uint16_t port, char *buf, socklen_t len)
{
    std::string addrKey = makeAddrKey(addr, port);
    if (buf == NULL || len == 0)
    {
        ERRORLOG("addReadBufferToQueue error buf == NULL or len == 0");
        return false;
    }

    std::lock_guard<std::mutex> lck(_mutex);
    auto itr = this->_BufferMapByAddr.find(addrKey);
    if (itr == this->_BufferMapByAddr.end())
    {
        DEBUGLOG("no key addrKey is {}", addrKey);
        return false;
    }

    return itr->second->add_data_to_read_buffer(buf, len);
}

bool bufferControl::AddBuffer(const std::string& addr, uint16_t port, const int fd)
{
    std::string addrKey = makeAddrKey(addr, port);
    if (addrKey.empty() || fd <= 0)
    {
        return false;
    }

    std::lock_guard<std::mutex> lck(_mutex);
    auto itr = this->_BufferMapByAddr.find(addrKey);
    if (itr != this->_BufferMapByAddr.end())
    {
        return false;
    }

    std::shared_ptr<SocketBuf> tmp(new SocketBuf());
    tmp->fd = fd;
    tmp->portAndIp = 0;  // Not used for string-keyed entries
    tmp->addr = addr;
    tmp->port = port;
    this->_BufferMapByAddr[addrKey] = tmp;

    return true;
}

bool bufferControl::DeleteBuffer(const std::string& addr, uint16_t port)
{
    std::string addrKey = makeAddrKey(addr, port);
    DEBUGLOG("DeleteBuffer addrKey:{}", addrKey);

    std::lock_guard<std::mutex> lck(_mutex);
    auto itr = this->_BufferMapByAddr.find(addrKey);
    if (itr != this->_BufferMapByAddr.end())
    {
        this->_BufferMapByAddr.erase(itr);
        return true;
    }
    return false;
}

std::string bufferControl::writeBufferQueue(const std::string& addr, uint16_t port)
{
    std::string addrKey = makeAddrKey(addr, port);
    std::lock_guard<std::mutex> lck(_mutex);
    auto itr = this->_BufferMapByAddr.find(addrKey);
    if (itr == this->_BufferMapByAddr.end())
    {
        return g_emptystr;
    }
    return itr->second->GetSendMsg();
}

void bufferControl::PopAndWriteBufferQueue(const std::string& addr, uint16_t port, int n)
{
    std::string addrKey = makeAddrKey(addr, port);
    if (addrKey.empty())
    {
        ERRORLOG("PopAndWriteBufferQueue error addrKey is empty");
        return;
    }

    std::lock_guard<std::mutex> lck(_mutex);
    auto itr = this->_BufferMapByAddr.find(addrKey);
    if (itr != this->_BufferMapByAddr.end())
    {
        itr->second->popAndSendMessageRequest(n);
        return;
    }
    DEBUGLOG("addrKey is not exist in map, addrKey: {}", addrKey);
}

bool bufferControl::addWritePack_(const std::string& addr, uint16_t port, const std::string iosMsg)
{
    std::string addrKey = makeAddrKey(addr, port);
    if (iosMsg.size() == 0)
    {
        ERRORLOG("add_write_buffer_queue error msg.size == 0");
        return false;
    }

    std::lock_guard<std::mutex> lck(_mutex);
    auto itr = this->_BufferMapByAddr.find(addrKey);
    if (itr == this->_BufferMapByAddr.end())
    {
        DEBUGLOG("no key addrKey is {}", addrKey);
        return false;
    }

    // NET-008: Handle send buffer limit
    if (!itr->second->PushSendMsg(iosMsg))
    {
        ERRORLOG("Send buffer full for addrKey {}", addrKey);
        return false;
    }

    return true;
}

bool bufferControl::IsExists(const std::string& addr, uint16_t port)
{
    std::string addrKey = makeAddrKey(addr, port);
    std::lock_guard<std::mutex> lck(_mutex);
    auto itr = this->_BufferMapByAddr.find(addrKey);
    if (itr == this->_BufferMapByAddr.end())
    {
        return false;
    }
    return true;
}

std::shared_ptr<SocketBuf> bufferControl::GetSocketBuf(const std::string& addr, uint16_t port)
{
    std::string addrKey = makeAddrKey(addr, port);
    std::lock_guard<std::mutex> lck(_mutex);
    auto iter = _BufferMapByAddr.find(addrKey);
    if (iter == _BufferMapByAddr.end())
    {
        return std::shared_ptr<SocketBuf>();
    }
    return iter->second;
}

bool bufferControl::IsCacheEmpty(const std::string& addr, uint16_t port)
{
    std::string addrKey = makeAddrKey(addr, port);
    std::lock_guard<std::mutex> lck(_mutex);
    auto itr = this->_BufferMapByAddr.find(addrKey);
    if (itr == this->_BufferMapByAddr.end())
    {
        return true;
    }
    return itr->second->isSendCacheEmpty();
}

std::shared_ptr<SocketBuf> bufferControl::GetSocketBufByFd(int fd)
{
    if (fd <= 0) return nullptr;

    std::lock_guard<std::mutex> lck(_mutex);

    // Search in new map
    for (auto& pair : _BufferMapByAddr)
    {
        if (pair.second->fd == fd)
        {
            return pair.second;
        }
    }

    // Search in legacy map
    for (auto& pair : _BufferMap)
    {
        if (pair.second->fd == fd)
        {
            return pair.second;
        }
    }

    return nullptr;
}
