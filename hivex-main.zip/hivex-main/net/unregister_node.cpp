﻿#include "unregister_node.h"
#include <chrono>

#include "./handle_event.h"
#include "./api.h"
#include "./network_policy.h"
#include "./connection_attempt.h"

#include "../utils/time_util.h"
#include "../net/peer_node.h"
#include "../utils/magic_singleton.h"
#include "../common/global_data.h"
#include "../common/config.h"
#include "../pb/net.pb.h"
#include "../utils/account_manager.h"
#include "../utils/sha256.h"

// NET-017: Use CA interface instead of direct dependency
#include "ca_interface.h"

// Still need global constants from CA layer
#include "../ca/global.h"

UnregisterNode::UnregisterNode()
{
}
UnregisterNode::~UnregisterNode()
{
}

namespace
{
std::string nodeKey(const Node &node)
{
    if (!node.address.empty())
    {
        return node.address;
    }
    return node.getPublicAddrStr() + ":" + std::to_string(node.listenPort);
}

bool isLocalEndpoint(const NodeEndpoint &endpoint, const Node &selfNode)
{
    if (!endpoint.isValid())
    {
        return true;
    }
    if (ClassifyNetworkAddress(endpoint.addr) == NetworkAddressScope::Unspecified)
    {
        return true;
    }

    const auto matches = [&endpoint](const std::string& address, uint32_t port)
    {
        return port != 0 && endpoint.port == port &&
               EndpointAddressesEquivalent(endpoint.addr, address);
    };

    for (const auto& selfEndpoint : selfNode.endpoints)
    {
        if (matches(selfEndpoint.addr, selfEndpoint.port))
        {
            return true;
        }
    }

    if (matches(selfNode.getListenAddrStr(), selfNode.listenPort) ||
        matches(selfNode.getPublicAddrStr(), selfNode.publicPort) ||
        matches(global::g_localIp, selfNode.listenPort))
    {
        return true;
    }

    for (const auto& configured : MagicSingleton<Config>::GetInstance()->GetEndpoints())
    {
        const uint32_t port = configured.port != 0 ? configured.port : selfNode.listenPort;
        if (matches(configured.addr, port))
        {
            return true;
        }
    }

    return false;
}

Node buildBootstrapNode(const std::vector<NodeEndpoint> &group, const Node &selfNode)
{
    Node node;
    node.setListenAddr(selfNode.getListenAddrStr());
    node.listenPort = kServerMainPort;
    for (const auto &endpoint : group)
    {
        if (isLocalEndpoint(endpoint, selfNode))
        {
            DEBUGLOG("Skip self endpoint during bootstrap: {}:{}", endpoint.addr, endpoint.port);
            continue;
        }
        node.addEndpoint(endpoint.addr, endpoint.port, endpoint.family, endpoint.priority);
    }
    return node;
}

Node nodeFromInfo(const NodeInfo &nodeinfo, const Node &selfNode)
{
    Node node;
    node.listenIp = selfNode.listenIp;
    node.setListenAddr(selfNode.getListenAddrStr());
    node.listenPort = kServerMainPort;
    node.publicIp = nodeinfo.public_ip();

    std::string publicAddr = !nodeinfo.node_public_addr().empty() ? nodeinfo.node_public_addr() : nodeinfo.public_addr();
    if (publicAddr.empty() && node.publicIp != 0)
    {
        publicAddr = IpPort::IpSz(node.publicIp);
    }
    if (!publicAddr.empty())
    {
        node.setPublicAddr(publicAddr);
    }

    node.publicPort = nodeinfo.public_port();
    for (int i = 0; i < nodeinfo.endpoints_size(); ++i)
    {
        const auto& endpoint = nodeinfo.endpoints(i);
        node.addEndpoint(endpoint.addr(), static_cast<uint16_t>(endpoint.port()), static_cast<IpVersion>(endpoint.family()), endpoint.priority());
    }
    uint32_t advertisedPort = nodeinfo.public_port() != 0 ? nodeinfo.public_port() : nodeinfo.listen_port();
    if (node.endpoints.empty() && !publicAddr.empty() && advertisedPort != 0)
    {
        node.addEndpoint(publicAddr, static_cast<uint16_t>(advertisedPort), IpPort::IsIPv6(publicAddr) ? IpVersion::IPv6 : IpVersion::IPv4, 0);
    }
    if (!node.endpoints.empty())
    {
        node.setPublicAddr(node.endpoints.front().addr);
        node.listenPort = node.endpoints.front().port;
    }
    node.address = nodeinfo.addr();
    node.identity = nodeinfo.identity();
    node.height = nodeinfo.height();
    node.ver = nodeinfo.version();
    if (nodeinfo.ip_version() != 0)
    {
        node.ipVersion = static_cast<IpVersion>(nodeinfo.ip_version());
    }
    return node;
}
}

int UnregisterNode::Add(const Node & node)
{
    std::unique_lock<std::shared_mutex> lck(mutexForNodes);
    std::string key = std::to_string(node.publicIp) + std::to_string(node.publicPort);

    if(key.size() == 0)
	{
		return -1;
	} 
	auto itr = _nodes.find(key);
	if (itr != _nodes.end())
	{
		return -2;
	}
	this->_nodes[key] = node;


    return 0;
}

bool UnregisterNode::Register(std::map<std::string, Node> nodeMap)
{
    std::string msgId;
    uint32 sendNum = nodeMap.size();
    if (!dataMgrPtr.CreateWait(5, sendNum, msgId))
    {
        return false;
    }

    std::vector<Node> nodelist = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    uint32_t sentCount = 0;
    
    for (auto & unconnectedNode : nodeMap)
    {
        bool isFind = false;
        for (auto & node : nodelist)
        {
            if ((!unconnectedNode.second.address.empty() && unconnectedNode.second.address == node.address) ||
                unconnectedNode.second.getPublicAddrStr() == node.getPublicAddrStr())
            {
                isFind = true;
                break;
            }
            // Endpoint-level dedup: match by any shared endpoint addr+port
            for (const auto& ep : unconnectedNode.second.endpoints) {
                for (const auto& existingEp : node.endpoints) {
                    if (ep.addr == existingEp.addr && ep.port == existingEp.port) {
                        isFind = true;
                        break;
                    }
                }
                if (isFind) break;
            }
        }
        
        if (isFind)
        {
            continue;
        }

        int ret = net_com::registerNodeRequest(unconnectedNode.second, msgId, false, GenerateConnectionAttemptId());
        if(ret != 0)
        {
            ERRORLOG("registerNodeRequest fail ret = {}", ret);
            continue;
        }
        ++sentCount;
    }

    if (!dataMgrPtr.SetExpectedResponses(msgId, sentCount))
    {
        MagicSingleton<ConnectionAttemptManager>::GetInstance()->ClosePendingRound(
            msgId, "invalid_registration_wait_count");
        dataMgrPtr.CancelWait(msgId);
        return false;
    }
    if (sentCount == 0)
    {
        std::vector<std::string> ignored;
        dataMgrPtr.WaitData(msgId, ignored);
        return true;
    }
    std::vector<std::string> returnDatas;
    const bool receivedAll = dataMgrPtr.WaitData(msgId, returnDatas);
    if (!receivedAll) INFOLOG("wait Register incomplete send:{} recv:{}", sentCount, returnDatas.size());

    RegisterNodeAck registerNodeAcknowledgment;
    for (auto &retData : returnDatas)
    {
        registerNodeAcknowledgment.Clear();
        if (!registerNodeAcknowledgment.ParseFromString(retData))
        {
            continue;
        }
        uint32_t ip = registerNodeAcknowledgment.from_ip();
        std::string fromAddr = registerNodeAcknowledgment.from_addr();
        uint32_t port = registerNodeAcknowledgment.from_port();

        DEBUGLOG("UnregisterNode::Register ip:{}, port:{}", ip, port);
        std::cout << "registerNodeAcknowledgment.nodes_size(): " << registerNodeAcknowledgment.nodes_size() <<std::endl;
        if(registerNodeAcknowledgment.nodes_size() == 1)
	    {
            const NodeInfo &nodeinfo = registerNodeAcknowledgment.nodes(0);
            uint32_t ackFd = registerNodeAcknowledgment.fd();
			bool bufferExists = false;
			if (ackFd > 0)
			{
			    bufferExists = MagicSingleton<bufferControl>::GetInstance()->GetSocketBufByFd(ackFd) != nullptr;
			}
			if (!bufferExists)
			{
			    bufferExists = ip != 0
			        ? MagicSingleton<bufferControl>::GetInstance()->IsExists(ip, port)
			        : MagicSingleton<bufferControl>::GetInstance()->IsExists(fromAddr, port);
			}
			if (bufferExists /* && node.is_established()*/)
			{
                DEBUGLOG("handleRegisterNodeAcknowledgment--FALSE from.ip: {}", ip != 0 ? IpPort::IpSz(ip) : fromAddr);
                auto ret = RegistrationVerifier(nodeinfo, ip, port, fromAddr, ackFd,
                                                registerNodeAcknowledgment.msg_id(),
                                                registerNodeAcknowledgment.attempt_id());
                if(ret < 0)
                {
                    DEBUGLOG("RegistrationVerifier error ,ip : {}, port: {}, ret:{}", ip, port, ret);
                }
			}
        }
    }

    MagicSingleton<ConnectionAttemptManager>::GetInstance()->ClosePendingRound(
        msgId, receivedAll ? "registration_verification_failed" : "registration_timeout");
    return true;
}
bool UnregisterNode::startRegistrationNode(std::map<std::string, int> &serverList)
{
    std::unique_lock<std::mutex> bootstrapLock(bootstrapRoundMutex, std::try_to_lock);
    if (!bootstrapLock.owns_lock())
    {
        DEBUGLOG("Skip legacy bootstrap: another round is active");
        return false;
    }
    std::string msgId;
    uint32 sendNum = serverList.size();
    if (!dataMgrPtr.CreateWait(5, sendNum, msgId))
    {
        return false;
    }
    Node selfNode = MagicSingleton<PeerNode>::GetInstance()->GetSelfNode();
    uint32_t sentCount = 0;
    for (auto & item : serverList)
	{
        //The party actively establishing the connection
		Node node;
		node.setPublicAddr(item.first);
		node.setListenAddr(selfNode.getListenAddrStr());
		node.listenPort = kServerMainPort;

		if (item.first == global::g_localIp)
		{
			continue;
		}

		int ret = net_com::registerNodeRequest(node, msgId, true, GenerateConnectionAttemptId());
        if(ret != 0)
        {
            INFOLOG("startRegistrationNode error ret : {}", ret);
        }
        else
        {
            ++sentCount;
        }
	}

    if (!dataMgrPtr.SetExpectedResponses(msgId, sentCount))
    {
        MagicSingleton<ConnectionAttemptManager>::GetInstance()->ClosePendingRound(
            msgId, "invalid_registration_wait_count");
        dataMgrPtr.CancelWait(msgId);
        return false;
    }
    if (sentCount == 0)
    {
        std::vector<std::string> ignored;
        dataMgrPtr.WaitData(msgId, ignored);
        return false;
    }
    std::vector<std::string> returnDatas;
    const bool receivedAll = dataMgrPtr.WaitData(msgId, returnDatas);
    if (!receivedAll)
    {
        INFOLOG("legacy bootstrap wait incomplete sent:{} recv:{}", sentCount, returnDatas.size());
    }
    bool registeredBootstrap = false;
    RegisterNodeAck registerNodeAcknowledgment;
    std::map<std::string, Node> nodeMap;


    for (auto &retData : returnDatas)
    {
        registerNodeAcknowledgment.Clear();
        if (!registerNodeAcknowledgment.ParseFromString(retData))
        {
            continue;
        }

        uint32_t ip = registerNodeAcknowledgment.from_ip();
        std::string fromAddr = registerNodeAcknowledgment.from_addr();
        uint32_t port = registerNodeAcknowledgment.from_port();
        uint32_t fd = registerNodeAcknowledgment.fd();
        for (int i = 0; i < registerNodeAcknowledgment.nodes_size(); i++)
	    {
            const NodeInfo &nodeinfo = registerNodeAcknowledgment.nodes(i);
            if(nodeinfo.addr() == selfNode.address)
            {
                continue;
            }
            if(i == 0)
            {
                //Determine if TCP is connected
                bool bufferExists = false;
                if (fd > 0)
                {
                    bufferExists = MagicSingleton<bufferControl>::GetInstance()->GetSocketBufByFd(fd) != nullptr;
                }
                if (!bufferExists)
                {
                    bufferExists = ip != 0
                        ? MagicSingleton<bufferControl>::GetInstance()->IsExists(ip, port)
                        : MagicSingleton<bufferControl>::GetInstance()->IsExists(fromAddr, port);
                }
                if (bufferExists)
                {
                    DEBUGLOG("handleRegisterNodeAcknowledgment--TRUE from.ip: {}", ip != 0 ? IpPort::IpSz(ip) : fromAddr);
                    auto ret = RegistrationVerifier(nodeinfo, ip, port, fromAddr, fd,
                                                    registerNodeAcknowledgment.msg_id(),
                                                    registerNodeAcknowledgment.attempt_id());
                    if(ret == 0) registeredBootstrap = true;
                    if(ret < 0)
                    {
                        DEBUGLOG("RegistrationVerifier error ip:{}, port:{}, ret:{}", ip != 0 ? IpPort::IpSz(ip) : fromAddr, port, ret);
                        continue;
                    }
                }
            }
            else
            {
                Node node = nodeFromInfo(nodeinfo, selfNode);
                std::string key = nodeKey(node);
                DEBUGLOG("Add NodeList--TRUE ip: {}", node.getPublicAddrStr());
                if(!key.empty() && nodeMap.find(key) == nodeMap.end())
                {
                    DEBUGLOG("add peer:{}, port:{}", node.getPublicAddrStr(), node.listenPort);
                    nodeMap[key] = node;
                }
            } 
        }
    }
    MagicSingleton<ConnectionAttemptManager>::GetInstance()->ClosePendingRound(
        msgId, receivedAll ? "registration_verification_failed" : "registration_timeout");
    Register(nodeMap);
    return registeredBootstrap;
}

bool UnregisterNode::startRegistrationNode(std::vector<std::vector<NodeEndpoint>> &serverEndpointGroups)
{
    std::unique_lock<std::mutex> bootstrapLock(bootstrapRoundMutex, std::try_to_lock);
    if (!bootstrapLock.owns_lock())
    {
        DEBUGLOG("Skip endpoint bootstrap: another round is active groups:{}", serverEndpointGroups.size());
        return false;
    }
    const auto startedAt = std::chrono::steady_clock::now();
    const size_t configuredGroupCount = serverEndpointGroups.size();
    Node selfNode = MagicSingleton<PeerNode>::GetInstance()->GetSelfNode();
    std::vector<Node> bootstrapNodes;
    for (auto &group : serverEndpointGroups)
    {
        if (group.empty()) continue;
        Node node = buildBootstrapNode(group, selfNode);
        if (!node.endpoints.empty()) bootstrapNodes.push_back(node);
    }

    if (bootstrapNodes.empty())
    {
        DEBUGLOG("startRegistrationNode skipped: no remote bootstrap endpoints after self-filter");
        return true;
    }

    std::string msgId;
    if (!dataMgrPtr.CreateWait(5, bootstrapNodes.size(), msgId)) return false;
    uint32_t sentCount = 0;
    for (auto &node : bootstrapNodes)
    {
        const std::string attemptId = GenerateConnectionAttemptId();
        const int ret = net_com::registerNodeRequest(node, msgId, true, attemptId);
        if (ret == 0)
        {
            ++sentCount;
        }
        else
        {
            INFOLOG("Bootstrap attempt not sent round_id:{} attempt_id:{} group:{} ret:{}",
                    msgId, attemptId, BootstrapEndpointGroupKey(node), ret);
        }
    }

    if (!dataMgrPtr.SetExpectedResponses(msgId, sentCount))
    {
        MagicSingleton<ConnectionAttemptManager>::GetInstance()->ClosePendingRound(
            msgId, "invalid_registration_wait_count");
        dataMgrPtr.CancelWait(msgId);
        return false;
    }
    if (sentCount == 0)
    {
        MagicSingleton<ConnectionAttemptManager>::GetInstance()->ClosePendingRound(
            msgId, "no_registration_request_sent");
        std::vector<std::string> ignored;
        dataMgrPtr.WaitData(msgId, ignored);
        return false;
    }

    std::vector<std::string> returnDatas;
    const bool receivedAll = dataMgrPtr.WaitData(msgId, returnDatas);
    if (!receivedAll)
    {
        INFOLOG("Bootstrap registration wait incomplete sent:{} recv:{}",
                sentCount, returnDatas.size());
    }

    bool registeredBootstrap = false;
    RegisterNodeAck registerNodeAcknowledgment;
    std::map<std::string, Node> nodeMap;
    for (auto &data : returnDatas)
    {
        registerNodeAcknowledgment.Clear();
        if (!registerNodeAcknowledgment.ParseFromString(data))
        {
            ERRORLOG("registerNodeAcknowledgment ParseFromString failed");
            continue;
        }

        uint32_t ackIp = registerNodeAcknowledgment.from_ip();
        std::string ackFromAddr = registerNodeAcknowledgment.from_addr();
        uint32_t ackPort = registerNodeAcknowledgment.from_port();
        int ackFd = static_cast<int>(registerNodeAcknowledgment.fd());

        for (int i = 0; i < registerNodeAcknowledgment.nodes_size(); ++i)
        {
            const NodeInfo &nodeinfo = registerNodeAcknowledgment.nodes(i);
            if (nodeinfo.addr() == selfNode.address) continue;

            if (i == 0)
            {
                const bool bufferExists = ackFd > 0 &&
                    MagicSingleton<bufferControl>::GetInstance()->GetSocketBufByFd(ackFd) != nullptr;
                if (!bufferExists)
                {
                    DEBUGLOG("Ignore registration ACK without live fd attempt_id:{} fd:{}",
                             registerNodeAcknowledgment.attempt_id(), ackFd);
                    continue;
                }

                const int ret = RegistrationVerifier(
                    nodeinfo, ackIp, ackPort, ackFromAddr, ackFd,
                    registerNodeAcknowledgment.msg_id(),
                    registerNodeAcknowledgment.attempt_id());
                if (ret == 0)
                {
                    registeredBootstrap = true;
                }
                else
                {
                    DEBUGLOG("RegistrationVerifier error addr:{} port:{} ret:{}",
                             ackFromAddr, ackPort, ret);
                }
                continue;
            }

            Node node = nodeFromInfo(nodeinfo, selfNode);
            if (!node.address.empty()) nodeMap[node.address] = node;
        }
    }

    MagicSingleton<ConnectionAttemptManager>::GetInstance()->ClosePendingRound(
        msgId, receivedAll ? "registration_verification_failed" : "registration_timeout");

    std::set<std::string> configuredEndpointKeys;
    for (const auto &group : serverEndpointGroups)
    {
        for (const auto &endpoint : group)
        {
            configuredEndpointKeys.insert(
                NormalizeEndpointAddress(endpoint.addr) + ":" + std::to_string(endpoint.port));
        }
    }
    for (auto it = nodeMap.begin(); it != nodeMap.end();)
    {
        bool configured = false;
        for (const auto &endpoint : it->second.endpoints)
        {
            const std::string key =
                NormalizeEndpointAddress(endpoint.addr) + ":" + std::to_string(endpoint.port);
            if (configuredEndpointKeys.count(key) != 0)
            {
                configured = true;
                break;
            }
        }
        if (configured)
        {
            DEBUGLOG("Skip configured bootstrap node from discovered nodeMap: {}",
                     it->second.getPublicAddrStr());
            it = nodeMap.erase(it);
        }
        else
        {
            ++it;
        }
    }

    const size_t discoveredCount = nodeMap.size();
    if (!nodeMap.empty()) Register(nodeMap);
    const auto elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - startedAt).count();
    INFOLOG("Bootstrap round completed round_id:{} groups:{} sent:{} recv:{} registered:{} discovered:{} elapsed_ms:{}",
            msgId, configuredGroupCount, sentCount, returnDatas.size(),
            registeredBootstrap, discoveredCount, elapsedMs);
    return registeredBootstrap;
}

bool UnregisterNode::syncStartNode()
{
    std::string msgId;
    std::vector<Node> node_list = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
    const uint32_t candidateCount = node_list.size();
    if (!dataMgrPtr.CreateWait(5, candidateCount, msgId))
    {
        return false;
    }
    Node selfNode = MagicSingleton<PeerNode>::GetInstance()->GetSelfNode();
    uint32_t sentCount = 0;

    for (auto & node : node_list)
    {
        //Determine if TCP is connected
        bool bufferExists = node.publicIp != 0
            ? MagicSingleton<bufferControl>::GetInstance()->IsExists(node.publicIp, node.publicPort)
            : MagicSingleton<bufferControl>::GetInstance()->IsExists(node.getPublicAddrStr(), node.publicPort);
        if (bufferExists /* && node.is_established()*/)
        {
            if (net_com::synchronizeNodeRequest(node, msgId))
            {
                ++sentCount;
            }
            else
            {
                WARNLOG("Sync node request send failed peer:{} fd:{}", node.address, node.fd);
            }
        }
        else
        {
            DEBUGLOG("synchronizeNodeRequest error id:{} ip:{} port:{}", node.address, node.getPublicAddrStr(), node.publicPort);
        }
    }

    if (!dataMgrPtr.SetExpectedResponses(msgId, sentCount))
    {
        dataMgrPtr.CancelWait(msgId);
        ERRORLOG("Invalid sync wait count candidates:{} sent:{}", candidateCount, sentCount);
        return false;
    }

    std::vector<std::string> returnDatas;
    const bool receivedAll = dataMgrPtr.WaitData(msgId, returnDatas);
    if (!receivedAll)
    {
        WARNLOG("Node sync incomplete candidates:{} sent:{} recv:{}",
                candidateCount, sentCount, returnDatas.size());
    }
    SyncNodeAck syncNodeAcknowledgment;
    std::map<std::string, Node> nodeMap;
    std::vector<Node> syncNodes;
    std::map<std::string, std::vector<Node>> vrfNodeList;

    
    auto VerifySign = [&](const CSign & sign, const std::string & serHash) -> int{
        if (sign.sign().size() == 0 || sign.pub().size() == 0)
        {
            return -1;
        }
        if (serHash.size() == 0)
        {
            return -2;
        }

        EVP_PKEY* eckey = nullptr;
        if(get_ecdsa_pub_key_by_bytes(sign.pub(), eckey) == false)
        {
            EVP_PKEY_free(eckey);
            ERRORLOG("Get public key from bytes failed!");
            return -3;
        }

        if(ecdsaVerificationMessage(serHash, eckey, sign.sign()) == false)
        {
            EVP_PKEY_free(eckey);
            ERRORLOG("Public key verify sign failed!");
            return -4;
        }
        EVP_PKEY_free(eckey);
        return 0;
    };

    for (auto &retData : returnDatas)
    {
        syncNodeAcknowledgment.Clear();
        if (!syncNodeAcknowledgment.ParseFromString(retData))
        {
            continue;
        }
        auto syncNodeAcknowledgmentMessage = syncNodeAcknowledgment;
        syncNodeAcknowledgmentMessage.clear_sign();
        std::string vinHashSerialized = Getsha256Hash(syncNodeAcknowledgmentMessage.SerializeAsString());

        int verificationResult = VerifySign(syncNodeAcknowledgment.sign(), vinHashSerialized);
        if (verificationResult != 0)
        {
            ERRORLOG("targetNodelist VerifySign fail!!!");
            continue;
        }

        std::vector<Node> target_address_list;
        for (int i = 0; i < syncNodeAcknowledgment.nodes_size(); i++)
	    {
            const NodeInfo &nodeinfo = syncNodeAcknowledgment.nodes(i);
            if(nodeinfo.addr() == selfNode.address)
            {
                continue;
            }
            Node node = nodeFromInfo(nodeinfo, selfNode);
            std::string key = nodeKey(node);

            if(!key.empty() && nodeMap.find(key) == nodeMap.end())
            {
                nodeMap[key] = node;
            }
            target_address_list.push_back(node);

        }
        vrfNodeList[syncNodeAcknowledgment.ids()] = target_address_list;
    }

    for(auto & item : vrfNodeList)
    {
        std::sort(item.second.begin(), item.second.end(), compareStructs);
        auto last = std::unique(item.second.begin(), item.second.end(), compareStructs);
        item.second.erase(last, item.second.end());
        DEBUGLOG(" sort and unique @@@@@@ ");
        for(auto & i : item.second)
        {
            syncNodes.push_back(i);
        }
    }

    //Count the number of IPs and the number of times they correspond to IPs
    {
        std::map<Node,int, NodeCompare> syncNodeCount;
        for(auto it = syncNodes.begin(); it != syncNodes.end(); ++it)
        {
            syncNodeCount[*it]++;
        }
        data_to_split_and_insert(syncNodeCount);
        syncNodes.clear();
        syncNodeCount.clear();
    }

    //Only the latest elements are stored in the maintenance map map
    if(stake_node_list.size() == 2 || unstakeNodeList.size() == 2)
    {
        clear_split_node_list_data();
    }

    if(nodeMap.empty())
    {
        auto configServerEndpointGroups = MagicSingleton<Config>::GetInstance()->GetServerEndpointGroups();
        std::vector<std::vector<NodeEndpoint>> serverEndpointGroups;
        for (auto & group: configServerEndpointGroups)
        {
            std::vector<NodeEndpoint> endpoints;
            for (auto & endpoint: group.endpoints)
            {
                uint16_t endpointPort = static_cast<uint16_t>(endpoint.port);
                IpVersion family = endpoint.family == 6 ? IpVersion::IPv6 : (endpoint.family == 4 ? IpVersion::IPv4 : IpVersion::Unknown);
                endpoints.push_back(NodeEndpoint{endpoint.addr, endpointPort, family, endpoint.priority});
            }
            if (!endpoints.empty())
            {
                serverEndpointGroups.push_back(endpoints);
            }
        }

        MagicSingleton<UnregisterNode>::GetInstance()->startRegistrationNode(serverEndpointGroups);
    }
    else
    {
        Register(nodeMap);
    }

    return true;
}



void UnregisterNode::GetIpMap(std::map<uint64_t, std::map<std::string, int>> & m1,std::map<uint64_t, std::map<std::string, int>> & m2)
{
    std::unique_lock<std::mutex> locker(mutexStackList);
    m1 = stake_node_list;
    m2 = unstakeNodeList;
}


void UnregisterNode::deleteSplitNodeList(const std::string & addr)
{
    std::unique_lock<std::mutex> locker(mutexStackList);
    if(stake_node_list.empty() || unstakeNodeList.empty())
    {
        INFOLOG("list is empty!");
        return;
    }

    for(auto & [_,iter] : stake_node_list)
    {
        for(auto iter2 = iter.begin();iter2 != iter.end(); ++iter2)
        {
            if(iter2->first == addr)
            {
                iter2 = iter.erase(iter2);
                return;
            }
        }
    }
    
    for(auto & [_,iter] : unstakeNodeList)
    {
        for(auto iter2 = iter.begin();iter2 != iter.end(); ++iter2)
        {
            if(iter2->first == addr)
            {
                iter2 = iter.erase(iter2);
                return;
            }
        }
    }
}

void UnregisterNode::get_consensus_stake_node_list(std::map<std::string,int>& consensusStakeNodeMap_)
{
    std::unique_lock<std::mutex> lck(mutexStackList);
    if(stake_node_list.empty())
    {
        return;
    }
    consensusStakeNodeMap_.insert(stake_node_list.rbegin()->second.begin(), stake_node_list.rbegin()->second.end());
    return;
}

void UnregisterNode::get_consensus_node_list(std::map<std::string,int>& consensus_node_map)
{
    std::unique_lock<std::mutex> lck(mutexStackList);
    if(stake_node_list.empty() || unstakeNodeList.empty())
    {
        return;
    }
    consensus_node_map.insert(stake_node_list.rbegin()->second.begin(), stake_node_list.rbegin()->second.end());
    
    for(const auto& it : unstakeNodeList.rbegin()->second)
    {
        consensus_node_map[it.first] = it.second;
    }
    return;
}

void UnregisterNode::clear_split_node_list_data()
{
    std::unique_lock<std::mutex> lck(mutexStackList);
    auto it = stake_node_list.begin();
    stake_node_list.erase(it);

    auto _it = unstakeNodeList.begin();
    unstakeNodeList.erase(_it);
    DEBUGLOG("clear_split_node_list_data @@@@@ ");
}

static int calculateAverage(const std::vector<int>& vec)
{
    if (vec.empty()) {
        std::cout << "Error: Vector is empty." << std::endl;
        return 0;
    }

    int sum = 0;
    
    for (int num : vec)
    {
        sum += num;
    }
    
    int average = static_cast<double>(sum) / vec.size();
    
    return average;
}

void UnregisterNode::data_to_split_and_insert(const std::map<Node, int, NodeCompare>  syncNodeCount)
{
    std::unique_lock<std::mutex> locker(mutexStackList);
    std::map<std::string, int>  m_stakeSyncNodeCount;
    std::map<std::string, int>  unstakeSyncNodeCount;

    auto VerifyBonusAddr = [](const std::string& bonusAddr) -> int
    {
        // NET-017: Use CA interface instead of direct dependency
        uint64_t delegateAmount;
        auto caInterface = NetworkCAInterfaceRegistry::Get();
        if (!caInterface) {
            return -99;
        }
        auto ret = caInterface->getBonusAmount(bonusAddr, delegateAmount);
        if (ret < 0)
        {
            return -99;
        }
        return delegateAmount >= global::ca::kMinDelegatingAmt ? 0 : -99;
    };

    DBReader dbReader;

    std::string assetType;
    // NET-017: Use CA interface instead of direct dependency
    auto caInterface = NetworkCAInterfaceRegistry::Get();
    int ret = -1;
    if (caInterface) {
        ret = caInterface->GetCanBeRevokeAssetType(assetType);
    }
    if(ret != 0){
        ERRORLOG("Get Can BeRevoke AssetType fail!");
    }

    DEBUGLOG("data_to_split_and_insert @@@@@ ");
    for(auto & item : syncNodeCount)
    {
        //Verification of Delegating and pledge
        bool canReward = VerifyBonusAddr(item.first.address);
        std::vector<std::string> pledgeUtxoHashes;
        int retValue = dbReader.getStakeUtxoByAddr(item.first.address,assetType, pledgeUtxoHashes);
        bool HasPledged = DBStatus::DB_SUCCESS == retValue || !pledgeUtxoHashes.empty();
        if (HasPledged && canReward)
        {
            m_stakeSyncNodeCount.insert(std::make_pair(item.first.address,item.second));
        }
        else
        {
            unstakeSyncNodeCount.insert(std::make_pair(item.first.address,item.second));
        }
    }

    uint64_t nowTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    stake_node_list[nowTime] = m_stakeSyncNodeCount;
    unstakeNodeList[nowTime] = unstakeSyncNodeCount;
}
