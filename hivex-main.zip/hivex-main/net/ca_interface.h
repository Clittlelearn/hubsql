/**
 * *****************************************************************************
 * @file        ca_interface.h
 * @brief       Interface for CA layer functions used by net layer (NET-017)
 *              This decouples net/ from direct dependency on ca/ implementation
 * @date        2026-06-25
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef NET_CA_INTERFACE_H
#define NET_CA_INTERFACE_H

#include <string>
#include <memory>

// Interface for CA layer functions needed by net layer
class INetworkCAInterface {
public:
    virtual ~INetworkCAInterface() = default;
    
    // Get asset type that can be revoked
    // Returns 0 on success, negative on error
    virtual int GetCanBeRevokeAssetType(std::string& assetType) = 0;
    
    // Get bonus amount for a given address
    // Returns 0 on success, negative on error
    virtual int getBonusAmount(const std::string& bonusAddr, uint64_t& delegateAmount) = 0;

    // Slashing: record a heartbeat disconnect for L2 Forfeit tracking
    virtual void RecordDisconnect(const std::string& addr) = 0;
};

// Global registry for the CA interface implementation
class NetworkCAInterfaceRegistry {
public:
    static void Register(std::shared_ptr<INetworkCAInterface> impl);
    static std::shared_ptr<INetworkCAInterface> Get();
    
private:
    static std::shared_ptr<INetworkCAInterface> instance_;
};

#endif // NET_CA_INTERFACE_H
