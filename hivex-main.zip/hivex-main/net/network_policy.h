#ifndef OPENHIVE_NET_NETWORK_POLICY_H
#define OPENHIVE_NET_NETWORK_POLICY_H

#include <cstdint>
#include <string>
#include "common/genesis.h"
#include "node.hpp"

enum class NetworkAddressScope
{
    Invalid, Unspecified, Loopback, LinkLocal, Private, Shared, Reserved, Public
};

struct NetworkConnectionPolicy
{
    bool requirePublicAddress{false};
    bool requirePublicAdvertisedEndpoint{false};
    bool allowSharedSourceIp{true};
    bool enforcePerIpLimit{false};
    bool enforceSubnet16Limit{false};
    bool enforceInboundRatio{false};
    uint32_t maxPeerConnections{kMaxTotalConnections};
};

NetworkAddressScope ClassifyNetworkAddress(const std::string& address);
bool IsUsableRemoteAddress(const std::string& address);
bool IsPublicNetworkAddress(const std::string& address);
uint16_t Ipv4Subnet16(uint32_t networkOrderIp);
std::string NormalizeEndpointAddress(const std::string& address);
bool EndpointAddressesEquivalent(const std::string& left, const std::string& right);
std::string GenerateConnectionAttemptId();
bool IsValidConnectionAttemptId(const std::string& attemptId);
ConnKind PreferredConnectionKind(const std::string& selfAddress, const std::string& peerAddress);
bool ShouldReplaceExistingConnection(int existingFd, ConnKind existingKind,
                                     ConnKind candidateKind, ConnKind preferredKind);
NetworkConnectionPolicy GetNetworkConnectionPolicy(Genesis::NetworkType networkType);
NetworkConnectionPolicy GetCurrentNetworkConnectionPolicy();
bool IsAddressAllowedByNetwork(Genesis::NetworkType networkType, const std::string& address);

#endif
