/**
 * *****************************************************************************
 * @file        network_interface.h
 * @brief       Abstract network layer interface (NET-018)
 *              Provides abstraction for future libp2p migration
 * @date        2026-06-25
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef NET_NETWORK_INTERFACE_H
#define NET_NETWORK_INTERFACE_H

#include <string>
#include <vector>
#include <functional>
#include <memory>

// Forward declarations
struct Node;

// Abstract network layer interface
class INetworkLayer {
public:
    virtual ~INetworkLayer() = default;
    
    // Initialization and shutdown
    virtual bool initialize() = 0;
    virtual void shutdown() = 0;
    
    // Node management
    virtual std::vector<Node> getConnectedNodes() const = 0;
    virtual std::vector<Node> getStakeNodes() const = 0;
    virtual int getConnectedNodeCount() const = 0;
    virtual bool addNode(const Node& node) = 0;
    virtual bool removeNode(const std::string& address) = 0;
    virtual bool findNode(const std::string& address, Node& node) const = 0;
    
    // Message sending
    // Returns true on success, false on failure
    virtual bool sendToNode(const std::string& nodeAddress, 
                           const std::string& msgType,
                           const std::string& serializedData,
                           bool compress = false,
                           bool encrypt = true,
                           int priority = 0) = 0;
    
    // Broadcast message to all connected nodes
    virtual bool broadcast(const std::string& msgType,
                          const std::string& serializedData,
                          bool compress = false,
                          bool encrypt = true,
                          int priority = 0) = 0;
    
    // Callback registration
    using MessageCallback = std::function<void(const std::string& fromAddr, 
                                               const std::string& msgType,
                                               const std::string& data)>;
    virtual void registerMessageHandler(const std::string& msgType, 
                                        MessageCallback callback) = 0;
    
    // Statistics
    virtual uint64_t getMessagesSent() const = 0;
    virtual uint64_t getMessagesReceived() const = 0;
    virtual uint64_t getBytesSent() const = 0;
    virtual uint64_t getBytesReceived() const = 0;
};

// Global registry for network layer implementation
class NetworkLayerRegistry {
public:
    static void Register(std::shared_ptr<INetworkLayer> impl);
    static std::shared_ptr<INetworkLayer> Get();
    
private:
    static std::shared_ptr<INetworkLayer> instance_;
};

#endif // NET_NETWORK_INTERFACE_H
