#ifndef _DEFINE_H_
#define _DEFINE_H_

#include <cstdint>
#include <string>

constexpr int END_FLAG              = 7777777;             
constexpr int IP_LEN				= 16;	//IPlenght
			  
constexpr int MAXEPOLLSIZE			= 100000;
constexpr int MAXLINE				= 10240l;
			   
constexpr int HEARTBEAT_INTERVAL     =  60;   // detect how many times to start sending heartbeat packets,
constexpr int HEARTBEAT_CHECKS    =  3;   //If the other party does not respond after sending several heartbeat packets, the connection is close

// Message size limits (NET-002)
constexpr uint32_t kMaxMessageSize = 32 * 1024 * 1024;   // 32MB hard limit
constexpr uint32_t kMaxSendBufferSize = 16 * 1024 * 1024; // 16MB per-peer send buffer limit (NET-008)

// Connection limits (NET-001)
constexpr int kMaxTotalConnections = 500;        // Global max connections
constexpr int kMaxInboundConnections = 300;      // Max inbound connections
constexpr int kMaxOutboundConnections = 200;     // Max outbound connections
constexpr int kMaxConnectionsPerIP = 3;          // Max connections per single IP
constexpr int kMaxNewConnectionsPerSecond = 20;  // Max new connections per second

// Rate limiting (NET-003)
constexpr uint64_t kMaxMessagesPerPeerPerSecond = 100;    // Max messages per peer per second
constexpr uint64_t kMaxBytesPerPeerPerSecond = 10 * 1024 * 1024;  // Max 10MB per peer per second
constexpr int kRateLimitBanSeconds = 60;         // Ban duration after rate limit violation
constexpr int kRateLimitBanThreshold = 5;        // Disconnect after 5 violations

// Message deduplication (NET-007)
constexpr size_t kDedupCacheSize = 100000;       // Max cached message fingerprints
constexpr int kDedupExpireSeconds = 300;         // Fingerprint expire time (5 minutes)

// Auto-reconnect (NET-006)
constexpr int kMaxReconnectAttempts = 5;         // Max reconnect attempts per node
constexpr int kReconnectBaseDelayMs = 1000;      // Base delay 1 second
constexpr int kReconnectMaxDelayMs = 60000;      // Max delay 60 seconds
constexpr int kMaxReconnectsPerSecond = 10;      // Global max reconnects per second
constexpr double kReconnectMinReputation = 0.2;  // Min reputation to reconnect

// Server endpoint bootstrap retry
constexpr int kServerEndpointRetryTickSeconds = 5;    // Wake interval for retry checks
constexpr int kServerEndpointRetryInitialSeconds = 5; // First retry delay
constexpr int kServerEndpointRetryMaxSeconds = 30;    // Retry delay cap

// Write timeout (NET-010)
constexpr int kWriteTimeoutSeconds = 30;         // Write timeout 30 seconds
constexpr size_t kSendBufferSoftLimit = 1 * 1024 * 1024;  // 1MB soft limit (backpressure)

// Eclipse attack protection (NET-014)
constexpr int kMaxInboundRatio = 70;             // Max 70% inbound connections
constexpr int kMinOutboundConnections = 8;       // Min outbound connections
constexpr int kMaxConnectionsPerSubnet16 = 5;    // Max connections per /16 subnet

// Key rotation (NET-012)
constexpr int kKeyRotationIntervalSeconds = 3600;  // Rotate keys every 1 hour


typedef int int32;
typedef unsigned int uint32;
typedef unsigned char uint8;
typedef char int8;

using u64 = std::uint64_t;
using u32 = std::uint32_t;
using u16 = std::uint16_t;
using u8 = std::uint8_t;

using i64 = std::int64_t;

using nll = long long;
using ull = unsigned long long;


//Network packet body
typedef struct NetPack
{
	uint32_t	len				= 0;
	std::string	data			= "";
	uint32_t   	checkSum		= 0;
	uint32_t	flag			= 0;
	uint32_t    endFlag        = END_FLAG;
}NetPack;

#endif