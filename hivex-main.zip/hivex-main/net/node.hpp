#ifndef _NODE_H_
#define _NODE_H_

#include <string>
#include <iostream>
#include <sstream>
#include <chrono>
#include <vector>
#include <algorithm>
#include <cstdint>
#include "define.h"
#include "ip_port.h"

enum ConnKind
{
	NOTYET, //Not yet connected
	dataRateToOutput, //Outer and external direct connection
	PASSIV	//Passively accept connections
};

// NET-016: IP address version
enum class IpVersion : uint8_t {
	Unknown = 0,
	IPv4 = 4,
	IPv6 = 6
};

struct NodeEndpoint
{
	std::string addr;
	uint16_t port = 0;
	IpVersion family = IpVersion::Unknown;
	uint32_t priority = 0;

	bool isValid() const
	{
		return !addr.empty() && port != 0;
	}

	std::string key() const
	{
		return addr + ":" + std::to_string(port);
	}
};

// NET-003: Per-peer statistics for rate limiting and reputation scoring
struct PeerStats {
    // Rate limiting fields (NET-003)
    double tokens = (double)kMaxMessagesPerPeerPerSecond;  // Token bucket current tokens
    std::chrono::steady_clock::time_point last_refill = std::chrono::steady_clock::now();
    bool rate_limited = false;
    int rate_limit_violations = 0;
    
    // General statistics (NET-011/019 will use these)
    uint64_t messages_received = 0;
    uint64_t messages_valid = 0;
    uint64_t messages_invalid = 0;
    uint64_t bytes_received = 0;
    double avg_rtt_ms = 0.0;
    std::chrono::steady_clock::time_point first_seen = std::chrono::steady_clock::now();
    std::chrono::steady_clock::time_point last_seen = std::chrono::steady_clock::now();
    int protocol_violations = 0;
    
    // NET-011: Reputation scoring fields (0.0 ~ 1.0)
    double latency_score = 0.5;
    double validity_score = 0.5;
    double uptime_score = 0.0;
    double compliance_score = 0.5;
    double total_score = 0.5;
    
    // Token bucket refill
    void refillTokens(std::chrono::steady_clock::time_point now) {
        double elapsed = std::chrono::duration<double>(now - last_refill).count();
        tokens = std::min((double)kMaxMessagesPerPeerPerSecond, 
                         tokens + elapsed * kMaxMessagesPerPeerPerSecond);
        last_refill = now;
    }
    
    bool consumeToken() {
        if (tokens < 1.0) return false;
        tokens -= 1.0;
        return true;
    }
    
    // NET-011: Recalculate total reputation score
    void recalculateScore() {
        // Update uptime score based on connection duration
        auto now = std::chrono::steady_clock::now();
        double hours = std::chrono::duration<double>(now - first_seen).count() / 3600.0;
        uptime_score = std::min(1.0, hours / 24.0);  // 24h = full score
        
        // Update validity score
        if (messages_received > 0) {
            validity_score = (double)messages_valid / messages_received;
        }
        
        // Weighted total
        total_score = 
            0.20 * latency_score +
            0.30 * validity_score +
            0.15 * uptime_score +
            0.35 * compliance_score;
    }
};

class Node
{
public:
	std::string     address     = "";
	std::string     pub               = "";
	std::string     sign              = "";
	std::string     identity          = "";
	std::string     name			  = "";
	std::string 	logo			  = "";
	std::string		ver			      = "";

	// NET-016: IPv4/IPv6 dual-stack support
	// Legacy fields (IPv4 only, kept for backward compatibility)
	uint32_t        listenIp                = 0;
	uint32_t        publicIp                = 0;

	// New fields (support both IPv4 and IPv6)
	std::string     listenAddr              = "";   // Listen address string (IPv4 or IPv6)
	std::string     publicAddr              = "";   // Public address string (IPv4 or IPv6)
	IpVersion       ipVersion               = IpVersion::Unknown;

	// Port fields (unchanged, same for IPv4 and IPv6)
	uint32_t        listenPort              = 0;
	uint32_t        publicPort              = 0;
	std::vector<NodeEndpoint> endpoints;
	NodeEndpoint connectedEndpoint;

	uint32_t        height                   = 0;
	ConnKind 	    connKind                = NOTYET;
	int32_t         fd                       = -1;
	int32_t         pulse             = HEARTBEAT_CHECKS;

	// NET-003: Per-peer statistics
	PeerStats peer_stats;

	Node(){}
	Node(std::string nodeAddress)
	{
		address = nodeAddress;
	}

	// NET-016: Helper methods for address access
	// Get public address as string (prefers new field, falls back to legacy)
	std::string getPublicAddrStr() const {
		if (!connectedEndpoint.addr.empty()) return connectedEndpoint.addr;
		if (!publicAddr.empty()) return publicAddr;
		if (!endpoints.empty()) return endpoints.front().addr;
		if (publicIp != 0) return std::string(IpPort::IpSz(publicIp));
		return "";
	}

	// Get listen address as string (prefers new field, falls back to legacy)
	std::string getListenAddrStr() const {
		if (!listenAddr.empty()) return listenAddr;
		if (listenIp != 0) return std::string(IpPort::IpSz(listenIp));
		return "";
	}

	// Set public address from string (updates both new and legacy fields)
	void setPublicAddr(const std::string& addr) {
		publicAddr = addr;
		if (!addr.empty()) {
			// Try to parse as IPv4 for legacy field
			uint32_t ip4 = IpPort::IpNum(addr);
			if (ip4 != 0 && ip4 != (uint32_t)-1) {
				publicIp = ip4;
				ipVersion = IpVersion::IPv4;
			} else {
				publicIp = 0;
				ipVersion = IpVersion::IPv6;
			}
		}
	}

	// Set listen address from string (updates both new and legacy fields)
	void setListenAddr(const std::string& addr) {
		listenAddr = addr;
		if (!addr.empty()) {
			uint32_t ip4 = IpPort::IpNum(addr);
			if (ip4 != 0 && ip4 != (uint32_t)-1) {
				listenIp = ip4;
			}
		}
	}

	void addEndpoint(const std::string& addr, uint16_t port, IpVersion family = IpVersion::Unknown, uint32_t priority = 0) {
		if (addr.empty() || port == 0) return;
		if (family == IpVersion::Unknown) {
			family = IpPort::IsIPv6(addr) ? IpVersion::IPv6 : IpVersion::IPv4;
		}
		auto iter = std::find_if(endpoints.begin(), endpoints.end(), [&](const NodeEndpoint& endpoint) {
			return endpoint.addr == addr && endpoint.port == port;
		});
		if (iter != endpoints.end()) {
			iter->family = family;
			iter->priority = priority;
			return;
		}
		endpoints.push_back(NodeEndpoint{addr, port, family, priority});
		syncLegacyEndpoint();
	}

	void syncLegacyEndpoint() {
		if (endpoints.empty()) return;
		std::sort(endpoints.begin(), endpoints.end(), [](const NodeEndpoint& left, const NodeEndpoint& right) {
			return left.priority < right.priority;
		});
		const auto& endpoint = endpoints.front();
		setPublicAddr(endpoint.addr);
		listenPort = endpoint.port;
	}

	void setConnectedEndpoint(const NodeEndpoint& endpoint) {
		connectedEndpoint = endpoint;
		setPublicAddr(endpoint.addr);
	}

	bool operator==(const Node &obj) const
	{
		return address == obj.address;
	}

	bool operator>(const Node &obj)
	{
		return (*this).address > obj.address;
	}

	void ResetHeart()
	{
		pulse = HEARTBEAT_CHECKS;
	}
	void Print()
	{
		std::cout << InfoStr() << std::endl;
	}

	std::string InfoStr()
	{

		std::ostringstream oss;
		oss
			<< "  addr(" << "0x"+ address << ")"
			<< "  ip(" << getPublicAddrStr() << ")"
			<< "  port(" << publicPort << ")"
			<< "  kind(" << connKind << ")"
			<< "  fd(" << fd << ")"
			<< "  pulse(" << pulse << ")"
			<< "  height( " << height << " )"
			<< "  name(" << name << ")"
			<< "  version(" << ver << ")"
			<< "  logo(" << logo << ")"
			<< std::endl;
		return oss.str();
	}


	bool IsConnected() const
	{
		return fd > 0 || fd == -2;
	}
	void SetHeight(uint32_t height)
	{
		this->height = height;
	}
};

#endif 