#include "handle_event.h"

#include <cstddef>
#include <exception>
#include <fstream>
#include <unordered_set>
#include <utility>
#include <iomanip>

#include "./pack.h"
#include "./ip_port.h"
#include "./global.h"
#include "./network_policy.h"
#include "./connection_attempt.h"


#include "../common/config.h"
#include "../common/global_data.h"
#include "../db/db_api.h"
#include "../net/dispatcher.h"
#include "../net/peer_node.h"
#include "../net/socket_buf.h"
#include "../net/test.hpp"
#include "../net/unregister_node.h"
#include "../net/interface.h"
#include "../include/logging.h"
#include "../include/scope_guard.h"
#include "../pb/common.pb.h"
#include "../pb/net.pb.h"
#include "../utils/account_manager.h"
#include "../utils/console.h"
#include "../utils/cycliclist.hpp"
#include "../utils/hex_code.h"
#include "../utils/magic_singleton.h"
#include "../utils/tmp_log.h"
#include "../utils/contract_utils.h"
#include "../utils/version.h"
#include "../utils/sha256.h"


namespace
{
void fillNodeInfoEndpoints(NodeInfo* nodeInfo, const Node& node)
{
	if (nodeInfo == nullptr) return;
	if (!node.endpoints.empty())
	{
		for (const auto& endpoint : node.endpoints)
		{
			if (!endpoint.isValid()) continue;
			EndpointInfo* endpointInfo = nodeInfo->add_endpoints();
			endpointInfo->set_addr(endpoint.addr);
			endpointInfo->set_port(endpoint.port);
			endpointInfo->set_family(static_cast<uint32_t>(endpoint.family));
			endpointInfo->set_priority(endpoint.priority);
		}
		return;
	}

	std::string addr = node.getPublicAddrStr();
	uint16_t port = node.listenPort != 0 ? static_cast<uint16_t>(node.listenPort) : static_cast<uint16_t>(node.publicPort);
	if (!addr.empty() && port != 0)
	{
		EndpointInfo* endpointInfo = nodeInfo->add_endpoints();
		endpointInfo->set_addr(addr);
		endpointInfo->set_port(port);
		endpointInfo->set_family(IpPort::IsIPv6(addr) ? 6 : 4);
	}
}

uint32_t advertisedNodePort(const Node& node)
{
	if (!node.endpoints.empty())
	{
		return node.endpoints.front().port;
	}
	if (node.listenPort != 0)
	{
		return node.listenPort;
	}
	return node.publicPort;
}

bool samePeerAddress(const MsgData& from, const Node& node)
{
	const std::string fromAddr = from.getAddrStr();
	const std::string nodeAddr = node.getPublicAddrStr();
	if (!fromAddr.empty() || !nodeAddr.empty())
	{
		return fromAddr == nodeAddr;
	}
	return from.ip != 0 && from.ip == node.publicIp;
}

bool HasAllowedAdvertisedEndpoint(const NodeInfo& nodeInfo,
                                  const NetworkConnectionPolicy& policy)
{
	if (!policy.requirePublicAdvertisedEndpoint) return true;
	for (const auto& endpoint : nodeInfo.endpoints())
	{
		if (endpoint.port() != 0 && IsPublicNetworkAddress(endpoint.addr()))
		{
			return true;
		}
	}
	const std::string advertisedAddr = !nodeInfo.node_public_addr().empty()
		? nodeInfo.node_public_addr()
		: nodeInfo.public_addr();
	const uint32_t advertisedPort = nodeInfo.listen_port() != 0
		? nodeInfo.listen_port()
		: nodeInfo.public_port();
	return advertisedPort != 0 && IsPublicNetworkAddress(advertisedAddr);
}
}

int processPrintMessageRequest(const std::shared_ptr<PrintMsgReq> &requestToPrintMessage, const MsgData &from)
{
	static int printMsCount = 0;
	int type = requestToPrintMessage->type();
	if (type == 0)
	{
		std::cout << ++printMsCount << " times data:" << requestToPrintMessage->data() << std::endl;
	}
	else
	{
		std::ofstream file("bigdata.txt", std::fstream::out);
		file << requestToPrintMessage->data();
		file.close();
		std::cout << "write bigdata.txt success!!!" << std::endl;
	}
	return 0;
}

static std::mutex nodeMutex;
int handleRegisterNodeRequest(const std::shared_ptr<RegisterNodeReq> &registerNode, const MsgData &from)
{
	INFOLOG("handleRegisterNodeRequest");
	DEBUGLOG("handleRegisterNodeRequest from.ip:{} from.port:{} from.fd:{}", from.getAddrStr(),from.port,from.fd);


	Node selfNode = MagicSingleton<PeerNode>::GetInstance()->GetSelfNode();

	std::lock_guard<std::mutex> lock(nodeMutex);
	NodeInfo *nodeInfo = registerNode->mutable_mynode();
	Node node;
	std::string dest_pub = nodeInfo->pub();
	std::string destAddr = nodeInfo->addr();

	node.fd = from.fd;
	node.address = destAddr;
	node.identity = nodeInfo->identity();
	node.name = nodeInfo->name();
	node.logo = nodeInfo->logo();
	node.pub = dest_pub;
	node.sign = nodeInfo->sign();
	node.listenIp = selfNode.listenIp;
	node.listenAddr = selfNode.getListenAddrStr();
	node.listenPort = kServerMainPort;
	node.publicIp = from.ip;
	node.publicAddr = from.getAddrStr();
	node.ipVersion = node.publicIp == 0 ? IpVersion::IPv6 : IpVersion::IPv4;
	node.publicPort = from.port;
	for (int i = 0; i < nodeInfo->endpoints_size(); ++i)
	{
		const auto& endpoint = nodeInfo->endpoints(i);
		node.addEndpoint(endpoint.addr(), static_cast<uint16_t>(endpoint.port()), static_cast<IpVersion>(endpoint.family()), endpoint.priority());
	}
	if (node.endpoints.empty())
	{
		std::string advertisedAddr = !nodeInfo->node_public_addr().empty() ? nodeInfo->node_public_addr() : nodeInfo->public_addr();
		uint16_t advertisedPort = nodeInfo->listen_port() != 0 ? static_cast<uint16_t>(nodeInfo->listen_port()) : static_cast<uint16_t>(nodeInfo->public_port());
		if (!advertisedAddr.empty() && advertisedPort != 0)
		{
			node.addEndpoint(advertisedAddr, advertisedPort, IpPort::IsIPv6(advertisedAddr) ? IpVersion::IPv6 : IpVersion::IPv4, 0);
		}
	}
	node.setConnectedEndpoint(NodeEndpoint{from.getAddrStr(), from.port, node.ipVersion, 0});
	node.publicPort = from.port;
	node.height = nodeInfo->height();
	node.ver = nodeInfo->version();

	int ret = 0;
	ON_SCOPE_EXIT{
		if (ret != 0)
		{
			DEBUGLOG("register node failed and disconnect.from.ip:{} from.port:{} from.fd:{},  ret:{}", node.getPublicAddrStr(),node.publicPort,node.fd, ret);
			if (!MagicSingleton<ConnectionAttemptManager>::GetInstance()->CloseAttempt(
			        registerNode->attempt_id(), "inbound_registration_failed"))
			{
				MagicSingleton<PeerNode>::GetInstance()->DisconnectNode(node);
			}
		}
	};

	if (!IsValidConnectionAttemptId(registerNode->attempt_id()))
	{
		return ret -= 13;
	}
	if (registerNode->network_name() != MagicSingleton<Genesis>::GetInstance()->GetNetworkName())
	{
		WARNLOG("Reject peer from different network local:{} remote:{}",
		        MagicSingleton<Genesis>::GetInstance()->GetNetworkName(), registerNode->network_name());
		return ret -= 17;
	}

	const auto networkPolicy = GetCurrentNetworkConnectionPolicy();

	//Multiple registration of the same IP address is prohibited
	std::vector<Node> pubNodeList_ = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
	auto result = std::find_if(pubNodeList_.begin(), pubNodeList_.end(),[&from, &node](auto & existingNode){
		return existingNode.address != node.address && samePeerAddress(from, existingNode);
	});
	if(!networkPolicy.allowSharedSourceIp && result != pubNodeList_.end())
	{
		return ret -= 1;
	}
		
	//Prohibit intranet node connection
	// NET-016: Use IsLanAddr to support both IPv4 and IPv6
	if(IpPort::IsLanAddr(from.getAddrStr()) == true)
	{
		WARNLOG("{} is an intranet node", from.getAddrStr());
		return ret -= 2;
	}

	if (!HasAllowedAdvertisedEndpoint(*nodeInfo, networkPolicy))
	{
		WARNLOG("Node {} has no public advertised endpoint", node.address);
		return ret -= 2;
	}

	// Judge whether the version is compatible
    if (0 != Util::IsVersionCompatible(nodeInfo->version()))
    {
        ERRORLOG("Incompatible version!");
        return ret -= 3;
    }

	if(node.address == MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr())
    {
        ERRORLOG("Don't register yourself ");
        return ret -= 4;
    }

	EVP_PKEY* eckey = nullptr;


	std::string node_addr = nodeInfo->addr();
	if (!isValidAddress(node_addr))
	{
		ERRORLOG("address invalid !!");
		return ret -= 5;
	}

    std::string Addr = GenerateAddr(nodeInfo->identity());
    DEBUGLOG("registerReq identity hex {}", Str2Hex(nodeInfo->identity()));
    if (Addr != node_addr)
    {
        std::string pub_hex = Str2Hex(nodeInfo->pub());
        DEBUGLOG("nodeInfo pub hex {}", pub_hex);
        if (!nodeInfo->pub().empty())
        {
            std::string AddrByPub = GenerateAddr(nodeInfo->pub());
            if (AddrByPub == node_addr)
            {
                Addr = AddrByPub;
            }
            else
            {
                ERRORLOG("Addr is {}", Addr);
                ERRORLOG("node_addr is {}", node_addr);
                ERRORLOG("address error !!");
                return ret -= 6;
            }
        }
        else
        {
            ERRORLOG("Addr is {}", Addr);
            ERRORLOG("node_addr is {}", node_addr);
            ERRORLOG("address error !!");
            return ret -= 6;
        }
    }

    if(nodeInfo->identity().size() <= 0 && nodeInfo->pub().size() <= 0)
    {
        ERRORLOG("public key is empty");
        return ret -= 7;
    }

    Account account;
    const std::string &verifyKey = nodeInfo->identity().size() > 0 ? nodeInfo->identity() : nodeInfo->pub();
    if(MagicSingleton<AccountManager>::GetInstance()->getAccountPublicKeyByBytes(verifyKey, account) == false){
        ERRORLOG(RED "Get public key from bytes failed!" RESET);
        return ret -= 8;
    }


    std::string nodeInfo_signature = nodeInfo->sign();
    if(account.Verify(Getsha256Hash(node_addr), nodeInfo_signature) == false)
    {
        ERRORLOG(RED "Public key verify sign failed!" RESET);
        return ret -= 9;
    }

	
	Node temNode;
	const bool find = MagicSingleton<PeerNode>::GetInstance()->FindNode(node.address, temNode);
	const ConnKind preferredKind = PreferredConnectionKind(selfNode.address, node.address);
	node.connKind = PASSIV;

	auto bindVerifiedEcdhKey = [&]() {
		auto ecdhKey = MagicSingleton<KeyExchangeManager>::GetInstance()->getKey(from.fd);
		if (ecdhKey)
		{
			ecdhKey->verified_address = node.address;
			ecdhKey->identity_verified = true;
		}
	};

	if (find)
	{
		if (temNode.fd == from.fd)
		{
			node.connKind = temNode.connKind;
			if (!MagicSingleton<PeerNode>::GetInstance()->Update(node)) return ret -= 15;
			bindVerifiedEcdhKey();
		}
		else
		{
			if (!ShouldReplaceExistingConnection(
			        temNode.fd, temNode.connKind, PASSIV, preferredKind))
			{
				INFOLOG("Keep existing connection for peer:{} old_fd:{} reject_fd:{} preferred:{}",
				        node.address, temNode.fd, from.fd,
				        preferredKind == PASSIV ? "passive" : "outbound");
				return ret -= 16;
			}

			if (!MagicSingleton<PeerNode>::GetInstance()->Update(node)) return ret -= 15;
			bindVerifiedEcdhKey();
			if (temNode.fd > 0)
			{
				MagicSingleton<PeerNode>::GetInstance()->DisconnectNode(temNode);
			}
		}
	}
	else
	{
		if (!samePeerAddress(from, node) || from.port != node.publicPort) return ret -= 15;
		if (!MagicSingleton<PeerNode>::GetInstance()->Add(node)) return ret -= 15;
		bindVerifiedEcdhKey();
	}
	
	
	std::string signature;

	Account acc;
	if(MagicSingleton<AccountManager>::GetInstance()->GetDefaultAccount(acc) != 0)
	{
		return ret -= 10;
	}

	if (selfNode.address != acc.GetAddr())
	{
		return ret -= 11;
	}
	if(!acc.Sign(Getsha256Hash(acc.GetAddr()), signature))
	{
		return ret -= 12;
	}

	selfNode.identity = acc.GetPubStr();
	selfNode.sign = signature;

	RegisterNodeAck registerNodeAcknowledgment;
	registerNodeAcknowledgment.set_msg_id(registerNode->msg_id());
	registerNodeAcknowledgment.set_attempt_id(registerNode->attempt_id());
	registerNodeAcknowledgment.set_network_name(MagicSingleton<Genesis>::GetInstance()->GetNetworkName());
	std::vector<Node> nodeList;

	std::vector<Node> tmp = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
	nodeList.push_back(selfNode);
	if(registerNode->is_get_nodelist() == true)
	{
		nodeList.insert(nodeList.end(), tmp.begin(), tmp.end());
	}

	for (auto &node : nodeList)
	{		
		if (node.fd < 0) 
		{
			if (node.address != selfNode.address)
			{
				ERRORLOG("node  addr is same of self node  addr");
				continue;
			}
		}

		NodeInfo *nodeInfo = registerNodeAcknowledgment.add_nodes();

		nodeInfo->set_addr(node.address);
		nodeInfo->set_name(node.name);
		nodeInfo->set_logo(node.logo);
		nodeInfo->set_listen_ip(node.listenIp);
		nodeInfo->set_listen_addr(node.getListenAddrStr());
		nodeInfo->set_listen_port(node.listenPort);
		nodeInfo->set_public_ip(node.publicIp);
		nodeInfo->set_public_addr(node.getPublicAddrStr());
		nodeInfo->set_node_public_addr(node.getPublicAddrStr());
		nodeInfo->set_ip_version(static_cast<uint32_t>(node.ipVersion));
		nodeInfo->set_public_port(advertisedNodePort(node));
		fillNodeInfoEndpoints(nodeInfo, node);
        nodeInfo->set_identity(node.identity);
        nodeInfo->set_sign(node.sign);
		nodeInfo->set_height(node.height);
		nodeInfo->set_version(node.ver);
	}

	// Keep the attempt non-terminal until the ACK is successfully queued.
	// On send failure, the scope guard owns removal of the peer, key and fd.
	if (!net_com::SendMessage(destAddr, registerNodeAcknowledgment,
	                          net_com::Compress::COMPRESS_TRUE,
	                          net_com::Encrypt::ENCRYPT_FALSE,
	                          net_com::Priority::kHighPriorityLevel2))
	{
		return ret -= 18;
	}

	if (!MagicSingleton<ConnectionAttemptManager>::GetInstance()->MarkRegistered(
	        registerNode->msg_id(), registerNode->attempt_id(), from.fd))
	{
		return ret -= 14;
	}
	return ret;
}

int handleRegisterNodeAcknowledgment(const std::shared_ptr<RegisterNodeAck> &registerNodeAcknowledgment, const MsgData &from)
{
	if (!IsValidConnectionAttemptId(registerNodeAcknowledgment->attempt_id())) return -2;
	if (registerNodeAcknowledgment->network_name() !=
	    MagicSingleton<Genesis>::GetInstance()->GetNetworkName()) return -4;
	if (!MagicSingleton<ConnectionAttemptManager>::GetInstance()->ValidatePendingAck(
	        registerNodeAcknowledgment->msg_id(), registerNodeAcknowledgment->attempt_id(), from.fd))
	{
		WARNLOG("Reject registration ACK with mismatched attempt or fd attempt_id:{} fd:{}",
		        registerNodeAcknowledgment->attempt_id(), from.fd);
		return -3;
	}
	// NET-016: Use IsLanAddr to support both IPv4 and IPv6
	if(IpPort::IsLanAddr(from.getAddrStr()) == true)
	{
		WARNLOG("{} is an intranet node", from.getAddrStr());
		return -1;
	}

	DEBUGLOG("from.ip:{}", from.getAddrStr());
	registerNodeAcknowledgment->set_from_ip(from.ip);
	registerNodeAcknowledgment->set_from_addr(from.getAddrStr());
	registerNodeAcknowledgment->set_from_port(from.port);
	registerNodeAcknowledgment->set_fd(from.fd);
	if (!dataMgrPtr.waitDataToAdd(registerNodeAcknowledgment->msg_id(),
	                              registerNodeAcknowledgment->attempt_id(),
	                              registerNodeAcknowledgment->SerializeAsString()))
	{
		DEBUGLOG("Ignore late registration ACK round_id:{} attempt_id:{} fd:{}",
		         registerNodeAcknowledgment->msg_id(),
		         registerNodeAcknowledgment->attempt_id(), from.fd);
	}
	return 0;
}

int RegistrationVerifier(const NodeInfo &nodeInfo, uint32_t &fromIp, uint32_t &fromPort,
                         const std::string &fromAddr, int fd, const std::string& roundId,
                         const std::string& attemptId)
{
	std::string peerAddr = fromIp != 0 ? IpPort::IpSz(fromIp) : fromAddr;
	if (peerAddr.empty())
	{
		peerAddr = !nodeInfo.node_public_addr().empty() ? nodeInfo.node_public_addr() : nodeInfo.public_addr();
	}

	// NET-016: Use IsLanAddr to support both IPv4 and IPv6
	if(IpPort::IsLanAddr(peerAddr) == true)
	{
		WARNLOG("{} is an intranet node", peerAddr);
		return -1;
	}

	if (!HasAllowedAdvertisedEndpoint(nodeInfo, GetCurrentNetworkConnectionPolicy()))
	{
		WARNLOG("Node {} has no public advertised endpoint", nodeInfo.addr());
		return -1;
	}

	INFOLOG("handleRegisterNodeAcknowledgment");

	auto self_node = MagicSingleton<PeerNode>::GetInstance()->GetSelfNode();

	Node node;
	node.address = nodeInfo.addr();
	node.identity = nodeInfo.identity();
	node.name = nodeInfo.name();
	node.logo = nodeInfo.logo();
	node.pub = nodeInfo.pub();
	node.sign = nodeInfo.sign();
	node.listenIp = self_node.listenIp;
	node.listenAddr = self_node.getListenAddrStr();
	node.listenPort = kServerMainPort;
	node.publicIp = fromIp;
	if (!peerAddr.empty())
	{
		node.setPublicAddr(peerAddr);
	}
	node.publicPort = fromPort;
	node.ipVersion = fromIp == 0 ? IpVersion::IPv6 : IpVersion::IPv4;
	node.height = nodeInfo.height();
	node.ver = nodeInfo.version();
	for (const auto& endpoint : nodeInfo.endpoints())
	{
		node.addEndpoint(endpoint.addr(), static_cast<uint16_t>(endpoint.port()),
		                 static_cast<IpVersion>(endpoint.family()), endpoint.priority());
	}
	if (node.endpoints.empty())
	{
		const std::string advertisedAddr = !nodeInfo.node_public_addr().empty()
			? nodeInfo.node_public_addr() : nodeInfo.public_addr();
		const uint32_t advertisedPort = nodeInfo.public_port() != 0
			? nodeInfo.public_port() : nodeInfo.listen_port();
		if (!advertisedAddr.empty() && advertisedPort != 0)
		{
			node.addEndpoint(advertisedAddr, static_cast<uint16_t>(advertisedPort),
			                 IpPort::IsIPv6(advertisedAddr) ? IpVersion::IPv6 : IpVersion::IPv4, 0);
		}
	}

	// Judge whether the version is compatible
    if (0 != Util::IsVersionCompatible(nodeInfo.version()))
    {
        ERRORLOG("Incompatible version!");
        return -2;
    }

	if(!isValidAddress(nodeInfo.addr()))
	{
		return -3;
	}

    std::string Addr = GenerateAddr(node.identity);
    if (Addr != node.address)
    {
        DEBUGLOG("node identity hex {}", Str2Hex(node.identity));
        DEBUGLOG("node pub hex {}", Str2Hex(node.pub));
        if (!node.pub.empty())
        {
            std::string AddrByPub = GenerateAddr(node.pub);
            if (AddrByPub == node.address)
            {
                Addr = AddrByPub;
            }
            else
            {
                DEBUGLOG("vAddr is {}", Addr);
                DEBUGLOG("vnode_addr is {}", node.address);
                return -4;
            }
        }
        else
        {
            DEBUGLOG("vAddr is {}", Addr);
            DEBUGLOG("vnode_addr is {}", node.address);
            return -4;
        }
    }
	
	Account account;
	if(MagicSingleton<AccountManager>::GetInstance()->getAccountPublicKeyByBytes(node.identity, account) == false){
		ERRORLOG(RED "Get public key from bytes failed!" RESET);
		return -5;
	}

    if(account.Verify(Getsha256Hash(node.address), node.sign) == false)
    {
        ERRORLOG(RED "Public key verify sign failed!" RESET);
        return -6;
    }

	if (node.address == MagicSingleton<PeerNode>::GetInstance()->GetSelfId())
	{
		return -7;
	}

	std::shared_ptr<SocketBuf> ptr;
	if (fd > 0) ptr = MagicSingleton<bufferControl>::GetInstance()->GetSocketBufByFd(fd);
	if (!ptr) return -9;
	node.fd = ptr->fd;
	net_com::ANALYSIS_CONNECTION_KIND(node);

	Node tempNode;
	const bool found = MagicSingleton<PeerNode>::GetInstance()->FindNode(node.address, tempNode);
	if (found)
	{
		if (tempNode.fd != fd)
		{
			const ConnKind preferredKind = PreferredConnectionKind(self_node.address, node.address);
			if (!ShouldReplaceExistingConnection(
			        tempNode.fd, tempNode.connKind, dataRateToOutput, preferredKind))
			{
				INFOLOG("Keep existing connection for peer:{} old_fd:{} reject_fd:{} preferred:{}",
				        node.address, tempNode.fd, fd,
				        preferredKind == PASSIV ? "passive" : "outbound");
				return -8;
			}
			if (!MagicSingleton<PeerNode>::GetInstance()->Update(node)) return -10;
			if (tempNode.fd > 0)
			{
				MagicSingleton<PeerNode>::GetInstance()->DisconnectNode(tempNode);
			}
		}
	}
	else if (!MagicSingleton<PeerNode>::GetInstance()->Add(node))
	{
		return -10;
	}
	if (!MagicSingleton<ConnectionAttemptManager>::GetInstance()->MarkRegistered(
	        roundId, attemptId, fd)) return -11;
	return 0;
}

int HandlePingReq(const std::shared_ptr<PingReq> &pingReq, const MsgData &from)
{
	Node node;
    if(!MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(from.fd, node))
    {
        WARNLOG("Invalid message peerNode_id:{}, node.address:{}, ip:{}", pingReq->id(), node.address, from.getAddrStr());
        return -1;
    }
    if(pingReq->id() != node.address)
    {
        WARNLOG("Invalid message peerNode_id:{}, node.address:{}, ip:{}", pingReq->id(), node.address, from.getAddrStr());
        return -2;
    }

	node.ResetHeart();
	MagicSingleton<PeerNode>::GetInstance()->AddOrUpdate(node);
	net_com::sendPongRequestMessage(node);
	
	return 0;

}

int handle_pong_request(const std::shared_ptr<PongReq> &pongReq, const MsgData &from)
{
	Node node;
    if(!MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(from.fd, node))
    {
		WARNLOG("Invalid message peerNode_id:{}, node.address:{}, ip:{}", pongReq->id(), node.address, from.getAddrStr());
        return -1;
    }
    if(pongReq->id() != node.address)
    {
        WARNLOG("Invalid message peerNode_id:{}, node.address:{}, ip:{}", pongReq->id(), node.address, IpPort::IpSz(from.ip));
        return -2;
    }

	node.ResetHeart();
	MagicSingleton<PeerNode>::GetInstance()->AddOrUpdate(node);
	DEBUGLOG("recv addr:{}, node.address:{}, ip:{}, pulse:{}", pongReq->id(), node.address, from.getAddrStr(), node.pulse);
	return 0;

}

int handleSyncNodeRequest(const std::shared_ptr<SyncNodeReq> &nodeSynchronizationRequestMessage, const MsgData &from)
{
	// NET-016: Use IsLanAddr to support both IPv4 and IPv6
	if(IpPort::IsLanAddr(from.getAddrStr()) == true)
	{
		WARNLOG("{} is an intranet node", from.getAddrStr());
		return -1;
	}

	DEBUGLOG("handleSyncNodeRequest from.ip:{}", from.getAddrStr());
	auto self_addr = MagicSingleton<PeerNode>::GetInstance()->GetSelfId();
	auto self_node = MagicSingleton<PeerNode>::GetInstance()->GetSelfNode();

	SyncNodeAck syncNodeAcknowledgment;
	//Get all the intranet nodes connected to you
	std::vector<Node> &&nodeList = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
	if (nodeList.size() == 0)
	{
		ERRORLOG("nodeList size is 0");
		return 0;
	}
	syncNodeAcknowledgment.set_ids(self_addr);
	syncNodeAcknowledgment.set_msg_id(nodeSynchronizationRequestMessage->msg_id());
	for (auto &node : nodeList)
	{
		if (node.fd < 0)
		{
			ERRORLOG("node fd < 0");
			continue;
		}

		NodeInfo *nodeInfo = syncNodeAcknowledgment.add_nodes();
		nodeInfo->set_addr(node.address);
		nodeInfo->set_listen_ip(node.listenIp);
		nodeInfo->set_listen_addr(node.getListenAddrStr());
		nodeInfo->set_listen_port(node.listenPort);
		nodeInfo->set_public_ip(node.publicIp);
		nodeInfo->set_public_addr(node.getPublicAddrStr());
		nodeInfo->set_node_public_addr(node.getPublicAddrStr());
		nodeInfo->set_ip_version(static_cast<uint32_t>(node.ipVersion));
		nodeInfo->set_public_port(advertisedNodePort(node));
		fillNodeInfoEndpoints(nodeInfo, node);
		nodeInfo->set_identity(node.identity);
		nodeInfo->set_height(node.height);
		nodeInfo->set_version(node.ver);
	}

	Account account;
	if(MagicSingleton<AccountManager>::GetInstance()->FindAccount(self_addr, account) != 0)
	{
		ERRORLOG("account {} doesn't exist", self_addr);
		return -2;
	}

	std::string signature;
	std::string vinHashSerialized = Getsha256Hash(syncNodeAcknowledgment.SerializeAsString());
	if(!account.Sign(vinHashSerialized, signature))
	{
		return -3;
	}

	CSign * sign = syncNodeAcknowledgment.mutable_sign();
	sign->set_sign(signature);
	sign->set_pub(account.GetPubStr());
	if (!net_com::SendMessage(from, syncNodeAcknowledgment, net_com::Compress::COMPRESS_TRUE,
	                          net_com::Encrypt::ENCRYPT_FALSE,
	                          net_com::Priority::kHighPriorityLevel2))
	{
		WARNLOG("Sync node ACK send failed peer:{} fd:{} round_id:{}",
		        nodeSynchronizationRequestMessage->ids(), from.fd,
		        nodeSynchronizationRequestMessage->msg_id());
		return -4;
	}
	return 0;
}

int handleSyncNodeAcknowledgment(const std::shared_ptr<SyncNodeAck> &syncNodeAcknowledgment, const MsgData &from)
{
	// NET-016: Use IsLanAddr to support both IPv4 and IPv6
	if(IpPort::IsLanAddr(from.getAddrStr()) == true)
	{
		WARNLOG("{} is an intranet node", from.getAddrStr());
		return -1;
	}

	DEBUGLOG("handleSyncNodeAcknowledgment from.ip:{}", from.getAddrStr());
    if(!PeerNode::verifyPeerNodeIdRequest(from.fd, syncNodeAcknowledgment->ids()))
    {
        return -2;
    }

	if (!dataMgrPtr.waitDataToAdd(syncNodeAcknowledgment->msg_id(),
	                              syncNodeAcknowledgment->ids(),
	                              syncNodeAcknowledgment->SerializeAsString()))
	{
		DEBUGLOG("Ignore late sync ACK round_id:{} peer:{} fd:{}",
		         syncNodeAcknowledgment->msg_id(), syncNodeAcknowledgment->ids(), from.fd);
	}
	return 0;
}

int HandleEchoReq(const std::shared_ptr<EchoReq> &echoReq, const MsgData &from)
{
	if(!PeerNode::verifyPeerNodeIdRequest(from.fd, echoReq->id()))
    {
        return -1;
    }
	EchoAck echoAck;
	echoAck.set_id(MagicSingleton<PeerNode>::GetInstance()->GetSelfId());
	echoAck.set_message(echoReq->message());
	net_com::SendMessage(echoReq->id(), echoAck, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::kPriorityLow0);
	return 0;
}

int handleEchoAcknowledge(const std::shared_ptr<EchoAck> &echoAck, const MsgData &from)
{
	if(!PeerNode::verifyPeerNodeIdRequest(from.fd, echoAck->id()))
    {
        return -1;
    }
	std::string echo_ack =  echoAck->message();
	if(-1 == echo_ack.find("_"))
	{
		MagicSingleton<echoTest>::GetInstance()->addEchoCatchVar(echo_ack, echoAck->id());
		return 0;
	}

	printf("echo from id:%s\tmessage:%s\n",echoAck->id().c_str(), echo_ack.c_str());
	return 0;
}

int networkTestRequest(const std::shared_ptr<TestNetReq> &testReq, const MsgData &from)
{
	if(!PeerNode::verifyPeerNodeIdRequest(from.fd, testReq->id()))
    {
        return -1;
    }
	TestNetAck testAck;
	testAck.set_data(testReq->data());
	std::string h =testReq->data();
	if(testReq->hash() == Getsha256Hash(h))
	{
		testAck.set_hash(h);
	}
	else
	{
		testAck.set_data("-1");
	}
	testAck.set_id(MagicSingleton<PeerNode>::GetInstance()->GetSelfId());
	testAck.set_time(testReq->time());
	net_com::SendMessage(testReq->id(), testAck, net_com::Compress::kCompressDisabled, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::kPriorityLow0);
	return 0;
}

int networkTestAcknowledge(const std::shared_ptr<TestNetAck> &testAck, const MsgData &from)
{
	if(!PeerNode::verifyPeerNodeIdRequest(from.fd, testAck->id()))
    {
        return -1;
    }

	auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch());
	double t = ms.count() - testAck->time();
	double speed = 20 / (t/1000);
	MagicSingleton<netTest>::GetInstance()->SetTime(speed);
	return 0;
}

int processNodeHeightChangeRequest(const std::shared_ptr<NodeHeightChangedReq>& req, const MsgData& from)
{
	DEBUGLOG("ip:{}", from.getAddrStr());
	Node node;
    if(!MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(from.fd, node))
    {
        ERRORLOG("Invalid message ip:{}", from.getAddrStr());
        return -1;
    }
    if(req->id() != node.address)
    {
        WARNLOG("Invalid message peerNode_id:{}, node.address:{}", req->id(), node.address);
        return -2;
    }

	std::string id = req->id();
	uint32 height = req->height();

	node.SetHeight(height);
	MagicSingleton<PeerNode>::GetInstance()->Update(node);
	DEBUGLOG("success update {}  to height {}", id, height);
		
	return 0;
}

int handleCheckTransactionRequest(const std::shared_ptr<CheckTxReq>& req, const MsgData& from)
{
	if (0 != Util::IsVersionCompatible(req->version()))
	{
		ERRORLOG("handleBuildBlockBroadcastMessage IsVersionCompatible");
		return -1;
	}

	if(req->isresponse() != 0 && req->isresponse() != 1)
	{
		ERRORLOG("The field is incorrect");
		return -2;
	}

	DBReader dbReader;
	std::string txRaw;

	CheckTxAck ack;
	ack.set_version(ohi::GetVersion());
	ack.set_msg_id(req->msg_id());
	for(auto & hash : req->txhash())
	{
		CorresHash * correctionHash =  ack.add_flaghash();
		correctionHash->set_hash(hash);
		if(DBStatus::DB_SUCCESS == dbReader.getTransactionByHash(hash, txRaw))
		{
			correctionHash->set_flag(1);
			if(req->isresponse())
			{
				ack.set_tx(txRaw);
			}
		}
		else
		{
			correctionHash->set_flag(0);
			ack.set_tx("");
		}
	}
	ack.set_addr(MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr());
	net_com::SendMessage(from, ack, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::kHighPriorityLevel2);

	return 0;
}

int handleCheckTransactionAck(const std::shared_ptr<CheckTxAck>& ack, const MsgData& from)
{
	if (0 != Util::IsVersionCompatible(ack->version()))
	{
		ERRORLOG("handleBuildBlockBroadcastMessage IsVersionCompatible");
		return -1;
	}
	Node node;
    if(!MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(from.fd, node))
    {
        ERRORLOG("Invalid message ");
        return -2;
    }
	dataMgrPtr.waitDataToAdd(ack->msg_id(), node.address, ack->SerializeAsString());

	return 0;
}

int handleNodeAddressChangeRequest(const std::shared_ptr<NodeAddrChangedReq>& req, const MsgData& from)
{
	INFOLOG("handleNodeAddressChangeRequest");

	const NodeSign &oldSign = req->oldsign();
	const NodeSign &newSign = req->newsign();

	std::string oldAddr = GenerateAddr(oldSign.pub());
	if(!PeerNode::verifyPeerNodeIdRequest(from.fd, oldAddr))
    {
        return -1;
    }

	Account oldAccount;
	if(MagicSingleton<AccountManager>::GetInstance()->getAccountPublicKeyByBytes(oldSign.pub(), oldAccount) == false){
		ERRORLOG(RED "Get public key from bytes failed!" RESET);
		return -2;
	}

	std::string oldSignature = oldSign.sign();
	if(oldAccount.Verify(Getsha256Hash(GenerateAddr(newSign.pub())), oldSignature) == false)
	{
		ERRORLOG(RED "Public key verify sign failed!" RESET);
		return -3;
	}

	Account newAccount;
	if(MagicSingleton<AccountManager>::GetInstance()->getAccountPublicKeyByBytes(newSign.pub(), newAccount) == false){
		ERRORLOG(RED "Get public key from bytes failed!" RESET);
		return -4;
	}

	std::string newSignature = newSign.sign();
	if(newAccount.Verify(Getsha256Hash(GenerateAddr(newSign.pub())), newSignature) == false)
	{
		ERRORLOG(RED "Public key verify sign failed!" RESET);
		return -5;
	}

	int ret = MagicSingleton<PeerNode>::GetInstance()->UpdateAddress(oldSign.pub(), newSign.pub());
	return ret;
}

void initializeCyclicTargetAddresses(const std::shared_ptr<BuildBlockBroadcastMsg>& msg, Cycliclist<std::string> & target_address_cycle_list)
{
	std::vector<std::string> targetAddresses;
	auto castAddrs = msg->castaddrs();
	if(msg->castaddrs_size() == 0)
	{
		std::cout <<" error castaddr empty" << std::endl;
	}

	for(auto & addr : castAddrs)
	{
		targetAddresses.push_back(addr);
	}
	
	std::sort(targetAddresses.begin(), targetAddresses.end());
	for(auto & addr : targetAddresses)
	{
		DEBUGLOG("initializeCyclicTargetAddresses addr : {}", addr);
		target_address_cycle_list.push_back(addr);
	}
}

void initialize_cyclic_node_list(Cycliclist<std::string>& cyclicNodeList) 
{
	std::vector<std::string> nodeListAddresses;
	std::vector<Node> nodeList = MagicSingleton<PeerNode>::GetInstance()->GetNodelist();
	
	for(auto &node : nodeList)
	{
		nodeListAddresses.push_back(node.address);
	}
	std::sort(nodeListAddresses.begin(),nodeListAddresses.end());

	for(auto & addr : nodeListAddresses)
	{
		DEBUGLOG("broadcast cyclic list addr : {}", addr);
		cyclicNodeList.push_back(addr);
	}
}

int HandleBroadcastMsg(const std::shared_ptr<BuildBlockBroadcastMsg>& msg, const MsgData& msgData)
{	
	DEBUGLOG("handleBuildBlockBroadcastMessage begin");

	//Determine if the version is compatible
	if (0 != Util::IsVersionCompatible(msg->version()))
	{
		ERRORLOG("handleBuildBlockBroadcastMessage IsVersionCompatible");
		return -1;
	}

	std::string serBlock = msg->blockraw();
	CBlock block;
   
	if (!block.ParseFromString(serBlock))
	{
		ERRORLOG("handleBuildBlockBroadcastMessage block ParseFromString failed");
		return -2;
	}

	std::vector<Cycliclist<std::string>::iterator> upperBoundary;
	std::vector<Cycliclist<std::string>::iterator> lowerBoundary;
	Cycliclist<std::string>::iterator targetIter;

	//Initialize lookup list
	auto findTargetInit=[&](const std::string & addr,Cycliclist<std::string> &clist)->bool
	{
       
		Cycliclist<std::string>::iterator targetPosition;
		//Find target location
       
		clist.filter([&](Cycliclist<std::string>::iterator iter){
			if(iter->data == addr){
				targetPosition = iter;
				targetIter = iter;
			}
			return false;
		});

        if(targetPosition==Cycliclist<std::string>::iterator(nullptr)){
           
		    
            return false;
        }
		Cycliclist<std::string>::iterator up;
		Cycliclist<std::string>::iterator down;
    
		up=targetPosition - 1;
		down=targetPosition + 1;
     
		int times = 0;
		while(times < clist.size() / 2){	
			if(up != down && up-1 != down && down+1 != up)
			{
             
				upperBoundary.push_back(up);
				lowerBoundary.push_back(down);
				up--;
				down++;
			}
			else
			{
				break;
			}
			times++;
		}
        return true;
	};

	//Find adjacent nodes up
	auto findUpperBoundIterator= [&](int times, Cycliclist<std::string> & nodeList)->std::pair<Cycliclist<std::string>::iterator,int>
	{
		std::pair<Cycliclist<std::string>::iterator,int> res;
        res.second = 0;

        try {
            if (times >= upperBoundary.size() || times >= lowerBoundary.size()) 
			{
                ERRORLOG("find times is over! "
                         "[times:{}],[upperBoundary.size:{}],[lowerBoundary.size:{}]",
                         times, upperBoundary.size(), lowerBoundary.size());
                res.second = -1033;
                return res;
            }

            Cycliclist<std::string>::iterator iter = nodeList.begin();
            if(iter == Cycliclist<std::string>::iterator(nullptr))
			{
                 res.second=-1;
                 return res;
            }
            for (; iter != nodeList.end(); iter++) {
                if(upperBoundary[times] == Cycliclist<std::string>::iterator(nullptr))
				{
                    res.second=-1;
                    return res;
                }
                if (upperBoundary[times]->data == iter->data) 
				{
                    res.first = iter;
                    res.second = 0;
                }
            }
             if(upperBoundary[times] == Cycliclist<std::string>::iterator(nullptr))
			 {      
                    res.second = -1;
                    return res;
            }
            if (upperBoundary[times]->data == iter->data) 
			{
                res.first = iter;
                res.second = 0;
            }

        } catch (std::exception &e) {
            res.second = -3;
        }
        return res;
	};

	//Find adjacent nodes down
	auto get_lower_iterator = [&](int times, Cycliclist<std::string> & nodeList)->std::pair<Cycliclist<std::string>::iterator,int>
	{
		std::pair<Cycliclist<std::string>::iterator,int> res;
        res.second = 0;

		if(times >= upperBoundary.size() || times >= lowerBoundary.size())
		{
			ERRORLOG("find times is over! [times:{}],[upperBoundary.size:{}],[lowerBoundary.size:{}]",times,upperBoundary.size(),lowerBoundary.size());
			res.second=-1033;
			return res;
		}
        try{
            Cycliclist<std::string>::iterator iter = nodeList.begin();
            if(iter == Cycliclist<std::string>::iterator(nullptr))
			{
                 res.second = -1;
                 return res;
            }
            for (; iter != nodeList.end(); iter++) {
                 if(lowerBoundary[times] == Cycliclist<std::string>::iterator(nullptr))
				 {
                    res.second = -1;
                    return res;
                 }
                if (lowerBoundary[times] -> data == iter-> data) {
                    res.first = iter;

                    res.second = 0;
                }
            }
            if(lowerBoundary[times] == Cycliclist<std::string>::iterator(nullptr))
			{       
                    res.second = -1;
                    return res;
            }
            if (lowerBoundary[times]->data == iter->data) 
			{
                res.first = iter;
                res.second = 0;
            }
        } catch (std::exception &e) {
            res.second = -3;
        }
        return res;
	};
	int findTimes = 0;
	if(msg->type() == 1)
	{
		Cycliclist<std::string> target_address_cycle_list;
		initializeCyclicTargetAddresses(msg, target_address_cycle_list);

		std::string defaultAddress = MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();
		bool isTargetFound = findTargetInit(defaultAddress, target_address_cycle_list);

        if(isTargetFound == false)
		{
            return -1;
        }

		Cycliclist<std::string> cyclicNodeList;
		initialize_cyclic_node_list(cyclicNodeList);

		msg->set_type(2);
		for(;findTimes < upperBoundary.size() && findTimes < lowerBoundary.size(); findTimes++)
		{
			auto upIter = findUpperBoundIterator(findTimes, cyclicNodeList);
            if(upIter.second != 0)
			{   
                return -1;
            }
			auto downIter = get_lower_iterator(findTimes, cyclicNodeList);
            if(downIter.second != 0)
			{
                return -1;
            }
          
			Cycliclist<std::string>::iterator startIterator = upIter.first;
			Cycliclist<std::string>::iterator endIterator = downIter.first;

			if(startIterator == Cycliclist<std::string>::iterator(nullptr) || endIterator == Cycliclist<std::string>::iterator(nullptr))
			{
				continue;
			}
			else
			{
				for(; startIterator != endIterator; startIterator++)
				{
					if(startIterator->data != defaultAddress)
					{
						MagicSingleton<TaskPool>::GetInstance()->commitBroadcastRequest(std::bind(&net_com::SendMessageTask, startIterator->data, *msg));
					}
				}
				if(startIterator->data != defaultAddress)
				{
					MagicSingleton<TaskPool>::GetInstance()->commitBroadcastRequest(std::bind(&net_com::SendMessageTask, startIterator->data, *msg));
				}
				break;
			}
		}
	}
	return 0;
}


int handleGetTxUtxoHashRequest(const std::shared_ptr<GetUtxoHashReq>& req, const MsgData& from){
	if (0 != Util::IsVersionCompatible(req->version()))
	{
		ERRORLOG("handleGetTxUtxoHashRequest IsVersionCompatible");
		return -1;
	}

	DBReader dbReader;
	std::string txRaw;

	GetUtxoHashAck ack;
	ack.set_version(ohi::GetVersion());
	ack.set_msg_id(req->msg_id());
	for(auto & hash : req->utxohash())
	{
		CorresHash * correctionHash =  ack.add_flaghash();
		correctionHash->set_hash(hash);
		if(DBStatus::DB_SUCCESS == dbReader.getTransactionByHash(hash, txRaw))
		{
			correctionHash->set_flag(1);
		}
		else
		{
			correctionHash->set_flag(0);
		}
	}

	net_com::SendMessage(from, ack, net_com::Compress::COMPRESS_TRUE, net_com::Encrypt::ENCRYPT_FALSE, net_com::Priority::kHighPriorityLevel2);

	return 0;
}

int handleGetTxUtxoHashAcknowledgment(const std::shared_ptr<GetUtxoHashAck>& ack, const MsgData& from){
	if (0 != Util::IsVersionCompatible(ack->version()))
	{
		ERRORLOG("handleGetTxUtxoHashAcknowledgment IsVersionCompatible");
		return -1;
	}
	Node node;
    if(!MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(from.fd, node))
    {
        ERRORLOG("Invalid message ");
        return -2;
    }
	dataMgrPtr.waitDataToAdd(ack->msg_id(), node.address, ack->SerializeAsString());

	return 0;

}
