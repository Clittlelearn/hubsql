﻿#ifndef _NET_VERSION_H_
#define _NET_VERSION_H_

#include <string>

namespace ohi {
    
    const std::string GetNetVersion();

}

#endif //_NET_VERSION_H_