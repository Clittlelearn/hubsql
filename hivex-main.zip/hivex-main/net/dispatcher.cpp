﻿#include "dispatcher.h"

#include <utility>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <set>
#include <chrono>
#include <mutex>

#include "./global.h"
#include "./key_exchange.h"
#include "../utils/magic_singleton.h"

#include "../common/task_pool.h"
#include "../include/logging.h"
#include "../pb/common.pb.h"
#include "../utils/compress.h"
#include "../utils/sha256.h"
#include "net/net_version.h"
#include "metrics.h"
#include "net_error.h"

int ProtobufDispatcher::Handle(const MsgData &data)
{
    CommonMsg commonMsg;
    int ret = commonMsg.ParseFromString(data.pack.data);
    if (!ret)
    {
        ERRORLOG("parse CommonMsg error");
        return static_cast<int>(NetError::ParseCommonMsgFailed);
    }

    std::string type = commonMsg.type();
    
    // FEAT-001: Update message receive metrics
    NetworkMetrics::Instance().messages_received++;
    NetworkMetrics::Instance().bytes_received += data.pack.data.size();
    NetworkMetrics::Instance().incrementMessageType(type);
    
    {
        std::lock_guard<std::mutex> lock(global::mutexRequestCountMap);
        global::requestCountMap[type].first += 1;
        global::requestCountMap[type].second += commonMsg.data().size();
        
        // BUG-002 fix: Periodically clean up requestCountMap to prevent unbounded growth
        // Clean up every 10000 messages
        static uint64_t cleanupCounter = 0;
        if (++cleanupCounter % 10000 == 0) {
            // Remove entries with zero count (shouldn't happen, but safety check)
            for (auto it = global::requestCountMap.begin(); it != global::requestCountMap.end(); ) {
                if (it->second.first == 0) {
                    it = global::requestCountMap.erase(it);
                } else {
                    ++it;
                }
            }
            // If still too large, reset all counters to prevent unbounded growth
            if (global::requestCountMap.size() > 1000) {
                for (auto& pair : global::requestCountMap) {
                    pair.second.first = 0;
                    pair.second.second = 0;
                }
                INFOLOG("NET: requestCountMap reset due to size ({} entries)", global::requestCountMap.size());
            }
        }
    }
    
    // NET-013: Semantic version compatibility check
    // Allow communication between nodes with same major version
    {
        std::string localVersion = ohi::GetNetVersion();
        std::string remoteVersion = commonMsg.version();
        
        // Extract major version (before first '.')
        auto extractMajor = [](const std::string& v) -> std::string {
            size_t dotPos = v.find('.');
            return (dotPos != std::string::npos) ? v.substr(0, dotPos) : v;
        };
        
        std::string localMajor = extractMajor(localVersion);
        std::string remoteMajor = extractMajor(remoteVersion);
        
        if (localMajor != remoteMajor) {
            ERRORLOG("Incompatible version: local={}, remote={}", localVersion, remoteVersion);
            return static_cast<int>(NetError::VersionIncompatible);
        }
        
        if (localVersion != remoteVersion) {
            DEBUGLOG("Compatible version mismatch: local={}, remote={}", localVersion, remoteVersion);
        }
    }

    // NET-003: Per-peer rate limiting check
    {
        Node node;
        if (MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(data.fd, node))
        {
            auto now = std::chrono::steady_clock::now();
            auto& stats = node.peer_stats;
            
            // Check if node is banned
            if (stats.rate_limited)
            {
                DEBUGLOG("Node {} is rate-limited, dropping message", node.address);
                return static_cast<int>(NetError::RateLimited);
            }
            
            // Refill tokens and check
            stats.refillTokens(now);
            if (!stats.consumeToken())
            {
                WARNLOG("Node {} exceeds rate limit", node.address);
                stats.rate_limited = true;
                stats.rate_limit_violations++;
                
                if (stats.rate_limit_violations >= kRateLimitBanThreshold)
                {
                    ERRORLOG("Node {} exceeded rate limit {} times, disconnecting",
                             node.address, stats.rate_limit_violations);
                    MagicSingleton<PeerNode>::GetInstance()->DisconnectNode(node);
                }
                return static_cast<int>(NetError::RateLimitExceeded);
            }
            
            // Update statistics
            stats.messages_received++;
            stats.bytes_received += data.pack.data.size();
            stats.last_seen = now;
            
            // Update the node in PeerNode
            MagicSingleton<PeerNode>::GetInstance()->Update(node);
        }
    }

    if (type.size() == 0)
    {
        ERRORLOG("handle type is empty");
        return static_cast<int>(NetError::MessageTypeEmpty);
    }

    const Descriptor *des = google::protobuf::DescriptorPool::generated_pool()->FindMessageTypeByName(type);
    if (!des)
    {
        ERRORLOG("cannot create Descriptor for {}", type.c_str());
        return static_cast<int>(NetError::DescriptorNotFound);
    }

    const Message *proto = google::protobuf::MessageFactory::generated_factory()->GetPrototype(des);
    if (!proto)
    {
        ERRORLOG("cannot create Message for {}", type.c_str());
        return static_cast<int>(NetError::MessagePrototypeFailed);
    }

    std::string subSerializedMessage;
    if (commonMsg.compress())
    {
        Compress uncpr(std::move(commonMsg.data()), commonMsg.data().size() * 10);
        subSerializedMessage = uncpr._rawData;
    }
    else
    {
        subSerializedMessage = std::move(commonMsg.data());
    }
      std::string str_plaintext;
    if(type != "KeyExchangeRequest" && type != "KeyExchangeResponse")
    {
        Ciphertext ciphertext;
        if(!ciphertext.ParseFromString(subSerializedMessage))
        {
            WARNLOG("ParseFromString Ciphertext fail!!!");
            return static_cast<int>(NetError::CiphertextParseFailed);
        }
        if ((ciphertext.aes_iv_12bytes().size() != CRYPTO_AES_IV_LEN)
                || (ciphertext.aes_tag_16bytes().size() != AES_TAG_LENGTH))
            {
                ERRORLOG("the length of aes iv or tag does not match.");
                return static_cast<int>(NetError::AesIvTagLengthMismatch);
            }

            auto key = MagicSingleton<KeyExchangeManager>::GetInstance()->getKey(data.fd);
            if(key == nullptr)
            {
                ERRORLOG("null key");
                return static_cast<int>(NetError::KeyNotFound);
            }

            if (!verify_token(key->peer_key.ec_pub_key, ciphertext.token()))
            {
                ERRORLOG("token check failed.");
                return static_cast<int>(NetError::TokenVerifyFailed);
            }

            if (!decrypt_ciphertext(key->peer_key, ciphertext, str_plaintext))
            {
                ERRORLOG("aes decryption error.");
                return static_cast<int>(NetError::AesDecryptFailed);
            }
    }
    else
    {
        str_plaintext = std::move(subSerializedMessage);
    }
    
    MessagePtr subMsg(proto->New());
    ret = subMsg->ParseFromString(str_plaintext);
    if (!ret)
    {
        ERRORLOG("bad msg for protobuf for {}", type.c_str());
        // NET-011: Update reputation on invalid message
        Node node;
        if (MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(data.fd, node)) {
            node.peer_stats.messages_invalid++;
            node.peer_stats.compliance_score *= 0.95;  // Penalty
            node.peer_stats.recalculateScore();
            MagicSingleton<PeerNode>::GetInstance()->Update(node);
        }
        return static_cast<int>(NetError::MessageParseFailed);
    }

    // NET-011: Update reputation on valid message
    {
        Node node;
        if (MagicSingleton<PeerNode>::GetInstance()->locateNodeByFd(data.fd, node)) {
            node.peer_stats.messages_valid++;
            node.peer_stats.recalculateScore();
            MagicSingleton<PeerNode>::GetInstance()->Update(node);
        }
    }

    // NET-007: Message deduplication check (after decryption)
    // Only deduplicate specific message types that may arrive via multiple paths
    // Skip dedup for: broadcast messages, key exchange, heartbeat, registration, etc.
    {
        // White list: message types that need deduplication
        static const std::set<std::string> dedupTypes = {
            "BuildBlockBroadcastMsg",  // Block broadcast (may arrive via multiple paths)
            "TxMsgReq",                // Transaction broadcast
            "ContractTxMsgReq",        // Contract transaction broadcast
            "FastSyncGetBlockAck",     // Sync block response
            "SyncGetBlockAck",         // Sync block response
            "SyncFromZeroGetBlockAck"  // Sync from zero response
        };
        
        if (dedupTypes.find(type) != dedupTypes.end()) {
            static std::unordered_map<std::string, std::chrono::steady_clock::time_point> dedupCache;
            static std::mutex dedupMutex;
            
            // Include pub/sign in fingerprint to distinguish different senders
            std::string fingerprint = Getsha256Hash(type + str_plaintext + commonMsg.pub() + commonMsg.sign());
            auto now = std::chrono::steady_clock::now();
            
            std::lock_guard<std::mutex> lock(dedupMutex);
            
            // Check if fingerprint exists and is not expired
            auto it = dedupCache.find(fingerprint);
            if (it != dedupCache.end()) {
                if (now - it->second < std::chrono::seconds(kDedupExpireSeconds)) {
                    DEBUGLOG("NET-007: Duplicate message dropped, type={}", type);
                    return 0;  // Duplicate message, silently drop
                }
                // Expired, remove old entry
                dedupCache.erase(it);
            }
            
            // Record new fingerprint
            dedupCache[fingerprint] = now;
            
            // If cache exceeds size limit, remove oldest entries
            if (dedupCache.size() > kDedupCacheSize) {
                // Simple cleanup: remove expired entries
                for (auto it = dedupCache.begin(); it != dedupCache.end(); ) {
                    if (now - it->second >= std::chrono::seconds(kDedupExpireSeconds)) {
                        it = dedupCache.erase(it);
                    } else {
                        ++it;
                    }
                }
            }
        }
    }

    auto taskPool = MagicSingleton<TaskPool>::GetInstance();
    std::string name = subMsg->GetDescriptor()->name();

    auto blockMap = blockProtocolCallbacks.find(name);
    if (blockMap != blockProtocolCallbacks.end())
    {
        taskPool->commit_block_task(blockMap->second, subMsg, data);
        return 0;
    }

    auto saveBlockmap = saveBlockProtocolCallbacks.find(name);
    if (saveBlockmap != saveBlockProtocolCallbacks.end())
    {
        taskPool->CommitSaveBlockJob(saveBlockmap->second, subMsg, data);
    }

    auto broadcastMap= broadcastProtocol.find(name);
    if (broadcastMap != broadcastProtocol.end())
    {
        taskPool->commitBroadcastRequest(broadcastMap->second, subMsg, data);
        return 0;
    }

    auto caMap = chainProtocolCallbacks.find(name);
    if (caMap != chainProtocolCallbacks.end())
    {
        taskPool->commitCaTask(caMap->second, subMsg, data);
        return 0;
    }

    auto netMap = netProtocolCallbacks.find(name);
    if (netMap != netProtocolCallbacks.end())
    {
        taskPool->CommitNetworkTask(netMap->second, subMsg, data);
        return 0;
    }
    auto txMap = txProtocolCallbacks.find(name);
    if (txMap != txProtocolCallbacks.end())
    {
        taskPool->CommitTransactionTask(txMap->second, subMsg, data);
        return 0;
    }
    auto syncBlockMapping = syncBlockProtocolCallbacks.find(name);
    if (syncBlockMapping != syncBlockProtocolCallbacks.end())
    {
        taskPool->CommitSyncBlockJob(syncBlockMapping->second, subMsg, data);
        return 0;
    }

    return -12;
}

void ProtobufDispatcher::TaskInfo(std::ostringstream& oss)
{
    auto taskPool = MagicSingleton<TaskPool>::GetInstance();
    oss << "ca_active_task:" << taskPool->CaActive() << std::endl;
    oss << "ca_pending_task:" << taskPool->CaPending() << std::endl;
    oss << "==================================" << std::endl;
    oss << "net_active_task:" << taskPool->NetActive() << std::endl;
    oss << "net_pending_task:" << taskPool->NetPending() << std::endl;
    oss << "==================================" << std::endl;
    oss << "broadcast_active_task:" << taskPool->BroadcastActive() << std::endl;
    oss << "broadcast_pending_task:" << taskPool->BroadcastPending() << std::endl;
    oss << "==================================" << std::endl;
    oss << "tx_active_task:" << taskPool->TxActive() << std::endl;
    oss << "tx_pending_task:" << taskPool->TxPending() << std::endl;
    oss << "==================================" << std::endl;
    oss << "syncBlock_active_task:" << taskPool->syncBlockActive() << std::endl;
    oss << "syncBlock_pending_task:" << taskPool->syncBlockPending() << std::endl;
    oss << "==================================" << std::endl;
    oss << "saveBlock_active_task:" << taskPool->isSaveBlockActive() << std::endl;
    oss << "saveBlock_pending_task:" << taskPool->saveBlockPending() << std::endl;
    oss << "==================================" << std::endl;
    oss << "block_active_task:" << taskPool->BlockActive() << std::endl;
    oss << "block_pending_task:" << taskPool->BlockPending() << std::endl;
    oss << "==================================" << std::endl;
    oss << "work_active_task:" << taskPool->WorkActive() << std::endl;
    oss << "work_pending_task:" << taskPool->WorkPending() << std::endl;
    oss << "==================================" << std::endl;

}
