/**
 * *****************************************************************************
 * @file        ca_interface.cpp
 * @brief       Implementation of CA interface registry (NET-017)
 * @date        2026-06-25
 * @copyright   mm
 * *****************************************************************************
 */
#include "ca_interface.h"

std::shared_ptr<INetworkCAInterface> NetworkCAInterfaceRegistry::instance_ = nullptr;

void NetworkCAInterfaceRegistry::Register(std::shared_ptr<INetworkCAInterface> impl) {
    instance_ = impl;
}

std::shared_ptr<INetworkCAInterface> NetworkCAInterfaceRegistry::Get() {
    return instance_;
}
