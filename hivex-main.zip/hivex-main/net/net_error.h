/**
 * *****************************************************************************
 * @file        net_error.h
 * @brief       Network error code definitions (QUAL-002)
 *              Unified error codes for network layer operations
 * @date        2026-06-25
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef NET_ERROR_H
#define NET_ERROR_H

enum class NetError : int {
    // Success
    Success = 0,
    
    // Protocol parsing errors (-1 ~ -19)
    ParseCommonMsgFailed = -1,        // CommonMsg deserialization failed
    VersionIncompatible = -2,         // Version incompatible (major version mismatch)
    MessageTypeEmpty = -3,            // Message type field is empty
    DescriptorNotFound = -4,          // Protobuf Descriptor not found in pool
    MessagePrototypeFailed = -5,      // Failed to create Message prototype
    CiphertextParseFailed = -6,       // Ciphertext deserialization failed
    AesIvTagLengthMismatch = -7,      // AES IV or Tag length mismatch
    KeyNotFound = -8,                 // ECDH key not found for this fd
    TokenVerifyFailed = -9,           // Token verification failed
    AesDecryptFailed = -10,           // AES decryption failed
    MessageParseFailed = -11,         // Final message deserialization failed
    CallbackNotFound = -12,           // No callback registered for this message type
    
    // Rate limiting errors (-20 ~ -29)
    RateLimited = -20,                // Node is rate-limited, message dropped
    RateLimitExceeded = -21,          // Node exceeded rate limit, penalty applied
    
    // Message deduplication (0 means success but message was duplicate)
    DuplicateMessage = 0,             // Duplicate message (silently dropped)
};

// Convert error code to string (for logging)
inline const char* NetErrorToString(NetError err) {
    switch (err) {
        case NetError::Success: return "Success/DuplicateMessage";
        case NetError::ParseCommonMsgFailed: return "ParseCommonMsgFailed";
        case NetError::VersionIncompatible: return "VersionIncompatible";
        case NetError::MessageTypeEmpty: return "MessageTypeEmpty";
        case NetError::DescriptorNotFound: return "DescriptorNotFound";
        case NetError::MessagePrototypeFailed: return "MessagePrototypeFailed";
        case NetError::CiphertextParseFailed: return "CiphertextParseFailed";
        case NetError::AesIvTagLengthMismatch: return "AesIvTagLengthMismatch";
        case NetError::KeyNotFound: return "KeyNotFound";
        case NetError::TokenVerifyFailed: return "TokenVerifyFailed";
        case NetError::AesDecryptFailed: return "AesDecryptFailed";
        case NetError::MessageParseFailed: return "MessageParseFailed";
        case NetError::CallbackNotFound: return "CallbackNotFound";
        case NetError::RateLimited: return "RateLimited";
        case NetError::RateLimitExceeded: return "RateLimitExceeded";
        default: return "Unknown";
    }
}

#endif // NET_ERROR_H
