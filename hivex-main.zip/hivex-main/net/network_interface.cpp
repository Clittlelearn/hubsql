/**
 * *****************************************************************************
 * @file        network_interface.cpp
 * @brief       Network layer interface registry implementation (NET-018)
 * @date        2026-06-25
 * @copyright   mm
 * *****************************************************************************
 */
#include "network_interface.h"

std::shared_ptr<INetworkLayer> NetworkLayerRegistry::instance_ = nullptr;

void NetworkLayerRegistry::Register(std::shared_ptr<INetworkLayer> impl) {
    instance_ = impl;
}

std::shared_ptr<INetworkLayer> NetworkLayerRegistry::Get() {
    return instance_;
}
