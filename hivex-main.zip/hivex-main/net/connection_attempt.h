#ifndef OPENHIVE_NET_CONNECTION_ATTEMPT_H
#define OPENHIVE_NET_CONNECTION_ATTEMPT_H

#include <chrono>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include "node.hpp"

enum class ConnectionAttemptState
{
    Created,
    Connecting,
    TcpConnected,
    KeyExchanging,
    KeyEstablished,
    RegisterSent,
    Registered,
    Closing,
    Closed
};

struct ConnectionAttempt
{
    std::string roundId;
    std::string attemptId;
    std::string groupKey;
    ConnectionAttemptState state{ConnectionAttemptState::Created};
    int fd{-1};
    Node originalNode;
    std::string closeReason;
    std::chrono::steady_clock::time_point closedAt{};
};

class ConnectionAttemptManager
{
public:
    bool CreateOutbound(const std::string& roundId, const std::string& attemptId,
                        const std::string& groupKey, const Node& originalNode);
    bool CreateInbound(const std::string& attemptId, int fd);
    bool Transition(const std::string& attemptId, ConnectionAttemptState expected,
                    ConnectionAttemptState next);
    bool SetConnectedFd(const std::string& attemptId, int fd);
    bool MarkRegisterSent(const std::string& attemptId);
    bool ValidateStateFd(const std::string& attemptId, ConnectionAttemptState state, int fd) const;
    bool ValidatePendingAck(const std::string& roundId, const std::string& attemptId,
                            int fd) const;
    bool MarkRegistered(const std::string& roundId, const std::string& attemptId, int fd);
    bool CloseAttempt(const std::string& attemptId, const std::string& reason);
    void ReleaseFd(int fd, const std::string& reason);
    void ClosePendingRound(const std::string& roundId, const std::string& reason);
    bool HasActiveGroup(const std::string& groupKey) const;
    bool Get(const std::string& attemptId, ConnectionAttempt& attempt) const;

private:
    static bool IsTerminal(ConnectionAttemptState state);
    void PurgeClosedLocked();
    void CleanupFd(int fd);

    mutable std::mutex mutex_;
    std::unordered_map<std::string, ConnectionAttempt> attempts_;
    std::unordered_map<int, std::string> fdToAttempt_;
    std::unordered_map<std::string, std::string> groupToAttempt_;
};

std::string ConnectionAttemptStateName(ConnectionAttemptState state);
std::string BootstrapEndpointGroupKey(const Node& node);

#endif
