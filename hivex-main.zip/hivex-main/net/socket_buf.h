﻿/**
 * *****************************************************************************
 * @file        socket_buf.h
 * @brief       
 * @author  ()
 * @date        2023-09-27
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef SOCKET_BUFFER_HEADER_GUARD
#define SOCKET_BUFFER_HEADER_GUARD

#include <string>
#include <queue>
#include <utility>
#include <map>
#include <unordered_map>
#include <mutex>
#include <memory>

#include "./msg_queue.h"
#include "./api.h"

#include "../include/logging.h"



extern std::unordered_map<int, std::shared_ptr<std::mutex>> fileDescriptorSetMutex;

/**
 * @brief       Get the fd mutex object
 * 
 * @param       fd 
 * @return      std::shared_ptr<std::mutex>
 */
std::shared_ptr<std::mutex> fdMutex(int fd);

/**
 * @brief       Remove the fd mutex object (call when fd is closed)
 *
 * @param       fd
 */
void removeFdMutex(int fd);

/**
 * @brief       Get the Mutex Size object
 *
 * @return      int
 */
int mutex_size();


// Message length is the first 4 bytes of the message and does not contain these 4 bytes 
class SocketBuf
{
public:
    int fd;
    uint64_t portAndIp;
    std::string addr;
    uint16_t port;

private:
    std::string _cache;
	std::mutex mutexForRead;

    std::string _sendCache;
    std::mutex sendMutex;
	std::atomic<bool> _isSending;
	
	// NET-010: Write timeout tracking
	std::chrono::steady_clock::time_point _lastWriteSuccess;
	bool _backpressureActive = false;

private:
    /**
     * @brief       
     * 
     * @param       sendData 
     * @return      true 
     * @return      false 
     */
    bool sendPacketToMessageQueue(const std::string& sendData);

public:
	SocketBuf() 
    : fd(0)
    , portAndIp(0)
    , port(0)
    , _isSending(false) 
    {};

    /**
     * @brief       
     * 
     * @param       data 
     * @param       len 
     * @return      true 
     * @return      false 
     */
    bool add_data_to_read_buffer(char *data, size_t len);

    /**
     * @brief       
     * 
     */
    void printfCache();

    /**
     * @brief       Get the Send Msg object
     * 
     * @return      std::string 
     */
    std::string GetSendMsg();

    /**
     * @brief       
     * 
     * @param       n 
     */
    void popAndSendMessageRequest(int n);

    /**
     * @brief       
     * 
     * @param       data 
     */
    bool PushSendMsg(const std::string& data);

    /**
     * @brief       
     * 
     * @return      true 
     * @return      false 
     */
    bool isSendCacheEmpty();

    /**
     * @brief       
     * 
     * @param       current_message_length 
     */

    /**
     * @brief       Verify the buffer and fix if there are errors

     * 
     * @param       current_message_length 
     */
    void VerifyCache(size_t current_message_length);      

    /**
     * @brief       Fix buffers
     * 
     */
    void CorrectCache();                      
};


class bufferControl
{
public:
    bufferControl() = default;
    ~bufferControl() = default;

    // NET-016: Helper to create address key from IP string and port
    static std::string makeAddrKey(const std::string& addr, uint16_t port) {
        return addr + ":" + std::to_string(port);
    }

private:
    friend std::string PrintCache(int where);
	std::mutex _mutex;

    // NET-016: New map using string key (supports IPv4 and IPv6)
    std::map<std::string, std::shared_ptr<SocketBuf>> _BufferMapByAddr;

    // Legacy map using uint64_t key (IPv4 only, for backward compatibility)
    std::map<uint64_t, std::shared_ptr<SocketBuf>> _BufferMap;

public:

    // === NET-016: New IPv4/IPv6 dual-stack interfaces ===

    bool addReadBufferToQueue(const std::string& addr, uint16_t port, char* buf, socklen_t len);
    bool AddBuffer(const std::string& addr, uint16_t port, const int fd);
    bool DeleteBuffer(const std::string& addr, uint16_t port);
    std::string writeBufferQueue(const std::string& addr, uint16_t port);
    void PopAndWriteBufferQueue(const std::string& addr, uint16_t port, int n);
    bool addWritePack_(const std::string& addr, uint16_t port, const std::string ios_msg);
    bool IsExists(const std::string& addr, uint16_t port);
    std::shared_ptr<SocketBuf> GetSocketBuf(const std::string& addr, uint16_t port);
    bool IsCacheEmpty(const std::string& addr, uint16_t port);

    // === Legacy IPv4-only interfaces (backward compatibility) ===

    /**
     * @brief
     *
     * @param       ip
     * @param       port
     * @param       buf
     * @param       len
     * @return      true
     * @return      false
     */
    bool addReadBufferToQueue(uint32_t ip, uint16_t port, char* buf, socklen_t len);

    /**
     * @brief       
     * 
     * @param       portAndIp 
     * @param       buf 
     * @param       len 
     * @return      true 
     * @return      false 
     */
    bool addReadBufferToQueue(uint64_t portAndIp, char* buf, socklen_t len);

    /**
     * @brief       
     * 
     * @param       ip 
     * @param       port 
     * @param       fd 
     * @return      true 
     * @return      false 
     */
    bool AddBuffer(uint32_t ip, uint16_t port,const int fd);

    /**
     * @brief       
     * 
     * @param       portAndIp 
     * @param       fd 
     * @return      true 
     * @return      false 
     */
    bool AddBuffer(uint64_t portAndIp,const int fd);

    /**
     * @brief       
     * 
     * @param       ip 
     * @param       port 
     * @return      true 
     * @return      false 
     */
    bool DeleteBuffer(uint32_t ip, uint16_t port);

    /**
     * @brief       
     * 
     * @param       portAndIp 
     * @return      true 
     * @return      false 
     */
    bool DeleteBuffer(uint64_t portAndIp);

    /**
     * @brief       
     * 
     * @param       fd 
     * @return      true 
     * @return      false 
     */
    bool DeleteBuffer(const int fd);

    /**
     * @brief       Get the Write Buffer Queue object
     * 
     * @param       portAndIp 
     * @return      std::string 
     */
    std::string writeBufferQueue(uint64_t portAndIp);

    /**
     * @brief       
     * 
     * @param       portAndIp 
     * @param       n 
     */
    void PopAndWriteBufferQueue(uint64_t portAndIp, int n);
	
    /**
     * @brief       
     * 
     * @param       portAndIp 
     * @param       ios_msg 
     * @return      true 
     * @return      false 
     */
    bool addWritePack_(uint64_t portAndIp, const std::string ios_msg);

    /**
     * @brief       
     * 
     * @param       ip 
     * @param       port 
     * @param       ios_msg 
     * @return      true 
     * @return      false 
     */
	bool addWritePack_(uint32_t ip, uint16_t port, const std::string ios_msg);

    /**
     * @brief       
     * 
     * @param       portAndIp 
     * @return      true 
     * @return      false 
     */
    bool IsExists(uint64_t portAndIp);

    /**
     * @brief       
     * 
     * @param       ip 
     * @param       port 
     * @return      true 
     * @return      false 
     */

    /**
     * @brief       
     * 
     * @param       ip 
     * @param       port 
     * @return      true 
     * @return      false 
     */
	bool IsExists(uint32_t ip, uint16_t port);

    /**
     * @brief       Get the Socket Buf object
     * 
     * @param       ip 
     * @param       port 
     * @return      std::shared_ptr<SocketBuf> 
     */
    std::shared_ptr<SocketBuf> GetSocketBuf(uint32_t ip, uint16_t port);
    
    /**
     * @brief       
     * 
     * @param       ip 
     * @param       port 
     * @return      true 
     * @return      false 
     */
    bool IsCacheEmpty(uint32_t ip, uint16_t port);

   
    /**
     * @brief       *test api*
     *
     */
    void printBuffers();

    // NET-016: Find SocketBuf by fd (searches both maps)
    std::shared_ptr<SocketBuf> GetSocketBufByFd(int fd);
};


#endif
