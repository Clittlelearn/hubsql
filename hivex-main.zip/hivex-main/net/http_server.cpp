
#include "http_server.h"

#include <unistd.h>
#include <fstream>
#include <functional>
#include "rpc/eth/eth.h"
#include "../common/config.h"
#include "../utils/magic_singleton.h"
#include "../../include/logging.h"
#include "metrics.h"

// CORS包装函数实现
HttpCallBack cors_wrapper(HttpCallBack handler) {
    return [handler](const Request &req, Response &res) {
        // 允许所有来源
        res.set_header("Access-Control-Allow-Origin", "*");
        // 允许的HTTP方法
        res.set_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        // 允许的请求头
        res.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");
        // 允许浏览器缓存预检请求结果的时间（秒）
        res.set_header("Access-Control-Max-Age", "86400");
        // 允许带凭据的跨域请求
        res.set_header("Access-Control-Allow-Credentials", "true");
        
        // 调用原始处理函数
        handler(req, res);
    };
}


std::thread HttpServer::_listenThread;
std::map<const std::string, HttpCallBack> HttpServer::_cbs;
std::map<const std::string, JsonRpcCallBack> HttpServer::rpcCbs;
std::map<std::string,HttpServer::ETH_RPC_FUNCTION> HttpServer::eth_rpc_callbacks;
void HttpServer::Work()
{
  using namespace httplib;

  Server svr;

  // 设置服务器超时配置，解决eth_blockNumber等接口超时问题
  svr.set_read_timeout(30, 0);  // 读取超时30秒
  svr.set_write_timeout(30, 0); // 写入超时30秒
  svr.set_payload_max_length(10 * 1024 * 1024); // 请求体最大10MB，防止OOM攻击
  
  // NET-005: Set request body size limit (1MB)
  svr.set_payload_max_length(1024 * 1024);
  
  if (MagicSingleton<Config>::GetInstance()->GetEnableHttps())
  {
    std::thread([](){
      using namespace httplib;
      auto cfg = MagicSingleton<Config>::GetInstance();
      std::string cert = cfg->GetSslCertPath();
      std::string key  = cfg->GetSslKeyPath();
      if (cert.empty() || key.empty())
      {
        std::cerr << "HTTPS enabled but ssl_cert_path or ssl_key_path is empty" << std::endl;
        return;
      }

      const bool enable_mtls = cfg->GetEnableMtls();
      const std::string ca_bundle = cfg->GetSslCaBundle();

      std::cerr << "HTTPS init: cert='" << cert << "' key='" << key << "'";
      if (enable_mtls)
      {
        std::cerr << " mtls=true ca_bundle='" << ca_bundle << "'";
      }
      std::cerr << std::endl;

      SSLServer ssl_svr(cert.c_str(), key.c_str(),
                        (enable_mtls && !ca_bundle.empty()) ? ca_bundle.c_str() : nullptr,
                        nullptr);
      
      // 设置HTTPS服务器超时配置
      ssl_svr.set_read_timeout(30, 0);  // 读取超时30秒
      ssl_svr.set_write_timeout(30, 0); // 写入超时30秒
      ssl_svr.set_payload_max_length(10 * 1024 * 1024); // 请求体最大10MB，防止OOM攻击
      
      if (!ssl_svr.is_valid())
      {
        std::cerr << "Failed to initialize SSLServer (check cert/key format, permissions, and OpenSSL)" << std::endl;
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
        ERR_print_errors_fp(stderr);
#endif
        return;
      }

      for(auto item: _cbs)
      {
        auto cors_handler = cors_wrapper(item.second);
        ssl_svr.Get(item.first.c_str(), cors_handler);
        ssl_svr.Post(item.first.c_str(), cors_handler);

        ssl_svr.Options(item.first.c_str(), [](const Request &req, Response &res) {
        // 允许所有来源
        res.set_header("Access-Control-Allow-Origin", "*");
        // 允许的HTTP方法
        res.set_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        // 允许的请求头
        res.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");
        // 允许浏览器缓存预检请求结果的时间（秒）
        res.set_header("Access-Control-Max-Age", "86400");
        // 允许带凭据的跨域请求
        res.set_header("Access-Control-Allow-Credentials", "true");
        res.status = 200;
    });
      }
      int https_port = cfg->GetHttpsPort();
      ssl_svr.listen("0.0.0.0", https_port);
    }).detach();
  }

  for(auto item: _cbs)
  {
    // 为每个回调添加CORS支持
    auto cors_handler = cors_wrapper(item.second);
    svr.Get(item.first.c_str(), cors_handler);
    svr.Post(item.first.c_str(), cors_handler);
    // 添加OPTIONS方法支持
    svr.Options(item.first.c_str(), [](const Request &req, Response &res) {
        // 允许所有来源
        res.set_header("Access-Control-Allow-Origin", "*");
        // 允许的HTTP方法
        res.set_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        // 允许的请求头
        res.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");
        // 允许浏览器缓存预检请求结果的时间（秒）
        res.set_header("Access-Control-Max-Age", "86400");
        // 允许带凭据的跨域请求
        res.set_header("Access-Control-Allow-Credentials", "true");
        res.status = 200;
    });
  }

  // 为404错误添加CORS支持
  svr.set_error_handler([](const Request &req, Response &res) {
      // 添加CORS头
      res.set_header("Access-Control-Allow-Origin", "*");
      res.set_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
      res.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");
      res.set_header("Access-Control-Max-Age", "86400");
      res.set_header("Access-Control-Allow-Credentials", "true");
      res.set_content("404 Not Found", "text/plain");
  });

  int port = 8080;
  port = MagicSingleton<Config>::GetInstance()->GetHttpPort();
  svr.listen("0.0.0.0", port);
}


void HttpServer::Start()
{
    RegisterAllCallback();
    _listenThread = std::thread(HttpServer::Work);
    _listenThread.detach();	
}




bool verifDebug(const nlohmann::json &jsona){
    const std::vector<std::string> apis={
        "eth_sendRawTransaction",
        "eth_getTransactionReceipt",
        "eth_getBlockByHash",
        "eth_getTransactionByHash",
        "eth_call"
    };

    std::string a=jsona["method"];
    for(auto &api:apis){
        if(a==api){
            return true;
        }
    }
    return true;
}


void eth_dispatch(const Request &req, Response &res){
    eth_res_header res_header;
    eth_errors err;

    eth_req_header req_header;
    nlohmann::json req_json;
    nlohmann::json res_json;


    try {
        req_json=nlohmann::json::parse(req.body);
    }catch(std::exception& e) {
        err.ok=false;
        err.code=-32603;
        err.message=e.what();
        auto ret= res_header.make_result(req_json,err);
        res.set_content(ret.dump(), "application/json");
        return ;
    }

    

     auto lamda=[&](nlohmann::json &json_p)->std::string{
        std::string obj=json_p.dump();

        bool is_debug=  verifDebug(json_p);
        if(is_debug){
           std::cout <<std::endl << json_p.dump(4) << std::endl;
        }

       

        nlohmann::json params;
        auto st= req_header.parse(json_p);
        if (!st.ok) {
            err.ok=false;
            err.code=-32603;
            err.message=st.error.value();
            auto ret= res_header.make_result(json_p,err);
            //res.set_content(ret.dump(), "application/json");
            return ret.dump();
        }



        bool is_params=json_p.contains("params");
        if(is_params==false) {
            err.ok=false;
            err.code=-32603;
            err.message="not found params!";
            auto ret= res_header.make_result(json_p,err);
            return ret.dump();
        }

        params=json_p["params"];
        bool params_is_array=params.is_array();
        if(params_is_array==false) {
            err.ok=false;
            err.code=-32603;
            err.message="params is not array!";
            auto ret= res_header.make_result(json_p,err);
            return ret.dump();
        }

        //std::cout << "=========== >:" << req_header.method<<std::endl;
        auto rpc_func=HttpServer::eth_rpc_callbacks.find(req_header.method);
        if (rpc_func!=HttpServer::eth_rpc_callbacks.end()) {
            auto callback=rpc_func->second;
            res_json=callback(json_p);
        }
        if(is_debug){
           std::cout <<std::endl << res_json.dump(4) << std::endl;
        }
        std::string str=res_json.dump();
        return str;
    };


    if (req_json.is_array()) {
        std::stringstream ss;
        ss << "[";
        int index=0;
        for (auto & p:req_json) {
            if (index!=0) {
                ss << ",";
            }
            index++;
           ss<< lamda(p);
        }
        ss << "]";
        std::cout << ss.str() <<std::endl;
        res.set_content(ss.str(), "application/json");
        return;
    }



    auto r= lamda(req_json);
    // std::cout << r <<std::endl;
    INFOLOG("HTTP RPC request processed");
    res.set_content(r, "application/json");
}

void HttpServer::RegisterAllCallback()
{
  	RegisterCallback("/hello",ApiHello);
    RegisterCallback("/",eth_dispatch);
    
    // NET-019: Prometheus metrics endpoint
    RegisterCallback("/metrics", [](const Request &req, Response &res) {
        res.set_content(NetworkMetrics::Instance().exportPrometheus(), "text/plain; version=0.0.4");
    });
}




void ApiHello(const Request & req, Response & res)
{
  res.set_content("Hello World!!!", "text/plain");
}














