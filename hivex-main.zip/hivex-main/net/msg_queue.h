/**
 * *****************************************************************************
 * @file        msg_queue.h
 * @brief       
 * @author  ()
 * @date        2023-09-26
 * @copyright   mm
 * *****************************************************************************
 */
#ifndef _MSG_QUEUE_H_
#define _MSG_QUEUE_H_

#include <memory>
#include <queue>
#include <string>
#include <utility>
#include <condition_variable>
#include <arpa/inet.h>

#include "./ip_port.h"
#include "./peer_node.h"

#include "../include/logging.h"
#include "metrics.h"

enum DataType
{
    E_READ,
    E_WORK,
    E_WRITE
};

typedef struct MsgData
{
    DataType type;
    int fd;
    uint16_t port;

    // NET-016: IPv4/IPv6 dual-stack support
    uint32_t ip;              // Legacy IPv4 field (backward compatibility)
    std::string addr;         // New field: address string (IPv4 or IPv6)

    std::string data;
    NetPack pack;
    std::string id;

    // NET-016: Helper to get address string (prefers new field)
    std::string getAddrStr() const {
        if (!addr.empty()) return addr;
        if (ip != 0) {
            char buf[INET_ADDRSTRLEN];
            struct in_addr in;
            in.s_addr = ip;
            inet_ntop(AF_INET, &in, buf, sizeof(buf));
            return std::string(buf);
        }
        return "";
    }
}MsgData;


struct compareMessageDataRequest
{
	bool operator () (MsgData & a, MsgData & b)
	{
		return (a.pack.flag & 0xF) < (b.pack.flag & 0xF);
	}
};


class MsgQueue
{
public:
    std::string strInfo;
    std::priority_queue<MsgData, std::vector<MsgData>, compareMessageDataRequest> msgQueue;
	std::mutex listMutex;

	std::condition_variable_any notEmpty;	
	std::condition_variable_any notFull;	
	size_t maxSize;						

public:
	/**
	 * @brief       
	 * 
	 * @return      true 
	 * @return      false 
	 */
	bool IsFull() const
	{
		return msgQueue.size() == maxSize;
	}

	/**
	 * @brief       
	 * 
	 * @return      true 
	 * @return      false 
	 */
	bool IsEmpty() const
	{
		return msgQueue.empty();
	}
	
	/**
	 * @brief       
	 * 
	 * @param       data 
	 * @return      true 
	 * @return      false 
	 */
    bool Push(MsgData& data)
    {
		std::lock_guard<std::mutex> lck(listMutex);
		while (IsFull())
		{
			DEBUGLOG(" {} the blocking queue is full,waiting...",strInfo.c_str());
			notFull.wait(listMutex);
		}
		msgQueue.push(std::move(data));
		notEmpty.notify_one();

		// FEAT-001: Update queue size metrics
		if (strInfo == "ReadQueue") {
			NetworkMetrics::Instance().read_queue_size = msgQueue.size();
		} else if (strInfo == "WorkQueue") {
			NetworkMetrics::Instance().work_queue_size = msgQueue.size();
		} else if (strInfo == "WriteQueue") {
			NetworkMetrics::Instance().write_queue_size = msgQueue.size();
		}

		return true;
    };

	/**
	 * @brief       
	 * 
	 * @param       out 
	 * @return      true 
	 * @return      false 
	 */
    bool tryWaitTop(MsgData & out)
    {
		std::lock_guard<std::mutex> lck(listMutex);
		while (IsEmpty())
		{
			notEmpty.wait(listMutex);
		}

		out = std::move(msgQueue.top());
		msgQueue.pop();
		notFull.notify_one();
		
		// FEAT-001: Update queue size metrics
		if (strInfo == "ReadQueue") {
			NetworkMetrics::Instance().read_queue_size = msgQueue.size();
		} else if (strInfo == "WorkQueue") {
			NetworkMetrics::Instance().work_queue_size = msgQueue.size();
		} else if (strInfo == "WriteQueue") {
			NetworkMetrics::Instance().write_queue_size = msgQueue.size();
		}
		
		return true;
    };
    
	/**
	 * @brief       
	 * 
	 * @param       ret 
	 * @return      true 
	 * @return      false 
	 */
    bool Pop(MsgData *ret)
    {
	    return ret;
    };

    MsgQueue() : strInfo(""), maxSize(10000 * 5) {}
	MsgQueue(std::string strInfo) : maxSize(10000 * 5)
	{
         strInfo = strInfo;
    }
    ~MsgQueue() = default;
};


#endif
