#include "network_policy.h"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <algorithm>
#include <array>
#include <cctype>
#include <iomanip>
#include <random>
#include <sstream>
#include "utils/magic_singleton.h"

namespace
{
bool MatchesIpv4Prefix(uint32_t ip, uint32_t network, uint8_t prefixLength)
{
    if (prefixLength == 0) return true;
    const uint32_t mask = 0xFFFFFFFFu << (32u - prefixLength);
    return (ip & mask) == (network & mask);
}
}

NetworkAddressScope ClassifyNetworkAddress(const std::string& address)
{
    in_addr ipv4{};
    if (inet_pton(AF_INET, address.c_str(), &ipv4) == 1)
    {
        const uint32_t ip = ntohl(ipv4.s_addr);
        if (MatchesIpv4Prefix(ip, 0x00000000u, 8)) return NetworkAddressScope::Unspecified;
        if (MatchesIpv4Prefix(ip, 0x7F000000u, 8)) return NetworkAddressScope::Loopback;
        if (MatchesIpv4Prefix(ip, 0x0A000000u, 8)) return NetworkAddressScope::Private;
        if (MatchesIpv4Prefix(ip, 0x64400000u, 10)) return NetworkAddressScope::Shared;
        if (MatchesIpv4Prefix(ip, 0xA9FE0000u, 16)) return NetworkAddressScope::LinkLocal;
        if (MatchesIpv4Prefix(ip, 0xAC100000u, 12)) return NetworkAddressScope::Private;
        if (MatchesIpv4Prefix(ip, 0xC0A80000u, 16)) return NetworkAddressScope::Private;
        if (MatchesIpv4Prefix(ip, 0xC0000000u, 24)) return NetworkAddressScope::Reserved;
        if (MatchesIpv4Prefix(ip, 0xC0000200u, 24)) return NetworkAddressScope::Reserved;
        if (MatchesIpv4Prefix(ip, 0xC6120000u, 15)) return NetworkAddressScope::Reserved;
        if (MatchesIpv4Prefix(ip, 0xC6336400u, 24)) return NetworkAddressScope::Reserved;
        if (MatchesIpv4Prefix(ip, 0xCB007100u, 24)) return NetworkAddressScope::Reserved;
        if (MatchesIpv4Prefix(ip, 0xE0000000u, 3)) return NetworkAddressScope::Reserved;
        return NetworkAddressScope::Public;
    }

    in6_addr ipv6{};
    if (inet_pton(AF_INET6, address.c_str(), &ipv6) != 1) return NetworkAddressScope::Invalid;
    if (IN6_IS_ADDR_UNSPECIFIED(&ipv6)) return NetworkAddressScope::Unspecified;
    if (IN6_IS_ADDR_LOOPBACK(&ipv6)) return NetworkAddressScope::Loopback;
    if (IN6_IS_ADDR_LINKLOCAL(&ipv6)) return NetworkAddressScope::LinkLocal;
    if ((ipv6.s6_addr[0] & 0xFEu) == 0xFCu) return NetworkAddressScope::Private;
    if (IN6_IS_ADDR_V4MAPPED(&ipv6))
    {
        char mapped[INET_ADDRSTRLEN]{};
        if (!inet_ntop(AF_INET, &ipv6.s6_addr[12], mapped, sizeof(mapped)))
            return NetworkAddressScope::Invalid;
        return ClassifyNetworkAddress(mapped);
    }
    if ((ipv6.s6_addr[0] & 0xE0u) == 0x20u) return NetworkAddressScope::Public;
    return NetworkAddressScope::Reserved;
}

bool IsUsableRemoteAddress(const std::string& address)
{
    const auto scope = ClassifyNetworkAddress(address);
    return scope != NetworkAddressScope::Invalid && scope != NetworkAddressScope::Unspecified;
}

bool IsPublicNetworkAddress(const std::string& address)
{
    return ClassifyNetworkAddress(address) == NetworkAddressScope::Public;
}

uint16_t Ipv4Subnet16(uint32_t networkOrderIp)
{
    return static_cast<uint16_t>(ntohl(networkOrderIp) >> 16u);
}

std::string NormalizeEndpointAddress(const std::string& address)
{
    const auto scope = ClassifyNetworkAddress(address);
    if (scope == NetworkAddressScope::Loopback) return "<loopback>";

    char normalized[INET6_ADDRSTRLEN]{};
    in_addr ipv4{};
    if (inet_pton(AF_INET, address.c_str(), &ipv4) == 1)
    {
        return inet_ntop(AF_INET, &ipv4, normalized, sizeof(normalized))
            ? std::string(normalized)
            : std::string{};
    }
    in6_addr ipv6{};
    if (inet_pton(AF_INET6, address.c_str(), &ipv6) == 1)
    {
        return inet_ntop(AF_INET6, &ipv6, normalized, sizeof(normalized))
            ? std::string(normalized)
            : std::string{};
    }

    std::string hostname = address;
    std::transform(hostname.begin(), hostname.end(), hostname.begin(),
                   [](unsigned char value) { return static_cast<char>(std::tolower(value)); });
    while (!hostname.empty() && hostname.back() == '.') hostname.pop_back();
    if (hostname == "localhost") return "<loopback>";
    return hostname;
}

bool EndpointAddressesEquivalent(const std::string& left, const std::string& right)
{
    const std::string normalizedLeft = NormalizeEndpointAddress(left);
    return !normalizedLeft.empty() && normalizedLeft == NormalizeEndpointAddress(right);
}

std::string GenerateConnectionAttemptId()
{
    std::array<unsigned char, 16> bytes{};
    std::random_device random;
    for (auto& byte : bytes)
    {
        byte = static_cast<unsigned char>(random());
    }
    std::ostringstream output;
    output << std::hex << std::setfill('0');
    for (const auto byte : bytes)
    {
        output << std::setw(2) << static_cast<unsigned int>(byte);
    }
    return output.str();
}

bool IsValidConnectionAttemptId(const std::string& attemptId)
{
    return attemptId.size() == 32 &&
           std::all_of(attemptId.begin(), attemptId.end(), [](unsigned char value) {
               return std::isxdigit(value) != 0;
           });
}

ConnKind PreferredConnectionKind(const std::string& selfAddress, const std::string& peerAddress)
{
    return selfAddress < peerAddress ? dataRateToOutput : PASSIV;
}

bool ShouldReplaceExistingConnection(int existingFd, ConnKind existingKind,
                                     ConnKind candidateKind, ConnKind preferredKind)
{
    if (existingFd <= 0) return true;
    if (existingKind == preferredKind) return false;
    return candidateKind == preferredKind;
}

NetworkConnectionPolicy GetNetworkConnectionPolicy(Genesis::NetworkType networkType)
{
    if (networkType == Genesis::NetworkType::Dev)
    {
        NetworkConnectionPolicy policy;
        policy.maxPeerConnections = 254; // 255-node dev network including self.
        return policy;
    }
    NetworkConnectionPolicy policy;
    policy.requirePublicAddress = true;
    policy.requirePublicAdvertisedEndpoint = true;
    policy.allowSharedSourceIp = false;
    policy.enforcePerIpLimit = true;
    policy.enforceSubnet16Limit = true;
    policy.enforceInboundRatio = true;
    return policy;
}

NetworkConnectionPolicy GetCurrentNetworkConnectionPolicy()
{
    return GetNetworkConnectionPolicy(MagicSingleton<Genesis>::GetInstance()->GetNetworkType());
}

bool IsAddressAllowedByNetwork(Genesis::NetworkType networkType, const std::string& address)
{
    if (!IsUsableRemoteAddress(address)) return false;
    const auto policy = GetNetworkConnectionPolicy(networkType);
    return !policy.requirePublicAddress || IsPublicNetworkAddress(address);
}
