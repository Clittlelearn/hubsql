以下是针对**区块链协议 Spec 文档**（尤其是 EVM 兼容高性能链）的**最佳编写实践指导**。这些实践主要借鉴 Ethereum Yellow Paper（形式化数学规范）、Solana Protocol Specs（模块化仓库结构）、IETF 密码学规范指南、BSC PoSA 相关文档，以及规范驱动开发（Specification-Driven Development, SDD）的通用原则。目标是让 Spec 成为**唯一权威来源**（single source of truth），指导参考实现（reference implementation）、一致性测试、审计和互操作，同时减少歧义和安全漏洞。

### **1. 总体原则（Core Principles）**
- **精确性与无歧义（Precision and Unambiguity）**：优先使用数学符号、伪代码、状态转换函数和表格，而非模糊自然语言。像 Ethereum Yellow Paper 那样定义符号表（Notation），用希腊字母表示状态（σ 为世界状态，μ 为机器状态，Υ 为状态转换函数）。每个行为（成功、失败、边缘案例）都必须有明确规则。
- **完备性（Completeness）**：覆盖所有协议方面，包括成功路径、错误处理、Gas 耗尽、共识安全、不变量（Invariants）和边缘条件。遗漏会导致不同客户端行为不一致。
- **确定性（Determinism）**：确保相同输入在所有合规实现中产生相同输出（例如 EVM 执行必须 100% 匹配 Yellow Paper opcode 语义）。
- **可验证性（Verifiability）**：Spec 应直接支持编写一致性测试套件（如 Ethereum 的 tests 仓库）。推荐同时提供伪代码/算法和参考 Python/Rust 实现（Solana specs 使用 Python-like 执行规范补充数学描述）。
- **可维护性与版本化（Maintainability & Versioning）**：使用 Git 维护（LaTeX + Markdown + KaTeX）。每个硬分叉/升级发布新版本（e.g., v1.0 Shanghai-compatible），附带变更日志（Changelog）。标注“EVM 兼容部分必须严格遵循 Ethereum 执行规范”。
- **模块化（Modularity）**：按层级组织（高层架构 → 详细组件），每个章节独立、可单独引用。类似 Solana specs 仓库，按 core / consensus / runtime / gossip 等目录划分。
- **受众导向（Audience-Oriented）**：主要面向客户端开发者、节点运营商和审计师。提供不同抽象级别：高层概述（自然语言） + 形式化细节。避免仅面向最终用户。

### **2. 文档结构推荐（Recommended Structure）**
采用分层结构，从抽象到具体，便于阅读和实现：

1. **标题页与元信息**：文档标题、版本、日期、状态（Draft / Stable）、作者/维护者、许可证、摘要（Abstract）。
2. **引言与范围（Introduction & Scope）**：协议目标、与 Ethereum/BSC/Solana/TRON 的关系、设计原则（简单性、可扩展性、安全性）。明确 EVM 兼容级别（Compatibility vs Equivalence）。
3. **符号与定义（Notation and Definitions）**：完整符号表（必须放在前面）。定义所有术语、数据类型（地址、RLP、MPT 等）、常量和不变量。
4. **高层架构（High-Level Architecture）**：分层图（应用层、执行层、共识层、网络层、数据层）。描述账户模型、状态机模型。
5. **创世与初始状态（Genesis Block and Initial State）**：Genesis JSON 格式、初始分配、配置参数（chainId、Gas Limit、验证者集等）。
6. **区块与交易（Blocks, Transactions）**：结构定义（头字段、体）、序列化（RLP）、验证规则、生命周期（mempool → 执行 → 打包）。
7. **执行层（Execution Layer - EVM）**：核心形式化部分。详细描述 EVM 状态元组、执行循环、opcode 语义、Gas 成本表、状态转换函数 Υ(σ, T) → σ'。必须包含 precompiles、异常处理、并行优化（如果有 Solana-like Sealevel 支持）。
8. **共识机制（Consensus Mechanism）**：PoSA/DPoS 等详细算法、验证者选举、slashing 规则、最终性（finality）、时间证明集成。提供伪代码或流程图。
9. **网络与同步（Networking & Synchronization）**：P2P 协议消息格式、Gossip、同步模式（fast/full/archive）。
10. **代币经济学与 Gas（Tokenomics & Gas Mechanics）**：EIP-1559 实现、费用分配、燃烧机制。
11. **治理与升级（Governance & Upgrades）**：硬分叉激活、链上提案过程。
12. **安全考虑与不变量（Security Considerations & Invariants）**：已知攻击缓解、形式化不变量列表（e.g., Gas 非负、状态根一致性）。
13. **附录（Appendices）**：完整 Opcode Gas 表、RLP 规则、测试向量、Genesis 示例、兼容性矩阵、参考实现接口（RPC 方法）。
14. **参考文献（References）**：Yellow Paper、EIPs、BSC BEPs、Solana specs 等。

### **3. 写作技巧与格式（Writing Techniques & Formatting）**
- **形式化 vs 可读性**：核心规则用数学/伪代码描述（e.g., Υ(σ, T) = σ'），辅以自然语言解释和示例。使用 LaTeX 渲染公式（KaTeX 在 Markdown 中）。Yellow Paper 的排版惯例（粗体希腊字母表示结构化状态）非常有效。
- **一致术语**：全程使用相同术语和缩写。首次出现时定义。建立术语表（Glossary）。
- **算法与伪代码**：为关键流程（如区块验证、EVM 执行循环、验证者轮换）提供清晰伪代码。标注输入/输出、前置条件、后置条件。
- **表格与图表**：大量使用表格（opcode、区块头字段、Gas 成本）。添加架构图、状态转换图、流程图（用 PlantUML 或类似工具生成）。
- **边缘案例与异常**：每个规则都明确说明失败行为（revert、Gas 消耗、回滚）。
- **兼容性声明**：明确哪些部分必须 100% 匹配 Ethereum（EVM opcode、交易格式），哪些是扩展（PoSA 共识、并行执行）。
- **长度控制**：保持简洁但完备。核心章节聚焦“是什么”和“必须如何”，实现细节留给参考客户端代码。

### **4. 规范驱动开发（SDD）集成实践**
- **Spec 先行**：在任何代码实现前完成 Spec。Spec 作为合约（contract）指导开发：实现必须通过 Spec 定义的一致性测试。
- **参考实现（Reference Implementation）**：基于 Spec 构建一个权威客户端（e.g., go-ethereum fork），其他实现必须与之行为一致。
- **测试驱动**：从 Spec 衍生测试向量（test vectors）和一致性测试套件。推荐包含 Python 执行规范（类似 Ethereum execution-specs）作为可执行补充。
- **变更管理**：任何修改通过 EIP-like 提案流程，更新 Spec 并标记版本。使用 Git 分支跟踪不同硬分叉。
- **工具支持**：LaTeX（Yellow Paper 风格） + Markdown。考虑 Spec-Kit 等现代工具辅助生成/验证 Spec。
- **迭代流程**：撰写 → 内部审查 → 社区反馈 → 参考实现验证 → 发布。每次迭代后运行全套测试确保一致性。

### **5. 常见陷阱与避免方法**
- **避免歧义**：不要说“通常”或“推荐”，而是说“必须（MUST）”、“应该（SHOULD）”、“可以（MAY）”（参考 RFC 2119 关键字）。
- **不要过度复杂**：遵循 Ethereum 哲学——简单性优先，在必要时才增加复杂度，并提供清晰文档。
- **安全优先**：始终包含威胁模型、slashing 规则和不变量证明。参考 OWASP Blockchain 或 Trail of Bits 指南。
- **不要仅数学化**：为开发者提供可读解释和示例，否则难以落地。
- **更新滞后**：Spec 必须与实现同步；建立自动化检查（如状态根验证测试）。

### **6. 额外推荐资源与工具**
- **模板参考**：Ethereum Yellow Paper（数学风格）、Solana specs 仓库（模块化）、IETF 密码学规范指南（一致术语、数学操作）。
- **格式工具**：LaTeX for 正式部分，Markdown + KaTeX for 协作，GitHub for 版本控制。
- **审查流程**：内部技术审查 + 外部审计 + 社区讨论（类似 ethresear.ch）。
- **可执行 Spec**：补充 Python/Rust 伪实现，便于测试和理解（Ethereum execution-specs 的做法）。
