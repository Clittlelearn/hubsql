# OpenHive 协议规范文档

**版本**: 0.5.0-draft
**状态**: Draft（开发中）
**日期**: 2026-07-15
**维护者**: OpenHive Core Team
**许可证**: 待确认

---

## 摘要

OpenHive 是一个基于 UTXO 模型的高性能公有链，集成 VRF（Verifiable Random Function）共识机制和 EVM（Ethereum Virtual Machine）智能合约执行引擎。本文档定义了 OpenHive 协议的完整规范，包括共识算法、数据结构、执行语义、存储模型、网络协议和 RPC 接口，作为参考实现、一致性测试和互操作的唯一权威来源。

---

## 目录

- [1. 引言与范围](#1-引言与范围)
- [2. 符号与定义](#2-符号与定义)
- [3. 高层架构](#3-高层架构)
- [4. 创世与初始状态](#4-创世与初始状态)
- [5. 区块与交易](#5-区块与交易)
- [6. 共识机制（VRF）](#6-共识机制vrf)
- [7. 执行层（EVM + 智能合约）](#7-执行层evm--智能合约)
- [8. 存储层](#8-存储层)
- [9. 网络层](#9-网络层)
- [10. RPC/API 接口](#10-rpcapi-接口)
- [11. 代币经济学与 Gas](#11-代币经济学与-gas)
- [12. 治理与升级](#12-治理与升级)
- [13. 安全考虑与不变量](#13-安全考虑与不变量)
- [附录 A. 完整常量表](#附录-a-完整常量表)
- [附录 B. 交易类型枚举](#附录-b-交易类型枚举)
- [附录 C. 数据库 Key 前缀规范](#附录-c-数据库-key-前缀规范)
- [附录 D. RPC 方法列表](#附录-d-rpc-方法列表)
- [附录 E. 未决问题与 TODO](#附录-e-未决问题与-todo)
- [附录 F. CLI 命令参考](#附录-f-cli-命令参考)
- [附录 G. HTML 统一样式系统](#附录-g-html-统一样式系统)
- [参考文献](#参考文献)

---

## 1. 引言与范围

### 1.1 协议目标

OpenHive 旨在构建一个：
- 支持多资产原生发行的 UTXO 基础链
- 具备 VRF 随机选择打包节点的 PoS 共识系统
- 兼容 EVM 智能合约执行环境
- 提供委托权益证明（Delegated Proof of Stake）激励机制

### 1.2 设计原则

1. **简单性优先**: 在必要时才增加复杂度
2. **确定性执行**: 相同输入在所有合规实现中产生相同输出
3. **可验证性**: 所有状态转换必须支持密码学验证
4. **EVM 兼容性**: EVM 执行层必须严格遵循 Ethereum 语义

### 1.3 网络类型

协议支持三种网络配置，通过编译宏区分：

| 网络类型 | 编译宏 | 用途 |
|---------|--------|------|
| DevNet | (默认) | 开发调试网络 |
| TestNet | `TESTCHAIN=ON` | 公共测试网络 |
| Primary | `PRIMARYCHAIN=ON` | 主网络 |

### 1.4 术语约定

本文档使用 RFC 2119 关键字：
- **MUST**: 必须，绝对要求
- **SHOULD**: 应该，推荐但允许例外
- **MAY**: 可以，可选行为

---

## 2. 符号与定义

### 2.1 基本数据类型

| 符号 | 类型 | 说明 |
|------|------|------|
| `Hash` | `string` (hex) | 256-bit SHA256 哈希值，64 字符十六进制字符串 |
| `Address` | `string` | 由公钥生成的地址标识符 |
| `AssetType` | `string` | 资产类型标识，"OHI" 为原生资产 |
| `U64` | `uint64_t` | 64 位无符号整数 |
| `I64` | `int64_t` | 64 位有符号整数 |
| `U32` | `uint32_t` | 32 位无符号整数 |
| `Bytes` | `string` / `bytes` | 任意长度字节序列 |

### 2.2 派生类型

| 符号 | 定义 | 说明 |
|------|------|------|
| `BlockHash` | `Hash` | 区块哈希 |
| `TxHash` | `Hash` | 交易哈希 |
| `UTXOHash` | `Hash` | UTXO 标识哈希 |
| `MerkleRoot` | `Hash` | Merkle 树根哈希 |
| `Nonce` | `U64` | EVM 账户 nonce 值 |
| `Period` | `U64` | VRF 共识周期编号 |

### 2.3 精度定义

OpenHive 使用**双精度系统**，区分标准精度（用户界面）和最小精度（底层存储）：

#### 2.3.1 定义

| 精度类型 | 说明 | 使用场景 |
|---------|------|---------|
| **标准精度** | 面向用户的金额表示，单位为 1 OHI | UI 展示、RPC 接口输入/输出 |
| **最小精度** | 底层存储和计算的最小单位，1 标准单位 = 10⁸ 最小单位 | 数据库存储、交易计算、智能合约 |

#### 2.3.2 转换关系

```
转换常量：kDecimalNum = 100,000,000 (10⁸)

标准精度 → 最小精度:
  min_amount = std_amount × kDecimalNum

最小精度 → 标准精度:
  std_amount = min_amount ÷ kDecimalNum
```

#### 2.3.3 示例

| 标准精度 | 最小精度 | 说明 |
|---------|---------|------|
| 1 OHI | 100,000,000 | 1 个 OHI 代币 |
| 0.5 OHI | 50,000,000 | 半个 OHI 代币 |
| 0.00000001 OHI | 1 | 最小精度单位（类似以太坊的 wei） |
| 3500 OHI | 350,000,000,000 | 节点最小质押量 |

#### 2.3.4 使用规范

1. **RPC 接口**: 输入/输出使用标准精度（用户友好）
2. **数据库存储**: 使用最小精度（避免浮点数误差）
3. **智能合约**: 内部计算使用最小精度
4. **交易构造**: 金额字段使用最小精度

**例外**: `LOCK_AMOUNT = 1` 是标准精度常量，使用时需要乘以 `kDecimalNum` 转换为最小精度。

### 2.4 状态符号

| 符号 | 说明 |
|------|------|
| `σ` | 全局世界状态（World State） |
| `B` | 区块状态（Block State） |
| `T` | 交易（Transaction） |
| `μ` | EVM 机器状态（Machine State） |
| `S` | 存储状态（Storage State） |
| `Υ` | 状态转换函数 `Υ(σ, T) → σ'` |

### 2.4 地址生成算法

地址生成遵循 **以太坊 EIP-55** 标准，使用 Keccak-256 哈希和校验和格式：

```
GenerateAddr(publicKey):
  1. 从公钥提取 64 字节 X,Y 坐标（未压缩格式，去掉 0x04 前缀）
     - 如果公钥是 65 字节（0x04 || X || Y）：直接提取后 64 字节
     - 如果公钥是 33 字节（压缩格式 0x02/0x03 || X）：解压缩恢复 Y 坐标
     - 如果公钥是 DER 编码：解析后提取 X,Y 坐标

  2. 计算 Keccak-256 哈希
     hash = Keccak256(X || Y)   // 64 字节输入，32 字节输出

  3. 取哈希值的后 20 字节
     addr_hex = hash[12:32]     // 跳过前 12 字节，取后 20 字节

  4. 应用 EIP-55 校验和格式
     checksumAddr = ToChecksumAddress(addr_hex)
     - 对地址的十六进制表示计算 Keccak-256
     - 如果 hash[i] >= 8，则 addr_hex[i] 转为大写
     - 否则保持小写

  5. 返回校验和地址（40 字符十六进制，大小写混合）
```

**示例**：
```
公钥（未压缩）: 0x0476d1b5... (65 字节)
X,Y 坐标      : 76d1b5... (64 字节)
Keccak256    : 0x8a3d5e7f... (32 字节)
地址（后 20 字节）: 0x5e7f... (20 字节)
校验和地址    : 0x5E7f... (EIP-55 格式)
```

**实现细节**：
- 曲线：secp256k1
- 哈希函数：Keccak-256（与以太坊兼容）
- 校验和：EIP-55
- 缓存：使用 `AddressCache` 缓存公钥到地址的映射

### 2.5 常量定义

核心常量见 [附录 A](#附录-a-完整常量表)。所有常量定义位于 `ca/global.h`，按命名空间 `global::ca` 组织。

---

## 3. 高层架构

### 3.1 分层模型

OpenHive 采用分层架构：

```
┌─────────────────────────────────────────────────────────────────┐
│                        客户端 / CLI                              │
│                  (main/menu.cpp, main/main.cpp)                 │
├─────────────────────────────────────────────────────────────────┤
│                         RPC/API 层                               │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────────┐  │
│  │ JSON-RPC 2.0│  │  ETH Compat  │  │  HTTP Server (httplib)  │  │
│  └─────────────┘  └──────────────┘  └─────────────────────────┘  │
├─────────────────────────────────────────────────────────────────┤
│                       共识层 (CA)                                │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────────┐  │
│  │ VRF Consensus│ │ Block Helper │  │ Transaction Handler     │  │
│  │ (10s cycle) │  │ (Save/Rollback)│ │ (UTXO validation)       │  │
│  └─────────────┘  └──────────────┘  └─────────────────────────┘  │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────────┐  │
│  │ Sync Block  │  │ Packager Disp│  │ Block Monitor/Storage   │  │
│  └─────────────┘  └──────────────┘  └─────────────────────────┘  │
├─────────────────────────────────────────────────────────────────┤
│                       智能合约层                                  │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────────┐  │
│  │ EVM (evmone)│  │  Precompiles │  │ Contract Dispatcher     │  │
│  │ EvmHost     │  │  Cache       │  │ Dependency Management   │  │
│  └─────────────┘  └──────────────┘  └─────────────────────────┘  │
├─────────────────────────────────────────────────────────────────┤
│                       存储层                                     │
│  ┌─────────────┐  ┌──────────────┐                               │
│  │  RocksDB    │  │  MPT (Trie)  │                               │
│  │ (Transaction│  │ (Contract    │                               │
│  │  DB mode)   │  │  State)      │                               │
│  └─────────────┘  └──────────────┘                               │
├─────────────────────────────────────────────────────────────────┤
│                       网络层                                     │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────────┐  │
│  │ PeerNode Mgr│  │ Protobuf Disp│  │ epoll Event Loop        │  │
│  └─────────────┘  └──────────────┘  └─────────────────────────┘  │
├─────────────────────────────────────────────────────────────────┤
│                       公共组件                                   │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────────┐  │
│  │ Config Mgr  │  │ Genesis Mgr  │  │ Task Pool / Timer       │  │
│  └─────────────┘  └──────────────┘  └─────────────────────────┘  │
│  ┌─────────────┐  ┌──────────────┐                               │
│  │ Account Mgr │  │ Logging      │                               │
│  │ (SilkPre)   │  │ (spdlog)     │                               │
│  └─────────────┘  └──────────────┘                               │
└─────────────────────────────────────────────────────────────────┘
```

### 3.2 状态机模型

OpenHive 是一个基于 **DAG（有向无环图）** 的确定性状态机：

```
初始状态 (Genesis) → 区块 DAG {B₁, B₂, ..., Bₙ, ...} → 主链状态 σₙ
```

#### 3.2.1 DAG 结构特征

OpenHive 采用 DAG 结构，允许同一高度存在多个区块（分叉）：

- **多区块同高**: 同一高度 `h` 可以有多个区块 `{B_h¹, B_h², ..., B_hᵏ}`
- **多前向引用**: 区块可以引用多个前驱区块（通过 VRF blockinfo）
- **主链选择**: 通过共识权重从 DAG 中选择主链（longest chain with most consensus）

**状态转换函数**：
```
σₙ = Υ(σₙ₋₁, Bₙ)
   = Υ(σₙ₋₁, {T₁, T₂, ..., Tₖ})
   = Υ(...Υ(Υ(σₙ₋₁, T₁), T₂)..., Tₖ)
```

**前置条件**:
- 区块 MUST 通过共识验证
- 交易 MUST 通过 UTXO 验证和双花检查

**后置条件**:
- 状态根 MUST 一致
- 所有 UTXO 变更 MUST 持久化

### 3.3 混合模型：UTXO + 账户

OpenHive 采用混合模型：

| 层面 | 模型 | 说明 |
|------|------|------|
| 基础层 | UTXO | 转账、质押、委托等使用 UTXO 模型 |
| 合约层 | 账户模型 | EVM 合约使用地址-余额-存储模型 |
| EVM 兼容 | 账户模型 | 通过 nonce 和 RLP 编码兼容以太坊工具链 |

---

## 4. 创世与初始状态

### 4.1 创世区块

创世区块（Height = 0）是链的起始点，具有以下特征：

- `version`: 0
- `height`: 0
- `prevhash`: 空字符串或全零哈希
- `time`: 创世时间戳（需配置）
- `txs`: 包含至少一笔创世交易（GENESIS 类型）

创世区块的具体初始分配、验证者集和配置参数通过 `genesis.json` 配置文件定义，详见 4.3 节。

### 4.2 创世交易

创世交易（`TxType::GENESIS`）负责初始化 UTXO 分配、设置初始资产类型并建立初始账户状态。

**生成流程 (`GenesisBlock::CreateGenesisTransaction`)**：
1.  读取 `genesis.json` 中的初始账户地址 `initAccountAddr` 和创世时间 `genesisTime`。
2.  设置交易元数据：
    -   `version`: 当前交易版本 (`CURRENT_TRANSACTION_VERSION`)
    -   `time`: 创世时间戳（微秒级）
    -   `identity`: 初始账户地址
    -   `type`: `TxType::GENESIS`
3.  遍历 `initialBalance` 配置（目前支持 `OHI` 和 `Vote`）：
    -   调用 `populateUtxoData` 为每种资产创建 UTXO。
    -   **注意**: 代码逻辑中，若初始余额非零则会被强制设为 0。这意味着创世区块目前仅用于初始化账户结构和资产类型，实际代币分配可能通过后续交易或空投完成。
4.  计算交易哈希：`SHA256(Serialize(Transaction))`。

**UTXO 填充逻辑 (`populateUtxoData`)**：
-   `assettype`: 资产类型（如 "OHI", "Vote"）。
-   `owner`: 所有者地址。
-   `vin`: 包含一个虚拟输入，`prevout.hash` 为全零哈希（64个'0'），`n` 为 0。
-   `vout`: 包含一个输出，`value` 为 `balance * kDecimalNum`（转换为最小精度），`addr` 为目标地址。

### 4.3 创世配置文件 (genesis.json)

创世区块的参数通过 `genesis.json` 配置文件进行初始化。系统启动时由 `Genesis` 类读取该文件。

**配置文件结构**:
```json
{
  "genesis": {
    "blockData": {
      "Name": "DevChain",       // 链名称
      "Type": "Genesis"         // 区块类型标识
    },
    "genesisTime": 1769736708175000,  // 创世时间戳（微秒）
    "initAccountAddr": "755Ccf704E17570b64E247f0794314e4C8E542CA", // 初始账户地址
    "vrfWhitelist": [],              // VRF 准入池白名单地址列表
    "initialBalance": {
      "OHI": 0,                  // 初始 OHI 余额（最小精度）
      "Vote": 0                 // 初始 Vote 余额（最小精度）
    }
  },
  "network": {
    "name": "devnet",           // 网络名称
    "type": "dev"               // 网络类型 (dev/test/primary)
  },
  "version": "1.0.0"
}
```

**关键参数说明**:
-   `genesisTime`: 创世区块的时间戳。
-   `initAccountAddr`: 创世区块的归属地址，通常作为初始验证者或管理账户。
-   `initialBalance`: 初始资产分配。当前实现中，创世交易强制将余额设为 0，实际分配可能依赖外部注入。
-   `network.type`: 决定网络类型（DevNet, TestNet, Primary），影响种子节点列表和共识参数。

### 4.4 初始配置

初始配置参数通过 `genesis.json` 和 `config.json` 文件管理：

- **初始验证者地址列表**: 通过 `genesis.vrfWhitelist` 配置（见 6.4.3 节）
- **初始 OHI 代币分配**: 创世区块中 `initialBalance` 字段定义，当前实现中余额强制为 0
- **初始 Gas 配置**: `KTargetGasPrice = 60000`，`INITIAL_BASE_FEE = 10`（见 11.5 节）
- **网络类型对应的链 ID**: `eth_chainId` 返回 `0x3027` (12315)（见 10.5 节）

---

## 5. 区块与交易

### 5.1 区块结构

区块使用 Protobuf 序列化，定义如下：

```protobuf
message CBlock {
  uint32 version            = 1;   // 区块版本
  uint64 time               = 2;   // 区块创建时间（微秒级时间戳）
  string hash               = 3;   // 区块哈希
  string prevhash           = 4;   // 前一区块哈希
  int64 height              = 5;   // 区块高度
  string merkleroot         = 6;   // Merkle 根哈希
  repeated CTransaction txs = 7;   // 区块内所有交易
  string data               = 8;   // 区块附加数据
  string info               = 9;   // 区块信息
  repeated CSign signature  = 10;  // 区块多签（打包节点签名）
  string reserve0           = 11;  // 预留字段 0
  string reserve1           = 12;  // 预留字段 1
}
```

### 5.2 区块哈希计算

区块哈希计算公式：
```
BlockHash = SHA256(Serialize(Block without hash field))
```

即：对除 `hash` 字段外的完整区块结构进行 Protobuf 序列化，然后计算 SHA256 哈希。

### 5.3 Merkle 根

Merkle 根由区块内所有交易的哈希构建，采用**双 SHA256 迭代归并**方式（类似 Bitcoin 变体）：

```
calculateBlockMerkle(block):
  1. 提取所有交易的 hash 字段（已是 SHA256 十六进制字符串）
  2. 迭代归并，每层对左右子节点先各自做一次 SHA256，拼接后再 SHA256:
     parent = SHA256(SHA256(left_hex) + SHA256(right_hex))
  3. 奇数节点时，最后一个节点复制自身参与配对
  4. 空区块返回空字符串
```

**特点**：每个叶子实际经过 `SHA256(SHA256(tx))` 双哈希，内部节点为 `SHA256(SHA256(left) + SHA256(right))`。

验证位置：`VerifyBlock` 中调用 `calculateBlockMerkle(block)` 与区块声明的 `merkleroot` 比对。

### 5.4 区块验证规则

区块在保存到数据库前 MUST 通过以下验证：

1. **版本检查**: `version` 必须为当前支持版本
2. **高度连续性**: `height == prev_block.height + 1`
3. **时间戳有效性**: `time > prev_block.time`
4. **前向哈希链接**: `prevhash == prev_block.hash`
5. **Merkle 根验证**: 计算的 Merkle 根与区块声明一致
6. **交易验证**: 区块内所有交易 MUST 通过验证
7. **共识签名**: MUST 包含至少 `kConsensus = 7` 个有效签名
8. **打包节点资格**: 签名节点 MUST 通过 VRF 选择且具有质押资格

### 5.5 DAG 分叉处理

#### 5.5.1 多区块存储

同一高度可以存在多个区块（分叉），数据库使用 `vector<blockHash>` 存储：

```cpp
// Key: BH:{height} → Value: vector<blockHash>
DBStatus getBlockHashsByBlockHeight(uint64_t blockHeight, std::vector<std::string> &hashes);
```

#### 5.5.2 BlockStatus 追踪

每个区块的验证状态通过 `BlockStatus` 追踪：

```protobuf
message BlockStatus {
  string blockHash           = 1;  // 区块哈希
  int32  status              = 2;  // 验证状态码
  repeated TxStatus txStatus = 3;  // 失败交易列表
  string id                  = 4;  // 验证节点 ID
}
```

节点维护 `BlockStatusWrapper` 映射表：
- `blockStatusMap: map<blockHash, BlockStatusWrapper>`
- 追踪每个区块的验证节点集合
- 统计共识权重（验证节点数量）

#### 5.5.3 主链选择规则

从 DAG 中选择主链基于**节点投票的多数共识**，而非累计工作量：

**双阈值机制**：

| 阈值 | 值 | 用途 |
|------|------|------|
| `kForkMajorityThreshold` | 0.51 | 简单多数，用于普通同步中判定主链方向 |
| `kByzantineFaultToleranceThreshold` | 0.66 | 拜占庭容错，用于快速同步中更严格的一致性验证 |

**普通同步判定公式**：
```
verifyNum = floor((响应节点数 + 1) × 0.51)
若某哈希的支持节点数 >= verifyNum，则视为主链哈希
```

**快速同步判定公式**：
```
isByzantineSuccessful = (hits >= 响应节点数 × 0.66)
```

**时间保护**：只有超过 `RollBackTime`（15 秒）或 `kStabilityTime`（60 秒）稳定期的区块才会被回滚。

**重试上限**：快速同步最多重试 5 次，超过后放弃并标记同步失败。

#### 5.5.4 区块回滚机制

当检测到更优分叉时，执行回滚和重组：

```
rollback_block_(rollbackBlockData_):
  1. 从当前 top 向下回滚到分叉点
  2. 删除分叉区块的状态数据
  3. 恢复 UTXO 到未消费状态
  4. 应用新分叉的区块
  5. 更新 top 高度
```

回滚超时：`RollBackTime = 15 秒`（超过此时间的区块不再回滚）

**回滚深度限制**：

| 限制类型 | 值 | 说明 |
|----------|------|------|
| 回滚超时时间 | 15 秒 | `RollBackTime`，区块时间早于 `now - 15s` 才可回滚 |
| 区块稳定期 | 60 秒 | `kStabilityTime`，快速同步中超过此时间的区块才加入回滚队列 |
| 快速同步回滚高度差 | 10 块 | `chainHeight - height > 10` 时触发回滚 |
| 广播区块接受范围 | 10 块 | 高度差超过 10 且超过 60 秒则拒绝 |
| 快速同步最大重试 | 5 次 | 超过后放弃快速同步，切换到从零同步 |
| 高度跳跃限制 | 5 块 | `ownHeight > preHeight + 5` 则拒绝区块 |

### 5.6 分叉解决与重组规则

#### 5.6.1 分叉检测周期

节点每隔 **15 秒** 执行一次分叉检测（与 VRF 周期同步）：

1. **目标节点选择**: 向全网具有投资质押资格的节点发起查询
2. **查询范围**: 自身节点高度 ±50 个区块
3. **响应阈值**: 至少需要收到 **80%** 的消息回复
   - 如果回复率 < 80%，判定为网络异常或节点孤立
   - 等待下一周期重新检测

#### 5.6.2 拜占庭容错共识

对于每个高度 `h`，收集所有返回的区块哈希并进行共识判定：

```
共识判定规则:
  - 对于高度 h 的区块哈希 hash_i
  - 统计每个 hash_i 的支持节点数 count_i
  - 计算共识阈值: verifyNum = floor((N + 1) * 0.51)
    - N: 实际收到回复的节点数
    - 51%: 简单多数原则
```

#### 5.6.3 分叉处理策略

根据共识结果执行不同操作：

| 场景 | 判定条件 | 处理方式 |
|------|---------|---------|
| **主链确认** | 本地区块哈希支持数 ≥ 51% | 保持当前链，无需操作 |
| **分叉同步** | 远程区块哈希支持数 ≥ 51% 且本地不存在 | 下载并应用新区块 |
| **分叉回滚** | 远程区块哈希支持数 ≥ 51% 但与本地冲突 | 回滚到分叉点前，应用新区块 |
| **孤立区块** | 所有区块哈希支持数 < 51% | 标记为孤立区块，等待更多共识 |

#### 5.6.4 重组流程

```
分叉解决流程:
  1. 收集阶段: 向质押节点发送高度范围查询请求
  2. 统计阶段: 构建 consensusMap[height][hash] → {node_ids}
  3. 判定阶段: 对每个高度的所有哈希进行 51% 阈值判定
  4. 回滚阶段: 将支持率 < 51% 的本地区块加入 rollbackBlockData_
  5. 同步阶段: 从共识节点下载支持率 ≥ 51% 的远程区块
  6. 应用阶段: 调用 rollback_block_ 执行回滚，然后应用新区块
```

#### 5.6.5 回滚保护机制

为防止恶意重组攻击，实现以下保护措施：

1. **时间窗口保护**: 
   - `RollBackTime = 15 秒`
   - 只有时间戳早于 `current_time - 15 秒` 的区块才允许回滚
   - 防止对最新区块的频繁重组

2. **深度限制**:
   - 快速同步模式：回滚深度超过 10 个区块时触发失败保护
   - 触发失败保护后，切换到从零同步模式

3. **节点资格限制**:
   - 只有具有质押资格的节点（`VerifyBonusAddr(node)` 返回 true）才能参与共识
   - 防止 Sybil 攻击

4. **失败恢复**:
   - 如果快速同步失败（`isFastSyncFailed = true`），切换到从零同步
   - 从零同步使用 SumHash 验证，提供更强的完整性保证

#### 5.6.6 同步模式切换

```
同步模式决策树:
  本地高度 ≈ 网络高度 (差距 ≤ 100)
    ├─ 共识一致 → 正常同步模式 (SyncNormal)
    └─ 共识分歧 → 分叉解决流程
  
  本地高度 ≪ 网络高度 (差距 > 100)
    ├─ 有可靠 SumHash 验证 → 快速同步 (SyncFromZero)
    └─ SumHash 验证失败 → 从零完整同步
```

### 5.7 部分区块与排除证明（Partial Block & Exclusion Proof）

当区块内合约交易的累计 Gas 超过区块 Gas 上限（`kBlockGasLimit = 30,000,000`）时，系统触发**熔断机制**，构建部分区块并提供排除证明。

#### 5.7.1 熔断机制

```
executeContracts(tx_iterator):
  for each tx in tx_iterator:
    totalBlockGasCost += txGasCost
    if totalBlockGasCost > kBlockGasLimit:
      1. 记录导致超限的交易及剩余所有交易为 "excluded"
      2. 记录 m_cumulativeGasBeforeExclusion（排除前的累计 Gas）
      3. 从交易缓存中移除被排除的交易
      4. 返回 {0, "PartialBlock"}，允许区块继续构建
```

#### 5.7.2 ExclusionProof 结构

```protobuf
message ExclusionProof {
  repeated CTransaction excluded_txs = 1;  // 被排除的交易完整数据
  uint64 cumulative_gas_before = 2;        // 执行这些交易前的累计 gas
  string reason = 3;                       // 排除原因（如 "BLOCK_GAS_LIMIT_EXCEEDED"）
  bytes packager_signature = 4;            // 打包者签名
}
```

#### 5.7.3 证明生成与验证

```
BuildBlock 中注入 ExclusionProof:
  1. 检查是否有被排除的交易（GetAndClearExclusionData）
  2. 如果有:
     a. 将被排除的交易填入 exclusion_proof.excluded_txs
     b. 设置 cumulative_gas_before
     c. 设置 reason = "BLOCK_GAS_LIMIT_EXCEEDED"
     d. 打包者对 proof 序列化数据签名
     e. 将签名存入 exclusion_proof.packager_signature
```

ExclusionProof 通过 `BlockMsg`（field 10）和 `BuildBlockBroadcastMsg`（field 11）传播，验证者可据此验证交易完整性。

#### 5.7.4 交易池大小限制

| 参数 | 值 | 说明 |
|------|------|------|
| `MAX_TX_POOL_SIZE` | 10000 | 普通交易池最大容量 |
| `MAX_CONTRACT_POOL_SIZE` | 5000 | 合约交易池最大容量 |

### 5.8 交易结构

交易使用 Protobuf 序列化：

```protobuf
message CTransaction {
  uint32 version            = 1;   // 交易版本
  uint64 time               = 2;   // 交易时间（微秒级时间戳）
  uint32 n                  = 3;   // 交易序号
  string identity           = 4;   // 打包节点身份
  string hash               = 5;   // 交易哈希
  uint32 consensus          = 6;   // 共识编号
  uint32 type               = 7;   // 交易类型（见附录 B）
  string data               = 8;   // 交易数据（JSON 格式）
  string note               = 9;   // 交易备注
  repeated CSign signature  = 10;  // 交易签名
  string reserve0           = 11;  // 预留字段 0
  string reserve1           = 12;  // 预留字段 1
  repeated CTxUtxos utxos   = 13;  // UTXO 列表
  uint32 independence       = 14;  // 交易独立性标志
  uint64 nonce              = 15;  // EVM 兼容 nonce
  string rlp                = 16;  // EVM 交易 RLP 编码
}
```

### 5.9 Merkle 根

Merkle 根计算方式详见 [5.3 节](#53-merkle-根)，采用双 SHA256 迭代归并方式。

### 5.10 UTXO 结构

```protobuf
message CTxUtxos {
  repeated string owner       = 1;  // 所有者地址列表
  repeated CTxInput vin       = 2;  // 输入列表
  repeated CTxOutput vout     = 3;  // 输出列表
  repeated CSign multisign    = 4;  // 多签列表
  string assettype            = 5;  // 资产类型
  int64 gas                   = 6;  // Gas 消耗
}

message CTxInput {
  repeated CTxPrevOutput prevOut = 1;  // 前向 UTXO 引用
  CSign vinSign                   = 2;  // 输入签名
  uint32 sequence                 = 3;  // 序列号
  string contractAddr             = 4;  // 合约地址（合约交易）
}

message CTxOutput {
  int64 value = 1;  // 输出值
  string addr = 2;  // 目标地址
}

message CTxPrevOutput {
  string hash = 1;  // UTXO 哈希
  uint32 n    = 2;  // UTXO 索引
}
```

### 5.11 交易哈希计算

交易哈希计算公式：
```
TxHash = SHA256(Serialize(Transaction without hash, signature, selection_vrf fields))
```

计算前 MUST 清除 `hash`、`signature`、`selection_vrf` 三个字段，确保哈希值不包含脏数据。所有交易哈希计算路径（RPC 提交、合约消息提交、区块打包等）MUST 使用一致的清除逻辑。

### 5.12 交易类型

完整的交易类型枚举见 [附录 B](#附录-b-交易类型枚举)。

主要分类：

| 类别 | 类型 | 说明 |
|------|------|------|
| 基础 | `GENESIS`, `TX` | 创世交易、普通转账 |
| 质押 | `STAKE`, `UNSTAKE` | 节点质押/解押 |
| 委托 | `DELEGATE`, `UNDELEGATE` | 委托/取消委托 |
| 合约 | `DEPLOY`, `CALL` | 部署/调用合约 |
| 投票 | `LOCK`, `UNLOCK`, `PROPOSAL`, `VOTE` | 投票权管理、提案、投票 |
| 奖励 | `BONUS`, `FUND` | 领取奖励、领取国库 |

### 5.13 交易生命周期

```
创建 → 签名 → 广播 → 验证 → 进入 Mempool → 打包 → 确认
```

#### 5.13.1 验证规则

交易在打包前 MUST 通过以下验证：

1. **超时验证**: `verifyTransactionTimeoutRequest(Tx)` - 交易时间不能超过 `KtxTimeout = 10秒`
2. **UTXO 高度验证**: `verifyTxUtxoHeight(Tx, txUtxoHeight)` - UTXO 高度必须有效
3. **双花检查**: `doubleSpendCheck(Tx)` - UTXO 未被消费
4. **签名验证**: 所有签名 MUST 有效
5. **资产类型验证**: 资产类型 MUST 有效且已批准
6. **Gas 验证**: 输入 Gas 必须足够
7. **质押/委托资格验证**: 根据交易类型验证前置条件

#### 5.13.2 交易独立性

`independence` 字段标识交易是否可独立执行：

| 值 | 含义 |
|----|------|
| `TX_INDEPENDENCE_FALSE` (0) | 依赖其他交易 |
| `TX_INDEPENDENCE_TRUE` (1) | 可独立执行 |
| `TX_INDEPENDENCE_NAN` (2) | 未知 |

#### 5.13.3 释放类交易的简化模型

UNSTAKE、UNLOCK、UNDELEGATE 三种释放类交易使用简化的交易构建模型，与普通交易的多 UTXO 搜索模式不同：

**核心特征**：

1. **单精确 UTXO 输入**: 直接使用指定的 `utxo_hash` 构建单个精确输入，不再通过 `TransferFromParam` / `createUtxoTransferFrom` 搜索多个 UTXO
2. **无 Gas 处理**: 三种交易均不涉及 Gas 计算、代付（`is_gas_tray`）或燃烧地址逻辑
3. **单输出**: 仅将原始金额返还给 `fromAddr`，无余额找零输出
4. **Nonce 防重放**: 通过 `DBReader::getNonceByAddr()` 获取地址级 nonce 并设置到交易中
5. **tx.data 元数据**: 以 JSON 格式存储操作信息

**tx.data 格式**：

| 交易类型 | tx.data 内容 |
|---------|-------------|
| UNSTAKE | `{"txInfo": {"unstakeUtxo": "<utxo_hash>"}}` |
| UNLOCK | `{"txInfo": {"unLockUtxo": "<utxo_hash>"}}` |
| UNDELEGATE | `{"txInfo": {"bonusAddr": "<to_addr>", "undelegatingUtxo": "<utxo_hash>"}}` |

**释放等待时间**：

| 常量 | 值 | 适用交易类型 |
|------|------|------------|
| `STAKE_RELEASE_WAIT_TIME` | 30 天 | UNSTAKE |
| `LOCK_RELEASE_WAIT_TIME` | 30 天 | UNLOCK |
| `DELEGATE_RELEASE_WAIT_TIME` | 1 天 | UNDELEGATE |
| `DEV_RELEASE_WAIT_TIME` | 1 分钟 | 所有类型（Dev 网络测试用） |

**哈希计算**: `tx.clear_hash()` → `tx.clear_signature()` → `SHA256(tx.SerializeAsString())` → `tx.set_hash()`

---

## 6. 共识机制（VRF）

### 6.1 概述

OpenHive 使用 VRF（Verifiable Random Function）共识机制，通过可验证随机函数在每个周期内随机选择打包节点和合约分发者。

VRF 周期为 **15 秒**，划分为三个阶段：VRF 广播（6s）、摘要交换与共识确认（4s）、共识计算（2s），外加 3 秒缓冲。调度者共识确认协议确保所有节点在同一周期内对 VRF 数据源达成一致，从而选出相同的合约分发者。

### 6.2 核心参数

| 参数 | 值 | 说明 |
|------|------|------|
| `CYCLE_DURATION_SECONDS` | 15 | VRF 完整周期（秒） |
| `PHASE1_DURATION` | 6 | 阶段1：VRF 广播（秒） |
| `PHASE2_DURATION` | 4 | 阶段2：摘要交换（秒） |
| `PHASE3_DURATION` | 2 | 阶段3：共识计算（秒） |
| `BUFFER_DURATION` | 3 | 缓冲时间（秒） |
| `kConsensus` | 7 | 最小共识节点数 |
| `send_node_threshold` | 15 | 区块流发送阈值 |
| `KReSend_node_threshold` | 15 | 重发节点阈值 |
| `MIN_UNSTAKE_HEIGHT` | 500 | 最小解押高度 |
| `MIN_STAKE_AMOUNT` | 3500 × 10⁸ | 最小节点质押量 |

### 6.3 VRF 周期机制

VRF 周期为 15 秒，划分为三个阶段。每个阶段的时间窗口由全局绝对时间驱动，所有节点同步切换。

```
周期 T（15 秒）:
 0s        6s       10s   12s  15s
 |--阶段1---|--阶段2--|--3--|--缓冲--|
  VRF 广播   摘要交换  共识计算
```

#### 6.3.1 阶段1：VRF 广播（0-6s）

每个周期起始时生成 VRF 种子：

```
seed = floor(current_time / CYCLE_DURATION_SECONDS) * CYCLE_DURATION_SECONDS
```

其中 `current_time` 为 UNIX epoch 秒数。

节点对种子进行签名生成 VRF 证明：

```
VRFConsensusInfo {
  vrfSeed: seed,
  blockinfo: [{blockHash[0:8], height}, ...],  // 最近 10 个区块
  Vrfsign: Sign(seed + blockinfo)
}
```

**签名范围**:
- VRF 种子
- 最近 10 个区块的哈希前 8 字符和高度

节点生成 `VRFConsensusInfo` 后广播给所有已知 peer。接收节点验证：
- 时间窗口：`|receivedSeedTime - generatedSeedTime| ≤ PHASE1_DURATION` (6 秒)
- 签名有效性：`VerifySign(VRFConsensusInfo)`
- 质押资格：`VerifyBonusAddr(nodeId)` 必须返回 true
- blockinfo 数量：必须等于 10

#### 6.3.2 阶段2：摘要交换（6-10s）

每个节点在阶段1结束后，广播一条 `VRFSummaryMsg`，声明"我在阶段1收到了哪些节点的 VRF"：

```protobuf
message VRFSummaryMsg {
  string seed = 1;                  // 周期标识
  repeated string received_node_ids = 2;  // 排序后的已收到 VRF 的节点地址列表
  bytes sign = 3;                   // 节点签名（防伪造）
}
```

摘要通过 gossip 扩散，接收方验签后存储并转发。摘要用于阶段3的共识计算。

**验证规则**:
- `received_node_ids` 大小不超过 VRF 条目数的 2 倍
- 签名必须有效
- 时钟偏差 > 2 秒的节点摘要被排除

#### 6.3.3 阶段3：共识计算（10-12s）

每个节点本地执行共识计算：

1. 遍历所有收到的摘要，统计每个地址被多少个摘要包含（`addrCounts`）
2. 根据**自适应阈值**筛选出共识集合（见 6.3.4 节）
3. 对边界条目做**确定性裁决**（见 6.3.5 节）
4. 排序输出共识候选集

所有节点使用相同的摘要集合和相同的阈值，算出相同的共识候选集，从而选出相同的分发者。

#### 6.3.4 自适应阈值算法

根据网络规模 N 分四档，带滞后区间防止档位振荡：

| 规模 | 阈值比例 | 允许缺失 | 示例 (N=100) |
|------|---------|---------|-------------|
| N >= 200 | 2/3 | N/3 | N=500 → threshold=334 |
| 50 <= N < 200 | 3/4 | N/4 | N=100 → threshold=75 |
| 20 <= N < 50 | 4/5 | N/5 | N=30 → threshold=24 |
| N < 20 | 9/10 | N/10 | N=10 → threshold=9 |

滞后区间 (`HYSTERESIS_MARGIN = 5`): 在档位边界 ±5 范围内保持上一档位不变，避免振荡。

#### 6.3.5 边界确定性裁决

当某地址的 count 在 `threshold - BOUNDARY_DELTA` 到 `threshold` 之间时（`BOUNDARY_DELTA = 2`），使用确定性裁决：

```
裁决种子 = SHA256(VRF_seed + cycle_number)
对每个边界地址 addr:
  hash = SHA256(裁决种子 + addr)
  if hash 最后一字节为偶数 → 纳入共识集
  if hash 最后一字节为奇数 → 排除
```

这保证所有节点对边界条目做出相同裁决。

#### 6.3.6 时间驱动的多级降级

降级由全局绝对时间驱动（非本地状态），所有节点同步降级：

| Level | 时间段 | 行为 |
|-------|--------|------|
| 0 | 0-15s | 正常模式，动态安全阈值 |
| 1 | 15-20s | threshold 降低 10% |
| 2 | 20-25s | threshold 降到 max(N/2, 1) |
| 3 | >25s | 放弃确认，回退到原始 VRF 数据 |

共识集大小低于 `max(kConsensus=7, send_node_threshold=15) = 15` 时，清空共识集并回退到原始 VRF 数据。

#### 6.3.7 安全机制

- **分区检测**: 覆盖率 = 摘要数/VRF数，低于 `PARTITION_COVERAGE_THRESHOLD = 0.60` 时判定为网络分区，不产出区块
- **时钟偏差检测**: 偏差 > `CLOCK_SKEW_TOLERANCE = 2` 秒的节点标记为时钟异常，其摘要被排除在共识计算之外
- **冷启动处理**: 新节点第一个完整周期只收集不选择
- **摘要大小验证**: `received_node_ids` 超过 VRF 条目数 2 倍的摘要被拒绝

### 6.4 准入池筛选（Entry Pool）

在打包节点选择之前，系统通过准入池机制对参与共识的节点进行预筛选，确保只有满足条件的节点才能进入出块候选集。

#### 6.4.1 两阶段筛选流程

节点筛选分为两个阶段：

```
Stage 1 — 准入池过滤（Entry Pool）:
  1. 计算 VRF 随机阈值:
     vrfThreshold = computeVRFThreshold(dataSource)
     - 将所有节点的签名哈希拼接后做 SHA256
     - 取哈希第 1 字节 (0-255)，除以 255.0 映射到 [0.0, 1.0]
  2. 全员白名单快速路径:
     - 如果 dataSource 中所有节点都在 genesis.vrfWhitelist 中，跳过准入池过滤
  3. 对每个节点计算质押概率:
     stakeProb = calculateStakeProbability(nodeId)
  4. 筛选: stakeProb >= vrfThreshold 的节点进入准入池
  5. 若准入池节点数 >= kConsensus (3)，替换数据源；否则回退到全部节点

Stage 2 — 频率筛选 + 随机选取（见 6.5 节）:
  对通过准入池的节点按频率筛选，最终随机选出 kConsensus 个出块节点
```

#### 6.4.2 质押概率计算

```
calculateStakeProbability(nodeId):
  1. 白名单检查:
     - 如果 nodeId 在 genesis.vrfWhitelist 中，返回 1.0（100% 准入）
  2. 质押时间查询:
     - 获取节点质押时间 pledgeTime
     - 如果 pledgeTime <= 0，返回 0.0（未质押）
  3. 概率计算:
     days = (current_time - kEntryPoolReferenceTimestamp) / 86400
     prob = kEntryPoolInitialProb + days × kEntryPoolDailyIncrement
     返回 min(prob, 1.0)
```

**概率参数**:

| 参数 | 值 | 说明 |
|------|------|------|
| `kEntryPoolInitialProb` | 0.50 | 初始概率 50% |
| `kEntryPoolDailyIncrement` | 0.025 | 每日递增 2.5% |
| `kEntryPoolReferenceTimestamp` | 1741996800 | 基准时间（2026-03-15 00:00:00 UTC） |

概率从 50% 起始，每天递增 2.5%，约 20 天后达到 100%。这意味着网络初期准入较宽松，随时间推移逐步放开。

#### 6.4.3 VRF 白名单

Genesis 配置支持 `vrfWhitelist` 字段，白名单中的地址在准入池筛选中始终以 100% 概率通过：

```json
{
  "genesis": {
    "vrfWhitelist": ["addr1", "addr2"]
  }
}
```

白名单通过 `Genesis::GetVRFWhitelist()` 读取，用于在网络初期保障核心节点的共识参与。

### 6.5 打包节点选择算法

#### 6.5.1 频率计算

```
computeMaxHeightWithMinFrequency():
  1. 数据源选择: 取 validatedVRfs 中倒数第 3 个周期的数据
  2. 哈希计数:
     - 遍历该周期所有节点，统计每个高度 h 下各区块哈希 hash 的出现次数 count(h, hash)
     - 记录每个节点报告的哈希集合 nodeHashes[node]
  3. 计算哈希占比:
     ratio(h, hash) = count(h, hash) / totalNodes
  4. 计算高度平均占比:
     avgRatio(h) = sum(ratios(h)) / len(ratios(h))
  5. 计算最优频率 (Optimal Frequency):
     optimalFrequency = sum(avgRatio(h) * h) / sum(h)
  6. 筛选最优哈希:
     optimalHashes = { hash | ratio(h, hash) >= optimalFrequency }
  7. 计算节点匹配度:
     matchCount(node) = |nodeHashes[node] ∩ optimalHashes|
     nodeFrequency(node) = matchCount(node) / |optimalHashes|
  8. 动态筛选合格节点:
     - validateNodeThreshold = totalNodes * 0.55 (硬编码，不可配置)
     - 初始 frequencyThreshold = 1.0
     - 循环:
       若 nodeFrequency(node) >= frequencyThreshold，则节点合格
       若 qualifiedNodes.size() < validateNodeThreshold 且 frequencyThreshold > 0:
         frequencyThreshold -= 0.1
         继续循环
     - 合格节点存入 newValidatedVRfs，并记录其频率 addFrequency(frequency)
```

#### 6.5.2 随机选择

```
extractPackagerVRFData(nodes, timestamp):
  1. 获取前一周期种子
  2. 从 newValidatedVRfs 或 validatedVRfs 提取数据源
  3. 按频率升序排序
  4. 筛选合格节点（频率 ≥ maxValue）
  5. 如果节点数 < kConsensus，降低 maxValue 重新筛选
  6. 从筛选后的数据源中随机选择 kConsensus 个节点
```

随机选择使用 SHA256 哈希所有签名哈希的组合作为种子：

```
sumSeed = Σ(VRFStructure.getSignatureHash())
seed = SHA256(sumSeed)
nodes = shuffleAndSelect(dataSource, seed, kConsensus)
```

#### 6.5.3 异常节点检测与奖励惩罚机制

节点在周期内的签名工作量直接影响其奖励分配。系统通过 `fetchAbnormalSignAddrListByPeriod` 函数检测表现不佳的节点，并在奖励申领（`CalcBonusValue`）时应用惩罚。

```
fetchAbnormalSignAddrListByPeriod(curTime, addr_percent, addrSignCount):
  1. 获取前一周期 (period - 1) 所有参与签名的地址列表
  2. 遍历每个地址，获取其签名次数 signNumber
  3. 计算总签名数 allSignNumber 和平均签名数 average = allSignNumber / addrSignCount.size()
  4. 遍历所有节点：
     - 如果 own_count >= average: 节点合格，跳过
     - 如果 own_count < average: 节点不合格
       计算分红比例 dividendRate = own_count / average
       将 (addr, dividendRate) 存入 addr_percent 容器
```

奖励分配逻辑 (`CalcBonusValue`):
  - 如果节点在 `addr_percent` 中 (dividendRate != 0.0):
    实际奖励 = dividendRate × (年化率 × 委托金额 / 365)
  - 如果节点合格 (isQualified == true):
    实际奖励 = 年化率 × 委托金额 / 365
  - 如果节点不在任何列表中:
    返回错误，节点无资格申领奖励

**惩罚效果**: 签名工作量低于平均水平的节点，其奖励将按实际工作量占比（`own_count / average`）同比例扣减，以此激励节点保持高可用性。

#### 6.5.4 合约分发者选择（Dispatcher Selection）

合约分发者通过 `calculatePackerByTime()` 从共识确认后的 VRF 数据源中选出。分发者负责接收用户合约交易、排序并注入系统交易（EVIDENCE/PUNISHMENT），最终构造合约打包消息。

分发者选择使用 SHA256 哈希所有共识候选集的签名哈希组合作为种子：

```
sumSeed = Σ(consensusCandidate.getSignatureHash())
seed = SHA256(sumSeed)
dispatcher = selectFromConsensusSet(seed)
```

由于所有节点通过 §6.3 的共识确认协议得到相同的共识候选集，因此选出相同的分发者。

分发者选择后，通过 `BuildBlockBroadcastMsg` 和 `BlockMsg` 中的 `dispatcher_vrf` 字段携带 RFC 9381 ECVRF 证明，验证者可通过 `VerifyContractDispatcherSelectionProofJson()` 验证分发者身份的合法性。

### 6.6 区块签名验证

区块打包后，打包节点对区块进行签名：

```
AddBlockSign(block):
  1. 获取当前周期选中的打包节点列表
  2. 打包节点对区块序列化数据签名
  3. 将签名附加到 block.signature 列表

VerifyBlockSign(block):
  1. 重新计算打包节点列表
  2. 验证每个签名的有效性
  3. 验证签名节点是否为合法打包节点
  4. 签名数量必须 ≥ kConsensus
```

### 6.7 共识数据存储

VRF 数据存储在内存中，维护两个映射表：

```cpp
validatedVRfs:   map<seed, map<nodeId, VRFStructure>>   // 已验证数据
newValidatedVRfs: map<seed, map<nodeId, VRFStructure>>  // 新验证数据
```

数据修剪规则：
- 当 `validatedVRfs.size() > MAX_VRFS_SIZE (10)` 时，删除最旧的数据

### 6.8 拜占庭容错

区块同步时使用拜占庭容错检查：

```
checkByzantineFault(receiveCount, hitCount):
  当 hitCount / receiveCount < 阈值时，判定可能存在拜占庭节点
```

### 6.9 惩罚机制概述

OpenHive 实现五级惩罚体系（L0-L4），从轻到重逐级升级，覆盖从奖励扣减到永久除名的完整惩罚梯度。

| 等级 | 名称 | 触发条件 | 效果 |
|------|------|----------|------|
| L0 | 奖励扣减 | 签名量低于平均值 | 按 `own_count / average` 比例扣减当期奖励（见 6.5.3 节） |
| L1 | Jailing | 连续缺席 ≥ 8640 周期(24h) 或连续 2 周期签名率 < 50% 平均值 | 暂停共识参与资格，不扣质押 |
| L2 | Forfeit | 关押超 2880 周期(8h) 或每小时断连 ≥ 10 次 | 当期奖励全部没收 |
| L3 | Stake Slash | 累计 3 笔 EVIDENCE 交易上链（非双签类型） | 按递增比率扣减自有质押：1% → 3% → 5% |
| L4 | Tombstone | 累计 5 笔 EVIDENCE 交易上链（双签类型）或 L3 扣减后剩余质押 < MIN_STAKE_AMOUNT | 永久除名，移除质押资格，退回所有委托 |

**Jailing 释放条件**:
- **自动释放**: 关押 ≥ `kJailAutoReleasePeriods = 100` 个周期后自动释放
- **手动释放**: 连续 `kJailManualReleasePeriods = 5` 个正常签到周期后释放
- **归档释放**: 缺席 > `kSlashArchivePeriods = 60480` 周期(7天) 时从 Jailing 释放

**节点状态过滤**: Jailed 和 Tombstoned 节点在 VRF 打包者选择时被自动过滤。Tombstoned 节点禁止重新质押。

### 6.10 证据检测与提交

系统支持三种违规类型的自动检测，检测后构造证据消息单播给当前分发者。

#### 6.10.1 违规类型

| 类型 | 说明 | 检测位置 | payload 校验规则 |
|------|------|----------|-----------------|
| `DOUBLE_SIGN_VRF` | 同一地址对同一 seed 产生两个不同 VRF 签名 | `vrf_consensus.cpp` | seed、两个不同 VRF 签名 |
| `DOUBLE_SIGN_BLOCK` | 同一地址在同一高度签了不同区块 | `algorithm.cpp` (SaveBlock) | 非零 height、两个不同 64 字节区块 hash |
| `LOW_SIGN_RATE` | 节点签名率持续低于阈值 | `algorithm.cpp` (每 100 周期检查) | valid_periods ≥ 50, sign_rate < 50% |

#### 6.10.2 证据提交流程

```
检测层发现作弊:
  1. 构造 SlashEvidenceMsg:
     {
       violation_type: 违规类型
       target_addr: 被举报地址
       evidence_data: 违规证据 (JSON)
       reporter_addr: 举报者地址
       period: 当前周期
     }
  2. 举报者对消息签名
  3. 随机退避 (0 ~ kSlashEvidenceMaxDelayMs=3000ms)
  4. 单播发送给当前分发者
```

退避机制用于避免大量举报同时到达导致分发者过载。

### 6.11 证据池与共识

分发者接收证据消息后，存入 `SlashEvidencePool` 进行聚合和共识判定。

#### 6.11.1 分发者接收流程

```
HandleSlashEvidenceMsg(msg):
  1. 验证 reporter 签名有效性
  2. 独立验证违规事实 (IndependentlyVerifyViolation):
     - DOUBLE_SIGN_VRF: 验证两个签名存在且不同
     - DOUBLE_SIGN_BLOCK: 验证两个区块哈希存在且不同
     - LOW_SIGN_RATE: 验证签名率低于阈值且有足够数据 (≥ 50 周期)
  3. 按 evidence_hash 聚合签名（同一 reporter 不重复计数）
  4. 签名数达到 kSlashEvidenceQuorum (= kConsensus = 7) 时标记 consensusReached = true
```

#### 6.11.2 证据池行为

- `buildEvidenceTransactions()`: 为所有 `consensusReached == true` 的证据构造 EVIDENCE 交易
- `buildPunishmentTransactions()`: 为达到惩罚阈值的节点构造 PUNISHMENT 交易
- 每周期最大举证数: `kSlashEvidenceMaxPerPeriod = 20`
- 举证去重窗口: `kSlashEvidenceDedupWindow = 60000ms`

**恶意举报者检测**: 有效举报率低于 `kSlashAbuseThresholdRate = 10%` 且总举报数 ≥ `kSlashAbuseMinReports = 5` 的 reporter 被标记为恶意举报者。

### 6.12 链上验证

EVIDENCE 和 PUNISHMENT 交易在打包和验证时经过严格的链上验证。

#### 6.12.1 EVIDENCE 交易验证 (`ValidateSlashEvidenceTx`)

- JSON 格式校验，必填字段完整性
- `evidence_hash` 与 payload 内容匹配
- payload 结构校验（根据违规类型）
- 签名数 ≥ `kSlashEvidenceQuorum` (3)
- 签名者为不重复的当前质押节点

#### 6.12.2 PUNISHMENT 交易验证 (`ValidateSlashPunishmentTx`)

- 必填字段完整性
- `penalty_level` 只能为 3 或 4
- `punishment_id` 确定性匹配:
  ```
  punishment_id = SHA256(target_addr + "|" + violation_type + "|" + penalty_level + "|" + SHA256(evidence_refs))
  ```
- 分发者签名有效
- threshold 状态一致
- `stake_refs` 快照匹配
- history 幂等检查（防止重复惩罚）

### 6.13 惩罚执行与回滚

#### 6.13.1 L3 质押扣减 (Stake Slash)

```
ExecuteL3Punishment(tx):
  1. 从 stake_refs 快照读取原质押总额
  2. 根据历史扣减次数确定比率:
     - 第 1 次: kSlashRateFirst = 1%
     - 第 2 次: kSlashRateSecond = 3%
     - 第 3 次及以后: kSlashRateThird = 5%
  3. 计算扣减量 = 原质押总额 × 比率
  4. 删除原 stake UTXOs
  5. 若剩余质押 ≥ MIN_STAKE_AMOUNT (3500 OHI):
     - 创建 tx.hash() + "_remaining" 合成 stake 交易和 UTXO
  6. 若剩余质押 < MIN_STAKE_AMOUNT:
     - 升级为 L4 (Tombstone)
```

#### 6.13.2 L4 永久除名 (Tombstoning)

```
ExecuteL4Punishment(tx):
  1. 写入 slash_tombstone_{addr} 永久标记
  2. 删除所有 stake UTXOs 和 stake address
  3. 遍历该节点的委托关系:
     - 为每个委托者创建退款 UTXO
     - 更新委托者余额
  4. 保存退款快照到 PunishmentDelegationRefunds（用于回滚）
```

#### 6.13.3 回滚机制

PUNISHMENT 交易支持完整回滚：

- **L3 回滚**: 恢复 `stake_refs` 中的原始 UTXOs，删除 `_remaining` 合成 UTXO，递减 slash count
- **L4 回滚**: 移除 tombstone 标记，恢复质押 UTXOs 和地址，根据退款快照反向恢复委托关系和余额

---

## 7. 执行层（EVM + 智能合约）

### 7.1 概述

OpenHive 集成 **evmone** 作为 EVM 执行引擎，遵循 EVMC (Ethereum Virtual Machine Connector) 接口，提供与以太坊兼容的智能合约执行环境。

### 7.2 EVM 架构

```
┌───────────────────────────────────────┐
│         Contract Dispatcher           │
│  (依赖管理、预哈希验证、调度)          │
├───────────────────────────────────────┤
│            EvmHost                    │
│  (实现 evmc::Host 接口)               │
│  - account_exists()                   │
│  - get_storage() / set_storage()      │
│  - get_balance()                      │
│  - get_code_size() / get_code()       │
│  - call()                             │
│  - emit_log()                         │
├───────────────────────────────────────┤
│            evmone                     │
│  (EVM 字节码执行引擎)                 │
├───────────────────────────────────────┤
│         Precompiles                   │
│  - 标准预编译 (EIP-152, EIP-196...)   │
│  - SilkPre 预编译                     │
│  - 预编译结果缓存                     │
├───────────────────────────────────────┤
│         MPT (Contract State)          │
│  (合约状态 Merkle Patricia Trie)      │
└───────────────────────────────────────┘
```

### 7.3 EVM 环境上下文

EVM 执行环境提供以下区块上下文信息：

```cpp
EvmEnvironment {
  blockTimestamp: U64,       // 当前区块时间戳
  blockPrevRandao: Bytes32,  // 前一区块随机数（VRF 种子）
  blockNumber: U64,          // 当前区块高度
  blockHash: Bytes32,        // 当前区块哈希
  chainId: U64,              // 链 ID
  gasPrice: U64,             // Gas 价格
}
```

**注意**: `blockPrevRandao` 并非直接使用 VRF 种子。当前实现基于发送者 UTXO 的交易哈希 ASCII 值之和计算，存在精度截断（`int64_t` → `uint32_t` → `evmc_uint256be`），高位全为零。该值高度可预测，与以太坊的 VRF-based prevRandao 语义不同。

### 7.4 EvmHost 接口实现

`EvmHost` 继承自 `evmc::Host`，提供 EVM 执行所需的宿主环境：

| 方法 | 说明 |
|------|------|
| `account_exists(addr)` | 检查账户是否存在 |
| `get_storage(addr, key)` | 读取合约存储 |
| `set_storage(addr, key, value)` | 写入合约存储 |
| `get_balance(addr)` | 查询账户余额 |
| `get_code_size(addr)` | 获取合约代码长度 |
| `get_code(addr)` | 获取合约代码 |
| `call(msg)` | 执行调用/创建 |
| `emit_log(addr, data, topics)` | 发射日志事件 |

### 7.5 合约交易流程

#### 7.5.1 部署合约（DEPLOY）

```
1. 创建 DEPLOY 类型交易
   - data: 包含合约字节码和部署参数（JSON）
   - utxos: 支付部署 Gas 的 UTXO
2. 验证交易并计算合约地址
3. 执行 EVM 初始化代码
4. 保存合约代码到数据库
5. 初始化合约 MPT 状态
6. 记录部署者地址 → 合约地址映射
```

**合约地址生成算法**：

合约地址生成遵循 **以太坊 EIP-161** 标准，使用 RLP 编码和 Keccak-256 哈希：

```
GenerateContractAddrEth(sender_address, nonce):
  1. 将部署者地址解析为 20 字节数组
     sender_bytes = HexToBytes(sender_address)   // 20 字节

  2. RLP 编码 [sender_address, nonce]
     rlp_data = RLP([sender_bytes, nonce])
     - sender_address: 20 字节地址
     - nonce: 部署者账户的 nonce 值（U64）
     - 编码格式：RLP 列表

  3. Keccak-256 哈希
     hash = Keccak256(rlp_data)   // 32 字节

  4. 取末 20 字节作为合约地址
     contract_addr = hash[12:32]   // 跳过前 12 字节，取后 20 字节

  5. 返回十六进制地址（不带 0x 前缀，小写）
```

**示例**：
```
部署者地址: 0x1234567890abcdef1234567890abcdef12345678
Nonce:      0
RLP 编码:   0xd6941234567890abcdef1234567890abcdef1234567880
Keccak256:  0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890
合约地址:   0x34567890abcdef1234567890abcdef1234567890
```

**实现细节**：
- 函数：`evm_utils::GenerateContractAddrEth(sender_address_checksum, nonce)`
- 哈希函数：Keccak-256（与以太坊兼容）
- 编码格式：RLP（Recursive Length Prefix）
- 地址格式：40 字符十六进制（小写，不带 0x 前缀）
- 校验和：可选使用 `ToChecksumAddress` 转换为 EIP-55 格式

#### 7.5.2 调用合约（CALL）

```
1. 创建 CALL 类型交易
   - data: 包含调用方法签名和参数（RLP 编码）
   - utxos: 支付调用 Gas 的 UTXO
2. 验证交易
3. 加载合约代码和状态
4. 执行 EVM 调用代码
5. 更新合约 MPT 状态
6. 处理返回值和日志
```

> **合约调用金额验证**: 合约调用时 `money` 参数不再进行金额范围校验（`validateAmount` 已注释），允许更灵活的金额传入。

#### 7.5.3 合约池保留机制

当合约交易打包遇到可恢复的失败时，系统保留合约池缓存而非无条件清除，以便下次重试：

**保留条件**:
- `fetchContractTxPreHash` 失败
- `newSeekContractPreHash` 失败
- `BuildBlock` 返回可恢复错误码（-103, -104, -105）

**清除条件**: 其他不可恢复的失败仍会清除 `_contractCache` 和 `contractInfoCache`。

交易结构新增 `known_top` 字段，允许交易携带已知区块高度，避免重复查询。

#### 7.5.4 合约授权批次的原子性与 Nonce

合约分发者按依赖关系形成交易组，并用 `dispatcher_vrf` 绑定原始授权集合和既定打包者。打包和重试 MUST 保持以下不变量：

1. 未经证明不得从授权集合删除交易；批次中任意普通验证或合约执行失败时，候选批次整体失败。
2. 实际包含集合与有效排除证明集合的并集 MUST 严格等于原授权集合，且三者不得包含重复项或交集。
3. 同一账户的批内交易按 `(tx.time, tx.hash)` 规范顺序验证连续 nonce；验证以数据库已确认 nonce 为起点，拒绝重复、旧 nonce、跳号和倒序。
4. 数据库存储 nonce 时按每笔已接受交易推进，并使用既有 undo 数据在回滚时恢复；不得以批次大小盲目计数。
5. 未来 nonce 批次 MUST 整批等待，不能拆分或越过同账户较早批次。初始资源限制为：nonce gap 1024、单账户16个等待批次、全局4096笔、64MiB、资源 TTL 10分钟。
6. 若原批次的交易已经在候选父块祖先链确认，只能使用绑定原交易、确认区块高度/哈希、交易索引、候选父块、原 VRF 摘要及集合摘要的已确认排除证明。证明不完整时 MUST 拒绝缩减批次。

等待和排除机制不得创建新的分发者授权，不得更改交易正文、排序、分发者或原打包者。若重试期间 VRF 候选上下文因 jailed/tombstoned 等原因变化，当前实现直接放弃，不退回分发者创建新轮次。

#### 7.5.5 Pending Nonce 与 Pending UTXO

交易发起端维护本地线程安全的 nonce/UTXO 原子预留。正式预留以最终交易哈希为标识，绑定账户、nonce、完整 `(asset_type, prevout.hash, prevout.n)` 输入集合及规范交易正文承诺。规则如下：

- 并发构造 MUST 在同一临界区分配唯一连续 nonce 并检查 UTXO 冲突；候选过滤只是性能优化，最终 `Reserve` 仍是冲突判定点。
- 合约构造早期使用 `draft_` 草稿预留；所有错误路径 MUST 自动释放。网络发送前 MUST 将草稿原子接管为最终交易哈希，接管或持久化失败时不得发送。
- 相同最终交易的重复请求只有在账户、nonce、输入集合和承诺全部一致时才允许幂等通过。
- 节点启动时恢复正式预留。普通交易共识有效期为10秒，`CALL/DEPLOY` 为30秒；正式预留超过共识截止后仍需等待30秒传播宽限。
- 超期自动释放前 MUST 存在对等节点、本机高度不低于网络参考高度；本机查到交易时按确认释放，本机未查到时必须确认全部预留输入仍可在本地未花费状态中读取。状态不确定时保持冻结并输出诊断，不得仅按 TTL 盲目释放。
- 区块数据库提交成功后，MUST 先删除持久化记录，再释放内存预留，避免崩溃重启后遗失未完成状态。

`eth_getTransactionCount(latest)` 返回数据库已确认 nonce；`pending` 返回从已确认值开始连续占用后的下一个本地 nonce。它不得被不连续的超大未来 nonce 推进。

#### 7.5.6 父块围栏与重新打包

打包节点执行合约授权批次前捕获 `(height, hashes_at_height)` 作为父状态快照。每次尝试在执行前、生成 prehash 前、建块后及区块处理失败后重新读取并比较：

```text
高度不同                 → stale parent
高度相同但哈希集合不同     → stale parent
任一快照不可读取           → 不安全，终止
高度及规范化哈希集合相同   → 允许继续
```

仅建块返回 `-103/-104/-105` 和内部 stale-parent `-106` 属于可恢复错误。快速重试参数为：

| 参数 | 当前值 | 语义 |
|---|---:|---|
| 最大 attempt | 3 | 包含第一次执行 |
| attempt 1→2 退避 | 50ms | 有界竞争退避 |
| attempt 2→3 退避 | 100ms | 有界竞争退避 |
| 合约有效期 | 30s | 从原交易时间计算，不刷新 |
| 延迟重试保护窗口 | 2s | 距最早截止不足2秒时不再开始 |

每次重试 MUST：保留原始 `TxMsgReq`、清除本轮派生执行缓存、读取最新父状态、复验原 `dispatcher_vrf`，并重新生成候选块及 `validator_vrf`。不得修改交易时间、交易正文或原授权集合。三次快速重试耗尽后，仅可恢复错误可将未经修改的完整 `ContractPackagerMsg` 原子持久化到既有等待队列；队列写入失败不得报告已接收。

#### 7.5.7 精确 VIN 验证边界

发起端选择 UTXO 时会排除本机 pending 预留，但 pending 是节点本地瞬时状态，MUST NOT 成为验证者重建合约输出的共识输入。验证端执行规则为：

1. 按原交易中的 asset、owner、VIN 和 prevout 精确读取候选父状态金额，不重新运行选币算法。
2. 拒绝空输入、重复输入、缺失或已花费输入、owner/VIN 结构不一致、金额/Gas 不足及整数溢出。
3. 同一 UTXO 组多 owner 时按 owner/VIN 对应项处理；单 owner 多 VIN 时保留其全部 VIN。
4. 使用精确输入金额重新生成合约输出并与原交易比较。输入仍未花费时重打包可恢复；输入已花费时安全失败，不得换用其他输入继续原授权交易。

因此，UTXO 选币策略属于交易创建策略，而交易携带的精确 VIN 及父状态有效性才是验证依据。索引、分页、best-fit 或 pending 集合的本地差异不得改变已签名交易的验证结果。

#### 7.5.8 菜单33压力测试的有界等待

高级菜单 `33. test contracl pool` 是测试工具而非通用 RPC 语义。它在遇到 `PENDING_UTXO_WAIT` 时最多等待10秒：每100ms检查区块高度，发现高度变化立即重新构造；无高度变化时每1秒兜底重试。每次重试读取最新高度、使用空交易对象并重新执行完整预留流程，绝不复用半成品或绕过冲突检查。

10秒到期后任务记录 `pressure task expired` 并结束。发送窗口结束后测试工具等待所有创建/重试线程退出，再开始合约报告的35秒结算观察。普通菜单和 RPC 不隐式等待，以免引入请求超时、重复提交和调用方状态歧义。

该方案在16节点同机测试环境完成连续两轮30秒、30TPS回归，两轮均为900/900；精确 VIN 修复前的对照轮为成功创建840、上链840、60次因 pending 未发送。

### 7.6 合约依赖管理与验证流程

合约交易可能依赖其他合约的状态，通过 `EvmHost` 和 `ContractDispatcher` 协同管理依赖关系和状态验证。

#### 7.6.1 合约调用依赖验证流程（`EvmHost::call`）

当 EVM 执行合约调用（`CALL`、`CALLCODE`、`DELEGATECALL`、`STATICCALL`）或创建（`CREATE`、`CREATE2`）时，执行以下依赖验证和状态加载流程：

```
EvmHost::call(msg):
  1. 记录访问与调用:
     - recordAccountAccess(msg.recipient)
     - 将 msg 存入 recorded_calls 和 callInputsRecorded

  2. 自毁状态检查:
     - 遍历 recorded_selfdestructs
     - 如果 msg.code_address 已被自毁，返回 EVMC_FAILURE

  3. 价值转移处理:
     - 解析 msg.value 获取转移金额
     - 调用 getContractTransfer(amount, fromAddr, toAddr, ongoingTransfer)
     - 验证余额充足性，更新 coinTransfersInProgress

  4. 预编译合约优先执行:
     - 调用 evmone::state::call_precompile(MAX_REVISION, msg)
     - 如果命中预编译，直接返回结果，跳过后续加载

  5. 合约代码加载:
     - 检查 createdContract 缓存（本次交易新创建的合约）
     - 如果不在缓存中，调用 evm_utils::GetContractCode 从数据库加载
     - 如果代码为空或加载失败，返回 EVMC_FAILURE

  6. MPT 状态加载与根哈希验证（核心依赖验证）:
     - 如果是 EVMC_CALL 且 !new_contract 且 !loadedContract:
       a. 调用 fetchContractRootHash(contractAddress, rootHash, contractDataStorage)
          获取合约当前 MPT 根哈希
       b. 检查 accounts[msg.recipient].storageRoot 是否已初始化
       c. 如果未初始化，调用 CreateTrie(rootHash, contractAddress, contractDataStorage)
          从 contractDataStorage 加载完整 MPT 状态树
       d. 将 contractAddress 加入 loadContract 集合，防止重复加载

  7. EVM 字节码执行:
     - 创建 evmc::VM 实例 (evmc_create_evmone)
     - 调用 vm.execute(*this, MAX_REVISION, msg, code.data(), code.size())
     - 捕获执行结果和输出数据

  8. 返回执行结果:
     - 成功返回 EVMC_SUCCESS 及输出
     - 失败返回 EVMC_FAILURE 及错误信息
```

#### 7.6.2 依赖验证关键点

| 验证步骤 | 验证内容 | 失败处理 |
|---------|---------|---------|
| 自毁检查 | 目标合约未被标记为自毁 | 直接返回失败，阻止调用 |
| 余额验证 | `getContractTransfer` 确保转账金额充足 | 余额不足返回失败 |
| 预编译优先 | 检查是否为 0x01-0x09 预编译地址 | 命中则直接执行，不加载用户代码 |
| 代码存在性 | 合约代码非空且可加载 | 代码为空返回失败 |
| MPT 根哈希验证 | `fetchContractRootHash` 获取有效根哈希 | 获取失败返回失败 |
| 状态树初始化 | `CreateTrie` 确保 MPT 状态正确加载 | 初始化失败影响后续存储读写 |
| 防重复加载 | `loadContract` 集合记录已加载合约 | 避免重复 I/O 和状态覆盖 |

#### 7.6.3 合约创建依赖处理（`CREATE` / `CREATE2`）

合约创建不依赖现有 MPT 状态，但需要处理 nonce 和地址生成：

```
CREATE 流程:
  1. nonceCache++ (本地 nonce 递增)
  2. 调用 GenerateContractAddrEth(fromAddr, nonceCache) 生成新地址
  3. 调用 createContract(msg, amount, fromAddr, contractAddress)
  4. 执行初始化代码获取 runtimeCode
  5. 将 runtimeCode 存入 createdContract 缓存
  6. 初始化新合约的 MPT 状态 (CreateTrie with empty root)

CREATE2 流程:
  1. nonceCache++
  2. 调用 calculateCreate2Address(msg) 生成确定性地址
     - 使用 sender + salt + initCodeHash 计算
  3. 后续流程同 CREATE
```

#### 7.6.4 依赖广播与共识

打包节点在打包合约交易时，需广播依赖关系供其他节点验证：

```protobuf
ContractDependencyBroadcastMsg {
  version: string
  dependencies: [
    {
      dependencyAddress: string   // 依赖的合约地址
      txHashes: [string]          // 相关的交易哈希列表
    }
  ]
  sign: CSign                     // 打包节点签名
}
```

接收节点验证流程：
1. 验证签名有效性
2. 检查依赖合约的 `rootHash` 是否与本地一致
3. 如果一致，接受该区块；如果不一致，触发分叉解决流程

#### 7.6.5 依赖验证与交易缓存机制（`DependencyManager` & `ContractTransactionCache`）

合约交易在发送前，必须通过 `DependencyManager` 的依赖冲突检查。如果存在依赖冲突，交易将被缓存并在条件满足时重试发送。

**1. 依赖检查流程 (`DependencyManager::CanSendTransaction`)**：
```
CanSendTransaction(msg):
  1. 解析 msg 获取交易哈希 tx_hash 和依赖地址列表 contractstoragelist
  2. 如果依赖列表为空，直接返回 true (允许发送)
  3. 遍历每个依赖地址 addr:
     - 查询 dependency_tx_hashes_[addr] (当前正在处理该地址依赖的交易哈希列表)
     - 如果列表非空，说明存在依赖冲突，返回 false (禁止发送)
  4. 所有依赖地址均无冲突，返回 true
```

**2. 交易缓存与重试机制 (`ContractTransactionCache`)**：
当 `CanSendTransaction` 返回 false 时，交易不会丢弃，而是存入缓存：
```
AddFailedTransaction(tx, msg):
  1. 检查 tx.hash() 是否已在缓存中
  2. 如果不在，创建 CachedTransaction 对象并存入 _cachedTransactions
  3. 记录当前时间戳 timestamp
```

缓存检查定时器 (`_CheckCachedTransactions`，每 1 秒执行一次)：
```
_CheckCachedTransactions():
  1. 遍历 _cachedTransactions 中的交易
  2. 计算交易在缓存中的停留时间 timeInCache
  3. 强制发送策略:
     - 如果 timeInCache >= FORCE_SEND_TIMEOUT (15 秒):
       发布 "TransactionConfirmed" 事件清理依赖
       立即发送该交易
  4. 依赖解除策略:
     - 调用 DependencyManager::CanSendTransaction(msg) 重新检查
     - 如果返回 true，说明依赖已解除，发送该交易
  5. 发送成功后，从缓存中移除该交易
```

**3. 依赖清理机制 (`EventManager` & `ClearDependency`)**：
```
DependencyManager::ClearDependency(tx_hash):
  1. 遍历 dependency_tx_hashes_ 中的所有地址
  2. 从每个地址的交易哈希列表中移除 tx_hash
  3. 如果某地址的哈希列表变为空，从 dependency_tx_hashes_ 中删除该地址条目
```

**4. 发送前交易更新 (`_SendCachedTransaction`)**：
从缓存发送交易前，会更新交易的时间和身份：
```
_SendCachedTransaction(cachedTx):
  1. 更新 tx.time 为当前 UTC 时间戳
  2. 调用 get_contract_distribution_manager 重新计算 tx.identity (打包节点)
  3. 重新计算 tx.hash (清空旧 hash 和 signature)
  4. 调用 contractTransactionRequest 发送交易
  5. 通知 BlockMonitor 记录该交易
```

**设计目的**:
- 防止同一合约地址的并发交易产生状态冲突
- 通过缓存机制实现交易的自动重试，提高交易成功率
- 15 秒强制发送机制防止交易因依赖未解除而永久阻塞

### 7.7 预编译合约

OpenHive 实现了 **9 个标准以太坊预编译合约**（地址 0x01-0x09），通过 **SilkPre** 库提供底层执行实现。没有自定义/非标准预编译合约。

**EVM 版本**: evmone **v0.14.1**，支持到 **Cancun** 硬分叉级别（`EVMC_MAX_REVISION = EVMC_CANCUN`）。

| 地址 | 名称 | Gas 成本 | 说明 |
|------|------|----------|------|
| 0x01 | ecrecover | 固定 3000 | ECDSA 签名恢复 |
| 0x02 | sha256 | 60 + 12 × ⌈len/32⌉ | SHA-256 哈希 |
| 0x03 | ripemd160 | 600 + 120 × ⌈len/32⌉ | RIPEMD-160 哈希 |
| 0x04 | identity | 15 + 3 × ⌈len/32⌉ | 数据复制 |
| 0x05 | expmod | 见下方说明 | 大整数模幂 |
| 0x06 | ecadd | Istanbul+: 150 / 之前: 500 | BN128 点加 |
| 0x07 | ecmul | Istanbul+: 6000 / 之前: 40000 | BN128 点乘 |
| 0x08 | ecpairing | Istanbul+: 45000 + 34000×k / 之前: 100000 + 80000×k | BN128 配对检查 |
| 0x09 | blake2bf | rounds（从输入读取） | BLAKE2b 压缩 |

**expmod (0x05) Gas 计算**：
- Berlin 之前 (EIP-198): `mult_complexity_eip198(max_len) × adjusted_exp_len / 20`
- Berlin 及之后 (EIP-2565): `max(200, mult_complexity_eip2565(max_len) × adjusted_exp_len / 3)`

**版本控制**：通过 `evmc_revision` 参数支持不同硬分叉的 Gas 定价差异（Frontier/Byzantium/Istanbul/Berlin）。

**缓存机制**：除 identity (0x04) 外的所有预编译结果会被缓存。

### 7.8 合约状态存储

合约状态使用 MPT（Merkle Patricia Trie）存储：

```
合约地址 → MPT Root Hash → {key: value}
```

- 每个合约有独立的 MPT
- MPT 根哈希存储在 RocksDB 中
- 状态变更通过 MPT 操作持久化

### 7.9 合约区块验证

合约区块需要额外的验证步骤：

```
verifyContractBlock(block):
  1. 验证所有合约交易的 pre_hash
  2. 验证合约依赖关系
  3. 执行合约交易并验证状态根
  4. 检查脏合约状态（verifyDirtyContract）
```

---

## 8. 存储层

### 8.1 概述

OpenHive 使用 **RocksDB** 作为持久化存储引擎，采用 `TransactionDB` 模式支持多键事务。

### 8.2 存储架构

```
┌───────────────────────────────────────┐
│           DB API (高层接口)            │
│  - getBlockByBlockHash()              │
│  - getBalanceByAddr()                 │
│  - getTransactionByHash()             │
│  - ...                                │
├───────────────────────────────────────┤
│      DBReader / DBReadWriter          │
│  (读写分离，事务支持)                  │
├───────────────────────────────────────┤
│          RocksDB (TransactionDB)       │
│  - 原子性保证                          │
│  - 并发控制                            │
│  - WAL 持久化                          │
└───────────────────────────────────────┘
```

### 8.3 数据模型

RocksDB 以键值对形式存储，通过 Key 前缀区分数据类型。

#### 8.3.1 区块相关

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `BH:{height}` | `vector<blockHash>` | 高度到区块哈希列表（支持分叉） |
| `B:{blockHash}` | `blockRaw` | 区块序列化数据 |
| `SH:{height}` | `sumHash` | 高度到汇总哈希 |
| `TH:{thousandNum}` | `thousandSumHash` | 千区块汇总哈希 |
| `TOP` | `blockHeight` | 当前最高区块高度 |

#### 8.3.2 交易相关

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `TX:{txHash}` | `txRaw` | 交易序列化数据 |
| `TXBH:{txHash}` | `blockHash` | 交易所在区块哈希 |

#### 8.3.3 UTXO 与余额

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `UB:{addr}:{assetType}:{utxoHash}` | `balance` | UTXO 余额 |
| `UAH:{addr}:{assetType}` | `vector<utxoHash>` | 地址 UTXO 哈希列表 |
| `BAL:{addr}:{assetType}` | `balance` | 地址余额 |
| `ASSET` | `vector<assetType>` | 所有资产类型 |

#### 8.3.4 质押与委托

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `STAKE_ADDR` | `vector<address>` | 所有质押地址 |
| `STAKE:{addr}:{assetType}` | `vector<utxo>` | 质押 UTXO 列表 |
| `DELEG:{bonusAddr}:{delegatingAddr}:{assetType}` | `vector<utxo>` | 委托关系 |
| `DELEG_ADDR` | `vector<address>` | 所有委托地址 |

#### 8.3.5 合约相关

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `EVM_DEPLOYER` | `vector<deployerAddr>` | 所有部署者地址 |
| `EVM_CODE:{contractAddr}` | `contractCode` | 合约代码 |
| `EVM_DEPLOY:{deployerAddr}` | `vector<contractAddr>` | 部署者合约列表 |
| `EVM_UTXO:{contractAddr}` | `contractDeploymentUtxo` | 合约部署 UTXO |
| `EVM_LATEST_UTXO:{contractAddr}` | `utxo` | 合约最新 UTXO |
| `MPT:{mptKey}` | `mptValue` | MPT 状态数据 |
| `EVM_ASSET:{contractAddr}` | `assetType` | 合约资产类型 |

#### 8.3.6 共识与统计

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `SIGN:{period}:{address}` | `signCount` | 周期内节点签名数 |
| `BLOCK_NUM:{period}` | `blockNumber` | 周期内区块数量 |
| `SIGN_ADDR:{period}` | `vector<address>` | 周期内签名地址 |
| `BURN:{period}` | `burnAmount` | 周期内销毁数量 |
| `PACKAGER` | `packagerCount` | 打包次数统计 |

#### 8.3.7 投票与提案

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `APPROVE:{assetType}` | `set<address>` | 赞成地址集合 |
| `AGAINST:{assetType}` | `set<address>` | 反对地址集合 |
| `VOTE_TX:{assetType}` | `vector<txHash>` | 投票交易哈希 |
| `PROPOSAL:{assetType}` | `proposalInfo` | 提案信息 |
| `REVOKE:{assetType}` | `revokeInfo` | 撤销提案信息 |
| `VOTE_CNT:{assetType}` | `{approve, against}` | 投票计数 |
| `VOTE_ADDR:{addr}:{assetType}` | `voteCount` | 地址投票数 |
| `VOTE_TOTAL:{assetType}` | `totalVoters` | 投票者总数 |

#### 8.3.8 锁定

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `LOCK_ADDR` | `vector<address>` | 所有锁定地址 |
| `LOCK_UTXO:{addr}:{assetType}` | `vector<utxo>` | 锁定 UTXO 列表 |

### 8.4 事务支持

使用 RocksDB `TransactionDB` 模式：

```cpp
// 只读读取器
DBReader reader;
reader.getBlockTop(height);

// 读写器（事务）
DBReadWriter writer;
writer.put(key, value);
writer.delete(key);
writer.commit();  // 原子提交
writer.rollback(); // 回滚
```

### 8.5 高度汇总与校验

#### 8.5.1 Sum Hash

每 100 个区块计算一次汇总哈希：

```
sumHash(height) = SHA256(SHA256(blockHash_{h-99}) || ... || SHA256(blockHash_h))
```

用于快速同步和分叉检测。

#### 8.5.2 千区块汇总

每 1000 个区块计算一个校验哈希：

```
thousandSumHash(n) = SHA256(sumHash(n*1000-999) || ... || sumHash(n*1000))
```

### 8.6 回滚机制

支持回滚到指定高度：

```cpp
RollBackToHeight(targetHeight):
  1. 从当前 top 向下遍历
  2. 对每个区块调用 DeleteBlock
  3. 删除区块数据、交易数据、UTXO 状态
  4. 恢复 UTXO 到未消费状态
  5. 更新 top 高度
```

### 8.7 MPT (Merkle Patricia Trie) 实现

#### 8.7.1 概述

MPT 用于存储智能合约状态，源自 Aleth (Ethereum C++ client) 的实现，但使用 **SHA256** 作为哈希函数（而非以太坊的 Keccak256）。

#### 8.7.2 节点类型

| 节点类型 | 结构 | 说明 |
|---------|------|------|
| `HashNode` | `data: string` | 哈希引用节点，存储子节点的哈希值 |
| `ValueNode` | `data: string` | 值节点，存储实际数据 |
| `ShortNode` | `nodeKey: string, nodeVal: nodePtr, nodeFlags: NodeFlag` | 短节点（带 key 前缀），用于压缩路径 |
| `FullNode` | `children: array[17] of nodePtr, flags: NodeFlag` | 全节点（16 个 nibble 子节点 + 1 个 value） |

`NodeFlag` 结构：
- `hash: HashNode`: 节点哈希值
- `dirty: bool`: 脏标志，表示节点是否被修改

#### 8.7.3 核心操作

| 操作 | 说明 |
|------|------|
| `Get(key)` | 查找键对应的值 |
| `Insert(n, prefix, key, value)` | 插入键值对，返回更新后的节点 |
| `Update(key, value)` | 更新键值对（调用 Insert） |
| `Commit(n)` | 提交脏节点，计算哈希 |
| `Save()` | 将脏节点持久化到数据库 |

#### 8.7.4 哈希计算

节点哈希计算流程：

```
ToHash(n):
  1. 调用 Encode(n) 将节点序列化为 RLP 格式
  2. 将 RLP 字节数组转换为十六进制字符串
  3. 计算 SHA256 哈希: hash = Getsha256Hex(hexString)
  4. 返回 HashNode{hash}
```

**注意**: 使用 **SHA256** 而非 Keccak256，这是与以太坊 MPT 的主要差异。

#### 8.7.5 RLP 编码

节点序列化规则：

| 节点类型 | RLP 格式 |
|---------|---------|
| `ShortNode` | `RLP([key, Encode(value)])` (2 元素列表) |
| `FullNode` | `RLP([c0, c1, ..., c15, c16])` (17 元素列表) |
| `ValueNode` | `RLP(data)` |
| `HashNode` | `RLP(hash)` |

空子节点编码为空字符串 `""`。

#### 8.7.6 Key 处理

- **终止符标记**: Key 末尾添加 `'z'` 字符标记叶子节点
  - `wrapperKey(key) = key + key.back() + 'z'`
  - `HasTerm(s)`: 检查字符串是否以 `'z'` 结尾
- **Hex 转换**: `HexToKeybytes(hex)` 将十六进制字符串转换为字节数组

#### 8.7.7 存储格式

MPT 节点存储在 RocksDB 中：

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `{contractAddr}_{hash}` | `RLP encoded node (hex)` | MPT 节点数据 |

存储流程：
1. `Commit(n)` 计算节点哈希，将脏节点加入 `dirtyHash` 映射
2. `Save()` 遍历 `dirtyHash`，通过 `DBWriter` 写入 RocksDB
3. 更新合约的 MPT 根哈希

#### 8.7.8 加载流程

从数据库加载 MPT：

```
Trie(roothash, contractAddr, contractDataStorage):
  1. 创建 HashNode{roothash}
  2. 调用 ResolveHash 加载根节点
  3. DescendKey 从数据库获取 RLP 数据
  4. DecodeNode 反序列化为节点树
```

加载优先级：
1. 优先从 `contractDataStorage` (内存缓存) 获取
2. 缓存未命中时从 RocksDB 获取

#### 8.7.9 与以太坊 MPT 的差异

| 特性 | OpenHive MPT | 以太坊 MPT |
|------|--------------|-----------|
| 哈希函数 | SHA256 | Keccak256 |
| 终止符标记 | 使用 `'z'` 字符 | 使用 nibble 编码 (16/17) |
| 存储 Key | `{contractAddr}_{hash}` | `SHA3(RLP(node))` |
| 节点缓存 | `contractDataContainer` (内存) | Trie cache |

---

## 9. 网络层

### 9.1 概述

OpenHive 使用自定义 P2P 网络层，基于 epoll 事件循环实现高并发网络通信。

### 9.2 网络架构

```
┌───────────────────────────────────────┐
│         PeerNode Manager              │
│  (节点发现、连接管理、心跳)            │
├───────────────────────────────────────┤
│       Protobuf Dispatcher             │
│  (消息路由、回调注册)                  │
├───────────────────────────────────────┤
│         epoll Event Loop              │
│  (I/O 多路复用、非阻塞 I/O)            │
├───────────────────────────────────────┤
│         Socket Buffer                 │
│  (发送/接收缓冲区)                     │
├───────────────────────────────────────┤
│         Key Exchange                  │
│  (ECDH 密钥交换、加密通信)             │
└───────────────────────────────────────┘
```

### 9.3 节点管理

#### 9.3.1 节点结构

```cpp
Node {
  address: string          // 节点地址（由公钥生成）
  name: string             // 节点名称
  pub: string              // 公钥
  listenIp: U32            // 监听 IP（遗留字段，IPv4 only）
  listenPort: U16          // 监听端口
  publicIp: U32            // 公网 IP（遗留字段，IPv4 only）
  publicPort: U16          // 公网端口
  listenAddr: string       // 监听地址（支持 IPv4/IPv6）
  publicAddr: string       // 公网地址（支持 IPv4/IPv6）
  ipVersion: IpVersion     // IP 版本枚举 (IPv4/IPv6/DualStack)
  endpoints: [NodeEndpoint] // 多端点列表（支持同时拥有 IPv4 和 IPv6 端点）
  height: U64              // 节点当前高度
  connKind: ConnKind       // 连接类型
  fd: I32                  // 文件描述符（-1 表示未连接）
  pulse: I32               // 心跳计数
  time: U64                // 最后通信时间戳
  ver: string              // 节点版本
}
```

`NodeEndpoint` 结构体支持多端点分组：

```cpp
struct NodeEndpoint {
  string addr;             // 端点地址
  uint16_t port;           // 端口
  IpVersion family;        // 地址族 (IPv4/IPv6)
  uint8_t priority;        // 优先级
}
```

> **注意**: `listenIp`/`publicIp` (U32) 为遗留 IPv4 字段，保留用于向后兼容。新代码应优先使用 `listenAddr`/`publicAddr` (string) 和 `endpoints` 字段，通过 `getPublicAddrStr()`/`getListenAddrStr()` 方法统一访问。

#### 9.3.2 节点发现

节点通过注册请求交换节点列表：

```
RegisterNodeReq → RegisterNodeAck
  包含自身节点信息和可选的节点列表请求
```

#### 9.3.3 心跳机制

节点维护一个定时器，每隔 `HEARTBEAT_INTERVAL` (60 秒) 执行一次 `DealHeart` 函数，用于检测对等节点的存活状态。

```
DealHeart():
  1. 获取所有已知节点列表（排除自身）
  2. 遍历每个节点:
     a. 节点 pulse 计数器减 1
     b. 如果 pulse <= 0:
        - 判定节点失联（连续 HEARTBEAT_CHECKS 次未响应）
        - 从节点列表中删除该节点
     c. 否则:
        - 发送 Ping 请求 (SendPingReq)
        - 更新节点状态 (Update)
```

**关键参数**:
- `HEARTBEAT_INTERVAL = 60` (秒): 心跳检测周期。
- `HEARTBEAT_CHECKS = 3`: 最大心跳检测次数。若节点连续 3 个周期（共 180 秒）未响应心跳，则判定为离线并断开连接。

### 9.4 消息协议

#### 9.4.1 消息格式

所有网络消息使用 Protobuf 序列化，通过 `Pack` 模块打包：

```cpp
NetPack {
  type: U32        // 消息类型
  data: Bytes      // 序列化数据
  flag: U8         // 标志位（含优先级）
  priority: U8     // 优先级 (0-15)
}
```

#### 9.4.2 消息路由

使用 `ProtobufDispatcher` 注册回调：

```cpp
// 链上消息
registerCallback<TxMsgReq>(handleTx)
registerCallback<BlockMsg>(handleBlock)

// 网络消息
NetRegisterCallback<RegisterNodeReq>(handleRegister)
NetRegisterCallback<PingReq>(handlePing)

// 广播消息
registerBroadcastCallback<BuildBlockBroadcastMsg>(handleBroadcastBlock)

// 交易消息
TxRegisterCallback<ContractTxMsgReq>(handleContractTx)

// 同步消息
registerSyncBlockCallback<SyncBlockMsg>(handleSyncBlock)
```

### 9.5 区块同步

#### 9.5.1 同步模式

支持三种同步模式：

| 模式 | 说明 | 适用场景 |
|------|------|---------|
| `SyncNormal` | 从最近已知高度快速同步 | 节点短时间离线 |
| `SyncFromZero` | 从创世区块完整同步 | 新节点首次加入 |
| `Broadcast` | 接收广播新区块 | 常规新区块追赶 |

#### 9.5.2 同步流程

```
快速同步:
  1. 请求目标高度附近的区块哈希列表
  2. 使用 sum hash 验证一致性
  3. 如果匹配，下载区块
  4. 如果不匹配，降级为从零同步

从零同步:
  1. 从 height = 0 开始
  2. 逐区块下载并验证
  3. 构建完整状态
```

#### 9.5.3 区块请求协议

```
SeekPreHashByHightReq {
  self_node_id: string
  msg_id: string
  seek_height: U64
}

SeekPreHashByHightAck {
  self_node_id: string
  msg_id: string
  seek_height: U64
  prehashes: [string]  // 该高度的所有区块哈希
}
```

### 9.6 连接管理

#### 9.6.1 连接类型

节点连接状态由 `ConnKind` 枚举定义，包含以下三种类型：

| 枚举值 | 说明 | 备注 |
|------|------|------|
| `NOTYET` | 未知/未连接 | 节点尚未建立连接或状态未知 |
| `dataRateToOutput` | 主动连接 | 本节点主动发起的外部直连 |
| `PASSIV` | 被动连接 | 本节点被动接受的连接 |

**注意**: 枚举名称 `dataRateToOutput` 和 `PASSIV` 为当前实现中的命名，后续版本可能会进行规范化调整。

#### 9.6.2 广播策略

新区块广播采用选择性广播：

```
broadcastMessage(block):
  1. 如果 block.height < MIN_UNSTAKE_HEIGHT:
     - 广播给前 global::broadcast_threshold 个节点
  2. 否则:
     - 只广播给有质押的合格节点
  3. 如果未连接节点比例 > 25%，拒绝广播
```

#### 9.7 ECDH 密钥交换与加密通信协议

节点间通信采用基于 ECDH 的密钥交换机制，协商 AES-256-GCM 加密密钥，确保 P2P 网络通信的安全性。

##### 9.7.1 密码学基础

| 组件 | 算法/参数 | 说明 |
|------|----------|------|
| 椭圆曲线 | NIST P-256 (`NID_X9_62_prime256v1`) | 用于 ECDH 密钥交换 |
| 公钥格式 | 65 字节未压缩格式 (`0x04 \|\| X \|\| Y`) | 符合 SEC 1 标准 |
| 私钥长度 | 32 字节 | 大端序存储 |
| 共享密钥长度 | 32 字节 | ECDH 输出 |
| Salt 长度 | 32 字节 | 随机生成，用于密钥派生 |
| 密钥派生 | HKDF (HMAC-SHA256) | 基于 RFC 5869 |
| 信息标签 | `"ENCRYPTION"` | HKDF info 参数 |
| 加密算法 | AES-256-GCM | 对称加密 |
| IV 长度 | 12 字节 | 随机生成 |
| Auth Tag 长度 | 16 字节 | GCM 认证标签 |

##### 9.7.2 密钥交换流程

```
KeyExchangeRequest (发起方 → 接收方):
  1. 发起方生成 ECDH 密钥对: (pub_own, priv_own)
  2. 生成 32 字节随机 Salt: salt_own
  3. 发送 KeyExchangeRequest {
       ec_public_key_65bytes: pub_own,
       salt_32bytes: salt_own
     }

KeyExchangeResponse (接收方 → 发起方):
  4. 接收方验证公钥和 Salt 长度
  5. 接收方生成 ECDH 密钥对: (pub_peer, priv_peer)
  6. 生成 32 字节随机 Salt: salt_peer
  7. 发送 KeyExchangeResponse {
       ec_public_key_65bytes: pub_peer,
       salt_32bytes: salt_peer
     }

共享密钥计算 (双方独立执行):
  8. 计算 ECDH 共享密钥:
     shared_key = ECDH_compute_key(priv_own, pub_peer)  // 32 字节
  9. 计算 Salt XOR:
     salt_xor = salt_own XOR salt_peer  // 32 字节
  10. HKDF 派生 AES 密钥:
     aes_key = HKDF-SHA256(
       ikm: shared_key,
       salt: salt_xor,
       info: "ENCRYPTION",
       L: 32  // 输出 32 字节 AES-256 密钥
     )
  11. 将 (pub_peer, aes_key, salt_peer) 存入 KeyExchangeMap[fd]
```

##### 9.7.3 数据加密与解密

加密通信使用 AES-256-GCM 模式：

```
encrypt_plaintext(aes_key, plaintext):
  1. 生成 12 字节随机 IV
  2. 执行 AES-GCM 加密:
     ciphertext = AES_GCM_Encrypt(key=aes_key, iv=IV, plaintext=plaintext)
     输出: (ciphertext, 16-byte auth_tag)
  3. 打包为 Ciphertext 消息:
     {
       cipher_version: 1,
       aes_iv_12bytes: IV,
       aes_tag_16bytes: auth_tag,
       ciphertext_nbytes: ciphertext
     }

decrypt_ciphertext(aes_key, ciphertext_msg):
  1. 解析 Ciphertext 消息获取 IV, auth_tag, ciphertext
  2. 执行 AES-GCM 解密:
     plaintext = AES_GCM_Decrypt(key=aes_key, iv=IV, ciphertext=ciphertext, tag=auth_tag)
  3. 验证 Auth Tag，失败则返回解密错误
```

##### 9.7.4 地址生成与密钥交换的区分

**注意**: `GenerateAddr(publicKey)` 函数用于从节点公钥生成地址标识符，**不参与** ECDH 密钥交换。其流程如下：
1. 解析公钥（支持 65 字节未压缩、33 字节压缩、DER 编码格式）
2. 提取 X, Y 坐标（64 字节）
3. 计算 `hash = Keccak256(X || Y)`
4. 取哈希后 40 字符作为地址
5. 应用 EIP-55 校验和格式

该函数仅用于节点身份标识和地址派生，与 ECDH 协商加密通道是独立的过程。

### 9.8 HTTP/RPC 服务器

内嵌 HTTP 服务器处理 RPC 请求：

- 基于 `cpp-httplib` 实现
- 支持 HTTPS（`CPPHTTPLIB_OPENSSL_SUPPORT`）
- HTTP/RPC 端口：通过 `config.json` 中的 `http_port` 配置，默认为 `13134`
- HTTPS 端口：通过 `config.json` 中的 `https_port` 配置，默认为 `443`
- 请求体大小限制：10MB（`svr.set_payload_max_length(10 * 1024 * 1024)`）

> **历史变更**: `server_port` 配置字段已移除，P2P 网络端口通过 `peer_port` 配置。

### 9.9 消息加密控制

网络消息加密从默认全量开启改为按消息类型可配置：

```cpp
enum class Encrypt : uint8_t {
    ENCRYPT_FALSE = 0,  // 不加密
    ENCRYPT_TRUE = 1,   // 加密
};

// SendMessage 默认 isEncrypt = ENCRYPT_FALSE
template <typename T>
bool SendMessage(const std::string id, T &msg,
    Compress isCompress = COMPRESS_TRUE,
    Encrypt isEncrypt = ENCRYPT_FALSE,
    Priority priority = kPriorityLow0);
```

**加密策略**:

| 消息类型 | 加密 | 说明 |
|---------|------|------|
| 交易发送 | ✅ | `contractTransactionRequest` 等 |
| 合约交易 | ✅ | 合约相关消息 |
| 心跳/Ping/Pong | ❌ | 网络保活消息 |
| 节点注册 | ❌ | 节点发现消息 |

### 9.10 区块上链率探测（Block Rate Probe）

区块上链率探测模块用于统计新区块在全网质押节点中的传播情况，评估区块的确认程度。

#### 9.10.1 配置

通过 `config.json` 中的 `enable_block_rate_probe` 字段控制（默认 `false`）：

```json
{
  "enable_block_rate_probe": true
}
```

#### 9.10.2 探测时间点

新区块到达后，在以下时间点执行探测：

| 探测序号 | 延迟 | 说明 |
|---------|------|------|
| 1 | T+5s | 首次探测 |
| 2 | T+10s | 二次探测 |
| 3 | T+20s | 最终探测 |

若任意一次探测的上链率 ≥ 80%，标记为已确认并取消后续探测。

#### 9.10.3 探测流程

```
AddBlock(blockHash):
  1. 注册区块，记录接收时间
  2. 在 T+5s, T+10s, T+20s 分别执行:
     a. 获取全网质押节点列表（_fetchPledgeAddress）
     b. 向所有质押节点发送 BlockRateProbeReq
     c. 收集 BlockRateProbeAck 响应（超时 10 秒）
     d. 计算上链率: rate = exist_count / total_pledge_count
     e. 如果 rate >= 0.8: confirmed = true，取消后续探测
```

#### 9.10.4 探测消息

```protobuf
message BlockRateProbeReq {
  string self_node_id = 1;  // 请求节点 ID
  string msg_id = 2;        // 消息标识
  string block_hash = 3;    // 被探测区块哈希
}

message BlockRateProbeAck {
  string self_node_id = 1;  // 响应节点 ID
  string msg_id = 2;        // 消息标识
  string block_hash = 3;    // 区块哈希
  bool exist = 4;           // 本地是否拥有该区块
}
```

#### 9.10.5 探测结果

```cpp
struct ProbeResult {
    string hash;                // 区块哈希
    uint64_t create_time;       // 接收时间（秒）
    bool confirmed;             // 是否已确认（rate >= 0.8）
    uint32_t probe_count;       // 实际探测次数
    vector<double> rates;       // 每次探测的上链率
};
```

**常量**: `kMaxCacheSize = 5000`（最大缓存记录数）

### 9.11 时间同步（NTP）

节点使用 NTP 协议同步系统时间，支持从配置文件或硬编码列表获取 NTP 服务器。

**配置文件**: `./ntp_server.conf`（每行一个服务器地址）

**硬编码服务器列表**（国际化部署）:

| 服务器 | 说明 |
|--------|------|
| `time.cloudflare.com` | Cloudflare NTP |
| `pool.ntp.org` | NTP Pool Project |
| `time.google.com` | Google NTP |
| `time.windows.com` | Microsoft NTP |
| `time.apple.com` | Apple NTP |

服务器按顺序遍历，支持重试机制。

### 9.12 连接限制与保护

网络层实施多层连接限制，防止资源耗尽和滥用：

| 参数 | 值 | 说明 |
|------|------|------|
| `kMaxTotalConnections` | 500 | 全局最大连接数 |
| `kMaxInboundConnections` | 300 | 入站连接上限 |
| `kMaxOutboundConnections` | 200 | 出站连接上限 |
| `kMaxConnectionsPerIP` | 3 | 每 IP 最大连接数 |
| `kMaxNewConnectionsPerSecond` | 20 | 每秒新建连接速率限制 |

### 9.13 消息速率限制

使用 Token Bucket 算法对每个 peer 进行消息速率限制：

| 参数 | 值 | 说明 |
|------|------|------|
| `kMaxMessagesPerPeerPerSecond` | 100 msg/s | 每节点消息速率上限 |
| `kMaxBytesPerPeerPerSecond` | 10 MB/s | 每节点字节速率上限 |

违规处理：单节点累计违规 5 次后 ban 60 秒。

### 9.14 消息大小与缓冲区限制

| 参数 | 值 | 说明 |
|------|------|------|
| `kMaxMessageSize` | 32 MB | 单条消息最大大小 |
| `kMaxSendBufferSize` | 16 MB | 每节点发送缓冲区上限 |
| HTTP 请求体限制 | 10 MB | HTTP/HTTPS 服务器请求体上限 |

### 9.15 消息去重

对 block/tx 类消息实施 SHA256 指纹去重，防止消息重放和环路扩散：

| 参数 | 值 | 说明 |
|------|------|------|
| `kDedupCacheSize` | 100,000 | 去重缓存容量 |
| `kDedupExpireSeconds` | 300s | 去重条目过期时间 |

> **注意**: 去重仅对区块和交易类消息生效，心跳、注册等网络保活消息不去重。

### 9.16 自动重连

节点断连后自动重连，使用 Full Jitter 指数退避策略：

| 参数 | 值 | 说明 |
|------|------|------|
| `kMaxReconnectAttempts` | 5 | 最大重连尝试次数 |
| `kReconnectBaseDelayMs` | 1000ms | 基础退避延迟 |
| `kReconnectMaxDelayMs` | 60000ms | 最大退避延迟 |

重连受信誉门控：节点信誉分 < 0.2 时不重连。全局重连速率限制 10 次/秒。

### 9.17 节点信誉评分

节点信誉采用四维加权评分模型：

| 维度 | 权重 | 说明 |
|------|------|------|
| Latency | 20% | 消息响应延迟 |
| Validity | 30% | 消息有效性 |
| Uptime | 15% | 在线时长 |
| Compliance | 35% | 协议遵从度 |

信誉分影响自动重连决策和节点选择优先级。

### 9.18 密钥轮换

ECDH 密钥每小时自动轮换，确保长期通信的前向安全性：

| 参数 | 值 | 说明 |
|------|------|------|
| `kKeyRotationIntervalSeconds` | 3600s | 密钥轮换间隔 |

密钥过期后自动断开连接，由自动重连机制（§9.16）使用新密钥重新建立连接。

### 9.19 日蚀攻击防护

通过连接分布限制缓解日蚀攻击：

| 参数 | 值 | 说明 |
|------|------|------|
| `kMaxInboundRatio` | 70% | 入站连接最大占比 |
| `kMinOutboundConnections` | 8 | 最小出站连接数 |
| `kMaxConnectionsPerSubnet16` | 5 | /16 子网最大连接数 |

### 9.20 IPv6 双栈支持

网络层支持 IPv4/IPv6 双栈通信（NET-016）：

- **Socket 层**: 使用 `AF_INET6` 双栈 socket，同时接受 IPv4 和 IPv6 连接
- **地址处理**: `IpPort` 工具类提供 `IsValidIPv6()`、`IsIPv6()`、`IsLocalIPv6()`、`IsPublicIPv6()` 等方法
- **节点端点**: `NodeEndpoint` 结构体支持一个节点同时拥有 IPv4 和 IPv6 端点，通过 `addEndpoint()` 添加并自动同步遗留字段
- **协议扩展**: Protobuf 消息新增 `listen_addr`、`node_public_addr`、`ip_version` 字段
- **向后兼容**: 旧的 `uint32_t` IPv4 字段保留，新代码优先使用 string 字段

### 9.21 网络监控指标

网络层内置 Prometheus 格式指标导出（NET-019/FEAT-001）：

**导出端点**: HTTP `/metrics`

**指标类别**:

| 类别 | 指标 | 说明 |
|------|------|------|
| 连接 | active/inbound/outbound | 当前活跃连接数 |
| 连接 | accepted/rejected/disconnects | 连接事件计数 |
| 消息 | received/sent | 消息计数 |
| 消息 | bytes_received/bytes_sent | 字节计数 |
| 消息 | dropped(dedup)/dropped(rate_limit) | 丢弃消息计数 |
| 队列 | read_queue/work_queue/write_queue | 队列深度 |
| 按类型 | messages_by_type | 每种消息类型的计数 |

### 9.22 网络层抽象接口

为未来 libp2p 迁移做准备，网络层定义了两个抽象接口：

- **`INetworkLayer`** (NET-018): 网络层对外抽象接口，包含节点管理、消息发送/广播、回调注册、统计等
- **`INetworkCAInterface`** (NET-017): 解除 `net/` 对 `ca/` 的反向依赖，`ca/` 通过此接口调用网络功能

### 9.23 连接尝试生命周期管理（ConnectionAttemptManager）

引入有限状态机（FSM）追踪每个连接尝试的完整生命周期，取代之前无状态的 fd 管理方式。

#### 9.23.1 状态枚举

`ConnectionAttemptState` 定义 9 个状态：

```
Created → Connecting → TcpConnected → KeyExchanging → KeyEstablished
→ RegisterSent → Registered → Closing → Closed
```

| 状态 | 说明 |
|------|------|
| `Created` | 连接尝试已创建，尚未发起 TCP 连接 |
| `Connecting` | TCP 连接进行中 |
| `TcpConnected` | TCP 连接已建立，fd 已绑定 |
| `KeyExchanging` | 密钥交换消息已发送/接收 |
| `KeyEstablished` | 密钥交换完成 |
| `RegisterSent` | 节点注册请求已发送（仅出站） |
| `Registered` | 节点注册完成，连接可用 |
| `Closing` | 正在关闭 |
| `Closed` | 已关闭 |

#### 9.23.2 Attempt ID

每个连接尝试分配唯一的 attempt ID：
- **格式**: 32 字符十六进制字符串（128 位随机数）
- **生成**: `GenerateConnectionAttemptId()`
- **验证**: `IsValidConnectionAttemptId()` 检查长度和字符合法性
- **用途**: 贯穿密钥交换 → 节点注册 → 注册确认全流程，防止乱序/过期消息污染状态

#### 9.23.3 核心操作

| 操作 | 说明 |
|------|------|
| `CreateOutbound(roundId, attemptId, groupKey, node)` | 创建出站连接尝试 |
| `CreateInbound(attemptId, fd)` | 为入站连接创建跟踪条目（fd 去重） |
| `Transition(attemptId, expected, next)` | 严格状态转换验证 |
| `SetConnectedFd(attemptId, fd)` | TCP 连接成功后绑定 fd |
| `ValidatePendingAck(roundId, attemptId, fd)` | 验证注册 ACK 合法性 |
| `CloseAttempt(attemptId, reason)` | 关闭尝试并清理关联资源 |
| `ClosePendingRound(roundId, reason)` | 批量关闭某轮次所有未终结尝试 |
| `ReleaseFd(fd, reason)` | socket 关闭时释放 fd 绑定 |
| `HasActiveGroup(groupKey)` | 防止对同一 endpoint group 重复连接 |

#### 9.23.4 自动清理

已关闭的尝试在 **60 秒** 后自动从内存中清除（`PurgeClosedLocked`）。

#### 9.23.5 完整连接流程

```
出站方:                              入站方:
1. GenerateConnectionAttemptId()
2. CreateOutbound(attemptId)
   state: Created
3. TCP connect
   state: Connecting → TcpConnected
4. 发送 KeyExchangeRequest(attemptId)
   state: TcpConnected → KeyExchanging
                                       5. 接收 KeyExchangeRequest(attemptId)
                                          CreateInbound(attemptId, fd)
                                          state: KeyExchanging → KeyEstablished
                                       6. 发送 KeyExchangeResponse(attemptId)
7. 接收 KeyExchangeResponse(attemptId)
   验证 attempt_id 匹配
   state: KeyExchanging → KeyEstablished
8. 发送 RegisterNodeReq(attemptId,
   network_name)
   state: KeyEstablished → RegisterSent
                                       7. 接收 RegisterNodeReq(attemptId,
                                          network_name)
                                          验证 network_name 匹配
                                       8. 注册节点
                                       9. MarkRegistered(roundId, attemptId)
                                          state: RegisterSent → Registered
                                       10. 发送 RegisterNodeAck(attemptId,
                                           network_name)
9. 接收 RegisterNodeAck(attemptId,
   network_name)
   验证 attempt_id + network_name
   state: Registered
```

### 9.24 网络策略引擎（NetworkPolicy）

策略驱动的网络连接控制框架，根据网络类型（Dev/Primary）应用不同的连接策略。

#### 9.24.1 地址分类

`NetworkAddressScope` 枚举定义地址范围：

| 分类 | IPv4 范围 | IPv6 范围 |
|------|----------|----------|
| `Unspecified` | 0.0.0.0/8 | ::/128 |
| `Loopback` | 127.0.0.0/8 | ::1/128 |
| `LinkLocal` | 169.254.0.0/16 | fe80::/10 |
| `Private` | 10/8, 172.16-31/12, 192.168/16 | fc00::/7 |
| `Shared` | 100.64.0.0/10 | — |
| `Public` | 其他 | 其他 |

支持 IPv4-mapped IPv6 地址的分类。

#### 9.24.2 连接策略配置

| 策略字段 | Dev 网络 | Primary 网络 |
|---------|---------|-------------|
| `requirePublicAddress` | false | **true** |
| `requirePublicAdvertisedEndpoint` | false | **true** |
| `allowSharedSourceIp` | true | **false** |
| `enforcePerIpLimit` | false | **true** |
| `enforceSubnet16Limit` | false | **true** |
| `enforceInboundRatio` | false | **true** |
| `maxPeerConnections` | 254 | `kMaxTotalConnections` |

#### 9.24.3 连接方向冲突解决

当同一对节点之间存在双向连接时，使用 `PreferredConnectionKind()` 基于地址字典序确定首选连接方向，`ShouldReplaceExistingConnection()` 决定是否替换已有连接。拒绝新连接时断开新 fd（而非旧 fd）。

#### 9.24.4 地址规范化

`NormalizeEndpointAddress()` 将所有 loopback 地址统一为 `<loopback>` 标记，用于 endpoint 比较。`EndpointAddressesEquivalent()` 基于规范化后的地址进行等价判断。

### 9.25 Bootstrap 引导重试机制

Server endpoint 的初始引导连接采用指数退避重试策略，与常规节点同步分离为独立轨道：

```
引导重试轨道:
  初始延迟: kServerEndpointRetryInitialSeconds = 5 秒
  最大延迟: kServerEndpointRetryMaxSeconds = 30 秒
  退避策略: 5s → 10s → 20s → 30s（上限）
  部分成功时重置退避延迟

常规同步轨道:
  周期: global::node_list_refresh_time
  独立计时，不受引导重试影响
```

两个轨道独立运行，互不干扰。Bootstrap 连接断开后自动重新进入引导流程。

### 9.26 网络消息协议扩展

#### 9.26.1 注册消息新增字段

`RegisterNodeReq` 和 `RegisterNodeAck` 新增以下字段：

| 消息 | 字段 | 类型 | 说明 |
|------|------|------|------|
| `RegisterNodeReq` | `attempt_id` | string | 连接尝试唯一标识 |
| `RegisterNodeReq` | `network_name` | string | 发起方的 Genesis 网络名称 |
| `RegisterNodeAck` | `attempt_id` | string | 回显的连接尝试标识 |
| `RegisterNodeAck` | `network_name` | string | 响应方的 Genesis 网络名称 |

#### 9.26.2 密钥交换消息新增字段

`KeyExchangeRequest` 和 `KeyExchangeResponse` 均新增 `attempt_id` 字段（string 类型），用于在密钥交换阶段绑定连接尝试。

#### 9.26.3 网络名称验证

注册阶段验证双方的 `network_name` 是否匹配。不同网络（如 DevNet 与 Primary）的节点之间拒绝注册，返回错误码 `-17`。

### 9.27 统一 fd 清理路径

所有连接关闭路径（`DisconnectNode()`、`CloseFd()`、`delete_by_fd()`）统一为单一清理序列：

```
1. ConnectionAttemptManager.ReleaseFd(fd)
2. KeyExchangeManager.removeKey(fd)
3. EpollMode.DeleteEpollEvent(fd)
4. bufferControl.DeleteBuffer(fd)
5. close(fd)
```

密钥交换和注册流程使用 `ON_SCOPE_EXIT` 确保失败时自动调用 `CloseAttempt()`，避免资源泄漏。

### 9.28 fd 互斥锁安全改进

`fdMutex` 返回类型从 `std::mutex&` 改为 `std::shared_ptr<std::mutex>`，防止 fd 关闭时 `removeFdMutex` 销毁 mutex 导致正在使用的写线程持有悬空引用。

### 9.29 MsgId 生成改进

`GlobalDataManager` 的 msgId 生成从 `GetUTCTimestamp()` 改为 `steady_clock::now()` + 原子递增序列号，避免时钟回拨导致的 ID 碰撞。新增 `SetExpectedResponses()` 支持动态调整期望响应数，新增 `CancelWait()` 支持主动取消等待。

---

## 10. RPC/API 接口

### 10.1 概述

OpenHive 提供两类 RPC 接口：

1. **自定义 JSON-RPC 2.0**: 主要业务接口
2. **ETH 兼容接口**: 兼容以太坊工具链

### 10.2 RPC 框架

基于 JSON-RPC 2.0 协议：

```json
// 请求
{
  "header": {
    "id": "string",
    "jsonrpc": "2.0",
    "method": "string"
  },
  "params": {...}
}

// 响应
{
  "header": {...},
  "result": {...},
  "status": {
    "code": "int",
    "errorCallstack": "string"
  }
}
```

#### 10.2.1 JSON Key 命名规范

RPC 响应中的 JSON key 统一使用 **camelCase** 命名。主要变更包括：

| 旧 Key (PascalCase) | 新 Key (camelCase) | 说明 |
|---------------------|--------------------|------|
| `BeginTime` | `beginTime` | 交易信息字段 |
| `EndTime` | `endTime` | 交易信息字段 |
| `txinfo` | `txInfo` | 交易信息对象 |
| `merkleroot` | `merkleRoot` | 区块字段 |
| `EnteringMoreContractAddr` | `tokenContractAddr` | 跨链合约地址 |
| `canBeStake` | `genesisToken` | 创世代币标志 |
| `dependentCTx` | `dependentCtx` | 依赖交易 |

> **Breaking Change**: 此变更影响所有依赖旧 JSON key 名称的客户端和前端，需同步更新。

#### 10.2.2 参数安全校验

所有 RPC 接口实施严格的参数校验：

- **哈希校验**: `validateHash()` — 验证 64 字符十六进制格式
- **金额校验**: `validateAmount()` — 验证正整数范围
- **类型校验**: `validateDelegateType()`、`validateLockType()`、`validateVoteType()` — 枚举值验证
- **HTTP 请求体限制**: 10MB 上限，防止 OOM 攻击

### 10.3 POST 接口

完整的 POST 接口列表见 [附录 D](#附录-d-rpc-方法列表)。

#### 10.3.1 基础查询

| 方法 | 说明 |
|------|------|
| `GetVersion` | 获取节点版本 |
| `GetBalance` | 获取地址余额 |
| `GetBlockHeight` | 获取当前区块高度 |
| `GetChainId` | 获取链 ID |
| `GetAccounts` | 获取本地账户列表 |
| `GetNodeList` | 获取已知节点列表 |
| `GetBlockByHash` | 根据哈希获取区块 |
| `GetBlockByHeight` | 根据高度获取区块 |
| `GetTransactionByHash` | 根据哈希获取交易 |
| `GetBlocks` | 获取区块列表 |

#### 10.3.2 质押与委托

| 方法 | 说明 |
|------|------|
| `CreateStakingTransaction` | 创建质押交易 |
| `CreateUnstakingTransaction` | 创建解押交易 |
| `CreateDelegatingTransaction` | 创建委托交易 |
| `CreateUndelegatingTransaction` | 创建取消委托交易 |
| `GetStakingUtxo` | 获取质押 UTXO |
| `GetDelegatingAddrs` | 获取委托地址列表 |
| `GetDelegatingUtxo` | 获取委托 UTXO |

#### 10.3.3 智能合约

| 方法 | 说明 |
|------|------|
| `CreateDeployContractTransaction` | 创建部署合约交易 |
| `CreateCallContractTransaction` | 创建调用合约交易 |
| `IsContract` | 检查地址是否为合约 |
| `GetUtxoDeployer` | 获取部署者 UTXO |

#### 10.3.4 投票与提案

| 方法 | 说明 |
|------|------|
| `CreateVoteTransaction` | 创建投票交易 |
| `CreateLockTransaction` | 创建锁定交易 |
| `CreateUnlockTransaction` | 创建解锁交易 |
| `GetVoteAddrs` | 获取投票地址 |
| `GetVoteTxHash` | 获取投票交易哈希 |
| `GetLockUtxo` | 获取锁定 UTXO |
| `GetAllAssetType` | 获取所有资产类型 |
| `GetAssetTypeInfo` | 获取资产类型详情 |

#### 10.3.5 奖励

| 方法 | 说明 |
|------|------|
| `CreateBonusTransaction` | 创建领取奖励交易 |
| `CreateFundTransaction` | 创建领取国库交易 |
| `GetBonusInfo` | 获取奖励信息（见下方详细说明） |
| `GetYieldInfo` | 获取收益信息 |
| `GetAllStakeNodeList` | 获取所有质押节点列表 |

##### GetBonusInfo 详细说明

**HTTP 路径**: `POST /GetBonusInfo`

**请求参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `addr` | string | 否 | 查询地址（支持 0x 前缀）。为空时返回所有地址的签名统计 |

**返回结构**（提供 `addr` 时）:

- `bonus` — 委托奖励信息:
  - `period`: 当前周期号
  - `as_delegator`: 作为委托方的奖励详情数组（含 `bonus_addr`, `gross_amount`, `commission_amount`, `estimated_amount`, `claimable_amount`, `claimable` 等）
  - `as_operator`: 作为操作方的奖励详情（含 `delegator_count`, `commission_rate`, `estimated_operator_commission` 等）
  - `total_estimated_amount` / `total_claimable_amount`: 合计预估/可申领总额
- `fund` — 基金奖励信息:
  - `asset_pool`: 各资产类型的气费池 `{assetType: gasAmount}`
  - `locked_reward` / `package_reward` / `estimated_reward` / `claimable_reward`: 按资产类型分的奖励
  - `qualification_ret`, `can_package_reward`, `package_times`, `package_count`, `claimable` 等

**返回结构**（未提供 `addr` 时）:
- `time`: 当前周期号
- `addr_count`: 所有地址的签名统计数组 `[{address, count}]`

**错误码**: `MEM::FIELD_EMPTY`, `MEM::INVALID_ADDR`, `MEM::PARSE_JSON_FAIL`, `MEM::GET_SIGN_COUNT_FAIL`

#### 10.3.6 测试接口

| 方法 | 说明 |
|------|------|
| `StartContractPoolTest` | 启动合约池自动化测试 |
| `StartAutoTransactionTest` | 启动自动交易测试 |

##### StartContractPoolTest

**HTTP 路径**: `POST /StartContractPoolTest`

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `time_s` | int | 必填 | 测试持续时间（秒） |
| `second` | long long | 1 | 时间窗口（秒） |
| `much` | long long | 1 | 每时间窗口的合约调用数 |

启动后台线程读取 `contract.json`，轮询账户列表循环调用合约，测试结束后生成 TPS 报告。返回 `height: "started"`。

##### StartAutoTransactionTest

**HTTP 路径**: `POST /StartAutoTransactionTest`

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `time_s` | int | 必填 | 测试持续时间（秒） |
| `TxNum` | int | 1 | 每秒交易数 |
| `timeout` | int | 1 | 超时时间（秒） |
| `asset_type` | string | "" | 资产类型 |

启动后台线程创建交易，测试结束后生成 TPS 报告。返回 `height: "started"`。

#### 10.3.7 回滚与锁定查询

| 方法 | 说明 |
|------|------|
| `GetAllRollBackBlocks` | 获取所有回滚区块 |
| `Get30daylockdatas` | 获取 30 天锁定 UTXO 数据 |
| `Confirm` | 查询交易上链确认状态 |

### 10.4 GET 接口

调试和查询接口：

| 端点 | 说明 |
|------|------|
| `/api` | API 模板（参数/响应示例） |
| `/block` | 获取区块列表 |
| `/get_block` | 获取区块数据（JSON） |
| `/pub` | 获取线程和请求统计 |
| `/account` | 获取账户列表 |
| `/Node` | 获取节点列表 |
| `/ShowVRFInfo` | 获取 VRF 验证信息 |
| `/printCalcHash` | 打印千块汇总 hash |
| `/printhundredhash` | 打印百块汇总 hash |
| `/printblock` | 打印区块 hash 到文件 |
| `/SystemInfo` | 获取系统信息 |
| `/printVoteInfo` | 打印投票信息 |
| `/printLockAddrs` | 打印锁定地址 |
| `/printProposalInfoByHash` | 打印提案详细信息 |
| `/printAvailableAssetType` | 打印可用资产类型 |
| `/printAsseTypeByContractAddr` | 根据合约地址查资产类型 |
| `/GetPublicIp` | 获取公网 IP |
| `/GetRollbackBlocks` | 获取回滚区块信息 |
| `/Get30daylockdatas` | 获取 30 天锁定 UTXO 数据 |
| `/Confirm` | 查询交易上链确认状态 |
| `/GetBlockRateProbeResults` | 获取区块上链率探测结果 |

### 10.5 ETH 兼容接口

`rpc/eth/` 目录提供 ETH 风格的 RPC 接口，用于兼容以太坊工具链（如 MetaMask、Hardhat、Web3.js 等）。

#### 10.5.1 接口列表

| 方法 | 说明 | 参数 | 返回值 | 备注 |
|------|------|------|--------|------|
| `eth_chainId` | 获取链 ID | 无 | `string` (hex) | 硬编码为 `0x3027` (12315) |
| `eth_blockNumber` | 获取当前区块高度 | 无 | `string` (hex) | 返回最新区块高度 |
| `eth_gasPrice` | 获取 Gas 价格 | 无 | `string` (hex) | 目前返回 `0x1` |
| `eth_feeHistory` | 获取费用历史 | `blockCount`, `newestBlock`, `rewardPercentiles` | `object` | EIP-1559 费用历史 |
| `eth_getBalance` | 获取账户余额 | `address`, `blockTag` | `string` (hex) | 精度自动转换 10⁸ → 10¹⁸ |
| `eth_getTransactionCount` | 获取交易计数 (nonce) | `address`, `blockTag` | `string` (hex) | 返回账户 nonce |
| `eth_sendRawTransaction` | 发送原始交易 | `signedTxData` (hex) | `string` (txHash) | 支持部署合约、调用合约、普通转账 |
| `eth_getTransactionReceipt` | 获取交易收据 | `txHash` | `object` | 包含 blockHash, blockNumber, gasUsed, logs 等 |
| `eth_call` | 执行合约调用 (只读) | `{to, data, from?}` | `string` (hex) | 返回合约执行输出 |
| `eth_getBlockByNumber` | 根据区块号获取区块 | `blockNumber`, `fullTx` | `object` | 支持区块标签（见下方说明） |
| `eth_getBlockByHash` | 根据区块哈希获取区块 | `blockHash`, `fullTx` | `object` | 返回区块详情 |
| `eth_getCode` | 获取合约代码 | `address`, `blockTag` | `string` (hex) | 返回合约字节码，无代码返回 `0x` |
| `eth_getTransactionByHash` | 根据哈希获取交易 | `txHash` | `object` | 返回交易详情 |
| `eth_estimateGas` | 估算 Gas | `{to, data, from?, value?}` | `string` (hex) | 估算执行所需 Gas |
| `eth_accounts` | 获取账户列表 | 无 | `array` of `string` | 返回本地账户地址列表 |
| `eth_maxPriorityFeePerGas` | 获取最大优先费用 | 无 | `string` (hex) | 固定返回 `"0x1"` |
| `net_version` | 获取网络版本 | 无 | `string` | 返回网络 ID |
| `web3_clientVersion` | 获取客户端版本 | 无 | `string` | 返回客户端版本号 |

##### eth_getBlockByNumber 区块标签

`eth_getBlockByNumber` 的第一个参数支持以下以太坊标准区块标签：

| 标签 | 说明 |
|------|------|
| `"latest"` | 查询当前最新区块 |
| `"pending"` | 查询当前最新区块（同 `latest`） |
| `"earliest"` | 返回创世区块（高度 0） |
| 十六进制字符串 | 按原逻辑解析区块号 |

##### 交易 JSON 格式（EIP-1559）

`eth_getBlockByNumber` 和 `eth_getBlockByHash` 返回的交易对象遵循 EIP-1559 格式：

| 字段 | 值 | 说明 |
|------|------|------|
| `type` | `"0x2"` | EIP-1559 交易类型 |
| `maxFeePerGas` | `"0x1"` | 最大 Gas 费用 |
| `maxPriorityFeePerGas` | `"0x1"` | 最大优先费用 |
| `chainId` | `"0x3027"` | 链 ID (12315) |
| `accessList` | `[]` | 访问列表（空） |

**注意**: 不再返回 `gasPrice` 字段，由 `maxFeePerGas` 和 `maxPriorityFeePerGas` 替代。

#### 10.5.2 精度转换

OpenHive 底层使用 10⁸ 精度，但 ETH 工具链期望 10¹⁸ 精度。`eth_getBalance` 会自动进行转换：

```
scale_up_10_8_to_18(balance):
  返回 balance × 10¹⁰ (十六进制格式)
```

`eth_sendRawTransaction` 接收 10¹⁸ 精度的 value，内部转换为 10⁸：

```
scale_down_10_18_to_8(value_bytes):
  返回 value / 10¹⁰ (最小精度)
```

#### 10.5.3 交易处理流程 (`eth_sendRawTransaction`)

1. **RLP 解码**: 解析原始交易数据
2. **签名验证**: 验证交易签名，提取 `from` 地址
3. **类型判断**:
   - `to` 为空 → **部署合约** (`DEPLOY`)
   - `to` 为合约地址 → **调用合约** (`CALL`)
   - `to` 为普通地址 → **普通转账** (`TX`)
4. **交易构造**: 调用 `TxHelper` 创建对应类型的交易
5. **签名与哈希**: 对交易签名并计算哈希（使用 `ca_algorithm::calculateTransactionHash`，先清除 hash/signature/selection_vrf 字段）
6. **广播**: 通过 `dropCallShippingRequest` 广播到网络
7. **缓存机制**: 如果依赖检查失败，交易存入 `ContractTransactionCache` 等待后续发送

`eth_sendRawTransaction` 支持从 ETH 原始交易解码后映射到多种 OpenHive 原生交易类型：

| ETH 交易特征 | 映射的 OpenHive 交易类型 |
|-------------|------------------------|
| `to` 为空 + data 非空 | `DEPLOY` (部署合约) |
| `to` 为合约地址 + data 非空 | `CALL` (调用合约) |
| `to` 为普通地址 + value > 0 | `TX` (普通转账) |
| data 编码投票操作 | `VOTE` (投票) |
| data 编码委托操作 | `DELEGATE` / `UNDELEGATE` |
| data 编码质押操作 | `STAKE` / `UNSTAKE` |
| data 编码锁仓操作 | `LOCK` / `UNLOCK` |

**金额处理**: 所有交易的 `amount` 统一从 ETH 原始交易的 `value` 字段通过 `scale_down_10_18_to_8()` 换算（18 位精度 → 8 位精度），不再从 JSON 参数读取。

**资产类型**: 合约部署和合约调用统一使用 `ASSET_TYPE_OHI` 作为资产类型。

#### 10.5.4 返回值格式

所有接口遵循 JSON-RPC 2.0 响应格式：

```json
{
  "id": "<request_id>",
  "jsonrpc": "2.0",
  "result": <response_data>
}
```

错误时返回：
```json
{
  "id": "<request_id>",
  "jsonrpc": "2.0",
  "error": {
    "code": <error_code>,
    "message": "<error_message>",
    "data": "<optional_data>"
  }
}
```

### 10.6 错误码

OpenHive 使用基于宏展开的错误码系统，定义在 `errorn/` 目录下。错误码分为 4 个独立域，通过 `PERROR` 宏自动附带调用栈信息。

#### 10.6.1 RPC 解析错误 (`RPC_PARSE_ERROR`)

| 枚举值 | 描述 |
|--------|------|
| `PARSE_JSON_FAIL` | JSON 解析失败 |
| `MISSING_JSON_FIELD` | 缺少字段 |
| `FIELD_TYPE_ERROR` | 字段类型错误 |
| `EMPTY_JSON` | JSON 为空 |
| `FIELD_EMPTY` | 字段为空 |
| `API_VERSION_ERROR` | API 版本应为 2.0 |
| `NOT_FOUND_PARAM` | 未找到参数 |
| `NOT_FOUND_METHOD` | 未找到方法 |
| `SERIALIZE_FAIL` | 序列化失败 |
| `TX_CONFIRMATION_FAIL` | 交易确认失败 |

#### 10.6.2 全局错误 (`GLOBAL_ERROR`)

| 枚举值 | 描述 |
|--------|------|
| `INVALID_ADDR` | 无效地址 |
| `INVALID_ASSET_TYPE` | 无效资产类型 |
| `INVALID_HASH` | 无效哈希 |
| `GET_TIME_FAIL` | 获取时间失败 |
| `INVALID_VALUE` | 无效金额 |
| `INFO_IS_TOO_BIG` | 信息过大 |
| `INVALID_AMOUNT` | 无效数量 |

#### 10.6.3 合约错误 (`CONTRACT_ERROR`)

| 枚举值 | 描述 |
|--------|------|
| `NOT_FOUND_ACCOUNT` | 未找到账户 |
| `INVALID_EVM_BTYEPCODE` | 无效字节码 |
| `EVM_PREVRANDA_FAIL` | prevRandao 计算失败 |
| `EVM_DEPLOY_FAIL` | 部署失败 |
| `EVM_CALL_FAIL` | 调用失败 |
| `EVM_MAKE_TRNAS_FAIL` | 构造 EVM 交易失败 |
| `EVM_INVALID_CONTRACT_TYPE` | 无效合约类型 |
| `EVM_ADDR_GEN_FAIL` | 地址生成失败 |
| `EVM_TIMEOUT` | EVM 超时 |
| `EVMONE_EXEC_FAIL` | evmone 执行失败 |

#### 10.6.4 CA 共识算法错误 (`CA_ERRORS`)

共 69 个错误码，覆盖质押/委托/投票/Gas/合约等所有业务场景。主要分类：

| 类别 | 示例错误码 |
|------|-----------|
| 资产/余额 | `ASSET_NOT_EXIST`, `BALANCE_IS_INSUFFICIENT`, `GET_BALANCE_FAILED` |
| 质押/委托 | `ACCOUNT_HAS_STAKED`, `THE_STAKE_AMOUNT_IS_INSUFFICIENT`, `NOT_QUALIFIED_FOR_UNDELEGATION` |
| UTXO | `NOT_FIND_UTXO_BY_HASH`, `FIND_UTXO_FAIL`, `GET_TX_UTXO_FAIL` |
| Gas | `GAS_IS_ZERO`, `GAS_ASSET_TYPE_NOT_MATCH`, `CHECK_GAS_ASSET_FAILED` |
| 合约 | `NOT_A_VALID_CONTRACT`, `CREATE_CONTRACT_ADDR_FAIL`, `CONTRACT_NONCE_FAIL` |
| 投票/提案 | `VOTE_INFO_CHECK_FAIL`, `GET_APPROVE_ADDRESS_FAILED` |
| 锁定/解锁 | `GET_LOCK_ADDRESS_FAILED`, `UNKNOWN_LOCK_TYPE`, `LESS_THAN_MIN_LOCK_AMOUNT` |

**错误码格式**：返回时为负数字符串（如 `"-0"`, `"-1"`），附带文件名、行号、函数名等调试信息。

---

## 11. 代币经济学与 Gas

### 11.1 原生代币 OHI

- **AssetType**: `"OHI"`
- **精度系统**: 双精度（标准精度/最小精度）
  - 标准精度：1 OHI（用户界面单位）
  - 最小精度：1（底层存储单位，类似以太坊的 wei）
- **转换常量**: `kDecimalNum = 100,000,000` (10⁸)
  - 1 OHI (标准) = 100,000,000 (最小精度)
- **锁定金额**: `LOCK_AMOUNT = 1` (标准精度) = 100,000,000 (最小精度)

### 11.1 原生代币与资产分类

OpenHive 采用**三层资产分类**体系：

#### 11.1.1 资产类型定义

| 资产类型 | 说明 | 示例 | 所在层 | 特性 |
|---------|------|------|--------|------|
| **Token** | 合约层代币，跨链资产 | wHIVE | EVM 合约层 | 仅能通过合约调用转移，使用 OHI 支付 Gas，不能质押/投资 |
| **Native Token** | 通过提案跃入 UTXO 层的代币 | nHIVE | UTXO 层 | 可支付 Gas、可质押、可投资、可跃出回合约层 |
| **Native** | 底层原生币 | OHI | UTXO 层 | 不能跃入/跃出，用于投票权、支付 Gas、质押、委托 |

> **注意**: 早期版本中存在独立的 `Vote` 资产类型（`ASSET_TYPE_VOTE = "Vote"`），用于投票权和 Gas 支付。该资产已在后续版本中完全移除，所有原 Vote 资产的使用场景（锁定投票、Gas 支付、质押委托、奖励申领等）统一使用 `OHI` 资产。

#### 11.1.2 AssetType 标识

- **OHI**: `global::ca::ASSET_TYPE_OHI = "OHI"`（底层原生币，统一用于投票、Gas、质押等所有用途）
- **Native Token**: AssetType 为**提案所在交易哈希**（动态生成）

#### 11.1.3 OHI 币说明

OHI 是一种 **Native Token**，其发行量和允许跃入金额由提案动态规定：
- 初始发行量：创世区块分配
- 后续发行：通过跃入协议（FlowIn）从合约层 Token 跃入
- 流通控制：通过提案和投票机制动态管理

### 11.2 跃入/跃出协议（FlowIn/FlowOut）

#### 11.2.1 跃入协议（FlowIn）

跃入协议允许合约层 Token 进入 UTXO 层成为 Native Token：

```
FlowIn 流程:
  1. 提案通过（赞成票 > 反对票）
  2. 用户调用跨链合约的 FlowIn 方法
  3. 合约层 Token 被锁定/销毁
  4. UTXO 层按提案汇率铸造对应数量的 Native Token
  5. Native Token 的 AssetType = 提案交易哈希
```

**跃入条件**：
- 提案必须已通过（赞成票 > 反对票）
- 用户必须在合约层持有对应 Token
- 按提案规定的汇率进行转换

#### 11.2.2 跃出协议（FlowOut）

跃出协议允许 Native Token 返回合约层成为 Token：

```
FlowOut 流程:
  1. 用户创建 FlowOut 交易
  2. UTXO 层 Native Token 被销毁
  3. 合约层按提案汇率释放/铸造对应 Token
  4. Token 返回合约层流转
```

**跃出条件**：
- 提案未被撤销（跃出始终允许）
- 如果提案被撤销：Native Token 只能跃出，不能跃入

#### 11.2.3 汇率计算

跃入/跃出使用提案中定义的汇率：

```
跃入金额 (UTXO 层) = (Token 数量 × ExchangeRate × 10⁸) / (10^{rateDecimal} × 10^{tokenDecimal})

其中:
- tokenDecimal 固定为 18（EVM 标准精度）
- rateDecimal 为汇率的小数位数
- ExchangeRate 为提案中定义的汇率
```

### 11.3 提案与投票机制

#### 11.3.1 提案发起

**提案发起资格**: 仅限创始账号（创世区块分配的特定地址）

**提案内容**:
```cpp
ProposalInfo {
  version: U8                           // 提案版本 (KProposalInfoVersion = 0)
  assetName: string                     // 资产名称（如 "nHIVE"）
  contractAddr: string                  // 合约地址
  rate: string                          // 汇率（Token → Native Token 的转换比例）
  crossChainInvestmentContractAddr: string
  taskType: CrossChainTxType            // 跨链交易类型
  minVote: U64                          // 最小投票数
  peerChainTokenAddr: string            // 对等链代币地址
  beginTime: U64                        // 投票开始时间
  endTime: U64                          // 投票结束时间
}
```

**提案目的**: 决定是否允许某个 Token 进入 UTXO 层进行流动交易、代付 Gas 费用和质押投资。

#### 11.3.2 投票资格与规则

**投票资格**: 所有锁定 OHI 资产的用户

**投票规则**:
1. 投票类型：赞成（Approve）或反对（Against），二选一
2. 票数计算：`票数 = 该地址的锁定 OHI 量`
3. 唯一性：一个地址对一个提案只能投票一次（`CheckForDuplicateVotes`）
4. 投票时间：在提案规定的 `beginTime` 到 `endTime` 期间

#### 11.3.3 提案结果判定

在提案投票到期时（`endTime`），根据票数对比判定：

| 场景 | 判定条件 | 结果 |
|------|---------|------|
| **提案通过** | 赞成票 > 反对票 | Token 可跃入 UTXO 层成为 Native Token |
| **提案否决** | 反对票 ≥ 赞成票 | 提案不通过，Token 继续在合约层流转 |

#### 11.3.4 撤销提案

**撤销提案发起**: 创始账号发起

**撤销提案内容**:
```cpp
RevokeProposalInfo {
  version: U8                           // 撤销提案版本 (KRevokeProposalInfoVersion = 0)
  proposalHash: string                  // 原提案交易哈希
  beginTime: U64                        // 投票开始时间
  endTime: U64                          // 投票结束时间
  minVote: U64                          // 最小投票数
}
```

**撤销流程**:
1. 创始账号发起撤销提案
2. 所有锁定 OHI 的用户投票
3. 如果赞成票 > 反对票，撤销提案通过
4. 撤销后：
   - Native Token 只能跃出，不能跃入
   - 无法再进行交易流转和质押
   - 已质押资产将不再有效

### 11.4 锁定机制（Lock）

#### 11.4.1 锁定目的

锁定 OHI 资产获得投票权，用于参与提案和撤销提案的投票。

#### 11.4.2 锁定参数

- **锁定金额**: `LOCK_AMOUNT = 1` (标准精度) = 100,000,000 (最小精度)
- **锁定类型**: `kLockTypeNet = "LockNet"`
- **虚拟锁定地址**: `VIRTUAL_LOCK_ADDRESS = "LockVirtualStake"`

#### 11.4.3 锁定/解锁流程

```
锁定 (LOCK):
  1. 创建 LOCK 交易
  2. 从用户地址转移 OHI 到锁定状态
  3. 获得投票权（票数 = 锁定金额）

解锁 (UNLOCK):
  1. 创建 UNLOCK 交易（使用简化模型，见 5.13.3 节）
  2. 指定要解锁的 utxo_hash，构建单精确 UTXO 输入
  3. 检查距锁定时间是否超过 LOCK_RELEASE_WAIT_TIME（30 天）
  4. 从锁定状态释放 OHI 回用户地址（单输出，无 Gas）
  5. 失去对应投票权
```

### 11.5 Gas 机制

#### 11.5.1 Gas 参数

| 参数 | 值 | 说明 |
|------|------|------|
| `KTargetGasPrice` | 60,000 | 目标 Gas 价格（EIP-1559 动态调整的目标阈值） |
| `INITIAL_BASE_FEE` | 10 | 初始基础费用（创世区块或无历史记录时的默认值） |
| `MAX_GAS_LIMIT` | 120,000 (`KTargetGasPrice * 2`) | 合约交易最大 Gas 成本限制，超过则拒绝 |
| `kBlockGasLimit` | 30,000,000 | 区块 Gas 上限（与以太坊相同） |
| `kGasLimitBufferRatio` | 0.9 | Gas 安全余量比例（90%） |

#### 11.5.2 基础 Gas 计算 (`CalculateGas` / `GenerateGas`)

基础 Gas 消耗基于交易的 UTXO 规模和数据大小计算：

```
CalculateGas(utxo, gasSize):
  utxoSize = Σ(vin.prevout.size() * 64)  // 每个输入引用占 64 字节
  gas = utxo.owner_size() * 34           // 每个所有者占 34 字节
  gas += utxoSize                        // 输入引用总大小
  gas += utxo.vout_size() * 34           // 每个输出占 34 字节
  gas += gasSize                         // 额外预留 Gas 大小
  gas *= 1                               // 乘数系数（当前为 1）
  返回 gas
```

`GenerateGas` 逻辑类似，但 `voutSize` 由调用方显式传入。
`precalculatedGas` 用于预估普通交易 Gas：`gas = voutSize * 34 + data.size() + note.size() + reserve0.size() + reserve1.size()`。

#### 11.5.3 动态基础费用调整 (`VerifyContractBaseFee` & `EIP1559FeeCalculator`)

合约交易（DEPLOY/CALL）采用类似 EIP-1559 的动态基础费用机制，根据网络拥堵程度自动调整 `baseFee`。

**精度说明**: `EIP1559FeeCalculator` 使用 `int64_t` 定点数（毫单位 ×1000），确保跨平台确定性。3 位小数精度，`FEE_SCALE = 1000`。

**调整流程**:
1. **限额检查**: 若 `gasCost > KTargetGasPrice * 2` (120,000)，直接拒绝交易。
2. **获取历史 baseFee**:
   - 遍历当前链顶向下查找发送者 (`fromAddr`) 的最后一笔合约交易。
   - 提取其 `txInfo["baseFee"]` 作为 `old_baseFee`。
   - 若未找到或处于创世区块 (`top == 0`)，默认 `old_baseFee = 10`。
   - **有效性校验**: `old_baseFee` MUST 为有效十进制数字字符串，无效值回退到默认值 `"10"`。
3. **计算新 baseFee**:
   调用 `EIP1559FeeCalculator::calculateNewFee(old_baseFee, gasCost, KTargetGasPrice)`：
   ```
   adjustment_factor = (gasCost - KTargetGasPrice) / (KTargetGasPrice * 8.0)
   new_fee_exact = old_baseFee * (1.0 + adjustment_factor)
   
   若 gasCost > KTargetGasPrice:
     new_baseFee = ceil(new_fee_exact)  // 拥堵时向上取整
   若 gasCost < KTargetGasPrice:
     new_baseFee = floor(new_fee_exact) // 空闲时向下取整
   否则:
     new_baseFee = new_fee_exact        // 平衡时不变
   
   new_baseFee = max(new_baseFee, 0.0)  // 确保非负
   ```
4. **计算最终 Gas 费用**:
   `gasCost = gasCost * new_baseFee`
5. **记录**: 将 `new_baseFee` 写入新交易的 `txInfo["baseFee"]` 供后续交易参考。

**设计目的**:
- 当交易 Gas 需求超过目标值 (60,000) 时，提高基础费用以抑制拥堵。
- 当网络空闲时，逐步降低基础费用以激励交易。
- 初始值设为 10，确保网络启动初期费用可控。

#### 11.5.4 Gas 资产输入

检查 Gas 资产资格：

```cpp
CheckGasAssetsInput(isGasAssets, gasAssets)
CheckGasAssetsQualification(gasAssets, height)
```

#### 11.5.5 Gas 销毁

Gas 费用销毁到虚拟地址：

- `VIRTUAL_BURN_GAS_ADDR = "VirtualBurnGas"`
- `kVirtualDeploymentContractAddress = "VirtualDeployContractBurnGas"`
- `VIRTUAL_CALL_CONTRACT_ADDR = "VirtualCallContractBurnGas"`
- `kVirtualCallFlowOutAddr = "VirtualCallFlowOutBurnGas"`

### 11.6 质押经济模型

#### 11.6.1 节点质押

- **最小质押量**: `MIN_STAKE_AMOUNT = 3500 × 10⁸ OHI`
- **解押等待**: `MIN_UNSTAKE_HEIGHT = 500` 个区块
- **释放等待时间**: `STAKE_RELEASE_WAIT_TIME = 30 天`（Dev 网络: `DEV_RELEASE_WAIT_TIME = 1 分钟`）
- **质押类型**: `STAKE_TYPE_NODE`
- **交易模型**: 使用简化模型（见 5.13.3 节），单精确 UTXO 输入，无 Gas 处理

#### 11.6.2 委托

- **最小委托量**: `kMinDelegatingAmt = 500 × 10⁸ OHI`
- **最小奖励委托量**: `kMinKGetBonusDelegatingAmt = 500,000 × 10⁸ OHI`
- **投资上限**: `KInvestmentCap = 3,500,000 × 10⁸ OHI`
- **最大投资次数**: `kMaximum_number_of_investments = 1000`

#### 11.6.3 佣金率

- **最小佣金率**: `MIN_COMMISSION_RATE = 0.05` (5%)
- **最大佣金率**: `MAX_COMMISSION_RATE = 0.35` (35%)

### 11.7 年化率计算与奖励分配机制

奖励分配的核心在于动态年化率（Annualized Rate）的计算。系统根据网络质押率、项目运行时间以及节点的工作表现，动态调整奖励发放比例。

#### 11.7.1 核心计算流程 (`GetNewAnnualizedRate`)

该函数是激励部分的核心，负责计算当前周期的年化率：

```
GetNewAnnualizedRate(curTime, stakingRate, annualizedRate):
  1. 计算项目运行周数 (weeksSinceStart):
     - 获取创世时间 projectStartTime (微秒)
     - 计算时间差: timeDiff = curTime - projectStartTime
     - 转换为周数: weeksSinceStart = timeDiff / (7 * 24 * 3600 * 10^6)
     - 限制范围: 若 weeksSinceStart >= 520 (10年)，则设为 519

  2. 计算衰减系数 k:
     - 调用 mapStakingRateToK(stakingRate)
     - 将质押率 (10%~100%) 线性映射到 k 值 (1.0~20.0)
     - 公式: k = 1.0 + (stakingRate - 10.0) * (20.0 - 1.0) / (100.0 - 10.0)

  3. 计算通胀率序列 (calculateInflationRates):
     - 参数: k, totalWeeks=520, startRate=5.0%, endRate=0.5%
     - 对每周 w (1~520) 计算:
       x = (w - 1) / (520 - 1)  // 归一化时间
       inflationRate[w] = endRate + (startRate - endRate) * exp(-k * x)
     - 采用指数衰减模型，随时间推移通胀率从 5.0% 逐渐降至 0.5%

  4. 计算年化率序列 (calculateAnnualizedRates):
     - 对每周计算: annualizedRate[w] = inflationRate[w] / (stakingRate / 100.0)
     - 质押率下限保护: 若 stakingRate < 10%，则按 10% 计算
     - 年化率与通胀率成正比，与质押率成反比（质押越少，奖励越高以激励质押）

  5. 返回当前周的年化率:
     - annualizedRate = annualizedRates[weeksSinceStart]
```

#### 11.7.2 网络质押率计算 (`GetNetworkStakingRate`)

质押率是参与质押/锁定的代币总量占总流通量的比例：
```
GetNetworkStakingRate(curTime, stakingRate):
  1. 获取当前总流通量 totalSupply (getTotalCirculationAsOfTodayStart)
  2. 获取当前锁定/质押总量 totalLockedAmount (getLockedAmountAsOfTodayStart)
  3. stakingRate = (totalLockedAmount / totalSupply) * 100.0
```

#### 11.7.3 奖励分配公式 (`CalcBonusValue`)

最终奖励分配综合考虑年化率、委托金额和节点工作表现：

```
CalcBonusValue(curTime, bonusAddr, values):
  1. 获取网络质押率 stakingRate
  2. 计算年化率 annualizedRate = GetNewAnnualizedRate(curTime, stakingRate)
  3. 检测异常节点:
     - 调用 fetchAbnormalSignAddrListByPeriod 获取 addr_percent
     - 若 bonusAddr 在 addr_percent 中:
       dividendRate = addr_percent[bonusAddr] (实际签名量 / 平均签名量)
     - 否则: dividendRate = 1.0 (合格节点)

  4. 遍历所有委托者 delegatingAddr:
     - 基础奖励 = annualizedRate * delegatedAmount / 365
     - 实际奖励 = dividendRate * 基础奖励
     - values[delegatingAddr] = 实际奖励
```

**设计目的**:
- **时间衰减**: 通过指数衰减模型，确保代币发行量随时间递减，最终趋于稳定的低通胀率 (0.5%)。
- **质押率反比**: 质押率越低，年化率越高，激励用户参与质押；质押率越高，年化率越低，防止过度通胀。
- **工作量惩罚**: 签名量低于平均水平的节点，其奖励按实际工作量占比同比例扣减，确保网络安全性。

---

## 12. 治理与升级

### 12.1 提案与投票

#### 12.1.1 提案类型

提案用于添加新资产类型或其他链级变更：

```cpp
ProposalInfo {
  version: U8                   // 提案版本 (KProposalInfoVersion = 0)
  assetName: string             // 资产名称
  contractAddr: string          // 合约地址
  rate: string                  // 汇率
  crossChainInvestmentContractAddr: string
  taskType: CrossChainTxType    // 跨链交易类型
  minVote: U64                  // 最小投票数
  peerChainTokenAddr: string    // 对等链代币地址
}
```

#### 12.1.2 投票流程

1. 创建 `PROPOSAL` 交易提交提案
2. 进入投票期：`KVoteCycle = 10 分钟`
3. VRF 投票开始时间：`KVrfVoteBeginTime = 10 秒`
4. 地址投票（`VOTE` 交易）
5. 投票结束，统计结果
6. 如果通过，资产类型生效

#### 12.1.3 投票类型

| 类型 | 值 | 说明 |
|------|------|------|
| `Against` | 0 | 反对票 |
| `Approve` | 1 | 赞成票 |

#### 12.1.4 投票规则

- 检查重复投票：`CheckForDuplicateVotes(assetType, addr)`
- 记录投票数：`addVoteCount(db, assetType, voteType, addr, voteNumber)`
- 获取投票结果：`GetVoteNum(db, assetType, approveNum, againstNum)`

### 12.1.5 撤销提案

提案可以通过 `REVOKEPROPOSAL` 交易撤销：

```cpp
RevokeProposalInfo {
  version: U8  // KRevokeProposalInfoVersion = 0
  ...
}
```

### 12.2 跨链交易类型

提案中可以包含跨链交易配置：

| 类型 | 值 | 说明 |
|------|------|------|
| `EnteringMore` | 0 | 仅包含越入越出 |
| `CrossChainInvestment` | 1 | 仅包含跨链投资 |
| `Both` | 2 | 包含越入越出和跨链投资 |
| `Null` | 3 | 不包含任何跨链交易 |

### 12.3 硬分叉与升级

当前版本尚未实现链上硬分叉激活机制。协议升级通过以下方式管理：

- **编译宏区分网络**: `TESTCHAIN=ON`（测试网）、`PRIMARYCHAIN=ON`（主网）
- **版本号管理**: 区块版本 `kCurrentBlockVersion = 0`，交易版本 `CURRENT_TRANSACTION_VERSION = 0`
- **EVM 版本**: 通过 evmone 库版本控制（当前 v0.14.1，支持到 Cancun）
- **向后兼容**: 区块验证时检查 `version == kCurrentBlockVersion`，不匹配则拒绝

**注意**：由于 BlockMsg proto 字段重编号（dispatcher_vrf/validator_vrf）和 ExclusionProof 新增，协议升级可能存在破坏性变更，需要全节点同步升级。

---

## 13. 安全考虑与不变量

### 13.1 不变量（Invariants）

以下不变量必须在所有状态转换中保持：

#### 13.1.1 交易不变量

1. **Gas 非负**: 所有交易的 Gas 消耗必须 ≥ 0
2. **UTXO 守恒**: `Σ(输入) = Σ(输出) + Gas`
3. **双花防护**: 每个 UTXO 只能被消费一次
4. **签名有效**: 所有交易签名必须通过验证

#### 13.1.2 区块不变量

1. **高度连续**: `block[n].height == block[n-1].height + 1`
2. **哈希链接**: `block[n].prevhash == block[n-1].hash`
3. **时间递增**: `block[n].time > block[n-1].time`
4. **Merkle 一致**: 区块 Merkle 根必须与交易列表匹配
5. **共识有效**: 区块必须包含至少 `kConsensus` 个有效签名

#### 13.1.3 状态不变量

1. **余额非负**: 所有账户余额 ≥ 0
2. **状态根一致**: 所有节点的 MPT 根哈希必须一致
3. **质押有效**: 打包节点必须有足够的质押

### 13.2 攻击缓解

#### 13.2.1 双花攻击

缓解措施：
- UTXO 双花检查：`doubleSpendCheck(tx)`
- 交易超时验证：`verifyTransactionTimeoutRequest(tx)`
- 区块确认等待：需要多个区块确认

#### 13.2.2 拜占庭节点

缓解措施：
- VRF 随机选择打包节点
- 多签共识（至少 3 个节点）
- 质押门槛：只有质押节点才能参与共识
- 拜占庭容错检查：`checkByzantineFault(receiveCount, hitCount)`

#### 13.2.3 垃圾交易攻击

缓解措施：
- Gas 费用机制
- 交易超时限制：`KtxTimeout = 10 秒`
- 交易池大小限制

#### 13.2.4 Sybil 攻击

缓解措施：
- 节点质押要求：`MIN_STAKE_AMOUNT`
- 地址验证：`isValidAddress(address)`
- 密钥交换：ECDH 加密通信

### 13.3 已知限制

当前实现存在以下已知限制和边界情况：

1. **blockPrevRandao 可预测性**: EVM 的 `block.prev_randao` 基于 UTXO 哈希 ASCII 值之和计算，存在精度截断，高度可预测，与以太坊 VRF-based prevRandao 语义不同。依赖此值的合约可能存在安全风险。

2. **双花检测独立性**: `Checker::CheckConflict`（池内检测）和 `doubleSpendCache`（短暂窗口缓存）独立运行无联动，可能存在检测盲区。合约交易冲突检测仅用 `prevout.hash`，不含地址和币种。

3. **拜占庭容错查找表限制**: `checkByzantineFault` 的静态查找表仅覆盖 1-10 个节点场景，超过 10 个节点时直接返回 `false`。

4. **交易池淘汰策略简单**: 采用纯 FIFO + TTL（10秒）淘汰，无 LRU、无优先级、无基于费率的淘汰。可能被大量低费垃圾交易淹没。

5. **EIP-1153 瞬态存储**: `EvmHost::get/set_transient_storage` 接口存在但可能为空实现。

6. **SELFDESTRUCT 语义**: 当前仍使用旧语义（EIP-6049 变更未完全实施）。

7. **区块大小限制**: 区块序列化大小不超过 4MB (`1024 * 1024 * 4`)。

8. **快速同步节点覆盖**: `checkByzantineFault` 仅覆盖小规模网络（≤10 节点），大规模网络的容错行为未充分验证。

### 13.4 安全最佳实践

1. **私钥管理**: 私钥不应出现在日志或网络消息中
2. **签名范围**: 签名必须覆盖完整的序列化数据
3. **时间窗口**: VRF 签名验证使用 ±10 秒时间窗口
4. **阈值验证**: 使用 55% 节点阈值筛选合格打包节点

---

## 附录 A. 完整常量表

### A.1 共识常量

| 常量 | 值 | 说明 |
|------|------|------|
| `kConsensus` | 7 | 最小共识节点数 |
| `CYCLE_DURATION_SECONDS` | 15 | VRF 完整周期（秒） |
| `PHASE1_DURATION` | 6 | 阶段1：VRF 广播（秒） |
| `PHASE2_DURATION` | 4 | 阶段2：摘要交换（秒） |
| `PHASE3_DURATION` | 2 | 阶段3：共识计算（秒） |
| `BUFFER_DURATION` | 3 | 缓冲时间（秒） |
| `MAX_VRFS_SIZE` | 10 | 最大 VRF 数据存储大小 |
| `send_node_threshold` | 15 | 区块流发送阈值 |
| `KReSend_node_threshold` | 15 | 重发阈值 |
| `MIN_SYNC_QUAL_NODES` | 3 | 最小同步合格节点数 |
| `TX_TIMEOUT_MIN` | 30 | 交易超时（分钟） |
| `kForkMajorityThreshold` | 0.51 | 简单多数，分叉方向初步判定 |
| `kByzantineFaultToleranceThreshold` | 0.66 | 2/3 BFT 共识验证阈值 |
| `kChainHeightPercentile` | 0.75 | 链高度百分位（选取第 75 百分位高度） |
| `kHighConfidenceThreshold` | 0.80 | 高置信度阈值（从零同步等安全场景） |

### A.1.1 VRF 调度者共识常量

| 常量 | 值 | 说明 |
|------|------|------|
| `THRESHOLD_RATIO_LARGE` | 2/3 | N ≥ 200 时阈值比例 |
| `THRESHOLD_RATIO_MEDIUM` | 3/4 | 50 ≤ N < 200 时阈值比例 |
| `THRESHOLD_RATIO_SMALL` | 4/5 | 20 ≤ N < 50 时阈值比例 |
| `THRESHOLD_RATIO_TINY` | 9/10 | N < 20 时阈值比例 |
| `HYSTERESIS_MARGIN` | 5 | 档位滞后区间 |
| `BOUNDARY_DELTA` | 2 | 边界裁决区间 |
| `LEVEL1_START` | 15s | 降级档位1起始 |
| `LEVEL2_START` | 20s | 降级档位2起始 |
| `LEVEL3_START` | 25s | 降级档位3起始 |
| `PARTITION_COVERAGE_THRESHOLD` | 0.60 | 分区检测阈值 |
| `CLOCK_SKEW_TOLERANCE` | 2s | 时钟偏差容忍 |

### A.1.2 惩罚机制常量

| 常量 | 值 | 说明 |
|------|------|------|
| `kSlashEvidenceQuorum` | 7 (= kConsensus) | 举证共识阈值 |
| `kSlashEvidenceMaxDelayMs` | 3000 | 举证最大退避延迟 (ms) |
| `kSlashEvidenceMaxPerPeriod` | 20 | 每周期最大举证数 |
| `kSlashEvidenceDedupWindow` | 60000 | 举证去重窗口 (ms) |
| `kPunishmentThresholdL3` | 3 | L3 触发所需 EVIDENCE 笔数 |
| `kPunishmentThresholdL4` | 5 | L4 触发所需 EVIDENCE 笔数 |
| `kSlashRateFirst` | 0.01 (1%) | L3 首次扣减比率 |
| `kSlashRateSecond` | 0.03 (3%) | L3 第二次扣减比率 |
| `kSlashRateThird` | 0.05 (5%) | L3 第三次及以后扣减比率 |
| `kJailConsecutiveAbsentPeriods` | 8640 | L1 触发：连续缺席周期数 (24h) |
| `kJailAutoReleasePeriods` | 100 | L1 自动释放周期数 |
| `kJailManualReleasePeriods` | 5 | L1 手动释放需连续正常周期数 |
| `kForfeitJailPeriods` | 2880 | L2 触发：关押超 8h |
| `kForfeitDisconnectCount` | 10 | L2 触发：每小时断连次数 |
| `kSlashAbuseThresholdRate` | 0.10 | 恶意举报者有效举报率阈值 |
| `kSlashAbuseMinReports` | 5 | 恶意举报者最小举报数 |

### A.1.5 准入池常量

| 常量 | 值 | 说明 |
|------|------|------|
| `kEntryPoolInitialProb` | 0.50 | 准入池初始概率 50% |
| `kEntryPoolDailyIncrement` | 0.025 | 每日递增 2.5% |
| `kEntryPoolReferenceTimestamp` | 1741996800 | 基准时间（2026-03-15 00:00:00 UTC） |

### A.2 经济常量

| 常量 | 值 | 说明 |
|------|------|------|
| `kDecimalNum` | 100,000,000 | 十进制倍数（标准精度→最小精度转换） |
| `MIN_STAKE_AMOUNT` | 350,000,000,000 | 最小质押量 (3500 OHI，已乘以 kDecimalNum) |
| `kMinKGetBonusDelegatingAmt` | 50,000,000,000,000 | 最小奖励委托量 (500,000 OHI) |
| `kMinDelegatingAmt` | 50,000,000,000 | 最小委托量 (500 OHI) |
| `KInvestmentCap` | 350,000,000,000,000 | 投资上限 (3,500,000 OHI) |
| `kMaximum_number_of_investments` | 1000 | 最大投资次数 |
| `LOCK_AMOUNT` | 1 | 锁定金额 (**标准精度**，使用时需乘以 kDecimalNum) |
| `MIN_UNSTAKE_HEIGHT` | 500 | 最小解押高度（区块数） |
| `LOCK_RELEASE_WAIT_TIME` | 30 天 (μs) | 锁定（Lock）释放等待时间 |
| `STAKE_RELEASE_WAIT_TIME` | 30 天 (μs) | 质押（Stake）释放等待时间 |
| `DELEGATE_RELEASE_WAIT_TIME` | 1 天 (μs) | 委托（Delegate）释放等待时间 |
| `DEV_RELEASE_WAIT_TIME` | 1 分钟 (μs) | Dev 网络释放等待时间（测试用） |
| `VOTE_CIRCULATION` | 100,000,000,000,000,000 | 投票流通量 |
| `KtxTimeout` | 10,000,000 μs | 交易超时 (10 秒) |
| `MAX_COMMISSION_RATE` | 0.35 | 最大佣金率 (35%) |
| `MIN_COMMISSION_RATE` | 0.05 | 最小佣金率 (5%) |
| `KTargetGasPrice` | 60,000 | 目标 Gas 价格 |
| `kBlockGasLimit` | 30,000,000 | 区块 Gas 上限 |
| `kGasLimitBufferRatio` | 0.9 | Gas 安全余量比例（90%） |

### A.3 投票常量

| 常量 | 值 | 说明 |
|------|------|------|
| `KVoteCycle` | 600,000,000 μs | 投票周期 (10 分钟) |
| `KVrfVoteBeginTime` | 10,000,000 μs | VRF 投票开始时间 (10 秒) |
| `KLowestExchangeRate` | 1e-8 | 最低汇率 |
| `KProposalInfoVersion` | 0 | 提案信息版本 |
| `KRevokeProposalInfoVersion` | 0 | 撤销提案信息版本 |

### A.4 虚拟地址

| 地址 | 说明 |
|------|------|
| `kTargetAddress = "VirtualStake"` | 虚拟质押地址 |
| `kVirtualDelegatingAddr = "VirtualDelegating"` | 虚拟委托地址 |
| `VIRTUAL_BURN_GAS_ADDR = "VirtualBurnGas"` | Gas 销毁地址 |
| `kVirtualDeploymentContractAddress = "VirtualDeployContractBurnGas"` | 合约部署 Gas 销毁 |
| `VIRTUAL_CALL_CONTRACT_ADDR = "VirtualCallContractBurnGas"` | 合约调用 Gas 销毁 |
| `kVirtualCallFlowOutAddr = "VirtualCallFlowOutBurnGas"` | 流出 Gas 销毁 |
| `VIRTUAL_LOCK_ADDRESS = "LockVirtualStake"` | 虚拟锁定地址 |

### A.5 资产类型常量

| 常量 | 值 | 说明 |
|------|------|------|
| `ASSET_TYPE_OHI` | `"OHI"` | 原生代币类型（统一用于投票、Gas、质押等所有用途） |
| `STAKE_TYPE_NET` | `"Net"` | 网络质押类型 |
| `kdelegateTypeNormal` | `"Normal"` | 普通委托类型 |
| `kLockTypeNet` | `"LockNet"` | 网络锁定类型 |

> **历史变更**: `ASSET_TYPE_VOTE = "Vote"` 已移除，所有原 Vote 资产用途统一使用 `ASSET_TYPE_OHI`。

### A.6 版本常量

| 常量 | 值 | 说明 |
|------|------|------|
| `CURRENT_TRANSACTION_VERSION` | 0 | 当前交易版本 |
| `kCurrentBlockVersion` | 0 | 当前区块版本 |

### A.7 网络层常量

| 常量 | 值 | 说明 |
|------|------|------|
| `kMaxTotalConnections` | 500 | 全局最大连接数 |
| `kMaxInboundConnections` | 300 | 入站连接上限 |
| `kMaxOutboundConnections` | 200 | 出站连接上限 |
| `kMaxConnectionsPerIP` | 3 | 每 IP 最大连接数 |
| `kMaxNewConnectionsPerSecond` | 20 | 每秒新建连接速率 |
| `kMaxMessagesPerPeerPerSecond` | 100 | 每节点消息速率上限 |
| `kMaxBytesPerPeerPerSecond` | 10 MB | 每节点字节速率上限 |
| `kMaxMessageSize` | 32 MB | 单条消息最大大小 |
| `kMaxSendBufferSize` | 16 MB | 每节点发送缓冲区上限 |
| `kDedupCacheSize` | 100,000 | 去重缓存容量 |
| `kDedupExpireSeconds` | 300s | 去重条目过期时间 |
| `kMaxReconnectAttempts` | 5 | 最大重连尝试次数 |
| `kReconnectBaseDelayMs` | 1000ms | 重连基础退避延迟 |
| `kReconnectMaxDelayMs` | 60000ms | 重连最大退避延迟 |
| `kWriteTimeoutSeconds` | 30s | 写超时时间 |
| `kKeyRotationIntervalSeconds` | 3600s | ECDH 密钥轮换间隔 |
| `kMaxInboundRatio` | 0.70 | 入站连接最大占比 |
| `kMinOutboundConnections` | 8 | 最小出站连接数 |
| `kMaxConnectionsPerSubnet16` | 5 | /16 子网最大连接数 |

---

## 附录 B. 交易类型枚举

```cpp
enum class TxType : int32_t {
    UNKNOWN = -1,           // 未知交易
    GENESIS = 0,            // 创世交易
    TX,                     // 普通转账
    STAKE,                  // 节点质押
    UNSTAKE,                // 解押
    DELEGATE,               // 委托
    UNDELEGATE,             // 取消委托
    DECLARATION,            // 声明
    DEPLOY,                 // 部署合约
    CALL,                   // 调用合约
    LOCK,                   // 锁定（获得投票权限）
    UNLOCK,                 // 解除锁定
    PROPOSAL,               // 提案（资产添加）
    REVOKEPROPOSAL,         // 撤销提案
    VOTE,                   // 投票
    FUND = 98,              // 领取国库奖励
    BONUS = 99,             // 领取奖励
    PUNISHMENT = 100,       // 惩罚交易（质押扣减/永久除名）
    EVIDENCE = 101          // 举证交易（链上记录，无资金转移）
};
```

---

## 附录 C. 数据库 Key 前缀规范

| 前缀 | 数据类型 | 示例 |
|------|---------|------|
| `BH:` | 高度→区块哈希列表 | `BH:12345` |
| `B:` | 区块哈希→区块数据 | `B:0xabc...` |
| `SH:` | 高度→汇总哈希 | `SH:12345` |
| `TH:` | 千区块编号→千区块哈希 | `TH:12` |
| `TOP` | 最高区块高度 | `TOP` |
| `TX:` | 交易哈希→交易数据 | `TX:0xdef...` |
| `TXBH:` | 交易哈希→区块哈希 | `TXBH:0xdef...` |
| `UB:` | 地址+资产+UTXO→余额 | `UB:addr1:OHI:utxo1` |
| `UAH:` | 地址+资产→UTXO列表 | `UAH:addr1:OHI` |
| `BAL:` | 地址+资产→余额 | `BAL:addr1:OHI` |
| `ASSET` | 所有资产类型 | `ASSET` |
| `STAKE_ADDR` | 所有质押地址 | `STAKE_ADDR` |
| `STAKE:` | 地址+资产→质押UTXO | `STAKE:addr1:OHI` |
| `DELEG:` | 分红+委托+资产→UTXO | `DELEG:bonus1:del1:OHI` |
| `DELEG_ADDR` | 所有委托地址 | `DELEG_ADDR` |
| `EVM_DEPLOYER` | 所有部署者地址 | `EVM_DEPLOYER` |
| `EVM_CODE:` | 合约地址→代码 | `EVM_CODE:0x123...` |
| `EVM_DEPLOY:` | 部署者→合约列表 | `EVM_DEPLOY:addr1` |
| `EVM_UTXO:` | 合约地址→部署UTXO | `EVM_UTXO:0x123...` |
| `EVM_LATEST_UTXO:` | 合约地址→最新UTXO | `EVM_LATEST_UTXO:0x123...` |
| `MPT:` | MPT键→MPT值 | `MPT:key1` |
| `EVM_ASSET:` | 合约地址→资产类型 | `EVM_ASSET:0x123...` |
| `SIGN:` | 周期+地址→签名数 | `SIGN:100:addr1` |
| `BLOCK_NUM:` | 周期→区块数 | `BLOCK_NUM:100` |
| `SIGN_ADDR:` | 周期→签名地址 | `SIGN_ADDR:100` |
| `BURN:` | 周期→销毁量 | `BURN:100` |
| `APPROVE:` | 资产→赞成地址 | `APPROVE:asset1` |
| `AGAINST:` | 资产→反对地址 | `AGAINST:asset1` |
| `VOTE_TX:` | 资产→投票交易 | `VOTE_TX:asset1` |
| `PROPOSAL:` | 资产→提案信息 | `PROPOSAL:asset1` |
| `REVOKE:` | 资产→撤销信息 | `REVOKE:asset1` |
| `VOTE_CNT:` | 资产→投票计数 | `VOTE_CNT:asset1` |
| `VOTE_ADDR:` | 地址+资产→投票数 | `VOTE_ADDR:addr1:asset1` |
| `VOTE_TOTAL:` | 资产→投票者总数 | `VOTE_TOTAL:asset1` |
| `LOCK_ADDR` | 所有锁定地址 | `LOCK_ADDR` |
| `LOCK_UTXO:` | 地址+资产→锁定UTXO | `LOCK UTXT:addr1:OHI` |
| `PACKAGER` | 打包次数统计 | `PACKAGER` |
| `evidence_on_chain_` | 举证交易上链记录 | `evidence_on_chain_{hash}` |
| `evidence_count_` | 举证计数索引 | `evidence_count_{addr}:{type}` |
| `evidence_threshold_` | 达到惩罚阈值的节点 | `evidence_threshold_{addr}` |
| `punishment_history_` | 惩罚执行历史 | `punishment_history_{addr}` |
| `slash_jail_` | Jailing 状态 | `slash_jail_{addr}` |
| `slash_tombstone_` | 永久除名记录 | `slash_tombstone_{addr}` |
| `slash_vrf_fail_` | VRF 签名失败记录 | `slash_vrf_fail_{addr}:{period}` |
| `slash_disconnect_` | 心跳断开计数 | `slash_disconnect_{addr}:{hour}` |
| `slash_lastactive_` | 节点最后活跃周期 | `slash_lastactive_{addr}` |
| `slash_l3count_` | L3 扣减次数 | `slash_l3count_{addr}` |

---

## 附录 D. RPC 方法列表

### D.1 POST 方法

| 方法名 | 文件 | 说明 |
|--------|------|------|
| `GetVersion` | `rpc_api_getVersion.cpp` | 获取版本 |
| `GetBalance` | `rpc_api_getBalance.cpp` | 获取余额 |
| `GetBlockHeight` | `rpc_api_getBlockHeight.cpp` | 获取区块高度 |
| `GetChainId` | `rpc_api_getChainId.cpp` | 获取链 ID |
| `GetAccounts` | `rpc_api_getAccounts.cpp` | 获取账户 |
| `GetNodeList` | `rpc_api_getNodeList.cpp` | 获取节点列表 |
| `GetBlockByHash` | `rpc_api_getBlockByHash.cpp` | 按哈希获取区块 |
| `GetBlockByHeight` | `rpc_api_getBlockByHeight.cpp` | 按高度获取区块 |
| `GetTransactionByHash` | `rpc_api_getTransactionByHash.cpp` | 按哈希获取交易 |
| `GetBlocks` | `rpc_api_getBlocks.cpp` | 获取区块列表 |
| `GetTransactions` | `rpc_api_getTransactions.cpp` | 获取交易列表 |
| `GetStakingUtxo` | `rpc_api_getStakingUtxo.cpp` | 获取质押 UTXO |
| `GetDelegatingAddrs` | `rpc_api_getDelegatingAddrs.cpp` | 获取委托地址 |
| `GetDelegatingUtxo` | `rpc_api_getDelegatingUtxo.cpp` | 获取委托 UTXO |
| `GetLockUtxo` | `rpc_api_getLockUtxo.cpp` | 获取锁定 UTXO |
| `GetBonusInfo` | `rpc_api_getBonusInfo.cpp` | 获取奖励信息 |
| `GetYieldInfo` | `rpc_api_getYieldInfo.cpp` | 获取收益信息 |
| `GetAllStakeNodeList` | `rpc_api_getAllStakeNodeList.cpp` | 获取质押节点列表 |
| `GetAllAssetType` | `rpc_api_getAllAssetType.cpp` | 获取所有资产类型 |
| `GetAssetTypeInfo` | `rpc_api_getAssetTypeInfo.cpp` | 获取资产类型信息 |
| `GetAssetTypeByContractAddr` | `rpc_api_getAssetTypeByContractAddr.cpp` | 按合约地址获取资产类型 |
| `GetVoteAddrs` | `rpc_api_getVoteAddrs.cpp` | 获取投票地址 |
| `GetVoteTxHash` | `rpc_api_getVoteTxHash.cpp` | 获取投票交易哈希 |
| `GetTransactionCount` | `rpc_api_getTransactionCount.cpp` | 获取交易计数 |
| `GetUtxoDeployer` | `rpc_api_getUtxoDeployer.cpp` | 获取部署者 UTXO |
| `GetAllRollBackBlocks` | `rpc_api_getAllRollBackBlocks.cpp` | 获取所有回滚区块 |
| `IsContract` | `rpc_api_isContract.cpp` | 检查是否为合约 |
| `CreateStakingTransaction` | `rpc_api_stake.cpp` | 创建质押交易 |
| `CreateUnstakingTransaction` | `rpc_api_unStake.cpp` | 创建解押交易 |
| `CreateDelegatingTransaction` | `rpc_api_delegating.cpp` | 创建委托交易 |
| `CreateUndelegatingTransaction` | `rpc_api_undelegating.cpp` | 创建取消委托交易 |
| `CreateDeployContractTransaction` | `rpc_api_deployContract.cpp` | 创建部署合约交易 |
| `CreateCallContractTransaction` | `rpc_api_callContract.cpp` | 创建调用合约交易 |
| `CreateVoteTransaction` | `rpc_api_vote.cpp` | 创建投票交易 |
| `CreateLockTransaction` | `rpc_api_lock.cpp` | 创建锁定交易 |
| `CreateUnlockTransaction` | `rpc_api_unlock.cpp` | 创建解锁交易 |
| `CreateBonusTransaction` | `rpc_api_bonus.cpp` | 创建奖励交易 |
| `CreateFundTransaction` | `rpc_api_fund.cpp` | 创建国库交易 |
| `CreateTransaction` | `rpc_api_Transaction.cpp` | 创建普通交易 |
| `Confirm` | `rpc_api_getBlockRateByTxHash.cpp` | 查询交易上链确认 |
| `Get30daylockdatas` | `rpc_api_get30dayLockUtxos.cpp` | 获取 30 天锁定 UTXO |
| `SendMessage` | `rpc_api_post_message.cpp` | 发送消息 |
| `SendContractMessage` | `rpc_api_postContractMsg.cpp` | 发送合约消息 |
| `GetEvidenceDetail` | `rpc_api_slashing.cpp` | 查询举证交易详情 |
| `GetPunishmentDetail` | `rpc_api_slashing.cpp` | 查询惩罚交易详情 |
| `GetEvidenceCount` | `rpc_api_slashing.cpp` | 查询节点举证计数 |
| `GetNodeSignRate` | `rpc_api_slashing.cpp` | 查询节点签名率 |
| `StartContractPoolTest` | `rpc_api_startContractPoolTest.cpp` | 启动合约池自动化测试 |
| `StartAutoTransactionTest` | `rpc_api_startAutoTransactionTest.cpp` | 启动自动交易测试 |

### D.1.5 ETH 兼容方法

| 方法 | 文件 | 说明 |
|------|------|------|
| `eth_chainId` | `eth_rpc.cpp` | 获取链 ID (12315) |
| `eth_blockNumber` | `eth_rpc.cpp` | 获取当前区块高度 |
| `eth_gasPrice` | `eth_rpc.cpp` | 获取 Gas 价格 |
| `eth_feeHistory` | `eth_rpc.cpp` | 获取费用历史 (EIP-1559) |
| `eth_getBalance` | `eth_rpc.cpp` | 获取账户余额 (10¹⁸ 精度) |
| `eth_getTransactionCount` | `eth_rpc.cpp` | 获取交易计数 (nonce) |
| `eth_sendRawTransaction` | `eth_rpc.cpp` | 发送原始交易 (RLP 编码) |
| `eth_getTransactionReceipt` | `eth_rpc.cpp` | 获取交易收据 |
| `eth_call` | `eth_rpc.cpp` | 执行合约调用 (只读) |
| `eth_getBlockByNumber` | `eth_rpc.cpp` | 根据区块号获取区块 |
| `eth_getBlockByHash` | `eth_rpc.cpp` | 根据区块哈希获取区块 |
| `eth_getCode` | `eth_rpc.cpp` | 获取合约代码 |
| `eth_getTransactionByHash` | `eth_rpc.cpp` | 根据哈希获取交易 |
| `eth_estimateGas` | `eth_rpc.cpp` | 估算 Gas |
| `eth_accounts` | `eth_rpc.cpp` | 获取账户列表 |
| `eth_maxPriorityFeePerGas` | `eth_rpc.cpp` | 获取最大优先费用（固定 `"0x1"`） |
| `net_version` | `eth_rpc.cpp` | 获取网络版本 |
| `web3_clientVersion` | `eth_rpc.cpp` | 获取客户端版本 |

### D.2 GET 方法

| 端点 | 文件 | 说明 |
|------|------|------|
| `GetAccount` | `rpc_api_getAccount.cpp` | 获取账户 |
| `GetAssetType` | `rpc_api_getAssetType.cpp` | 获取资产类型 |
| `GetBlock` | `rpc_api_getBlock.cpp` | 获取区块 |
| `GetBlockRequest` | `rpc_api_getBlockRequest.cpp` | 获取区块请求 |
| `GetNewVrfInfo` | `rpc_api_getNewVrfInfo.cpp` | 获取新 VRF 信息 |
| `GetNode` | `rpc_api_getNode.cpp` | 获取节点 |
| `GetPub` | `rpc_api_getPub.cpp` | 获取公钥 |
| `GetPublicIp` | `rpc_api_getPublicIp.cpp` | 获取公网 IP |
| `GetSystemInfo` | `rpc_api_getSystemInfo.cpp` | 获取系统信息 |
| `GetVrfInfo` | `rpc_api_getVrfInfo.cpp` | 获取 VRF 信息 |
| `PrintAssetType` | `rpc_api_printAssetType.cpp` | 打印资产类型 |
| `PrintBlock` | `rpc_api_printBlock.cpp` | 打印区块 |
| `PrintProposalInfo` | `rpc_api_printProposalInfo.cpp` | 打印提案信息 |
| `PrintVoteInfo` | `rpc_api_printVoteInfo.cpp` | 打印投票信息 |
| `PrintHundredSumHash` | `rpc_api_printHundredSumHash.cpp` | 打印百区块哈希 |
| `PrintCalcHash` | `rpc_api_printCalcHash.cpp` | 打印计算哈希 |
| `PrintLockAddrs` | `rpc_api_printLockAddrs.cpp` | 打印锁定地址 |
| `api` | `rpc_template.cpp` | API 模板 |
| `GetRollbackBlocks` | `rpc_api_getAllRollBackBlocks.cpp` | 获取回滚区块 |
| `Get30daylockdatas` | `rpc_api_get30dayLockUtxos.cpp` | 获取 30 天锁定数据 |
| `Confirm` | `rpc_api_getBlockRateByTxHash.cpp` | 查询交易上链确认 |
| `GetBlockRateProbeResults` | `rpc_api_getBlockRateProbeResults.cpp` | 获取区块上链率探测结果 |
| `GetSlashNodeStatus` | `rpc_api_slashing_get.cpp` | 查询节点惩罚状态 |
| `GetEvidenceList` | `rpc_api_slashing_get.cpp` | 查询举证记录列表 |
| `GetPunishmentList` | `rpc_api_slashing_get.cpp` | 查询惩罚记录列表 |
| `GetThresholdNodes` | `rpc_api_slashing_get.cpp` | 查询达到阈值的节点 |
| `GetSlashStats` | `rpc_api_slashing_get.cpp` | 查询全局惩罚统计 |
| `GetJailedNodes` | `rpc_api_slashing_get.cpp` | 查询所有被 Jailed 的节点 |
| `GetTombstonedNodes` | `rpc_api_slashing_get.cpp` | 查询所有被 Tombstoned 的节点 |

---

## 附录 E. 未决问题与 TODO

以下问题在撰写本文档时未能从代码中完全确认，需要核心开发者补充或修正：

### E.1 共识机制

1. ~~**TODO: [需要确认]** VRF 使用的具体签名算法（SilkPre 签名算法的详细规范）~~ ✅ **已确认**：VRF 签名使用 **ECDSA secp256k1**（通过 OpenSSL 实现），非 SilkPre。签名流程：`VRFConsensusInfo.SerializeAsString() → SHA256 → Keccak-256 → ECDSA sign`，输出 65 字节（r:32 + s:32 + v:1），含低 S 值规范化。SilkPre 仅为 EVM 预编译合约库，不参与 VRF 签名。详见 7.7 节。
2. ~~**TODO: [需要确认]** `validateNodeThreshold` 的 55% 阈值是否可配置~~ ✅ **已确认**：见 6.4.1 节，硬编码为 `totalNodes * 0.55`，当前版本不可配置。
3. ~~**TODO: [需要补充]** 异常节点检测和处理机制~~ ✅ **已补充**：见 6.4.3 节，通过 `fetchAbnormalSignAddrListByPeriod` 检测签名量低于平均值的节点，计算 `dividendRate = own_count / average`，在 `CalcBonusValue` 中按比例扣减奖励。
4. ~~**TODO: [需要确认]** 打包节点选择中 `computeMaxHeightWithMinFrequency` 的具体数学公式~~ ✅ **已确认**：见 6.4.1 节，包含哈希计数、占比计算、加权平均最优频率、节点匹配度及动态阈值筛选（1.0 起每次降 0.1 至 55% 阈值）。

### E.2 智能合约

5. ~~**TODO: [需要确认]** 合约地址生成算法~~ ✅ **已确认**：见 7.5.1 节，采用以太坊 EIP-161 标准（RLP 编码 [sender, nonce]，Keccak-256 哈希，取末 20 字节）。
6. ~~**TODO: [需要确认]** `blockPrevRandao` 是否直接使用 VRF 种子~~ ✅ **已确认**：见 7.3 节，**不是** VRF 种子。基于发送者 UTXO 交易哈希的 ASCII 值之和计算，存在 `int64_t → uint32_t → evmc_uint256be` 精度截断，高位全为零，高度可预测。
7. ~~**TODO: [需要补充]** 完整预编译合约列表和 Gas 成本表~~ ✅ **已补充**：见 7.7 节，9 个标准以太坊预编译合约（0x01-0x09），通过 SilkPre 库实现，evmone v0.14.1，支持到 Cancun 硬分叉。
8. ~~**TODO: [需要确认]** 合约依赖关系的具体验证流程~~ ✅ **已确认并补充**：见 7.6 节，包含 EvmHost::call 验证流程（7.6.1-7.6.3）及 DependencyManager/ContractTransactionCache 依赖冲突检查与缓存重试机制（7.6.5）。
9. ~~**TODO: [需要补充]** EVM 版本和激活的 EIP 列表~~ ✅ **已补充**：见 7.7 节，evmone v0.14.1，`EVMC_MAX_REVISION = EVMC_CANCUN`。已激活 EIP：EIP-2, EIP-55, EIP-152, EIP-161, EIP-196, EIP-197, EIP-198, EIP-1014, EIP-1153（接口存在但可能空实现）, EIP-1559, EIP-2565, EIP-2929, EIP-6049（SELFDESTRUCT 仍为旧语义）。

### E.3 代币经济学

10. ~~**TODO: [需要确认]** OHI 代币总供应量~~ ✅ **已确认**：OHI 是 Native Token，发行量由提案动态规定（创世区块初始分配 + FlowIn 跃入）。详见 11.1 节资产分类和 11.2 节跃入/跃出协议。
11. ~~**TODO: [需要确认]** Gas 定价机制和动态调整规则~~ ✅ **已确认**：见 11.5 节，基础 Gas 基于 UTXO 规模计算（34字节/所有者，64字节/输入引用）；合约交易采用 EIP-1559 动态调整机制，目标阈值 60,000，初始 baseFee 为 10，拥堵时 ceil 上调，空闲时 floor 下调，上限 120,000。
12. ~~**TODO: [需要确认]** `mapStakingRateToK` 的具体映射函数~~ ✅ **已确认并补充**：见 11.7 节，完整年化率计算与奖励分配机制。包含 `mapStakingRateToK` 线性映射 (10%~100% → 1.0~20.0)、指数衰减通胀率计算 (5.0% → 0.5%)、年化率反比公式及 `CalcBonusValue` 奖励分配流程。
13. ~~**TODO: [需要确认]** `LOCK_AMOUNT` 的单位和实际值~~ ✅ **已确认**：`LOCK_AMOUNT = 1` 是**标准精度**，实际最小精度为 `1 × kDecimalNum = 100,000,000`。详见 2.3 节精度定义和 11.1 节。

### E.4 网络层

14. ~~**TODO: [需要确认]** `HEARTBEAT_INTERVAL` 的具体值~~ ✅ **已确认**：见 9.3.3 节，`HEARTBEAT_INTERVAL = 60` 秒，配合 `HEARTBEAT_CHECKS = 3`，连续 180 秒无响应则断开连接。
15. ~~**TODO: [需要确认]** `kServerMainPort` 的默认端口~~ ✅ **已更新**：`server_port` 配置字段已移除。见 9.8 节，HTTP/RPC 端口通过 `http_port` 配置，默认为 `13134`。P2P 网络端口通过 `peer_port` 配置。
16. ~~**TODO: [补充]** 完整连接类型枚举定义~~ ✅ **已补充**：见 9.6.1 节，`ConnKind` 枚举包含 `NOTYET` (未知/未连接)、`dataRateToOutput` (主动连接)、`PASSIV` (被动连接) 三种类型。
17. ~~**TODO: [需要补充]** ECDH 密钥交换的详细协议~~ ✅ **已补充**：见 9.7 节，基于 NIST P-256 曲线，交换公钥 (65字节) 和 Salt (32字节)，通过 ECDH + Salt XOR + HKDF (info="ENCRYPTION") 派生 AES-256 密钥，采用 AES-256-GCM 加密通信。明确区分 `GenerateAddr` (地址生成) 与 ECDH (密钥交换) 的职责。

### E.5 RPC/API

18. ~~**TODO: [需要补充]** 完整 ETH 兼容接口列表~~ ✅ **已补充**：见 10.5 节和附录 D.1.5，包含 18 个 ETH 兼容接口（eth_chainId, eth_blockNumber, eth_gasPrice, eth_feeHistory, eth_getBalance, eth_getTransactionCount, eth_sendRawTransaction, eth_getTransactionReceipt, eth_call, eth_getBlockByNumber, eth_getBlockByHash, eth_getCode, eth_getTransactionByHash, eth_estimateGas, eth_accounts, eth_maxPriorityFeePerGas, net_version, web3_clientVersion）。
19. ~~**TODO: [需要补充]** 完整 RPC 错误码定义~~ ✅ **已补充**：见 10.6 节，4 个错误域（RPC_PARSE_ERROR 10 个、GLOBAL_ERROR 7 个、CONTRACT_ERROR 13 个、CA_ERRORS 69 个），共 99 个错误码，通过 `PERROR` 宏自动附带调用栈信息。
20. ~~**TODO: [需要确认]** RPC 鉴权和访问控制机制~~ ✅ **已确认**：当前版本**未实现** RPC 鉴权和访问控制。所有 RPC 接口对外开放，无认证机制。建议后续版本添加 API Key 或 IP 白名单等访问控制。

### E.6 安全与治理

21. ~~**TODO: [需要补充]** 硬分叉激活机制~~ ✅ **已补充**：见 12.3 节，当前无链上硬分叉激活机制，通过编译宏和版本号管理升级。
22. ~~**TODO: [需要补充]** slashing 规则（如果有）~~ ✅ **已实现**：见 6.9-6.13 节，完整五级惩罚体系（L0-L4）。L0 奖励扣减、L1 Jailing（暂停共识资格）、L2 Forfeit（奖励没收）、L3 Stake Slash（1%/3%/5% 递增质押扣减）、L4 Tombstone（永久除名）。支持三种违规检测（DOUBLE_SIGN_VRF/DOUBLE_SIGN_BLOCK/LOW_SIGN_RATE），证据通过单播消息提交给分发者，经共识后上链。
23. ~~**TODO: [需要补充]** 已知攻击场景和缓解措施详情~~ ✅ **已补充**：见 13.2 节和 13.3 节。双花防护（`doubleSpendCheck` + `CheckConflict` + `doubleSpendCache` 三层）、拜占庭容错（51%/66% 双阈值 + 静态查找表）、交易超时（普通 10s/合约 30s）、交易池限制（10000/5000 + FIFO+TTL 淘汰）。已知限制：双花检测层间无联动、BFT 查找表仅覆盖 ≤10 节点、交易池淘汰策略简单。
24. ~~**TODO: [需要确认]** 创世区块初始分配和配置参数~~ ✅ **已确认**：见 4.2 节和 4.3 节，通过 `genesis.json` 配置创世时间、初始账户地址、网络类型及初始余额（当前实现中创世余额强制为 0，仅用于初始化结构）。

### E.7 其他

25. ~~**TODO: [需要确认]** Merkle 树的具体实现~~ ✅ **已确认**：见 8.7 节，Merkle Patricia Trie 实现，源自 Aleth，使用 SHA256 哈希（非 Keccak256），支持 ShortNode/FullNode 节点类型，RLP 编码，终止符标记使用 `'z'` 字符。
26. ~~**TODO: [需要确认]** 地址生成的详细算法（`GenerateAddr`）~~ ✅ **已确认**：见 2.4 节，采用以太坊 EIP-55 标准（Keccak-256 哈希公钥 XY 坐标，取后 20 字节，应用校验和格式）
27. ~~**TODO: [需要补充]** 交易池管理和淘汰策略~~ ✅ **已补充**：见 5.7.4 节和 5.13 节。交易池大小限制 `MAX_TX_POOL_SIZE = 10000`（普通）/ `MAX_CONTRACT_POOL_SIZE = 5000`（合约）。淘汰策略：TTL 过期（10秒）+ FIFO 头部删除，无 LRU、无优先级。打包触发：3 秒定时器。打包后无论成功失败均清空整个池（全有或全无模式）。双花检测：入池前通过 UTXO 输入交集检测，冲突交易直接拒绝（先到先得）。
28. ~~**TODO: [需要确认]** 分叉解决和重组规则~~ ✅ **已确认**：见 5.6 节，每 15 秒向质押节点查询±50 高度区块哈希，80% 响应阈值，51% 共识判定，支持时间窗口保护和深度限制
29. ~~**TODO: [需要补充]** 区块 Gas 上限和熔断机制~~ ✅ **已补充**：见 5.7 节，`kBlockGasLimit = 30,000,000`，超限时触发 Partial Block 并生成 ExclusionProof
30. ~~**TODO: [需要补充]** VRF 准入池筛选机制~~ ✅ **已补充**：见 6.4 节，两阶段筛选（准入池 + 频率筛选），质押概率公式和白名单机制
31. ~~**TODO: [需要补充]** 区块上链率探测机制~~ ✅ **已补充**：见 9.10 节，T+5s/T+10s/T+20s 三次探测，80% 阈值确认
32. ~~**TODO: [需要补充]** 消息加密控制策略~~ ✅ **已补充**：见 9.9 节，按消息类型可配置加密
33. ~~**TODO: [需要补充]** NTP 时间同步服务器列表~~ ✅ **已补充**：见 9.11 节，国际化 NTP 服务器列表

---

## 附录 F. CLI 命令参考

### F.1 启动命令

| 命令 | 缩写 | 说明 |
|------|------|------|
| `openhive` | — | 标准启动，交互式密码解锁 keystore |
| `openhive auto` | `openhive a` | 快速启动，使用固定密码 `"1"` 自动解锁所有 keystore 账户，跳过交互式提示 |

### F.2 配置命令

| 命令 | 说明 |
|------|------|
| `openhive set -server add <node_id> <ip>` | 添加 P2P 服务端点到 `config.json` |
| `openhive set -server remove <node_id> <ip>` | 从 `config.json` 移除 P2P 服务端点 |

**已废弃命令**: `set -ip` 和 `set -port` 已移除。IP 和端口通过 `config.json` 中的 `endpoints` 和 `server_endpoints` 字段配置。

**端口**: 端点端口固定使用 `kDefaultEndpointPort`（13133），自动识别 IPv4/IPv6 写入 `family` 字段。

**错误码**:

| 错误码 | 含义 |
|--------|------|
| -1 | action 不是 add 或 remove |
| -2 | node_id 为空 |
| -3 | IP 地址非法 |
| -4 | node_id 在 server_endpoints 中不存在 |
| -5 | 指定 node_id 下未找到该 IP |

### F.3 测试菜单

当编译时启用 `ENABLE_TX_TESTS` 宏时，高级菜单新增选项 **46. Transaction Tests**，提供 GTest 交易集成测试子菜单。

## 附录 G. HTML 统一样式系统

所有 GET 接口的 HTML 响应使用统一的样式模板（`ohi::rpc::html` 命名空间）：

| 函数 | 说明 |
|------|------|
| `html::style()` | 返回统一 CSS 样式表（GitHub 风格暗色主题） |
| `html::begin(title)` | 返回 HTML 页面头部（含品牌标识） |
| `html::end()` | 返回 HTML 页面尾部 |

**CSS 设计系统**:
- 使用 CSS 变量: `--bg: #0d1117`, `--surface: #161b22`, `--border: #30363d`, `--primary: #2ecc71`, `--text: #f0f6fc`, `--muted: #8b949e`
- 响应式布局: `max-width: 1400px`, 700px 断点适配移动端
- Content-Type: `text/html; charset=utf-8`

**受影响的页面**: Account Information、Block List、Node List、Thread and Request Statistics、Available Asset Types、Proposal Details（提案/投票）。

## 参考文献

1. Ethereum Yellow Paper: Ethereum: A Secure Decentralised Generalised Transaction Ledger
2. EVMC Specification: https://github.com/ethereum/evmc
3. evmone: https://github.com/ethereum/evmone
4. RocksDB Documentation: https://rocksdb.org/
5. RFC 2119: Key words for use in RFCs to Indicate Requirement Levels
6. Protobuf Specification: https://developers.google.com/protocol-buffers
7. Solana Protocol Specs: https://github.com/solana-labs/solana
8. IETF Cryptography Guidelines

---

**文档版本历史**:

| 版本 | 日期 | Commit Range | 变更说明 |
|------|------|--------------|----------|
| 0.1.0-draft | 2026-04-23 | - | 初始草案，基于现有代码分析 |
| 0.2.0-draft | 2026-06-16 | `f5281a3d..f8263f2c` | 项目更名 MeMeChain→OpenHive，代币 MM→OHI，首个跨链资产 hive；新增 VRF 准入池机制（6.4）、ExclusionProof 部分区块（5.7）、区块上链率探测（9.10）、消息加密控制（9.9）、NTP 国际化（9.11）；更新 Gas 模型（kBlockGasLimit=30M）、Genesis 配置（vrfWhitelist）；修正章节编号；更新 RPC 接口列表和常量表 |
| 0.3.0-draft | 2026-06-16 | `f8263f2c..HEAD` | 解决附录 E 全部 A 类 TODO：确认 VRF 签名为 ECDSA secp256k1（非 SilkPre）；确认 blockPrevRandao 基于 UTXO 哈希计算（非 VRF 种子）；补充 9 个预编译合约完整列表和 Gas 成本表；确认 evmone v0.14.1 / Cancun 级别；补充 Merkle 树双 SHA256 实现；补充主链选择双阈值机制（51%/66%）；补充回滚深度限制表；补充完整 RPC 错误码（99 个）；补充攻击缓解措施和已知限制；补充交易池淘汰策略 |
| 0.4.0-draft | 2026-07-03 | `3477cc9f..6ab5d2c` | **VRF 调度者共识协议**：VRF 周期 10s→15s，三阶段划分（广播/摘要交换/共识计算），自适应阈值（4档），边界确定性裁决，时间驱动多级降级（§6.3）；新增调度者选择（§6.5.4）。**Slashing 惩罚机制**：完整 L0-L4 五级体系（§6.9-6.13），三种违规检测，证据池共识，链上验证，质押扣减/永久除名/回滚。**Vote 资产移除**：所有 Vote 资产用途统一为 OHI（§11.1/11.3/11.4，附录 A.5）。**网络层加固**：19 项修复（连接限制/速率限制/消息去重/自动重连/信誉评分/密钥轮换/日蚀防护），IPv6 双栈（§9.20），监控指标（§9.21），层抽象接口（§9.22）。**RPC 变更**：JSON key camelCase 统一（§10.2.1），参数安全校验（§10.2.2），eth_sendRawTransaction 扩展多交易类型（§10.5.3）。**其他**：交易哈希清除三字段（§5.11），合约池保留机制（§7.5.3），BaseFee 有效性校验（§11.5.3），server_port 配置移除（§9.8），命名空间 mmc→ohi |
| 0.5.0-draft | 2026-07-15 | `6ab5d2c..484b7b3` | **合约重打包与并发安全**：授权批次原子性、批内连续 nonce、pending nonce/UTXO 原子预留、未来 nonce 整批等待、已确认交易排除证明、父块高度及哈希集合围栏、三次快速重打包与持久化延迟重试、验证端精确 VIN 重建、菜单33 pending 有界等待；连续两轮30秒/30TPS均为900/900（§7.5.4-§7.5.8）。 |

**维护说明**:

- 本文档应与代码同步更新
- 每次协议变更必须同步更新相关章节
- TODO 标记的项需要核心开发者确认后逐步消除
- 版本号应与协议升级对应
- **下次更新时**：从 `484b7b3` 开始追溯变更
