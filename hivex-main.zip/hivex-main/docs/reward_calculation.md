# Bonus 与 Fund 奖励计算机制

## 概述

| 维度 | Bonus（分红奖励） | Fund（国库奖励） |
|------|-------------------|-------------------|
| 奖励来源 | 通胀（年化收益率 × 委托金额） | 前一天全网 Gas 消耗（国库资金池） |
| 受益者 | 委托人 + 节点（佣金） | 节点本人 |
| 触发交易 | `BonusTrans` (`TxType::BONUS`) | `FundTrans` (`TxType::FUND`) |
| 实现文件 | `ca/transaction/bonus.cpp` | `ca/transaction/fund.cpp` |
| 核心算法 | `ca_algorithm::CalcBonusValue()` | `CheckFundQualificationAndGetRewardAmount()` |

---

## 一、Bonus（分红奖励）

### 1.1 资格检查（`EvaluateBonusEligibility`）

在计算奖励前，先进行 Slash 惩罚检查（`CalcBonusValue` 行 8959-9010）：

| 惩罚级别 | 条件 | 错误码 |
|----------|------|--------|
| **Tombstoned**（永久封禁） | DB 中存在 `slash_tombstone_<addr>` 记录 | `-201` |
| **L2 Forfeit（Jail 超时）** | `jailedDuration >= kForfeitJailPeriods` | `-200` |
| **L2 Forfeit（断连过多）** | 当前小时内断连次数 `>= kForfeitDisconnectCount` | `-200` |

### 1.2 工作量系数计算

调用 `fetchAbnormalSignAddrListByPeriod()` 获取：

- `addrSignCount`: 每个节点的签名数量
- `addr_percent`: 每个节点签名数占全网的比例（即 `dividendRate`）

分支逻辑：

```
IF dividendRate > 0:
    → 节点签名数低于全网平均值，按比例衰减
ELSE IF isQualified == true（addrSignCount 中存在该节点）:
    → 节点签名数高于全网平均值，按 dividendRate=1.0 全额领取
ELSE:
    → 节点无资格，返回 -5
```

### 1.3 年化收益率

```cpp
// ca/algorithm.cpp 行 ~9080
double stakingRate = 0.0;
GetNetworkStakingRate(curTime, stakingRate);      // 获取全网质押率（%）
GetNewAnnualizedRate(curTime, stakingRate, annualizedRate); // 根据质押率计算年化率（%）
annualizedRate = annualizedRate / 100.0;           // 转换为小数
```

### 1.4 委托金额获取

```cpp
GetDelegatingAmountAndDuration(bonusAddr, curTime, zeroTime, mpDelegatingAddr2Amount);
```

返回 `map<delegatorAddr, pair<amount, duration>>`。

### 1.5 最终奖励公式

$$\text{reward}_{delegator} = \text{dividendRate} \times \frac{\text{annualizedRate} \times \text{delegateAmount}}{365}$$

- `dividendRate`: 1.0（全额）或 <1.0（按工作量比例衰减）
- `annualizedRate`: 小数形式的年化收益率
- `delegateAmount`: 委托人对该节点的委托金额
- `365`: 年化到每日

### 1.6 佣金分配（`BonusTrans::trans()`）

```cpp
// bonus.cpp 行 ~168-185
for (auto delegator : delegator_reward_allocations) {
    operator_commission = delegator.second * temp_commission_rate + 0.5;  // 四舍五入
    total_operator_commission += operator_commission;
    uint64_t award = delegator.second - operator_commission;              // 委托人实际所得
    total_claim += award;
}
```

节点最终所得 = `total - expend + total_operator_commission`（`first_choose=false` 时）。

---

## 二、Fund（国库奖励）

### 2.1 资金池来源

```cpp
// fund.cpp 行 ~53-67
for (const auto &per_asset_type : asset_map) {
    uint64_t gas_amount = 0;
    dbReader.getGasAmountByPeriod(period - 1, per_asset_type.first, gas_amount);
    // period - 1 = 前一天的 Gas 消耗
    asset_type_amount[asset_type] = gas_amount;
}
```

资金池 = **前一天**全网 burn 的 Gas 总量（按资产类型分开）。

### 2.2 资格检查（`CheckFundQualificationAndGetRewardAmount`）

| 步骤 | 检查内容 | 失败码 |
|------|----------|--------|
| 1 | 时间窗口：`txTime` 在 `[今日00:00+1h, now+10s]` 之间 | `-1` / `-2` |
| 2 | 当前周期内是否已领取过（遍历 `getFundUtxoByPeriod`） | `-6` |
| 3 | 获取该地址所有 ≥24h 的锁定 UTXO 金额总和（`return_value`） | 成功返回 0 |

`return_value` = 该地址所有 `VIRTUAL_LOCK_ADDRESS` vout 的 value 之和。

### 2.3 两种分配方式

两种方式**可以同时触发**，各自独立计算，各占资金池的 **50%**。

#### A. 锁定奖励（`is_locked`）

触发条件：

```cpp
// fund.cpp 行 ~86-94
return_value != 0 && total_locked_amount != 0
```

公式：

```cpp
// createUtxoFundTransfer, fund.cpp 行 ~306
double rate = double(return_value) / double(total_locked_amount);
uint64_t value = uint64_t(rate * asset_type.second * 0.5);
```

$$\text{lockedReward} = \frac{\text{nodeLockedAmount}}{\text{totalLockedAmount}} \times \text{gasPool} \times 0.5$$

#### B. 打包奖励（`is_packaged`）

触发条件：

```cpp
// fund.cpp 行 ~96-108
VerifyBonusAddr(addr) == true   // 节点满足质押条件
&& times != 0 && count != 0     // 前一周期有打包记录
```

公式：

```cpp
// createUtxoFundTransfer, fund.cpp 行 ~314
double rate = double(times) / double(count);
uint64_t value = uint64_t(rate * asset_type.second * 0.5);
```

$$\text{packageReward} = \frac{\text{nodePackages}}{\text{totalBlocks}} \times \text{gasPool} \times 0.5$$

### 2.4 资格缺失处理

```cpp
// fund.cpp 行 ~117-120
if (!is_packaged && !is_locked) {
    ERRORLOG("Nodes are not eligible to claim fund");
    return -11;
}
```

两个条件都不满足 → 无法领取国库奖励。

---

## 三、流程图

```mermaid
flowchart TD
    subgraph Bonus["Bonus 分红奖励"]
        B1[检查 Slash 状态] --> B2{Tombstoned/Jail/断连?}
        B2 -->|是| B_Fail[拒绝领取]
        B2 -->|否| B3[获取节点签名数<br/>计算 dividendRate]
        B3 --> B4[获取全网质押率<br/>计算年化率]
        B4 --> B5[获取委托金额和时长]
        B5 --> B6["reward = dividendRate × annualizedRate × amount / 365"]
        B6 --> B7[按佣金比例分配给委托人和节点]
    end

    subgraph Fund["Fund 国库奖励"]
        F1[获取前一天 Gas 消耗总额] --> F2[检查时间窗口]
        F2 --> F3{是否已领取?}
        F3 -->|是| F_Fail[拒绝]
        F3 -->|否| F4[获取 ≥24h 锁定金额]
        F4 --> F5{is_locked?}
        F5 -->|是| F6["lockedReward = nodeLock/totalLock × gasPool × 0.5"]
        F5 -->|否| F7{is_packaged?}
        F7 -->|是| F8["packageReward = nodePkgs/totalBlocks × gasPool × 0.5"]
        F7 -->|否| F9{两者都不满足?}
        F9 -->|是| F_Fail2[返回 -11]
    end
```

---

## 四、关键数据结构

### Bonus 相关

| 变量/函数 | 说明 |
|-----------|------|
| `delegator_reward_allocations` | `map<delegatorAddr, rewardAmount>` — 每个委托人的奖励 |
| `temp_commission_rate` | 节点的佣金比例（由 `GetCommissionPercentage` 获取） |
| `dividendRate` | 工作量系数，范围 `(0, 1.0]` |
| `annualizedRate` | 年化收益率（小数形式） |

### Fund 相关

| 变量/函数 | 说明 |
|-----------|------|
| `asset_type_amount` | `map<assetType, gasAmount>` — 每种资产的资金池 |
| `return_value` | 该节点 ≥24h 的锁定总金额 |
| `total_locked_amount` | 全网总锁定金额 |
| `times` / `count` | 该节点打包次数 / 全网总出块数 |
| `locked_reward` / `packaged_reward` | 两部分奖励分别记录 |
