# eth_sendRawTransaction 业务 JSON 格式文档

## 概述

`eth_sendRawTransaction` 接口通过以太坊标准 RLP 编码的交易中的 `data` 字段承载业务 JSON。

### 判断逻辑

```
to 为空                    → 🚀 部署合约
data 不为空 && 是合法 JSON   → 📋 业务菜单分发
data 不为空 && 不是合法 JSON  → 📞 EVM 合约调用
data 为空                    → 💰 普通转账
```

### 公共字段说明

所有业务 JSON 共享以下公共字段：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `type` | string | ✅ | 业务类型标识，决定路由到哪个 handler |
| `is_find_utxo` | bool | ❌ | 是否全网查找 UTXO，默认 `false` |
| `sponsor_gas` | bool | ❌ | 是否单独支付手续费，默认 `false` |
| `gas_asset` | object | ❌ | 手续费支付资产信息 |
| `gas_asset.addr` | string | ❌ | 支付手续费的地址（0x 前缀） |
| `gas_asset.asset_type` | string | ❌ | 支付手续费的资产类型（0x 前缀） |
| `encoded_info` | string | ❌ | 交易备注（Base64 编码，最大 1KB），默认 `""` |

### 交易来源与去向

以下字段来自 `EthTransaction`（即 RLP 解码后的交易对象），**不在 JSON data 中**：

| 来源 | 说明 |
|------|------|
| `ethTx.from` | 交易发起方地址 |
| `ethTx.to` | 交易接收方地址（用于委托/解除委托的目标地址、转账的目标地址） |
| `ethTx.value` | 转账金额（仅普通转账使用） |

---

## 1. 普通转账 — `type: "tx"` 或 `"transaction"`

对应菜单: **HandleTransaction**

```json
{
    "type": "tx",
    "asset_type": "0x...",
    "amount": "100000000",
    "is_find_utxo": false,
    "sponsor_gas": false,
    "gas_asset": {
        "addr": "0x...",
        "asset_type": "0x..."
    },
    "encoded_info": ""
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `asset_type` | string | ❌ | `""` | 转账资产类型 |
| `amount` | string | ❌ | `"0"` | 转账金额（最小单位，整数） |

> **注意**: 收款地址从 `ethTx.to` 获取，付款地址从 `ethTx.from` 获取。

---

## 2. 质押 — `type: "stake"`

对应菜单: **HandleStake**

```json
{
    "type": "stake",
    "asset_type": "0x...",
    "amount": "100000000",
    "reward_rank": "10",
    "is_find_utxo": false,
    "sponsor_gas": false,
    "gas_asset": {
        "addr": "0x...",
        "asset_type": "0x..."
    },
    "encoded_info": ""
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `asset_type` | string | ❌ | `""` | 质押资产类型 |
| `amount` | string | ❌ | `"0"` | 质押金额（最小单位，整数） |
| `reward_rank` | string | ❌ | `"10"` | 分红抽成比例，取值范围 `"1"` ~ `"35"`（对应 1%~35%） |

> **注意**: 质押地址从 `ethTx.from` 获取。

---

## 3. 解除质押 — `type: "unstake"`

对应菜单: **HandleUnstake**

```json
{
    "type": "unstake",
    "asset_type": "0x...",
    "stake_utxo_hash": "0x...",
    "is_find_utxo": false,
    "sponsor_gas": false,
    "gas_asset": {
        "addr": "0x...",
        "asset_type": "0x..."
    },
    "encoded_info": ""
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `asset_type` | string | ❌ | `""` | 质押资产类型 |
| `stake_utxo_hash` | string | ❌ | `""` | 要解除质押的 UTXO hash |

> **注意**: 解除质押地址从 `ethTx.from` 获取。

---

## 4. 委托 — `type: "delegating"` 或 `"delegate"`

对应菜单: **handleDelegating**

```json
{
    "type": "delegating",
    "asset_type": "0x...",
    "amount": "100000000",
    "delegate_type": "1",
    "is_find_utxo": false,
    "sponsor_gas": false,
    "gas_asset": {
        "addr": "0x...",
        "asset_type": "0x..."
    },
    "encoded_info": ""
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `asset_type` | string | ❌ | `""` | 委托资产类型 |
| `amount` | string | ❌ | `"0"` | 委托金额（最小单位，整数） |
| `delegate_type` | string | ❌ | `"1"` | 委托类型（整数） |

> **注意**: 委托发起地址从 `ethTx.from` 获取，被委托地址从 `ethTx.to` 获取。

---

## 5. 撤销委托 — `type: "undelegating"` 或 `"undelegate"`

对应菜单: **HandleUndelegating**

```json
{
    "type": "undelegating",
    "asset_type": "0x...",
    "utxo_hash": "0x...",
    "is_find_utxo": false,
    "sponsor_gas": false,
    "gas_asset": {
        "addr": "0x...",
        "asset_type": "0x..."
    },
    "encoded_info": ""
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `asset_type` | string | ❌ | `""` | 委托资产类型 |
| `utxo_hash` | string | ❌ | `""` | 要撤销委托的 UTXO hash |

> **注意**: 发起地址从 `ethTx.from` 获取，被撤销的委托节点地址从 `ethTx.to` 获取。

---

## 6. 领取奖励 — `type: "bonus"`

对应菜单: **HandleBonus**

```json
{
    "type": "bonus",
    "asset_type": "0x...",
    "first_choose": false,
    "is_find_utxo": false,
    "sponsor_gas": false,
    "gas_asset": {
        "addr": "0x...",
        "asset_type": "0x..."
    },
    "encoded_info": ""
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `asset_type` | string | ❌ | `""` | 领取奖励的资产类型 |
| `first_choose` | bool | ❌ | `false` | 是否首次选择 |

> **注意**: 领取地址从 `ethTx.from` 获取。

---

## 7. 锁定（投票质押） — `type: "lock"`

对应菜单: **HandleLock**

```json
{
    "type": "lock",
    "lock_amount": "100000000",
    "lock_type": "1",
    "is_find_utxo": false,
    "sponsor_gas": false,
    "gas_asset": {
        "addr": "0x...",
        "asset_type": "0x..."
    },
    "encoded_info": ""
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `lock_amount` | string | ❌ | `"0"` | 锁定金额（最小单位，整数） |
| `lock_type` | string | ❌ | `"1"` | 锁定类型，对应 `TxHelper::LockType` 枚举值 |

> **注意**: 锁定地址从 `ethTx.from` 获取。锁定后获得投票权限。

---

## 8. 解除锁定 — `type: "unlock"`

对应菜单: **HandleUnLock**

```json
{
    "type": "unlock",
    "utxo_hash": "0x...",
    "is_find_utxo": false,
    "sponsor_gas": false,
    "gas_asset": {
        "addr": "0x...",
        "asset_type": "0x..."
    },
    "encoded_info": ""
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `utxo_hash` | string | ❌ | `""` | 要解除锁定的 UTXO hash |

> **注意**: 解除锁定地址从 `ethTx.from` 获取。

---

## 9. 投票 — `type: "vote"`

对应菜单: **HandleVote**

```json
{
    "type": "vote",
    "vote_hash": "0x...",
    "vote": "1",
    "is_find_utxo": false,
    "sponsor_gas": false,
    "gas_asset": {
        "addr": "0x...",
        "asset_type": "0x..."
    },
    "encoded_info": ""
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `vote_hash` | string | ❌ | `""` | 投票的提案 hash |
| `vote` | string | ❌ | `"1"` | `"1"` = 赞成（PROPOSAL），`"0"` = 反对（REVOKEPROPOSAL） |

> **注意**: 投票地址从 `ethTx.from` 获取。`vote` 字段支持字符串 `"0"`/`"1"` 或布尔值 `true`/`false`。

---

## 10. 发起提案 — `type: "proposal"`

对应菜单: **HandleProposal**（创世账号发起添加资产投票提案）

```json
{
    "type": "proposal",
    "vote_hash": "0x...",
    "is_find_utxo": false,
    "sponsor_gas": false,
    "gas_asset": {
        "addr": "0x...",
        "asset_type": "0x..."
    },
    "encoded_info": ""
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `vote_hash` | string | ❌ | `""` | 提案 hash |
| `proposal_hash` | string | ❌ | `""` | 提案 hash 的备用字段名 |

> **注意**: 内部等价于 `type: "vote"` + `vote: "1"`（赞成票）。`vote_hash` 和 `proposal_hash` 任选其一。

---

## 11. 撤销提案 — `type: "revoke_proposal"` 或 `"revokeProposal"`

对应菜单: **revokeProposalRequest**（创世账号撤销资产投票提案）

```json
{
    "type": "revoke_proposal",
    "vote_hash": "0x...",
    "is_find_utxo": false,
    "sponsor_gas": false,
    "gas_asset": {
        "addr": "0x...",
        "asset_type": "0x..."
    },
    "encoded_info": ""
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `vote_hash` | string | ❌ | `""` | 提案 hash |
| `proposal_hash` | string | ❌ | `""` | 提案 hash 的备用字段名 |

> **注意**: 内部等价于 `type: "vote"` + `vote: "0"`（反对票）。

---

## 12. 申领国库奖励 — `type: "fund"` 或 `"treasury"`

对应菜单: **HandleTresury**

```json
{
    "type": "fund",
    "is_find_utxo": false,
    "encoded_info": ""
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| 无额外字段 | — | — | — | 仅需公共字段 |

> **注意**: 申领地址从 `ethTx.from` 获取。该类型**不需要** `gas_asset` 和 `sponsor_gas`。

---

## 附录: type 值速查表

| `type` 值 | 对应菜单 | Handler 函数 |
|-----------|----------|-------------|
| `"tx"` / `"transaction"` | HandleTransaction | `handle_transaction` |
| `"stake"` | HandleStake | `handle_stake` |
| `"unstake"` | HandleUnstake | `handle_unstake` |
| `"delegating"` / `"delegate"` | handleDelegating | `handle_delegating` |
| `"undelegating"` / `"undelegate"` | HandleUndelegating | `handle_undelegating` |
| `"bonus"` | HandleBonus | `handle_bonus` |
| `"lock"` | HandleLock | `handle_lock` |
| `"unlock"` | HandleUnLock | `handle_unlock` |
| `"vote"` | HandleVote | `handle_vote` |
| `"proposal"` | HandleProposal | `handle_proposal` |
| `"revoke_proposal"` / `"revokeProposal"` | revokeProposalRequest | `handle_revoke_proposal` |
| `"fund"` / `"treasury"` | HandleTresury | `handle_treasury` |

## 附录: 完整调用示例

### 客户端构造交易的伪代码流程

```
1. 构造 JSON data：
   {
     "type": "stake",
     "asset_type": "0x...",
     "amount": "100000000",
     "reward_rank": "10",
     ...
   }

2. 将 JSON 字符串编码为 hex：
   json_str = JSON.stringify(data)
   data_hex = toHex(json_str)   // 字符串 → hex bytes

3. 构造以太坊交易：
   EthTransaction {
     from: "0xSenderAddress...",
     to: "",                    // stake 不需要 to，留空或填任意值
     value: "0x0",
     data: data_hex,            // JSON 的 hex 编码
     gasLimit: 21000,
     gasPrice: ...,
     nonce: ...,
     chainId: 12315
   }

4. RLP 编码交易 → 得到 rawTx hex

5. 调用 RPC：
   {
     "jsonrpc": "2.0",
     "method": "eth_sendRawTransaction",
     "params": ["0x<rawTx_hex>"],
     "id": 1
   }

6. 返回值：
   {
     "jsonrpc": "2.0",
     "id": 1,
     "result": "0x<tx_hash>"
   }
```
