# NET-011: 节点信誉评分系统

**级别**: P1（建议修复）  
**预估工作量**: 5-7 天  
**涉及文件**: 新增 `net/peer_scorer.h/cpp`，修改 `net/peer_node.cpp`, `net/dispatcher.cpp`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

当前所有通过签名验证的节点一视同仁，无法识别和隔离慢节点、不可靠节点或恶意节点。

**影响**：
- 恶意节点可以长期存在于网络中
- 慢节点影响广播和同步效率
- 无法做出智能的连接决策（如优先连接高质量节点）

---

## 修复方案

### 1. 评分维度

| 维度 | 权重 | 说明 |
|------|------|------|
| 响应延迟 | 20% | Ping/Pong RTT |
| 消息有效性 | 25% | 收到的消息是否通过验证 |
| 在线时长 | 15% | 持续在线时间 |
| 消息频率 | 10% | 是否在合理范围内 |
| 协议合规 | 20% | 是否遵守协议规范 |
| 区块贡献 | 10% | 是否提供有效区块数据 |

### 2. 共享 PeerStats 结构

> **审查修正**：NET-003（速率限制）、NET-007（消息去重统计）、NET-011（信誉评分）和 NET-019（监控指标）都需要 per-peer 统计数据。为避免重复维护和多次 `locateNodeByFd` 调用，引入统一的 `PeerStats` 结构体。

```cpp
// node.hpp - 新增 PeerStats 结构，挂在 Node 上
struct PeerStats {
    // === NET-003 速率限制字段 ===
    double tokens = 100.0;                          // 令牌桶当前令牌数
    std::chrono::steady_clock::time_point last_refill;  // 上次补充时间
    bool rate_limited = false;                      // 是否被限流
    int rate_limit_violations = 0;                  // 限流违规次数
    
    // === NET-011 信誉评分字段 ===
    double latency_score = 0.5;
    double validity_score = 0.5;
    double uptime_score = 0.0;
    double frequency_score = 0.5;
    double compliance_score = 0.5;
    double contribution_score = 0.0;
    double total_score = 0.5;
    
    // === 通用统计字段（NET-019 监控也使用）===
    uint64_t messages_received = 0;
    uint64_t messages_valid = 0;
    uint64_t messages_invalid = 0;
    uint64_t messages_dropped = 0;
    uint64_t bytes_received = 0;
    uint64_t bytes_sent = 0;
    double avg_rtt_ms = 0.0;
    std::chrono::steady_clock::time_point first_seen;
    std::chrono::steady_clock::time_point last_seen;
    int protocol_violations = 0;
    
    // 令牌桶补充
    void refillTokens(std::chrono::steady_clock::time_point now) {
        double elapsed = std::chrono::duration<double>(now - last_refill).count();
        tokens = std::min(100.0, tokens + elapsed * kMaxMessagesPerPeerPerSecond);
        last_refill = now;
    }
    
    bool consumeToken() {
        if (tokens < 1.0) return false;
        tokens -= 1.0;
        return true;
    }
    
    // 信誉评分重算
    void recalculateScore() {
        total_score = 
            0.20 * latency_score +
            0.25 * validity_score +
            0.15 * uptime_score +
            0.10 * frequency_score +
            0.20 * compliance_score +
            0.10 * contribution_score;
    }
};

struct Node {
    // ... 现有字段
    
    // 新增：统一的 per-peer 统计
    PeerStats peer_stats;
};
```

### 3. 评分更新时机

> `PeerScorer` 不再维护独立的 `scores_` map，而是直接操作 `Node::peer_stats` 中的评分字段。

```cpp
class PeerScorer {
public:
    // 收到消息时（在 dispatcher Handle() 中调用）
    void onMessageReceived(Node& node, bool valid) {
        auto& stats = node.peer_stats;
        stats.messages_received++;
        if (valid) {
            stats.messages_valid++;
            stats.validity_score = (double)stats.messages_valid / stats.messages_received;
        } else {
            stats.messages_invalid++;
            stats.validity_score *= 0.9;  // 惩罚
        }
        stats.last_seen = std::chrono::steady_clock::now();
        stats.recalculateScore();
    }
    
    // Ping/Pong 时更新 RTT
    void onRttMeasured(Node& node, double rtt_ms) {
        auto& stats = node.peer_stats;
        // 指数移动平均
        stats.avg_rtt_ms = stats.avg_rtt_ms * 0.8 + rtt_ms * 0.2;
        
        // RTT 评分：< 100ms = 1.0, > 5000ms = 0.0
        stats.latency_score = std::max(0.0, std::min(1.0, 
            1.0 - (stats.avg_rtt_ms - 100.0) / 4900.0));
        stats.recalculateScore();
    }
    
    // 协议违规时
    void onProtocolViolation(Node& node) {
        auto& stats = node.peer_stats;
        stats.protocol_violations++;
        stats.compliance_score *= 0.8;  // 每次违规打 8 折
        stats.recalculateScore();
    }
    
    // 速率限制违规时（由 NET-003 调用）
    void onRateLimitViolation(Node& node) {
        auto& stats = node.peer_stats;
        stats.compliance_score *= 0.9;
        stats.recalculateScore();
    }
    
    // 获取评分
    double getScore(const std::string& addr) const {
        auto node = PeerNode::GetInstance()->FindNode(addr);
        return node ? node->peer_stats.total_score : 0.5;
    }
    
    // 判断是否应该断开
    bool shouldDisconnect(const Node& node) const {
        return node.peer_stats.total_score < 0.1;  // 低于 0.1 断开
    }
};
```

### 4. 集成到消息处理

```cpp
// dispatcher.cpp - Handle() 中
void ProtobufDispatcher::Handle(int fd, const std::string& data) {
    auto node = PeerNode::GetInstance()->locateNodeByFd(fd);
    if (!node) return;
    
    // ... 解析消息
    
    bool valid = (parseResult >= 0);
    PeerScorer::getInstance()->onMessageReceived(node->address, valid);
    
    if (!valid) return;
    
    // ... 正常处理
}
```

### 5. 连接决策优化

```cpp
// 在节点同步时，优先连接高分节点
void syncStartNode() {
    auto candidates = collectNewNodes();
    
    // 按评分排序
    std::sort(candidates.begin(), candidates.end(), 
        [](const Node& a, const Node& b) {
            return PeerScorer::getInstance()->getScore(a.address) > 
                   PeerScorer::getInstance()->getScore(b.address);
        });
    
    // 优先连接前 N 个高分节点
    for (int i = 0; i < std::min((int)candidates.size(), 10); i++) {
        Register(candidates[i]);
    }
}
```

### 6. 评分衰减

评分应随时间衰减，避免历史数据过度影响：

```cpp
// 每小时执行一次
void decayScores() {
    for (auto& [addr, score] : scores_) {
        // 所有维度向 0.5（中性值）衰减 1%
        score.latency_score = score.latency_score * 0.99 + 0.5 * 0.01;
        score.validity_score = score.validity_score * 0.99 + 0.5 * 0.01;
        // ...
        score.recalculate();
    }
}
```

---

## 配置化

```json
{
    "network": {
        "peer_scoring": {
            "enabled": true,
            "disconnect_threshold": 0.1,
            "decay_interval_hours": 1,
            "decay_factor": 0.01
        }
    }
}
```

---

## 验证方法

1. 模拟发送无效消息的节点，验证评分下降
2. 模拟高延迟节点，验证延迟评分下降
3. 验证长期在线节点评分提升
4. 验证低分节点被断开
5. 验证高分节点被优先连接

---

## 兼容性

- 纯本地逻辑，不影响协议
- 其他节点无需升级
