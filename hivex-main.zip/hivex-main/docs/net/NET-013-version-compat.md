# NET-013: 版本兼容性协商

**级别**: P2（可选修复）  
**预估工作量**: 1-2 天  
**涉及文件**: `net/dispatcher.cpp`, `net/net_version.h/cpp`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

当前版本号 `"0.0"` 严格匹配，不匹配直接拒绝：

```cpp
// dispatcher.cpp:33
if (commonMsg.version() != mm::GetNetVersion()) {
    ERRORLOG("commonMsg.version() {}", commonMsg.version());
    return -2;  // 直接拒绝
}
```

**影响**：
- 升级时新旧版本节点无法通信
- 网络分裂风险
- 无法进行滚动升级

---

## 修复方案

### 1. 语义化版本

```cpp
// net_version.h
struct NetVersion {
    int major = 0;
    int minor = 0;
    int patch = 0;
    
    std::string toString() const {
        return std::to_string(major) + "." + std::to_string(minor) + "." + std::to_string(patch);
    }
    
    static NetVersion parse(const std::string& s) { /* ... */ }
    
    // 兼容性判断
    bool isCompatibleWith(const NetVersion& other) const {
        // major 不同 = 不兼容
        // major 相同，minor 不同 = 兼容（新功能可选）
        // major.minor 相同，patch 不同 = 完全兼容
        return major == other.major;
    }
};
```

### 2. 兼容性检查

```cpp
// dispatcher.cpp
if (!commonMsg.version().isCompatibleWith(mm::GetNetVersion())) {
    WARNLOG("Incompatible version: local={}, remote={}", 
            mm::GetNetVersion().toString(), commonMsg.version());
    return -2;
}

// 版本不同但兼容时记录日志
if (commonMsg.version() != mm::GetNetVersion()) {
    INFOLOG("Compatible version mismatch: local={}, remote={}", 
            mm::GetNetVersion().toString(), commonMsg.version());
}
```

### 3. 版本协商（可选增强）

在节点注册时交换支持的版本列表：

```protobuf
message NodeInfo {
    // ... 现有字段
    repeated string supported_versions = 15;  // 支持的协议版本列表
}
```

双方选择最高共同版本作为通信版本。

---

## 兼容性

- 需要更新版本号格式
- 向后兼容：旧版本节点仍使用字符串匹配
