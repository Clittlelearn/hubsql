# NET-008: 发送缓冲区大小限制

**级别**: P1（建议修复）  
**预估工作量**: 0.5 天  
**涉及文件**: `net/socket_buf.h`, `net/socket_buf.cpp`, `net/define.h`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

`SocketBuf::PushSendMsg()` 直接追加数据到 `_sendCache`，无大小限制：

```cpp
// socket_buf.cpp:136-139
void SocketBuf::PushSendMsg(const std::string& data) {
    this->_sendCache += data;  // 无上限检查
}
```

如果远端消费速度慢，发送缓冲区会无限增长，最终导致 OOM。

---

## 修复方案

### 1. 定义缓冲区大小限制

```cpp
// define.h
constexpr size_t kMaxSendBufferSize = 16 * 1024 * 1024;  // 16MB per peer
```

### 2. 在 PushSendMsg 中检查

```cpp
// socket_buf.cpp
// 返回类型从 void 改为 bool
bool SocketBuf::PushSendMsg(const std::string& data) {
    std::lock_guard<std::mutex> lck(sendMutex);
    if (_sendCache.size() + data.size() > kMaxSendBufferSize) {
        ERRORLOG("Send buffer exceeds limit: {} + {} > {}",
                 _sendCache.size(), data.size(), kMaxSendBufferSize);
        return false;  // 返回失败，调用方应断开连接
    }
    _sendCache += data;
    return true;
}
```

### 3. 调用方处理

> **审查修正**：`bufferControl` 内部使用 `std::map<uint64_t, std::shared_ptr<SocketBuf>>` 存储，key 是 `portAndIp`（端口和 IP 的组合），不是 fd。通过 `MagicSingleton<bufferControl>::GetInstance()` 访问。

```cpp
// socket_buf.cpp - addWritePack_() 中
// 调用链：net_com::SendOneMessage() -> bufferControl::addWritePack_() -> SocketBuf::PushSendMsg()
void bufferControl::addWritePack_(uint32_t ip, uint16_t port, const std::string& data) {
    auto buf = GetSocketBuf(ip, port);
    if (!buf) return;
    
    if (!buf->PushSendMsg(data)) {
        ERRORLOG("Send buffer full for {}:{}, disconnecting", IpPort::IpToStr(ip), port);
        // 标记需要断开，由上层处理
    }
}
```

---

## 验证方法

1. 模拟慢消费者（不读取数据），验证缓冲区增长到上限后消息被拒绝
2. 验证正常消费者不受影响
3. 验证缓冲区超限后连接被正确处理

---

## 兼容性

- 纯本地限制，不影响协议
