# NET-016: IPv6 双栈支持

**级别**: P2（可选修复）
**实施状态**: ✓ 已完成
**实施提交**: `1d42c2f`（fix_net_ipv6 分支）
**实际工作量**: 约 2 周（7 个阶段，17 个文件，772 行新增）

---

## 背景

OpenHive 网络层最初只支持 IPv4，所有 socket 使用 `AF_INET`，IP 地址用 `uint32_t` 存储。随着 IPv6 的普及，这个限制越来越明显——在 IPv6-only 的网络环境中，节点完全无法通信。

NET-016 的目标是让 OpenHive 同时支持 IPv4 和 IPv6，而不是二选一。我们选择了**双栈（dual-stack）**方案：一个 socket 同时接受两种连接，新旧代码共存，IPv4 节点完全不受影响。

---

## 实施过程

整个实现分 7 个阶段，从底层数据结构到上层配置逐步推进，每个阶段都保证编译通过。

### 阶段 1：核心数据结构

最基础的一步——让 Node 和 MsgData 能存 IPv6 地址。

我们没有直接改 `uint32_t publicIp` 的类型（那会导致大量代码编译失败），而是**新增**了 `std::string publicAddr` 和 `std::string listenAddr` 字段。旧字段保留，新字段并存。Node 结构提供了 `getPublicAddrStr()` 方法，优先返回新字段，如果新字段为空就回退到旧字段——这样现有代码不用改也能正常工作。

`bufferControl` 原来用 `uint64_t portAndIp` 做 key，IPv6 地址塞不进 64 位。我们新增了一个 `std::map<std::string, SocketBuf>` 映射表，key 格式是 `"addr:port"`。旧的 map 保留，两套并存。

**修改文件**：`node.hpp`、`msg_queue.h`、`socket_buf.h/cpp`、`api.h/cpp`

### 阶段 2：Socket 操作层

这一步让网络层真正能收发 IPv6 数据包。

监听 socket 改用 `AF_INET6`，同时设置 `IPV6_V6ONLY=0`，这样一个 socket 就能同时接受 IPv4 和 IPv6 连接。连接函数新增了 `InitConnection(const std::string& addr, ...)` 重载，根据地址内容自动选择 `AF_INET` 或 `AF_INET6`。

`epoll_mode.cpp` 的 accept 逻辑改用 `sockaddr_storage`，accept 后检查 `ss_family` 判断是 IPv4 还是 IPv6，分别提取地址。

`IpPort` 工具类新增了 6 个方法：`IsValidIPv6()`、`IsIPv6()`、`IsLocalIPv6()`、`IsPublicIPv6()`、`get_peer_addr_str()`、`IsLanAddr()`。其中 `IsLanAddr()` 统一处理 IPv4 和 IPv6 的局域网判断，后续代码都用这个方法替代了原来的 `IsLan(IpSz(ip))`。

**修改文件**：`api.cpp`、`api.h`、`epoll_mode.cpp`、`ip_port.h/cpp`

### 阶段 3：消息处理层

这一步把消息处理链路中的 IP 地址日志输出改为使用新的地址字符串方法。

`handle_event.cpp` 中有大量 `IpPort::IpSz(from.ip)` 的调用，全部替换为 `from.getAddrStr()`。局域网检测从 `IpPort::IsLan(IpPort::IpSz(from.ip))` 改为 `IpPort::IsLanAddr(from.getAddrStr())`，这样 IPv6 地址也能正确判断。

`dispatcher.cpp` 不需要修改——它不直接使用 IP 地址。

**修改文件**：`handle_event.cpp`、`work_thread.cpp`

### 阶段 4：协议定义

节点之间交换节点信息时，需要能传递 IPv6 地址。

`net.proto` 的 `NodeInfo` 消息新增了三个字段：
- `listen_addr`（编号 15）：监听地址字符串
- `node_public_addr`（编号 16）：公网地址字符串
- `ip_version`（编号 17）：IP 版本标识（0=未知，4=IPv4，6=IPv6）

`RegisterNodeAck` 新增了 `from_addr`（编号 6）字段。

旧的 `uint32 listen_ip`、`uint32 public_ip` 等字段保留不动，确保旧版本节点仍然能正常通信。

**修改文件**：`proto/net.proto`

### 阶段 5：上层逻辑

把 peer_node、unregister_node、key_exchange 中的 IP 地址日志输出改为使用新的地址字符串方法。

改动比较机械，主要是把 `IpPort::IpSz(node.publicIp)` 替换为 `node.getPublicAddrStr()`，把 `IpPort::IpSz(IpPort::get_peer_nip_info(fd))` 替换为 `IpPort::get_peer_addr_str(fd)`。

**修改文件**：`peer_node.cpp`、`unregister_node.cpp`、`key_exchange.cpp`

### 阶段 6：配置管理

config.json 中的 IP 地址配置需要能接受 IPv6 格式。

新增了 `isValidIPv6()` 和 `isValidIP()` 函数。`FilterIp()` 和 `filter_server_ip()` 原来用正则表达式只匹配 IPv4 格式，现在改为调用 `isValidIP()`，同时支持 IPv4 和 IPv6。

**修改文件**：`common/config.h`、`common/config.cpp`

### 阶段 7：验证与提交

逐一检查了所有修改文件，确认没有遗漏的 IPv4 专用代码。编译通过后提交。

---

## 关键设计决策

### 为什么选择渐进式修改而非一次性重构？

直接改 `uint32_t publicIp` 为 `std::string` 会导致几十个文件编译失败。渐进式修改的好处是：每个阶段都能编译通过，随时可以停下来测试，风险可控。

### 为什么保留旧的 uint32 字段？

向后兼容。旧版本节点只认识 `uint32 public_ip`，新版本节点两种字段都填。这样新旧节点可以正常通信，不需要所有节点同时升级。

### 为什么用双栈 socket 而不是分别监听？

双栈 socket（`AF_INET6` + `IPV6_V6ONLY=0`）用一个 socket 就能同时接受 IPv4 和 IPv6 连接，管理简单。如果分别监听两个 socket，需要维护两套 fd，epoll 逻辑也会更复杂。

---

## 兼容性

- **IPv4 完全兼容**：旧的 `uint32_t` IP 字段保留，旧版本节点不受影响
- **协议向后兼容**：Protobuf 新增字段使用新编号，旧节点忽略这些字段
- **配置向后兼容**：config.json 中的 IPv4 地址仍然有效
- **双栈监听**：一个 socket 同时接受 IPv4 和 IPv6 连接

---

## 修改文件清单

| 文件 | 修改内容 |
|------|---------|
| `net/node.hpp` | 新增 IpVersion 枚举、publicAddr/listenAddr 字段、辅助方法 |
| `net/msg_queue.h` | MsgData 新增 addr 字段、getAddrStr() 方法 |
| `net/socket_buf.h/cpp` | 新增 string-keyed bufferControl map、9 个双栈接口 |
| `net/api.h/cpp` | 双栈监听、新 InitConnection 重载、packAddrAndPort 函数 |
| `net/epoll_mode.cpp` | sockaddr_storage accept、地址族检测 |
| `net/ip_port.h/cpp` | 6 个 IPv6 支持方法 |
| `net/handle_event.cpp` | IsLanAddr 替换、日志输出改用 getAddrStr() |
| `net/work_thread.cpp` | 日志输出改用 getAddrStr() |
| `net/peer_node.cpp` | 日志输出改用 getPublicAddrStr() |
| `net/unregister_node.cpp` | 日志输出改用 getPublicAddrStr() |
| `net/key_exchange.cpp` | 日志输出改用 getPublicAddrStr() |
| `proto/net.proto` | NodeInfo 新增 3 字段、RegisterNodeAck 新增 1 字段 |
| `common/config.h/cpp` | isValidIPv6/isValidIP 函数、FilterIp 支持双栈 |
