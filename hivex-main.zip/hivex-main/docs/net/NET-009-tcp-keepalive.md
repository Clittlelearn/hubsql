# NET-009: TCP keepalive 配置

**级别**: P1（建议修复）  
**预估工作量**: 0.5 天  
**涉及文件**: `net/api.cpp`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

当前未配置任何 TCP 层面的 keepalive 选项。半开连接（如对端突然断网、电源断开）只能依赖应用层心跳检测（最长 180 秒才能发现）。

---

## 修复方案

在建立 TCP 连接后（`InitConnection()` 和 `accept()` 后），配置 keepalive：

```cpp
// api.cpp - 新增函数
void configureTcpKeepalive(int fd) {
    int enable = 1;
    int idle = 60;     // 空闲 60 秒后开始发送 keepalive 探测
    int interval = 10; // 每 10 秒发送一次探测
    int count = 3;     // 3 次无响应判定为断开
    
    setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &enable, sizeof(enable));
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPIDLE, &idle, sizeof(idle));
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPINTVL, &interval, sizeof(interval));
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPCNT, &count, sizeof(count));
}
```

在两个地方调用：

```cpp
// 1. 主动连接（InitConnection 成功后）
int fd = Socket(AF_INET, SOCK_STREAM, 0);
// ... connect ...
configureTcpKeepalive(fd);

// 2. 被动连接（EpollLoop accept 后）
int clientFd = accept(fdServerMain, ...);
configureTcpKeepalive(clientFd);
```

---

## 效果

- 半开连接在 60 + 10×3 = 90 秒内被内核检测并关闭
- 与应用层心跳（180 秒）互补，更快发现断连
- 不增加额外代码复杂度

---

## 验证方法

1. 使用 `tcpdump` 观察 keepalive 探测包
2. 模拟半开连接（iptables DROP），验证 90 秒内连接被关闭
3. 正常连接不受影响

---

## 兼容性

- TCP 层配置，不影响应用层协议
- 对端无需任何配合
