# NET-005: HTTP RPC 认证机制

**级别**: P0（必须修复）  
**预估工作量**: 1-2 天  
**涉及文件**: `net/http_server.cpp`, `net/http_server.h`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

HTTP RPC 服务器无任何认证机制：
- 无 API Key / Bearer Token 验证
- 无用户名/密码认证
- 无 IP 白名单
- 无请求体大小限制
- 无速率限制
- CORS 设置为 `Allow-Origin: *`

**风险**：
- 任何能访问 HTTP 端口的人都可以调用所有 RPC 方法
- 包括 `eth_sendRawTransaction` 等敏感操作
- 可被用于发起大量请求造成拒绝服务

---

## 修复方案

### 1. API Key 认证

在 `config.json` 中配置：

```json
{
    "rpc": {
        "enable_auth": true,
        "api_key": "your-secret-api-key-here",
        "api_key_header": "X-API-Key"
    }
}
```

在 HTTP 服务器中验证：

```cpp
// http_server.cpp
void HttpServer::handlePost(const httplib::Request& req, httplib::Response& res) {
    // 1. 检查 API Key
    if (config_->GetEnableRpcAuth()) {
        auto it = req.headers.find(config_->GetApiKeyHeader());
        if (it == req.headers.end() || it->second != config_->GetApiKey()) {
            res.status = 401;
            res.set_content(R"({"error":"Unauthorized"})", "application/json");
            return;
        }
    }
    
    // ... 正常处理
}
```

### 2. IP 白名单

```json
{
    "rpc": {
        "enable_ip_whitelist": false,
        "allowed_ips": ["127.0.0.1", "192.168.1.0/24"]
    }
}
```

```cpp
bool HttpServer::isIpAllowed(const std::string& clientIp) {
    if (!config_->GetEnableIpWhitelist()) return true;
    
    for (const auto& allowed : config_->GetAllowedIps()) {
        if (matchIpRange(clientIp, allowed)) return true;
    }
    return false;
}
```

### 3. 请求体大小限制

```cpp
// http_server.cpp - 初始化时
svr.set_payload_max_length(1024 * 1024);  // 1MB 上限
```

### 4. HTTP 速率限制

```cpp
// 简单的 per-IP 速率限制
class HttpRateLimiter {
    std::unordered_map<std::string, std::deque<time_point>> requests_;
    std::mutex mutex_;
    
public:
    bool allow(const std::string& ip) {
        std::lock_guard<std::mutex> lock(mutex_);
        auto now = steady_clock::now();
        auto& q = requests_[ip];
        
        while (!q.empty() && now - q.front() > seconds(1))
            q.pop_front();
        
        if (q.size() >= 100) return false;  // 100 req/s per IP
        q.push_back(now);
        return true;
    }
};
```

### 5. CORS 修复

```cpp
// 移除过于宽松的 CORS
// 原: Access-Control-Allow-Origin: *
// 改: 根据配置设置
if (!config_->GetAllowedOrigins().empty()) {
    res.set_header("Access-Control-Allow-Origin", config_->GetAllowedOrigins());
} else {
    // 默认只允许同源
    res.set_header("Access-Control-Allow-Origin", req.get_header_value("Origin"));
}
```

### 6. 移除硬编码日志

```cpp
// 移除 http_server.cpp:277 的硬编码日志
// std::ofstream os("/root/mm/build/bin/http_log.txt", std::ios::app);
// 替换为 spdlog 或可配置的日志
```

---

## 配置汇总

```json
{
    "rpc": {
        "enable_auth": true,
        "api_key": "your-secret-api-key-here",
        "api_key_header": "X-API-Key",
        "enable_ip_whitelist": false,
        "allowed_ips": ["127.0.0.1"],
        "max_request_body_size": 1048576,
        "rate_limit_per_ip_per_second": 100,
        "allowed_origins": ""
    }
}
```

---

## 验证方法

1. 无 API Key 请求返回 401
2. 正确 API Key 请求正常处理
3. 非白名单 IP 请求被拒绝
4. 超大请求体被拒绝
5. 高频请求被速率限制

---

## 兼容性

- 新增配置项，默认关闭认证（向后兼容）
- TestNet/Primary 部署时启用认证
- DevNet 可保持关闭以方便调试
