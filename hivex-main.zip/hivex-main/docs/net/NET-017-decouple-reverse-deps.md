# NET-017: 解耦 net/ 对 ca/ 的反向依赖

**级别**: 架构优化（长期）  
**预估工作量**: 2-3 天  
**涉及文件**: `net/interface.h`, `net/api.cpp`, `net/unregister_node.cpp`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

`net/` 有 4 处反向依赖 `ca/`，破坏了分层架构：

| 文件 | 依赖内容 | 性质 |
|------|---------|------|
| `net/interface.h:13` | `#include "../ca/block_rate_probe.h"` | 头文件依赖 |
| `net/api.cpp:46` | `#include "../ca/algorithm.h"` | 算法工具引用 |
| `net/unregister_node.cpp:15` | `#include "../ca/algorithm.h"` | 算法工具引用 |
| `net/unregister_node.cpp:16` | `#include "../ca/bonus_addr_cache.h"` | **高耦合点** |

开发者已在代码中标注：
```cpp
// unregister_node.cpp:512
// !!! 此处引用了CA（mmc::ca::BonusAddrCache）导致耦合过高，后续需要依赖倒置
```

---

## 修复方案

### 1. 提取公共工具到 common/

将 `ca/algorithm.h` 中的通用工具函数移到 `common/` 目录：

```
ca/algorithm.h → common/algorithm.h
```

更新所有引用：
```cpp
// net/api.cpp, net/unregister_node.cpp
#include "../common/algorithm.h"  // 替换原 ca/algorithm.h
```

### 2. 依赖倒置：BonusAddrCache

定义接口，由 ca/ 实现，net/ 通过接口调用：

```cpp
// common/stake_query_interface.h
class IStakeQuery {
public:
    virtual ~IStakeQuery() = default;
    virtual bool getAmount(const std::string& bonusAddr, 
                          int64_t& amount) const = 0;
    virtual bool isStakeNode(const std::string& addr) const = 0;
};

// 注册全局实例（由 ca/ 初始化时设置）
class StakeQueryRegistry {
    static std::shared_ptr<IStakeQuery> instance_;
public:
    static void Register(std::shared_ptr<IStakeQuery> impl);
    static std::shared_ptr<IStakeQuery> Get();
};
```

```cpp
// ca/bonus_addr_cache.h — 实现接口
class BonusAddrCache : public IStakeQuery {
    bool getAmount(const std::string& bonusAddr, int64_t& amount) const override {
        // 现有实现
    }
};

// ca/ 初始化时注册
StakeQueryRegistry::Register(std::make_shared<BonusAddrCache>());
```

```cpp
// net/unregister_node.cpp — 通过接口调用
#include "common/stake_query_interface.h"

auto query = StakeQueryRegistry::Get();
if (query && query->getAmount(bonusAddr, amount)) {
    // ...
}
```

### 3. 解耦 block_rate_probe

`net/interface.h` 对 `ca/block_rate_probe.h` 的依赖需要重新组织：

```cpp
// 方案 A：将 BlockRateProbe 的触发逻辑移到 ca/
// net/interface.h 只注册回调，不 include block_rate_probe.h

// 方案 B：将 BlockRateProbe 移到 net/
// 如果它是纯网络层功能（探测消息发送/接收）
```

---

## 验证方法

1. `net/` 目录中不再 `#include` 任何 `ca/` 的头文件
2. 编译通过，功能不变
3. `ca/` 对 `net/` 的依赖方向保持不变

---

## 兼容性

- 内部重构，不影响协议和外部行为
