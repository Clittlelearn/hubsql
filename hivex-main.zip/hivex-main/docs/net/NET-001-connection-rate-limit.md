# NET-001: 入站连接限流

**级别**: P0（必须修复）  
**预估工作量**: 1-2 天  
**涉及文件**: `net/epoll_mode.cpp`, `net/peer_node.h`, `net/define.h`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

`EpollMode::EpollLoop()` 中 accept 循环无条件接受所有入站连接，没有任何限制：

```cpp
// epoll_mode.cpp:88-110（简化）
while (true) {
    int n = epoll_wait(epollFd, events, MAXEPOLLSIZE, timeout);
    for (int i = 0; i < n; i++) {
        if (events[i].data.fd == fdServerMain) {
            // 无条件 accept，无任何限制
            int fd = accept(fdServerMain, ...);
            // 直接加入 epoll 和 bufferControl
        }
    }
}
```

**风险**：
- 攻击者可以从大量 IP 建立连接，耗尽文件描述符（上限 100000）
- 无应用层最大连接数限制，`_nodeMap` 无界增长
- 无单 IP 连接数限制，单点可建立大量连接

---

## 修复方案

### 1. 全局最大连接数限制

在 `net/define.h` 中新增常量：

```cpp
constexpr int kMaxTotalConnections = 500;      // 全局最大连接数
constexpr int kMaxInboundConnections = 300;     // 最大入站连接数
constexpr int kMaxOutboundConnections = 200;    // 最大出站连接数
```

在 `PeerNode` 中增加连接计数和检查：

```cpp
// peer_node.h
class PeerNode {
    int inbound_count_ = 0;
    int outbound_count_ = 0;
    
    bool CanAcceptNewInbound() const {
        return (inbound_count_ + outbound_count_) < kMaxTotalConnections
            && inbound_count_ < kMaxInboundConnections;
    }
};
```

在 `EpollLoop()` 的 accept 分支中检查：

```cpp
if (events[i].data.fd == fdServerMain) {
    if (!PeerNode::GetInstance()->CanAcceptNewInbound()) {
        int fd = accept(fdServerMain, ...);
        close(fd);  // 超限，立即关闭
        continue;
    }
    // ... 正常处理
}
```

### 2. 单 IP 连接数限制

```cpp
constexpr int kMaxConnectionsPerIP = 3;  // 单 IP 最大连接数
```

在 accept 后、加入 `_nodeMap` 前检查：

```cpp
// 统计该 IP 的现有连接数
int count = CountConnectionsByIP(clientIp);
if (count >= kMaxConnectionsPerIP) {
    close(fd);
    continue;
}
```

### 3. 新连接速率限制

使用滑动窗口限制每秒新连接数：

```cpp
constexpr int kMaxNewConnectionsPerSecond = 20;

class ConnectionRateLimiter {
    std::deque<std::chrono::steady_clock::time_point> timestamps_;
    std::mutex mutex_;
    
public:
    bool Allow() {
        std::lock_guard<std::mutex> lock(mutex_);
        auto now = std::chrono::steady_clock::now();
        // 清除 1 秒前的记录
        while (!timestamps_.empty() && 
               now - timestamps_.front() > std::chrono::seconds(1)) {
            timestamps_.pop_front();
        }
        if (timestamps_.size() >= kMaxNewConnectionsPerSecond) {
            return false;
        }
        timestamps_.push_back(now);
        return true;
    }
};
```

在 accept 分支中：

```cpp
if (!rateLimiter.Allow()) {
    int fd = accept(fdServerMain, ...);
    close(fd);
    continue;
}
```

---

## 配置化

建议将限制参数放入 `config.json`：

```json
{
    "network": {
        "max_total_connections": 500,
        "max_inbound_connections": 300,
        "max_outbound_connections": 200,
        "max_connections_per_ip": 3,
        "max_new_connections_per_second": 20
    }
}
```

---

## 验证方法

1. 使用脚本模拟大量连接，验证超限后新连接被拒绝
2. 从同一 IP 建立多个连接，验证单 IP 限制生效
3. 高频建立连接，验证速率限制生效
4. 正常节点连接不受影响

---

## 兼容性

- 纯本地限制，不影响网络协议
- 现有正常节点不受影响
- 无需版本协商
