# OpenHive 网络层新增接口 API 文档

**版本**: 1.0.0
**日期**: 2026-06-25
**分支**: fix_net

---

## 一、NetError 错误码枚举

**文件**: `net/net_error.h`
**来源**: QUAL-002

### 概述

统一网络层错误码定义，替代 `dispatcher.cpp` 中的魔法数字（-1 到 -21）。

### 枚举定义

```cpp
enum class NetError : int {
    // 成功
    Success = 0,
    
    // 协议解析错误 (-1 ~ -19)
    ParseCommonMsgFailed = -1,        // CommonMsg 反序列化失败
    VersionIncompatible = -2,         // 版本不兼容（主版本号不同）
    MessageTypeEmpty = -3,            // 消息类型字段为空
    DescriptorNotFound = -4,          // Protobuf Descriptor 未找到
    MessagePrototypeFailed = -5,      // 创建 Message 原型失败
    CiphertextParseFailed = -6,       // Ciphertext 反序列化失败
    AesIvTagLengthMismatch = -7,      // AES IV 或 Tag 长度不匹配
    KeyNotFound = -8,                 // ECDH 密钥未找到
    TokenVerifyFailed = -9,           // Token 验证失败
    AesDecryptFailed = -10,           // AES 解密失败
    MessageParseFailed = -11,         // 最终消息反序列化失败
    CallbackNotFound = -12,           // 回调未注册
    
    // 速率限制错误 (-20 ~ -29)
    RateLimited = -20,                // 节点已被限流，消息丢弃
    RateLimitExceeded = -21,          // 节点超出速率限制，惩罚生效
    
    // 消息去重
    DuplicateMessage = 0,             // 重复消息（静默丢弃）
};
```

### 辅助函数

```cpp
// 错误码转字符串（用于日志）
const char* NetErrorToString(NetError err);
```

### 使用示例

```cpp
#include "net/net_error.h"

int ProtobufDispatcher::Handle(const MsgData& data) {
    CommonMsg commonMsg;
    if (!commonMsg.ParseFromString(data.pack.data)) {
        ERRORLOG("parse CommonMsg error");
        return static_cast<int>(NetError::ParseCommonMsgFailed);
    }
    // ...
}
```

---

## 二、INetworkCAInterface 接口

**文件**: `net/ca_interface.h`, `net/ca_interface.cpp`
**实现**: `ca/network_ca_impl.h`, `ca/network_ca_impl.cpp`
**来源**: NET-017

### 概述

解耦 `net/` 对 `ca/` 的直接依赖。`net/` 层通过此接口调用 `ca/` 层的功能，而不是直接 `#include` ca/ 头文件。

### 接口定义

```cpp
class INetworkCAInterface {
public:
    virtual ~INetworkCAInterface() = default;
    
    // 获取可撤销资产类型
    // 参数: assetType - 输出参数，接收资产类型字符串
    // 返回: 0 成功，负数失败
    virtual int GetCanBeRevokeAssetType(std::string& assetType) = 0;
    
    // 获取节点奖励金额
    // 参数: bonusAddr - 节点地址
    //       delegateAmount - 输出参数，接收委托金额
    // 返回: 0 成功，负数失败
    virtual int getBonusAmount(const std::string& bonusAddr, 
                               uint64_t& delegateAmount) = 0;
};
```

### 注册表

```cpp
class NetworkCAInterfaceRegistry {
public:
    // 注册 CA 接口实现（在程序启动时调用）
    static void Register(std::shared_ptr<INetworkCAInterface> impl);
    
    // 获取已注册的 CA 接口实现
    static std::shared_ptr<INetworkCAInterface> Get();
};
```

### 使用示例

**net/ 层调用**（`net/api.cpp`, `net/unregister_node.cpp`）：
```cpp
#include "net/ca_interface.h"

// 获取 CA 接口
auto caInterface = NetworkCAInterfaceRegistry::Get();
if (caInterface) {
    std::string assetType;
    int ret = caInterface->GetCanBeRevokeAssetType(assetType);
    if (ret != 0) {
        ERRORLOG("GetCanBeRevokeAssetType failed");
    }
}
```

**ca/ 层注册**（`ca/network_ca_impl.cpp`）：
```cpp
// 自动注册（文件加载时执行）
namespace {
    struct NetworkCAImplRegistrar {
        NetworkCAImplRegistrar() {
            NetworkCAInterfaceRegistry::Register(
                std::make_shared<NetworkCAImpl>());
        }
    };
    static NetworkCAImplRegistrar registrar;
}
```

### 解耦效果

**修改前**：
```cpp
// net/api.cpp
#include "../ca/algorithm.h"        // 直接依赖 ca/
#include "../ca/bonus_addr_cache.h" // 直接依赖 ca/
```

**修改后**：
```cpp
// net/api.cpp
#include "net/ca_interface.h"       // 只依赖接口
// ca/ 头文件仅在 ca/network_ca_impl.cpp 中引入
```

---

## 三、NetworkMetrics 监控指标

**文件**: `net/metrics.h`
**来源**: NET-019, FEAT-001

### 概述

单例类，收集网络层运行时指标，通过 HTTP `/metrics` 端点以 Prometheus 格式导出。

### 指标字段

#### 连接指标

| 字段 | 类型 | 说明 | 更新位置 |
|------|------|------|---------|
| `active_connections` | `atomic<int>` | 当前活跃连接数 | `peer_node.cpp` Add/Delete |
| `inbound_connections` | `atomic<int>` | 入站连接数 | `peer_node.cpp` Add/Delete |
| `outbound_connections` | `atomic<int>` | 出站连接数 | `peer_node.cpp` Add/Delete |
| `total_connections_accepted` | `atomic<uint64_t>` | 累计接受连接数 | `epoll_mode.cpp` accept |
| `total_connections_rejected` | `atomic<uint64_t>` | 累计拒绝连接数 | `epoll_mode.cpp` 限制检查 |
| `total_disconnects` | `atomic<uint64_t>` | 累计断开连接数 | `peer_node.cpp` Delete |

#### 消息指标

| 字段 | 类型 | 说明 | 更新位置 |
|------|------|------|---------|
| `messages_received` | `atomic<uint64_t>` | 累计接收消息数 | `dispatcher.cpp` Handle |
| `messages_sent` | `atomic<uint64_t>` | 累计发送消息数 | `api.cpp` SendOneMessage |
| `bytes_received` | `atomic<uint64_t>` | 累计接收字节数 | `dispatcher.cpp` Handle |
| `bytes_sent` | `atomic<uint64_t>` | 累计发送字节数 | `api.cpp` SendOneMessage |
| `messages_dropped_dedup` | `atomic<uint64_t>` | 去重丢弃消息数 | `dispatcher.cpp` 去重检查 |
| `messages_dropped_rate_limit` | `atomic<uint64_t>` | 限流丢弃消息数 | `dispatcher.cpp` 限流检查 |

#### 队列指标

| 字段 | 类型 | 说明 | 更新位置 |
|------|------|------|---------|
| `read_queue_size` | `atomic<int>` | 读队列当前大小 | `msg_queue.h` Push/Pop |
| `work_queue_size` | `atomic<int>` | 工作队列当前大小 | `msg_queue.h` Push/Pop |
| `write_queue_size` | `atomic<int>` | 写队列当前大小 | `msg_queue.h` Push/Pop |

#### 按类型统计

| 字段 | 类型 | 说明 | 更新位置 |
|------|------|------|---------|
| `messages_by_type` | `unordered_map<string, atomic<uint64_t>>` | 各类型消息计数 | `dispatcher.cpp` Handle |

### 单例访问

```cpp
// 获取单例
NetworkMetrics& metrics = NetworkMetrics::Instance();

// 更新指标
metrics.messages_received++;
metrics.bytes_received += dataSize;
metrics.incrementMessageType("TxMsgReq");
```

### Prometheus 导出

**HTTP 端点**: `GET /metrics`
**Content-Type**: `text/plain; version=0.0.4`

**示例输出**：
```
# HELP openhive_network_connections_active Active peer connections
# TYPE openhive_network_connections_active gauge
openhive_network_connections_active 42

# HELP openhive_network_connections_inbound Inbound connections
# TYPE openhive_network_connections_inbound gauge
openhive_network_connections_inbound 30

# HELP openhive_network_connections_outbound Outbound connections
# TYPE openhive_network_connections_outbound gauge
openhive_network_connections_outbound 12

# HELP openhive_network_messages_total Total messages processed
# TYPE openhive_network_messages_total counter
openhive_network_messages_total{direction="received"} 123456
openhive_network_messages_total{direction="sent"} 234567

# HELP openhive_network_bytes_total Total bytes transferred
# TYPE openhive_network_bytes_total counter
openhive_network_bytes_total{direction="received"} 1234567890
openhive_network_bytes_total{direction="sent"} 2345678901

# HELP openhive_network_messages_dropped Dropped messages
# TYPE openhive_network_messages_dropped counter
openhive_network_messages_dropped{reason="dedup"} 100
openhive_network_messages_dropped{reason="rate_limit"} 50

# HELP openhive_network_queue_size Current queue sizes
# TYPE openhive_network_queue_size gauge
openhive_network_queue_size{queue="read"} 5
openhive_network_queue_size{queue="work"} 10
openhive_network_queue_size{queue="write"} 3

# HELP openhive_network_messages_by_type Messages by type
# TYPE openhive_network_messages_by_type counter
openhive_network_messages_by_type{type="TxMsgReq"} 5000
openhive_network_messages_by_type{type="BuildBlockBroadcastMsg"} 1200
```

### 监控集成

**Prometheus 配置**（`prometheus.yml`）：
```yaml
scrape_configs:
  - job_name: 'openhive'
    static_configs:
      - targets: ['node1:13134', 'node2:13134']
    metrics_path: '/metrics'
    scrape_interval: 15s
```

**Grafana 仪表盘**（建议面板）：
- 活跃连接数（gauge）
- 消息速率（counter rate）
- 带宽使用（counter rate）
- 丢弃消息速率（counter rate）
- 队列深度（gauge）

---

## 四、INetworkLayer 接口（未实施）

**文件**: `net/network_interface.h`, `net/network_interface.cpp`
**来源**: NET-018（已跳过）

### 概述

为未来 libp2p 迁移准备的网络层抽象接口。**当前未实施**，因为：
- 网络规模 200-500 节点，当前架构足够
- 不需要 NAT 穿透和跨语言互操作
- libp2p 迁移未确定

### 接口定义（仅供参考）

```cpp
class INetworkLayer {
public:
    virtual ~INetworkLayer() = default;
    
    virtual bool initialize() = 0;
    virtual void shutdown() = 0;
    
    virtual std::vector<Node> getConnectedNodes() const = 0;
    virtual std::vector<Node> getStakeNodes() const = 0;
    virtual int getConnectedNodeCount() const = 0;
    virtual bool findNode(const std::string& address, Node& node) const = 0;
    
    virtual bool sendToNode(const std::string& nodeAddress,
                           const std::string& msgType,
                           const std::string& serializedData,
                           bool compress = false,
                           bool encrypt = true,
                           int priority = 0) = 0;
    
    virtual bool broadcast(const std::string& msgType,
                          const std::string& serializedData,
                          bool compress = false,
                          bool encrypt = true,
                          int priority = 0) = 0;
    
    // ... 其他方法
};
```

### 未来迁移路径

如果未来需要迁移到 libp2p：
1. 实现 `Libp2pNetworkImpl : INetworkLayer`
2. 修改 `ca/` 层通过 `NetworkLayerRegistry::Get()` 调用
3. 在 `entry.cpp` 中注册实现

---

## 五、文件清单

| 文件 | 类型 | 来源 | 说明 |
|------|------|------|------|
| `net/net_error.h` | 新增 | QUAL-002 | 错误码枚举定义 |
| `net/ca_interface.h` | 新增 | NET-017 | CA 层接口声明 |
| `net/ca_interface.cpp` | 新增 | NET-017 | CA 层接口注册表实现 |
| `ca/network_ca_impl.h` | 新增 | NET-017 | CA 层接口实现声明 |
| `ca/network_ca_impl.cpp` | 新增 | NET-017 | CA 层接口实现 + 自动注册 |
| `net/metrics.h` | 新增 | NET-019 | 网络监控指标单例类 |
| `net/network_interface.h` | 新增 | NET-018 | 网络层抽象接口（未实施） |
| `net/network_interface.cpp` | 新增 | NET-018 | 网络层接口注册表（未实施） |
