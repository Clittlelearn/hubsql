# NET-012: 密钥轮换机制

**级别**: P2（可选修复）  
**预估工作量**: 2-3 天  
**涉及文件**: `net/key_exchange.h`, `net/key_exchange.cpp`, `net/define.h`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

`EcdhKey::timeout` 字段定义了但从未使用。密钥在连接生命周期内不轮换，长时间运行的连接始终使用同一把 AES 密钥。

**风险**：
- 密钥使用时间越长，被破解的风险越高
- 如果内存被读取，所有历史通信都可被解密

---

## 修复方案

### 1. 密钥生命周期

```cpp
// define.h
constexpr int kKeyRotationIntervalSeconds = 3600;  // 每小时轮换一次
constexpr int kKeyGracePeriodSeconds = 60;          // 新旧密钥重叠 60 秒
```

### 2. 轮换流程

```
正常通信中，每 kKeyRotationIntervalSeconds:
  1. 发起方生成新的 ECDH 临时密钥对 + salt
  2. 通过旧密钥加密发送 KeyRotationReq
  3. 接收方用旧密钥解密，生成自己的新密钥对
  4. 计算新的共享密钥
  5. 通过旧密钥发送 KeyRotationAck
  6. 双方切换到新密钥
  7. 旧密钥在 grace period 后销毁
```

### 3. 实现要点

- 轮换期间新旧密钥并存，确保不丢消息
- 轮换消息本身使用旧密钥加密
- 轮换失败时保持旧密钥，定时重试
- 记录轮换次数和时间用于调试

---

## 兼容性

- 新增 `KeyRotationReq/Ack` 消息
- 需要双方同时升级
