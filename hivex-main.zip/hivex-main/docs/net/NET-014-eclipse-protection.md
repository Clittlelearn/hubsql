# NET-014: 日食攻击防护

**级别**: P2（可选修复）  
**预估工作量**: 3-5 天  
**涉及文件**: `net/peer_node.cpp`, `net/unregister_node.cpp`, `net/define.h`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

节点发现完全依赖已知节点返回的列表 + 静态 seed nodes。没有出站连接多样性保证。如果攻击者控制了足够多的邻居节点，可以垄断本节点的网络视图。

**风险**：
- 攻击者可以隔离目标节点，使其只与攻击者控制的节点通信
- 可以阻止目标节点收到真实的区块和交易
- 可以进行双花攻击

---

## 修复方案

### 1. 入站/出站连接比例限制

```cpp
// define.h
constexpr int kMaxInboundRatio = 70;   // 入站最多占 70%
constexpr int kMinOutboundConnections = 8;  // 至少 8 个出站连接
```

```cpp
bool PeerNode::canAcceptInbound() const {
    int total = inbound_count_ + outbound_count_;
    int maxInbound = total * kMaxInboundRatio / 100;
    return inbound_count_ < maxInbound;
}
```

### 2. 子网多样性

限制同一 /16 子网的连接数：

```cpp
constexpr int kMaxConnectionsPerSubnet16 = 5;

int countBySubnet16(uint32_t ip) {
    uint16_t subnet = (ip >> 16) & 0xFFFF;
    int count = 0;
    for (auto& [addr, node] : _nodeMap) {
        uint16_t nodeSubnet = (node.publicIp >> 16) & 0xFFFF;
        if (nodeSubnet == subnet) count++;
    }
    return count;
}
```

### 3. 出站连接多样性

主动连接时优先选择不同子网/不同来源的节点：

```cpp
void selectDiverseNodes(const std::vector<Node>& candidates, int count) {
    // 按子网分组
    std::map<uint16_t, std::vector<const Node*>> bySubnet;
    for (auto& n : candidates) {
        uint16_t subnet = (n.publicIp >> 16) & 0xFFFF;
        bySubnet[subnet].push_back(&n);
    }
    
    // 轮询选择，确保子网多样性
    std::vector<Node> selected;
    auto it = bySubnet.begin();
    while (selected.size() < count && !bySubnet.empty()) {
        if (it->second.empty()) {
            it = bySubnet.erase(it);
        } else {
            selected.push_back(*it->second.back());
            it->second.pop_back();
            ++it;
        }
        if (it == bySubnet.end()) it = bySubnet.begin();
    }
}
```

### 4. 锚定节点

保留一定比例的"锚定节点"（长期信任的节点），防止被完全隔离：

```cpp
// config.json
{
    "network": {
        "anchor_nodes": [
            "pubkey1:ip1:port1",
            "pubkey2:ip2:port2"
        ],
        "min_anchor_connections": 2
    }
}
```

锚定节点始终尝试保持连接，不参与正常的节点淘汰流程。

---

## 验证方法

1. 从同一子网建立大量连接，验证被限制
2. 验证出站连接分布在不同子网
3. 验证锚定节点始终保持连接

---

## 兼容性

- 纯本地策略，不影响协议
