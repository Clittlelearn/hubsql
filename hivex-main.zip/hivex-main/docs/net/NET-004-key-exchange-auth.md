# NET-004: ECDH 密钥交换身份绑定

**级别**: P0（必须修复）  
**预估工作量**: 2-3 天  
**涉及文件**: `net/key_exchange.cpp`, `net/handle_event.cpp`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

当前 ECDH 密钥交换是裸 ECDH，没有将对方公钥与其节点身份（address/pubkey）绑定验证：

```
连接建立 → KeyExchangeRequest（发送 ECDH 公钥 + salt）
         → KeyExchangeResponse（接收 ECDH 公钥 + salt）
         → 计算共享密钥 → AES 加密通信
```

整个过程中：
- 没有验证对方 ECDH 公钥是否属于其声称的节点身份
- 没有与节点注册时提供的 identity/pubkey 进行绑定
- 攻击者可以拦截连接，替换 ECDH 公钥，完全解密通信

**风险**：
- 中间人攻击（MITM）
- 无法保证通信对端确实是预期的节点

---

## 修复方案

### 方案概述

在密钥交换完成后，增加一个**身份验证步骤**：双方使用各自的节点私钥对 ECDH 公钥进行签名，对方验证签名确认身份。

### 1. 扩展密钥交换协议

在 `key_exchange.proto` 中新增身份验证消息：

```protobuf
// 密钥交换完成后的身份验证
message KeyExchangeAuthReq {
    bytes ecdh_pubkey = 1;        // 本次 ECDH 使用的公钥
    bytes identity_signature = 2; // 节点私钥对 ecdh_pubkey 的签名
    string address = 3;           // 节点地址
}

message KeyExchangeAuthAck {
    bool success = 1;
    bytes ecdh_pubkey = 2;
    bytes identity_signature = 3;
    string address = 4;
}
```

### 2. 密钥交换流程变更

```
原流程:
  A → B: KeyExchangeRequest(ecdh_pub_A, salt_A)
  B → A: KeyExchangeResponse(ecdh_pub_B, salt_B)
  [计算共享密钥，开始加密通信]

新流程:
  A → B: KeyExchangeRequest(ecdh_pub_A, salt_A)
  B → A: KeyExchangeResponse(ecdh_pub_B, salt_B)
  [计算共享密钥]
  A → B: KeyExchangeAuthReq(ecdh_pub_A, sign_A(ecdh_pub_A), addr_A)  [加密]
  B → A: KeyExchangeAuthAck(success, ecdh_pub_B, sign_B(ecdh_pub_B), addr_B)  [加密]
  [双方验证签名，确认身份]
  [正式通信]
```

### 3. 实现细节

**发起方（A）**：

```cpp
// key_exchange.cpp - 在 keyExchangeRequest() 完成后
void KeyExchangeManager::performAuthAfterExchange(int fd, const Node& peer) {
    // 1. 获取自己的 ECDH 公钥
    auto ecdh_key = getKey(fd);
    // 注意：C++ 结构体 EcdhKey 中字段名为 ec_pub_key（不是 protobuf 的 ec_public_key_65bytes）
    std::string ecdh_pubkey(ecdh_key->own_key.ec_pub_key, EC_PUBLIC_KEY_LENGTH);

    // 2. 用自己的节点私钥签名 ECDH 公钥
    // 通过 AccountManager 获取本节点的账户私钥（不存在 getLocalNodePrivateKey() 函数）
    auto& accountMgr = MagicSingleton<AccountManager>::GetInstance();
    Account account = accountMgr->getAccount(peer.address);  // 获取本节点账户
    std::string signature = account.Sign(Getsha256Hash(ecdh_pubkey));

    // 3. 发送认证请求（使用已协商的 AES 密钥加密）
    KeyExchangeAuthReq req;
    req.set_ecdh_pubkey(ecdh_pubkey);
    req.set_identity_signature(signature);
    req.set_address(getLocalNodeAddress());

    net_com::SendMessage(peer, req, ..., ENCRYPT_TRUE);

    // 4. 等待认证响应（复用现有的 dataMgrPtr.CreateWait/WaitData 同步模型）
    // ...
}
```

**接收方（B）**：

```cpp
// handle_event.cpp - 新增回调
void handleKeyExchangeAuthRequest(int fd, const KeyExchangeAuthReq& req, const NetPack& from) {
    // 1. 获取已协商的 ECDH 密钥
    auto ecdh_key = KeyExchangeManager::getInstance()->getKey(fd);
    if (!ecdh_key) {
        ERRORLOG("No ECDH key for fd {}", fd);
        return;
    }

    // 2. 验证对方 ECDH 公钥与已存储的一致
    // ecdh_key->peer_key.ec_pub_key 是对方在密钥交换阶段提供的 ECDH 公钥
    std::string stored_peer_pub(ecdh_key->peer_key.ec_pub_key, EC_PUBLIC_KEY_LENGTH);
    if (req.ecdh_pubkey() != stored_peer_pub) {
        ERRORLOG("ECDH pubkey mismatch for fd {}", fd);
        disconnect(fd);
        return;
    }

    // 3. 用对方的节点公钥验证签名
    Account account;
    account.setPublicKey(req.address());  // 从地址/公钥恢复
    std::string hash = Getsha256Hash(req.ecdh_pubkey());
    if (!account.Verify(hash, req.identity_signature())) {
        ERRORLOG("Identity signature verification failed for {}", req.address());
        disconnect(fd);
        return;
    }

    // 4. 验证地址与公钥一致性
    std::string derived_addr = GenerateAddr(account.getPublicKey());
    if (derived_addr != req.address()) {
        ERRORLOG("Address mismatch: derived={}, claimed={}", derived_addr, req.address());
        disconnect(fd);
        return;
    }

    // 5. 将验证通过的身份信息绑定到 ECDH 密钥
    // 需要在 EcdhKey 结构体中新增字段
    ecdh_key->verified_address = req.address();
    ecdh_key->identity_verified = true;

    // 6. 发送认证响应
    auto& accountMgr = MagicSingleton<AccountManager>::GetInstance();
    Account localAccount = accountMgr->getAccount(getLocalNodeAddress());
    std::string local_ecdh_pub(ecdh_key->own_key.ec_pub_key, EC_PUBLIC_KEY_LENGTH);

    KeyExchangeAuthAck ack;
    ack.set_success(true);
    ack.set_ecdh_pubkey(local_ecdh_pub);
    ack.set_identity_signature(localAccount.Sign(Getsha256Hash(local_ecdh_pub)));
    ack.set_address(getLocalNodeAddress());

    net_com::SendMessage(from, ack, ..., ENCRYPT_TRUE);
}
```

### 4. 运行时验证

在后续消息处理中，验证消息来源与密钥交换时验证的身份一致：

```cpp
// dispatcher.cpp - Handle() 中
if (ecdh_key->identity_verified) {
    // 验证消息中的 pub/address 与密钥交换时验证的一致
    if (commonMsg.pub() != ecdh_key->verified_pubkey) {
        ERRORLOG("Message pubkey doesn't match verified identity");
        return -4;
    }
}
```

---

## EcdhKey 结构体扩展

需要在 `key_exchange.h` 的 `EcdhKey` 结构体中新增身份验证相关字段：

```cpp
// key_exchange.h - EcdhKey 结构体新增字段
struct EcdhKey {
    // ... 现有字段（own_key, peer_key, timeout）
    
    // 新增：身份绑定
    std::string verified_address;    // 验证通过的节点地址
    bool identity_verified = false;  // 身份是否已验证
};
```

## 验证方法

1. 正常节点间密钥交换 + 身份验证，验证通过
2. 模拟中间人替换 ECDH 公钥，验证签名检查失败
3. 验证地址与公钥不一致时被拒绝
4. 验证运行时消息来源与身份绑定一致

---

## 兼容性

- 协议变更：新增 `KeyExchangeAuthReq/Ack` 消息
- 所有节点统一升级，无需考虑新旧版本兼容
- `KeyExchangeAuthReq/Ack` 在已建立的加密通道内传输，走正常的 AES 解密路径（不需要在 dispatcher.cpp 的解密跳过列表中添加）
- 不影响现有业务消息格式
