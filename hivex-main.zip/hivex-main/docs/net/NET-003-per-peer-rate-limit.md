# NET-003: per-peer 消息速率限制

**级别**: P0（必须修复）  
**预估工作量**: 2-3 天  
**涉及文件**: `net/dispatcher.cpp`, `net/peer_node.h`, `net/node.hpp`, `net/define.h`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

消息队列 `MsgQueue` 的 50000 条上限是全局共享的，没有 per-peer 限制。一个恶意节点的高频消息可以填满整个队列，影响所有正常节点的消息处理。

```cpp
// msg_queue.h - 全局共享队列
class MsgQueue {
    std::priority_queue<...> queue_;
    static constexpr size_t kMaxSize = 50000;  // 全局上限
    // 没有 per-peer 限制
};
```

**风险**：
- 单节点洪水攻击影响全网消息处理
- 无法区分正常高频节点和恶意洪水攻击
- 无法对特定节点进行精细限流

---

## 修复方案

### 1. per-peer 消息计数器

在每个 `Node` 结构中增加消息计数：

```cpp
// node.hpp
struct Node {
    // ... 现有字段
    
    // 新增：速率限制
    std::atomic<uint64_t> msg_count_{0};           // 当前窗口消息数
    std::chrono::steady_clock::time_point msg_window_start_;  // 窗口起始时间
    std::atomic<bool> rate_limited_{false};         // 是否被限流
};
```

### 2. 速率限制器

```cpp
// define.h
constexpr uint64_t kMaxMessagesPerPeerPerSecond = 100;    // 每节点每秒最大消息数
constexpr uint64_t kMaxBytesPerPeerPerSecond = 10 * 1024 * 1024;  // 每节点每秒最大字节数 10MB
constexpr int kRateLimitWindowSeconds = 1;                 // 滑动窗口大小

// 限流惩罚
constexpr int kRateLimitBanSeconds = 60;    // 超限后 ban 60 秒
constexpr int kRateLimitBanThreshold = 5;   // 60 秒内被限流 5 次则断开
```

### 3. 两层限流策略

> **审查修正**：`MsgQueue::Push()` 在队列满时会阻塞生产者（`notFull.wait()`）。如果速率限制只在 `Handle()` 中执行，消息已经进入队列系统，限流效果会打折扣。因此采用两层策略：第一层在 WorkRead 线程从 socket 读取后、推入队列前做粗粒度限流；第二层在 `Handle()` 中做精细限流。

#### 3a. 第一层：读取路径粗粒度限流（队列前）

在 `WorkThreads::networkReadHandler()` 中，从 socket 读取数据后、推入 `queue_work` 前，按 fd 做粗粒度限流：

```cpp
// work_thread.cpp - networkReadHandler() 中
void networkReadHandler(const MsgData& data) {
    // 第一层：per-fd 粗粒度限流（在推入队列前）
    if (!PeerRateLimiter::getInstance()->allowRead(data.fd, data.data.size())) {
        DEBUGLOG("fd {} exceeds read rate limit, dropping data", data.fd);
        return;  // 直接丢弃，不进入队列
    }
    
    // ... 正常推入 queue_work
}
```

#### 3b. 第二层：Handle() 精细限流

```cpp
// dispatcher.cpp - Handle() 入口
// 实际签名：Handle(const MsgData &data)，fd 通过 data.fd 获取
int ProtobufDispatcher::Handle(const MsgData& data) {
    int fd = data.fd;
    
    // 查找发送节点
    auto node = PeerNode::GetInstance()->locateNodeByFd(fd);
    if (!node) return -1;

    // 检查是否被 ban
    if (node->peer_stats.rate_limited) {
        DEBUGLOG("Node {} is rate-limited, dropping message", node->address);
        return -2;
    }

    // 令牌桶检查（比固定窗口更平滑，避免边界突发）
    auto now = std::chrono::steady_clock::now();
    auto& stats = node->peer_stats;
    stats.refillTokens(now);  // 按时间补充令牌
    
    if (!stats.consumeToken()) {
        WARNLOG("Node {} exceeds rate limit", node->address);
        stats.rate_limited = true;
        stats.rate_limit_violations++;

        if (stats.rate_limit_violations >= kRateLimitBanThreshold) {
            ERRORLOG("Node {} exceeded rate limit {} times, disconnecting",
                     node->address, stats.rate_limit_violations);
            PeerNode::GetInstance()->DisconnectNode(node->address);
        }
        return -3;
    }

    // ... 正常消息处理（版本检查 → 解密 → 去重 → 路由）
}
```

> **与 NET-011 的协调**：`peer_stats` 是共享的 per-peer 统计结构（详见 NET-011），速率限制违规作为信誉评分的输入因子，而非独立的惩罚动作。

### 4. 字节级限流（可选增强）

```cpp
// 在 Node 中增加字节计数
std::atomic<uint64_t> bytes_count_{0};

// 在 Handle() 中检查
node->bytes_count_ += data.size();
if (node->bytes_count_ > kMaxBytesPerPeerPerSecond) {
    // 限流处理
}
```

### 5. 定时重置线程

需要一个定时任务来重置各节点的计数器：

```cpp
// 可以复用现有的心跳定时器
// 或在 WorkThreads 中增加一个定时任务
void ResetRateLimitCounters() {
    auto nodes = PeerNode::GetInstance()->GetNodelist();
    auto now = std::chrono::steady_clock::now();
    for (auto& node : nodes) {
        if (now - node.msg_window_start_ > std::chrono::seconds(kRateLimitWindowSeconds)) {
            node.msg_count_ = 0;
            node.bytes_count_ = 0;
            node.msg_window_start_ = now;
        }
    }
}
```

---

## 配置化

```json
{
    "network": {
        "max_messages_per_peer_per_second": 100,
        "max_bytes_per_peer_per_second": 10485760,
        "rate_limit_ban_seconds": 60,
        "rate_limit_ban_threshold": 5
    }
}
```

---

## 特殊消息豁免

某些高优先级消息可能不受速率限制：

```cpp
bool IsRateLimitExempt(uint32_t msgType) {
    switch (msgType) {
        case MSG_TYPE_PING:
        case MSG_TYPE_PONG:
        case MSG_TYPE_KEY_EXCHANGE:
            return true;  // 心跳和密钥交换不限流
        default:
            return false;
    }
}
```

---

## 验证方法

1. 模拟单节点高频发送消息，验证被限流
2. 验证限流不影响其他节点
3. 验证限流在窗口期后自动解除
4. 验证多次超限后节点被断开
5. 验证心跳等关键消息不受限流影响

---

## 兼容性

- 纯本地限制，不影响协议
- 正常节点的消息频率远低于限制值，不受影响
- 无需版本协商
