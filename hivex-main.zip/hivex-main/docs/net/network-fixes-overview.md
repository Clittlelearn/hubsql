# OpenHive 网络层修复方案总览

**版本**: 1.0.0
**日期**: 2026-06-25
**状态**: 已完成（核心修复 + 代码质量改进）
**分支**: fix_net

---

## 一、背景

OpenHive 网络层（`net/` 目录，约 15,652 行 C++ 代码）采用自研 epoll + Protobuf + ECDH 架构。经过代码审查，发现存在安全性、可靠性、功能性等方面的问题。本文档梳理所有修复项及实施结果。

### 设计原则

1. **安全性优先**：先修复安全漏洞，再完善功能
2. **最小改动**：尽量不改动业务层（`ca/`）代码
3. **向后兼容**：修复不应破坏现有节点间的通信
4. **可测试性**：每个修复项应可独立验证

---

## 二、实施结果总览

### 已完成项（27 项）

| 编号 | 问题 | 实施提交 | 修改文件 |
|------|------|---------|---------|
| NET-001 | 入站连接限流 | `bd84986` | `epoll_mode.cpp`, `define.h` |
| NET-002 | 消息大小上限 | `ea4c350` | `pack.cpp`, `define.h`, `socket_buf.cpp` |
| NET-003 | per-peer 速率限制 | `bd84986` | `dispatcher.cpp`, `node.hpp`, `define.h` |
| NET-004 | ECDH 身份绑定 | `2c76ee8` | `key_exchange.proto`, `key_exchange.h/cpp`, `handle_event.cpp` |
| NET-005 | HTTP RPC 认证 | `bd84986` | `http_server.cpp` |
| NET-006 | 断线自动重连 | `36522e8` | `peer_node.h/cpp`, `work_thread.cpp`, `api.cpp` |
| NET-007 | 消息去重 | `2c76ee8`, `d5df945` | `dispatcher.cpp` |
| NET-008 | 发送缓冲区限制 | `ea4c350` | `socket_buf.h/cpp`, `define.h` |
| NET-009 | TCP keepalive | `ea4c350` | `api.cpp`, `epoll_mode.cpp` |
| NET-010 | 写超时处理 | `36522e8` | `socket_buf.h/cpp`, `define.h` |
| NET-011 | 节点信誉评分 | `36522e8` | `node.hpp`, `dispatcher.cpp` |
| NET-012 | 密钥轮换 | `684c950` | `key_exchange.h/cpp`, `api.cpp`, `define.h` |
| NET-013 | 版本兼容性 | `684c950` | `net_version.cpp`, `dispatcher.cpp` |
| NET-014 | 日食攻击防护 | `684c950` | `epoll_mode.cpp`, `define.h` |
| NET-015 | 硬编码日志 | `ea4c350` | `http_server.cpp` |
| NET-017 | 解耦反向依赖 | `d9a70f8` | `ca_interface.h/cpp`, `network_ca_impl.h/cpp`, `api.cpp`, `unregister_node.cpp` |
| NET-019 | 网络监控 | `ec0ab14`, `0dddffa` | `metrics.h`, `http_server.cpp`, `peer_node.cpp`, `dispatcher.cpp`, `api.cpp`, `msg_queue.h`, `epoll_mode.cpp` |
| BUG-001 | fdMutex 内存泄漏 | `d9a70f8` | `socket_buf.h/cpp`, `peer_node.cpp` |
| BUG-002 | requestCountMap 增长 | `d9a70f8` | `dispatcher.cpp` |
| BUG-003 | EpollStop 逻辑错误 | `d9a70f8` | `epoll_mode.h` |
| QUAL-001 | locateNodeByFd 性能 | `9d6f649` | `peer_node.h/cpp` |
| QUAL-002 | 统一错误码 | `9d6f649` | `net_error.h`, `dispatcher.cpp` |
| QUAL-003 | 日志级别调整 | `9d6f649` | `handle_event.cpp`, `peer_node.cpp`, `dispatcher.cpp`, `epoll_mode.cpp`, `work_thread.cpp` |
| FEAT-001 | 监控指标集成 | `0dddffa` | `peer_node.cpp`, `dispatcher.cpp`, `api.cpp`, `msg_queue.h`, `epoll_mode.cpp` |

### 暂缓/取消项（5 项）

| 编号 | 问题 | 决策 | 理由 |
|------|------|------|------|
| NET-016 | IPv6 支持 | **暂缓** | 需要专项重构（30 个文件，5-8 周），TestNet 稳定后启动 |
| NET-018 | 网络接口抽象 | **跳过** | libp2p 迁移未确定；200-500 节点规模不需要；NAT 穿透和跨语言互操作不需要 |
| FEAT-002 | 配置化网络参数 | **取消** | 参数是系统级约束，用户不应自行修改，配置化增加误操作风险 |
| FEAT-003 | 信誉评分持久化 | **暂缓** | 需要时间衰减机制，当前网络规模不需要 |
| FEAT-004 | DNS Seed 发现 | **暂缓** | 当前静态 seed 足够，DNS seed 增加运维成本 |

---

## 三、实施阶段回顾

```
阶段 1（基础设施）：NET-015, NET-009, NET-002, NET-008     → 提交 ea4c350
阶段 2（核心防护）：NET-001, NET-003, NET-005               → 提交 bd84986
阶段 3（消息管线）：NET-004, NET-007                        → 提交 2c76ee8
阶段 4（弹性恢复）：NET-006, NET-010, NET-011               → 提交 36522e8
阶段 5（高级防护）：NET-012, NET-013, NET-014               → 提交 684c950
阶段 6（架构优化）：NET-019                                  → 提交 ec0ab14
BUG 修复 + 解耦  ：BUG-001/002/003, NET-017                → 提交 d9a70f8
代码质量改进     ：QUAL-001/002/003                          → 提交 9d6f649
监控指标集成     ：FEAT-001                                  → 提交 0dddffa
去重修复         ：NET-007 白名单修正                        → 提交 d5df945
```

---

## 四、关键实施细节

### 4.1 消息处理管线（dispatcher.cpp Handle()）

最终的消息处理顺序：

```
1. 解析 CommonMsg
2. 版本兼容性检查（NET-013：major 版本匹配即可）
3. per-peer 速率限制（NET-003：令牌桶）
4. 解密（AES-GCM）
5. 消息解析
6. 信誉评分更新（NET-011）
7. 消息去重（NET-007：白名单模式，仅区块/交易/同步消息）
8. 路由到回调
```

### 4.2 连接管理（epoll_mode.cpp accept 路径）

最终的检查顺序：

```
1. 全局连接数限制（NET-001：500）
2. 单 IP 连接数限制（NET-001：3）
3. /16 子网多样性（NET-014：5）
4. 入站/出站比例（NET-014：70% 入站上限）
5. 新连接速率限制（NET-001：20/s）
6. TCP keepalive 配置（NET-009）
```

### 4.3 共享数据结构

**PeerStats**（`node.hpp`）：
- 速率限制字段（NET-003）：令牌桶、违规计数
- 统计字段（FEAT-001）：消息计数、字节计数
- 信誉评分字段（NET-011）：latency/validity/uptime/compliance/total

**NetworkMetrics**（`metrics.h`）：
- 连接指标：active/inbound/outbound/accepted/rejected/disconnects
- 消息指标：received/sent/bytes/dropped
- 队列指标：read/work/write queue size
- 按类型统计：messages_by_type

### 4.4 新增接口

**INetworkCAInterface**（`ca_interface.h`）：
- `GetCanBeRevokeAssetType()` — 获取可撤销资产类型
- `getBonusAmount()` — 获取奖励金额
- 解耦 net/ 对 ca/ 的直接依赖（NET-017）

**NetError**（`net_error.h`）：
- 统一错误码枚举（QUAL-002）
- 替代 dispatcher.cpp 中的魔法数字 -1 ~ -21

---

## 五、配置参数汇总

所有新增的网络参数（硬编码在 `net/define.h` 中）：

| 参数 | 值 | 来源 |
|------|-----|------|
| `kMaxMessageSize` | 32MB | NET-002 |
| `kMaxSendBufferSize` | 16MB | NET-008 |
| `kMaxTotalConnections` | 500 | NET-001 |
| `kMaxConnectionsPerIP` | 3 | NET-001 |
| `kMaxNewConnectionsPerSecond` | 20 | NET-001 |
| `kMaxMessagesPerPeerPerSecond` | 100 | NET-003 |
| `kRateLimitBanThreshold` | 5 | NET-003 |
| `kDedupCacheSize` | 100000 | NET-007 |
| `kDedupExpireSeconds` | 300 | NET-007 |
| `kMaxReconnectAttempts` | 5 | NET-006 |
| `kReconnectBaseDelayMs` | 1000 | NET-006 |
| `kReconnectMaxDelayMs` | 60000 | NET-006 |
| `kMaxReconnectsPerSecond` | 10 | NET-006 |
| `kReconnectMinReputation` | 0.2 | NET-006 |
| `kWriteTimeoutSeconds` | 30 | NET-010 |
| `kSendBufferSoftLimit` | 1MB | NET-010 |
| `kMaxInboundRatio` | 70% | NET-014 |
| `kMinOutboundConnections` | 8 | NET-014 |
| `kMaxConnectionsPerSubnet16` | 5 | NET-014 |
| `kKeyRotationIntervalSeconds` | 3600 | NET-012 |

---

## 六、监控端点

### Prometheus 指标（`/metrics` HTTP 端点）

```
# 连接指标
openhive_network_connections_active
openhive_network_connections_inbound
openhive_network_connections_outbound
openhive_network_connections_total{event="accepted|rejected|disconnects"}

# 消息指标
openhive_network_messages_total{direction="received|sent"}
openhive_network_bytes_total{direction="received|sent"}
openhive_network_messages_dropped{reason="dedup|rate_limit"}

# 队列指标
openhive_network_queue_size{queue="read|work|write"}

# 按类型统计
openhive_network_messages_by_type{type="<MessageType>"}
```

---

## 七、提交历史

```
9d6f649  refactor: code quality improvements (QUAL-001/002/003)
0dddffa  feat: integrate network metrics collection (FEAT-001)
d5df945  fix: NET-007 message dedup only applies to block/tx messages
ec0ab14  net: implement Phase 6 monitoring (NET-019)
684c950  net: implement Phase 5 advanced protection (NET-012/013/014)
36522e8  net: implement Phase 4 resilience features (NET-006/010/011)
2c76ee8  net: implement Phase 3 identity and dedup (NET-004/007)
bd84986  net: implement Phase 2 network protection (NET-001/003/005)
ea4c350  net: implement Phase 1 network hardening (NET-002/008/009/015)
d9a70f8  fix: resolve bugs and decouple net/ from ca/ dependencies
8aff568  docs: add network layer fix plan with 19 repair items
```

---

## 八、相关文档

- [NET-001: 入站连接限流](./NET-001-connection-rate-limit.md)
- [NET-002: 消息大小上限](./NET-002-message-size-limit.md)
- [NET-003: per-peer 速率限制](./NET-003-per-peer-rate-limit.md)
- [NET-004: 密钥交换身份绑定](./NET-004-key-exchange-auth.md)
- [NET-005: HTTP RPC 认证](./NET-005-http-auth.md)
- [NET-006: 断线自动重连](./NET-006-auto-reconnect.md)
- [NET-007: 消息去重](./NET-007-message-dedup.md)
- [NET-008: 发送缓冲区限制](./NET-008-send-buffer-limit.md)
- [NET-009: TCP keepalive](./NET-009-tcp-keepalive.md)
- [NET-010: 写超时处理](./NET-010-write-timeout.md)
- [NET-011: 节点信誉系统](./NET-011-peer-scoring.md)
- [NET-012: 密钥轮换](./NET-012-key-rotation.md)
- [NET-013: 版本兼容性](./NET-013-version-compat.md)
- [NET-014: 日食攻击防护](./NET-014-eclipse-protection.md)
- [NET-015: 硬编码日志路径](./NET-015-hardcoded-log.md)
- [NET-016: IPv6 支持](./NET-016-ipv6-support.md)（暂缓）
- [NET-017: 解耦反向依赖](./NET-017-decouple-reverse-deps.md)
- [NET-018: 网络接口抽象](./NET-018-network-interface-abstraction.md)（跳过）
- [NET-019: 网络监控](./NET-019-network-metrics.md)
