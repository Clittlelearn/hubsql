# NET-018: 抽象网络接口层

**级别**: 架构优化（长期）  
**预估工作量**: 3-5 天  
**涉及文件**: 新增 `net/network_interface.h`，修改 `net/interface.h`, `ca/` 中 21 个文件

---
**实施状态**: ✗ 跳过
**原因**: libp2p 迁移未确定；200-500 节点规模不需要；NAT 穿透和跨语言互操作不需要

---

## 问题描述

ca/ 有 21 个文件直接依赖 net/ 的具体实现（`net/api.h`, `net/interface.h`, `net/peer_node.h` 等）。如果未来需要迁移到 libp2p 或其他网络实现，需要改动大量 ca/ 代码。

---

## 修复方案

### 1. 定义网络抽象接口

```cpp
// net/network_interface.h
class INetworkLayer {
public:
    virtual ~INetworkLayer() = default;
    
    // 初始化
    virtual bool initialize() = 0;
    virtual void shutdown() = 0;
    
    // 单播发送
    virtual bool sendToNode(const std::string& nodeAddress, 
                           const std::string& msgType,
                           const std::string& serializedData,
                           bool compress = false,
                           bool encrypt = true,
                           int priority = 0) = 0;
    
    // 广播
    virtual bool broadcast(const std::string& msgType,
                          const std::string& serializedData,
                          bool compress = false,
                          bool encrypt = true,
                          int priority = 0) = 0;
    
    // 节点管理
    virtual std::vector<NodeInfo> getConnectedNodes() const = 0;
    virtual std::vector<NodeInfo> getStakeNodes() const = 0;
    virtual int getConnectedNodeCount() const = 0;
    
    // 回调注册
    using MessageCallback = std::function<void(const std::string& fromAddr, 
                                               const std::string& msgType,
                                               const std::string& data)>;
    virtual void registerMessageHandler(const std::string& msgType, 
                                        MessageCallback callback) = 0;
};

// 全局访问
class NetworkLayer {
    static std::unique_ptr<INetworkLayer> instance_;
public:
    static void Initialize(std::unique_ptr<INetworkLayer> impl);
    static INetworkLayer* Get();
};
```

### 2. 现有实现适配

```cpp
// net/current_network_impl.h
class CurrentNetworkImpl : public INetworkLayer {
public:
    bool sendToNode(const std::string& nodeAddress, ...) override {
        // 内部调用现有的 net_com::SendMessage
        auto node = PeerNode::GetInstance()->FindNode(nodeAddress);
        if (!node) return false;
        return net_com::SendMessage(*node, msg, ...);
    }
    
    bool broadcast(...) override {
        // 内部调用现有的 net_com::BroadCastMessage
        return net_com::BroadCastMessage(from, msg, ...);
    }
    
    // ... 其他方法
};
```

### 3. ca/ 代码迁移

```cpp
// 迁移前（ca/transaction.cpp）
#include "net/interface.h"
NetSendMessage<BuildBlockBroadcastMsg>(node, msg, ...);

// 迁移后
#include "net/network_interface.h"
NetworkLayer::Get()->sendToNode(node.address, "BuildBlockBroadcastMsg", 
                                serializedData, ...);
```

### 4. 未来 libp2p 实现

```cpp
// net/libp2p_network_impl.h（未来）
class Libp2pNetworkImpl : public INetworkLayer {
public:
    bool sendToNode(...) override {
        // 使用 libp2p 的 host->NewStream() + 写入
    }
    
    bool broadcast(...) override {
        // 使用 libp2p 的 gossipsub
    }
};
```

---

## 迁移策略

分步迁移 ca/ 中的 21 个文件：

1. **第一批**：只使用 `NetSendMessage`/`NetBroadcastMessage` 的文件（最简单）
2. **第二批**：使用了 `PeerNode` 查询的文件
3. **第三批**：使用了 `MsgQueue` 的文件
4. **最后**：移除旧的 `net/interface.h` 模板函数

---

## 兼容性

- 内部重构，不影响协议
- 可以逐步迁移，新旧代码可以共存
