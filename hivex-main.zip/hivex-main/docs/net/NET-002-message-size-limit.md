# NET-002: 消息大小上限检查

**级别**: P0（必须修复）  
**预估工作量**: 0.5 天  
**涉及文件**: `net/pack.cpp`, `net/define.h`, `net/socket_buf.cpp`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

消息拆包函数 `Pack::apartPackData()` 只检查了下限，没有上限：

```cpp
// pack.cpp（实际签名）
bool Pack::apartPackData(NetPack& pk, const char* pack, int packLen) {
    if (packLen < 12) {  // 只检查下限
        ERRORLOG("apartPackData len < 12");
        return false;
    }
    // packLen 是函数参数，由调用方从 socket 缓冲区的前 4 字节读取后传入
    // 没有检查 packLen 上限
    // packLen 是 int，但实际消息长度字段是 uint32_t
}
```

消息长度的读取发生在 `SocketBuf::sendPacketToMessageQueue()` 中：
```cpp
// socket_buf.cpp - 从缓冲区前 4 字节读取消息长度
memcpy(&current_message_length, this->_cache.data(), 4);
```

`SocketBuf` 的 `VerifyCache()` 在消息长度超过 100MB 时才触发 `CorrectCache()` 修复，但这是事后修复而非事前预防，此时内存已被大量占用。

**风险**：
- 恶意节点发送超大 `packLen` 值，导致内存分配失败或 OOM
- 即使不 OOM，大消息也会阻塞处理线程

---

## 修复方案

### 1. 定义消息大小常量

```cpp
// define.h
constexpr uint32_t kMaxMessageSize = 32 * 1024 * 1024;   // 32MB 硬上限
constexpr uint32_t kMaxBlockSize = 16 * 1024 * 1024;      // 区块消息 16MB
constexpr uint32_t kMaxTxSize = 4 * 1024 * 1024;          // 交易消息 4MB
constexpr uint32_t kMaxNormalMsgSize = 1 * 1024 * 1024;   // 普通消息 1MB
```

### 2. 在 apartPackData 中增加上限检查

```cpp
// pack.cpp — 修正后的实际函数签名
bool Pack::apartPackData(NetPack& pk, const char* pack, int packLen) {
    if (packLen < 12) {
        ERRORLOG("apartPackData len < 12");
        return false;
    }

    // 新增：上限检查
    if ((uint32_t)packLen > kMaxMessageSize) {
        ERRORLOG("apartPackData len {} exceeds max {}", packLen, kMaxMessageSize);
        return false;
    }

    // ... 后续解析（memcpy 到 pk 各字段）
}
```

### 3. 在 SocketBuf 中增加早期检查

```cpp
// socket_buf.cpp - add_data_to_read_buffer()
void SocketBuf::add_data_to_read_buffer(const char* data, size_t len) {
    // 新增：在追加数据前检查总大小
    if (_cache.size() + len > kMaxMessageSize * 2) {  // 留一定余量
        ERRORLOG("SocketBuf cache exceeds limit, clearing");
        _cache.clear();
        return;
    }
    _cache.append(data, len);
}
```

### 4. 发送缓冲区同样限制

```cpp
// socket_buf.cpp - PushSendMsg()
void SocketBuf::PushSendMsg(const std::string& data) {
    if (_sendCache.size() + data.size() > kMaxMessageSize * 4) {
        ERRORLOG("Send buffer exceeds limit, dropping message");
        return;  // 或断开连接
    }
    _sendCache += data;
}
```

---

## 消息类型分级限制（可选增强）

如果后续需要更精细的控制，可以按消息类型设置不同上限：

```cpp
uint32_t getMaxMsgSize(uint32_t msgType) {
    switch (msgType) {
        case MSG_TYPE_BLOCK:        return kMaxBlockSize;
        case MSG_TYPE_TX:           return kMaxTxSize;
        case MSG_TYPE_SYNC_BLOCK:   return kMaxBlockSize;
        default:                    return kMaxNormalMsgSize;
    }
}
```

但这需要在解析 `CommonMsg.type` 后才能判断，实现更复杂。初期建议先用统一上限。

---

## 验证方法

1. 构造超大 `packLen` 的消息，验证被拒绝
2. 构造刚好等于上限的消息，验证正常处理
3. 正常消息不受影响

---

## 兼容性

- 纯本地检查，不影响协议
- 现有正常消息远小于 32MB，不受影响
- 无需版本协商
