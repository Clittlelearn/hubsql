# NET-007: 消息去重机制

**级别**: P1（建议修复）  
**预估工作量**: 1-2 天  
**涉及文件**: `net/dispatcher.cpp`, `net/define.h`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

当前没有消息去重机制。广播消息如果通过不同路径到达同一节点，会被重复处理。

**影响**：
- 交易被重复验证和转发
- 区块被重复处理
- 浪费 CPU 和带宽资源
- 可能导致状态不一致

---

## 修复方案

### 1. 消息指纹计算

对每个消息计算唯一指纹（hash）：

```cpp
// 消息指纹 = SHA256(msg_type + msg_serialized_data)
std::string computeMessageFingerprint(const std::string& msgType, const std::string& data) {
    return SHA256(msgType + ":" + data);
}
```

### 2. 去重缓存

使用 LRU 缓存存储最近见过的消息指纹：

```cpp
// define.h
constexpr size_t kDedupCacheSize = 100000;         // 缓存大小
constexpr int kDedupExpireSeconds = 300;            // 5 分钟过期

class MessageDeduplicator {
    struct Entry {
        std::string fingerprint;
        std::chrono::steady_clock::time_point timestamp;
    };
    
    std::unordered_map<std::string, std::chrono::steady_clock::time_point> cache_;
    std::list<std::string> lru_order_;  // LRU 顺序
    std::mutex mutex_;
    
public:
    // 返回 true 表示首次见到，false 表示重复
    bool checkAndRecord(const std::string& fingerprint) {
        std::lock_guard<std::mutex> lock(mutex_);
        
        auto now = std::chrono::steady_clock::now();
        
        // 检查是否已存在
        auto it = cache_.find(fingerprint);
        if (it != cache_.end()) {
            // 检查是否过期
            if (now - it->second < std::chrono::seconds(kDedupExpireSeconds)) {
                return false;  // 重复
            }
            // 过期了，移除旧记录
            cache_.erase(it);
        }
        
        // 记录新消息
        cache_[fingerprint] = now;
        lru_order_.push_front(fingerprint);
        
        // 如果超过大小限制，移除最旧的
        if (cache_.size() > kDedupCacheSize) {
            auto oldest = lru_order_.back();
            lru_order_.pop_back();
            cache_.erase(oldest);
        }
        
        return true;  // 首次
    }
};
```

### 3. 在消息分发入口检查

> **审查修正**：由于 AES-GCM 加密使用了随机 IV（`encrypt_plaintext()` 中每次通过 `RAND_bytes` 生成 12 字节 IV），同一条消息每次加密的结果不同。因此消息去重 **不能** 基于密文指纹，必须在解密后基于明文内容计算指纹。

去重在 `Handle()` 中的执行顺序：解析 → 版本检查 → 速率限制（NET-003）→ 解密 → **去重** → 路由。

```cpp
// dispatcher.cpp - Handle() 中，解密之后、路由之前
// 实际签名：Handle(const MsgData &data)
int ProtobufDispatcher::Handle(const MsgData& data) {
    // ... 解析 CommonMsg、版本检查、速率限制（NET-003）、解密 ...

    // 消息去重（在解密之后，基于明文内容）
    // 使用消息类型 + 解密后的 data 计算指纹
    std::string fingerprint = computeMessageFingerprint(
        commonMsg.type(), commonMsg.data());
    
    if (!MessageDeduplicator::getInstance()->checkAndRecord(fingerprint)) {
        DEBUGLOG("Duplicate message dropped: type={}, fingerprint={}", 
                 commonMsg.type(), fingerprint.substr(0, 16));
        return 0;  // 重复消息，静默丢弃
    }
    
    // ... 路由到回调
}
```

### 4. 豁免消息类型

某些消息不需要去重（如心跳、请求-响应对）：

```cpp
bool needsDedup(const std::string& msgType) {
    static const std::set<std::string> exempt = {
        "PingReq", "PongReq", "EchoReq", "EchoAck",
        "KeyExchangeRequest", "KeyExchangeResponse",
        "RegisterNodeReq", "RegisterNodeAck",
        "SyncNodeReq", "SyncNodeAck"
    };
    return exempt.find(msgType) == exempt.end();
}
```

---

## 性能考虑

- SHA256 计算开销：对于大消息（如区块），计算指纹有一定开销
- 可选优化：使用消息自带的 hash 字段（如 `TxMsgReq.hash()`、`BlockMsg.hash()`）作为指纹
- 内存占用：10 万条指纹 × ~64 字节 ≈ 6.4MB

### 优化方案：使用消息自带 hash

```cpp
std::string extractMessageHash(const CommonMsg& msg) {
    // 对于有 hash 字段的消息，直接使用
    // 对于没有 hash 的消息，计算 SHA256
    // ...
}
```

---

## 验证方法

1. 发送相同消息两次，验证第二次被丢弃
2. 验证不同消息不被误判为重复
3. 验证过期消息可以被重新处理
4. 验证缓存大小限制生效
5. 验证豁免消息类型不受去重影响

---

## 兼容性

- 纯本地逻辑，不影响协议
- 其他节点无需升级
