# NET-019: 网络监控指标导出

**级别**: 架构优化（长期）  
**预估工作量**: 3-5 天  
**涉及文件**: 新增 `net/metrics.h/cpp`，修改 `net/dispatcher.cpp`, `net/peer_node.cpp`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

当前网络层只有内部 `requestCountMap` 统计，无法导出到外部监控系统。

---

## 修复方案

### 1. 指标定义

```cpp
// net/metrics.h
class NetworkMetrics {
public:
    // 连接指标
    std::atomic<int> active_connections{0};
    std::atomic<int> inbound_connections{0};
    std::atomic<int> outbound_connections{0};
    std::atomic<uint64_t> total_connections_accepted{0};
    std::atomic<uint64_t> total_connections_rejected{0};
    std::atomic<uint64_t> total_disconnects{0};
    
    // 消息指标
    std::atomic<uint64_t> messages_received{0};
    std::atomic<uint64_t> messages_sent{0};
    std::atomic<uint64_t> bytes_received{0};
    std::atomic<uint64_t> bytes_sent{0};
    std::atomic<uint64_t> messages_dropped_dedup{0};
    std::atomic<uint64_t> messages_dropped_rate_limit{0};
    
    // per-type 统计
    std::unordered_map<std::string, std::atomic<uint64_t>> messages_by_type;
    
    // 延迟指标
    std::atomic<double> avg_ping_rtt_ms{0.0};
    
    // 队列指标
    std::atomic<int> read_queue_size{0};
    std::atomic<int> work_queue_size{0};
    std::atomic<int> write_queue_size{0};
    
    // 单例
    static NetworkMetrics& Instance();
};
```

### 2. Prometheus 格式导出

通过 HTTP 端点导出：

```
GET /metrics
```

返回 Prometheus 文本格式：

```
# HELP openhive_network_connections_active Active peer connections
# TYPE openhive_network_connections_active gauge
openhive_network_connections_active 42

# HELP openhive_network_messages_total Total messages processed
# TYPE openhive_network_messages_total counter
openhive_network_messages_total{direction="received"} 123456
openhive_network_messages_total{direction="sent"} 234567

# HELP openhive_network_bytes_total Total bytes transferred
# TYPE openhive_network_bytes_total counter
openhive_network_bytes_total{direction="received"} 1234567890
openhive_network_bytes_total{direction="sent"} 2345678901

# HELP openhive_network_messages_by_type Messages by type
# TYPE openhive_network_messages_by_type counter
openhive_network_messages_by_type{type="TxMsgReq"} 5000
openhive_network_messages_by_type{type="BuildBlockBroadcastMsg"} 1200
```

### 3. 集成点

```cpp
// dispatcher.cpp - Handle() 入口
NetworkMetrics::Instance().messages_received++;
NetworkMetrics::Instance().bytes_received += data.size();

// api.cpp - SendMessage
NetworkMetrics::Instance().messages_sent++;
NetworkMetrics::Instance().bytes_sent += serializedData.size();

// peer_node.cpp - Add/Delete
NetworkMetrics::Instance().active_connections = _nodeMap.size();
```

---

## 兼容性

- 新增 HTTP 端点，不影响现有功能
- 可配置启用/禁用
