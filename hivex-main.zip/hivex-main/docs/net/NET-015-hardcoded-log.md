# NET-015: 移除硬编码调试日志

**级别**: P2（可选修复）  
**预估工作量**: 0.5 天  
**涉及文件**: `net/http_server.cpp`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

`http_server.cpp:277` 中硬编码了日志路径：

```cpp
std::ofstream os("/root/mm/build/bin/http_log.txt", std::ios::app);
```

**问题**：
- 路径硬编码为特定构建目录
- append 模式，无日志轮转，会导致磁盘空间耗尽
- 记录了完整的请求和响应 JSON，可能泄露敏感数据

---

## 修复方案

### 1. 移除硬编码日志

直接删除该段代码，使用项目统一的 spdlog：

```cpp
// 替换为
INFOLOG("HTTP request: {} {}", req.method, req.path);
```

### 2. 如需保留 HTTP 访问日志

```cpp
// 使用 spdlog，配置日志轮转
auto http_logger = spdlog::rotating_logger_mt("http_access", "logs/http_access.log", 
                                               10 * 1024 * 1024, 5);
http_logger->info("{} {} {}", req.method, req.path, res.status);
```

---

## 兼容性

- 不影响任何功能
