# NET-010: 写超时处理

**级别**: P1（建议修复）  
**预估工作量**: 1-2 天  
**涉及文件**: `net/work_thread.cpp`, `net/api.cpp`, `net/socket_buf.cpp`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

`handle_net_write()` 中，当对端消费速度慢时，`_sendCache` 中的数据持续积压无法发送出去：

```cpp
// work_thread.cpp:120-168（简化）
void handle_net_write(int fd) {
    // socket 已设为非阻塞模式
    // net_tcp::Send() 遇 EAGAIN 返回已发送字节数，不会阻塞
    // 但如果对端 TCP 窗口为 0，write() 持续返回 EAGAIN
    // 数据留在 _sendCache 中不断积压
}
```

> **审查修正**：socket 已设为非阻塞模式，`Send()` 不会真正阻塞。真正的问题是：当对端 TCP 接收窗口为 0 时，`write()` 持续返回 `EAGAIN`，已写入 `_sendCache` 的数据无法发出，导致缓冲区持续增长。

---

## 修复方案

### 1. 非阻塞写入

确保 socket 设置为非阻塞模式（当前已在 `EpollLoop` 中设置），并使用 `EPOLLOUT` 事件驱动写入：

```cpp
// 不再在 handle_net_write 中直接 Send
// 而是检查缓冲区，如果有数据且 socket 可写，则写入
void handle_net_write(int fd) {
    auto& buf = bufferControl[fd];
    if (!buf.hasDataToSend()) return;
    
    // 非阻塞写入
    const std::string& data = buf.getSendData();
    ssize_t sent = send(fd, data.c_str(), data.size(), MSG_NOSIGNAL);
    
    if (sent < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            // socket 缓冲区满，等待下次 EPOLLOUT
            return;
        }
        // 真正的错误
        ERRORLOG("Write error for fd {}: {}", fd, strerror(errno));
        handleWriteError(fd);
        return;
    }
    
    // 移除已发送的数据
    buf.consumeSendData(sent);
}
```

### 2. 写超时检测

> **审查修正**：`bufferControl` 内部使用 `std::map<uint64_t, std::shared_ptr<SocketBuf>>` 存储，key 是 `portAndIp`，不是 fd。需要新增遍历接口来检查所有 SocketBuf 的写超时。

记录每个 SocketBuf 最后一次成功写入的时间，超时则断开：

```cpp
// define.h
constexpr int kWriteTimeoutSeconds = 30;  // 写超时 30 秒

// socket_buf.h - SocketBuf 新增字段
class SocketBuf {
    std::chrono::steady_clock::time_point last_write_success_;
    // ...
};

// bufferControl 新增遍历接口
class bufferControl {
public:
    // 新增：遍历所有 SocketBuf，检查写超时
    std::vector<uint64_t> findWriteTimeouts() {
        std::lock_guard<std::mutex> lock(_mutex);
        auto now = std::chrono::steady_clock::now();
        std::vector<uint64_t> timeoutKeys;
        for (auto& [key, buf] : _BufferMap) {
            if (buf->hasDataToSend() && 
                now - buf->last_write_success_ > std::chrono::seconds(kWriteTimeoutSeconds)) {
                timeoutKeys.push_back(key);
            }
        }
        return timeoutKeys;
    }
};
```

```cpp
// 在定时检查中
void checkWriteTimeouts() {
    auto timeouts = MagicSingleton<bufferControl>::GetInstance()->findWriteTimeouts();
    for (auto key : timeouts) {
        ERRORLOG("Write timeout for portAndIp {}, disconnecting", key);
        // 通过 portAndIp 反查节点地址并断开
        PeerNode::GetInstance()->DisconnectNodeByPortAndIp(key);
    }
}
```

### 3. 发送缓冲区水位标记

当发送缓冲区超过高水位时，暂停向该节点发送新消息：

```cpp
constexpr size_t kSendBufferHighWaterMark = 8 * 1024 * 1024;  // 8MB

bool SocketBuf::isSendBufferBackpressured() const {
    return _sendCache.size() > kSendBufferHighWaterMark;
}

// 在广播时检查
void broadcastMessage(const Node& from, const auto& msg) {
    for (auto& node : PeerNode::GetInstance()->GetNodelist()) {
        auto& buf = bufferControl[node.fd];
        if (buf.isSendBufferBackpressured()) {
            WARNLOG("Skipping slow node {}: send buffer {} bytes", 
                    node.address, buf.getSendBufferSize());
            continue;  // 跳过慢节点
        }
        SendMessage(node, msg);
    }
}
```

---

## 验证方法

1. 模拟慢消费者（读取速度极低），验证写超时后连接被断开
2. 验证非阻塞写入不会阻塞写线程
3. 验证背压机制跳过慢节点
4. 正常节点不受影响

---

## 兼容性

- 纯本地逻辑，不影响协议
