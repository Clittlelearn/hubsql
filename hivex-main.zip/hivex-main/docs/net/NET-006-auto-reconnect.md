# NET-006: 断线自动重连

**级别**: P1（建议修复）  
**预估工作量**: 2-3 天  
**涉及文件**: `net/peer_node.cpp`, `net/unregister_node.cpp`, `net/api.cpp`, `net/define.h`

---
**实施状态**: ✓ 已完成
**实施提交**: 见 [总览文档](./network-fixes-overview.md)

---

## 问题描述

当前节点断开后直接 `delete_by_fd()` 删除，不会尝试重连。只能等 100 秒后的周期节点同步（`switchNodeListThread`）才可能重新发现并连接。

```cpp
// work_thread.cpp:91-107（简化）
// read 返回 0 或错误时
PeerNode::GetInstance()->delete_by_fd(fd);
// 直接删除，不重连
```

**影响**：
- 网络不稳定时节点大量流失
- 新节点加入后如果连接断开，需要等待较长时间才能恢复
- 小网络中节点流失可能导致网络不可用

---

## 修复方案

### 1. 区分主动断开和被动断开

```cpp
enum class DisconnectReason {
    LOCAL_CLOSE,       // 本节点主动关闭
    REMOTE_CLOSE,      // 对端关闭
    NETWORK_ERROR,     // 网络错误
    TIMEOUT,           // 超时
    PROTOCOL_ERROR,    // 协议错误
    RATE_LIMITED       // 被限流
};
```

只有 `REMOTE_CLOSE` 和 `NETWORK_ERROR` 才触发重连。`PROTOCOL_ERROR` 和 `RATE_LIMITED` 不重连。

### 2. 重连策略（Full Jitter 指数退避）

> **审查修正**：简单的指数退避在网络分区恢复后可能导致大量节点同时重连（Thundering Herd）。采用 AWS 推荐的 **Full Jitter** 策略，引入随机性避免同步。

```cpp
// define.h
constexpr int kMaxReconnectAttempts = 5;         // 最大重连次数
constexpr int kReconnectBaseDelayMs = 1000;      // 基础延迟 1 秒
constexpr int kReconnectMaxDelayMs = 60000;      // 最大延迟 60 秒

// Full Jitter 公式：delay = random(0, min(cap, base * 2^attempt))
inline int64_t calculateReconnectDelay(int attempt) {
    int64_t expDelay = kReconnectBaseDelayMs * (1LL << std::min(attempt, 20));
    int64_t cap = std::min(expDelay, (int64_t)kReconnectMaxDelayMs);
    // 使用随机数避免 thundering herd
    static thread_local std::mt19937 rng(std::random_device{}());
    std::uniform_int_distribution<int64_t> dist(0, cap);
    return dist(rng);
}
```

额外增加**全局重连速率限制**，避免瞬间打满 fd：

```cpp
constexpr int kMaxReconnectsPerSecond = 10;  // 全局每秒最多 10 个重连
```

### 3. 重连管理器

新增 `ReconnectManager` 类：

```cpp
class ReconnectManager {
    struct ReconnectEntry {
        Node node_info;              // 节点信息（保留 IP/端口/公钥）
        int attempt_count = 0;       // 已尝试次数
        int64_t next_attempt_ms = 0; // 下次尝试时间
    };
    
    std::map<std::string, ReconnectEntry> pending_;  // address -> entry
    std::mutex mutex_;
    
public:
    // 节点断开时调用
    void onDisconnected(const Node& node, DisconnectReason reason) {
        if (reason == DisconnectReason::PROTOCOL_ERROR ||
            reason == DisconnectReason::RATE_LIMITED ||
            reason == DisconnectReason::LOCAL_CLOSE) {
            return;  // 不重连
        }
        
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = pending_.find(node.address);
        if (it == pending_.end()) {
            ReconnectEntry entry;
            entry.node_info = node;
            entry.attempt_count = 0;
            entry.next_attempt_ms = currentMs() + kReconnectBaseDelayMs;
            pending_[node.address] = entry;
        }
    }
    
    // 定时调用（每 5 秒）
    void checkAndReconnect() {
        std::lock_guard<std::mutex> lock(mutex_);
        auto now = currentMs();
        
        for (auto it = pending_.begin(); it != pending_.end(); ) {
            auto& entry = it->second;
            
            if (now < entry.next_attempt_ms) {
                ++it;
                continue;
            }
            
            entry.attempt_count++;
            if (entry.attempt_count > kMaxReconnectAttempts) {
                INFOLOG("Node {} exceeded max reconnect attempts, removing", 
                        entry.node_info.address);
                it = pending_.erase(it);
                continue;
            }
            
            // 审查补充：重连前检查节点信誉评分（依赖 NET-011）
            double score = PeerScorer::getInstance()->getScore(entry.node_info.address);
            if (score < 0.2) {
                INFOLOG("Node {} reputation too low ({:.2f}), skipping reconnect", 
                        entry.node_info.address, score);
                it = pending_.erase(it);
                continue;
            }
            
            // 尝试重连
            INFOLOG("Reconnecting to node {} (attempt {}/{})", 
                    entry.node_info.address, entry.attempt_count, kMaxReconnectAttempts);
            
            bool success = tryReconnect(entry.node_info);
            if (success) {
                INFOLOG("Reconnected to node {}", entry.node_info.address);
                it = pending_.erase(it);
            } else {
                // Full Jitter 指数退避（替代原来的固定倍数退避）
                int64_t delay = calculateReconnectDelay(entry.attempt_count);
                entry.next_attempt_ms = now + delay;
                ++it;
            }
        }
    }
    
private:
    bool tryReconnect(const Node& node) {
        // 复用现有的 ConnectNode + KeyExchange + Register 流程
        int fd = PeerNode::GetInstance()->ConnectNode(node);
        if (fd <= 0) return false;
        
        // 密钥交换
        if (!KeyExchangeManager::getInstance()->keyExchangeRequest(fd, node)) {
            PeerNode::GetInstance()->DisconnectNode(node.address);
            return false;
        }
        
        // 注册
        // ...
        return true;
    }
};
```

### 4. 集成到现有流程

```cpp
// work_thread.cpp - 断开连接时
void handle_net_read(int fd) {
    int n = read(fd, buf, MAXLINE);
    if (n <= 0) {
        auto node = PeerNode::GetInstance()->locateNodeByFd(fd);
        DisconnectReason reason = (n == 0) ? DisconnectReason::REMOTE_CLOSE 
                                           : DisconnectReason::NETWORK_ERROR;
        
        if (node) {
            ReconnectManager::getInstance()->onDisconnected(*node, reason);
        }
        
        PeerNode::GetInstance()->delete_by_fd(fd);
    }
}
```

```cpp
// 在现有定时器中增加重连检查
// 可以复用 CTimer 或新增定时任务
g_reconnectTimer.AsyncLoop(5000, []() {
    ReconnectManager::getInstance()->checkAndReconnect();
});
```

---

## 配置化

```json
{
    "network": {
        "enable_auto_reconnect": true,
        "max_reconnect_attempts": 5,
        "reconnect_base_delay_ms": 5000,
        "reconnect_max_delay_ms": 300000
    }
}
```

---

## 验证方法

1. 手动断开一个节点，验证自动重连
2. 验证指数退避：重连间隔递增
3. 验证超过最大次数后停止重连
4. 验证协议错误不触发重连
5. 验证重连后密钥交换和注册正常完成

---

## 兼容性

- 纯本地逻辑，不影响协议
- 对端节点无需升级
