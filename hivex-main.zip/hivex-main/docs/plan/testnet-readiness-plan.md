# OpenHive TestNet 广域网测试准备计划

**状态**: Draft  
**日期**: 2026-06-17  
**维护者**: OpenHive Core Team

---

## 目录

- [1. 网络启动与引导](#1-网络启动与引导)
- [2. 测试服务器](#2-测试服务器)
- [3. 域名和证书](#3-域名和证书)
- [4. 测试数据](#4-测试数据)
- [5. 测试方案](#5-测试方案)
- [6. 运维与监控](#6-运维与监控)
- [7. GitHub](#7-github)

---

## 1. 网络启动与引导

> 网络启动的前置条件，必须在任何测试之前完成。

### 1.1 Genesis 配置

- [ ] 确定 `genesisTime`（微秒级时间戳）
- [ ] 确定 `initAccountAddr`（创世账户地址，拥有唯一提案权限）
- [ ] 确定 `vrfWhitelist`（VRF 白名单地址列表，100% 通过准入筛选）
- [ ] 确定 `network.type: "test"`
- [ ] 确定 `network.name`（如 `"testnet"`）

### 1.2 种子节点配置

- [ ] 确定种子节点服务器列表（IP + P2P 端口 13133）
- [ ] 统一所有节点的 `config.json` 中 `server` 字段
- [ ] 验证种子节点连通性

### 1.3 初始 OHI 分配方案

- [ ] 确定 OHI 注入方式（创世余额当前强制为 0，需通过创世账户转账或其他方式分配）
- [ ] 确定测试账户列表及初始余额
- [ ] 确定节点质押用 OHI 的来源（每个节点至少 3,500 OHI）
- [ ] 确定投资/交易测试用 OHI 的分配计划

### 1.4 编译与版本

- [ ] 确认所有节点使用 `TESTCHAIN=ON` 编译
- [ ] 确认 Chain ID 为 `0x3027` (12315)
- [ ] 确认所有节点版本一致
- [ ] 确认 `config.json` 中 P2P 端口（13133）、HTTP 端口（13134）等参数正确

---

## 2. 测试服务器

### 2.1 硬件配置

- [ ] 确定最低硬件要求（CPU / 内存 / 磁盘）
  - 参考：RocksDB TransactionDB + MPT 状态树，建议 SSD
  - 参考：evmone EVM 执行引擎
- [ ] 确定节点角色分配（种子节点 / 共识节点 / RPC 节点 / 浏览器节点）
- [ ] 确定服务器数量（最少 3 个节点满足 DevNet/TestNet 共识要求）

### 2.2 地域分布

- [ ] 确定服务器地域分布方案（同机房 / 跨地域 / 跨大洲）
- [ ] 评估网络延迟对 VRF 10 秒周期的影响
- [ ] 评估 NTP 时间同步精度（VRF 签名验证 ±10 秒窗口）

### 2.3 带宽

- [ ] 确定节点间 P2P 通信带宽需求
- [ ] 确定 RPC 对外服务带宽需求
- [ ] 评估区块广播带宽（区块大小上限 4MB）

---

## 3. 域名和证书

### 3.1 域名规划

- [ ] 确定 TestNet 域名（如 `testnet.openhive.io`）
- [ ] 确定各节点的域名或子域名
- [ ] 确定 RPC 访问域名

### 3.2 TLS 证书

- [ ] 确定 HTTPS 方案（Let's Encrypt / 商业证书 / 自签名）
- [ ] 决定是否启用 mTLS 双向认证
  - 启用：需准备 CA 证书（`ssl_ca_bundle`）和客户端证书
  - 不启用：仅需服务端证书
- [ ] 配置节点 `config.json` 中 HTTPS 相关字段
  - `enable_https: true`
  - `ssl_cert_path` / `ssl_key_path`
  - `ssl_ca_bundle`（mTLS 场景）
  - `https_port`（默认 443）

### 3.3 P2P 网络安全

- [ ] 确认 ECDH P-256 密钥交换正常工作
- [ ] 确认 AES-256-GCM 加密通信正常
- [ ] 确认消息加密策略（交易/合约加密，心跳/注册不加密）

---

## 4. 测试数据

### 4.1 账号地址

- [ ] 生成创世账户（`initAccountAddr`，拥有提案权限）
- [ ] 生成节点账户列表（每个需 ≥ 3,500 OHI 用于质押）
- [ ] 生成普通测试账户列表（用于转账、投资、投票等）
- [ ] 生成合约部署专用账户
- [ ] 确定各账户的初始 OHI / Vote 分配

### 4.2 合约部署

- [ ] Token 单合约（标准 ERC-20 类似合约）
- [ ] Token 多合约（多资产发行）
- [ ] SWAP 类合约（DEX 交易对）
- [ ] NFT 合约（ERC-721 类似）
- [ ] 跨链合约（Flow 相关合约）
- [ ] 其他常用测试合约（多签、代理等）

### 4.3 测试脚本

- [ ] 节点部署自动化脚本
- [ ] Genesis 配置生成脚本
- [ ] 账户创建与资金分配脚本
- [ ] 合约部署脚本（Hardhat / 自定义）
- [ ] 交易批量发送脚本
- [ ] 测试结果收集与报告脚本

---

## 5. 测试方案

### 5.1 连通性测试

- [ ] 节点间 P2P 连接（TCP 13133）
- [ ] RPC HTTP 访问（端口 13134）
- [ ] RPC HTTPS 访问（端口 443）
- [ ] 节点发现与注册（RegisterNodeReq/Ack）
- [ ] 心跳机制验证（60 秒间隔，180 秒超时断连）
- [ ] NTP 时间同步验证（5 个国际 NTP 服务器）
- [ ] ECDH 密钥交换验证
- [ ] MetaMask 连接测试（Chain ID 12315，RPC URL）

### 5.2 交易测试

#### 5.2.1 普通类交易

- [ ] 转账（TX）— 单资产、多资产、多收款方
- [ ] 质押（STAKE）— 最低 3,500 OHI，佣金率 5%-35%
- [ ] 解质押（UNSTAKE）— 1 天后可操作，30 天后可用，最小高度 500
- [ ] 投资/委托（DELEGATE）— 最低 500 OHI，上限 3,500,000 OHI，最多 1,000 次
- [ ] 解投资/取消委托（UNDELEGATE）— 1 天后可操作，30 天后可用
- [ ] 锁定（LOCK）— 锁定 1 OHI 的 Vote 获得投票权
- [ ] 解锁（UNLOCK）— 1 天后可解锁
- [ ] 申领奖励（BONUS）— 24 小时后可申领，签名工作量影响奖励比例
- [ ] 国库奖励（FUND）— 50% 按锁定占比 + 50% 按签名分配

#### 5.2.2 合约类交易

- [ ] 部署合约（DEPLOY）— EVM 字节码部署，EIP-161 地址生成
- [ ] 调用合约（CALL）— 普通调用、带值调用、合约间调用
- [ ] 合约依赖管理 — 依赖冲突检测、缓存重试（1 秒检查、15 秒强制发送）
- [ ] 合约 Gas 验证 — 单笔最大 120,000 Gas，区块上限 30,000,000

#### 5.2.3 跨链交易（Flow 全生命周期）

- [ ] 准入提案发起（仅创世账户）— 定义 assetName、contractAddr、rate、crossChainInvestmentContractAddr、taskType
- [ ] 提案投票 — 锁定 Vote → 投票（赞成/反对），10 分钟周期，>50% 通过
- [ ] FlowIn（跃入）— 合约层 Token → UTXO 层 Native Token，汇率转换验证
- [ ] Native Token 质押/投资 — 跃入后的 Native Token 参与质押和投资
- [ ] FlowOut（跃出）— UTXO 层 Native Token → 合约层 Token
- [ ] 撤销提案 — 撤销后 Native Token 只能跃出，禁止新的跃入/质押
- [ ] 汇率精度验证 — `跃入金额 = (Token数量 × ExchangeRate × 10^8) / (10^rateDecimal × 10^18)`
- [ ] 跨链合约部署与调用

#### 5.2.4 Flow 类交易

- [ ] 跃入（FlowIn）交易
- [ ] 跃出（FlowOut）交易
- [ ] 代付 Gas（`sponsor_gas` 参数）
- [ ] 跨链投资（CrossChainInvestment）
- [ ] 多种 taskType 验证（EnteringMore / CrossChainInvestment / Both / Null）

#### 5.2.5 压力测试

- [ ] 并发交易 — 多账户同时发送交易
- [ ] 长时间运行 — 持续 24h+ 稳定性
- [ ] 交易池边界 — 普通池 10,000 / 合约池 5,000 满载行为
- [ ] 交易池淘汰 — FIFO + TTL（10 秒超时）验证
- [ ] 区块 Gas 熔断 — 超过 30,000,000 Gas 时 ExclusionProof 生成与验证
- [ ] 大区块处理 — 区块序列化大小上限 4MB

### 5.3 RPC 测试

#### 5.3.1 接口调用

- [ ] 基础查询接口 — GetVersion / GetBalance / GetBlockHeight / GetChainId / GetAccounts
- [ ] 节点信息接口 — GetNodeList / GetAllStakeNodeList / GetAddrType
- [ ] 收益信息接口 — GetYieldInfo / GetBonusInfo
- [ ] 区块交易查询 — GetTransactionByHash / GetBlockByHash / GetBlockByHeight / GetBlockByTransactionHash
- [ ] UTXO 查询 — GetDelegatingUtxo / GetStakingUtxo / GetLockUtxo
- [ ] 合约查询 — IsContract / GetUtxoDeployerByConAddr / GetAssetTypeByContractAddr
- [ ] 投票查询 — GetVoteAddrs / GetVoteTxHash / GetAllAssetType / GetAssetTypeInfo
- [ ] 交易创建接口 — CreateTransaction / CreateStakingTransaction / CreateDelegatingTransaction 等 14 种
- [ ] 消息发送 — SendMessage / SendContractMessage
- [ ] 回滚查询 — GetRollbackBlocks
- [ ] ETH 兼容接口 — 17 个标准方法逐一验证

#### 5.3.2 RPC 压力测试

- [ ] 高并发 RPC 请求
- [ ] 长时间 RPC 连接稳定性
- [ ] 错误码验证（RPC_PARSE_ERROR / GLOBAL_ERROR / CONTRACT_ERROR / CA_ERRORS）

### 5.4 钱包测试

- [ ] MetaMask 连接 — 自定义网络配置（RPC URL + Chain ID 12315 + 货币符号 OHI）
- [ ] OKX Wallet 连接
- [ ] 钱包转账交易
- [ ] 钱包合约交互（通过 DApp）
- [ ] ETH 兼容接口精度转换验证（10^8 ↔ 10^18）
- [ ] `eth_gasPrice` 固定返回 `0x1` 的兼容性处理

### 5.5 工具类测试

- [ ] SDK 测试（如有）
- [ ] Hardhat 部署与交互
- [ ] Web3.js / ethers.js 连接
- [ ] 部署脚本验证
- [ ] CLI 工具（`./openhive -c` 生成配置、`./openhive -d` 守护进程启动）

### 5.6 浏览器测试

- [ ] 区块数据展示（高度、哈希、时间戳、交易数量）
- [ ] 交易详情展示（类型、输入/输出、签名、Gas）
- [ ] 账户信息展示（余额、质押、委托、锁定状态）
- [ ] 合约信息展示（代码、状态、部署者）
- [ ] 节点列表展示
- [ ] 功能性操作（搜索、跳转、筛选）

### 5.7 Hub 测试

- [ ] Hub 交易处理
- [ ] Hub 跨链交易
- [ ] Hub 特殊业务处理
- [ ] Hub 与节点间数据一致性

### 5.8 异常测试

- [ ] DDoS 模拟 — 大量无效请求冲击
- [ ] 异常交易 — 非法签名、双花、超时交易、Gas 不足
- [ ] 节点离线 — 单节点离线后重连，验证同步恢复
- [ ] 多节点离线 — 超过共识阈值的节点离线
- [ ] 网络分区 — 部分节点间网络不通
- [ ] 拜占庭节点 — 发送错误区块/交易数据
- [ ] 时钟偏差 — 节点时间不同步（超过 ±10 秒 VRF 窗口）

### 5.9 DAG 分叉与同步测试

- [ ] 分叉触发 — 同一高度产生多个有效区块
- [ ] 分叉检测 — 15 秒周期检测，51% 简单多数判定
- [ ] 分叉回滚 — 回滚保护验证（15 秒超时、60 秒稳定期、10 块高度差限制）
- [ ] BFT 验证 — 66% 阈值在快速同步中的作用
- [ ] 同步模式切换 — SyncNormal / SyncFromZero / Broadcast
- [ ] 快速同步降级 — 失败 5 次后切换到从零同步
- [ ] 新节点首次同步 — 从创世区块完整同步
- [ ] 离线节点重连 — 离线一段时间后追赶同步
- [ ] 补块协议 — 依赖区块丢失导致的链式验证中断恢复
- [ ] SumHash 验证 — 每 100 区块汇总哈希一致性
- [ ] 千区块汇总 — 每 1000 区块校验哈希一致性

### 5.10 治理测试

- [ ] 提案发起 — 仅创世账户可发起
- [ ] 非创世账户发起提案 — 应被拒绝
- [ ] 投票流程 — 锁定 Vote → 投票（赞成/反对）→ 10 分钟周期 → >50% 通过
- [ ] 投票重复 — 单账户单提案仅能投票一次
- [ ] 提案通过 — Native Token 可跃入
- [ ] 提案未通过 — 无效果
- [ ] 撤销提案 — Native Token 只能跃出

### 5.11 精度与兼容性测试

- [ ] 双精度转换 — 标准精度（RPC）↔ 最小精度（存储，×10^8）
- [ ] ETH 精度转换 — 10^8 ↔ 10^18 自动转换
- [ ] `blockPrevRandao` 可预测性验证（已知中等风险）
- [ ] 缺少 KZG 预编译（0x0a）的兼容性
- [ ] `eth_gasPrice` 固定返回 `0x1` 的影响
- [ ] EIP-1559 baseFee 动态调整验证（目标 60,000，初始 10）
- [ ] UTXO Gas 计算验证（输入 64B/个 + 所有者 34B/个 + 输出 34B/个）

### 5.12 共识机制测试

- [ ] VRF 周期稳定性 — 10 秒周期
- [ ] 准入池筛选 — 质押概率（初始 50%，每日递增 2.5%）
- [ ] 白名单节点 — 100% 通过准入
- [ ] 频率筛选 — 动态阈值（总节点数 × 55%）
- [ ] 打包节点选择 — 随机选择 3 个节点
- [ ] 区块签名验证 — 至少 3 个有效签名
- [ ] 异常节点惩罚 — 签名量低于平均值，奖励按比例扣减
- [ ] 区块上链率探测 — T+5s / T+10s / T+20s，≥80% 确认

---

## 6. 运维与监控

### 6.1 节点监控

- [ ] 区块高度增长监控
- [ ] VRF 周期稳定性监控（10 秒）
- [ ] 节点心跳状态监控（60 秒间隔，180 秒超时）
- [ ] 交易池水位监控（普通池 10,000 / 合约池 5,000）
- [ ] 节点连接数监控
- [ ] 区块上链率监控（`enable_block_rate_probe: true`）

### 6.2 日志管理

- [ ] 节点日志收集（spdlog）
- [ ] 日志级别配置（`log_level` / `log_to_file`）
- [ ] 集中日志平台对接
- [ ] 关键错误告警

### 6.3 备份与恢复

- [ ] RocksDB 数据备份方案
- [ ] 配置文件备份
- [ ] 灾难恢复流程
- [ ] 从备份恢复后状态一致性验证

---

## 7. GitHub

### 7.1 代码提交

- [ ] TestNet 分支管理策略
- [ ] 代码审查流程
- [ ] 版本号管理

### 7.2 文档提交

- [ ] TestNet 部署文档
- [ ] 测试报告模板
- [ ] 已知问题与限制文档（8 项已知安全限制）
- [ ] Wiki 文档更新（基于 TestNet 测试结果）

---

## 附录：关键参数速查

| 参数 | 值 | 说明 |
|------|------|------|
| VRF 周期 | 10 秒 | 打包节点选择周期 |
| 最小共识节点数 | 3 (TestNet) / 10 (Primary) | kConsensus |
| 最小质押量 | 3,500 OHI | MIN_STAKE_AMOUNT |
| 最小投资额 | 500 OHI | — |
| 投资上限 | 3,500,000 OHI | 单节点 |
| 最大投资次数 | 1,000 | 单节点 |
| 佣金率 | 5%-35% | 节点可配置 |
| 最小锁定量 | 1 OHI (Vote) | — |
| 区块 Gas 上限 | 30,000,000 | 触发熔断 |
| 单笔合约最大 Gas | 120,000 | — |
| 普通交易池 | 10,000 | MAX_TX_POOL_SIZE |
| 合约交易池 | 5,000 | MAX_CONTRACT_POOL_SIZE |
| 交易超时 | 10 秒 | KtxTimeout |
| 心跳间隔 | 60 秒 | HEARTBEAT_INTERVAL |
| 心跳超时 | 180 秒 | 3 次无响应断连 |
| P2P 端口 | 13133 | TCP |
| HTTP 端口 | 13134 | JSON-RPC |
| HTTPS 端口 | 443 | 可选 |
| Chain ID | 0x3027 (12315) | — |
| EVM 版本 | evmone v0.14.1 / Cancun | — |
| 回滚超时 | 15 秒 | RollBackTime |
| 稳定期 | 60 秒 | kStabilityTime |
| 分叉判定阈值 | 51% | 简单多数 |
| BFT 阈值 | 66% | 拜占庭容错 |
| 区块大小上限 | 4 MB | — |
| 投票周期 | 10 分钟 | KVoteCycle |
| 投票通过阈值 | >50% | 赞成票 |
