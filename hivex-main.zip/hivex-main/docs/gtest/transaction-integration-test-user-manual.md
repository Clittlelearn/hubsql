# Transaction Integration Test User Manual

## Scope

This manual describes the menu-driven GTest transaction integration tests enabled by `ENABLE_TX_TESTS=ON`.

Current suites:

- `Transfer.*`
- `Stake.*`
- `Delegate.*`
- `Undelegate.*`
- `Lock.*`
- `Unlock.*`
- `Vote.*`
- `Bonus.*`
- `Fund.*`

The tests run inside the `openhive` process through advanced menu `46. Transaction Tests`. Test configuration is read from `test_config.json` in the same directory as the running `openhive` binary.

## Build

From a clean build directory:

```bash
cmake .. -DENABLE_TX_TESTS=ON
make -j24
```

Disable the menu and test code with:

```bash
cmake .. -DENABLE_TX_TESTS=OFF
make -j24
```

The project uses system GTest (`libgtest-dev`). GTest is not added to `deps_build`, and the binary links `gtest` only, not `gtest_main`.

## Menu Flow

Open advanced menu, then enter:

```text
46. Transaction Tests
```

Submenu:

```text
1. Run All Tests
2. Test TX Transfer
3. Test Stake
4. Test Delegate
5. Test Lock
6. Test Vote
7. Test Unstake (requires pre-staked account > 30 days)
8. Test Undelegate (requires pre-delegated account > 30 days)
9. Test Unlock (requires pre-locked account > 30 days)
10. Test Bonus
11. Test Fund
12. Configure Test Accounts
0. Back
```

Configuration submenu:

```text
1. Generate or overwrite accounts/scenarios template
2. Reload and validate current config
3. Print current config summary
0. Back
```

Use option `12 -> 2` after editing `test_config.json`; restarting the node is not required for config reload.

Each scenario accepts an optional `enabled` boolean. It defaults to `true` for backward compatibility. Set it to `false` to skip only that GTest case while allowing the other scenarios in the same transaction suite to run.

## Configuration Model

The config has three main sections:

- `assets`: short asset aliases mapped to canonical asset types.
- `accounts`: account aliases with `address`, `key_path`, and declared asset aliases.
- `scenarios`: transaction-specific test inputs that reference account and asset aliases.

Addresses may include `0x`; tests normalize them internally. Amounts are minimum units. For OHI, `1 OHI = 100000000`.

Example asset and account entries:

```json
{
  "assets": {
    "ohi": {"asset_type": "OHI"},
    "asset_x": {"asset_type": "dcd2ea46...0aab086"}
  },
  "accounts": {
    "genesis": {
      "address": "0x755C...42CA",
      "key_path": "/root/code/openhive/build/bin/keystore",
      "assets": ["ohi"]
    },
    "sender1": {
      "address": "0x946d...AeFf",
      "key_path": "/root/code/openhive/build/bin/keystore",
      "assets": ["ohi", "asset_x"]
    }
  }
}
```

Scenario `asset_type` and `gas.asset_type` values may use these aliases. `OHI` and complete 64-character hexadecimal asset types remain valid for backward compatibility. Hexadecimal asset types are normalized without a `0x` prefix. Unknown aliases fail config validation, and enabled scenarios require the sending and gas-paying accounts to declare the resolved assets.

## Scenario Notes

`basic` generally targets the genesis account or a simple prepared account.

`non_genesis` should use a non-genesis account so gas is charged normally.

`separate_gas_asset` means the same sender uses a different asset type to pay gas. It does not mean a third-party sponsor. For these tests:

```json
"asset_type": "ohi",
"gas": {
  "from": "sender1",
  "asset_type": "asset_x"
}
```

The gas asset must differ from the transaction asset.

## Per-Suite Preconditions

`Transfer.*`:

- `from` and `to` must be different accounts.
- `from` must have enough `asset_type` UTXO.
- Separate gas asset scenarios require the same sender to have enough gas asset.

`Stake.*`:

- `amount >= MIN_STAKE_AMOUNT` (`3500 * 100000000`).
- A staking account can only have one active stake for a given asset type.
- Use different accounts for `non_genesis` and `separate_gas_asset` to avoid one test causing the next to skip.

`Delegate.*`:

- `amount >= kMinDelegatingAmt` (`500 * 100000000`).
- `to` is the bonus/stake target address.
- Separate gas asset follows the same account/different asset rule.

`Unstake.*`:

- Requires a valid active stake transaction hash in `utxo_hash`.
- The stake must satisfy the chain's unstake qualification rules, including time/height requirements.

`Undelegate.*`:

- Requires a valid delegate transaction hash in `utxo_hash`.
- `from` is the delegator account, `to` is the bonus/stake target account.
- The delegate record must satisfy undelegate qualification rules.

`Lock.*`:

- Uses OHI lock asset.
- `amount >= LOCK_AMOUNT * kDecimalNum`.
- A lock account cannot already have an active lock record.

`Unlock.*`:

- Requires a valid active lock transaction hash in `utxo_hash`.
- The lock must satisfy unlock qualification rules.

`Vote.*`:

- `from` must be qualified to vote. Usually this means the account has an active lock record.
- `vote_hash` must reference a valid proposal/revoke-proposal transaction.
- `vote_tx_type` should match the target transaction type, usually `11` for `PROPOSAL`.
- `vote_type` is passed directly to the chain vote logic.

`Bonus.*`:

- Requires the account to be eligible for bonus claiming.
- The chain must have calculable bonus value for the account.
- If using separate gas, gas asset must be prepared.

`Fund.*`:

- Requires previous-period fund rewards to exist.
- Account must be eligible through lock and/or package contribution rules.

## What Tests Assert

The assertions are based on each transaction's implementation and state transition:

- transaction type
- JSON `txInfo` fields
- expected virtual vout address and amount, such as `VirtualStake`, `VirtualDelegating`, or `LockVirtualStake`
- gas burn value and separate gas asset behavior where supported
- sender balance changes
- every normal vin `(hash, n=0)` belongs to the pre-transaction asset snapshot
- redeem business vin uses the configured `(hash, n=1)`, while additional balance inputs remain `n=0`
- consumed UTXO removal and creation of expected change/release outputs
- state-critical vin/vout fields in the DB transaction match the locally built transaction after chain inclusion
- stake or lock DB records where applicable

Some suites with strong environmental prerequisites use `GTEST_SKIP()` when config is incomplete or prerequisite DB records are missing. If config is complete and the transaction builds, failures indicate transaction behavior or assertion mismatch that should be investigated.

## Recommended Validation Order

Use fresh/prepared accounts and validate one suite at a time:

1. `Transfer.*`
2. `Stake.*`
3. `Delegate.*`
4. `Lock.*`
5. `Vote.*`
6. `Unstake.*`
7. `Undelegate.*`
8. `Unlock.*`
9. `Bonus.*`
10. `Fund.*`

For `Unstake`, `Undelegate`, and `Unlock`, first run the corresponding create-side transaction and copy the resulting chain transaction hash into `utxo_hash` after the qualification period is satisfied.
