# 交易集成测试方案

**版本**: 1.2
**日期**: 2026-07-09
**状态**: 基础 helper、TX 转账用例、STAKE 质押用例已落地，ENABLE_TX_TESTS=ON/OFF 构建已通过，待 DevNet 验证

---

## 1. 背景与目标

### 1.1 现状

项目已有基于 GTest 的单元测试框架（`tests/` 目录），历史上通过独立 `test` 可执行目标运行。当前测试主要覆盖纯逻辑场景（如 `test_transaction_cache_concurrency.cpp`），缺少对交易生命周期的集成测试。

当前分支 `feat_integrate_gtest_main` 已完成主程序集成骨架：删除独立 `test` 目标，新增 `ENABLE_TX_TESTS` 编译开关，将测试入口接入高级菜单 `46. Transaction Tests`。

### 1.2 目标

为每种交易类型（TX、STAKE、UNSTAKE、DELEGATE、UNDELEGATE、LOCK、UNLOCK、VOTE、BONUS、FUND 等）建立集成测试，验证：

- 交易构建与签名的正确性
- 交易上链后状态变更的正确性（余额、UTXO、质押/委托/锁定记录等）
- 区块内交易内容（vout、gas、type、txInfo）的正确性
- 守恒不变量（发送方减少 = 接收方增加 + gas 销毁）

### 1.3 核心决策

经过讨论，确定以下技术方案：

| 决策项 | 结论 | 原因 |
|--------|------|------|
| 测试运行方式 | 集成到主程序中，通过菜单触发 | 交易测试需要完整节点环境（DB、网络、VRF共识、出块管线），独立二进制无法低成本获取这些环境 |
| 测试框架 | 保留 GTest，链接进主程序 | 利用 GTest 的断言（EXPECT_EQ/ASSERT_TRUE等）、过滤（--gtest_filter）、报告功能 |
| 交易提交方式 | 调用 `*Trans::goMessage()` | 与菜单完全相同的代码路径，签名/构建逻辑零重复 |
| 数据读取方式 | DBReader 直读 + RPC 查询接口 | DBReader 获取精确内部状态，RPC 验证对外接口正确性，两者交叉对比 |
| 独立 test 目标 | 删除 | 所有测试集成进主程序后，独立二进制失去意义，且增加构建复杂度 |
| OBJECT 库 | 删除 | OBJECT 库是为独立 test 目标共享源码而设，删除独立目标后不再需要 |

### 1.4 当前进展

截至 2026-07-07，已完成：

- 已从 `main` 创建并切换到分支 `feat_integrate_gtest_main`。
- 已删除 CMake 中独立 GTest `test` 目标，改为通过 `ENABLE_TX_TESTS` 将测试代码编译进主程序。
- 已新增 `tests/test_runner.h` / `tests/test_runner.cpp`，提供 GTest 初始化、过滤运行和交易测试子菜单。
- 已新增 `tests/test_helper.h` 声明骨架，并补充 `tests/test_helper.cpp` 实现配置读取、等待上链、余额/UTXO/交易查询和余额快照。
- 已在高级菜单 `45. Export and test contract` 之后新增 `46. Transaction Tests`，主菜单不新增测试入口。
- 已用 `nproc=24` 验证 `ENABLE_TX_TESTS=OFF` 和 `ENABLE_TX_TESTS=ON` 两种模式均可编译主程序。
- 已临时禁用 `tests/test_transaction_cache_concurrency.cpp` 后半段调用旧 `TransactionCache` API 的陈旧测试段，保留前半段 mock 并发测试，避免 `tests/*.cpp` 集成编译失败。
- 已将 `ENABLE_TX_TESTS=ON` 下的测试源从 `tests/*.cpp` 收敛为显式列表，目前包含 `tests/test_runner.cpp`、`tests/test_helper.cpp`、`tests/test_tx_transfer.cpp`、`tests/test_tx_stake.cpp`、`tests/test_tx_more.cpp`。
- 已实现 `configureTestAccounts()` 交互式写入程序二进制同级目录的 `test_config.json`，并在 `.gitignore` 中显式忽略该文件。
- 已新增 `tests/test_tx_transfer.cpp`，实现 TX 转账测试初版：支持按配置资产类型执行 `BasicTransfer`、可选 `NonGenesisTransfer`、可选 `TransferWithSeparateGasAsset`，并断言交易类型、收款 vout、gas vout、余额变化、找零和所有旧 UTXO 消费。
- 已安装系统级 `libgtest-dev`，并验证 `ENABLE_TX_TESTS=ON` 可完成主程序构建；保持只链接 `GTest::gtest`，不链接 `gtest_main`。

仍未完成：

- `Transfer.BasicTransfer` 已在 DevNet 节点上跑通；`NonGenesisTransfer` 和 `TransferWithSeparateGasAsset` 需要准备对应账户配置后验证。
- `ENABLE_TX_TESTS=ON` 已使用系统级 `libgtest-dev` 完成配置和主程序构建验证，未将 GTest 纳入 `deps_build`。
- `Stake.*` 三个用例已完成初版；DELEGATE、LOCK、VOTE 等其他真实交易生命周期测试用例尚未实现。
- `configureTestAccounts()` 已能写入配置，但尚未做地址格式、余额和前置条件校验。

---

## 2. 架构设计

### 2.1 运行时架构

```
主程序（节点进程）
├── 线程1: 主菜单循环
│   └── 用户选择"运行测试" → RUN_ALL_TESTS()
│       ├── GTest 在当前线程执行测试用例
│       ├── 测试用例调用 goMessage() 提交交易
│       └── 测试用例等待出块后读取状态、断言
│
├── 线程2: 网络层（epoll event loop）    ← 不受测试影响
├── 线程3: VRF 共识 / 出块管线           ← 不受测试影响
├── 线程4: 区块同步                       ← 不受测试影响
└── ...其他后台线程
```

关键点：节点的核心循环在独立线程中运行，GTest 在菜单线程中执行，互不干扰。交易通过 `goMessage()` 提交后，由正常的出块管线打包上链。

### 2.2 交易提交路径

```
测试用例
  → *Trans::trans()          构建交易体
  → *Trans::signTx()         签名（复用项目代码，零额外工作）
  → *Trans::goMessage()      提交
      → handleTransaction()  验证 + TransactionCache::AddCache()
      → VRF 出块管线          自动打包进区块
  → DBReader / RPC           读取后态
  → EXPECT_* / ASSERT_*      断言
```

注意：`goMessage()` 内部通过 `tx.identity()` 判断打包节点。在单节点 DevNet 环境下，`identity` 为本机地址，走本地路径 `handleTransaction()`。

### 2.3 编译控制

通过 CMake 选项 `ENABLE_TX_TESTS` 控制是否将测试代码编译进主程序：

```bash
# 测试构建（包含测试代码）
cmake -DENABLE_TX_TESTS=ON ..

# 生产构建（不含测试代码）
cmake ..
```

---

## 3. 账户规划

### 3.1 账户分类

| 账户 | 用途 | 前置条件 | 测试的交易类型 |
|------|------|---------|--------------|
| 账户 A | 通用测试 | 有私钥，余额充足 | TX, STAKE, DELEGATE, LOCK, VOTE |
| 账户 B | 解押专用 | 已质押 > 30 天 | UNSTAKE |
| 账户 C | 撤资专用 | 已委托 > 30 天 | UNDELEGATE |
| 账户 D | 解锁专用 | 已锁定 > 30 天 | UNLOCK |
| 账户 E | 奖励专用 | 有委托且节点已产出奖励 | BONUS |
| 账户 F | 国库专用 | 有锁仓或打包贡献记录 | FUND |

### 3.2 配置管理

测试账户信息通过程序二进制同级目录的 `test_config.json` 配置，不硬编码在代码中，不入库（加入 .gitignore）。当前采用 `assets + accounts + scenarios` 结构：`assets` 维护短名称到规范资产类型的映射；`accounts` 维护账户别名、地址、私钥路径和资产别名集合；`scenarios` 按交易类型引用账户和资产别名。每个 scenario 支持可选的 `enabled` 布尔字段，缺省为 `true`；设为 `false` 时对应 GTest 用例明确跳过，且不影响同一交易类型下的其他场景。

```json
{
  "assets": {
    "ohi": {"asset_type": "OHI"},
    "asset_x": {"asset_type": "<asset-x-hash>"},
    "asset_y": {"asset_type": "<asset-y-hash>"}
  },
  "accounts": {
    "genesis": {
      "address": "0x<genesis-address>",
      "key_path": "<genesis-key-path>",
      "assets": ["OHI", "<asset-x>"]
    },
    "sender1": {
      "address": "0x<normal-sender-address>",
      "key_path": "<normal-sender-key-path>",
      "assets": ["OHI", "<asset-x>", "<asset-y>"]
    },
    "receiver1": {
      "address": "0x<receiver-address>",
      "key_path": "<receiver-key-path>",
      "assets": ["OHI", "<asset-x>"]
    },
    "staker1": {
      "address": "0x<normal-staker-address-1>",
      "key_path": "<normal-staker-key-path-1>",
      "assets": ["OHI"]
    },
    "staker2": {
      "address": "0x<normal-staker-address-2>",
      "key_path": "<normal-staker-key-path-2>",
      "assets": ["OHI", "<asset-x>"]
    }
  },
  "scenarios": {
    "transfer": {
      "basic": {
        "from": "genesis",
        "to": "receiver1",
        "asset_type": "OHI",
        "amount": 100000000
      },
      "non_genesis": {
        "from": "sender1",
        "to": "receiver1",
        "asset_type": "OHI",
        "amount": 100000000
      },
      "separate_gas_asset": {
        "from": "sender1",
        "to": "receiver1",
        "asset_type": "OHI",
        "amount": 100000000,
        "gas": {
          "from": "sender1",
          "asset_type": "<asset-x>"
        }
      }
    },
    "stake": {
      "basic": {
        "from": "genesis",
        "asset_type": "OHI",
        "amount": 350000000000,
        "reward_rate": "5"
      },
      "non_genesis": {
        "from": "staker1",
        "asset_type": "OHI",
        "amount": 350000000000,
        "reward_rate": "5"
      },
      "separate_gas_asset": {
        "from": "staker2",
        "asset_type": "OHI",
        "amount": 350000000000,
        "reward_rate": "5",
        "gas": {
          "from": "staker2",
          "asset_type": "<asset-x>"
        }
      }
    }
  }
}
```

首次运行可通过 46 -> 12 -> 1 生成模板；测试人员编辑程序同级目录的 `test_config.json` 后，可通过 46 -> 12 -> 2 重新加载并验证当前配置。运行测试前若程序同级目录不存在 `test_config.json`，测试菜单会提示先执行 12 号配置项。

---

## 4. 文件组织

```
tests/
├── test_helper.h                ← 通用辅助函数和宏声明（已创建）
├── test_helper.cpp              ← 通用辅助函数实现（已创建）
├── test_runner.h                ← 测试菜单入口声明（已创建）
├── test_runner.cpp              ← 测试菜单入口，GTest 初始化（已创建）
│
│   ── 交易集成测试（新增）──
├── test_tx_transfer.cpp         ← TX 普通转账
├── test_tx_stake.cpp            ← STAKE 质押
├── test_tx_more.cpp             ← DELEGATE / UNDELEGATE / LOCK / UNLOCK / VOTE / BONUS / FUND 等
│
│   ── 纯单元测试（已有，保留）──
├── test_transaction_cache_concurrency.cpp
└── ...其他已有单元测试
```

当前实现中，所有 `tests/*.cpp` 文件在 `ENABLE_TX_TESTS=ON` 时编译进主程序。后续建议改为明确列表或命名约定，只纳入交易集成测试相关源文件，避免历史单元测试、RPC 测试或样例测试污染主程序测试入口。

---

## 5. CMakeLists.txt 修改要点

### 5.1 删除的内容

- `add_library(openhive_objs OBJECT ${SOURCES})` 及相关的 `target_include_directories`
- `redefine_file_macro(openhive_objs)` — 仅保留 `redefine_file_macro(${PROJECT_NAME})`
- `add_dependencies(openhive_objs proto_gen)` — 改为 `add_dependencies(${PROJECT_NAME} proto_gen)`
- 主程序中的 `$<TARGET_OBJECTS:openhive_objs>` — 恢复为直接编译 `${SOURCES}`
- 整个 GTest 独立 `test` 目标及其配置（`add_executable(test ...)`, `target_link_libraries(test ...)` 等）

### 5.2 新增的内容

```cmake
# 交易集成测试（编译进主程序）
option(ENABLE_TX_TESTS "Include transaction integration tests in main binary" OFF)

if(ENABLE_TX_TESTS)
    find_package(GTest REQUIRED)

    file(GLOB TEST_SOURCES "tests/*.cpp")
    target_sources(${PROJECT_NAME} PRIVATE ${TEST_SOURCES})
    target_include_directories(${PROJECT_NAME} PRIVATE ${GTEST_INCLUDE_DIRS})
    if(TARGET GTest::gtest)
        target_link_libraries(${PROJECT_NAME} PRIVATE GTest::gtest)
    else()
        target_link_libraries(${PROJECT_NAME} PRIVATE ${GTEST_LIBRARIES})
    endif()
    target_compile_definitions(${PROJECT_NAME} PRIVATE ENABLE_TX_TESTS)

    message(STATUS "Transaction integration tests: ENABLED")
else()
    message(STATUS "Transaction integration tests: DISABLED")
endif()
```

### 5.3 主程序源码编译恢复

```cmake
# 恢复为直接编译（不再通过 OBJECT 库）
add_executable(${PROJECT_NAME} ${MAIN_FILE} ${SOURCES})
target_include_directories(${PROJECT_NAME} PRIVATE ${PROJECT_INCLUDE_DIRS})
redefine_file_macro(${PROJECT_NAME})
add_dependencies(${PROJECT_NAME} proto_gen)
```

注意：`PROJECT_INCLUDE_DIRS` 变量可以保留，它定义了项目的 include 路径列表，对主程序仍然有用。

---

## 6. 菜单集成

### 6.1 菜单入口

测试入口不放在 `main/menu.cpp` 主菜单中，而是放在高级菜单 `ca/advanced_menu.cpp` 中。

在高级菜单 `45. Export and test contract` 之后新增 `46. Transaction Tests`：

```
44. View all bonus info.
45. Export and test contract
46. Transaction Tests    ← 新增，仅 ENABLE_TX_TESTS 开启时显示
 0. Exit
```

输入校验规则同步扩展到 `46`。当 `ENABLE_TX_TESTS=OFF` 时，菜单不显示 `46`，也不接受 `46` 输入。

### 6.2 测试子菜单

选择 46 后进入测试子菜单：

```
=== Transaction Tests ===
 1. Run All Tests
 2. Test TX Transfer
 3. Test Stake
 4. Test Delegate
 5. Test Lock
 6. Test Vote
 7. Test Unstake (requires pre-staked account > 30 days)
 8. Test Undelegate (requires pre-delegated account > 30 days)
 9. Test Unlock (requires pre-locked account > 30 days)
10. Test Bonus
11. Test Fund
12. Configure Test Accounts
 0. Back
```

选项 1-11 通过 `--gtest_filter` 只运行对应的测试套件。选项 12 进入配置维护子菜单，可生成模板、重新加载并验证当前配置、打印摘要。

### 6.3 代码入口

当前实现中，`tests/test_runner.cpp` 提供三个入口：

```cpp
void runTransactionTests(const std::string& filter = "");
void showTransactionTestMenu();
void configureTestAccounts();
```

`runTransactionTests()` 负责初始化 GTest、设置 `GTEST_FLAG(filter)` 并执行 `RUN_ALL_TESTS()`。当前实现使用一次性初始化，避免重复进入测试菜单时重复调用 `InitGoogleTest()`。

高级菜单调用示例：

```cpp
// ca/advanced_menu.cpp 中高级菜单选项 46 的处理
#ifdef ENABLE_TX_TESTS
case 46:
    showTransactionTestMenu();
    break;
#endif
```

`showTransactionTestMenu()` 位于 `tests/test_runner.cpp`，负责展示测试子菜单并按选项调用 `runTransactionTests()`。

---

## 7. 测试辅助函数

### 7.1 test_helper.h 核心内容

```cpp
// tests/test_helper.h
#pragma once
#ifdef ENABLE_TX_TESTS

#include <gtest/gtest.h>
#include "db/db_api.h"
#include "ca/global.h"

// ===== 配置管理 =====
struct TestConfig {
    std::string generalAddr;
    std::string unstakeAddr;
    std::string undelegateAddr;
    std::string unlockAddr;
    std::string bonusAddr;
    std::string fundAddr;
    // 从 test_config.json 加载
    static TestConfig load(const std::string& path = "test_config.json");
};

// ===== 等待交易上链 =====
// 轮询区块高度，检查交易是否已被打包
// timeout_seconds: 超时时间（秒），建议 120
// 返回: true = 已上链, false = 超时
bool waitForTxInChain(const std::string& txHash, int timeout_seconds = 120);

// ===== 快捷查询 =====
int64_t getBalance(const std::string& addr, const std::string& assetType = "OHI");
std::vector<std::string> getUtxoHashes(const std::string& addr, const std::string& assetType = "OHI");
bool utxoExists(const std::string& utxoHash, const std::string& addr, const std::string& assetType = "OHI");
CTransaction getTransaction(const std::string& txHash);

// ===== 状态快照 =====
struct BalanceSnapshot {
    int64_t balance;
    std::vector<std::string> utxoHashes;
    
    static BalanceSnapshot take(const std::string& addr);
};

#endif
```

### 7.2 等待上链的实现思路

```cpp
bool waitForTxInChain(const std::string& txHash, int timeout_seconds)
{
    DBReader reader;
    uint64_t startHeight = 0;
    reader.getBlockTop(startHeight);
    
    int elapsed = 0;
    while (elapsed < timeout_seconds) {
        sleep(5);  // 每 5 秒检查一次
        elapsed += 5;
        
        uint64_t currentHeight = 0;
        reader.getBlockTop(currentHeight);
        
        if (currentHeight > startHeight) {
            // 检查新区块中是否包含该交易
            std::string txRaw;
            int ret = reader.getTransactionByHash(txHash, txRaw);
            if (ret == 0) {  // 找到了
                return true;
            }
        }
        
        std::cout << "[Wait] " << elapsed << "s, height=" << currentHeight << std::endl;
    }
    return false;
}
```

---

## 8. 各交易类型测试用例

### 8.1 TX 普通转账 (test_tx_transfer.cpp)

```
测试套件: Transfer

用例: BasicTransfer
  前态: sender 余额, receiver 余额, sender UTXO 列表
  执行: TransforerTrans → trans() → signTx() → goMessage()
  等待: waitForTxInChain(txHash)
  断言:
    □ receiver 新增 UTXO 金额 == 转账金额
    □ sender 找零 UTXO 金额 == 原 UTXO - 转账金额 - gas
    □ VirtualBurnGas 收到 gas 金额的 UTXO
    □ 旧 UTXO 已从 sender 地址移除
    □ tx.type() == TxType::TX
    □ vout[0].addr == receiver, vout[0].value == 转账金额
    □ DBReader 读取结果与 RPC 查询结果一致
```

### 8.2 STAKE 质押 (test_tx_stake.cpp)

```
测试套件: Stake

用例: BasicStake
  前态: 地址余额, 质押状态（应无质押记录）
  执行: StakeTrans(amount=3500 OHI, commissionRate=0.10) → goMessage()
  断言:
    □ stakeAddr 列表包含该地址
    □ 质押 UTXO 已创建，金额 == 配置 amount
    □ 地址余额减少 == amount + gas
    □ vout[0] 写入 VirtualStake，vout value == amount
    □ txInfo 含 stakeType="Net", stakeAmount, commissionRate
    □ stake DB 中 getStakeAddr 包含该地址
    □ stake DB 中 getStakeUtxoByAddr(addr, assetType) 包含该交易 hash
    □ separate gas asset 场景下质押资产只扣 amount，gas 资产扣 gas
```

### 8.3 DELEGATE 委托 (test_delegate.cpp)

```
测试套件: Delegate

用例: BasicDelegate
  前态: 地址余额, 委托状态（应无）, 目标节点地址
  执行: DelegatingTrans(amount=500 OHI, bonusAddr=目标节点) → goMessage()
  断言:
    □ 委托关系已注册（bonusAddr → delegatingAddr）
    □ 委托 UTXO 已创建
    □ 余额减少 == 委托量 + gas
    □ vout 包含 VirtualDelegating
    □ 总委托量增加
    □ txInfo 含 bonusAddr, delegateAmount, delegateType="Normal"
```

### 8.4 LOCK 锁定 (test_lock.cpp)

```
测试套件: Lock

用例: BasicLock
  前态: 地址余额, 锁定状态（应无）, 总锁仓量
  执行: LockTrans(amount=1 OHI) → goMessage()
  断言:
    □ lockAddr 列表包含该地址
    □ 锁定 UTXO 已创建
    □ 余额减少 == 锁定量 + gas
    □ vout 包含 LockVirtualStake
    □ 总锁仓量增加 == 锁定量
    □ txInfo 含 lockType="LockNet", lockAmount
```

### 8.5 VOTE 投票 (test_vote.cpp)

```
测试套件: Vote

用例: BasicVote
  前置: 账户 A 已执行 LOCK（无需等 30 天，LOCK 后即可投票）
  前态: 锁定量
  执行: VoteTrans → goMessage()
  断言:
    □ voteNumber == 锁定量（lockValue）
    □ 投票计数已更新
    □ txInfo 含 voteHash, voteTxType, voteType, voteNumber
```

### 8.6 UNSTAKE 解押 (test_unstake.cpp，账户 B)

```
测试套件: Unstake

用例: BasicUnstake
  前置: 账户 B 已质押 > 30 天
  前态: 质押 UTXO hash, 质押金额, 地址余额
  执行: UnStake(stake_utxo_hash) → goMessage()
  断言:
    □ 质押 UTXO 已消费（从 stakeUtxo 移除）
    □ stakeAddr 已移除该地址（若无剩余质押）
    □ 余额增加 == 原质押金额 - gas
    □ 30 天锁定数据已写入
    □ vout[0].addr == 地址自身
    □ vout[0].value == 原质押金额
```

### 8.7 UNDELEGATE 撤资 (test_undelegate.cpp，账户 C)

```
测试套件: Undelegate

用例: BasicUndelegate
  前置: 账户 C 已委托 > 30 天
  前态: 委托 UTXO hash, 委托金额, 地址余额
  执行: UndelegatingTrans(undelegatingUtxo, bonusAddr) → goMessage()
  断言:
    □ 委托 UTXO 已消费
    □ 委托关系已清除
    □ 余额增加 == 原委托金额 - gas
    □ 30 天锁定数据已写入
    □ 总委托量减少
```

### 8.8 UNLOCK 解锁 (test_unlock.cpp，账户 D)

```
测试套件: Unlock

用例: BasicUnlock
  前置: 账户 D 已锁定 > 30 天
  前态: 锁定 UTXO hash, 锁定金额, 地址余额, 总锁仓量
  执行: UnlockTrans(unLockUtxo) → goMessage()
  断言:
    □ 锁定 UTXO 已消费
    □ lockAddr 已移除
    □ 余额增加 == 原锁定金额 - gas
    □ 总锁仓量减少
```

### 8.9 BONUS 申领奖励 (test_bonus.cpp，账户 E)

```
测试套件: Bonus

用例: BasicBonus
  前置: 账户 E 所在节点有可领取奖励
  前态: 各委托人的委托量, 节点佣金率, 当前 period
  执行: BonusTrans → goMessage()
  断言:
    □ 每个委托人的 vout 金额 == 预期奖励（扣除佣金后）
    □ 节点运营者 vout == 总佣金
    □ 总流通量增加 == 总奖励金额
    □ bonusUtxoByPeriod 记录了该交易
    □ 同一 period 不能重复领取
```

### 8.10 FUND 申领国库 (test_fund.cpp，账户 F)

```
测试套件: Fund

用例: BasicFund
  前置: 账户 F 有锁仓或打包贡献
  前态: 节点锁仓量, 打包次数, 全局统计
  执行: FundTrans → goMessage()
  断言:
    □ 无 VIN（凭空创建输出）
    □ 锁仓奖励 vout == totalReward × (nodeLocked/totalLocked) × 0.5
    □ 打包奖励 vout == totalReward × (nodePackages/totalPackages) × 0.5
    □ fundUtxoByPeriod 记录了该交易
```

---

## 9. 关键常量参考

测试中需要使用的常量（定义在 `ca/global.h`）：

| 常量 | 值 | 说明 |
|------|------|------|
| `kDecimalNum` | 100,000,000 (1e8) | 最小精度单位 |
| `MIN_STAKE_AMOUNT` | 3500 × kDecimalNum | 最低质押量 |
| `kMinDelegatingAmt` | 500 × kDecimalNum | 最低委托量 |
| `LOCK_AMOUNT` | 1 × kDecimalNum | 最低锁定量（使用时需乘 kDecimalNum） |
| `MAX_COMMISSION_RATE` | 0.35 (35%) | 最高佣金率 |
| `MIN_COMMISSION_RATE` | 0.05 (5%) | 最低佣金率 |
| `kTargetAddress` | "VirtualStake" | 质押虚拟地址 |
| `kVirtualDelegatingAddr` | "VirtualDelegating" | 委托虚拟地址 |
| `VIRTUAL_LOCK_ADDRESS` | "LockVirtualStake" | 锁定虚拟地址 |
| `VIRTUAL_BURN_GAS_ADDR` | "VirtualBurnGas" | Gas 销毁地址 |
| `ASSET_TYPE_OHI` | "OHI" | 资产类型标识 |

---

## 10. 关键代码路径参考

| 功能 | 文件 | 函数/类 |
|------|------|---------|
| 交易类型枚举 | `ca/global.h` | `enum class TxType` |
| 交易构建基类 | `ca/transaction/utxo_core.h` | `UtxoCore` |
| 普通转账 | `ca/transaction/trans.cpp` | `TransforerTrans::goMessage()` |
| 质押 | `ca/transaction/stake.cpp` | `StakeTrans::goMessage()` |
| 解押 | `ca/transaction/unstake.cpp` | `UnStake::goMessage()` |
| 委托 | `ca/transaction/delegating.cpp` | `DelegatingTrans::goMessage()` |
| 撤资 | `ca/transaction/undelegating.cpp` | `UndelegatingTrans::goMessage()` |
| 锁定 | `ca/transaction/lock.cpp` | `LockTrans::goMessage()` |
| 解锁 | `ca/transaction/unlock.cpp` | `UnlockTrans::goMessage()` |
| 投票 | `ca/transaction/vote.cpp` | `VoteTrans::goMessage()` |
| 奖励 | `ca/transaction/bonus.cpp` | `BonusTrans::goMessage()` |
| 国库 | `ca/transaction/fund.cpp` | `FundTrans::goMessage()` |
| 交易提交入口 | `ca/transaction.cpp` | `handleTransaction()` (line 1484) |
| Mempool | `ca/transaction_cache.cpp` | `TransactionCache::AddCache()` (line 251) |
| DB 只读接口 | `db/db_api.h` | `DBReader` |
| DB 读写接口 | `db/db_api.h` | `DBReadWriter` |
| Gas 计算 | `ca/transaction.cpp` | `CalculateGas()` (line 4119) |
| 菜单入口 | `main/menu.cpp` | `Menu()` (line 67) |
| 菜单处理函数 | `ca/ca.cpp` | `HandleTransaction()`, `HandleStake()` 等 |

---

## 11. 实施步骤

### 第一步：CMakeLists.txt 重构 + 骨架搭建（已完成）

1. 已基于 `main` 分支创建 `feat_integrate_gtest_main` 分支。
2. 已修改 CMakeLists.txt：
   - 已删除独立 GTest `test` 目标。
   - 已新增 `ENABLE_TX_TESTS` 条件编译块。
   - 已将测试代码链接进主程序。
   - 当前未涉及 OBJECT 库，因为当前 CMake 已是直接编译主程序源码。
3. 已创建 `tests/test_runner.h` / `tests/test_runner.cpp`（GTest 初始化 + RUN_ALL_TESTS + 测试子菜单）。
4. 已修改 `ca/advanced_menu.cpp`，在高级菜单 `45. Export and test contract` 后新增 `46. Transaction Tests`。
5. 已验证：
   - `cmake -S . -B /tmp/openhive-build-default -DENABLE_TX_TESTS=OFF`
   - `cmake --build /tmp/openhive-build-default --target openhive -j24`
   - `cmake -S . -B /tmp/openhive-build-tx -DENABLE_TX_TESTS=ON`
   - `cmake --build /tmp/openhive-build-tx --target openhive -j24`

### 第二步：测试源筛选（已完成）

当前 `ENABLE_TX_TESTS=ON` 会编译 `tests/*.cpp`。这会把历史单元测试、RPC 测试、样例测试一起纳入主程序。后续建议：

1. 改为显式维护交易集成测试源文件列表；或
2. 采用命名约定，例如只纳入 `tests/test_runner.cpp`、`tests/test_helper.cpp`、`tests/test_tx_*.cpp`；或
3. 将交易集成测试移动到 `tests/tx_integration/`，CMake 只收集该目录。

目标是避免旧测试 API 变更、RPC 外部依赖或样例代码影响主程序测试构建。当前已采用显式列表方式，只纳入交易集成测试相关源码。

### 第三步：测试辅助函数（已完成初版）

1. 已创建 `tests/test_helper.h` 声明骨架。
2. 已创建 `tests/test_helper.cpp`。
3. 已实现：
   - `TestConfig::load()`
   - `waitForTxInChain()`
   - `getBalance()`
   - `getUtxoHashes()`
   - `utxoExists()`
   - `getTransaction()`
   - `BalanceSnapshot::take()`
4. 待验证：辅助函数可正常读取 DB 数据，并能在 DevNet 节点上等待交易上链。

### 第四步：配置管理（已完成初版）

1. 已设计 `accounts + scenarios` 形式的 `test_config.json` 结构，由菜单生成模板，测试人员手工编辑。
2. 已将 `test_config.json` 加入 `.gitignore`，避免私钥路径和测试账户信息入库。
3. 已实现 `configureTestAccounts()` 子菜单：生成/覆盖模板、重新加载并验证当前配置、打印配置摘要。
4. 当前校验会重新读取程序同级目录的 `test_config.json`，检查 JSON 可解析、账户别名可解析，并将占位符配置标记为 incomplete；余额和交易前置条件仍由具体测试用例校验。

### 第五步：TX 转账测试（已完成初版，待 DevNet 验证）

1. 已创建 `tests/test_tx_transfer.cpp`。
2. 已实现 `Transfer.BasicTransfer`、`Transfer.NonGenesisTransfer`、`Transfer.TransferWithSeparateGasAsset` 三个用例，其中后两者按配置缺失自动 skip。
3. `Transfer.BasicTransfer` 已在 DevNet 跑通；`Transfer.NonGenesisTransfer` 和 `Transfer.TransferWithSeparateGasAsset` 待准备账户与多资产余额后验证。
4. 已将 TX 用例沉淀为后续交易测试模板。
5. 已强化 UTXO 状态断言：普通输入必须来自交易前对应资产快照且使用 `n=0`；上链交易的关键 vin/vout 状态必须与本地构建结果一致。

### 第六步：STAKE 质押测试（已完成初版，待 DevNet 验证）

1. 已创建 `tests/test_tx_stake.cpp`。
2. 已实现 `Stake.BasicStake`、`Stake.NonGenesisStake`、`Stake.StakeWithSeparateGasAsset` 三个用例。
3. 断言覆盖交易类型、txInfo、VirtualStake vout、burn gas、余额变化、普通 UTXO 消费、stake 地址列表和 stake UTXO DB 写入。
4. 同一账户已有 active stake 时按测试环境前置条件不足 skip；模板为 `non_genesis` 和 `separate_gas_asset` 使用不同 staker，避免顺序执行互相影响。

### 第七步：其余交易类型（已完成初版，待 DevNet 验证）

1. 已创建 `tests/test_tx_more.cpp`。
2. 已实现 `Delegate.BasicDelegate`、`Delegate.DelegateWithSeparateGasAsset`。
3. 已实现 `Lock.BasicLock`、`Lock.LockWithSeparateGasAsset`。
4. 已实现 `Unstake.BasicUnstake`、`Undelegate.BasicUndelegate`、`Unlock.BasicUnlock`，这些用例依赖配置中的历史 UTXO hash 和链上资格。
5. 已实现 `Vote.BasicVote`，依赖有效提案/撤销提案 hash 和投票资格。
6. 已实现 `Bonus.BasicBonus`、`Fund.BasicFund`，依赖奖励周期和资格数据。

### 第七步：验证与文档（待完成）

1. 每新增一类交易测试后，验证 `ENABLE_TX_TESTS=ON` 和 `OFF` 两种模式都能编译。
2. 在 DevNet 节点上运行对应测试套件。
3. 更新 README，说明构建参数、菜单路径和测试账户配置方式。

---

## 12. 注意事项

### 12.1 UTXO 追踪

UTXO 模型下，交易消费特定 UTXO 并产生新 UTXO。同一账户的多个测试需要追踪 UTXO 变化。建议：
- 每个测试用例开始时记录当前可用 UTXO
- 测试完成后更新 UTXO 记录
- 或使用不同子地址隔离不同测试

### 12.2 等待出块

VRF 周期 15 秒，交易不一定在下一个区块被打包。`waitForTxInChain()` 需要：
- 设置合理的超时时间（建议 120 秒）
- 每 5 秒轮询一次
- 超时后报告失败而非阻塞

### 12.3 30 天锁定

UNSTAKE、UNDELEGATE、UNLOCK 要求前置操作超过 30 天。这些测试：
- 需要提前准备专用账户（账户 B/C/D）
- 或者只测试"拒绝路径"（验证不到 30 天时正确拒绝）

### 12.4 编译开关

生产构建不应包含测试代码。确保：
- `ENABLE_TX_TESTS=OFF`（默认）时，tests/ 下的文件不参与编译
- 测试相关头文件用 `#ifdef ENABLE_TX_TESTS` 保护
- 菜单项在测试未启用时不显示或显示为灰色

### 12.5 goMessage() 统一性

UNSTAKE、UNDELEGATE、UNLOCK 目前在菜单中走旧代码路径（goMessage 被注释掉），待代码合并后统一走 goMessage()。本方案假设合并完成后实施。如果合并未完成，这些交易类型的测试需要走旧的提交路径。

### 12.6 当前构建注意事项

- `ENABLE_TX_TESTS=ON` 当前仍使用 `file(GLOB TEST_SOURCES "tests/*.cpp")`，后续应收敛测试源范围。
- 主程序应链接 `GTest::gtest`，不要链接 `gtest_main`，否则可能与主程序入口冲突。
- `tests/test_transaction_cache_concurrency.cpp` 后半段存在调用旧 `TransactionCache` API 的陈旧测试，目前已用 `#if 0` 禁用；后续可删除、迁移或按新 API 重写。
- 构建后 `gen_version_info.sh` 可能输出 `fatal: not a git repository ... there is no git in your shell`，当前不阻断目标生成；如需干净 CI 输出，应单独修复该脚本的工作目录或 git 检测逻辑。

## 13. 下一步检查点

建议按以下检查点推进：

1. 完成测试源筛选，确保 `ENABLE_TX_TESTS=ON` 只编译交易集成测试相关文件。
2. 实现 `tests/test_helper.cpp`，并添加最小 helper 自测或菜单 smoke test。
3. 实现 `test_config.json` 读写和 `.gitignore` 规则。
4. 实现 `Transfer.BasicTransfer` 并在 DevNet 跑通。
5. 将 TX/STAKE 测试沉淀为模板，再复制到 DELEGATE、LOCK、VOTE。
6. 准备 30 天前置账户或拒绝路径测试，用于 UNSTAKE、UNDELEGATE、UNLOCK。
7. 在 BONUS、FUND 前先确认 DevNet 的出块奖励、period 和统计数据稳定可控。
