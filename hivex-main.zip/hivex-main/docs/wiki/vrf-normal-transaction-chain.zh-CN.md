# 普通交易 VRF 创建与验证链路

本文档说明普通交易从发起、选择交易打包者、区块流转、最终广播过程中涉及的 VRF 创建与验证步骤。

## 参与角色

- 交易发起方：构造普通交易，并用自己的 VRF 密钥选择交易打包者。
- 交易打包者：被发起方选中，负责处理交易、补充交易确认签名并打包进区块。
- 区块验证者：由区块打包者通过 VRF 选出，负责验证区块流转。
- 最终广播接收节点：收到最终区块广播后，复验区块和必要的 VRF 证明。

## VRF 一：普通交易选择打包者

日志工作流名：`TX_PACKAGER`

创建方：交易发起方。

证明内容：发起方基于交易公开输入、候选节点集合和自己的 VRF 私钥生成 proof，选择 1 个交易打包者。

创建阶段：

```text
[VRF_CHAIN][TX_PACKAGER][CREATE][tx_request_create][tx:...]
```

本地验证阶段：

```text
[VRF_CHAIN][TX_PACKAGER][VERIFY][tx_request_handle][tx:...]
[VRF_CHAIN][TX_PACKAGER][VERIFY][tx_post_attach_check][tx:...]
```

区块流转验证阶段：

```text
[VRF_CHAIN][TX_PACKAGER][VERIFY][block_flow_verify][tx:...]
```

最终广播验证阶段：

```text
[VRF_CHAIN][TX_PACKAGER][VERIFY][block_broadcast_verify][tx:...]
```

判断标准：

- proof 必须能被发起方的 VRF 公钥验证。
- proof 重新计算出的 selected 必须等于 `tx.identity()`。
- `tx.selection_vrf` 是交易内的专用字段，不再混用 `tx.signature()`。

## VRF 二：区块打包者选择签名验证者

日志工作流名：`BLOCK_VALIDATOR`

创建方：区块打包者。

证明内容：区块打包者基于区块公开输入、候选节点集合和自己的 VRF 私钥生成 proof，选择区块流转验证者集合。

创建阶段：

```text
[VRF_CHAIN][BLOCK_VALIDATOR][CREATE][block_flow_create][block:...]
```

区块流转验证阶段：

```text
[VRF_CHAIN][BLOCK_VALIDATOR][VERIFY][block_flow_verify][block:...]
```

最终广播验证阶段：

```text
[VRF_CHAIN][BLOCK_VALIDATOR][VERIFY][block_broadcast_verify][block:...]
```

判断标准：

- proof 的 selector 必须等于区块打包者地址。
- proof 重新计算出的验证者集合，加上区块打包者自身，必须等于消息携带的完整 `verifyAddrs`。
- 最终区块广播通过 `BuildBlockBroadcastMsg.verifyAddrs` 和 `BuildBlockBroadcastMsg.validator_vrf` 复验这一步。

## 普通交易完整链路

1. 发起方创建普通交易。
2. 发起方创建 `TX_PACKAGER` proof，选出 `tx.identity()`。
3. 被选中的交易打包者收到交易请求，验证 `TX_PACKAGER` proof。
4. 打包者把交易放入区块。
5. 打包者创建 `BLOCK_VALIDATOR` proof，选出区块验证者集合。
6. 区块验证者在区块流转阶段验证 `TX_PACKAGER` 和 `BLOCK_VALIDATOR`。
7. 最终广播接收节点在广播阶段再次验证 `TX_PACKAGER` 和 `BLOCK_VALIDATOR`。

## 常用排查命令

```bash
grep "VRF_CHAIN.*TX_PACKAGER" mm_*.log
grep "VRF_CHAIN.*BLOCK_VALIDATOR" mm_*.log
grep "VRF_CHAIN.*block_flow_verify" mm_*.log
grep "VRF_CHAIN.*block_broadcast_verify" mm_*.log
```
