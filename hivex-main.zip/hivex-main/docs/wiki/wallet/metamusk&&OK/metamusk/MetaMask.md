

# MetaMask

### 1.添加自定义网络

![image-20260327125047310](.\image-20260327125047310.png)![image-20260327125058973](.\image-20260327125058973.png)![image-20260327125118131](.\image-20260327125118131.png)![image-20260327125132507](.\image-20260327125132507.png)



1. 打开 MetaMask

2. 点击顶部网络（默认 Ethereum Mainnet）

3. 点击 **“Add Network / 添加网络”**

4. 选择 **“Add a network manually”**

5. 填写以下信息（示例）：

   ```
   Network Name: MyChain Testnet
   RPC URL: http://127.0.0.1:8545
   Chain ID: 1337
   Currency Symbol: ETH
   Block Explorer URL: (可选)
   ```

   点击保存

   👉 成功后，钱包会自动切换到该网络

### 2.添加现有账户（钱包）

![image-20260327130119724](.\image-20260327130119724.png)![image-20260327130137836](.\image-20260327130137836.png)

1. 打开顶部账户
2. 选择 Add wallet

### 3.发送普通转账

![image-20260327130834389](.\image-20260327130834389.png)![image-20260327130851403](.\image-20260327130851403.png)![image-20260327130905698](.\image-20260327130905698.png)

1. 打开已经添加好的网络中的代币
2. 选择Send
3. 填写To(给某个账户转账的地址) ，Amount（相应的金额）
4. 然后点击Continue即可





