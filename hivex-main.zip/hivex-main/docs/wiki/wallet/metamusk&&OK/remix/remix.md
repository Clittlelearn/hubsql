# remix 接入

## 连接节点

选择钱包

![1774843694377](images/remix/1774843694377.png)

![1774843732155](images/remix/1774843732155.png)

选择matemask

![1774843780556](images/remix/1774843780556.png)

编译

![1774843831201](images/remix/1774843831201.png)

部署

![1774843853016](images/remix/1774843853016.png)
