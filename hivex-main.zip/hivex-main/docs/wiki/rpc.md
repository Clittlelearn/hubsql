## 查询类接口

### getTransactionByHash

**说明**：

根据交易hash获取交易信息

**参数**：

* id 透传信息
* jsonrpc  json版本
* params 参数
  * txHash 交易hash

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  * code 返回值编号
    * 0	success
    * -1   Transaction hash error
    * -2    Failed to parse transaction body
  * message 调用信息
  * tx 交易信息（详细信息见交易信息描述）

例子

```json
//req
{
  "id":"1",
  "jsonrpc":"2.0",
  "params":{"txHash":"bfc73f1c66c7c552cbdb3d02cc1c434b1efaf35fd3916350b5d8a38f92c96fc7"}
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "getTransactionByHash",
  "result": {
    "code": 0,
    "message": "success",
    "tx": {
      "Consensus": 7,
      "GasTx": 0,
      "Type": "Tx",
      "data": {
        "TxInfo": {
          "LockAmount": 100000000000,
          "LockType": "LockNet"
        }
      },
      "identity": "0x85240c8dF5011d5967FA4566D3e2Ad5575A51856",
      "info": "",
      "time": 1724827704568873,
      "txHash": "0xbfc73f1c66c7c552cbdb3d02cc1c434b1efaf35fd3916350b5d8a38f92c96fc7",
      "txType": 9,
      "utxo": [
        {
          "assetType": "X",
          "gasutxo": 0,
          "multisign": [
            {
              "pub": "xIVI+gfNGHAVrISn879D49+XV3HKT8kaHk7VnlAilvuQF67GYAeXqEoLapIjP0TBTcpsDHmZTqQUzjXVnJu0BQ==",
              "sign": "xIVI+gfNGHAVrISn879D49+XV3HKT8kaHk7VnlAilvuQF67GYAeXqEoLapIjP0TBTcpsDHmZTqQUzjXVnJu0BQ=="
            }
          ],
          "owner": [
            "0xffFd42e045737b11570B7981c2648ea532a10B23"
          ],
          "vin": {
            "prevout": {
              "hash": [
                "0x36b19c533a49ec05a06be9c99c4e1c2e1609f9679aa75989c8ae0999ca63562a"
              ]
            },
            "vinsign": [
              {
                "pub": "MCowBQYDK2VwAyEAnVwyI7Xwk4lVNwi4j7ogCoHyy40isQmMumbM58JKTTU=",
                "sign": "jXugdh1gM05AT73xU5WYP6THqX7ghdi4heKe04XjdsJQ/QhR6DxwkA5SLUO//lFswiiWFMf6gf697uVewJ4MAw=="
              }
            ]
          },
          "vout": [
            {
              "addr": "LockVirtualStake",
              "value": 100000000000
            },
            {
              "addr": "0xffFd42e045737b11570B7981c2648ea532a10B23",
              "value": 9759599999665600
            },
            {
              "addr": "VirtualBurnGas",
              "value": 26100
            }
          ]
        }
      ],
      "verifySign": [
        {
          "pub": "MCowBQYDK2VwAyEACE2DupNwSIpn854yGLj7QF/YHd6eAeLOhHYObzcbCTM=",
          "sign": "NTJntLI0ILj7hPFP1n5xmRj1eAOUKxEqec8cXLxGjjhJ74r8Qqn7fIwIsDbuQI8BGCD/D1Ikp9muLq/1eMACCw==",
          "signaddr": "0x85240c8dF5011d5967FA4566D3e2Ad5575A51856"
        }
      ]
    }
  }
}
```

### GetBlockByTransactionHash

**说明**：

根据交易hash获取块信息

**参数**：

* id 透传信息
* jsonrpc  json版本
* params 参数
  * txHash 交易hash

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  * code 返回值编号
    * 0	success
    * -1   Tx hash error
    * -2   Block hash error
    * -3   Block invert error
  * message 调用信息
  * blockInfo 块信息（详细信息见块信息描述）

例子

```json
//req
{
  "id":"1",
  "jsonrpc":"2.0",
  "params":{"txHash":"0x4505234713387c489827cc38a4209221bfe01fe65d688830b2f4f1871951b6e4"}
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetBlockByTransactionHash",
  "result": {
    "blockInfo": {
      "block": {
        "blocksign": [
          {
            "pub": "MCowBQYDK2VwAyEAyxQqn3qeeAnatwu4h6I67eponm6VIdgAq8e9E/ttMso=",
            "sign": "xTmjJ3Eg+D5vqQmoh45tSqXKkQKzWsf5viXngTn16YMt18zhTsvFSzxHSpdxG1ghy6W39vT3PaiDjhOay/8NBA==",
            "signaddr": "0x35c89d9d466efd46A22E4e14ffB7f257278936a4"
          },
          {
            "pub": "MCowBQYDK2VwAyEAkqKb/VZksy3W+yTrX1br/7XxyEfUT8NxqtNkgWbElW0=",
            "sign": "ycNo4/cbDzN6N/yAMhqfuryLAkQ1Nt7oxGFdUabD7yUtXoEYoE7BetrsNpteFoyQH+Ojb2FrgsPMQfxhiTfDBw==",
            "signaddr": "0xf1a3c06f94a5Ee892a30d3Bfd66Af9A956fAbFD6"
          },
          {
            "pub": "MCowBQYDK2VwAyEA9Nb6YjtFFvxCXpqvtKsACleUe1/uV8scNE5k/tsgvhQ=",
            "sign": "vLpBEcidJPIJG73uRWK2Lcj58fsqlmgn+0p87pda+za6Vk45sn9tjiLzLKJrMs4rwWIQ9fkVjQWD53hji8EPDw==",
            "signaddr": "0x9afDc8688CDd18C17e8183263300d121f9deEB7D"
          },
          {
            "pub": "MCowBQYDK2VwAyEAWoIv4oyj1KvKTNSwc7y3nYBgnHzUEvXoTtV6/Ajuk9M=",
            "sign": "6KiQerwod6LD0q2/vWb8hWt6b1BWYLbrlz/wHgi9yGqixjWKtsoqkbe5lwdR5yHoualrahWuK7aFH8U0tSveAg==",
            "signaddr": "0x73eE2Fc25e8f9Fc0297B71B527352c2fA788f1b3"
          },
          {
            "pub": "MCowBQYDK2VwAyEAGQz8jDoEorTdZ6fQDuqCGqEqLZQpkZYzfBTa9y1+H/4=",
            "sign": "2V03ve+GbMjnSuREd4Uc5uF5ucQO1CNuIt8l8TMnl0sXMxsjFlxUQfmTJkflIgGe447Y6VV1Y/+qLadFx83MAA==",
            "signaddr": "0x5e8cd8c67783f70322B1b4ACbB0059808053C8d2"
          },
          {
            "pub": "MCowBQYDK2VwAyEAxC4xdTxCxU0pIiHRmu/ikDwPnS4TMmwRQbq88cT9Xpw=",
            "sign": "iW0rxmyuDem/o5dE2MnDXL9KxviprzP/ncjnTCkOSDeK3gY7g4+fCmnAcMgKE3lii+mman0a4Dg6NDfn1NocBg==",
            "signaddr": "0xC55A0d261bd7F2cDfaBba2a0e785Bf11eF1DC3B7"
          },
          {
            "pub": "MCowBQYDK2VwAyEAfWXv+y1GhWJXMYnxZV+0sD7GwANNQ7KRbxTjzzdskwU=",
            "sign": "sUInzXJlLuybtgzwAlTiRxJuf2HLMcEdiiGNBEb4SjFF8pSumJQQujG8pQpiwelppPtC9WfL1hVlpiLDKT+eAQ==",
            "signaddr": "0x04dc129B0Bb3F9B2ad2eD97407109DDF75a91EEb"
          }
        ],
        "bytes": 2034,
        "data": null,
        "hash": "0x34e49bf1e7ea404cbfce4c462f492d0965d8b92d815c21d3f58e29cc7e548438",
        "height": 5,
        "merkleroot": "0x4505234713387c489827cc38a4209221bfe01fe65d688830b2f4f1871951b6e4",
        "prevhash": "0xbbb2bc3e5f11af6067a40cb99558b4346b4a5420b10b796e346de23744a71ca7",
        "time": 1726287221171952
      },
      "tx": [
        {
          "Consensus": 7,
          "GasTx": 0,
          "Type": "Tx",
          "identity": "0x35c89d9d466efd46A22E4e14ffB7f257278936a4",
          "info": "",
          "time": 1726287221171952,
          "txHash": "0x4505234713387c489827cc38a4209221bfe01fe65d688830b2f4f1871951b6e4",
          "txType": 1,
          "utxo": [
            {
              "assetType": "0x416ba3e59614072c3bbdfb4f194fe71d248a7d82b1727f2d4ca51f8b4aba1528",
              "gasutxo": 0,
              "multisign": [
                {
                  "pub": "DO8FihR8vOTWxUjEG3LHcTkcFnZFyd/mWv/QX7cjIYGUF1MqCNQc8WIOmdu2VmiN4gRF9cQcARtq0QPDz8MGDQ==",
                  "sign": "DO8FihR8vOTWxUjEG3LHcTkcFnZFyd/mWv/QX7cjIYGUF1MqCNQc8WIOmdu2VmiN4gRF9cQcARtq0QPDz8MGDQ=="
                }
              ],
              "owner": [
                "0xffFd42e045737b11570B7981c2648ea532a10B23"
              ],
              "vin": {
                "prevout": {
                  "hash": [
                    "0xc87ebdb92895a2a3a81d10a2c5c64371b1f1ebc33da5d861d4efbfa7f35d4320"
                  ]
                },
                "vinsign": [
                  {
                    "pub": "MCowBQYDK2VwAyEAnVwyI7Xwk4lVNwi4j7ogCoHyy40isQmMumbM58JKTTU=",
                    "sign": "IK0eU9QAdGKX1rVCzPuCoI83iTz7M+laAE7D6UAvSqLd0r8GLNqN+56QEkQsEfA8OQ7ONokhmAi+wkF5lioqDQ=="
                  }
                ]
              },
              "vout": [
                {
                  "addr": "0xc5CAf882D5B49F2b2b9D31400D4726E61BC8fBAB",
                  "value": 2000000000000
                },
                {
                  "addr": "0xc5b22F90279130e954bC1CbdFDf3772E8C2C0df0",
                  "value": 2000000000000
                },
                {
                  "addr": "0xc8bbA532f295EA2Ed02B4B51405F9129c17B5CB2",
                  "value": 2000000000000
                },
                {
                  "addr": "0xc9152625Abefeff3cf1211249d85Bae1744B68e5",
                  "value": 2000000000000
                },
                {
                  "addr": "0xd55b75566DEaD988205B01757938B2c985E2e335",
                  "value": 2000000000000
                },
                {
                  "addr": "0xda6DD96003bc6B8770857967de324Bc3b37C7506",
                  "value": 2000000000000
                },
                {
                  "addr": "0xf1a3c06f94a5Ee892a30d3Bfd66Af9A956fAbFD6",
                  "value": 2000000000000
                },
                {
                  "addr": "0xffFd42e045737b11570B7981c2648ea532a10B23",
                  "value": 9985999999959400
                },
                {
                  "addr": "VirtualBurnGas",
                  "value": 40600
                }
              ]
            }
          ],
          "verifySign": [
            {
              "pub": "MCowBQYDK2VwAyEAyxQqn3qeeAnatwu4h6I67eponm6VIdgAq8e9E/ttMso=",
              "sign": "36ZEG2kZZ5wkTCzHq+oCJBIrkJYUt909ShKZILG24y5F256OX8nlk5AVi5Dn+7Vvm97CQkmDLVdEKyQksxq7BQ==",
              "signaddr": "0x35c89d9d466efd46A22E4e14ffB7f257278936a4"
            }
          ]
        }
      ]
    },
    "code": 0,
    "message": "success"
  }
}
```



### GetBlockByHash

**说明**：

根据块hash获取块信息

**参数**：

* id 透传信息
* jsonrpc  json版本
* params 参数
  * blockHash 块hash

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  * code 返回值编号
    * 0	success
    * -1   Block hash error
  * message 调用信息
  * blockInfo 块信息（详细信息见块信息描述）

例子

```json
//req
{
  "id":"1",
  "jsonrpc":"2.0",
  "params":{"blockHash":"0xb51f9199b387ce0b45c847c85f86fa3db3eb5e15b50b4a267dd9f582cd4bc256"}
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetBlockByHash",
  "result": {
    "blockInfo": {
      "block": {
        "blocksign": [
          {
            "pub": "MCowBQYDK2VwAyEACE2DupNwSIpn854yGLj7QF/YHd6eAeLOhHYObzcbCTM=",
            "sign": "oKx5qKFORpeQ5XyrbR6bzPQyUFyB2W7iW9kVZ7QkFUK6KYpb+1Hc4asO8ra63C572FhXpBMvda5aF74TjA1ECg==",
            "signaddr": "0x85240c8dF5011d5967FA4566D3e2Ad5575A51856"
          },
          {
            "pub": "MCowBQYDK2VwAyEA8jzU4KuMjBgESW8u9aX5coT+KtfpcGWwAoRixNrjem4=",
            "sign": "y3RwfXf1OVzH3GJkIicRhdAev6N8NxSVniMf6/hLQ25TUBkBezig0Q8/IWVR8DWbfg2HqPCw0DpaIA4BHmJpDw==",
            "signaddr": "0x9Ed0009A37D251706c4f14a85f755eabaCE99Ae9"
          },
          {
            "pub": "MCowBQYDK2VwAyEAfuNxn5WIsxqDXkc57Vl2ZFsbAv50UEKMkzeP2Po1udU=",
            "sign": "BSx8AoB99luZEMPQtsVWDCBgo1JsxHh4cw1cVf91OBITpJWLHos7iYKZ2PTp1ZFbtF+98s1mrDq8UtH4E30pCA==",
            "signaddr": "0xd27384462Bfe9d37c8e27b732c2aBbcA99B2026f"
          },
          {
            "pub": "MCowBQYDK2VwAyEAIyogP9HbFhQLJPXWTJvr7oacfOj7V7jbwr+tWuLUpeo=",
            "sign": "oZSfjyABTAmYMs8JDeH9BGcsxQ3ih9VnDSgyj4LTYIWw+wtoQS6lWW01Hh4r3E3NCicwGaYHeOtVa0S65Kr6AQ==",
            "signaddr": "0x066F1A3f2E6C25a21B1a8B342E8CEA91Df585835"
          },
          {
            "pub": "MCowBQYDK2VwAyEAKblncGE2av+phdWRpUGHta3wagpb+xMdnZ3HBy1sTsM=",
            "sign": "hHw9F2rO+LwXRYsLOUk4MAidRp0esVEU+iRuOSIjvods6Df37yscTOmqj5xsTPB2FBbT2jknObpceaUrdRv+Aw==",
            "signaddr": "0x3aeeFE155376a47E63bB93fE4e95e67aF42B68eC"
          },
          {
            "pub": "MCowBQYDK2VwAyEANI0XsAkIjo1T9QSBucwrNMklWOohtZccqub4OWUNrWU=",
            "sign": "g0+kMIf5ekUL4imH/A0XeOLQxHoQuVzRVfoBSotNlYx1KgcARhUNVXx7ysxrh27lif1wTG0RwCNliISFEsJfAA==",
            "signaddr": "0x5F4c7cFD9B2095c947B9be84F6A57D08e44eF791"
          },
          {
            "pub": "MCowBQYDK2VwAyEAbALWvBTB+PQv2StB5NEYON6WVj1eYwHxGfI0G/UFFmk=",
            "sign": "zcw8ob5dNOBV8InDEe1xkcJc5CnxZJYEwBNfHsbFUYi7/RYhmA4AO8SwFRAavc6i36TEJ3FhkKAERSwK8C+mCQ==",
            "signaddr": "0x277Ff39E8176A582A392265ca619bdb6477674a5"
          }
        ],
        "bytes": 1765,
        "data": null,
        "hash": "0xb51f9199b387ce0b45c847c85f86fa3db3eb5e15b50b4a267dd9f582cd4bc256",
        "height": 65,
        "merkleroot": "0xbfc73f1c66c7c552cbdb3d02cc1c434b1efaf35fd3916350b5d8a38f92c96fc7",
        "prevhash": "0xb03385ae8fce992887c56f38966636a7e31cc273b599a2e4197a31878a7fcaf5",
        "time": 1724827704568873
      },
      "tx": [
        {
          "Consensus": 7,
          "GasTx": 0,
          "Type": "Tx",
          "data": {
            "TxInfo": {
              "LockAmount": 100000000000,
              "LockType": "LockNet"
            }
          },
          "identity": "0x85240c8dF5011d5967FA4566D3e2Ad5575A51856",
          "info": "",
          "time": 1724827704568873,
          "txHash": "0xbfc73f1c66c7c552cbdb3d02cc1c434b1efaf35fd3916350b5d8a38f92c96fc7",
          "txType": 9,
          "utxo": [
            {
              "assetType": "X",
              "gasutxo": 0,
              "multisign": [
                {
                  "pub": "xIVI+gfNGHAVrISn879D49+XV3HKT8kaHk7VnlAilvuQF67GYAeXqEoLapIjP0TBTcpsDHmZTqQUzjXVnJu0BQ==",
                  "sign": "xIVI+gfNGHAVrISn879D49+XV3HKT8kaHk7VnlAilvuQF67GYAeXqEoLapIjP0TBTcpsDHmZTqQUzjXVnJu0BQ=="
                }
              ],
              "owner": [
                "0xffFd42e045737b11570B7981c2648ea532a10B23"
              ],
              "vin": {
                "prevout": {
                  "hash": [
                    "0x36b19c533a49ec05a06be9c99c4e1c2e1609f9679aa75989c8ae0999ca63562a"
                  ]
                },
                "vinsign": [
                  {
                    "pub": "MCowBQYDK2VwAyEAnVwyI7Xwk4lVNwi4j7ogCoHyy40isQmMumbM58JKTTU=",
                    "sign": "jXugdh1gM05AT73xU5WYP6THqX7ghdi4heKe04XjdsJQ/QhR6DxwkA5SLUO//lFswiiWFMf6gf697uVewJ4MAw=="
                  }
                ]
              },
              "vout": [
                {
                  "addr": "LockVirtualStake",
                  "value": 100000000000
                },
                {
                  "addr": "0xffFd42e045737b11570B7981c2648ea532a10B23",
                  "value": 9759599999665600
                },
                {
                  "addr": "VirtualBurnGas",
                  "value": 26100
                }
              ]
            }
          ],
          "verifySign": [
            {
              "pub": "MCowBQYDK2VwAyEACE2DupNwSIpn854yGLj7QF/YHd6eAeLOhHYObzcbCTM=",
              "sign": "NTJntLI0ILj7hPFP1n5xmRj1eAOUKxEqec8cXLxGjjhJ74r8Qqn7fIwIsDbuQI8BGCD/D1Ikp9muLq/1eMACCw==",
              "signaddr": "0x85240c8dF5011d5967FA4566D3e2Ad5575A51856"
            }
          ]
        }
      ]
    },
    "code": 0,
    "message": "success"
  }
}
```

### GetBlockByHeight

**说明**：

根据块高度获取块信息

**参数**：

* id 透传信息
* jsonrpc  json版本
* params 参数
  * beginHeight 起始块高度
  * endHeight 结束块高度
  * 当 endHeight > top 时 endHeight = top，beginHeight 和 endHeight 之差最大为100

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  * code 返回值
    * 0	success
    * -1   Block height error, beginHeight < endHeight
    * -2   The height of the request does not exceed 100
    * -3    Database abnormal, Get block hashes by block height error
    * -4    Database abnormal, Get block by block hash error
    * -5    Database abnormal, Get block top error
  * message 调用信息
  * blocks 块信息（详细信息见块信息描述）

例子

```json
//req
{
  "id":"1",
  "jsonrpc":"2.0",
  "params":{"beginHeight":"10", "endHeight":"20"}
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetBlockByHeight",
  "result": {
    "blocks": [
      {
        "block": {
          "blocksign": [
            {
              "pub": "MCowBQYDK2VwAyEAJPmMLCjSAjBx9GY2JAtmsSR9IuSDI1lN1m4yhUvxOEM=",
              "sign": "+3RAHn0u6TGjDYavjS/Td+mtTzctxyCi9z+0tLkqYenmJ8XWmTjb1QeYpF5hsqYL9Q9JRl/xNeZHyweK89arDA==",
              "signaddr": "0xE8a1A99432658958B6F3065977fe39192d91ecF6"
            },
            {
              "pub": "MCowBQYDK2VwAyEAbALWvBTB+PQv2StB5NEYON6WVj1eYwHxGfI0G/UFFmk=",
              "sign": "k4s5ucxeFUutQhOdos6zGlIkbW5HHg294aHPnfBzFMTpcv0hiDvcdREICjol1JjdZy9CQkQugDGjFeDrtA7VCQ==",
              "signaddr": "0x277Ff39E8176A582A392265ca619bdb6477674a5"
            },
            {
              "pub": "MCowBQYDK2VwAyEA6zMDRvZ82ObZCpVFw2+47ejYrLquImR1oI3skXZRtiY=",
              "sign": "JW+A2V0wbdmX5ZXnFE37fDMTLcFwKg8tLU8nI2Cz6FMm37zNhbarloPws41Mavw+ms5KC93h4x/CHAKrAyVTCw==",
              "signaddr": "0xCe3efA4FE6b044FB985736C62ABFDF435CC9AfCF"
            },
            {
              "pub": "MCowBQYDK2VwAyEA6Q6C8O9jkTtbPEHYnwIyBsx85/DEVnq640FmXXniTlE=",
              "sign": "2tCSQk+OHaWZXJ/Px9ql8id21a9pW6h6+/K4QZRfWYmaOBCpVK7AMhfcOmLN/P8AdrcYGSwfBDxWO+ryB0CUDA==",
              "signaddr": "0x690e0814a282f02Db36078f2B794777595bEDe89"
            },
            {
              "pub": "MCowBQYDK2VwAyEAgNYIcBwelxAzk/0Y2zHKIouw/Hgp7PyezmODMynlPtA=",
              "sign": "wd16hITmuuSYBa2yUoXnX9p5j9WkFQhZCPclL+dh2Fmreb0tOwx4N/rJ1OzT8a4c/zpWaxef3x/zVrLEiFEjAw==",
              "signaddr": "0xD9ECEec8420a0c053b70511f5f150EbD44358F3d"
            },
            {
              "pub": "MCowBQYDK2VwAyEAjV7zlpaeW3frrfwVoJgRZ+t2afDrVcWJnJtbOOvjX4k=",
              "sign": "nMEGg/v7rVNaRJur6dtNfMi30/rsEtygadHa4h0c92vZoa6uPiV+vko6haA8s4fo9h3/Zx9TLqdKwLe7fUPTCg==",
              "signaddr": "0x7E6A499159814eB3e3b1139afA2a7E4C9E883cce"
            },
            {
              "pub": "MCowBQYDK2VwAyEAfmL01bATzcX8LbZPBQ4haaWHfcNqaNnlVrsnk8+LTJI=",
              "sign": "YgOyUQx2LVSmEQrZgVF4t4weOUS7xMWmc9QHRqnrGzUYuEvJX/JBJLtxIBJKqjdKYOB1Sg0h6a5tHKL93rJ9DA==",
              "signaddr": "0xcaB8d5526b63BaF381Bc7a64eAF8690D16011BC4"
            }
          ],
          "bytes": 1932,
          "data": null,
          "hash": "0xbd804875a98343ad652ce7ad2252c06bbaa50410c156a588d0b4b43a7a8a4360",
          "height": 10,
          "merkleroot": "0x311fa442700603cacb38018e0ce7f1f43224879905c5ea80aabd236267fc9451",
          "prevhash": "0x02c305a51b1a9201ed5a68513fe8bcd83f29f87ac452b3c708e0984e32c237b0",
          "time": 1724814849728314
        },
        "tx": [
          {
            "Consensus": 7,
            "GasTx": 0,
            "Type": "Tx",
            "identity": "0xE8a1A99432658958B6F3065977fe39192d91ecF6",
            "info": "",
            "time": 1724814849728314,
            "txHash": "0x311fa442700603cacb38018e0ce7f1f43224879905c5ea80aabd236267fc9451",
            "txType": 1,
            "utxo": [
              {
                "assetType":"5e7c785de771a3130587872bc4381b15c1b2d38a6c101796c67535af5c5471f0",
                "gasutxo": 0,
                "multisign": [
                  {
                    "pub": "wmgFvHyr83tY0QO6Zg4kf/7JTLL3aKwSL8mxmulD4uerOnigthuyye6AuYOF7CgVQhl64Gg36PbTfd9W7QSHCw==",
                    "sign": "wmgFvHyr83tY0QO6Zg4kf/7JTLL3aKwSL8mxmulD4uerOnigthuyye6AuYOF7CgVQhl64Gg36PbTfd9W7QSHCw=="
                  }
                ],
                "owner": [
                  "0xffFd42e045737b11570B7981c2648ea532a10B23"
                ],
                "vin": {
                  "prevout": {
                    "hash": [
                      "0x54b87606b3ae037ecd5d76cd5e496bc489ad602931ec5f6a7722e93c91e96e5c"
                    ]
                  },
                  "vinsign": [
                    {
                      "pub": "MCowBQYDK2VwAyEAnVwyI7Xwk4lVNwi4j7ogCoHyy40isQmMumbM58JKTTU=",
                      "sign": "19Mh06xHGee+J3lZFxLVL3k3xlEzGP4c8dfPxbsgaUCP/0jQodfxkeK8q8D2GkFA64ApYQT/qg3Fy9Igvc59Dw=="
                    }
                  ]
                },
                "vout": [
                  {
                    "addr": "0x690e0814a282f02Db36078f2B794777595bEDe89",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0x746CADE61c69a2af24CEf4928a523E616c84b36E",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0x79bb919D80AccbF3b7a62E5E2E841B2837B6D882",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0x7E6A499159814eB3e3b1139afA2a7E4C9E883cce",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0x7f3928315606DA72868848f1F0f6154461F1cBA2",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0xffFd42e045737b11570B7981c2648ea532a10B23",
                    "value": 9981999999898600
                  },
                  {
                    "addr": "VirtualBurnGas",
                    "value": 33800
                  }
                ]
              }
            ],
            "verifySign": [
              {
                "pub": "MCowBQYDK2VwAyEAJPmMLCjSAjBx9GY2JAtmsSR9IuSDI1lN1m4yhUvxOEM=",
                "sign": "8nvcAC6dWFfZIOswHpTWj2cw7/dsZ/BWd16PtIhRH1+GT4R1TGpI3Y+LZ0xg1u/vLGiiYtQhL/dY167A8KtPDw==",
                "signaddr": "0xE8a1A99432658958B6F3065977fe39192d91ecF6"
              }
            ]
          }
        ]
      },
      {
        "block": {
          "blocksign": [
            {
              "pub": "MCowBQYDK2VwAyEAlCT0eYlIC0N086DOdxf1JV4KIAdrMPk9edmgVSvFtEs=",
              "sign": "PbEvCF/iZqbcaHWC4kT7cyvTxnVNCTV9D7c0IBcssDil1u6g3wd7KRMZuiCmW4FMOeU1KepWYLlrMNY9V0G6CA==",
              "signaddr": "0x00380ecf01085A4D877B9C83Bf7da715661057a5"
            },
            {
              "pub": "MCowBQYDK2VwAyEAVlvNx7mZLV1Nz/YnT+bhALXC/GR7XN7su3/izWBWhx8=",
              "sign": "I1ZAC0ozRItpy101deuPHqcCpkh9w8sSoC3yOXSGcQvbNg3ygWEurC3JGV85HCvh7Soixtt9JG37jTYLA8wpBg==",
              "signaddr": "0xE68A90e2af411b20a9CF421adF6531AaEfD404F8"
            },
            {
              "pub": "MCowBQYDK2VwAyEA6zMDRvZ82ObZCpVFw2+47ejYrLquImR1oI3skXZRtiY=",
              "sign": "LK7aRfFshdFhCq+f6B3mB7cnKM9+GdxSNUVO72pg3qwvnZgHjyY69EmOCRYl4n7jTsou9DK/dRo0P9S6XDNDCw==",
              "signaddr": "0xCe3efA4FE6b044FB985736C62ABFDF435CC9AfCF"
            },
            {
              "pub": "MCowBQYDK2VwAyEA2F7rPz4YMNeQl5Gx4mAFM/+23eg2C0O8mHYf6FdtuR0=",
              "sign": "FEEgsOGBtctp05OL5O9Yyti1QGbbzQ5oNEwDOLW4H0ANATlc5t7ARqKLeO84mPO84sXZT4rtD8GRUXr2JzYpBQ==",
              "signaddr": "0x82b79db0f26524f34c67e736a7BB0611Db702930"
            },
            {
              "pub": "MCowBQYDK2VwAyEAJPmMLCjSAjBx9GY2JAtmsSR9IuSDI1lN1m4yhUvxOEM=",
              "sign": "QQWAfuXu7qYMYOA+/v5ZuLRiASjWG+rCZPK+b7M6oR86XJlkX7AowjIpMoU3VKcrj40H34VtEekvAscvIb2mCg==",
              "signaddr": "0xE8a1A99432658958B6F3065977fe39192d91ecF6"
            },
            {
              "pub": "MCowBQYDK2VwAyEAiQR7rUhgYA1Eb1YXJJXLRSVaX/46aYvYilNidVD3DDs=",
              "sign": "Ndgb/dqyBEUESrORxJDPOEEFKYP3I7gJ6FPec+Ock0psSWhquNie5NyNV+IGp+6bCOC7hIIuQFUMhwWVZJ3rCA==",
              "signaddr": "0xC2ee63B5169D2cdbc1BBB5CfC1f15051A8549B5e"
            },
            {
              "pub": "MCowBQYDK2VwAyEA6Q6C8O9jkTtbPEHYnwIyBsx85/DEVnq640FmXXniTlE=",
              "sign": "L0r36sdK9V/LGl3qvOVzuF5Ae/FIKms93Bbkzi2tVDmU9NUHM81AMmQiP2xvYcF9Qr7Se3HHIrgh/qseDmJhBA==",
              "signaddr": "0x690e0814a282f02Db36078f2B794777595bEDe89"
            }
          ],
          "bytes": 1932,
          "data": null,
          "hash": "0x6124e62c2d36c3cb63f2fdd9d07bb7de8b989ee1079680fdcf35bd65bd307825",
          "height": 11,
          "merkleroot": "0xc844ffc0f4cd2e8c3d64c875ce709340b856eabb3baa61ef85db6614ed53abb0",
          "prevhash": "0xbd804875a98343ad652ce7ad2252c06bbaa50410c156a588d0b4b43a7a8a4360",
          "time": 1724814857464488
        },
        "tx": [
          {
            "Consensus": 7,
            "GasTx": 0,
            "Type": "Tx",
            "identity": "0x00380ecf01085A4D877B9C83Bf7da715661057a5",
            "info": "",
            "time": 1724814857464488,
            "txHash": "0xc844ffc0f4cd2e8c3d64c875ce709340b856eabb3baa61ef85db6614ed53abb0",
            "txType": 1,
            "utxo": [
              {
                "assetType": "0x416ba3e59614072c3bbdfb4f194fe71d248a7d82b1727f2d4ca51f8b4aba1528",
                "gasutxo": 0,
                "multisign": [
                  {
                    "pub": "xb2RNPl3GJ3nfr8Fsthl7jKaCBEPwYn/hz9aFOSQwuhNl/XVm45YI31btHFBSnM3scLCnn73nCUOIF3WD4jwCg==",
                    "sign": "xb2RNPl3GJ3nfr8Fsthl7jKaCBEPwYn/hz9aFOSQwuhNl/XVm45YI31btHFBSnM3scLCnn73nCUOIF3WD4jwCg=="
                  }
                ],
                "owner": [
                  "0xffFd42e045737b11570B7981c2648ea532a10B23"
                ],
                "vin": {
                  "prevout": {
                    "hash": [
                      "0x9258ed48fc0e4d63d1e99ce7d6dea5cad80dd273a32bef2b4ddfc4031b1ddcf3"
                    ]
                  },
                  "vinsign": [
                    {
                      "pub": "MCowBQYDK2VwAyEAnVwyI7Xwk4lVNwi4j7ogCoHyy40isQmMumbM58JKTTU=",
                      "sign": "BcCAUie3/f4pR9qC/qAGZ1oQeqG3U75MLiPmgp/eCGT4IN46a/Ca2X7IjeiGI6hyK2H7/X12z3LPgd6dE+SrDw=="
                    }
                  ]
                },
                "vout": [
                  {
                    "addr": "0x690e0814a282f02Db36078f2B794777595bEDe89",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0x746CADE61c69a2af24CEf4928a523E616c84b36E",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0x79bb919D80AccbF3b7a62E5E2E841B2837B6D882",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0x7E6A499159814eB3e3b1139afA2a7E4C9E883cce",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0x7f3928315606DA72868848f1F0f6154461F1cBA2",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0xffFd42e045737b11570B7981c2648ea532a10B23",
                    "value": 9981999999898600
                  },
                  {
                    "addr": "VirtualBurnGas",
                    "value": 33800
                  }
                ]
              }
            ],
            "verifySign": [
              {
                "pub": "MCowBQYDK2VwAyEAlCT0eYlIC0N086DOdxf1JV4KIAdrMPk9edmgVSvFtEs=",
                "sign": "NB+Z095i7ctP7kwjtBPmqkH3e4T6tFMW8xXiMyCfpF6zlAVZfxxrxqleZHeDvwzYkKXxcC96d1ZFiOQIR+PYBg==",
                "signaddr": "0x00380ecf01085A4D877B9C83Bf7da715661057a5"
              }
            ]
          }
        ]
      },
      {
        "block": {
          "blocksign": [
            {
              "pub": "MCowBQYDK2VwAyEAKblncGE2av+phdWRpUGHta3wagpb+xMdnZ3HBy1sTsM=",
              "sign": "oic8leQoCg5SCde5THO0InvNJMyprZiADPG9BJTi69tnzHkgVXAhwwVtY+i8PZBOE/+vzY3/3GImVQM/ByHNDA==",
              "signaddr": "0x3aeeFE155376a47E63bB93fE4e95e67aF42B68eC"
            },
            {
              "pub": "MCowBQYDK2VwAyEADD94/vLoo/SLRuWomnmvignrER/7wX+HDCoBMCXT9hM=",
              "sign": "LynnYAA1IHGl6VDsWXvxFEnWZ5ukDo1E2n5RbIiNEvWSj7TPfWQRcON/A3dCZFmxVTxDsL8TDWzoPhczM0CmCw==",
              "signaddr": "0x746CADE61c69a2af24CEf4928a523E616c84b36E"
            },
            {
              "pub": "MCowBQYDK2VwAyEACE2DupNwSIpn854yGLj7QF/YHd6eAeLOhHYObzcbCTM=",
              "sign": "vdEDCb2crS/0NMmAmFCHxrWcu1sqjthfWmqhVTZIoIFwnyuqpBMh3UOnsTKnCA6e4edgWq1k953bOy7Dw/QbBQ==",
              "signaddr": "0x85240c8dF5011d5967FA4566D3e2Ad5575A51856"
            },
            {
              "pub": "MCowBQYDK2VwAyEAw+WS2EacRYHJfOulc7OGvkR2LN/im1BrepT51IM/l74=",
              "sign": "cZmtNiDHWFWUKZcAJchxdrrqSSHa745kQk5pCdxwnuecLzlaVDje3XZLjd2c+gw6TapZCSmoRCeodhwcujagAw==",
              "signaddr": "0x8DABa2e48009a713B419bD31051f5708fEd2672E"
            },
            {
              "pub": "MCowBQYDK2VwAyEATcB9j/WO1+oUQdrk0iD3BkcnbgQQS/dCxDgAkfMGIGo=",
              "sign": "FyZIobk1azEBiQLt2c/d3G2RQDl4UZdOlfs4okmQoi9lEk3gk/ZHhhWy1gl2pIdnOkKv/5aAwCVYI7OamZmPCg==",
              "signaddr": "0x22618D827b657C3A3Aa322CEa63275cD9cf5620B"
            },
            {
              "pub": "MCowBQYDK2VwAyEAIyogP9HbFhQLJPXWTJvr7oacfOj7V7jbwr+tWuLUpeo=",
              "sign": "hv9Afdacp4hQKjItMn6dT9Jn/3wkiqSr1e1iKwO7OtclsbvoeI60eIhSSn8ERurx7hx0fEfl3FRpGsXE0lIDDg==",
              "signaddr": "0x066F1A3f2E6C25a21B1a8B342E8CEA91Df585835"
            },
            {
              "pub": "MCowBQYDK2VwAyEAJPmMLCjSAjBx9GY2JAtmsSR9IuSDI1lN1m4yhUvxOEM=",
              "sign": "UWP62p8zleLgoEvAs8jHZu+yRt03LJaDRXUX8YsRIrmvNmrFm3Qg+gfZ2MOZGnJWGK4/d6F4+3YfL/5Y+i9hCQ==",
              "signaddr": "0xE8a1A99432658958B6F3065977fe39192d91ecF6"
            }
          ],
          "bytes": 1932,
          "data": null,
          "hash": "0x8cc1071fd61c9992fb0897739c8ae464e1cf404f8046682b17a2600d7e36152a",
          "height": 12,
          "merkleroot": "0x6c472a4c621f481941abae6a60db7bfdc0406ebbd0c21a13b1e6cfba59ff73e1",
          "prevhash": "0x6124e62c2d36c3cb63f2fdd9d07bb7de8b989ee1079680fdcf35bd65bd307825",
          "time": 1724814882100984
        },
        "tx": [
          {
            "Consensus": 7,
            "GasTx": 0,
            "Type": "Tx",
            "identity": "0x3aeeFE155376a47E63bB93fE4e95e67aF42B68eC",
            "info": "",
            "time": 1724814882100984,
            "txHash": "0x6c472a4c621f481941abae6a60db7bfdc0406ebbd0c21a13b1e6cfba59ff73e1",
            "txType": 1,
            "utxo": [
              {
                "assetType": "X",
                "gasutxo": 0,
                "multisign": [
                  {
                    "pub": "Iuh2bSBKrarIbz3rbiuW1VIP9W7p9tk7QOsGcvIhkKW0aELqWE0nqk8jWv9YaT//PXPRhKDhpR/v2YCn1YmjCA==",
                    "sign": "Iuh2bSBKrarIbz3rbiuW1VIP9W7p9tk7QOsGcvIhkKW0aELqWE0nqk8jWv9YaT//PXPRhKDhpR/v2YCn1YmjCA=="
                  }
                ],
                "owner": [
                  "0xffFd42e045737b11570B7981c2648ea532a10B23"
                ],
                "vin": {
                  "prevout": {
                    "hash": [
                      "0x0006ac2efc60edeb71f12c720b9dde07841bdbb2930a22f6f9d5ad64f76138cc"
                    ]
                  },
                  "vinsign": [
                    {
                      "pub": "MCowBQYDK2VwAyEAnVwyI7Xwk4lVNwi4j7ogCoHyy40isQmMumbM58JKTTU=",
                      "sign": "5Bec0R/u/KZDnSmyxBH5RoDxKKiEdtf2hL1fGeFIvg0vs1sBmXKIALu08Gx2eoDKQO+wp4PLxJDVNMSO4f+tDw=="
                    }
                  ]
                },
                "vout": [
                  {
                    "addr": "0x82b79db0f26524f34c67e736a7BB0611Db702930",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0x85240c8dF5011d5967FA4566D3e2Ad5575A51856",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0x8897DE435e9276a0683ADBb4E62d6C9DdCd261DE",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0x8DABa2e48009a713B419bD31051f5708fEd2672E",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0x9Ed0009A37D251706c4f14a85f755eabaCE99Ae9",
                    "value": 1200000000000
                  },
                  {
                    "addr": "0xffFd42e045737b11570B7981c2648ea532a10B23",
                    "value": 9974899999803900
                  },
                  {
                    "addr": "VirtualBurnGas",
                    "value": 33800
                  }
                ]
              }
            ],
            "verifySign": [
              {
                "pub": "MCowBQYDK2VwAyEAKblncGE2av+phdWRpUGHta3wagpb+xMdnZ3HBy1sTsM=",
                "sign": "1OX7Nhecxr23Hnsyb+nwlXMwRSnDer3nLp3hTTPqrAbClzs6uFqHDLr7dHLdPhc/sfEonnerlTLYSvwvh2kyAA==",
                "signaddr": "0x3aeeFE155376a47E63bB93fE4e95e67aF42B68eC"
              }
            ]
          }
        ]
      }
    ],
    "code": 0,
    "message": "success"
  }
}
```

### ConfirmTransaction

确认交易是否上链

**参数**

- txhash 交易哈希
- 交易高度

**返回值**：

- code 返回值编号
  - 0 success
  - -1 Nodelist size is empty
  - -2 filterHeightNodeList size is empty
  - -3 CreateWait error
  - -4 AddResNode error
  - -5 WaitData error
  - -6 susSize node list is empty
  - -7 The amount received was too small to verify transaction on-chain
  - -8 tx Parse error

- message 返回值信息
- tx 交易体信息
- percent 上链率
- sendsize 请求节点的个数
- receivedsize 接受回复的个数

```json
{
  "id":"1",
  "jsonrpc":"2.0",
  "params":{
      "txhash":"64e91e7fa9ce873a1891806ae1adcc0af98d38ff78660c8408ad9caa81c67495",
      "height": "500"
    }
}
```

```json
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "ConfirmTransaction",
  "result": {
    "code": 0,
    "message": "success",
    "percent": "1.000000",
    "receivedsize": "27",
    "sendsize": "34",
    "tx": {
      "Consensus": 7,
      "Type": "Tx",
      "data": {
        "TxInfo": {
          "BonusAddr": "0xFFFc74b51BC5e75527fE5970D04355958dd3657C",
          "delegateAmount": 1000000000000,
          "delegateType": "Normal"
        }
      },
      "identity": "0x0796B6DB27e5eb1e9F8Bd2c4d03191C902D22F0f",
      "time": 1716775934685374,
      "txHash": "0x64e91e7fa9ce873a1891806ae1adcc0af98d38ff78660c8408ad9caa81c67495",
      "txType": 4,
      "utxo": {
        "multisign": [
          {
            "pub": "Hv7Z7SrYgnK9WGI0qZJJkCcDBVG5mYZlAN2fe0RsdEEIY3i9iAbRK+JtT+hxrv1+pWJeR3IdT/81Mx6TlAkkAg==",
            "sign": "Hv7Z7SrYgnK9WGI0qZJJkCcDBVG5mYZlAN2fe0RsdEEIY3i9iAbRK+JtT+hxrv1+pWJeR3IdT/81Mx6TlAkkAg=="
          }
        ],
        "owner": [
          "0xFFFc74b51BC5e75527fE5970D04355958dd3657C"
        ],
        "vin": {
          "prevout": {
            "hash": [
              "0x7dd57386b958cb7ad02170bd5c190e369c1694f596d524d2b2bfa5e1a55c253b"
            ]
          },
          "vinsign": [
            {
              "pub": "MCowBQYDK2VwAyEA+X/pIfbC/gTA+iuG5yoLn6AH90PFdko5gWfURmCYC90=",
              "sign": "eArBhLH2J24CjgE6SnPMV1/p+5Uqyuh2QwCwD7ldeqpJ63hPpcQ0n9CiNXh8CNPeKJNufduL1WjfDvqHymiZBA=="
            }
          ]
        },
        "vout": [
          {
            "addr": "VirtualDelegating",
            "value": 1000000000000
          },
          {
            "addr": "0xFFFc74b51BC5e75527fE5970D04355958dd3657C",
            "value": 6998899999939100
          },
          {
            "addr": "VirtualBurnGas",
            "value": 32400
          }
        ]
      },
      "verifySign": [
        {
          "pub": "MCowBQYDK2VwAyEAHDoLfSX+ygmvSICr/1Q/UnfLlPFkAQBB4oPZne/SoVo=",
          "sign": "bCoIyAR1qH5LDHpX5Y5E5OqZogQo0EDDPnihTaPDHV5jQdT9AEadCo/+uhRMOi7l9XlwxhrCcxesnfJDXbQmCg==",
          "signaddr": "0x0796B6DB27e5eb1e9F8Bd2c4d03191C902D22F0f"
        },
        {
          "pub": "MCowBQYDK2VwAyEABK13LqOyxq7skjywUZwpTTLVXU3yPMSClL0u9xI5+hg=",
          "sign": "",
          "signaddr": "0x2eb2F635320c3Dbf29eadD35E894c13EE3F20bd5"
        },
        {
          "pub": "MCowBQYDK2VwAyEANFAhkjOUKAp0RbqjjiDetKQjcwQTXLRpL0Vh7uz3Sm0=",
          "sign": "",
          "signaddr": "0x3b5AF36c2F269c4eA5ADffd12d65818A9cd94Dc2"
        },
        {
          "pub": "MCowBQYDK2VwAyEAl0V//ZTw/56RkIUtrEzyXIbPm0nQ+XjB2QEDZR+KbT4=",
          "sign": "",
          "signaddr": "0x3CA9403151e5E7ad6072c9CF29237A3BB61eFaF3"
        },
        {
          "pub": "MCowBQYDK2VwAyEAtLhQrLNMMCWqjBzgy3cf/eRC7ypLgZgg7inzrFP4vyY=",
          "sign": "",
          "signaddr": "0x0a887Ad7a0a383e8fF9E1CB2433712e53C26AF95"
        },
        {
          "pub": "MCowBQYDK2VwAyEAr8qDQ8MYYxD26OVtzmLshwDH44rbtFcxp+n7YMsvit8=",
          "sign": "",
          "signaddr": "0x3812aE1f4a85A937340e882e4285f2CdaaCbC21F"
        },
        {
          "pub": "MCowBQYDK2VwAyEACPZP4VDg6AE4zXC3GN0et49O0wxAQ5bNfgqDulRc+vk=",
          "sign": "",
          "signaddr": "0x244125ddD7A63479F3A5DA8bC36682EdaFfdc92d"
        },
        {
          "pub": "MCowBQYDK2VwAyEAdTGsapuDIoqcgqXHYKJgNPuTkwhZ6EYGi9ORPXV7krQ=",
          "sign": "",
          "signaddr": "0xca3B60adeEf20337427b0d4Fa6E62920ea81a855"
        },
        {
          "pub": "MCowBQYDK2VwAyEAh6RFUhVdsoE3MehHfFNlj4tWgyzLo+8F6SIPbW7zIYw=",
          "sign": "",
          "signaddr": "0x28bA6E30cB0d9372a18c80552eE11DFe47883FAd"
        },
        {
          "pub": "MCowBQYDK2VwAyEAZVRP0epGewUhFeh7p6tvzX3Rhn4BSB/7Exjqr8hW5yk=",
          "sign": "",
          "signaddr": "0xd57730E2CE30d412cea04689C9cDE2f0846df169"
        },
        {
          "pub": "MCowBQYDK2VwAyEANkIfPzXigAr1hfIIh4qaJ7bG0jrC7a5F1FUR39kBnoE=",
          "sign": "",
          "signaddr": "0x08C08F389c8255c0B4d1C5e337C811D02F220B6e"
        },
        {
          "pub": "MCowBQYDK2VwAyEAQ05ytVs7kiZxfN2f6PUT9XpjfASpuMxoDNTJkzmimew=",
          "sign": "",
          "signaddr": "0xbBE3F8cf409A4554AC4dC3307B0198967E68258F"
        },
        {
          "pub": "MCowBQYDK2VwAyEAE9q3hlengBKro4iPMtj+F3RGyoJ7DdyToMzBSFvv2f8=",
          "sign": "",
          "signaddr": "0x1A2a22101480Cd3c0f966e0399cc5f4150B0EbF7"
        }
      ]
    },
    "txhash": "0x64e91e7fa9ce873a1891806ae1adcc0af98d38ff78660c8408ad9caa81c67495"
  }
}
```

### GetAllStakeNodeList

获取质押节点列表

**参数**

- 无

**返回值**

- code 返回值编号
  - 0 success
  - -1 peerlist is empty

- message 返回值信息
- version 版本
- list 质押列表
- addr 地址
- ip 节点ip地址
- identity 账号公钥
- logo 节点logo
- name 节点name 

```json
{
  "id":"1",
  "jsonrpc":"2.0",
  "params":{}
}
```

```json
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetAllStakeNodeList",
  "result": {
    "code": 0,
    "list": {
      "list": [
        {
          "addr": "0x01921896D8AAC12B19BC8413135907AB5aE82326",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAnkb8f/5s/LsQXNlU7/SDXR2sPf8IZZrbZ9v2HmYJffk=",
          "ip": "192.168.1.86",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x0796B6DB27e5eb1e9F8Bd2c4d03191C902D22F0f",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAHDoLfSX+ygmvSICr/1Q/UnfLlPFkAQBB4oPZne/SoVo=",
          "ip": "192.168.1.118",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x08C08F389c8255c0B4d1C5e337C811D02F220B6e",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEANkIfPzXigAr1hfIIh4qaJ7bG0jrC7a5F1FUR39kBnoE=",
          "ip": "192.168.1.99",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x0a887Ad7a0a383e8fF9E1CB2433712e53C26AF95",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAtLhQrLNMMCWqjBzgy3cf/eRC7ypLgZgg7inzrFP4vyY=",
          "ip": "192.168.1.95",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x0aFeBC02da4d5111d05d425e74e822B032274f2b",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAd2sNbj9c8IKcU8zzC2qWrGkwwFkZSQTtkvrgkxCzpTE=",
          "ip": "192.168.1.100",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x1A2a22101480Cd3c0f966e0399cc5f4150B0EbF7",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAE9q3hlengBKro4iPMtj+F3RGyoJ7DdyToMzBSFvv2f8=",
          "ip": "192.168.1.104",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x1CD6855FB33190754b122f8aBad737791BaB3F0a",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAF/4cPYBHTbG05HVOwUSmM/0wWPdrf7UbB1VO2ZfDuK0=",
          "ip": "192.168.1.61",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x244125ddD7A63479F3A5DA8bC36682EdaFfdc92d",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEACPZP4VDg6AE4zXC3GN0et49O0wxAQ5bNfgqDulRc+vk=",
          "ip": "192.168.1.102",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x28bA6E30cB0d9372a18c80552eE11DFe47883FAd",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAh6RFUhVdsoE3MehHfFNlj4tWgyzLo+8F6SIPbW7zIYw=",
          "ip": "192.168.1.116",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x2eb2F635320c3Dbf29eadD35E894c13EE3F20bd5",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEABK13LqOyxq7skjywUZwpTTLVXU3yPMSClL0u9xI5+hg=",
          "ip": "192.168.1.103",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x3292FEAbea61A76cf59Fa917b9DCcC937Ca489eE",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAz7Y+YE+zTAZO26NcyvbWFpwPOYS18kyofL9pitE73G0=",
          "ip": "192.168.1.117",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x372b320ECA35F86A28249E3e309545A44270DD7D",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAJJnp6slecl6UN0fjGiWya9a37N0iwUW1gQBS3Sh0qvU=",
          "ip": "192.168.1.101",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x3812aE1f4a85A937340e882e4285f2CdaaCbC21F",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAr8qDQ8MYYxD26OVtzmLshwDH44rbtFcxp+n7YMsvit8=",
          "ip": "192.168.1.96",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x3CA9403151e5E7ad6072c9CF29237A3BB61eFaF3",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAl0V//ZTw/56RkIUtrEzyXIbPm0nQ+XjB2QEDZR+KbT4=",
          "ip": "192.168.1.98",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x3b5AF36c2F269c4eA5ADffd12d65818A9cd94Dc2",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEANFAhkjOUKAp0RbqjjiDetKQjcwQTXLRpL0Vh7uz3Sm0=",
          "ip": "192.168.1.119",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x69b34b7538DeB6913f2b9f59Cbc8610059442e5A",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEApiP9nArs1ZDRXH3k89VuRReOlgNufYsF939nC3pBsqg=",
          "ip": "192.168.1.35",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x6a72ad3e9762d67D45a311954CdC6ad4693203a9",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAQjLIZj6+3TH2mSye+RS2HqN5W1+cGSg63ghfEOvBDnc=",
          "ip": "192.168.1.81",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x79c80a68Cc851d9A2aBF16c32eBAaC866C4Fced9",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAawp+8tDyeSREnNHrEaeBs6B9AeclJOlrAkeWMijTPww=",
          "ip": "192.168.1.114",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x855052fa258B463AEAd1E5abD55F2ffbCBb3F022",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAwigpWZg9E0DRbbbNuE4PDHT7MJ9XIH2hh5yADHNa6jw=",
          "ip": "192.168.1.89",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x8C33DF5ca4a4de15B53316dc3db60Ae4A7e09734",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEApakW/x/DvV7BBRmhbQzkxhj7xbS0Xr5JN4tSEigWshA=",
          "ip": "192.168.1.105",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x8F66e288547032026dd1ddFb992ff7eEcD9261f0",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAbA5Gq2olxI11gecRsyYYmaecJN0ht74mB2fLNWb3TcQ=",
          "ip": "192.168.1.115",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x8fFb06c288C30F3e62b31d6c5FD34328A964774a",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAner1iR+SqRLmN0lLWB0+su0Quh0XpNDTmm9PWWODirI=",
          "ip": "192.168.1.111",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x9234e37d86AE7De3Dd0Ac57AF815b54551873504",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAcUcydwF7CSr9bjBiUbd3drV+WMd4yd8xFL7HWGA4FTw=",
          "ip": "192.168.1.113",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x93E70Da36F35934C704ca9f2d2CF5cbc3Cba5988",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEARRkX0aksdpaxlbCExPkiaYaga6T/i2/iJyPGRTTNDm8=",
          "ip": "192.168.1.91",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0xB6AE1C10C5547ed1D6ba50d74cc92214E17b5111",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAkHwtzRc4cHtDid6kE/hqO/h6bPlU+cG5ZigBEwOGD2Y=",
          "ip": "192.168.1.88",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0xD82a5740De434f67b64946ba5939dfECc594Bcc1",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAB13mSe2XJ46JzM6WC3sOh7dh5TlMaDevNUlX7b4tuu8=",
          "ip": "192.168.1.109",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0xE2EBF3781D7eFeCbf242a5510AAb60985E045F17",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAktscT7UBR2sjjapjsIjA00bR5vg3I62vPu1HcXQkzrM=",
          "ip": "192.168.1.108",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0xFFFc74b51BC5e75527fE5970D04355958dd3657C",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEA+X/pIfbC/gTA+iuG5yoLn6AH90PFdko5gWfURmCYC90=",
          "ip": "192.168.1.87",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0xadc2A709EC1413eCcEB4d115E50BD9ebBA35E3Ce",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAYc23TU7Tw6L9QcUXNM6FuS5kEzTTQEfX15dR9+n251Y=",
          "ip": "192.168.1.93",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0xbBE3F8cf409A4554AC4dC3307B0198967E68258F",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAQ05ytVs7kiZxfN2f6PUT9XpjfASpuMxoDNTJkzmimew=",
          "ip": "192.168.1.90",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0xc6C621E6BA9Ad2FA2E81998006e0f4Ff45c34b65",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEALUncL09pHgayYIMkZS+hbq5t61CIHG0juNkcbAo9abE=",
          "ip": "192.168.1.106",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0xca3B60adeEf20337427b0d4Fa6E62920ea81a855",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAdTGsapuDIoqcgqXHYKJgNPuTkwhZ6EYGi9ORPXV7krQ=",
          "ip": "192.168.1.97",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0xd56d950d5a79d7906269f87FEa9d1FE48Cb577E7",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAAXU9Om/NJRE0T7lo3L1b/QMcd6cBmGRW1/Y4jX2xiHQ=",
          "ip": "192.168.1.60",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0xd57730E2CE30d412cea04689C9cDE2f0846df169",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAZVRP0epGewUhFeh7p6tvzX3Rhn4BSB/7Exjqr8hW5yk=",
          "ip": "192.168.1.110",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0xdaAfa89eafe616EEa5Aa219d93bC8b1C0299Cc9E",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEAbrU2gaKp26A8Tmn7S0bMTTBJ5BrnLCv450l6oU+ixZM=",
          "ip": "192.168.1.107",
          "version": "1_1.0.0_d"
        },
        {
          "addr": "0x5c8bf650F93d82A7131C2FeA01Ec2bFB3C61A03B",
          "height": "590",
          "identity": "MCowBQYDK2VwAyEASFAPKN8n+Nqn2RcJX8XCgyx1sveBLZ/f5tn5JpM2Xxs=",
          "ip": "123.121.14.187",
          "version": "1_1.0.0_d"
        }
      ],
      "message": "success",
      "version": "1_1.0.0_d"
    },
    "message": "success"
  }
}
```

### GetBonusInfo

获取节点签名信息

**参数**

- 无

**返回值**

- code
  - 0 success
  - -1 DB get sign addr failed!
- message
- address 节点地址
- count 签名个数
- time 时间

```json
{
  "id":"1",
  "jsonrpc":"2.0",
  "params":{}
}
```

```json
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetBonusInfo",
  "result": {
    "code": 0,
    "info": {
      "addr_count": [
        {
          "address": "0xCA66A76E2a279050EF6b57797ac53199379abB9F",
          "count": 3
        },
        {
          "address": "0xdaAfa89eafe616EEa5Aa219d93bC8b1C0299Cc9E",
          "count": 4
        },
        {
          "address": "0x5c8bf650F93d82A7131C2FeA01Ec2bFB3C61A03B",
          "count": 4
        },
        {
          "address": "0xca3B60adeEf20337427b0d4Fa6E62920ea81a855",
          "count": 2
        },
        {
          "address": "0xadc2A709EC1413eCcEB4d115E50BD9ebBA35E3Ce",
          "count": 3
        },
        {
          "address": "0x0796B6DB27e5eb1e9F8Bd2c4d03191C902D22F0f",
          "count": 4
        },
        {
          "address": "0x8C33DF5ca4a4de15B53316dc3db60Ae4A7e09734",
          "count": 3
        },
        {
          "address": "0x116058AcF188BB96F9Da1317Bd11fD737E4f8Cd2",
          "count": 4
        },
        {
          "address": "0x3812aE1f4a85A937340e882e4285f2CdaaCbC21F",
          "count": 2
        },
        {
          "address": "0x3CA9403151e5E7ad6072c9CF29237A3BB61eFaF3",
          "count": 3
        },
        {
          "address": "0x855052fa258B463AEAd1E5abD55F2ffbCBb3F022",
          "count": 5
        },
        {
          "address": "0x01921896D8AAC12B19BC8413135907AB5aE82326",
          "count": 5
        },
        {
          "address": "0xd57730E2CE30d412cea04689C9cDE2f0846df169",
          "count": 13
        },
        {
          "address": "0x0aFeBC02da4d5111d05d425e74e822B032274f2b",
          "count": 4
        },
        {
          "address": "0xbBE3F8cf409A4554AC4dC3307B0198967E68258F",
          "count": 8
        },
        {
          "address": "0x93E70Da36F35934C704ca9f2d2CF5cbc3Cba5988",
          "count": 6
        },
        {
          "address": "0x28bA6E30cB0d9372a18c80552eE11DFe47883FAd",
          "count": 1
        },
        {
          "address": "0xFFFc74b51BC5e75527fE5970D04355958dd3657C",
          "count": 10
        },
        {
          "address": "0xB6AE1C10C5547ed1D6ba50d74cc92214E17b5111",
          "count": 10
        },
        {
          "address": "0x3292FEAbea61A76cf59Fa917b9DCcC937Ca489eE",
          "count": 8
        },
        {
          "address": "0x9234e37d86AE7De3Dd0Ac57AF815b54551873504",
          "count": 6
        },
        {
          "address": "0x372b320ECA35F86A28249E3e309545A44270DD7D",
          "count": 9
        },
        {
          "address": "0x79c80a68Cc851d9A2aBF16c32eBAaC866C4Fced9",
          "count": 5
        },
        {
          "address": "0x8fFb06c288C30F3e62b31d6c5FD34328A964774a",
          "count": 7
        },
        {
          "address": "0xc6C621E6BA9Ad2FA2E81998006e0f4Ff45c34b65",
          "count": 15
        },
        {
          "address": "0xE2EBF3781D7eFeCbf242a5510AAb60985E045F17",
          "count": 3
        },
        {
          "address": "0x3b5AF36c2F269c4eA5ADffd12d65818A9cd94Dc2",
          "count": 6
        },
        {
          "address": "0x244125ddD7A63479F3A5DA8bC36682EdaFfdc92d",
          "count": 5
        },
        {
          "address": "0x8F66e288547032026dd1ddFb992ff7eEcD9261f0",
          "count": 7
        },
        {
          "address": "0x2eb2F635320c3Dbf29eadD35E894c13EE3F20bd5",
          "count": 5
        },
        {
          "address": "0xD82a5740De434f67b64946ba5939dfECc594Bcc1",
          "count": 10
        },
        {
          "address": "0x0a887Ad7a0a383e8fF9E1CB2433712e53C26AF95",
          "count": 2
        }
      ],
      "time": "1717113600000000"
    },
    "message": "message"
  }
}
```

### GetStakingUtxo

获取质押的utxo

**参数**

- fromaddr 地址

**返回值**

- code
  - 0 success
  - -1 fromaddr not stake!

- message 返回信息(详情见code对应的错误返回信息)
- utxo 质押时的utxo
- value 质押时的金额

```json
{
  "id":"1",
  "jsonrpc":"2.0",
  "params":{"fromAddr":"5c8bf650F93d82A7131C2FeA01Ec2bFB3C61A03B"}
}
```

```json
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetStakingUtxo",
  "result": {
    "code": 0,
    "message": "",
    "utxos": {
      "827022b125d2b60e9ed40a1e7bfa6874b90bb6dbccd515824cb353f0ab3397c6": 100000000000
    }
  }
}
```

### GetUndelegatingUtxo

获取解投资的utxo

**参数**

- fromAddr 投资人
- toAddr 被投资人

返回值

- code
  - 0 success 
  - -1 The address has no Delegating in anyone
- message
- utxos  解投资的utxo

```json
{
  "id":"1",
  "jsonrpc":"2.0",
  "params":{
    "fromAddr":"5c8bf650F93d82A7131C2FeA01Ec2bFB3C61A03B",
    "toAddr":"5c8bf650F93d82A7131C2FeA01Ec2bFB3C61A03B"
  }
}
```

```json
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetAllStakeNodeList",
  "result": {
    "code": 0,
    "message": "success",
    "utxos": {
      "utxo": [
        "17c62bacc4db9eee7a9b4596894dbf6a17754319fc8b24204fd4e7519a3f4457"
      ]
    }
  }
}
```



### GetBalance

**说明**：

返回给定地址的帐户余额

**参数**：

* id 透传信息

* jsonrpc  json版本

* params 参数

  * addr 要查询地址
  * 资产类型
  

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  * code 返回值
    0  	sucess
    -1   address is invalid
    -2   search balance failed
  * message 调用信息
  * balance 账户余额
  * addr 要查询的地址
  * assetType  资产类型

**例子**:

```json
//req
{
    "id": "1",
    "jsonrpc": "2.0",
    "params": {
        "addr": "0xffFd42e045737b11570B7981c2648ea532a10B23",
        "assetType": "X"
    }
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetBalance",
  "result": {
    "addr": "0xffFd42e045737b11570B7981c2648ea532a10B23",
    "assetType": "X",
    "balance": "9759699999691700",
    "code": 0,
    "message": "success"
  }
}
```



### GetBlockHeight

**说明**：

返回最新区块的编号

**参数**：

* id 透传信息
* jsonrpc  json版本

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  * code 返回值
    -  0  	sucess
    -  -1   getBlockTop error
  * message 调用信息
  * top 最新区块的编号

**例子**:

```json
//req
{
    "id":"1",
    "jsonrpc":"2.0",
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetBlockHeight",
  "result": {
    "code": 0,
    "message": "success",
    "height": "590"
  }
}
```



### GetVersion

**说明**：

返回当前客户端版本、网络版本、数据库版本和config版本

**参数**：

* id 透传信息
* jsonrpc  json版本

**返回值**：

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  * code 返回值
    -  0  	sucess
  * message 调用信息
  * clientVersion 客户端版本
  * netVersion   网络版本
  * configVersion   config版本
  * dbVersion  数据库版本

**例子**:

```json
//req
{
    "id":"1",
    "jsonrpc":"2.0",
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetVersion",
  "result": {
    "clientVersion": "1_1.0.0_d",
    "code": 0,
    "configVersion": "1.0.0",
    "dbVersion": "1_1.0.0_d",
    "message": "success",
    "netVersion": "1"
  }
}
```



### GetBlockTransactionCountByHash

**说明**：

返回匹配给定区块哈希的区块中的交易数量

**参数**：

* id 透传信息
* jsonrpc  json版本
* params 参数
  * blockHash 区块hash

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  * code 返回值
    *  0  	sucess
    *  -1   getBlockByBlockHash error
    *  -2   block parse string fail
  * message 调用信息
  * txCount 给定区块哈希的区块中的交易数量

**例子**:

```json
//req
{
    "id":"1",
    "jsonrpc":"2.0",
    "params":{"blockHash":"0x12e52383dc0fedc40bdab13fc1afd851d7123facf030f90163c03f87411650f1"}
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetBlockTransactionCountByHash",
  "result": {
    "code": 0,
    "message": "success",
    "txCount": "1"
  }
}
```







### GetAccounts

**说明**：

 返回客户端拥有的地址列表

**参数**：

* id 透传信息
* jsonrpc  json版本

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  * code 返回值
    - 0  	sucess
  * message 调用信息
  * acccountlist 客户端拥有的地址列表

**例子**: 

```json
//req
{
    "id":"1",
    "jsonrpc":"2.0",
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetAccounts",
  "result": {
    "acccountlist": [
      "0x6a72ad3e9762d67D45a311954CdC6ad4693203a9",
      "0x87dE53fdC1e5AA53eB9Cb839C2EF664Cab0f4C01",
      "0x9d394DFB4475Eaef15A27396568e5028f13C3F85",
      "0xD4c60A4866BeE49e0642feC293ee8560C237b758",
      "0xf535227CCA5487776e666374c839de8b7005892B"
    ],
    "code": 0,
    "message": "success"
  }
}
```



### GetChainId

**说明**：

返回链 ID

**参数**：

* id 透传信息

* jsonrpc  json版本

  

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  * code 返回值
    -  0  	sucess
  * message 调用信息
  * chainId 链 ID

**例子**:

```json
//req
{
    "id":"1",
    "jsonrpc":"2.0",
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetChainId",
  "result": {
    "chainId": "0x1080c0ce",
    "code": 0,
    "message": "success"
  }
}
```



### GetNodeList

**说明**：

返回当前连接到客户端的节点列表

**参数**：

* id 透传信息

* jsonrpc  json版本

  

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  * code 返回值
    -  0  	sucess
  * message 调用信息
  * peers  连接到客户端的节点列表
  * size 连接到客户端的节点数量



```json
//req
{
    "id":"1",
    "jsonrpc":"2.0",
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetNodeList",
  "result": {
    "code": 0,
    "message": "success",
    "peers": [
      {
        "addr": "0x0aFeBC02da4d5111d05d425e74e822B032274f2b", //账户地址
        "fd": 16,  		//文件描述符。
       "pulse": "3",		//心跳
        "height": 2499,  	//节点当前高度
        "ip": "192.168.1.100", 	//远端ip
        "ip_l": "192.168.1.81", 	//自身ip
        "kind": 1,    		// 连接类型
        "name": "",    		//节点名字
        "logo": "",   		//浏览器标志
        "port": 55302, 		//本地端口号
        "port_l": 20619, 	//远端端口号
        "version": "1_1.0.0_d" 	//客户端版本
      },
      {
        "addr": "0xd57730E2CE30d412cea04689C9cDE2f0846df169",
        "fd": 17,
        "pulse": 3,
        "height": 2499,
        "ip": "192.168.1.110",
        "ip_l": "192.168.1.81",
        "kind": 1,
        "name": "",
         "logo": "",
        "port": 36874,
        "port_l": 20619,
        "version": "1_1.0.0_d"
      }
    ],
    "size": 2
  }
}
```

### GetYieldInfo

获取利率信息

**参数**：无

**返回值**

- code 返回值编号
  - -1：The earning Rate is greater than the threshold
- annualizedRate 年化率

例子：

```json
//req
{
    "id" : "1",
    "jsonrpc": "2.0",
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetYieldInfo",
  "result": {
    "code": 0,
    "message": "success",
    "annualizedRate" : "0.16"
    }
}

```

### GetDelegatingAddrsByBonusAddr

**说明**：

根据地址获取该地址的被投资信息，一个地址可以被投资的最大金额为：65000 * 100000000

**参数**：

* id 透传信息
* jsonrpc  json版本
* params 参数
  * addr 要查询的地址

**返回值**：

* id 透传信息

* jsonrpc  json版本

* method 方法名称

* result 返回信息

  * code 返回值
    * 0	success
    * -1   Database abnormal, Get delegating addrs by node failed!
    * -2   The account number to be delegatinged have been delegatinged by 999 people
    * -3   Database abnormal, Get bonus addr delegating utxos by bonusAddr failed
    * -4   Database abnormal, Get transaction by hash failed
    * -5   Failed to parse transaction body
  * message 调用信息
  * info  投资地址对应投资的资产类型和金额
  
  ```json
  //req
  {
    "id":"1",
    "jsonrpc":"2.0",
    "params":{"addr":"0xadc2A709EC1413eCcEB4d115E50BD9ebBA35E3Ce"}
  }
  //ack
  {
    "id": "1",
    "jsonrpc": "2.0",
    "method": "GetDelegatingAddrsByBonusAddr",
    "result": {
      "code": 0,
      "info": {
        "746CADE61c69a2af24CEf4928a523E616c84b36E": [
          [
            "5e7c785de771a3130587872bc4381b15c1b2d38a6c101796c67535af5c5471f0",
            "500000000000"
          ],
          [
            "0x416ba3e59614072c3bbdfb4f194fe71d248a7d82b1727f2d4ca51f8b4aba1528",
            "500000000000"
          ]
        ],
        "AbA56968eA57C630B22A21ff791458cF253cA6aE": [
          [
            "X",
            "1000000000000"
          ]
        ],
        "Ce3efA4FE6b044FB985736C62ABFDF435CC9AfCF": [
          [
            "5e7c785de771a3130587872bc4381b15c1b2d38a6c101796c67535af5c5471f0",
            "100000000000"
          ],
          [
            "0x416ba3e59614072c3bbdfb4f194fe71d248a7d82b1727f2d4ca51f8b4aba1528",
            "100000000000"
          ]
        ],
        "D9ECEec8420a0c053b70511f5f150EbD44358F3d": [
          [
            "5e7c785de771a3130587872bc4381b15c1b2d38a6c101796c67535af5c5471f0",
            "200000000000"
          ],
          [
            "0x416ba3e59614072c3bbdfb4f194fe71d248a7d82b1727f2d4ca51f8b4aba1528",
            "300000000000"
          ]
        ]
      },
      "message": "success"
    }
  }
  ```
  

### GetAddrType

**说明**：

获取地址是否投资、是否质押、是否锁定

**参数**：

* id 透传信息
* jsonrpc  json版本
* params 参数
  * addr 要查询的地址

**返回值**：

* id 透传信息

* jsonrpc  json版本

* method 方法名称

* result 返回信息

  * code 返回值
    * 0	success
  * isDelegated  是否投资
  * isLocked  是否锁定
  * isStaked  是否质押
  * isBonus   当前是否可以申领
  * isQualified  是否有申领资格

例子：

```json
//req
{
  "id":"1",
  "jsonrpc":"2.0",
  "params":{"addr":"0x9D69D2774Ecbf6F36c0d8250892aFAD68EB35919"}
}
//ack
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetAddrType",
  "result": {
    "code": 0,
    "isBonus": false,
    "isDelegated": false,
    "isLocked": false,
    "isQualified": false,
    "isStaked": false,
    "message": "success"
  }
}
```

## 交易相关

当前账号发送交易的流程如下：

1. 判断本次交易与此账号上一笔交易发送的时间差。在APP端，通过调用发送交易的两个接口后，解析两个接口返回的内容，并将交易信息缓存在本地。确认交易接口（ConfirmTransaction）返回的txJson结构中包含交易时间和gas等信息，而调用合约请求接口（CreateCallContractTransaction）返回的txJson中也包含交易时间和gas等信息。同时，发送消息（SendMessage）或发送合约消息（SendContractMessage）的接口返回内容中包含txhash。

2. 需要判断接口返回值result中code是否为0，以确认接口调用是否正常。只有在接口调用code为0的情况下，才能进行下一个接口调用。

3. 所有交易接口都采用Post请求方式，请求体中的数据格式为JSON。

* 时间差30秒内，需判断上笔交易是否成功上链，成功上链发送当前交易，没成功上链提示用户操作频繁。
* 时间差大于等于30秒，直接发送本次交易。

判断交易是否成功上链

1. 先获取节点高度，调用 GetBlockHeight 接口，获取返回 result 中的 height 字段值为节点高度
2. 再调用ConfirmTransaction接口，高度字段值传 GetBlockHeight 接口返回的height 字段值，Txhash传当前账号上次发送交易调用SendMessage或者SendContractMessage接口返回的txhash值, ConfirmTransaction接口返回percent值字段大于等于0.8代表交易成功上链。

## 发送 X-Eco 交易

先调用CreateTransaction等交易接口，然后签名CreateTransaction接口返回的所有内容，签名方法是调用库里的Sig方法，然后调用/SendMessage接口,调用/SendMessage接口请求参数为调用sigTx方法返回的JSON字符串。

### SendMessage

**说明**：

对于CreateTransaction，CreateStakeTransaction，CreateUnStakeTransaction，CreateDelegatingTransaction，CreateUndelegatingTransaction，CreateBonus 等接口，完成调用后使用签名SDK工具进行签名后使用SendMessage接口将交易发送到节点即可完成发送交易。是否上链使用ConfirmTransaction接口进行判定。

**参数**：

为CreateTransaction等接口返回的数据调用SDK工具签名接口的返回值

**返回值**：

无，调用完此接口查看是否上链即可

**例子**:

```json
//对CreateTransaction返回数据进行签名后的数据
{
    "id": "",
    "jsonrpc": "",
    "result": {
        "code": "",
        "gas": "20200",
        "height": "600",
        "message": "",
        "time": "1717148047269517",
        "txJson": "{\"time\":\"1717148047269517\",\"identity\":\"2eb2F635320c3Dbf29eadD35E894c13EE3F20bd5\",\"utxo\":{\"owner\":[\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"],\"vin\":[{\"prevOut\":[{\"hash\":\"3f1342e96e426e2905021ad991787131ec70d31298646b1e80da9d912eeff274\"}],\"vinSign\":{\"sign\":\"ApxL8NDgh9YYDuUXpdbsbVv0cEAr3HyXmr2TICkD4mfuDIZqVlZJNUmaPAKHCs5kkn7JnZx7r12+CpnnR4ZpAg==\",\"pub\":\"MCowBQYDK2VwAyEA89VSBQU7d4uL+jvqAKeCRbgYz2tzk/Rf8DNRhB0sLbg=\"}}],\"vout\":[{\"value\":\"1350000000\",\"addr\":\"06BA76F46631d4F344d1344303895001F1E3Af29\"},{\"value\":\"1982446992477\",\"addr\":\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"},{\"value\":\"20200\",\"addr\":\"VirtualBurnGas\"}],\"multiSign\":[{\"sign\":\"WCoFsLKML69x1rSpQc7pwbnd+GMfZ0Ce3wTPg96Rdb1v7ezFw9KuEBXwvGecTz264pVZB6T8hzgJIx26GuKVAA==\",\"pub\":\"MCowBQYDK2VwAyEA89VSBQU7d4uL+jvqAKeCRbgYz2tzk/Rf8DNRhB0sLbg=\"}]},\"type\":\"Tx\",\"consensus\":7,\"txType\":1}",
        "txType": "1",
        "vrfJson": "{\"vrfdata\":{\"hash\":\"6cf89d80c98eecd9138caca4f55d7ad0fda2aed9d8e68dd4642543ae3ee056d6\"},\"Vrfsign\":{\"sign\":\"u5dNZ16Rd77B4nLd8gAcKTwz+GxeHH1HIlcGennGbPaKgIFXUkmFzS/EnVxRC4nmSfESAdWyMEmj4pKBhwuqAg==\",\"pub\":\"MCowBQYDK2VwAyEAcUcydwF7CSr9bjBiUbd3drV+WMd4yd8xFL7HWGA4FTw=\"}}"
    }
}
```

### SendContractMessage

**说明**：

对于CreateCallContractTransaction,CreateDeployContractTransaction等接口，完成调用后使用签名SDK工具进行签名后使用SendContractMessage接口将交易发送到节点即可完成发送交易。是否上链使用ConfirmTransaction接口进行判定。

**参数**：

为CreateDeployContractTransaction等接口返回的数据调用SDK工具签名接口的返回值

**返回值**：

无，调用完此接口查看是否上链即可

**例子**：

```json
//req
{
    "id": "",
    "jsonrpc": "",
    "result": {
        "code": "",
        "contractJs": "{\"version\":\"1_1.0.0_d\",\"txMsgReq\":{\"version\":\"1_1.0.0_d\",\"txMsgInfo\":{\"nodeHeight\":\"601\",\"contractStorageList\":[\"A8B8Ae6F84709fF80E08aD9d26575c161aCC95f1\"]},\"vrfInfo\":{\"vrfdata\":{\"hash\":\"dea1b44a641928d6a09db9a3d9da274abe4ef13eb23833213144a5b46c612136\"},\"Vrfsign\":{\"pub\":\"MCowBQYDK2VwAyEASFAPKN8n+Nqn2RcJX8XCgyx1sveBLZ/f5tn5JpM2Xxs=\"}}}}",
        "message": "",
        "txJson": "{\"time\":\"1717148103333839\",\"identity\":\"2eb2F635320c3Dbf29eadD35E894c13EE3F20bd5\",\"utxo\":{\"owner\":[\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"],\"vin\":[{\"prevOut\":[{\"hash\":\"dea1b44a641928d6a09db9a3d9da274abe4ef13eb23833213144a5b46c612136\"}],\"vinSign\":{\"sign\":\"3o82Rq7taGO+VRtrhtxWOVPAolo/pVxuNXEBdklDpDVd8tJcTjNrnmaMFixdav2wCyvCb+AFOd02ryPI4JV1Cw==\",\"pub\":\"MCowBQYDK2VwAyEA89VSBQU7d4uL+jvqAKeCRbgYz2tzk/Rf8DNRhB0sLbg=\"}}],\"vout\":[{\"value\":\"480\",\"addr\":\"VirtualDeployContractBurnGas\"},{\"value\":\"1982446498797\",\"addr\":\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"},{\"value\":\"493200\",\"addr\":\"VirtualBurnGas\"}],\"multiSign\":[{\"sign\":\"YVcOA5gZhVNaQx7eoduw4lOI4d1HNtPRWEUoMzDK6D2UnZXDbRziXV66XiaRxKOzXF3kF/N4j8PEe5CMjkf3BQ==\",\"pub\":\"MCowBQYDK2VwAyEA89VSBQU7d4uL+jvqAKeCRbgYz2tzk/Rf8DNRhB0sLbg=\"}]},\"type\":\"Tx\",\"consensus\":7,\"txType\":7,\"data\":\"{\\\"TxInfo\\\":{\\\"blockPrevRandao\\\":4406,\\\"blockTimestamp\\\":1717148110,\\\"input\\\":\\\"608060405234801561001057600080fd5b506108b3806100206000396000f3fe608060405234801561001057600080fd5b50600436106100575760003560e01c80630483a7f61461005c5780631629614e1461008c57806327e235e3146100a85780637ad9ad7c146100d8578063afc58189146100f4575b600080fd5b610076600480360381019061007191906105a8565b610110565b60405161008391906106d7565b60405180910390f35b6100a660048036038101906100a19190610615565b610128565b005b6100c260048036038101906100bd91906105a8565b6102a7565b6040516100cf91906106d7565b60405180910390f35b6100f260048036038101906100ed91906105d5565b6102bf565b005b61010e60048036038101906101099190610615565b61037d565b005b60016020528060005260406000206000915090505481565b80806000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000205410156101aa576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016101a1906106b7565b60405180910390fd5b816000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546101f89190610759565b9250508190555081600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020600082825461024e9190610703565b925050819055503373ffffffffffffffffffffffffffffffffffffffff167f3a14c6aa3e15c61c97825b026647b989a91e18aa33b689769475a298922480428360405161029b91906106d7565b60405180910390a25050565b60006020528060005260406000206000915090505481565b806000808473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020600082825461030d9190610703565b925050819055508173ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff167f322d0c4befd4c2dd440740b711488a1638fd7d8eeb25f9dacede84083db428c98360405161037191906106d7565b60405180910390a35050565b6000600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020541415610400576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016103f790610697565b60405180910390fd5b80600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020541015610482576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161047990610697565b60405180910390fd5b806000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546104d09190610703565b9250508190555080600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546105269190610759565b925050819055503373ffffffffffffffffffffffffffffffffffffffff167f867b353f032680758428983522443995b88120a470e436b962c6a9d0d8940af78260405161057391906106d7565b60405180910390a250565b60008135905061058d8161084f565b92915050565b6000813590506105a281610866565b92915050565b6000602082840312156105be576105bd6107f8565b5b60006105cc8482850161057e565b91505092915050565b600080604083850312156105ec576105eb6107f8565b5b60006105fa8582860161057e565b925050602061060b85828601610593565b9150509250929050565b60006020828403121561062b5761062a6107f8565b5b600061063984828501610593565b91505092915050565b600061064f6011836106f2565b915061065a826107fd565b602082019050919050565b60006106726014836106f2565b915061067d82610826565b602082019050919050565b610691816107bf565b82525050565b600060208201905081810360008301526106b081610642565b9050919050565b600060208201905081810360008301526106d081610665565b9050919050565b60006020820190506106ec6000830184610688565b92915050565b600082825260208201905092915050565b600061070e826107bf565b9150610719836107bf565b9250827fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0382111561074e5761074d6107c9565b5b828201905092915050565b6000610764826107bf565b915061076f836107bf565b925082821015610782576107816107c9565b5b828203905092915050565b60006107988261079f565b9050919050565b600073ffffffffffffffffffffffffffffffffffffffff82169050919050565b6000819050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b600080fd5b7f4e6f206c6f636b65642062616c616e6365000000000000000000000000000000600082015250565b7f496e73756666696369656e742062616c616e6365000000000000000000000000600082015250565b6108588161078d565b811461086357600080fd5b50565b61086f816107bf565b811461087a57600080fd5b5056fea264697066735822122067e67aed3152cf78a07c4f8842540cf5803e421699b10fbf8f66c015550b0ed464736f6c63430008070033\\\",\\\"recipient\\\":\\\"A8B8Ae6F84709fF80E08aD9d26575c161aCC95f1\\\",\\\"sender\\\":\\\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\\\",\\\"version\\\":0,\\\"virtualMachine\\\":0}}\"}"
    }
}
```

### CreateTransaction

获取普通交易体

**参数**

- fromAddr 发起方地址
- toAddr 接收方地址
- isFindUtxo 是否全网探寻当前utxo的状态
- value 转账金额
- txDescriptionData: 交易描述信息

**返回值**

- code 返回值编号
  - 0     success
  - -1    db get top failed
  - -2    Check parameters failed
  - -3     to addr is empty
  - -4     To address is not  address!
  - -5     from address is same with toaddr
  - -6     Value is zero!
  - -7     The information entered exceeds the specified length
  - -8     FindUtxo failed!
  - -9     Utxo is empty!
  - -10    Tx owner is empty!
  - -11     Generate Gas failed!
  - -12     余额不足 (原-72013)
  - -13     Find packager failed
  - -14     utxo is using!

- message 返回值信息(详情见code对应的错误返回信息)
- txJson: 交易体信息
- height:高度
- vrfJson: vrf信息
- txType:交易类型
- time: 发送交易的时间
- gas: 燃料费

```json
{"id":"","jsonrpc":"","params":{"fromAddr":["cED97dA085527Fe7e1772CA59Aa1e64A78143128"],"isFindUtxo":false,"toAddr":[{"addr":"06BA76F46631d4F344d1344303895001F1E3Af29","value":"13.5"}],"txInfo":""}}
```

```json
{"id":"","jsonrpc":"","method":"","result":{"code":0,"gas":"20200","height":"600","message":"0","time":"1717148047269517","txJson":"{\"time\":\"1717148047269517\",\"identity\":\"2eb2F635320c3Dbf29eadD35E894c13EE3F20bd5\",\"utxo\":{\"owner\":[\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"],\"vin\":[{\"prevOut\":[{\"hash\":\"3f1342e96e426e2905021ad991787131ec70d31298646b1e80da9d912eeff274\"}]}],\"vout\":[{\"value\":\"1350000000\",\"addr\":\"06BA76F46631d4F344d1344303895001F1E3Af29\"},{\"value\":\"1982446992477\",\"addr\":\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"},{\"value\":\"20200\",\"addr\":\"VirtualBurnGas\"}]},\"type\":\"Tx\",\"consensus\":7,\"txType\":1}","txType":"1","vrfJson":"{\"vrfdata\":{\"hash\":\"6cf89d80c98eecd9138caca4f55d7ad0fda2aed9d8e68dd4642543ae3ee056d6\"},\"Vrfsign\":{\"sign\":\"u5dNZ16Rd77B4nLd8gAcKTwz+GxeHH1HIlcGennGbPaKgIFXUkmFzS/EnVxRC4nmSfESAdWyMEmj4pKBhwuqAg==\",\"pub\":\"MCowBQYDK2VwAyEAcUcydwF7CSr9bjBiUbd3drV+WMd4yd8xFL7HWGA4FTw=\"}}"}}
```

### CreateDeployContractTransaction

获取部署合约交易体

**参数**

- addr 部署方地址
- contract 合约部署码
- nContractType 默认为0
- info 合约信息
- data 合约code
- pubstr 部署地址公钥的base64
- isFindUtxo 是否全网探寻当前utxo的状态
- txDescriptionData: 交易描述信息

**返回值**

- code 返回值编号
  - 0 success
  - -300 执行合约失败(根据output错误信息判断是否是余额不足)
  - -2004 主网币余额不足
  - -13114 主网币余额不足
  - -13116 reward 小于 gas
  - -13117 主网币余额不足


- message 返回值信息(详情见code对应的错误返回信息)
- contractJs 合约信息
- txJson 交易信息

```json
{"id":"","jsonrpc":"","params":{"addr":"cED97dA085527Fe7e1772CA59Aa1e64A78143128","contract":"608060405234801561001057600080fd5b506108b3806100206000396000f3fe608060405234801561001057600080fd5b50600436106100575760003560e01c80630483a7f61461005c5780631629614e1461008c57806327e235e3146100a85780637ad9ad7c146100d8578063afc58189146100f4575b600080fd5b610076600480360381019061007191906105a8565b610110565b60405161008391906106d7565b60405180910390f35b6100a660048036038101906100a19190610615565b610128565b005b6100c260048036038101906100bd91906105a8565b6102a7565b6040516100cf91906106d7565b60405180910390f35b6100f260048036038101906100ed91906105d5565b6102bf565b005b61010e60048036038101906101099190610615565b61037d565b005b60016020528060005260406000206000915090505481565b80806000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000205410156101aa576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016101a1906106b7565b60405180910390fd5b816000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546101f89190610759565b9250508190555081600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020600082825461024e9190610703565b925050819055503373ffffffffffffffffffffffffffffffffffffffff167f3a14c6aa3e15c61c97825b026647b989a91e18aa33b689769475a298922480428360405161029b91906106d7565b60405180910390a25050565b60006020528060005260406000206000915090505481565b806000808473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020600082825461030d9190610703565b925050819055508173ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff167f322d0c4befd4c2dd440740b711488a1638fd7d8eeb25f9dacede84083db428c98360405161037191906106d7565b60405180910390a35050565b6000600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020541415610400576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016103f790610697565b60405180910390fd5b80600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020541015610482576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161047990610697565b60405180910390fd5b806000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546104d09190610703565b9250508190555080600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546105269190610759565b925050819055503373ffffffffffffffffffffffffffffffffffffffff167f867b353f032680758428983522443995b88120a470e436b962c6a9d0d8940af78260405161057391906106d7565b60405180910390a250565b60008135905061058d8161084f565b92915050565b6000813590506105a281610866565b92915050565b6000602082840312156105be576105bd6107f8565b5b60006105cc8482850161057e565b91505092915050565b600080604083850312156105ec576105eb6107f8565b5b60006105fa8582860161057e565b925050602061060b85828601610593565b9150509250929050565b60006020828403121561062b5761062a6107f8565b5b600061063984828501610593565b91505092915050565b600061064f6011836106f2565b915061065a826107fd565b602082019050919050565b60006106726014836106f2565b915061067d82610826565b602082019050919050565b610691816107bf565b82525050565b600060208201905081810360008301526106b081610642565b9050919050565b600060208201905081810360008301526106d081610665565b9050919050565b60006020820190506106ec6000830184610688565b92915050565b600082825260208201905092915050565b600061070e826107bf565b9150610719836107bf565b9250827fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0382111561074e5761074d6107c9565b5b828201905092915050565b6000610764826107bf565b915061076f836107bf565b925082821015610782576107816107c9565b5b828203905092915050565b60006107988261079f565b9050919050565b600073ffffffffffffffffffffffffffffffffffffffff82169050919050565b6000819050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b600080fd5b7f4e6f206c6f636b65642062616c616e6365000000000000000000000000000000600082015250565b7f496e73756666696369656e742062616c616e6365000000000000000000000000600082015250565b6108588161078d565b811461086357600080fd5b50565b61086f816107bf565b811461087a57600080fd5b5056fea264697066735822122067e67aed3152cf78a07c4f8842540cf5803e421699b10fbf8f66c015550b0ed464736f6c63430008070033","data":"","info":"[]","isFindUtxo":false,"nContractType":"0","pubstr":"MCowBQYDK2VwAyEA89VSBQU7d4uL+jvqAKeCRbgYz2tzk/Rf8DNRhB0sLbg=","txInfo":"info"}}
```

```json
{"id":"","jsonrpc":"","method":"","result":{"code":0,"contractJs":"{\"version\":\"1_1.0.0_d\",\"txMsgReq\":{\"version\":\"1_1.0.0_d\",\"txMsgInfo\":{\"nodeHeight\":\"601\",\"contractStorageList\":[\"A8B8Ae6F84709fF80E08aD9d26575c161aCC95f1\"]},\"vrfInfo\":{\"vrfdata\":{\"hash\":\"dea1b44a641928d6a09db9a3d9da274abe4ef13eb23833213144a5b46c612136\"},\"Vrfsign\":{\"pub\":\"MCowBQYDK2VwAyEASFAPKN8n+Nqn2RcJX8XCgyx1sveBLZ/f5tn5JpM2Xxs=\"}}}}","message":"","txJson":"{\"time\":\"1717148103333839\",\"identity\":\"2eb2F635320c3Dbf29eadD35E894c13EE3F20bd5\",\"utxo\":{\"owner\":[\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"],\"vin\":[{\"prevOut\":[{\"hash\":\"dea1b44a641928d6a09db9a3d9da274abe4ef13eb23833213144a5b46c612136\"}]}],\"vout\":[{\"value\":\"480\",\"addr\":\"VirtualDeployContractBurnGas\"},{\"value\":\"1982446498797\",\"addr\":\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"},{\"value\":\"493200\",\"addr\":\"VirtualBurnGas\"}]},\"type\":\"Tx\",\"consensus\":7,\"txType\":7,\"data\":\"{\\\"TxInfo\\\":{\\\"blockPrevRandao\\\":4406,\\\"blockTimestamp\\\":1717148110,\\\"input\\\":\\\"608060405234801561001057600080fd5b506108b3806100206000396000f3fe608060405234801561001057600080fd5b50600436106100575760003560e01c80630483a7f61461005c5780631629614e1461008c57806327e235e3146100a85780637ad9ad7c146100d8578063afc58189146100f4575b600080fd5b610076600480360381019061007191906105a8565b610110565b60405161008391906106d7565b60405180910390f35b6100a660048036038101906100a19190610615565b610128565b005b6100c260048036038101906100bd91906105a8565b6102a7565b6040516100cf91906106d7565b60405180910390f35b6100f260048036038101906100ed91906105d5565b6102bf565b005b61010e60048036038101906101099190610615565b61037d565b005b60016020528060005260406000206000915090505481565b80806000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000205410156101aa576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016101a1906106b7565b60405180910390fd5b816000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546101f89190610759565b9250508190555081600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020600082825461024e9190610703565b925050819055503373ffffffffffffffffffffffffffffffffffffffff167f3a14c6aa3e15c61c97825b026647b989a91e18aa33b689769475a298922480428360405161029b91906106d7565b60405180910390a25050565b60006020528060005260406000206000915090505481565b806000808473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020600082825461030d9190610703565b925050819055508173ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff167f322d0c4befd4c2dd440740b711488a1638fd7d8eeb25f9dacede84083db428c98360405161037191906106d7565b60405180910390a35050565b6000600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020541415610400576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016103f790610697565b60405180910390fd5b80600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020541015610482576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161047990610697565b60405180910390fd5b806000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546104d09190610703565b9250508190555080600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546105269190610759565b925050819055503373ffffffffffffffffffffffffffffffffffffffff167f867b353f032680758428983522443995b88120a470e436b962c6a9d0d8940af78260405161057391906106d7565b60405180910390a250565b60008135905061058d8161084f565b92915050565b6000813590506105a281610866565b92915050565b6000602082840312156105be576105bd6107f8565b5b60006105cc8482850161057e565b91505092915050565b600080604083850312156105ec576105eb6107f8565b5b60006105fa8582860161057e565b925050602061060b85828601610593565b9150509250929050565b60006020828403121561062b5761062a6107f8565b5b600061063984828501610593565b91505092915050565b600061064f6011836106f2565b915061065a826107fd565b602082019050919050565b60006106726014836106f2565b915061067d82610826565b602082019050919050565b610691816107bf565b82525050565b600060208201905081810360008301526106b081610642565b9050919050565b600060208201905081810360008301526106d081610665565b9050919050565b60006020820190506106ec6000830184610688565b92915050565b600082825260208201905092915050565b600061070e826107bf565b9150610719836107bf565b9250827fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0382111561074e5761074d6107c9565b5b828201905092915050565b6000610764826107bf565b915061076f836107bf565b925082821015610782576107816107c9565b5b828203905092915050565b60006107988261079f565b9050919050565b600073ffffffffffffffffffffffffffffffffffffffff82169050919050565b6000819050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b600080fd5b7f4e6f206c6f636b65642062616c616e6365000000000000000000000000000000600082015250565b7f496e73756666696369656e742062616c616e6365000000000000000000000000600082015250565b6108588161078d565b811461086357600080fd5b50565b61086f816107bf565b811461087a57600080fd5b5056fea264697066735822122067e67aed3152cf78a07c4f8842540cf5803e421699b10fbf8f66c015550b0ed464736f6c63430008070033\\\",\\\"recipient\\\":\\\"A8B8Ae6F84709fF80E08aD9d26575c161aCC95f1\\\",\\\"sender\\\":\\\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\\\",\\\"version\\\":0,\\\"virtualMachine\\\":0}}\"}"}}
```

### CreateCallContractTransaction

获取执行合约交易体

**参数**

- addr 执行方地址
- args 执行合约参数
- contractAddress 合约地址
- deployer 部署合约方地址
- deployutxo 部署合约的txhash
- istochain 是否上链
- pubstr 执行方公钥的base64
- tip 小费
- info 信息
- money 金额

**返回值**

**返回值**

- code 返回值编号
  - 0 success
  - -300 执行合约失败(根据output错误信息判断是否是余额不足)
  - -2004 主网币余额不足
  - -13114 主网币余额不足
  - -13116 reward 小于 gas
  - -13117 主网币余额不足

- message 返回值信息(详情见code对应的错误返回信息,省略内容为内部错误)
- contractJs 合约信息
- txJson 交易信息

```json
{"id":"123","jsonrpc":"","params":{"addr":"cED97dA085527Fe7e1772CA59Aa1e64A78143128","args":"0x7ad9ad7c000000000000000000000000ff3778ca36a2936390c06d8b0457f5b8e408389c0000000000000000000000000000000000000000000000000000000000002710","contractAddress":"0x7350399179EC2B0702008aE8b43a0579AA699Eb1","deployer":"cED97dA085527Fe7e1772CA59Aa1e64A78143128","deployutxo":"0x8a02413da127b48318a7ed12a46a4f68b83cdc6c21f937d7e6c99393d64112b0","isFindUtxo":false,"istochain":"true","money":"0","pubstr":"MCowBQYDK2VwAyEA89VSBQU7d4uL+jvqAKeCRbgYz2tzk/Rf8DNRhB0sLbg=","tip":"0","txInfo":"info"}}
```

```json
{"id":"123","jsonrpc":"","method":"","result":{"code":0,"contractJs":"{\"version\":\"1_1.0.0_d\",\"txMsgReq\":{\"version\":\"1_1.0.0_d\",\"txMsgInfo\":{\"nodeHeight\":\"603\",\"contractStorageList\":[\"7350399179EC2B0702008aE8b43a0579AA699Eb1\"]},\"vrfInfo\":{\"vrfdata\":{\"hash\":\"79675c88de3a336d2e47c6134146f0a4d26e068ca76aa730ca654830c6bb6b96\"},\"Vrfsign\":{\"pub\":\"MCowBQYDK2VwAyEASFAPKN8n+Nqn2RcJX8XCgyx1sveBLZ/f5tn5JpM2Xxs=\"}}}}","message":"","txJson":"{\"time\":\"1717148359029088\",\"identity\":\"0aFeBC02da4d5111d05d425e74e822B032274f2b\",\"utxo\":{\"owner\":[\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"],\"vin\":[{\"prevOut\":[{\"hash\":\"79675c88de3a336d2e47c6134146f0a4d26e068ca76aa730ca654830c6bb6b96\"}]}],\"vout\":[{\"value\":\"25041\",\"addr\":\"VirtualCallContractBurnGas\"},{\"value\":\"1982446318715\",\"addr\":\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"},{\"value\":\"65000\",\"addr\":\"VirtualBurnGas\"}]},\"type\":\"Tx\",\"consensus\":7,\"txType\":8,\"data\":\"{\\\"TxInfo\\\":{\\\"blockPrevRandao\\\":4345,\\\"blockTimestamp\\\":1717148360,\\\"contractDeployer\\\":\\\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\\\",\\\"donation\\\":0,\\\"input\\\":\\\"7ad9ad7c000000000000000000000000ff3778ca36a2936390c06d8b0457f5b8e408389c0000000000000000000000000000000000000000000000000000000000002710\\\",\\\"output\\\":\\\"\\\",\\\"recipient\\\":\\\"7350399179EC2B0702008aE8b43a0579AA699Eb1\\\",\\\"sender\\\":\\\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\\\",\\\"transfer\\\":0,\\\"version\\\":0,\\\"virtualMachine\\\":0}}\"}"}}
```

### CreateStakingTransaction

获取质押交易信息

**参数**:

- fromAddr：发起方地址
- stakeAmount：质押金额
- StakeType：质押类型
- pumpingPercentage：质押抽水比例
- isFindUtxo: 是否全网探寻当前utxo的状态
- txInfo: 交易描述信息

**返回值**：

- code 返回值编号
  - 0：success
  - -1：input pumping percentage error
  - -2：Failed to get the current highest block height
  - -3：Check parameters failed
  - -4：From address invlaid
  - -5：Stake amount is zero
  - -6：The pledge amount must be greater than Minimum pledge value
  - -7：Unknown stake type
  - -8：There has been a pledge transaction before !
  - -9：The information entered exceeds the specified length
  - -10：FindUtxo failed
  - -11：Utxo is empty
  - -12：Tx owner is invalid
  - -13：The commission ratio is not in the range
  - -14：The gas charge cannot be 0
  - -15：The total amount is less than gas
  - -16：Failed to get the packager
- message 返回值信息
- txJson: 交易体信息
- height:高度
- vrfJson: vrf信息
- txType:交易类型
- time: 发送交易的时间
- gas: 燃料费



例子：

```json
//req
{
    "id" : "1",
    "jsonrpc": "2.0",
    "params" : "{"fromAddr" : "69b34b7538DeB6913f2b9f59Cbc8610059442e5A", "stakeAmount" : "1000", "StakeType" : "0","CommissionRate": "5", "isFindUtxo": true, "txInfo": ""}"
}

//ack
{"id":"1","jsonrpc":"2.0","method":"CreateStakingTransaction","result":{"code":0,"gas":"28100","height":"593","message":"success","time":"1717146934713506","txJson":"{\"time\":\"1717146934713506\",\"identity\":\"8F66e288547032026dd1ddFb992ff7eEcD9261f0\",\"utxo\":{\"owner\":[\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\"],\"vin\":[{\"prevOut\":[{\"hash\":\"1a9446933109a33766fde80ced93142b261f81e315bc8afd9abd5306239842c1\"}]}],\"vout\":[{\"value\":\"100000000000\",\"addr\":\"VirtualStake\"},{\"value\":\"1899899508900\",\"addr\":\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\"},{\"value\":\"28100\",\"addr\":\"VirtualBurnGas\"}]},\"type\":\"Tx\",\"consensus\":7,\"txType\":2,\"data\":\"{\\\"TxInfo\\\":{\\\"CommissionRate\\\":0.05,\\\"StakeAmount\\\":100000000000,\\\"StakeType\\\":\\\"Net\\\"}}\"}","txType":"0","vrfJson":"{}"}}



```



### CreateUnstakingTransaction

获取解质押交易

**参数**:

- fromAddr: 发起方地址
- utxoHash:  utxo哈希
- isFindUtxo: 是否全网探寻当前utxo的状态
- txInfo: 交易描述信息

**返回值**：

- code 返回值编号
  
  - 0：success
  
  - -1：Failed to get the current highest block height
  - -2：Check parameters failed
  - -3： FromAddr is not normal addr.
  - -4：FindUtxo failed
  - -5：Utxo is empty
  - -6：Tx owner is empty
  - -7：The information entered exceeds the specified length
  - -8：The total amount is less than expend
  - -9：get_block_packager error
  - -101：Get all stake address failed
  - -102：The account number has not staked assets
  - -103：Get stake utxo from address failed
  - -104：The utxo to be de staked is not in the staked utxo
  - -105：The staked utxo is not more than 30 days
  - -106：Stake tx not found
  - -107：Failed to parse transaction body
  - -108：Stake value is zero
  
- message 返回值信息

- txJson: 交易体信息

- height:高度

- vrfJson: vrf信息

- txType:交易类型

- time: 发送交易的时间

- gas: 燃料费

例子:

```json
//req
{
    "id" : "1",
    "jsonrpc": "2.0",
    "params" : "{"fromAddr" : "69b34b7538DeB6913f2b9f59Cbc8610059442e5A", "utxoHash" : "405efe5ae260a8297751784ce5bb590efea1324b29c24b658b3b2e1ed948eec3","isFindUtxo": true, "txInfo": ""}"
}

//ack
{"id":"1","jsonrpc":"2.0","method":"CreateUnstakingTransaction","result":{"code":0,"gas":"39300","height":"595","message":"success","time":"1717147041334522","txJson":"{\"time\":\"1717147041334522\",\"identity\":\"372b320ECA35F86A28249E3e309545A44270DD7D\",\"utxo\":{\"owner\":[\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\",\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\"],\"vin\":[{\"prevOut\":[{\"hash\":\"b088fde1b1b270399134a7027408b2ef270d7f00859f306f9cb006e46de77e18\",\"n\":1}]},{\"prevOut\":[{\"hash\":\"e47b853d8d59e8d5982f68ed19dee6cdc5ce7e173df3e699af817366bd7b7541\"}],\"sequence\":1}],\"vout\":[{\"value\":\"100000000000\",\"addr\":\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\"},{\"value\":\"899899437600\",\"addr\":\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\"},{\"value\":\"39300\",\"addr\":\"VirtualBurnGas\"}]},\"type\":\"Tx\",\"consensus\":7,\"txType\":3,\"data\":\"{\\\"TxInfo\\\":{\\\"UnstakeUtxo\\\":\\\"b088fde1b1b270399134a7027408b2ef270d7f00859f306f9cb006e46de77e18\\\"}}\"}","txType":"0","vrfJson":"{}"}}
```

### CreateDelegatingTransaction

获取投资交易信息

**参数**:

- fromAddr: 发起方地址
- toAddr:  被投资地址
- delegateAmount： 投资金额
- delegateType： 投资类型

- isFindUtxo: 是否全网探寻当前utxo的状态
- txInfo: 交易描述信息

**返回值**：

- code 返回值编号
  - 0：success
  
  - -1：Failed to get the current highest block height
  - -2：Check parameters failed
  - -3：The initiator address is incorrect
  - -4：The receiver address is incorrect
  - -5：Delegating amount less 35
  - -6：Unknown delegating type
  - -7：The information entered exceeds the specified length
  - -8：FindUtxo failed
  - -9：Utxo is empty
  - -10：Tx owner is empty
  - -11：gas cannot be 0
  - -12：The total amount is less than expend
  - -13：get_block_packager error
  - -101：The delegatingor have already delegatinged in a node
  - -102：The Delegating amount is less than 35
  - -103：The account to be delegatinged has not spent 500 to access the Internet
  - -104：Get delegating addrs by node failed
  - -105：The account number to be delegatinged have been delegatinged by 999 people
  - -106：getDelegatingAddrUtxoByBonusAddr failed
  - -107：getTransactionByHash failed
  - -108：Failed to parse transaction body
  - -109：The total amount delegatinged in a single node will be more than 65000
  
- message 返回值信息

- txJson: 交易体信息

- height:高度

- vrfJson: vrf信息

- txType:交易类型

- time: 发送交易的时间

- gas: 燃料费

例子:

```json
//req
{
    "id" : "1",
    "jsonrpc": "2.0",
    "params" : "{"fromAddr" : "69b34b7538DeB6913f2b9f59Cbc8610059442e5A","toAddr":"69b34b7538DeB6913f2b9f59Cbc8610059442e5A","delegateAmount":"1000", "delegateType" : "0","pumpingPercentage": "5", "isFindUtxo": false, "txInfo": ""}"
}

//ack
{"id":"1","jsonrpc":"2.0","method":"CreateDelegatingTransaction","result":{"code":0,"gas":"32000","height":"590","message":"success","time":"1717146585760939","txJson":"{\"time\":\"1717146585760939\",\"identity\":\"8fFb06c288C30F3e62b31d6c5FD34328A964774a\",\"utxo\":{\"owner\":[\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\"],\"vin\":[{\"prevOut\":[{\"hash\":\"ed71842812bd3d5e0032d40f5a01ff8db1b0018a0a36c11292ed97e3783b2a78\"}]}],\"vout\":[{\"value\":\"1000000000000\",\"addr\":\"VirtualDelegating\"},{\"value\":\"899899621300\",\"addr\":\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\"},{\"value\":\"32000\",\"addr\":\"VirtualBurnGas\"}]},\"type\":\"Tx\",\"consensus\":7,\"txType\":4,\"data\":\"{\\\"TxInfo\\\":{\\\"BonusAddr\\\":\\\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\\\",\\\"delegateAmount\\\":1000000000000,\\\"delegateType\\\":\\\"Normal\\\"}}\"}","txType":"0","vrfJson":"{}"}}

```



### CreateUndelegatingTransaction

获取解投资交易信息

**参数**:

- fromAddr: 发起方地址
- toAddr:  被投资地址
- utxoHash： 投资的utxo哈希

- isFindUtxo: 是否全网探寻当前utxo的状态
- txInfo: 交易描述信息

**返回值**：

- code 返回值编号
  - 0：success
  
  - -1：Failed to get the current highest block height
  - -2：Check parameters failed 
  - -3：FromAddr is not normal addr.
  - -4：To address is not normal addr.
  - -5：The information entered exceeds the specified length
  - -6：FindUtxo failed
  - -7：Utxo is empty
  - -8：Tx owner is empty
  - -9：gas cannot be 0
  - -10：The total amount is less than expend
  - -11：get_block_packager error
  - -102：The account has not delegatinged assets to node
  - -103：getDelegatingAddrUtxoByBonusAddr failed
  - -104：The utxo to Undelegating is not in the utxos that have been delegatinged
  - -105：The delegatinged utxo is not more than 1 day
  - -106：Delegating tx not found
  - -107：Failed to parse transaction body
  - -108：The node to be Undelegatinged is not delegatinged
  - -109：The delegatinged value is zero
  
- message 返回值信息

- txJson: 交易体信息

- height:高度

- vrfJson: vrf信息

- txType:交易类型

- time: 发送交易的时间

- gas: 燃料费

```json
//req
{
    "id" : "1",
    "jsonrpc": "2.0",
    "params" : "{"fromAddr" : "69b34b7538DeB6913f2b9f59Cbc8610059442e5A","toAddr":"69b34b7538DeB6913f2b9f59Cbc8610059442e5A","utxoHash":"db2caaf71ff57ec954e67cabede4a4b2207fd8645e684e66983eaefea63f4e2a","isFindUtxo": false, "txInfo": ""}"
}

//ack
{"id":"1","jsonrpc":"2.0","method":"CreateUndelegatingTransaction","result":{"code":0,"gas":"45000","height":"591","message":"success","time":"1717146744611408","txJson":"{\"time\":\"1717146744611408\",\"identity\":\"3292FEAbea61A76cf59Fa917b9DCcC937Ca489eE\",\"utxo\":{\"owner\":[\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\",\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\"],\"vin\":[{\"prevOut\":[{\"hash\":\"3941c0cc427c3053222b9d1f32a2882a564e1ed3c45bcf59a48dc08c6eceb6e3\",\"n\":1}]},{\"prevOut\":[{\"hash\":\"3941c0cc427c3053222b9d1f32a2882a564e1ed3c45bcf59a48dc08c6eceb6e3\"}],\"sequence\":1}],\"vout\":[{\"value\":\"1000000000000\",\"addr\":\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\"},{\"value\":\"899899576300\",\"addr\":\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\"},{\"value\":\"45000\",\"addr\":\"VirtualBurnGas\"}]},\"type\":\"Tx\",\"consensus\":7,\"txType\":5,\"data\":\"{\\\"TxInfo\\\":{\\\"BonusAddr\\\":\\\"69b34b7538DeB6913f2b9f59Cbc8610059442e5A\\\",\\\"UndelegatingUtxo\\\":\\\"3941c0cc427c3053222b9d1f32a2882a564e1ed3c45bcf59a48dc08c6eceb6e3\\\"}}\"}","txType":"0","vrfJson":"{}"}}

```



### CreateBonusTransaction

获取申领交易信息

**参数**:

- Addr:  申领地址地址
- isFindUtxo:  是否全网探寻当前utxo的状态
- txInfo：交易描述信息

**返回值**：

- code 返回值编号
  
  - 0：success
  
  - -1：Failed to get the current highest block height
  - -2：Description Failed to obtain the balance of type X from the database based on the current type
  - -3：Description Failed to obtain the jump asset type
  - -4：Check parameters failed
  - -5：The bonus address is incorrect
  - -6：The information entered exceeds the specified length
  - -7：Failed to obtain the amount claimed by the delegatingor
  - -8：FindUtxo failed
  - -9：Utxo is zero
  - -10：Tx owner is empty
  - -11：GetCommissionPercentage error
  - -12：The gas charge cannot be 0
  - -13：The total cost = {} is less than the cost
  - -14：The claim amount is 0
  - -15：Extra Gas Trade Check parameters failed!
  - -16：Extra Gas Trade FindUtxo failed!
  - -17：Extra Gas Trade Utxo is empty
  - -18：Tx owner is empty!
  - -19：get_block_packager fail
  
- message 返回值信息

- txJson: 交易体信息

- height:高度

- vrfJson: vrf信息

- txType:交易类型

- time: 发送交易的时间

- gas: 燃料费

- assetType: 指定的申领类型

```json
//req
{
    "id" : "1",
    "jsonrpc": "2.0",
    "params" : "{"addr" : "116058AcF188BB96F9Da1317Bd11fD737E4f8Cd2","isFindUtxo": false, "txInfo": "","gasTrade": {"E6F00cFBd59cd8870D065Cde2Ffa0DE61eE1A529", "6f1eee7e83bed73cfe2cd9533c1fc795a4ee344984a0372479fab7635c44889a"},"isGasTrade":true,"assetType" = "6f1eee7e83bed73cfe2cd9533c1fc795a4ee344984a0372479fab7635c44889a"}"
}

//ack
{"id":"1","jsonrpc":"2.0","method":"CreateBonusTransaction","result":{"code":0,"gas":"25600","height":"597","message":"success","time":"1717147601683173","txJson":"{\"time\":\"1717147601683173\",\"identity\":\"08C08F389c8255c0B4d1C5e337C811D02F220B6e\",\"utxo\":{[{\"assetType\":\"X\",\"gasutxo\":0,\"multisign\":[{\"pub\":\"8BSO1z/899s8GDLyiXt4HOwY/gv98su/8GprEhoHiMznSrI83+KsfxmYYecWQNckYsuEw9O9dpisUgy1l1s1CQ==\",\"sign\":\"8BSO1z/899s8GDLyiXt4HOwY/gv98su/8GprEhoHiMznSrI83+KsfxmYYecWQNckYsuEw9O9dpisUgy1l1s1CQ==\"}],\"owner\":[\"0xE6F00cFBd59cd8870D065Cde2Ffa0DE61eE1A529\"],\"vin\":{\"prevout\":{\"hash\":[\"0x0251026fc24ec97263ec10728939bbb7846b7a2af5512589f1fa5311c957e5aa\"]},\"vinsign\":[{\"pub\":\"MCowBQYDK2VwAyEAgXxTSTyTVeggWtT5OKJlulf9z+vqIWIGRBs2JAS04rk=\",\"sign\":\"H/l5zCi+4f0MRFzBt7YHXsoQJWmkAT5bvM21jPrXtuGvZ9It0mzXlms+FwK4ZupzenMb8z5wAXD8/45E96GKBA==\"}]},\"vout\":[{\"addr\":\"0xE6F00cFBd59cd8870D065Cde2Ffa0DE61eE1A529\",\"value\":29504712329},{\"addr\":\"0xE6F00cFBd59cd8870D065Cde2Ffa0DE61eE1A529\",\"value\":298027397},{\"addr\":\"VirtualBurnGas\",\"value\":0}]},{\"assetType\":\"6f1eee7e83bed73cfe2cd9533c1fc795a4ee344984a0372479fab7635c44889a\",\"gasutxo\":1,\"multisign\":[{\"pub\":\"9EjMmQyNv9K+hVeoxV38XYjbqSRx8PRIvFi63G5ZB91GYSpgKECgGYFSFbI6g96V0mKBvSR6vzzVOZRcZfZDBA==\",\"sign\":\"9EjMmQyNv9K+hVeoxV38XYjbqSRx8PRIvFi63G5ZB91GYSpgKECgGYFSFbI6g96V0mKBvSR6vzzVOZRcZfZDBA==\"}],\"owner\":[\"0xE6F00cFBd59cd8870D065Cde2Ffa0DE61eE1A529\"],\"vin\":{\"prevout\":{\"hash\":[\"0x0251026fc24ec97263ec10728939bbb7846b7a2af5512589f1fa5311c957e5aa\"]},\"vinsign\":[{\"pub\":\"MCowBQYDK2VwAyEAgXxTSTyTVeggWtT5OKJlulf9z+vqIWIGRBs2JAS04rk=\",\"sign\":\"H/l5zCi+4f0MRFzBt7YHXsoQJWmkAT5bvM21jPrXtuGvZ9It0mzXlms+FwK4ZupzenMb8z5wAXD8/45E96GKBA==\"}]},\"vout\":[{\"addr\":\"0xE6F00cFBd59cd8870D065Cde2Ffa0DE61eE1A529\",\"value\":999913800},{\"addr\":\"VirtualBurnGas\",\"value\":25800}]}]},\"type\":\"Tx\",\"consensus\":7,\"txType\":99,\"data\":\"{\\\"TxInfo\\\":{\\\"BonusAddrList\\\":3,\\\"BonusAmount\\\":530410958}}\"}","txType":"0","vrfJson":"{}"}}

```

## 共治协议

### getAssetType

**说明**

获取所有提案类型

**参数**

* id 透传信息
* jsonrpc  json版本

**返回值**

- id 透传信息
- jsonrpc  json版本
- method 方法名称
- result 返回信息
  - code 返回值编号
    - 0	success
    - -1  Get asset type error
  - assertType  所有提案类型

```json
req:
{
    "id":"1",
    "jsonrpc":"2.0"
}

ack:
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "getAssetType",
  "result": {
    "assertType": [
      "0x44b90ac31b70805ced1f6c7884c0b8eb24b78b63689c6d3b19f42fbf11b28b6b",
      "0x416ba3e59614072c3bbdfb4f194fe71d248a7d82b1727f2d4ca51f8b4aba1528",
      "0xd3e8eba0d3eeae87c17c9ab2d4e42fa436374e111b631f71824e7a08ce2b03e8"
    ],
    "code": 0,
    "message": "success"
  }
}
```

------

### GetAssetTypeInfo

**说明**

根据提案类型获取提案信息

**参数**

* id 透传信息
* jsonrpc  json版本
* params
  * assetType  提案类型

**返回值**

- id 透传信息
- jsonrpc  json版本
- method 方法名称
- result 返回信息
  - code 返回值编号
    - 0	success
    - -1  Get asset info error
    - -2  Get revoke tx hash error
    - -3  Get revoke proposal info error
  - proposalInfo  提案相关信息(JSON格式)
    - BeginTime	  	 提案开始时间时间戳（微妙）
    - EndTime		 	 提案结束时间时间戳（微妙）
    - ContractAddr   	合约地址
    - ExchangeRate    汇率
    - ExpirationDate    提案有效期（目前为保留字段）
    - Name				  资产名称（Base64）
    - canBeStake		当前资产是否可用用于质押（是否为S资产）1：可用质押   0：不可以质押
    - MIN_VOTE_NUM       最小投票数量
    - Identifier              标识
    - Title				     标题
    - Version			    版本
  - revokeProposalInfo  该提案的撤销提案相关信息(JSON格式)
    - BeginTime           撤销提案开始时间时间戳（微妙）
    - EndTime			  撤销提案结束时间时间戳（微妙）
    - ProposalHash		  	   提案hash
    - RevokeProposalHash	 撤销提案hash
    - MIN_VOTE_NUM       最小投票数量
    - Version				版本

```json
req:
{
    "id":"1",
    "jsonrpc":"2.0",
    "params":{"assetType":"0c23a6a11119065dc9bd32197bda6aab58abf8f1519bddb4d8009f01da9830ee"}
}
ack:
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetAssetTypeInfo",
  "result": {
    "code": 0,
    "message": "success",
    "proposalInfo": "{\"BeginTime\":1740990051747766,\"canBeStake\":0,\"ContractAddr\":\"0x5f2ECcfd8dBA119832464ce93777ec770A4A617b\",\"EndTime\":1740990771747766,\"ExchangeRate\":\"1\",\"ExpirationDate\":18446744073709551615,\"Identifier\":\"MTEx\",\"MIN_VOTE_NUM\":1,\"Name\":\"Qg==\",\"Title\":\"MTE=\",\"Version\":0}",
    "revokeProposalInfo": [
      "{\"BeginTime\":1741141725928616,\"EndTime\":1741142445928616,\"MIN_VOTE_NUM\":4,\"ProposalHash\":\"0x0c23a6a11119065dc9bd32197bda6aab58abf8f1519bddb4d8009f01da9830ee\",\"RevokeProposalHash\":\"0x8028ec7742c3f7e7cbcf4e3deabc095770df6300a424d8cc44caaae2b582af07\",\"Version\":0}"
    ]
  }
}
```

------

### GetVoteTxHash

**说明**

获取提案或撤销提案类型的所有投票交易哈希

**参数**

* id 透传信息
* jsonrpc  json版本
* params
  * hash  提案类型hash或撤销提案类型hash

**返回值**

- id 透传信息
- jsonrpc  json版本
- method 方法名称
- result 返回信息
  - code 返回值编号
    - 0	success
    - -1   Get vote tx hash error

```json
req:
{
    "id":"1",
    "jsonrpc":"2.0",
    "params":{"hash":"0x416ba3e59614072c3bbdfb4f194fe71d248a7d82b1727f2d4ca51f8b4aba1528"}
}
ack:
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetVoteTxHash",
  "result": {
    "code": 0,
    "message": "success",
    "txHashs": [
      "0x414a16d5316448ea36775412defd79ec870150803575e0c53e12a11bc1c25d05"
    ]
  }
}
```

------

### GetVoteAddrs

**说明**

获取对应提案或撤销提案类型的所有投票地址

**参数**

* id 透传信息
* jsonrpc  json版本
* params
  * hash  提案类型hash或撤销提案类型hash

**返回值**

- id 透传信息
- jsonrpc  json版本
- method 方法名称
- result 返回信息
  - code 返回值编号
    -  0	success
    - -1   Asset Hash length error
    - -2   Get approve addrs error
    - -3   Get approve vote number error
    - -4   Get against addrs error
    - -5   Get approve vote number error
  - againstAddrs  投反对票地址和票数
  - approveAddrs 投赞成票地址和票数

```json
req:
{
    "id":"1",
    "jsonrpc":"2.0",
    "params":{"hash":"0xca5d5ceec91b03fcacfee34b42e5586d5dec6e4149a72feb63eb9adc71d68ba5"}
}
ack:
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetVoteAddrs",
  "result": {
    "againstAddrs": {},
    "approveAddrs": {
      "0xD38c2d3f4Ca4a4328f4367aF7B2790055C424eB7": 1
    },
    "code": 0,
    "message": "success"
  }
}
```

------

### createLockTransaction

**说明**

使用指定地址进行锁定，锁定金额当前为1000

**参数**：

* id 透传信息
* jsonrpc  json版本
* params 参数
  * LockType 锁定类型 默认为0
  * fromAddr 锁定地址
  * isFindUtxo 是否查询Utxo
  * isGasTrade 是否使用其他资产支付gas
  * gasTrade  支付gas的地址和资产名称
  * lockAmount 锁定金额
  * txInfo   交易描述信息

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  - code 返回值编号
    - 0	success
    - -1   db get top failed!
    - -2   Check parameters failed!
    - -3  From address invlaid
    - -4   The pledge amount error
    - -5  Unknown lock type! 
    - -6   The information entered exceeds the specified length
    - -7   There has been a lock transaction before !
    - -8   FindUtxo failed
    - -9   Utxo is empty
    - -10  Tx owner is invalid!
    - -11  gas = 0 !
    - -12  The total cost is less than the cost
    - -13  Check parameters failed
    - -14 FindUtxo failed
    - -15  Gas utxo is empty
    - -16  Tx owner is empty!
    - -17  Failed to get the packager
    - -18  LockAmount format error
  - height  高度
  - time     交易时间
  - txJson  交易体

```json
req:
{
    "id": "",
    "jsonrpc": "",
    "params": {
        "LockType": "0",
        "fromAddr": "0x3CD050678178A3029E7436A661694237589AF868",
        "gasTrade": [
            "0x3CD050678178A3029E7436A661694237589AF868",
            "6f1eee7e83bed73cfe2cd9533c1fc795a4ee344984a0372479fab7635c44889a"
        ],
        "isFindUtxo": false,
        "isGasTrade": true,
        "lockAmount": "1000",
        "txInfo": ""
    }
}
ack:
{
  "id": "",
  "jsonrpc": "",
  "method": "createLockTransaction",
  "result": {
    "code": 0,
    "gas": "",
    "height": "1046",
    "message": "success",
    "time": "1741081616280062",
    "txJson": "{\"time\":\"1741081616280062\",\"identity\":\"3CD050678178A3029E7436A661694237589AF868\",\"type\":\"Tx\",\"consensus\":7,\"txType\":9,\"data\":\"{\\\"TxInfo\\\":{\\\"LockAmount\\\":100000000000,\\\"LockType\\\":\\\"LockNet\\\"}}\",\"utxos\":[{\"owner\":[\"3CD050678178A3029E7436A661694237589AF868\"],\"vin\":[{\"prevOut\":[{\"hash\":\"9056df2e966eaee88499effc3d5976c6a4534a23335daf81c2b9501d26be47b1\"}]}],\"vout\":[{\"value\":\"100000000000\",\"addr\":\"LockVirtualStake\"},{\"value\":\"32575342465\",\"addr\":\"3CD050678178A3029E7436A661694237589AF868\"},{\"addr\":\"VirtualBurnGas\"}],\"assetType\":\"X\"},{\"owner\":[\"3CD050678178A3029E7436A661694237589AF868\"],\"vin\":[{\"prevOut\":[{\"hash\":\"f6bf68016abb9927be848021ce8e0eccefa2bde96ae062896fee682dd0a46820\"}]}],\"vout\":[{\"value\":\"80001999907200\",\"addr\":\"3CD050678178A3029E7436A661694237589AF868\"},{\"value\":\"26000\",\"addr\":\"VirtualBurnGas\"}],\"assetType\":\"6f1eee7e83bed73cfe2cd9533c1fc795a4ee344984a0372479fab7635c44889a\",\"GasUtxo\":\"1\"}],\"gasTx\":1}",
    "txType": "1",
    "vrfJson": "{}"
  }
}
```

------

### GetLockUtxo

**说明**

获取对应地址的锁定utxo哈希

**参数**

* id 透传信息
* jsonrpc  json版本
* params 参数
  * fromAddr  查询地址

**返回值**

- id 透传信息
- jsonrpc  json版本
- method 方法名称
- result 返回信息
  - code 返回值编号
    - 0	success
    - -1   fromaddr not lock!
    - -2   get transaction error
    - -3   parse transaction error
  - utxos  锁定 utxo hash 和 锁定金额

```json
req:
{
    "id": "1",
    "jsonrpc": "2.0",
    "params": {
        "fromAddr": "0xffFd42e045737b11570B7981c2648ea532a10B23"
    }
}
ack:
{
  "id": "1",
  "jsonrpc": "2.0",
  "method": "GetLockUtxo",
  "result": {
    "code": 0,
    "message": "success",
    "utxos": [
      "70da8e27db29177361514726446b5689ad318ba926530958e777ac5657ec5236",
      100000000000
    ]
  }
}
```

------

### createUnlockTransactionRequest

**说明**：

对指定地址进行解锁定操作

**参数**：

* id 透传信息
* jsonrpc  json版本
* params 参数
  * fromAddr 锁定地址
  * utxoHash 解锁定时的utxo
  * isFindUtxo 是否查询Utxo
  * isGasTrade 是否使用其他资产支付gas
  * gasTrade  支付gas的地址和资产名称
  * txInfo  交易描述信息

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  - code 返回值编号
    - 0	success
    - -1   db get top failed!
    - -2   The information entered exceeds the specified length
    - -3   Check parameters failed
    - -4   FromAddr is not normal  addr
    - -5   FromAddr is not qualified to unlock
    - -6   FindUtxo failed
    - -7   Utxo is empty
    - -8   Tx owner is empty
    - -9   gas = 0
    - -10  The total cost  is less than the cost
    - -11  Check parameters failed
    - -12  FindUtxo failed
    - -13  Utxo is empty
    - -14  Tx owner is empty
    - -15  get_block_packager error
  - height  高度
  - time     交易时间
  - txJson  交易体

```json
req:
{
    "id": "1",
    "jsonrpc": "2,0",
    "method": "",
    "params": {
        "fromAddr": "0x3CD050678178A3029E7436A661694237589AF868",
        "gasTrade": [
            "0x3CD050678178A3029E7436A661694237589AF868",
            "6f1eee7e83bed73cfe2cd9533c1fc795a4ee344984a0372479fab7635c44889a"
        ],
        "isFindUtxo": false,
        "isGasTrade": false,
        "txInfo": "",
        "utxoHash": "8d9253fb2ecfe3e8ff698de172a396739d70208fb07ad7bf9e0b0385ed987bf5"
    }
}

ack:
{
  "id": "1",
  "jsonrpc": "2,0",
  "method": "createUnlockTransactionRequest",
  "result": {
    "code": 0,
    "gas": "",
    "height": "1070",
    "message": "success",
    "time": "1741154556596941",
    "txJson": "{\"time\":\"1741154556596941\",\"identity\":\"C776F881bC6c6763821f3e3b3c1E2625B522ee0d\",\"type\":\"Tx\",\"consensus\":7,\"txType\":10,\"data\":\"{\\\"TxInfo\\\":{\\\"UnLockUtxo\\\":\\\"8d9253fb2ecfe3e8ff698de172a396739d70208fb07ad7bf9e0b0385ed987bf5\\\"}}\",\"utxos\":[{\"owner\":[\"3CD050678178A3029E7436A661694237589AF868\",\"3CD050678178A3029E7436A661694237589AF868\"],\"vin\":[{\"prevOut\":[{\"hash\":\"8d9253fb2ecfe3e8ff698de172a396739d70208fb07ad7bf9e0b0385ed987bf5\",\"n\":1}]},{\"prevOut\":[{\"hash\":\"8d9253fb2ecfe3e8ff698de172a396739d70208fb07ad7bf9e0b0385ed987bf5\"}],\"sequence\":1}],\"vout\":[{\"value\":\"10000000000\",\"addr\":\"3CD050678178A3029E7436A661694237589AF868\"},{\"value\":\"32575237865\",\"addr\":\"3CD050678178A3029E7436A661694237589AF868\"},{\"value\":\"39200\",\"addr\":\"VirtualBurnGas\"}],\"assetType\":\"X\"}]}",
    "txType": "1",
    "vrfJson": "{}"
  }
}
```

------

### CreateVoteTransaction

**说明**：

对指定提案类型或撤销提案类型投票

**参数**：

* id 透传信息
* jsonrpc  json版本
* params 参数
  * fromAddr 投票地址
  * gasTrade  支付gas的地址和资产名称
  * isFindUtxo 是否查询Utxo
  * pollType  投票类型 0为反对票，1为赞成票
  * voteHash  提案类型或撤销提案类型hash
  * voteTxType  投票类型 11为提案类型  12为撤销提案类型
  * txInfo  交易描述信息

**返回值**：

* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  - code 返回值编号
    - 0	success
    - -1   db get top failed!
    - -2   The information entered exceeds the specified length
    - -3   FromAddr is not normal addr
    - -4   Check parameters failed
    - -5   FromAddr is not qualified to unlock
    - -6   Check vote tx info error
    - -7   FindUtxo failed!
    - -8   Utxo is empty
    - -9  Tx owner is empty
    - -10  gas = 0
    - -11  The total cost is less than the cost
    - -12  Find block packager error
  - height  高度
  - time     交易时间
  - txJson  交易体

```json
req:
{
    "id": "",
    "jsonrpc": "",
    "method": "",
    "params": {
        "fromAddr": "0x3CD050678178A3029E7436A661694237589AF868",
        "gasTrade": [
            "0x3CD050678178A3029E7436A661694237589AF868",
            "556fc975c75073a7a76acc4990d0b68d79f97af971674ccb9b2d46d61d76ae1b"
        ],
        "isFindUtxo": false,
        "pollType": "1",
        "txInfo": "",
        "voteHash": "6df465a89c945f1a2ca5b429c8a2f3e656920c26d39026e122a01ecf9de998c6",
        "voteTxType": "11"
    }
}

ack:
{
  "id": "",
  "jsonrpc": "",
  "method": "CreateVoteTransaction",
  "result": {
    "code": 0,
    "gas": "",
    "height": "1070",
    "message": "success",
    "time": "",
    "txJson": "{\"time\":\"1741154374038148\",\"identity\":\"C776F881bC6c6763821f3e3b3c1E2625B522ee0d\",\"type\":\"Tx\",\"consensus\":7,\"txType\":13,\"data\":\"{\\\"TxInfo\\\":{\\\"VoteHash\\\":\\\"6df465a89c945f1a2ca5b429c8a2f3e656920c26d39026e122a01ecf9de998c6\\\",\\\"VoteTxType\\\":11,\\\"VoteType\\\":1}}\",\"utxos\":[{\"owner\":[\"3CD050678178A3029E7436A661694237589AF868\"],\"vin\":[{\"prevOut\":[{\"hash\":\"6367c45ba4c30b72acd493e36c863547e80b131cda2473f3c956f3b34d2eea8a\"}]}],\"vout\":[{\"value\":\"29999936200\",\"addr\":\"3CD050678178A3029E7436A661694237589AF868\"},{\"value\":\"28700\",\"addr\":\"VirtualBurnGas\"}],\"assetType\":\"556fc975c75073a7a76acc4990d0b68d79f97af971674ccb9b2d46d61d76ae1b\",\"GasUtxo\":\"1\"}],\"gasTx\":1}",
    "txType": "1",
    "vrfJson": "{}"
  }
}
```

### CreateFundTransaction

**描述**：

接受国库的天然气奖励

**参数**：

* id 透传信息
* jsonrpc  json版本
* params 参数
  * fromAddr 接受奖励地址
  * isFindUtxo 是否寻找utxo
  * txInfo  交易信息

**返回值**：



  - height   Height
  - time     transaction time 
  - txJson   transaction json
* id 透传信息
* jsonrpc  json版本
* method 方法名称
* result 返回信息
  - code 返回值编号
    - 0	success
    - -1   db get top failed!
    - -2   The information entered exceeds the specified length
    - -3   Default is not normal  addr.
    - -4   Get available asset fail!
    - -5   GetGasamountbyTimeType error!
    - -6   Nodes are not eligible to claim fund
    - -7   Sign Utxo fail!
    - -8   Utxo is empty
    - -9  Tx owner is empty
    - -10  gas = 0
    - -11  The total cost is less than the cost
    - -12  Find block packager error
    - -13  fetchIdentityNodes fail!!! ret
  - height  高度
  - time     交易时间
  - txJson  交易体



```json
req:
{
    "id": "",
    "jsonrpc": "",
    "method": "",
    "params": {
        "fromAddr": "0x3CD050678178A3029E7436A661694237589AF868",
        "isFindUtxo": false,
        "txInfo": ""
    }
}

ack:
{
  "id": "",
  "jsonrpc": "",
  "method": "CreateFundTransaction",
  "result": {
    "code": 0,
    "gas": "",
    "height": "1070",
    "message": "success",
    "time": "",
    "txJson": "{\"time\":\"1741154374038148\",\"identity\":\"C776F881bC6c6763821f3e3b3c1E2625B522ee0d\",\"type\":\"Tx\",\"consensus\":7,\"txType\":13,\"data\":\"{\\\"TxInfo\\\":{\\\"FundLockedAmount\\\":\\\"31000\\\",\\\"FundPackageAmount\\\":23,}}\",\"utxos\":[{\"owner\":[\"3CD050678178A3029E7436A661694237589AF868\"],\"vin\":[{\"prevOut\":[{\"hash\":\"6367c45ba4c30b72acd493e36c863547e80b131cda2473f3c956f3b34d2eea8a\"}]}],\"vout\":[{\"value\":\"29999936200\",\"addr\":\"3CD050678178A3029E7436A661694237589AF868\"},{\"value\":\"28700\",\"addr\":\"VirtualBurnGas\"}],\"assetType\":\"556fc975c75073a7a76acc4990d0b68d79f97af971674ccb9b2d46d61d76ae1b\",\"GasUtxo\":\"1\"}],\"gasTx\":1}",
    "txType": "1",
    "vrfJson": "{}"
  }
}
```


## 交易信息描述

- Consensus:  共识数量
- identity:  打包者
- time：交易时间
- txHash：交易hash
- type：默认字段为 Tx
- utxo
  - multisign：utxo的签名
    - pub：公钥base64
    - sign：签名base64
  - owner：交易的发起方
  - vin
    - prevout
      - hash：vin的交易hash
    - vinsign：vin的签名
      - pub：公钥base64
      - sign：签名base64
  - vout
    - addr ：转账的目标账号
    - value ：转账金额
- verifySign ：交易签名信息
  - pub：公钥base64
  - sign：签名base64
  - signaddr：签名节点的地址
- txType：交易类型
  - 0：未知交易类型
  - 1：转账交易
  - 2：质押交易
  - 3：解质押交易
  - 4：投资
  - 5：解投资交易
  - 7：部署合约
  - 8：执行合约
  - 99：申领交易
- data
  - 质押交易
    - TxInfo 质押交易信息
      - CommissionRate：抽水比例
      - StakeAmount：质押金额
      - StakeType：质押类型，默认为Net
  - 解质押交易
    - TxInfo 解质押交易信息
      - UnstakeUtxo：质押交易的utxo
  - 投资交易
    - TxInfo 投资交易信息
      - BonusAddr：投资地址
      - delegateAmount：投资金额
      - delegateType：投资类型，默认为Normal
  - 解投资交易
    - TxInfo 解投资交易信息
      - BonusAddr：投资地址
      - UndelegatingUtxo：投资utxo
  - 申领交易
    - TxInfo 申领交易信息
      - BonusAddrList：申领地址数量
      - BonusAmount：申领金额
  - 部署合约
    - TxInfo  部署合约信息
      - blockPrevRandao：根据交易的vin计算出的随机数
      - blockTimestamp：合约块时间戳（秒为单位）
      - input：合约二进制码
      - recipient：消息的发送者
      - sender：消息的接收者
      - version：版本
      - virtualMachine：虚拟机
        - EVM：0
        - WASM：1
  - 执行合约
    - TxInfo  执行合约信息
      - blockPrevRandao：根据交易的vin计算出的随机数
      - blockTimestamp：合约块时间戳（秒为单位）
      - contractDeployer：部署合约地址
      - donation：给合约部署人的小费
      - input：执行合约的参数
      - recipient：消息的发送者
      - sender：消息的接收者
      - transfer：转给合约的钱
      - version：版本
      - virtualMachine：虚拟机
        - EVM：0
        - WASM：1

## 块信息描述

- blocksign:  块流转签名
  - pub:  公钥base64
  - sign：签名base64
  - signaddr：签名地址
- bytes：块大小
- hash：块hash
- height：块高度
- merkleroot：默克尔根
- prevhash：前置块hash
- tx：交易信息
- data
  - 部署合约
    - 交易hash
      - creation：合约内创建的合约
      - dependentCTx：合约的依赖关系
      - output：部署合约的二进制码
      - preHash：合约的前置hash
      - storage：storage
  - 执行合约
    - 交易hash
      - creation：合约内创建的合约
      - dependentCTx：合约的依赖关系
      - destruction：销毁的合约
      - log
        - creator：生成log的合约地址
        - data：date
        - topics：topics
      - output：合约的输出
      - preHash：合约的前置hash
      - storage：storage



