# 排除特定测试
./bin/test_main --gtest_filter=-RpcPerfTest.EthBlockNumber_All_QPS_Levels

# 运行所有测试除了性能测试
./bin/test_main --gtest_filter=-RpcPerfTest.*

# 运行所有包含 QPS 的测试
./bin/test_main --gtest_filter=*QPS*

# 运行所有包含 Get 的 API 测试
./bin/test_main --gtest_filter=PostApiTest.Get*

# 运行多个指定测试（用冒号分隔）
./bin/test_main --gtest_filter=RpcPerfTest.EthBlockNumber_QPS_100:RpcPerfTest.EthBlockNumber_QPS_200

# 运行所有 API 测试
./bin/test_main --gtest_filter=PostApiTest.*

# 运行所有性能测试
./bin/test_main --gtest_filter=RpcPerfTest.*

# 运行指定的单个测试
./bin/test_main --gtest_filter=RpcPerfTest.EthBlockNumber_QPS_100

# 运行 API 测试中的单个测试
./bin/test_main --gtest_filter=PostApiTest.GetBalance

# 运行所有测试
cd /root/mm/build
make test

# 运行特定测试二进制文件
./bin/test_main