# 存储层

版本: v0.0.1 | 更新日期: 2026-06-17

---

## 概述

OpenHive 使用 **RocksDB** 作为持久化存储引擎，采用 `TransactionDB` 模式支持多键原子事务。智能合约状态通过 **MPT（Merkle Patricia Trie）** 存储，MPT 源自 Aleth（Ethereum C++ client）实现，但使用 SHA256 替代 Keccak256 作为哈希函数。

节点采用全账本存储架构，完整保留每个区块生成时的全局状态快照，构建可追溯的链式校验机制。通过 Merkle 树索引实现历史数据的快速定位与完整性验证。所有节点均部署分布式数据库（RocksDB），确保任意单点故障不影响历史数据可用性。

---

## 1. 存储架构

```mermaid
graph TB
    subgraph DBLayer["存储分层架构"]
        API["DB API（高层接口）<br/>getBlockByBlockHash()<br/>getBalanceByAddr()<br/>getTransactionByHash()<br/>..."]
        RW["DBReader / DBReadWriter<br/>读写分离 · 事务支持"]
        RDB["RocksDB TransactionDB<br/>原子性保证 · 并发控制 · WAL 持久化"]
    end

    API --> RW
    RW --> RDB

    subgraph MPTLayer["MPT 状态存储"]
        TRIE["Trie 类<br/>Get / Insert / Update / Commit / Save"]
        RLP["RLP 编码<br/>节点序列化"]
        CACHE["contractDataContainer<br/>内存缓存"]
    end

    TRIE --> RLP
    TRIE --> CACHE
    TRIE --> RW
```

### RocksDB TransactionDB 特性

| 特性 | 说明 |
|------|------|
| **原子性** | 多键写入要么全部成功，要么全部回滚 |
| **并发控制** | 行级锁（`readForUpdate`），支持并发读写 |
| **WAL 持久化** | Write-Ahead Log 确保崩溃恢复 |
| **后台错误监听** | `BackgroundErrorListener` 捕获存储引擎异常 |

---

## 2. 数据模型（Key 前缀体系）

RocksDB 以键值对形式存储所有数据，通过 **Key 前缀** 区分不同数据类型。共 37 种前缀，按领域分组如下：

### 2.1 区块相关

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `BH:{height}` | `vector<blockHash>` | 高度→区块哈希列表（支持分叉，同一高度可多个区块） |
| `B:{blockHash}` | `blockRaw` | 区块序列化数据（Protobuf） |
| `SH:{height}` | `sumHash` | 高度→汇总哈希（每 100 区块计算） |
| `TH:{thousandNum}` | `thousandSumHash` | 千区块汇总哈希（每 1000 区块） |
| `TOP` | `blockHeight` | 当前最高区块高度 |

### 2.2 交易相关

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `TX:{txHash}` | `txRaw` | 交易序列化数据 |
| `TXBH:{txHash}` | `blockHash` | 交易所在区块哈希 |

### 2.3 UTXO 与余额

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `UB:{addr}:{assetType}:{utxoHash}` | `balance` | UTXO 余额 |
| `UAH:{addr}:{assetType}` | `vector<utxoHash>` | 地址 UTXO 哈希列表 |
| `BAL:{addr}:{assetType}` | `balance` | 地址余额 |
| `ASSET` | `vector<assetType>` | 所有已注册资产类型 |

### 2.4 质押与委托

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `STAKE_ADDR` | `vector<address>` | 所有质押地址 |
| `STAKE:{addr}:{assetType}` | `vector<utxo>` | 质押 UTXO 列表 |
| `DELEG:{bonusAddr}:{delegatingAddr}:{assetType}` | `vector<utxo>` | 委托关系 |
| `DELEG_ADDR` | `vector<address>` | 所有委托地址 |

### 2.5 合约相关

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `EVM_DEPLOYER` | `vector<deployerAddr>` | 所有合约部署者地址 |
| `EVM_CODE:{contractAddr}` | `contractCode` | 合约字节码 |
| `EVM_DEPLOY:{deployerAddr}` | `vector<contractAddr>` | 部署者→合约地址列表 |
| `EVM_UTXO:{contractAddr}` | `contractDeploymentUtxo` | 合约部署 UTXO |
| `EVM_LATEST_UTXO:{contractAddr}` | `utxo` | 合约最新 UTXO |
| `MPT:{mptKey}` | `mptValue` | MPT 状态节点数据 |
| `EVM_ASSET:{contractAddr}` | `assetType` | 合约资产类型 |

### 2.6 共识与统计

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `SIGN:{period}:{address}` | `signCount` | 周期内节点签名数 |
| `BLOCK_NUM:{period}` | `blockNumber` | 周期内区块数量 |
| `SIGN_ADDR:{period}` | `vector<address>` | 周期内签名地址列表 |
| `BURN:{period}` | `burnAmount` | 周期内 Gas 销毁数量 |
| `PACKAGER` | `packagerCount` | 打包次数统计 |

### 2.7 投票与提案

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `APPROVE:{assetType}` | `set<address>` | 赞成地址集合 |
| `AGAINST:{assetType}` | `set<address>` | 反对地址集合 |
| `VOTE_TX:{assetType}` | `vector<txHash>` | 投票交易哈希列表 |
| `PROPOSAL:{assetType}` | `proposalInfo` | 提案信息 |
| `REVOKE:{assetType}` | `revokeInfo` | 撤销提案信息 |
| `VOTE_CNT:{assetType}` | `{approve, against}` | 投票计数 |
| `VOTE_ADDR:{addr}:{assetType}` | `voteCount` | 地址投票数 |
| `VOTE_TOTAL:{assetType}` | `totalVoters` | 投票者总数 |

### 2.8 锁定

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `LOCK_ADDR` | `vector<address>` | 所有锁定地址 |
| `LOCK_UTXO:{addr}:{assetType}` | `vector<utxo>` | 锁定 UTXO 列表 |

### 2.9 惩罚相关

| 前缀 | 数据类型 | 示例 |
|------|---------|------|
| `evidence_on_chain_` | 举证交易上链记录 | `evidence_on_chain_{hash}` |
| `evidence_count_` | 举证计数索引 | `evidence_count_{addr}:{type}` |
| `evidence_threshold_` | 达到惩罚阈值的节点 | `evidence_threshold_{addr}` |
| `punishment_history_` | 惩罚执行历史 | `punishment_history_{addr}` |
| `slash_jail_` | Jailing 状态 | `slash_jail_{addr}` |
| `slash_tombstone_` | 永久除名记录 | `slash_tombstone_{addr}` |
| `slash_vrf_fail_` | VRF 签名失败记录 | `slash_vrf_fail_{addr}:{period}` |
| `slash_disconnect_` | 心跳断开计数 | `slash_disconnect_{addr}:{hour}` |
| `slash_lastactive_` | 节点最后活跃周期 | `slash_lastactive_{addr}` |
| `slash_l3count_` | L3 扣减次数 | `slash_l3count_{addr}` |

---

## 3. 事务支持

### 3.1 读写分离模式

OpenHive 的数据库访问层采用读写分离设计：

```mermaid
classDiagram
    class DBReader {
        +getBlockTop(height)
        +getBlockByBlockHash(hash)
        +getTransactionByHash(hash)
        +getBalanceByAddr(addr, asset)
        +getStakeAddr(addresses)
        +getContractCode(addr)
        +getMptValue(key)
        ...60+ 查询方法
    }

    class DBReadWriter {
        +put(key, value)
        +delete(key)
        +readForUpdate(key) 
        +commit()
        +rollback()
    }

    DBReader <|-- DBReadWriter
```

| 类 | 用途 | 说明 |
|------|------|------|
| `DBReader` | 只读查询 | 无事务开销，适用于纯读取场景 |
| `DBReadWriter` | 读写操作 | 开启事务，支持原子提交或回滚 |

### 3.2 行级锁

`readForUpdate(key)` 方法在读取数据时获取行级锁，防止并发写入冲突。适用于需要先读后写的场景（如余额更新）。

---

## 4. 高度汇总与校验

### 4.1 Sum Hash

每 **100 个区块** 计算一次汇总哈希，用于快速同步和分叉检测：

```
sumHash(height) = SHA256(SHA256(blockHash_{h-99}) || ... || SHA256(blockHash_h))
```

存储位置：`SH:{height}` → `sumHash`

### 4.2 千区块汇总

每 **1000 个区块** 对 sumHash 再做一次 SHA256 汇总：

```
thousandSumHash(n) = SHA256(sumHash(n×1000-999) || ... || sumHash(n×1000))
```

存储位置：`TH:{thousandNum}` → `thousandSumHash`

```mermaid
graph LR
    subgraph BlockRange["区块 1-100"]
        B1[B₁] ~~~ B100[B₁₀₀]
    end
    B100 -->|SHA256| SH1[sumHash₁₀₀]

    subgraph BlockRange2["区块 101-200"]
        B101[B₁₀₁] ~~~ B200[B₂₀₀]
    end
    B200 -->|SHA256| SH2[sumHash₂₀₀]

    SH1 ~~~ SH2

    SH2 -->|每 1000 块| TH[thousandSumHash]
```

### 4.3 用途

| 场景 | 使用的哈希 | 说明 |
|------|-----------|------|
| 快速同步 | Sum Hash | 验证区块数据完整性 |
| 分叉检测 | Sum Hash | 比对本地与远程节点的汇总哈希 |
| 深度校验 | 千区块汇总 | 更高层级的完整性验证 |

---

## 5. 回滚机制

当检测到更优分叉或数据异常时，系统支持回滚到指定高度：

```mermaid
flowchart TD
    A[触发回滚] --> B[从当前 top 向下遍历]
    B --> C[对每个区块调用 DeleteBlock]
    C --> D[删除区块数据]
    C --> E[删除交易数据]
    C --> F[恢复 UTXO 到未消费状态]
    D --> G[更新 TOP 高度]
    E --> G
    F --> G
```

**回滚保护**：
- 回滚超时：15 秒（`RollBackTime`），超过此时间的区块不再回滚
- 快速同步回滚高度差限制：10 块
- 快速同步最大重试：5 次，超过后切换到从零同步

---

## 6. MPT（Merkle Patricia Trie）实现

### 6.1 概述

MPT 用于存储智能合约状态，源自 **Aleth**（Ethereum C++ client）的实现。每个合约拥有独立的 MPT 实例，根哈希存储在 RocksDB 中。

### 6.2 节点类型

| 节点类型 | 结构 | 说明 |
|---------|------|------|
| `HashNode` | `data: string` | 哈希引用节点，存储子节点的 SHA256 哈希值 |
| `ValueNode` | `data: string` | 值节点，存储实际数据 |
| `ShortNode` | `key, value, flags` | 短节点（带 key 前缀），用于压缩路径（路径优化） |
| `FullNode` | `children[17], flags` | 全节点（16 个 nibble 子节点 + 1 个 value） |

`NodeFlag` 包含：
- `hash`: 节点哈希值（HashNode）
- `dirty`: 脏标志，表示节点是否被修改

```mermaid
graph TB
    subgraph MPTStructure["MPT 节点结构"]
        FN["FullNode<br/>16 子节点 + 1 value"]
        SN["ShortNode<br/>key 前缀 + 子节点"]
        VN["ValueNode<br/>叶子值"]
        HN["HashNode<br/>哈希引用"]
    end

    FN -->|nibble 0| SN
    FN -->|nibble 1| HN
    FN -->|...| FN2["FullNode"]
    SN -->|压缩路径| VN
    HN -->|延迟加载| FN3["从 DB 加载"]
```

### 6.3 核心操作

| 操作 | 说明 |
|------|------|
| `Get(key)` | 查找键对应的值 |
| `Insert(node, prefix, key, value)` | 插入键值对，返回更新后的节点 |
| `Update(key, value)` | 更新键值对（内部调用 Insert） |
| `Commit(node)` | 提交脏节点，计算哈希 |
| `Save()` | 将脏节点持久化到 RocksDB |

### 6.4 哈希计算

```
ToHash(node):
  1. Encode(node) → RLP 序列化
  2. RLP 字节 → 十六进制字符串
  3. hash = SHA256(hexString)
  4. 返回 HashNode{hash}
```

> **关键差异**：使用 **SHA256** 而非以太坊的 Keccak256。

### 6.5 RLP 编码

节点序列化规则：

| 节点类型 | RLP 格式 |
|---------|---------|
| `ShortNode` | `RLP([key, Encode(value)])` — 2 元素列表 |
| `FullNode` | `RLP([c0, c1, ..., c15, c16])` — 17 元素列表 |
| `ValueNode` | `RLP(data)` |
| `HashNode` | `RLP(hash)` |

空子节点编码为空字符串 `""`。

### 6.6 Key 处理

- **终止符标记**：Key 末尾添加 `'z'` 字符标记叶子节点
  - `wrapperKey(key) = key + key.back() + 'z'`
  - `HasTerm(s)`: 检查字符串是否以 `'z'` 结尾
- **Hex 转换**：`HexToKeybytes(hex)` 将十六进制字符串转换为字节数组

### 6.7 存储格式

MPT 节点存储在 RocksDB 中：

| Key 模式 | Value | 说明 |
|---------|-------|------|
| `{contractAddr}_{hash}` | `RLP encoded node (hex)` | MPT 节点数据 |

**存储流程**：
1. `Commit(node)` 计算节点哈希，将脏节点加入 `dirtyHash` 映射
2. `Save()` 遍历 `dirtyHash`，通过 `DBWriter` 写入 RocksDB
3. 更新合约的 MPT 根哈希

### 6.8 加载流程

```mermaid
flowchart TD
    A["Trie(roothash, contractAddr)"] --> B["创建 HashNode{roothash}"]
    B --> C["ResolveHash 加载根节点"]
    C --> D{"contractDataStorage<br/>缓存命中?"}
    D -->|是| E["从内存缓存获取 RLP 数据"]
    D -->|否| F["从 RocksDB 获取 RLP 数据"]
    E --> G["DecodeNode 反序列化为节点树"]
    F --> G
```

---

## 7. 与以太坊 MPT 的差异

| 特性 | OpenHive MPT | 以太坊 MPT |
|------|-------------|-----------|
| **哈希函数** | SHA256 | Keccak256 |
| **终止符标记** | `'z'` 字符 | nibble 编码（16/17） |
| **存储 Key** | `{contractAddr}_{hash}` | `SHA3(RLP(node))` |
| **节点缓存** | `contractDataContainer`（内存） | Trie cache |
| **来源** | Aleth（Ethereum C++ client）修改 | 原生实现 |

---

## 8. 合约状态存储

每个智能合约拥有独立的 MPT 实例：

```
合约地址 → MPT Root Hash → {storage_key: storage_value}
```

- MPT 根哈希存储在 RocksDB 中
- 状态变更通过 MPT 操作（Insert/Update）持久化
- 合约交易的 MPT 状态加载需经过根哈希验证（详见 [EVM 兼容性](05-evm-compatibility.md)）

---

## 参考资料

- [协议规范 — §8 存储层](../spec/spec_dev.md)
- [协议规范 — 附录 C 数据库 Key 前缀规范](../spec/spec_dev.md)
- [协议规范 — §8.7 MPT 实现](../spec/spec_dev.md)

---

**本轮修订摘要**：
- 模块名称：存储层
- 处理方式：新增（旧 wiki 仅有数据存储层概述，无技术细节）
- 新增术语：RocksDB TransactionDB, Key 前缀, Sum Hash, 千区块汇总, MPT, HashNode, ValueNode, ShortNode, FullNode, RLP, readForUpdate
- 待确认问题：无
- 下一步计划：08-network.md — 网络层
