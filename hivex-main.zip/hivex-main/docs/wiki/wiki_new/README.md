# OpenHive Wiki

版本: v0.0.1 | 更新日期: 2026-06-17

---

欢迎来到 **OpenHive** 项目文档。OpenHive 是一条采用 DAG 区块引用结构和 VRF PoS 共识机制的公链，原生支持 UTXO 模型并兼容以太坊 EVM，面向开发者提供高性能、低成本的智能合约部署环境。

---

## 文档目录

### 入门

| 章节 | 说明 |
|------|------|
| [入门指南](01-getting-started.md) | 项目简介、核心优势、快速开始 |

### 核心概念

| 章节 | 说明 |
|------|------|
| [架构设计](02-architecture.md) | 分层模型、DAG 结构、UTXO + 账户混合模型 |
| [共识机制](03-consensus.md) | VRF PoS、准入池、打包节点选择、分叉处理 |
| [账户模型](04-account-model.md) | 地址生成、精度系统、三层资产体系 |
| [EVM 兼容性](05-evm-compatibility.md) | evmone 集成、Gas 差异、预编译合约、ETH RPC |
| [交易与特殊功能](06-transactions.md) | 交易类型、质押/投资/投票/提案/奖励 |

### 基础设施

| 章节 | 说明 |
|------|------|
| [存储层](07-storage.md) | RocksDB、MPT、Key 前缀规范 |
| [网络层](08-network.md) | P2P 架构、ECDH 加密、同步机制、NTP |

### 开发者指南

| 章节 | 说明 |
|------|------|
| [节点部署](09-node-deployment.md) | 编译、配置、启动、网络类型 |
| [RPC 接口](10-api-rpc.md) | 自定义 JSON-RPC 与 ETH 兼容接口 |

### 治理与经济

| 章节 | 说明 |
|------|------|
| [治理机制](11-governance.md) | 提案/投票/撤销、跨链资产治理 |
| [经济模型](12-economic-model.md) | 代币经济学、年化率、奖励分配、Gas 机制 |

### 附录

| 章节 | 说明 |
|------|------|
| [安全考虑](13-security.md) | 协议不变量、攻击缓解、已知限制 |
| [术语表](14-glossary.md) | 核心术语定义 |
| [版本历史](15-version-history.md) | 文档版本记录 |

---

## 快速链接

- **协议规范**: [spec_dev.md](../spec/spec_dev.md)
- **RPC 接口文档**: [GET 接口](../rpc/rpc_api_get_doc.md) | [POST 接口](../rpc/rpc_api_post_doc.md)
- **钱包教程**: [MetaMask](../wallet/metamusk&&OK/metamusk/MetaMask.md) | [Remix IDE](../wallet/metamusk&&OK/remix/remix.md) | [币安钱包](../wallet/metamusk&&OK/bian/bian.md) | [OKX 钱包](../wallet/metamusk&&OK/OK/OK.md)

---

## 关键参数速览

| 参数 | 值 |
|------|------|
| 共识机制 | VRF PoS（15 秒周期） |
| 最小共识节点数 | 3 |
| 最小质押量 | 3,500 OHI |
| 最小投资额 | 500 OHI |
| 区块 Gas 上限 | 30,000,000 |
| Chain ID | 0x3027 (12315) |
| EVM 版本 | evmone v0.14.1 / Cancun |
| 存储引擎 | RocksDB TransactionDB |
| 状态树 | MPT（SHA256） |
| 网络加密 | ECDH P-256 + AES-256-GCM |
