# 术语表

版本: v0.0.1 | 更新日期: 2026-06-17

---

## 基础概念

| 术语 | 英文 | 定义 |
|------|------|------|
| OpenHive | — | 本项目名称，基于 UTXO + EVM 双轨制的高性能公链 |
| OH | — | OpenHive 项目简称 |
| OHI | OHI | OpenHive 统一原生代币，用于投票、Gas 支付、质押等所有用途，初始供应量为 0，通过挖矿获得 |
| hive | hive | 首个跨链资产名称（全小写），可跨链后质押投资 |
| Vote | Vote | 已移除的原生资产（spec v0.4.0），原投票权和 Gas 支付功能统一由 OHI 承担 |
| DAG | Directed Acyclic Graph | 有向无环图，本项目中区块之间采用 DAG 引用关系 |
| BlockDAG | Block DAG | 区块 DAG 结构，允许同一高度存在多个区块 |
| PoS | Proof of Stake | 权益证明共识机制 |
| DPoS | Delegated Proof of Stake | 委托权益证明，支持投资/解投资机制 |
| UTXO | Unspent Transaction Output | 未花费交易输出，用于管理 OHI 和特殊交易功能 |

## 共识机制

| 术语 | 英文 | 定义 |
|------|------|------|
| VRF | Verifiable Random Function | 可验证随机函数，用于随机选择打包节点 |
| 准入池 | Entry Pool | VRF 共识的第一阶段筛选，基于质押概率过滤节点 |
| 打包节点 | Packager / Block Producer | 被 VRF 选中的出块节点，负责打包交易和签名区块 |
| 验证节点 | Validator | 参与共识验证的节点 |
| VRF 周期 | VRF Cycle | 15 秒为一个周期，每个周期重新选择打包节点 |
| kConsensus | — | 最小共识节点数（= 3），区块至少需要此数量的有效签名 |
| 分叉检测 | Fork Detection | 每 15 秒向质押节点查询区块哈希，检测分叉 |
| 熔断机制 | Circuit Breaker | 区块累计 Gas 超过 kBlockGasLimit 时触发，构建部分区块 |
| ExclusionProof | Exclusion Proof | 排除证明，当区块 Gas 超限时打包者提供的交易完整性证明 |
| VRFSummaryMsg | VRF Summary Message | VRF 摘要交换消息，用于调度者共识确认协议 |

## 资产与经济

| 术语 | 英文 | 定义 |
|------|------|------|
| 三层资产 | Three-tier Asset System | Token（合约层）/ Native Token（跃入层）/ Native（底层）分类体系 |
| Token | Token | 合约层代币（如 wHIVE），仅 EVM 合约内流转 |
| Native Token | Native Token | 通过提案跃入 UTXO 层的代币（如 nHIVE），可质押/投资 |
| AssetType | Asset Type | 资产类型标识，OHI 为原生资产，Native Token 的 AssetType 为提案交易哈希 |
| 跃入 | FlowIn | 合约层 Token 锁定/销毁 → UTXO 层铸造 Native Token 的过程 |
| 跃出 | FlowOut | UTXO 层 Native Token 销毁 → 合约层释放 Token 的过程 |
| 提案 | Proposal | 发起治理提案，决定是否允许某个 Token 跃入 UTXO 层 |
| 标准精度 | Standard Precision | 面向用户的金额表示，单位为 1 OHI |
| 最小精度 | Minimum Precision | 底层存储最小单位，1 OHI = 10⁸ 最小单位 |
| kDecimalNum | — | 精度转换常量 = 100,000,000 (10⁸) |

## 交易与业务功能

| 术语 | 英文 | 定义 |
|------|------|------|
| 质押 | Stake | 锁定 OHI 以参与网络共识，最低 3,500 OHI |
| 解质押 | Unstake | 解除质押，需等待 MIN_UNSTAKE_HEIGHT（500 区块） |
| 投资 | Delegate/Invest | 将资产投入特定节点，最低 500 OHI |
| 解投资 | Undelegate/Uninvest | 撤回投资 |
| 锁定 | Lock | 锁定 OHI 获得投票权，金额 1 OHI（标准精度） |
| 解锁 | Unlock | 释放锁定的 OHI，恢复投票权 |
| 投票 | Vote | 对提案投赞成或反对票，票数 = 锁定 OHI 量 |
| 撤销提案 | Revoke Proposal | 撤回已通过的提案，撤销后 Native Token 只能跃出不能跃入 |
| 申领奖励 | Claim Bonus | 领取质押/投资产生的每日奖励 |
| 国库奖励 | Treasury Fund | 按质押权重 50% + 锁定权重 50% 分配的国库奖励 |
| 年化率 | Annualized Rate | 动态计算的年化收益率，从 5.0% 指数衰减至 0.5%（10 年周期） |
| 佣金率 | Commission Rate | 节点可设定的佣金比例（5%-35%） |

## 智能合约

| 术语 | 英文 | 定义 |
|------|------|------|
| EVM | Ethereum Virtual Machine | 以太坊虚拟机，本项目通过 evmone 实现兼容 |
| evmone | evmone | Ethereum Foundation 官方的 C++ EVM 实现（v0.14.1） |
| EVMC | Ethereum Virtual Machine Connector | EVM 连接接口标准 |
| MPT | Merkle Patricia Trie | 合约状态存储的树形数据结构 |
| baseFee | Base Fee | EIP-1559 动态基础费用，根据网络拥堵自动调整 |
| 依赖管理 | Dependency Management | 合约交易的依赖冲突检查与缓存重试机制 |
| SilkPre | SilkPre | 密码学预编译库，提供 ecrecover、sha256 等预编译合约实现 |

## 存储与网络

| 术语 | 英文 | 定义 |
|------|------|------|
| RocksDB | RocksDB | 持久化存储引擎，使用 TransactionDB 模式 |
| ECDH | Elliptic Curve Diffie-Hellman | 密钥交换协议，使用 NIST P-256 曲线 |
| AES-256-GCM | — | 对称加密算法，用于 P2P 通信加密 |
| HKDF | HMAC-based Key Derivation Function | 密钥派生函数，基于 RFC 5869 |
| SumHash | Sum Hash | 每 100 区块计算的汇总哈希，用于快速同步和分叉检测 |
| NTP | Network Time Protocol | 网络时间协议，用于节点时间同步 |
| IPv6 双栈 | IPv6 Dual Stack | 网络层同时支持 IPv4 和 IPv6 连接 |

## 安全

| 术语 | 英文 | 定义 |
|------|------|------|
| 双花检查 | Double Spend Check | 确保每个 UTXO 只能被消费一次 |
| 拜占庭容错 | Byzantine Fault Tolerance (BFT) | 容忍不超过 1/3 节点为恶意的共识能力 |
| 不变量 | Invariant | 必须在所有状态转换中保持的协议规则 |
| Slashing（惩罚机制） | Slashing | OpenHive 的五级惩罚体系（L0-L4），覆盖从奖励扣减到永久除名 |
| Jailing | Jailing | L1 级惩罚，暂停节点共识参与资格 |
| Tombstone | Tombstone | L4 级惩罚，永久除名节点 |
