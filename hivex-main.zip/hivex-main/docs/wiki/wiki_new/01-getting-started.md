# 入门指南

版本: v0.0.1 | 更新日期: 2026-06-17

---

## 概述

本章介绍 OpenHive 的项目定位、核心优势，以及如何快速开始使用网络。

---

## 1. 什么是 OpenHive

OpenHive 是一种开放型分布式账本系统，其核心特性在于全节点自治的公有链架构。任何网络参与者均可自由读取链上信息、发起转账操作、验证交易有效性，并平等参与网络共识决策。所有节点交易记录实时同步至全网，链上地址资产余额及资金流向完全透明可查，由全球验证节点组成的去中心化记账网络保障账本数据的完整性与可审计性。

OpenHive 是一条基于 **UTXO 模型** 的高性能公有链，具备以下核心特征：

- **DAG 区块结构** — 区块之间采用有向无环图（DAG）引用关系，允许同一高度存在多个区块，通过共识权重选择主链
- **VRF PoS 共识** — 使用可验证随机函数（VRF）随机选择打包节点，15 秒为一个共识周期
- **UTXO + EVM 双轨制** — UTXO 管理原生代币（OHI）和特殊交易功能；EVM（基于 evmone）管理智能合约
- **以太坊生态兼容** — 兼容 MetaMask、Hardhat、Web3.js 等以太坊工具链，支持 Solidity 智能合约部署

```mermaid
graph LR
    A[用户/开发者] --> B[ETH 工具链<br/>MetaMask / Hardhat / Web3.js]
    A --> C[RPC API<br/>JSON-RPC 2.0]
    B --> D[OpenHive 节点]
    C --> D
    D --> E[VRF PoS 共识]
    D --> F[UTXO 交易引擎]
    D --> G[EVM 合约引擎<br/>evmone]
    D --> H[RocksDB + MPT 存储]
    D --> I[P2P 网络<br/>ECDH + AES-256-GCM]
```

---

## 2. 核心优势

### 2.1 UTXO + EVM 双轨架构

OpenHive 将 UTXO 模型的高效并发能力与 EVM 的智能合约生态相结合：

- **UTXO 层**：管理 OHI 原生代币的转账、质押、投资、投票等业务功能，天然支持并行验证
- **EVM 层**：通过 evmone v0.14.1 实现完整的以太坊虚拟机，支持 Solidity 合约和 ERC-20/ERC-721 等标准

### 2.2 DAG 区块结构

不同于传统单链结构，OpenHive 采用 BlockDAG：

- 同一高度可存在多个区块（分叉），通过共识权重选择主链
- 区块可引用多个前驱区块，形成网状拓扑
- 提高网络吞吐量，减少因分叉导致的资源浪费

### 2.3 VRF 随机共识

- 每 15 秒一个周期，通过 VRF 随机选择打包节点
- 两阶段筛选（准入池 + 频率筛选）确保公平性
- 至少 7 个节点共识签名，支持拜占庭容错

### 2.4 三层资产体系

OpenHive 支持独特的三层资产分类，实现跨链资产的深度整合：

| 层级 | 说明 | 示例 |
|------|------|------|
| **Token** | 合约层代币 | wHIVE |
| **Native Token** | 通过提案跃入 UTXO 层的代币 | nHIVE |
| **Native** | 底层原生币 | OHI |

详见 [账户模型](04-account-model.md) 中的三层资产体系章节。

### 2.5 丰富的链上业务功能

通过 UTXO 机制实现一系列特殊交易功能：

- **质押 / 解质押** — 参与网络共识的准入机制
- **投资 / 解投资** — 委托权益证明（DPoS）激励机制
- **锁定 / 解锁** — 获取投票权的治理准入
- **提案 / 投票 / 撤销** — 链上治理与跨链资产管理
- **申领奖励 / 国库奖励** — 节点激励机制

详见 [交易与特殊功能](06-transactions.md)。

### 2.6 安全通信

- P2P 网络支持 ECDH P-256 密钥交换 + AES-256-GCM 加密通信
- secp256k1 椭圆曲线签名（与以太坊一致）
- 多层双花防护机制

---

## 3. 快速开始

### 3.1 系统要求

| 项目 | 要求 |
|------|------|
| 操作系统 | CentOS 7+ / Ubuntu 18.04+ |
| 编译器 | GCC 11.2.1+ |
| 构建工具 | CMake 3.21+ |
| 依赖 | zlib, autoconf, automake, libtool |

### 3.2 编译

```bash
# 安装依赖（CentOS）
yum install -y zlib zlib-devel unzip zip autoconf automake libtool
yum -y install perl-IPC-Cmd
yum install -y devtoolset-11-toolchain
scl enable devtoolset-11 bash

# 克隆源码
git clone <repository-url>
cd openhive

# 编译
mkdir build && cd build
cmake .. && make
```

编译完成后，主程序将在 `bin/` 目录下生成。

### 3.3 配置节点

启动时添加 `-c` 参数自动生成配置文件：

```bash
cd bin
./openhive -c
```

编辑 `config.json`：

```json
{
    "http_callback": { "ip": "", "path": "", "port": 0 },
    "http_port": 13134,
    "rpc": true,
    "ip": "<your-public-ip>",
    "endpoints": [],
    "server_endpoints": [
        {
            "node_id": "<seed-node-id>",
            "endpoints": [
                { "addr": "<seed-node-ip>", "port": 13133, "family": "ipv4" }
            ]
        }
    ],
    "log": {
        "console": false,
        "level": "OFF",
        "path": "./logs"
    },
    "version": "1.0.0"
}
```

**关键配置说明**：

| 字段 | 说明 |
|------|------|
| `server_endpoints` | 种子节点端点分组，每组含 `node_id` 和 `endpoints` 列表 |
| `endpoints` | 本机对外广播的端点列表（可选） |
| `http_port` | HTTP/RPC 服务端口（默认 13134） |
| `rpc` | 是否开启 RPC 接口（`true` 开启） |
| `log.level` | 日志级别（TRACE / DEBUG / INFO / WARN / ERROR / OFF） |
| `ip` | 本机公网 IP，启动时系统会自动检测 |

> **注意**: 旧版 `server` 字段（纯 IP 列表）已被 `server_endpoints`（结构化端点分组）替代。可通过 CLI 命令 `openhive set -server add/remove` 管理种子端点。

配置 `genesis.json`（创世配置）：

```json
{
    "genesis": {
        "blockData": { "Name": "OpenHive", "Type": "Genesis" },
        "genesisTime": 1769736708175000,
        "initAccountAddr": "<genesis-account-address>",
        "vrfWhitelist": [],
        "initialBalance": { "OHI": 0 }
    },
    "network": {
        "name": "devnet",
        "type": "dev"
    },
    "version": "1.0.0"
}
```

**网络类型**：

| 类型 | 编译宏 | 说明 |
|------|--------|------|
| DevNet | (默认) | 开发调试网络 |
| TestNet | `TESTCHAIN=ON` | 公共测试网络 |
| Primary | `PRIMARYCHAIN=ON` | 主网络 |

### 3.4 启动节点

```bash
./openhive -d    # 守护进程模式启动
./openhive auto  # 快速启动（自动解锁，密码 "1"，跳过交互提示）
```

**CLI 命令**：

| 命令 | 说明 |
|------|------|
| `openhive` | 标准启动，交互式密码解锁 keystore |
| `openhive auto` (或 `openhive a`) | 快速启动，自动解锁所有账户 |
| `openhive -d` | 守护进程模式 |
| `openhive -c` | 生成默认配置文件 |
| `openhive set -server add <node_id> <ip>` | 添加种子节点端点 |
| `openhive set -server remove <node_id> <ip>` | 移除种子节点端点 |

### 3.5 验证节点运行

通过 RPC 接口验证节点是否正常运行：

```bash
# 获取版本信息
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetVersion","params":{},"id":1}'

# 获取当前区块高度
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetBlockHeight","params":{},"id":2}'

# 获取账户列表
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetAccounts","params":{},"id":3}'
```

ETH 兼容接口（需开启 RPC）：

```bash
# 获取 Chain ID
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":1}'
# 返回: {"jsonrpc":"2.0","result":"0x3027","id":1}

# 获取最新区块号
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":2}'
```

---

## 4. 钱包使用教程

> 钱包教程详见独立文档，以下链接将引导至对应教程页面。

- [MetaMask 钱包](../wallet/metamusk&&OK/metamusk/MetaMask.md)
- [Remix IDE](../wallet/metamusk&&OK/remix/remix.md)
- [币安钱包](../wallet/metamusk&&OK/bian/bian.md)
- [OKX 钱包](../wallet/metamusk&&OK/OK/OK.md)

---

## 参考资料

- [协议规范 — §1 引言与范围](../spec/spec_dev.md)
- [协议规范 — §4 创世与初始状态](../spec/spec_dev.md)
- [RPC API 文档](../rpc/rpc_api_get_doc.md) | [POST 接口文档](../rpc/rpc_api_post_doc.md)

---

**本轮修订摘要**：
- 模块名称：入门指南
- 处理方式：重写（基于旧 wiki "MMC简介 + MMC优势 + 编译部署" 章节，全面更新）
- 新增术语：OpenHive, OHI, DAG, VRF PoS, UTXO, EVM
- 待确认问题：无
- 下一步计划：02-architecture.md — 架构设计
