# 治理机制

版本: v0.0.1 | 更新日期: 2026-06-17

---

## 概述

OpenHive 的链上治理机制通过提案和投票系统实现，主要用于管理跨链资产的跃入/跃出。本章描述提案类型、投票规则、锁定机制和治理流程。

---

## 1. 核心账户权限

| 账户类型 | 提案权限 | 投票权限 |
|---------|---------|---------|
| **创世账户** | ✅ 可发起提案和撤销提案 | ✅ 可投票（需锁定） |
| **节点账户** | ❌ 不可发起 | ✅ 可投票（需锁定） |
| **普通账户** | ❌ 不可发起 | ✅ 可投票（需锁定） |

> **注意**：提案的所有关键参数——包括最小投票人数、投票时长、汇率等——均由创世账号在发起提案时确定。撤销提案同样由创世账号发起和确定。

---

## 2. 提案类型

### 2.1 准入提案

申请将某个合约层 Token 跃入 UTXO 层成为 Native Token。

**提案内容**：

| 字段 | 说明 |
|------|------|
| `assetName` | 资产名称（如 "nHIVE"） |
| `contractAddr` | 合约层 Token 的合约地址 |
| `rate` | 汇率（Token → Native Token 的转换比例） |
| `crossChainInvestmentContractAddr` | 跨链投资合约地址 |
| `taskType` | 跨链交易类型 |

**跨链交易类型**：

| 类型 | 说明 |
|------|------|
| `EnteringMore` | 仅允许跃入 |
| `CrossChainInvestment` | 允许跨链投资 |
| `Both` | 同时允许跃入和跨链投资 |
| `Null` | 无特殊权限 |

### 2.2 撤销提案

撤回已通过的准入提案。

**效果**：
- Native Token **只能跃出，不能跃入**
- 无法再进行交易流转和质押
- 已质押资产将不再有效

---

## 3. 锁定机制

参与投票的前提是锁定 OHI。

### 3.1 锁定参数

| 参数 | 值 | 说明 |
|------|------|------|
| 锁定金额 | 1 OHI（标准精度） | `LOCK_AMOUNT = 1` |
| 锁定资产 | 仅 OHI | — |
| 锁定类型 | `LockNet` | — |
| 虚拟锁定地址 | `LockVirtualStake` | — |

### 3.2 锁定权益

- **投票权**：获得提案投票资格，票数 = 该地址的锁定 OHI 量
- **收益权**：参与国库奖励分配（50% 按锁定权重分配）

### 3.3 锁定/解锁流程

```mermaid
flowchart LR
    A[持有 OHI] -->|LOCK 交易| B[锁定 OHI]
    B --> C[获得投票权]
    C -->|参与投票| D[投票]
    B -->|UNLOCK 交易| E[释放 OHI]
    E --> F[失去投票权]
```

---

## 4. 投票流程

### 4.1 投票规则

| 规则 | 说明 |
|------|------|
| 投票资格 | 有效锁定账户 |
| 投票方式 | 赞成（1）或反对（0） |
| 票数 | = 该地址的锁定 OHI 量 |
| 单账户限制 | 单账户单提案仅能投票一次 |
| 投票周期 | 10 分钟（`KVoteCycle = 600,000,000 μs`） |
| 通过阈值 | 赞成票 > 总票数的 50% |

### 4.2 投票流程

```mermaid
sequenceDiagram
    participant GA as 创世账户
    participant Net as 网络
    participant V1 as 投票者 A
    participant V2 as 投票者 B
    participant Chain as 链上状态

    GA->>Net: 发起提案（PROPOSAL）
    Net->>Chain: 记录提案，开始 10 分钟投票期
    V1->>Chain: 投票（赞成/反对）
    V2->>Chain: 投票（赞成/反对）
    Note over Chain: 10 分钟后计票
    Chain->>Chain: 统计赞成票 vs 反对票
    alt 赞成票 > 50%
        Chain->>Chain: 提案通过，资产可跃入
    else 赞成票 ≤ 50%
        Chain->>Chain: 提案否决
    end
```

### 4.3 通过 RPC 投票

```bash
# 查询待投票提案
curl "http://localhost:13134/printProposalInfoByHash?hash=<proposal-hash>"

# 创建投票交易
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateVoteTransaction",
    "params": {
      "voteAddr": "0xVoter...",
      "voteHash": "<proposal-hash>",
      "voteType": 1,
      "fromAddr": "0xVoter..."
    },
    "id": 1
  }'
```

---

## 5. 撤销提案流程

```mermaid
sequenceDiagram
    participant GA as 创世账户
    participant Chain as 链上状态
    participant V as 投票者

    GA->>Chain: 发起撤销提案（REVOKEPROPOSAL）
    Chain->>Chain: 开始 10 分钟投票期
    V->>Chain: 投票（赞成/反对撤销）
    Note over Chain: 10 分钟后计票
    alt 赞成票 > 50%
        Chain->>Chain: 撤销通过
        Chain->>Chain: Native Token 只能跃出
        Chain->>Chain: 禁止新的跃入和质押
    else 赞成票 ≤ 50%
        Chain->>Chain: 撤销否决，原提案继续有效
    end
```

---

## 6. 跨链资产治理

### 6.1 跃入/跃出与治理的关系

```mermaid
flowchart TD
    A[提案通过] --> B[Token 可跃入 UTXO 层]
    B --> C[Native Token 可质押/投资/交易]
    C --> D[撤销提案]
    D --> E[Native Token 只能跃出]
    E --> F[禁止新的跃入/质押/交易]
```

### 6.2 汇率管理

跃入/跃出的汇率由提案中定义的 `rate` 字段决定：

```
跃入金额 (UTXO 层) = (Token 数量 × ExchangeRate × 10⁸) / (10^{rateDecimal} × 10^{tokenDecimal})
```

- `tokenDecimal` 固定为 18（EVM 标准精度）
- `rateDecimal` 为汇率的小数位数

---

## 7. 治理参数汇总

| 参数 | 值 | 说明 |
|------|------|------|
| `KVoteCycle` | 10 分钟 | 投票周期 |
| `KVrfVoteBeginTime` | 10 秒 | VRF 投票开始时间 |
| 通过阈值 | > 50% | 赞成票占比 |
| `LOCK_AMOUNT` | 1 OHI | 锁定金额（标准精度） |
| `KProposalInfoVersion` | 0 | 提案信息版本 |
| `KRevokeProposalInfoVersion` | 0 | 撤销提案信息版本 |

---

## 参考资料

- [协议规范 — §11.3 提案与投票机制](../spec/spec_dev.md)
- [协议规范 — §11.4 锁定机制](../spec/spec_dev.md)
- [协议规范 — §12 治理与升级](../spec/spec_dev.md)
- [交易与特殊功能](06-transactions.md)

---

**本轮修订摘要**：
- 模块名称：治理机制
- 处理方式：重写（旧 wiki 投票体系参数过时，锁定金额 10,000 Vote → 实际 1 OHI）
- 新增术语：CrossChainTxType, 准入提案, 撤销提案
- 待确认问题：无
- 下一步计划：12-economic-model.md — 经济模型
