# 版本历史

版本: v0.0.1 | 更新日期: 2026-06-17

---

## Wiki 文档版本

| 版本 | 日期 | 说明 |
|------|------|------|
| v0.0.3 | 2026-07-14 | 同步 spec v0.5.0：kConsensus 3→7，send_node_threshold 5→15；释放类交易（UNSTAKE/UNLOCK/UNDELEGATE）简化为单精确 UTXO 输入模型，释放等待时间常量化；新增网络连接生命周期管理（ConnectionAttemptManager FSM、NetworkPolicy 策略引擎、Bootstrap 重试）；新增 GetBonusInfo 详细参数、StartContractPoolTest/StartAutoTransactionTest 测试接口；ETH 兼容升级（eth_getBlockByNumber 区块标签、EIP-1559 交易格式、eth_maxPriorityFeePerGas）；CLI 新增 auto 快速启动和 set -server 端点管理，废弃 set -ip/set -port；config.json 中 server 字段迁移至 server_endpoints |
| v0.0.2 | 2026-07-03 | 同步 spec v0.4.0：共识周期 10s→15s，移除 Vote 资产（OHI 统一承担所有用途），移除 server_port 配置项，新增惩罚机制/IPv6 双栈等术语 |
| v0.0.1 | 2026-06-17 | 初始版本。基于 spec v0.3.0-draft 和源码全面修订，替换旧 wiki（MMC 文档 v0.0.1） |

---

## 协议版本

| 版本 | 说明 |
|------|------|
| 区块版本 | 0 (`kCurrentBlockVersion`) |
| 交易版本 | 0 (`CURRENT_TRANSACTION_VERSION`) |
| 提案版本 | 0 (`KProposalInfoVersion`) |
| 撤销提案版本 | 0 (`KRevokeProposalInfoVersion`) |

---

## Spec 文档版本

| 版本 | 日期 | 说明 |
|------|------|------|
| 0.5.0 | 2026-07-14 | kConsensus 3→7，释放类交易重构，网络连接生命周期管理，新增 RPC 接口，ETH EIP-1559 升级 |
| 0.4.0 | 2026-07-03 | 共识周期 10s→15s，移除 Vote 原生资产，新增惩罚体系（L0-L4）、VRF 调度者确认协议、IPv6 双栈 |
| 0.3.0-draft | 2026-06-16 | 附录 E 全部 TODO 已解决 |

---

## 主要变更（v0.0.1 相对旧 Wiki）

| 变更类别 | 说明 |
|---------|------|
| 名称更新 | MMC/MoonMesh/TFSC → OpenHive，MM → OHI |
| 共识协议 | SEC → VRF PoS（15 秒周期） |
| 签名算法 | ED25519 → secp256k1 ECDSA |
| 参数更新 | 质押 100,000→3,500 OHI，投资 3,500→500 OHI，锁定 10,000→1 OHI |
| 新增章节 | 存储层、网络层、安全考虑、ETH 兼容接口、三层资产体系 |
| 删除内容 | 未实现功能（动态分片、侧链、zk-SNARKs、IBTP） |
| 文档结构 | 单文件 → 15 文件模块化结构 |
| 操作示例 | CLI 菜单式 → RPC/API 方式 |
