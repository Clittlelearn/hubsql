# 架构设计

版本: v0.0.1 | 更新日期: 2026-06-17

---

## 概述

本章描述 OpenHive 的整体架构设计，包括分层模型、DAG 区块结构、UTXO + 账户混合模型，以及各层之间的交互关系。

---

## 1. 分层模型

OpenHive 采用分层解耦架构，各层职责明确、接口清晰：

```mermaid
graph TB
    subgraph Client["客户端层"]
        CLI[CLI / 交互式菜单]
        SDK[第三方 SDK]
    end

    subgraph RPC["RPC/API 层"]
        JSONRPC[JSON-RPC 2.0<br/>自定义接口]
        ETHRPC[ETH 兼容接口<br/>17 个标准方法]
        HTTP[HTTP Server<br/>httplib]
    end

    subgraph Consensus["共识层 (CA)"]
        VRF[VRF 共识引擎<br/>15s 周期]
        TXH[交易处理器<br/>UTXO 验证]
        BLK[区块管理<br/>保存/回滚]
        SYNC[区块同步<br/>快速/从零/广播]
    end

    subgraph Contract["智能合约层"]
        EVM[EVM 引擎<br/>evmone v0.14.1]
        PRE[预编译合约<br/>9 个标准]
        DEP[依赖管理<br/>DependencyManager]
    end

    subgraph Storage["存储层"]
        RDB[RocksDB<br/>TransactionDB]
        MPT[MPT<br/>Merkle Patricia Trie]
    end

    subgraph Network["网络层"]
        P2P[P2P 网络<br/>epoll 事件循环]
        PB[Protobuf 消息分发]
        ECDH[ECDH P-256<br/>AES-256-GCM]
    end

    subgraph Common["公共组件"]
        CFG[配置管理]
        GEN[创世配置]
        TP[线程池]
        LOG[日志系统<br/>spdlog]
    end

    Client --> RPC
    RPC --> Consensus
    Consensus --> Contract
    Consensus --> Storage
    Consensus --> Network
    Contract --> Storage
    Network --> Storage
    Common --> Consensus
    Common --> Network
```

### 各层职责

| 层级 | 职责 | 核心模块 |
|------|------|---------|
| **客户端层** | 用户交互、SDK 接入 | `main/`, 第三方 SDK |
| **RPC/API 层** | 对外接口服务，JSON-RPC 2.0 和 ETH 兼容 | `rpc/`, `net/http_server.cpp` |
| **共识层 (CA)** | VRF 共识、交易验证、区块管理、同步 | `ca/` |
| **智能合约层** | EVM 执行、预编译合约、依赖管理 | `ca/evm/`, `contract/` |
| **存储层** | 持久化存储、状态树管理 | `db/`, `mpt/` |
| **网络层** | P2P 通信、节点管理、加密传输 | `net/` |
| **公共组件** | 配置、创世、线程池、日志 | `common/`, `utils/`, `include/` |

---

## 2. DAG 区块结构

### 2.1 与传统单链的对比

区块链分叉现象本质上是出块速率与网络广播效率的动态失衡导致的拓扑结构演化。当节点生成新区块的速度超过全网广播确认的传播速度时，不同地理位置的节点将在未完全同步的状态下继续生成后续区块，形成并行延伸的多个链式分支。OpenHive 通过 DAG 结构将这种分叉转化为系统的固有特性，而非需要消除的异常。

```mermaid
graph LR
    subgraph Traditional["传统单链"]
        direction LR
        B0[B₀] --> B1[B₁] --> B2[B₂] --> B3[B₃]
    end

    subgraph BlockDAG["OpenHive BlockDAG"]
        direction LR
        D0[B₀] --> D1a[B₁ᵃ]
        D0 --> D1b[B₁ᵇ]
        D1a --> D2a[B₂ᵃ]
        D1b --> D2a
        D1a --> D2b[B₂ᵇ]
        D2a --> D3[B₃]
        D2b --> D3
    end
```

| 特性 | 传统单链 | OpenHive BlockDAG |
|------|---------|-------------------|
| 同高度区块数 | 仅 1 个 | 可存在多个（分叉） |
| 前驱引用 | 单一父区块 | 可引用多个前驱 |
| 分叉处理 | 丢弃孤块 | 多区块存储，共识权重选主链 |
| 拓扑结构 | 线性链 | 有向无环图 |

### 2.2 DAG 结构特征

- **多区块同高**：同一高度 `h` 可以有多个区块 `{B_h¹, B_h², ..., B_hᵏ}`
- **多前向引用**：区块通过 VRF blockinfo 引用多个前驱区块
- **主链选择**：通过共识权重从 DAG 中选择主链（简单多数 51% 初步判定 + BFT 2/3 验证）

### 2.3 结构优势

OpenHive 的 DAG 结构带来了以下核心优势：

- **拓扑结构革新**：将单链结构转化为网状拓扑，允许区块同时引用不同的前驱节点，形成并行验证通道，使网络吞吐量随节点规模线性扩展
- **并发写入机制**：基于 VRF PoS 共识协议，实现多区块生产者并行处理交易。在相同出块时间下，网络可并行打包 N 个区块，理论交易容量提升 N 倍
- **粒度优化**：从区块级打包细化至交易级处理，通过交易间哈希引用建立全局偏序关系

### 2.3 状态转换

OpenHive 是一个基于 DAG 的确定性状态机：

```
初始状态 (Genesis) → 区块 DAG {B₁, B₂, ..., Bₙ} → 主链状态 σₙ
```

状态转换函数：

```
σₙ = Υ(σₙ₋₁, Bₙ)
   = Υ(...Υ(Υ(σₙ₋₁, T₁), T₂)..., Tₖ)
```

**前置条件**：
- 区块必须通过共识验证
- 交易必须通过 UTXO 验证和双花检查

**后置条件**：
- 状态根必须一致
- 所有 UTXO 变更必须持久化

---

## 3. UTXO + 账户混合模型

OpenHive 采用混合模型，在不同层面使用最适合的账本模型：

```mermaid
graph TB
    subgraph UTXOLayer["UTXO 层（基础层）"]
        UTXO[UTXO 模型]
        UTXO_F1[转账]
        UTXO_F2[质押/解质押]
        UTXO_F3[投资/解投资]
        UTXO_F4[锁定/解锁]
        UTXO_F5[投票/提案]
        UTXO_F6[奖励申领]
    end

    subgraph AccountLayer["账户层（合约层）"]
        ACC[账户模型]
        ACC_F1[智能合约部署]
        ACC_F2[合约调用]
        ACC_F3[ERC-20/721 代币]
        ACC_F4[nonce 管理]
    end

    UTXO -->|Gas 支付<br/>状态验证| AccountLayer
    AccountLayer -->|合约结果<br/>UTXO 关联| UTXOLayer
```

| 层面 | 模型 | 适用场景 | 特点 |
|------|------|---------|------|
| **基础层** | UTXO | 转账、质押、委托、投票等 | 天然并行验证，双花检测高效 |
| **合约层** | 账户模型 | EVM 合约执行 | 兼容以太坊工具链，支持 nonce 和 RLP |
| **EVM 兼容** | 账户模型 | ETH 工具链交互 | 通过精度转换（10⁸ ↔ 10¹⁸）实现兼容 |

### 地址体系统一

UTXO 地址与 EVM 地址格式完全一致：
- 地址生成遵循 EIP-55 标准（Keccak-256 取后 20 字节 + 校验和）
- 签名验签算法相同（secp256k1 ECDSA）
- 单一账户可同时管理 UTXO 资产和合约状态

---

## 4. 数据流概览

### 4.1 普通交易流转

```mermaid
sequenceDiagram
    participant User as 用户
    participant Node as 发起节点
    participant VRF as VRF 共识
    participant Pkg as 打包节点
    participant Val as 验证节点
    participant Net as 全网节点

    User->>Node: 发起交易（RPC/CLI）
    Node->>VRF: VRF 签名，参与选主
    VRF->>Node: 选出打包节点
    Node->>Pkg: 发送交易至打包节点
    Pkg->>Pkg: 预验证交易（签名、余额、双花）
    Pkg->>Val: 分发交易至验证节点
    Val->>Val: 验证交易有效性
    Val-->>Pkg: 返回验证结果
    Pkg->>Pkg: 打包区块（达到共识数）
    Pkg->>Net: 广播区块
    Net->>Net: 独立验证并同步状态
```

### 4.2 合约交易流转

```mermaid
sequenceDiagram
    participant User as 用户
    participant Node as 发起节点
    participant Disp as 依赖分发器
    participant Pkg as 打包节点
    participant EVM as EVM 引擎
    participant MPT as MPT 状态树
    participant Net as 全网节点

    User->>Node: 发起合约交易
    Node->>Disp: 提交合约交易
    Disp->>Disp: 依赖分析（合约地址）
    Disp->>Pkg: 按依赖分组分发
    Pkg->>EVM: 执行合约（evmone）
    EVM->>MPT: 加载/更新合约状态
    MPT-->>EVM: 返回状态根哈希
    EVM-->>Pkg: 返回执行结果
    Pkg->>Pkg: 打包区块
    Pkg->>Net: 广播区块
    Net->>Net: 验证合约执行结果
```

---

## 5. 源码目录结构

| 目录 | 说明 | 核心文件 |
|------|------|---------|
| `ca/` | 共识层（核心逻辑） | `ca.cpp`, `transaction.cpp`, `vrf_consensus.cpp`, `global.h` |
| `ca/evm/` | EVM 集成 | `evm_host.cpp`, `evm_manager.cpp`, `evmEnvironment.cpp` |
| `ca/transaction/` | 交易类型实现 | `stake.cpp`, `delegating.cpp`, `vote.cpp`, `lock.cpp` 等 |
| `contract/` | 预编译合约 | `precompiles.cpp`, `precompiles_silkpre.cpp` |
| `db/` | 数据库层 | `db_api.cpp`, `rocksdb.cpp`, `rocksdb_read_write.cpp` |
| `mpt/` | Merkle Patricia Trie | `trie.cpp`, `rlp.cpp`, `node.h` |
| `net/` | P2P 网络 | `peer_node.cpp`, `dispatcher.cpp`, `key_exchange.cpp`, `epoll_mode.cpp` |
| `rpc/` | RPC 接口 | `http_api.cpp`, `eth/eth_rpc.cpp` |
| `rpc/api/post/` | POST 接口实现 | 40+ 个接口处理文件 |
| `rpc/api/get/` | GET 接口实现 | 18+ 个接口处理文件 |
| `common/` | 公共组件 | `config.cpp`, `genesis.cpp`, `task_pool.cpp` |
| `proto/` | Protobuf 定义 | `block.proto`, `transaction.proto`, `net.proto` 等 |
| `main/` | 应用入口 | `main.cpp`, `menu.cpp` |
| `utils/` | 工具库 | `sha256.cpp`, `account_manager.cpp`, `vrf_selection.cpp` |
| `silkpre/` | 密码学库 | secp256k1, SHA-256, RIPEMD-160 |

---

## 参考资料

- [协议规范 — §3 高层架构](../spec/spec_dev.md)
- [协议规范 — §5 区块与交易](../spec/spec_dev.md)
- [协议规范 — 附录 A 完整常量表](../spec/spec_dev.md)

---

**本轮修订摘要**：
- 模块名称：架构设计
- 处理方式：重写（旧 wiki 架构描述含未实现功能如动态分片/侧链，已完全重写）
- 新增术语：BlockDAG, 状态机, 混合模型
- 待确认问题：无
- 下一步计划：03-consensus.md — 共识机制
