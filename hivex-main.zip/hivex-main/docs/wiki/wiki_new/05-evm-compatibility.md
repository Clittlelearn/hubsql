# EVM 兼容性

版本: v0.0.1 | 更新日期: 2026-06-17

---

## 概述

OpenHive 集成 **evmone v0.14.1** 作为 EVM 执行引擎，支持到 **Cancun** 硬分叉级别，提供与以太坊兼容的智能合约执行环境。本章描述 EVM 集成架构、Gas 计量差异、预编译合约、合约依赖管理，以及 ETH 兼容 RPC 接口。

---

## 1. EVM 架构

```mermaid
graph TB
    subgraph EVMStack["EVM 执行栈"]
        CD[Contract Dispatcher<br/>依赖管理 / 预哈希验证]
        EH[EvmHost<br/>evmc::Host 接口实现]
        VM[evmone v0.14.1<br/>EVM 字节码执行引擎]
        PC[Precompiles<br/>9 个标准预编译]
        PCC[Precompiles Cache<br/>结果缓存]
        MPT[MPT<br/>合约状态存储]
    end

    CD --> EH
    EH --> VM
    VM --> PC
    PC --> PCC
    EH --> MPT
```

### 核心组件

| 组件 | 说明 | 实现文件 |
|------|------|---------|
| **evmone** | EVM 字节码执行引擎（原版，无定制修改） | `ca/evm/evm_manager.cpp` |
| **EvmHost** | 实现 `evmc::Host` 接口 | `ca/evm/evm_host.cpp` |
| **EvmEnvironment** | EVM 执行环境上下文构建 | `ca/evm/evmEnvironment.cpp` |
| **ContractDispatcher** | 合约依赖管理与调度 | `ca/dispatchtx.cpp` |
| **Precompiles** | 9 个标准以太坊预编译合约 | `contract/precompiles.cpp` |

### EVM 环境上下文

| 字段 | 类型 | 说明 |
|------|------|------|
| `blockTimestamp` | U64 | 当前区块时间戳 |
| `blockPrevRandao` | Bytes32 | 基于 UTXO 哈希 ASCII 值之和计算（非 VRF 种子） |
| `blockNumber` | U64 | 当前区块高度 |
| `blockHash` | Bytes32 | 当前区块哈希 |
| `chainId` | U64 | 12315 (0x3027) |
| `gasPrice` | U64 | Gas 价格 |

> **注意**：`blockPrevRandao` 当前实现基于发送者 UTXO 的交易哈希 ASCII 值之和计算，存在精度截断，高位全为零。该值高度可预测，与以太坊的 VRF-based prevRandao 语义不同。

---

## 2. 合约交易流程

### 2.1 部署合约（DEPLOY）

```mermaid
sequenceDiagram
    participant User as 用户
    participant Node as 节点
    participant EVM as evmone
    participant DB as RocksDB
    participant MPT as MPT

    User->>Node: 创建 DEPLOY 交易（含字节码）
    Node->>Node: 验证交易
    Node->>Node: 计算合约地址（EIP-161）
    Node->>EVM: 执行初始化代码
    EVM->>DB: 保存合约代码
    EVM->>MPT: 初始化 MPT 状态树
    Node->>Node: 记录部署者→合约地址映射
```

**合约地址生成**（遵循以太坊 EIP-161）：

```
contractAddr = Keccak256(RLP([senderAddress, nonce]))[12:32]
```

- `senderAddress`：部署者地址（20 字节）
- `nonce`：部署者账户的 nonce 值
- 输出：40 字符十六进制地址

### 2.2 调用合约（CALL）

```mermaid
sequenceDiagram
    participant User as 用户
    participant Node as 节点
    participant EH as EvmHost
    participant VM as evmone
    participant MPT as MPT

    User->>Node: 创建 CALL 交易（含方法签名+参数）
    Node->>Node: 验证交易
    Node->>EH: 加载合约代码和状态
    EH->>MPT: fetchContractRootHash()
    EH->>MPT: CreateTrie() 加载状态树
    EH->>VM: 执行 EVM 字节码
    VM-->>EH: 返回执行结果
    EH->>MPT: 更新合约状态
    Node->>Node: 处理返回值和日志
```

> **注意**：合约调用时 `money` 参数不再进行金额范围校验。

### 2.3 依赖验证流程

合约交易可能依赖其他合约的状态。交易发起节点根据合约间的依赖关系（如跨合约调用、状态变量耦合度）构建依赖图谱，通过哈希一致性算法将关联合约分配至同一分发节点，形成交易簇集。分发节点对接收的合约交易集进行依赖解析，依据调用顺序构建有向无环图（DAG），消除循环依赖风险。存在强依赖关系的合约交易被打包为原子事务块，确保事务执行的不可分割性。

EvmHost 在执行合约调用时执行以下验证：

| 步骤 | 验证内容 | 失败处理 |
|------|---------|---------|
| 1 | 自毁状态检查 | 目标合约已自毁 → 返回失败 |
| 2 | 余额验证 | 转账金额超过余额 → 返回失败 |
| 3 | 预编译合约检查 | 命中 0x01-0x09 → 直接执行 |
| 4 | 合约代码加载 | 代码为空 → 返回失败 |
| 5 | MPT 根哈希验证 | 获取根哈希失败 → 返回失败 |
| 6 | 状态树初始化 | CreateTrie 失败 → 返回失败 |
| 7 | 防重复加载 | 已加载合约跳过 |

---

## 3. 合约依赖管理

### 3.1 DependencyManager

合约交易在发送前需通过依赖冲突检查，防止同一合约地址的并发交易产生状态冲突：

```mermaid
flowchart TD
    A[新合约交易] --> B{依赖地址列表<br/>是否为空?}
    B -->|是| C[直接发送]
    B -->|否| D[查询每个依赖地址的<br/>进行中交易列表]
    D --> E{存在冲突?}
    E -->|否| C
    E -->|是| F[存入 ContractTransactionCache]
    F --> G[每 1 秒检查缓存]
    G --> H{缓存时间 ≥ 15s?}
    H -->|是| I[强制发送]
    H -->|否| J{依赖已解除?}
    J -->|是| C
    J -->|否| G
```

### 3.2 ContractTransactionCache

| 特性 | 说明 |
|------|------|
| 缓存检查频率 | 每 1 秒 |
| 强制发送超时 | 15 秒 |
| 发送前更新 | 更新交易时间、重新计算 identity 和 hash |
| 清理机制 | 交易完成后清除依赖记录 |

### 3.3 依赖广播与共识

打包节点广播合约依赖关系供其他节点验证：

- 接收节点验证签名有效性
- 检查依赖合约的 MPT 根哈希是否与本地一致
- 不一致则触发分叉解决流程

---

## 4. 预编译合约

OpenHive 实现了 **9 个标准以太坊预编译合约**（地址 0x01-0x09），通过 SilkPre 库提供底层实现。无自定义预编译合约。

| 地址 | 名称 | Gas 成本 | 说明 |
|------|------|----------|------|
| 0x01 | ecrecover | 固定 3000 | ECDSA 签名恢复 |
| 0x02 | sha256 | 60 + 12 × ⌈len/32⌉ | SHA-256 哈希 |
| 0x03 | ripemd160 | 600 + 120 × ⌈len/32⌉ | RIPEMD-160 哈希 |
| 0x04 | identity | 15 + 3 × ⌈len/32⌉ | 数据复制 |
| 0x05 | expmod | EIP-2565 动态计算 | 大整数模幂 |
| 0x06 | ecadd | 150 (Istanbul+) | BN128 点加 |
| 0x07 | ecmul | 6000 (Istanbul+) | BN128 点乘 |
| 0x08 | ecpairing | 45000 + 34000×k (Istanbul+) | BN128 配对检查 |
| 0x09 | blake2bf | rounds（从输入读取） | BLAKE2b 压缩 |

**缓存**：除 identity (0x04) 外的所有预编译结果会被缓存。

---

## 5. Gas 机制

### 5.1 Gas 参数

| 参数 | 值 | 说明 |
|------|------|------|
| `KTargetGasPrice` | 60,000 | EIP-1559 动态调整目标 |
| `INITIAL_BASE_FEE` | 10 | 创世区块或无历史记录时的默认值 |
| 最大 Gas 限制 | 120,000 | 单笔合约交易最大 Gas 成本 |
| `kBlockGasLimit` | 30,000,000 | 区块 Gas 上限（与以太坊相同） |
| `kGasLimitBufferRatio` | 90% | Gas 安全余量 |

### 5.2 EIP-1559 动态基础费用

OpenHive 支持 EIP-1559 动态 baseFee 调整：

- **baseFee 精度**：`int64_t × 1000`（毫单位定点数，3 位小数），确保跨平台确定性
- **baseFee 验证**：`old_baseFee` 必须为有效十进制数字，无效值回退到默认值 10
- **调整机制**：根据前一个区块的 Gas 使用量动态调整
- **Gas 销毁**：合约交易的 Gas 费用销毁到虚拟地址（`VirtualBurnGas` / `VirtualDeployContractBurnGas` / `VirtualCallContractBurnGas`）

### 5.3 基础交易 Gas

UTXO 层的基础交易（转账、质押等）使用 UTXO 规模的 Gas 计算，与 EVM Gas 独立。

---

## 6. ETH 兼容接口

### 6.1 接口列表

OpenHive 提供 **17 个标准 ETH JSON-RPC 方法**，兼容 MetaMask、Hardhat、Web3.js 等工具链：

| 方法 | 说明 | 备注 |
|------|------|------|
| `eth_chainId` | 获取链 ID | 返回 `0x3027` (12315) |
| `eth_blockNumber` | 获取当前区块高度 | — |
| `eth_gasPrice` | 获取 Gas 价格 | 目前返回 `0x1` |
| `eth_feeHistory` | 获取费用历史 | EIP-1559 |
| `eth_getBalance` | 获取账户余额 | 精度自动转换 |
| `eth_getTransactionCount` | 获取 nonce | — |
| `eth_sendRawTransaction` | 发送原始交易 | 支持部署/调用/转账及 OpenHive 原生交易（VOTE, DELEGATE, UNDELEGATE, STAKE, UNSTAKE, LOCK, UNLOCK） |
| `eth_getTransactionReceipt` | 获取交易收据 | — |
| `eth_call` | 只读合约调用 | — |
| `eth_getBlockByNumber` | 按区块号获取区块 | — |
| `eth_getBlockByHash` | 按区块哈希获取区块 | — |
| `eth_getCode` | 获取合约代码 | — |
| `eth_getTransactionByHash` | 按哈希获取交易 | — |
| `eth_estimateGas` | 估算 Gas | — |
| `eth_accounts` | 获取账户列表 | — |
| `net_version` | 获取网络版本 | — |
| `web3_clientVersion` | 获取客户端版本 | — |

### 6.2 精度转换

OpenHive 底层使用 10⁸ 精度，ETH 工具链期望 10¹⁸ 精度：

| 方向 | 方法 | 转换 |
|------|------|------|
| 读取（链→工具链） | `eth_getBalance` | `balance × 10¹⁰` |
| 写入（工具链→链） | `eth_sendRawTransaction` | `value ÷ 10¹⁰` |

> **注意**：`eth_sendRawTransaction` 中金额统一从 ETH 原始交易的 `value` 字段换算（18位→8位精度）。

### 6.3 eth_sendRawTransaction 处理流程

```mermaid
flowchart TD
    A[接收原始交易<br/>10¹⁸ 精度] --> B[RLP 解码]
    B --> C[签名验证<br/>提取 from 地址]
    C --> D{to 字段}
    D -->|为空| E[部署合约 DEPLOY]
    D -->|合约地址| F[调用合约 CALL]
    D -->|普通地址| G[普通转账 TX]
    E --> H[精度转换 10¹⁸→10⁸]
    F --> H
    G --> H
    H --> I[构造交易 + 签名]
    I --> J[广播到网络]
    J --> K{依赖检查通过?}
    K -->|是| L[完成]
    K -->|否| M[存入缓存等待重试]
```

---

## 7. 与以太坊的异同

| 特性 | OpenHive | 以太坊 | 差异说明 |
|------|---------|--------|---------|
| EVM 实现 | evmone v0.14.1 | 多种实现（Geth, evmone 等） | 使用原版 evmone，无定制修改 |
| EVM 版本 | Cancun | 最新硬分叉 | 一致 |
| 预编译合约 | 0x01-0x09 | 0x01-0x0a（含 KZG） | 缺少 KZG 点评估预编译 |
| Gas 计量 | EVM 操作码与以太坊一致 | — | 基础 Gas 计算使用 UTXO 规模 |
| EIP-1559 | 支持 | 支持 | baseFee 使用 int64×1000 定点数 |
| 精度 | 10⁸ | 10¹⁸ | ETH 接口自动转换 |
| Chain ID | 0x3027 (12315) | 1 (主网) | 不同 |
| 合约地址生成 | EIP-161 (RLP+Keccak256) | EIP-161 | 一致 |
| 地址格式 | EIP-55 | EIP-55 | 一致 |
| `blockPrevRandao` | UTXO 哈希 ASCII 和 | VRF-based | **不同**，可预测性较高 |
| `eth_gasPrice` | 返回 `0x1` | 动态返回 | **不同**，固定值 |

---

## 参考资料

- [协议规范 — §7 执行层（EVM + 智能合约）](../spec/spec_dev.md)
- [协议规范 — §10.5 ETH 兼容接口](../spec/spec_dev.md)
- [RPC POST 接口文档](../rpc/rpc_api_post_doc.md)

---

**本轮修订摘要**：
- 模块名称：EVM 兼容性
- 处理方式：重写（旧 wiki 仅概述 EVM 兼容，无技术细节）
- 新增术语：evmone, EVMC, EIP-1559, EIP-161, baseFee, ExclusionProof, DependencyManager, ContractTransactionCache
- 待确认问题：无
- 下一步计划：06-transactions.md — 交易与特殊功能
