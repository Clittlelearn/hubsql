# 节点部署

版本: v0.0.1 | 更新日期: 2026-06-17

---

## 概述

本章描述 OpenHive 节点的编译、配置、启动和网络类型，帮助开发者快速搭建和运行节点。

---

## 1. 系统要求

| 项目 | 要求 |
|------|------|
| 操作系统 | CentOS 7+ / Ubuntu 18.04+ |
| 编译器 | GCC 11.2.1+ |
| 构建工具 | CMake 3.21+（最低 3.15.x） |
| 依赖库 | zlib, autoconf, automake, libtool, perl-IPC-Cmd |

---

## 2. 编译

### 2.1 安装依赖（CentOS）

```bash
# 基础依赖
yum install -y zlib zlib-devel unzip zip autoconf automake libtool
yum -y install perl-IPC-Cmd

# GCC 11 工具链
yum install -y devtoolset-11-toolchain
scl enable devtoolset-11 bash
```

### 2.2 安装 CMake

```bash
curl -O https://cmake.org/files/v3.21/cmake-3.21.4.tar.gz
tar zxvf cmake-3.21.4.tar.gz
cd cmake-3.21.4
./configure
gmake && make install
```

### 2.3 编译项目

```bash
git clone <repository-url>
cd openhive
mkdir build && cd build
cmake .. && make
```

编译完成后，主程序将在 `bin/` 目录下生成。

---

## 3. 配置文件

### 3.1 config.json — 节点配置

启动时添加 `-c` 参数自动生成默认配置文件：

```bash
cd bin
./openhive -c
```

配置文件结构：

```json
{
    "http_callback": {
        "ip": "",
        "path": "",
        "port": 0
    },
    "http_port": 13134,
    "enable_https": false,
    "https_port": 443,
    "ssl_cert_path": "",
    "ssl_key_path": "",
    "ssl_ca_bundle": "",
    "enable_mtls": false,
    "enable_block_rate_probe": false,
    "rpc": true,
    "ip": "<your-public-ip>",
    "endpoints": [],
    "server_endpoints": [
        {
            "node_id": "<seed-node-id>",
            "endpoints": [
                { "addr": "<seed-node-ip>", "port": 13133, "family": "ipv4" }
            ]
        }
    ],
    "log": {
        "console": false,
        "level": "OFF",
        "path": "./logs"
    },
    "info": {
        "logo": "",
        "name": ""
    },
    "version": "1.0.0"
}
```

**配置字段说明**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `server_endpoints` | object[] | 种子节点端点分组，每组含 `node_id` 和 `endpoints` 列表 |
| `endpoints` | object[] | 本机对外广播的端点列表（可选） |
| `http_port` | int | HTTP/RPC 服务端口（默认 13134） |
| `https_port` | int | HTTPS 端口（默认 443） |
| `rpc` | bool | 是否开启 RPC 接口 |
| `enable_https` | bool | 是否启用 HTTPS |
| `ssl_cert_path` | string | SSL 证书路径 |
| `ssl_key_path` | string | SSL 私钥路径 |
| `ssl_ca_bundle` | string | CA 证书包路径 |
| `enable_mtls` | bool | 是否启用双向 TLS 认证 |
| `enable_block_rate_probe` | bool | 是否启用区块上链率探测 |
| `ip` | string | 本机公网 IP（系统会自动检测） |
| `log.console` | bool | 是否输出日志到控制台 |
| `log.level` | string | 日志级别：TRACE / DEBUG / INFO / WARN / ERROR / OFF |
| `log.path` | string | 日志文件路径 |
| `info.name` | string | 节点名称 |
| `info.logo` | string | 节点 logo |
| `http_callback` | object | HTTP 回调配置（区块通知） |
| `version` | string | 配置文件版本 |

### 3.2 genesis.json — 创世配置

```json
{
    "genesis": {
        "blockData": {
            "Name": "OpenHive",
            "Type": "Genesis"
        },
        "genesisTime": 1769736708175000,
        "initAccountAddr": "<genesis-account-address>",
        "vrfWhitelist": [],
        "initialBalance": {
            "OHI": 0
        }
    },
    "network": {
        "name": "devnet",
        "type": "dev"
    },
    "version": "1.0.0"
}
```

**关键字段说明**：

| 字段 | 说明 |
|------|------|
| `genesisTime` | 创世区块时间戳（微秒） |
| `initAccountAddr` | 创世账户地址（拥有提案权限） |
| `vrfWhitelist` | VRF 准入池白名单地址列表（始终以 100% 概率通过准入筛选） |
| `initialBalance` | 初始资产分配（当前实现中余额强制为 0） |
| `network.type` | 网络类型：`dev` / `test` / `primary` |

---

## 4. 网络类型

| 网络类型 | 编译宏 | Chain ID | kConsensus | send_node_threshold | 说明 |
|---------|--------|----------|-----------|-------------------|------|
| DevNet | (默认) | 0x3027 (12315) | 7 | 15 | 开发调试网络 |
| TestNet | `TESTCHAIN=ON` | 0x3027 (12315) | 7 | 15 | 公共测试网络 |
| Primary | `PRIMARYCHAIN=ON` | 0x3027 (12315) | 7 | 15 | 主网络 |

网络类型通过编译宏区分，影响种子节点列表和共识参数。所有网络类型的 `kConsensus` 统一为 7，`send_node_threshold` 统一为 15。Primary（主网）版本额外要求至少 10 个节点参与共识，以保障主网的安全性。

---

## 5. 启动与运行

### 5.1 启动方式

```bash
# 守护进程模式
./openhive -d

# 交互式菜单模式
./openhive --menu

# 快速启动（自动解锁，跳过交互提示）
./openhive auto
```

### 5.2 CLI 命令

| 命令 | 说明 |
|------|------|
| `openhive auto` (缩写 `a`) | 快速启动，使用密码 "1" 自动解锁所有 keystore 账户 |
| `openhive set -server add <node_id> <ip>` | 添加种子节点端点到 config.json |
| `openhive set -server remove <node_id> <ip>` | 从 config.json 移除种子节点端点 |

> **已废弃**: `set -ip` 和 `set -port` 命令已移除。IP 和端口通过 `config.json` 中的 `endpoints` 和 `server_endpoints` 配置。

### 5.2 时间同步

节点启动时会自动进行 NTP 时间校验，确保各节点时间一致。NTP 配置通过 `./ntp_server.conf` 管理。

手动校验时间：

```bash
# 安装 NTP
sudo yum -y install ntp

# 同步时间
ntpdate pool.ntp.org

# 启动 NTP 守护进程
systemctl start ntpd
systemctl enable ntpd
```

---

## 6. 目录结构

节点运行后生成以下目录和文件：

| 文件或目录 | 类型 | 说明 |
|-----------|------|------|
| `cert/` | 目录 | 存放生成的私钥文件 |
| `data.db/` | 目录 | RocksDB 数据库文件 |
| `logs/` | 目录 | 日志文件 |
| `config.json` | 文件 | 节点配置 |
| `genesis.json` | 文件 | 创世配置 |
| `ntp_server.conf` | 文件 | NTP 服务器配置 |

---

## 7. 验证节点运行

```bash
# 获取版本信息
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetVersion","params":{},"id":1}'

# 获取区块高度
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetBlockHeight","params":{},"id":2}'

# 获取节点列表
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetNodeList","params":{},"id":3}'

# ETH 兼容接口 — Chain ID
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":4}'
```

---

## 参考资料

- [协议规范 — §1.3 网络类型](../spec/spec_dev.md)
- [协议规范 — §4 创世与初始状态](../spec/spec_dev.md)
- [协议规范 — §9.8 HTTP/RPC 服务器](../spec/spec_dev.md)

---

**本轮修订摘要**：
- 模块名称：节点部署
- 处理方式：修订（基于旧 wiki "编译和部署" 章节，更新名称、补充 HTTPS/mTLS/区块探测等新配置）
- 新增术语：无
- 待确认问题：无
- 下一步计划：10-api-rpc.md — RPC 接口
