# RPC 接口

版本: v0.0.1 | 更新日期: 2026-06-17

---

## 概述

OpenHive 提供两类 RPC 接口：**自定义 JSON-RPC 2.0 接口**（用于业务查询和交易创建）和 **ETH 兼容接口**（兼容以太坊工具链）。本章概述接口分类和使用方式。

> **注意**：RPC 响应中的 JSON key 统一使用 camelCase 命名（如 `beginTime`, `txInfo`, `merkleRoot`）。

---

## 1. 自定义 JSON-RPC 2.0 接口

OpenHive 的自定义 RPC 接口分为 GET 和 POST 两类，详细文档请参见独立维护的 RPC 文档：

### 1.1 GET 接口

用于浏览器查询和调试，通过 HTTP GET 请求访问。

**详细文档**：[GET 接口文档](../rpc/rpc_api_get_doc.md)

主要接口概览：

| 路径 | 功能 |
|------|------|
| `/block` | 获取区块列表 |
| `/get_block` | 获取区块数据（JSON） |
| `/account` | 获取账户列表 |
| `/Node` | 获取节点列表 |
| `/ShowVRFInfo` | 获取 VRF 验证信息 |
| `/SystemInfo` | 获取系统信息 |
| `/printCalcHash` | 打印千块汇总 hash |
| `/printhundredhash` | 打印百块汇总 hash |
| `/printVoteInfo` | 打印投票信息 |
| `/printLockAddrs` | 打印锁定地址 |
| `/printProposalInfoByHash` | 打印提案信息 |
| `/printAvailableAssetType` | 打印可用资产类型 |
| `/GetPublicIp` | 获取公网 IP |
| `/GetRollbackBlocks` | 获取回滚区块信息 |
| `/Confirm` | 查询交易上链确认状态 |
| `/GetBlockRateProbeResults` | 获取区块上链率探测结果 |
| `/GetSlashNodeStatus` | 查询节点惩罚状态 |
| `/GetEvidenceList` | 查询举证记录列表 |
| `/GetPunishmentList` | 查询惩罚记录列表 |
| `/GetThresholdNodes` | 查询达到阈值的节点 |
| `/GetSlashStats` | 查询全局惩罚统计 |
| `/GetJailedNodes` | 查询所有被 Jailed 的节点 |
| `/GetTombstonedNodes` | 查询所有被 Tombstoned 的节点 |

**调用示例**：

```bash
# 获取最近 100 个区块
curl "http://localhost:13134/block?html=true"

# 获取系统信息
curl "http://localhost:13134/SystemInfo"

# 获取 VRF 信息
curl "http://localhost:13134/ShowVRFInfo"
```

### 1.2 POST 接口

用于业务查询和交易创建，通过 JSON-RPC 2.0 协议访问。

**详细文档**：[POST 接口文档](../rpc/rpc_api_post_doc.md)

主要接口分类：

#### 基础查询

| 方法 | 功能 |
|------|------|
| `GetVersion` | 获取版本信息 |
| `GetBalance` | 获取余额 |
| `GetBlockHeight` | 获取区块高度 |
| `GetChainId` | 获取链 ID |
| `GetAccounts` | 获取账户列表 |
| `GetNodeList` | 获取节点列表 |
| `GetAllStakeNodeList` | 获取所有质押节点 |
| `GetAddrType` | 获取地址类型 |
| `GetYieldInfo` | 获取收益信息 |
| `GetBonusInfo` | 获取奖励信息（支持按地址查询委托/基金奖励详情） |

#### 交易创建

| 方法 | 功能 |
|------|------|
| `CreateTransaction` | 创建普通交易 |
| `CreateStakingTransaction` | 创建质押交易 |
| `CreateUnstakingTransaction` | 创建解押交易 |
| `CreateDelegatingTransaction` | 创建投资交易 |
| `CreateUndelegatingTransaction` | 创建解投资交易 |
| `CreateBonusTransaction` | 创建奖励交易 |
| `CreateCallContractTransaction` | 创建调用合约交易 |
| `CreateDeployContractTransaction` | 创建部署合约交易 |
| `CreateLockTransaction` | 创建锁定交易 |
| `CreateUnLockTransaction` | 创建解锁交易 |
| `CreateVoteTransaction` | 创建投票交易 |
| `CreateFundTransaction` | 创建国库奖励交易 |
| `SendMessage` | 发送消息 |
| `SendContractMessage` | 发送合约消息 |

#### 查询接口

| 方法 | 功能 |
|------|------|
| `GetTransactionByHash` | 根据哈希获取交易 |
| `GetBlockByHash` | 根据哈希获取区块 |
| `GetBlockByHeight` | 根据高度获取区块 |
| `GetStakingUtxo` | 获取质押 UTXO |
| `GetDelegatingUtxo` | 获取投资 UTXO |
| `GetLockUtxo` | 获取锁定 UTXO |
| `GetVoteAddrs` | 获取投票地址 |
| `GetAllAssetType` | 获取所有资产类型 |
| `IsContract` | 判断是否为合约 |

#### 惩罚查询

| 方法 | 功能 |
|------|------|
| `GetEvidenceDetail` | 查询举证交易详情 |
| `GetPunishmentDetail` | 查询惩罚交易详情 |
| `GetEvidenceCount` | 查询节点举证计数 |
| `GetNodeSignRate` | 查询节点签名率 |

#### 测试接口

| 方法 | 功能 |
|------|------|
| `StartContractPoolTest` | 启动合约池自动化测试 |
| `StartAutoTransactionTest` | 启动自动交易测试 |

**调用示例**：

```bash
# 获取余额
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "GetBalance",
    "params": {"addr": "0x...", "assetType": "OHI"},
    "id": 1
  }'

# 创建转账交易
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateTransaction",
    "params": {
      "fromAddr": "0x...",
      "toAddr": "0x...",
      "txAsset": "OHI",
      "amount": 1000
    },
    "id": 2
  }'
```

---

## 2. ETH 兼容接口

OpenHive 兼容以太坊工具链（MetaMask、Hardhat、Web3.js 等），提供 **18 个标准 ETH JSON-RPC 方法**。

### 2.1 接口列表

| 方法 | 说明 | 备注 |
|------|------|------|
| `eth_chainId` | 获取链 ID | `0x3027` (12315) |
| `eth_blockNumber` | 获取当前区块高度 | — |
| `eth_gasPrice` | 获取 Gas 价格 | 目前返回 `0x1` |
| `eth_feeHistory` | 获取费用历史 | EIP-1559 |
| `eth_getBalance` | 获取账户余额 | 精度自动转换 10⁸ → 10¹⁸ |
| `eth_getTransactionCount` | 获取 nonce | — |
| `eth_sendRawTransaction` | 发送原始交易 | 支持部署/调用/转账 |
| `eth_getTransactionReceipt` | 获取交易收据 | — |
| `eth_call` | 只读合约调用 | — |
| `eth_getBlockByNumber` | 按区块号获取区块 | 支持 `latest`/`pending`/`earliest` 标签 |
| `eth_getBlockByHash` | 按区块哈希获取区块 | — |
| `eth_getCode` | 获取合约代码 | — |
| `eth_getTransactionByHash` | 按哈希获取交易 | — |
| `eth_estimateGas` | 估算 Gas | — |
| `eth_accounts` | 获取账户列表 | — |
| `eth_maxPriorityFeePerGas` | 获取最大优先费用 | 固定返回 `"0x1"` |
| `net_version` | 获取网络版本 | — |
| `web3_clientVersion` | 获取客户端版本 | — |

**eth_getBlockByNumber 区块标签**：第一个参数支持 `"latest"`（最新区块）、`"pending"`（同 latest）、`"earliest"`（创世区块）和十六进制区块号。

**交易 JSON 格式（EIP-1559）**：返回的交易对象使用 `maxFeePerGas` 和 `maxPriorityFeePerGas` 替代旧的 `gasPrice` 字段，交易 `type` 为 `"0x2"`。

### 2.2 精度转换

| 方向 | 转换 |
|------|------|
| 链 → 工具链 | `balance × 10¹⁰`（10⁸ → 10¹⁸） |
| 工具链 → 链 | `value ÷ 10¹⁰`（10¹⁸ → 10⁸） |

### 2.3 MetaMask 配置

在 MetaMask 中添加 OpenHive 网络：

| 参数 | 值 |
|------|------|
| 网络名称 | OpenHive |
| RPC URL | `http://<node-ip>:13134` |
| Chain ID | `12315` |
| 货币符号 | `OHI` |

### 2.4 调用示例

```bash
# 获取 Chain ID
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":1}'
# 返回: {"jsonrpc":"2.0","result":"0x3027","id":1}

# 获取最新区块号
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":2}'

# 获取余额（自动精度转换）
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_getBalance","params":["0x...", "latest"],"id":3}'
```

---

## 3. 错误码

OpenHive 使用基于宏展开的错误码系统，分为 4 个域：

| 错误域 | 说明 |
|--------|------|
| `RPC_PARSE_ERROR` | RPC 解析错误（参数格式、方法不存在等） |
| `GLOBAL_ERROR` | 全局错误（数据库、网络、配置等） |
| `CONTRACT_ERROR` | 合约错误（执行失败、Gas 不足等） |
| `CA_ERRORS` | 共识算法错误（签名、质押、投票等） |

---

## 参考资料

- [协议规范 — §10 RPC/API 接口](../spec/spec_dev.md)
- [协议规范 — 附录 D RPC 方法列表](../spec/spec_dev.md)
- [GET 接口文档](../rpc/rpc_api_get_doc.md)
- [POST 接口文档](../rpc/rpc_api_post_doc.md)

---

**本轮修订摘要**：
- 模块名称：RPC 接口
- 处理方式：新增（旧 wiki 无独立 RPC 章节）
- 新增术语：无
- 待确认问题：无
- 下一步计划：11-governance.md — 治理机制
