# 交易与特殊功能

版本: v0.0.1 | 更新日期: 2026-06-17

---

## 概述

OpenHive 的交易系统基于 UTXO 模型，支持 19 种交易类型，涵盖基础转账、质押/投资、治理投票、智能合约等多种功能。

交易是双方以货币和服务为媒介的价值交换。在区块链中，交易是一个数字记录，通过网络广播交易数据，通知加密货币所有权的转移，并通过 VRF PoS 共识机制进行确认和验证，使交易不可逆且防篡改。交易是区块链网络交互操作的唯一方式，包括发布资产、转账、部署智能合约、合约调用等等，都是基于交易的方式进行操作处理。

本章详细描述交易结构、各类型交易的功能说明和关键参数。

---

## 1. 交易结构

交易使用 Protobuf 序列化：

| 字段 | 类型 | 说明 |
|------|------|------|
| `version` | uint32 | 交易版本（当前为 0） |
| `time` | uint64 | 交易时间（微秒级时间戳） |
| `identity` | string | 打包节点身份 |
| `hash` | string | 交易哈希 |
| `type` | uint32 | 交易类型（见枚举） |
| `data` | string | 交易数据（JSON 格式） |
| `note` | string | 交易备注（≤ 1KB） |
| `signature` | repeated CSign | 交易签名 |
| `utxos` | repeated CTxUtxos | UTXO 列表 |
| `independence` | uint32 | 交易独立性标志 |
| `nonce` | uint64 | EVM 兼容 nonce |

### 交易类型枚举

| 类型 | 值 | 说明 |
|------|------|------|
| `GENESIS` | 0 | 创世交易 |
| `TX` | — | 普通转账 |
| `STAKE` | — | 质押 |
| `UNSTAKE` | — | 解质押 |
| `DELEGATE` | — | 投资 |
| `UNDELEGATE` | — | 解投资 |
| `DEPLOY` | — | 部署合约 |
| `CALL` | — | 调用合约 |
| `LOCK` | — | 锁定 |
| `UNLOCK` | — | 解锁 |
| `PROPOSAL` | — | 提案 |
| `REVOKEPROPOSAL` | — | 撤销提案 |
| `VOTE` | — | 投票 |
| `FUND` | 98 | 申领国库奖励 |
| `BONUS` | 99 | 申领奖励 |
| `PUNISHMENT` | 100 | 惩罚 |
| `EVIDENCE` | 101 | 举证 |

---

## 2. 交易生命周期

```mermaid
flowchart LR
    A[创建] --> B[签名]
    B --> C[广播]
    C --> D[验证]
    D --> E[进入 Mempool]
    E --> F[打包]
    F --> G[确认]
```

### 验证规则

交易在打包前必须通过以下验证：

| 检查项 | 说明 |
|--------|------|
| 超时验证 | 交易时间不能超过 10 秒 |
| UTXO 高度验证 | UTXO 高度必须有效 |
| 双花检查 | UTXO 未被消费 |
| 签名验证 | 所有签名必须有效 |
| 资产类型验证 | 资产类型必须有效且已批准 |
| Gas 验证 | 输入 Gas 必须足够 |
| 资格验证 | 根据交易类型验证前置条件 |

### 交易池

| 参数 | 值 | 说明 |
|------|------|------|
| 普通交易池上限 | 10,000 | — |
| 合约交易池上限 | 5,000 | — |
| 淘汰策略 | FIFO + TTL | 超时 10 秒淘汰 |

### 释放类交易说明

UNSTAKE、UNLOCK、UNDELEGATE 三种释放类交易使用简化的交易构建模型：

| 特征 | 说明 |
|------|------|
| **单精确 UTXO 输入** | 直接使用指定的 `utxo_hash` 构建单个输入，不搜索多个 UTXO |
| **无 Gas 处理** | 不涉及 Gas 计算、代付或燃烧地址 |
| **单输出** | 仅将原始金额返还给发送方，无余额找零 |
| **Nonce 防重放** | 通过地址级 nonce 防止交易重放 |
| **tx.data 元数据** | JSON 格式存储操作信息（如 utxo_hash、bonusAddr） |

**释放等待时间**：

| 常量 | 值 | 适用交易 |
|------|------|---------|
| `STAKE_RELEASE_WAIT_TIME` | 30 天 | UNSTAKE |
| `LOCK_RELEASE_WAIT_TIME` | 30 天 | UNLOCK |
| `DELEGATE_RELEASE_WAIT_TIME` | 1 天 | UNDELEGATE |
| `DEV_RELEASE_WAIT_TIME` | 1 分钟 | 所有类型（Dev 网络测试用） |

---

## 3. 基础转账（TX）

实现资产点对点转移。

**前置条件**：
- 发送方和接收方地址有效
- 账户余额 ≥ 转账金额 + Gas 费
- 指定资产类型

**通过 RPC 创建转账交易**：

```bash
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateTransaction",
    "params": {
      "fromAddr": "0xSender...",
      "toAddr": "0xReceiver...",
      "txAsset": "OHI",
      "amount": 1000
    },
    "id": 1
  }'
```

---

## 4. 质押（STAKE）

锁定 OHI 以参与网络共识，获得打包和验证交易的资格。质押是保障网络稳定性的基础机制，通过锁定资产过滤低质量节点，同时质押量与收益成正比，激励长期贡献。

| 参数 | 值 | 说明 |
|------|------|------|
| 最低质押量 | 3,500 OHI | 参与共识的最低门槛 |
| 质押资产 | 仅 OHI | — |
| 佣金率范围 | 5% - 35% | 节点可设定的佣金比例 |

> **注意**：一个地址同一时间只能进行一次质押（即只有一个有效质押 UTXO）。

**功能**：
- 获得打包节点资格
- 参与 VRF 共识签名
- 收取质押奖励
- 接受投资并收取佣金

**通过 RPC 创建质押交易**：

```bash
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateStakingTransaction",
    "params": {
      "addr": "0xNode...",
      "currencyType": "OHI",
      "amount": 3500
    },
    "id": 1
  }'
```

---

## 5. 解质押（UNSTAKE）

解除质押，赎回锁定的 OHI。

| 参数 | 值 | 说明 |
|------|------|------|
| 最小解质押周期 | 1 天后可操作 | 解质押请求最早在 1 天后可发起 |
| 释放等待时间 | 30 天 (`STAKE_RELEASE_WAIT_TIME`) | 解质押成功后资产需等待 30 天方可使用 |
| 最小解质押区块高度 | 500 区块 | `MIN_UNSTAKE_HEIGHT` |

**前置条件**：
- 提供原始质押交易哈希（UTXO）

**交易模型**：使用简化的单精确 UTXO 输入模型（见下方"释放类交易说明"），无 Gas 处理，单输出返还质押金额。交易 `data` 字段包含 `{"txInfo": {"unstakeUtxo": "<utxo_hash>"}}`。

解质押成功后，资金即时返回至账户，但需等待 30 天后方可用于新的交易或质押。

**通过 RPC 创建解质押交易**：

```bash
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateUnstakingTransaction",
    "params": {
      "addr": "0xNode...",
      "currencyType": "OHI",
      "utxo": "<stake-utxo-hash>"
    },
    "id": 1
  }'
```

---

## 6. 投资（DELEGATE）

将资产投入特定节点，获取投资收益。这是 OpenHive DPoS 激励机制的核心。

投资机制是 OpenHive DPoS 激励体系的核心。通过投资，投资者与被投资节点共享奖励，促进节点间形成价值关联网络。一个地址可以对多个其他地址（包括自己）进行投资，实现资产的灵活配置。

| 参数 | 值 | 说明 |
|------|------|------|
| 最低投资额 | 500 OHI | `kMinDelegatingAmt` |
| 最小奖励投资额 | 500,000 OHI | 获得签名权的最小投资总额 |
| 投资上限 | 3,500,000 OHI | 单个地址被投资的累计总额上限 |
| 最大投资次数 | 1,000 | 单个地址被投资的笔数上限 |
| 支持资产 | 多币种 | 支持 OHI 和 Native Token |

**通过 RPC 创建投资交易**：

```bash
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateDelegatingTransaction",
    "params": {
      "fromAddr": "0xInvestor...",
      "toAddr": "0xNode...",
      "currencyType": "OHI",
      "amount": 500
    },
    "id": 1
  }'
```

---

## 7. 解投资（UNDELEGATE）

撤回投资，赎回投入的资产。

| 参数 | 值 | 说明 |
|------|------|------|
| 最小解投资周期 | 1 天后可操作 | 解投资请求最早在 1 天后可发起 |
| 释放等待时间 | 1 天 (`DELEGATE_RELEASE_WAIT_TIME`) | 解投资成功后资产需等待 1 天方可使用 |

**前置条件**：
- 提供投资交易哈希（UTXO）

**交易模型**：使用简化的单精确 UTXO 输入模型（见下方"释放类交易说明"），无 Gas 处理，单输出返还委托金额。交易 `data` 字段包含 `{"txInfo": {"bonusAddr": "<to_addr>", "undelegatingUtxo": "<utxo_hash>"}}`。

解投资成功后，资金即时返回至投资者账户，但需等待 1 天后方可用于新的交易。

**通过 RPC 创建解投资交易**：

```bash
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateUndelegatingTransaction",
    "params": {
      "fromAddr": "0xInvestor...",
      "toAddr": "0xNode...",
      "currencyType": "OHI",
      "utxo": "<delegate-utxo-hash>"
    },
    "id": 1
  }'
```

---

## 8. 锁定（LOCK）

锁定 OHI 获得投票权，用于参与提案投票和国库奖励分配。

| 参数 | 值 | 说明 |
|------|------|------|
| 锁定金额 | 1 OHI（标准精度） | `LOCK_AMOUNT = 1` |
| 锁定资产 | 仅 OHI | — |
| 锁定类型 | `LockNet` | — |
| 最小解锁定周期 | 1 天 | 锁定后最早 1 天后可发起解锁 |

锁定金额无上限。

**功能**：
- 获得提案投票权（票数 = 锁定 OHI 量）
- 参与国库奖励分配

**通过 RPC 创建锁定交易**：

```bash
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateLockTransaction",
    "params": {
      "addr": "0xVoter...",
      "amount": 1
    },
    "id": 1
  }'
```

---

## 9. 解锁（UNLOCK）

释放锁定的 OHI，恢复资产流动性。

| 参数 | 值 | 说明 |
|------|------|------|
| 释放等待时间 | 30 天 (`LOCK_RELEASE_WAIT_TIME`) | 解锁后资产需等待 30 天方可使用 |

**前置条件**：
- 提供原始锁定交易哈希（UTXO）

**交易模型**：使用简化的单精确 UTXO 输入模型（见下方"释放类交易说明"），无 Gas 处理，单输出返还锁定金额。交易 `data` 字段包含 `{"txInfo": {"unLockUtxo": "<utxo_hash>"}}`。

解锁成功后，OHI 即时返回至账户，投票权同步失效。

**通过 RPC 创建解锁交易**：

```bash
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateUnLockTransaction",
    "params": {
      "addr": "0xVoter...",
      "utxo": "<lock-utxo-hash>"
    },
    "id": 1
  }'
```

---

## 10. 提案（PROPOSAL）

发起治理提案，决定是否允许某个 Token 跃入 UTXO 层成为 Native Token。

**权限要求**：仅限创世账户操作

**提案内容**：

| 字段 | 说明 |
|------|------|
| `assetName` | 资产名称（如 "nHIVE"） |
| `contractAddr` | 合约地址 |
| `rate` | 汇率（Token → Native Token 的转换比例） |
| `taskType` | 跨链交易类型 |

**提案类型**：

| 类型 | 说明 |
|------|------|
| 准入提案 | 新增跨链资产，允许 Token 跃入 UTXO 层 |
| 撤销提案 | 终止链间资产互通，仅允许资产流出 |

---

## 11. 投票（VOTE）

对提案投赞成（1）或反对（0）票。

**前置条件**：
- 账户必须处于有效锁定状态
- 票数 = 锁定 OHI 量
- 单账户单提案仅能投票一次
- 投票周期：10 分钟
- 通过阈值：赞成票 > 50%

**通过 RPC 创建投票交易**：

```bash
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateVoteTransaction",
    "params": {
      "voteAddr": "0xVoter...",
      "voteHash": "<proposal-hash>",
      "voteType": 1,
      "fromAddr": "0xVoter..."
    },
    "id": 1
  }'
```

---

## 12. 撤销提案（REVOKEPROPOSAL）

撤回已通过的提案。

**效果**：
- 撤销后 Native Token **只能跃出，不能跃入**
- 无法再进行交易流转和质押
- 已质押资产将不再有效

---

## 13. 申领奖励（BONUS）

领取质押/投资产生的每日奖励。

**前置条件**：
- 必须是质押账户
- 最少申领时间：质押后 24 小时方可首次申领

**奖励计算公式**：

```
实际奖励 = dividendRate × (年化率 × 委托金额 / 365)
```

- `dividendRate`：节点签名工作量比例（`签名次数 / 平均签名次数`，合格节点为 1.0）
- 年化率：动态计算，从 5.0% 指数衰减至 0.5%（10 年周期）

**通过 RPC 创建奖励交易**：

```bash
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateBonusTransaction",
    "params": {
      "bonusAddr": "0xNode..."
    },
    "id": 1
  }'
```

---

## 14. 国库奖励（FUND）

领取国库奖励，来源为前一日全网消耗的 Gas 费用统计。

**分配规则**：

| 分配维度 | 比例 | 说明 |
|---------|------|------|
| OHI 锁定占比分配 | 50% | 由各账号 OHI 锁定占比进行分配，锁定量越大的账号分得越多 |
| 达标节点签名分配 | 50% | 按前一日的达标节点分配，按签名数的百分比分配，签名贡献越多的节点获得的奖励越多 |

**通过 RPC 创建国库奖励交易**：

```bash
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateFundTransaction",
    "params": {
      "addr": "0xNode..."
    },
    "id": 1
  }'
```

---

## 15. 智能合约交易

### 15.1 部署合约（DEPLOY）

通过 RPC 部署智能合约：

```bash
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateDeployContractTransaction",
    "params": {
      "deployerAddr": "0xDeployer...",
      "contractPath": "./contract/contract",
      "inputData": "0x..."
    },
    "id": 1
  }'
```

### 15.2 调用合约（CALL）

通过 RPC 调用智能合约：

```bash
curl -X POST http://localhost:13134 -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "CreateCallContractTransaction",
    "params": {
      "fromAddr": "0xCaller...",
      "toAddr": "0xContract...",
      "args": "0xa0712d68..."
    },
    "id": 1
  }'
```

合约交易详细说明参见 [EVM 兼容性](05-evm-compatibility.md)。

---

## 16. 特殊交易功能对比

| 功能 | 交易类型 | 前置条件 | 关键参数 | UTXO 优势 |
|------|---------|---------|---------|----------|
| 质押 | STAKE | 持有 ≥ 3,500 OHI | 质押金额、佣金率 | 天然并行验证 |
| 解质押 | UNSTAKE | 1 天后可操作（释放等待 30 天） | 原始质押 UTXO | 精确资产追踪 |
| 投资 | DELEGATE | 持有 ≥ 500 OHI | 目标节点、金额 | 多币种支持 |
| 解投资 | UNDELEGATE | 1 天后可操作（释放等待 1 天） | 投资 UTXO | 即时赎回 |
| 锁定 | LOCK | 持有 OHI | 1 OHI | 轻量级投票权获取 |
| 解锁 | UNLOCK | 有锁定记录（释放等待 30 天） | 锁定 UTXO | 即时释放 |
| 投票 | VOTE | 有效锁定 | 提案哈希、投票类型 | 票数 = 锁定量 |
| 提案 | PROPOSAL | 创世账户 | 资产名称、汇率 | — |
| 奖励 | BONUS | 质押账户 | — | 自动计算分配 |
| 国库 | FUND | 满足门槛 | — | 双权重分配 |

---

## 17. 举证交易（EVIDENCE）

举证交易用于将惩罚证据上链记录。

- **交易类型**: `TxType::EVIDENCE = 101`
- **发起方**: 合约分发者（系统交易）
- **Gas**: 不计入 Gas 累计
- **说明**: 记录节点违规行为（双签、低签名率等），无资金转移。需要至少 3 个质押节点的签名确认。

## 18. 惩罚交易（PUNISHMENT）

惩罚交易执行对违规节点的处罚。

- **交易类型**: `TxType::PUNISHMENT = 100`
- **发起方**: 合约分发者（系统交易）
- **Gas**: 不计入 Gas 累计
- **惩罚等级**:
  - L3（Stake Slash）: 按 1%/3%/5% 递增扣减质押
  - L4（Tombstone）: 永久除名，移除质押资格，退回委托

---

## 参考资料

- [协议规范 — §5 区块与交易](../spec/spec_dev.md)
- [协议规范 — §11 代币经济学与 Gas](../spec/spec_dev.md)
- [协议规范 — 附录 B 交易类型枚举](../spec/spec_dev.md)
- [RPC POST 接口文档](../rpc/rpc_api_post_doc.md)

---

**本轮修订摘要**：
- 模块名称：交易与特殊功能
- 处理方式：重写（旧 wiki 参数全部过时，操作方式为 CLI 菜单式，已改为 RPC/API 方式）
- 新增术语：无（复用前序章节术语）
- 待确认问题：无
- 下一步计划：07-storage.md — 存储层
