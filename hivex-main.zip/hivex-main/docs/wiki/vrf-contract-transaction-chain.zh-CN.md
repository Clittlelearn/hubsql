# 合约交易 VRF 创建与验证链路

本文档说明合约部署和合约调用从发起、选择分发者、选择合约打包者、区块流转、最终广播过程中涉及的选择与 VRF 验证步骤。

部署合约和调用合约共用同一套主链路：

- 菜单入口创建 `CALL` 或 `DEPLOY` 交易。
- 公共合约填充逻辑补齐交易公开字段。
- 发起方按原有时段轮转规则选择合约分发者，也就是 `tx.identity()`。
- 分发者通过 VRF 再选择合约打包者。
- 合约打包者创建区块，并通过 VRF 选择区块签名验证者。

## 参与角色

- 合约交易发起方：构造 `CALL` 或 `DEPLOY` 交易，并选择合约分发者。
- 合约分发者：验证自己是否被发起方选中，然后对合约交易批次选择合约打包者。
- 合约打包者：验证自己是否被分发者选中，负责构建合约区块。
- 区块验证者：验证合约区块、合约分发者时段选择、合约打包者选择和区块签名验证者选择。
- 最终广播接收节点：收到最终区块广播后，复验完整 VRF 链路。

## 选择一：合约交易选择分发者

合约分发者已经恢复为原有按时段确定性轮转逻辑，不再创建或验证 `CONTRACT_DISPATCHER` VRF proof。

选择方：所有节点基于同一交易时间段本地计算。

选择内容：节点基于当前时段的候选节点集合和候选节点签名 hash 聚合种子，计算出同一个合约分发者。

判断标准：

- 所有节点在同一时段必须计算出相同的 `tx.identity()`。
- 验证时重新按 `tx.time()` 计算分发者，结果必须等于交易里的 `tx.identity()`。

## VRF 一：分发者选择合约打包者

日志工作流名：`CONTRACT_PACKAGER`

创建方：合约分发者。

证明内容：分发者基于合约交易批次 hash、批次时间、候选合约打包节点集合和自己的 VRF 私钥生成 proof，选择 1 个合约打包者。

创建阶段：

```text
[VRF_CHAIN][CONTRACT_PACKAGER][CREATE][dispatch_contract_packager_create][contract-batch:...]
```

合约打包者验证阶段：

```text
[VRF_CHAIN][CONTRACT_PACKAGER][VERIFY][contract_packager_handle][contract-batch:...]
```

区块流转验证阶段：

```text
[VRF_CHAIN][CONTRACT_PACKAGER][VERIFY][contract_packager_block_verify][contract-batch:...]
```

最终广播验证阶段：

```text
[VRF_CHAIN][CONTRACT_PACKAGER][VERIFY][block_broadcast_verify][contract-batch:...]
```

判断标准：

- proof 必须能被分发者的 VRF 公钥验证。
- proof 重新计算出的 selected 必须等于当前合约区块打包者。
- `distSign` 必须由分发者签出，且签名内容必须是合约交易批次 hash。
- 最终区块广播通过 `BuildBlockBroadcastMsg.distSign` 和 `BuildBlockBroadcastMsg.dispatcher_vrf` 复验这一步。

## VRF 二：合约打包者选择区块签名验证者

日志工作流名：`BLOCK_VALIDATOR`

创建方：合约打包者。

证明内容：合约打包者基于区块公开输入、候选节点集合和自己的 VRF 私钥生成 proof，选择区块流转验证者集合。

创建阶段：

```text
[VRF_CHAIN][BLOCK_VALIDATOR][CREATE][block_flow_create][block:...]
```

区块流转验证阶段：

```text
[VRF_CHAIN][BLOCK_VALIDATOR][VERIFY][block_flow_verify][block:...]
```

最终广播验证阶段：

```text
[VRF_CHAIN][BLOCK_VALIDATOR][VERIFY][block_broadcast_verify][block:...]
```

判断标准：

- proof 的 selector 必须等于合约区块打包者地址。
- proof 重新计算出的验证者集合，加上合约区块打包者自身，必须等于消息携带的完整 `verifyAddrs`。

## 合约交易完整链路

1. 发起方创建部署合约或调用合约交易。
2. 发起方按时段轮转规则计算合约分发者 `tx.identity()`。
3. 合约分发者收到请求，按同一时段规则验证自己是否为 `tx.identity()`。
4. 合约分发者对合约交易批次创建 `CONTRACT_PACKAGER` proof，选出合约打包者。
5. 合约打包者收到批次，验证 `CONTRACT_PACKAGER` proof 和分发者签名 `distSign`。
6. 合约打包者创建区块，并创建 `BLOCK_VALIDATOR` proof，选出区块签名验证者。
7. 区块验证者在流转阶段验证合约分发者时段选择、`CONTRACT_PACKAGER` 和 `BLOCK_VALIDATOR`。
8. 最终广播接收节点在广播阶段再次验证合约分发者时段选择、`CONTRACT_PACKAGER` 和 `BLOCK_VALIDATOR`。

## 常用排查命令

```bash
grep "VRF_CHAIN.*CONTRACT_PACKAGER" mm_*.log
grep "VRF_CHAIN.*BLOCK_VALIDATOR" mm_*.log
grep "VRF_CHAIN.*contract_packager" mm_*.log
grep "VRF_CHAIN.*block_broadcast_verify" mm_*.log
```
