# OpenHive 节点部署与操作指南

版本: v0.0.3 | 更新日期: 2026-07-14

---

## 概述

本文档介绍如何在服务器上部署 OpenHive 节点，包括硬件/软件要求、编译安装、配置文件说明，以及交互式菜单的各项操作。本文档面向节点运维人员和开发者。

---

## 1. 硬件要求

| 项目 | 最低要求 | 推荐配置 |
|------|---------|---------|
| CPU | 2 核 | 4 核+ |
| 内存 | 2 GB | 4 GB+ |
| 磁盘 | 20 GB SSD | 50 GB+ SSD |
| 网络 | 10 Mbps | 100 Mbps+，需公网 IP |

> **说明**：节点需要全账本存储，磁盘空间会随区块增长持续增加。建议使用 SSD 以保证数据库读写性能。

---

## 2. 软件要求

### 2.1 操作系统

| 操作系统 | 版本 |
|---------|------|
| CentOS | 7+ |
| Ubuntu | 18.04+ |

### 2.2 编译工具链

| 软件 | 版本要求 | 说明 |
|------|---------|------|
| GCC | 11.2.1+ | C++ 编译器 |
| CMake | 3.21+（最低 3.15.x） | 构建系统 |
| Git | 任意版本 | 源码管理 |

### 2.3 依赖库

| 依赖 | 说明 |
|------|------|
| zlib / zlib-devel | 压缩库 |
| autoconf, automake, libtool | 构建工具 |
| perl-IPC-Cmd | Perl 模块 |
| unzip, zip | 压缩工具 |
| OpenSSL 开发库 | 密码学运算 |
| Boost | 线程池、异步 IO 等 |

---

## 3. 编译安装

### 3.1 CentOS 环境

```bash
# 安装基础依赖
yum install -y zlib zlib-devel unzip zip autoconf automake libtool
yum -y install perl-IPC-Cmd

# 安装 GCC 11 工具链
yum install -y devtoolset-11-toolchain
scl enable devtoolset-11 bash

# 升级 CMake（如系统版本低于 3.15）
curl -O https://cmake.org/files/v3.21/cmake-3.21.4.tar.gz
tar zxvf cmake-3.21.4.tar.gz
cd cmake-3.21.4
./configure && gmake && make install
```

### 3.2 Ubuntu 环境

```bash
# 更新软件源
apt update

# 安装基础依赖
apt install -y build-essential gcc-11 g++-11 cmake git \
    zlib1g-dev autoconf automake libtool unzip zip \
    libssl-dev libboost-all-dev perl

# 设置 GCC 11 为默认编译器
update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-11 100
update-alternatives --install /usr/bin/g++ g++ /usr/bin/g++-11 100
```

### 3.3 编译源码

```bash
# 克隆源码
git clone <repository-url>
cd openhive

# 编译
mkdir build && cd build
cmake .. && make
```

编译完成后，主程序 `openhive` 将在 `bin/` 目录下生成。

### 3.4 时间同步

节点间时间一致性对交易排序和共识至关重要，必须配置 NTP 时间同步。

```bash
# CentOS
yum -y install ntp
ntpdate pool.ntp.org
systemctl start ntpd
systemctl enable ntpd

# Ubuntu
apt install -y ntp
systemctl start ntp
systemctl enable ntp

# 验证时间同步
date
ntpq -p    # 或 ntpstat
```

---

## 4. 命令行工具

OpenHive 主程序支持多种命令行模式：

```
openhive <command> [options]
```

### 4.1 命令一览

| 命令 | 缩写 | 说明 |
|------|------|------|
| `menu` | `m` | 启动交互式菜单 |
| `daemon` | `d` | 以守护进程模式启动 |
| `gen key` | `g key` | 生成账户密钥对 |
| `gen config` | `g config` | 生成 config.json 配置文件 |
| `gen genesis [type]` | `g genesis` | 生成 genesis.json 模板 |
| `set -rpc <true\|false>` | `s -rpc` | 开关 RPC 服务 |
| `set -server add <node_id> <ip>` | `s -server add` | 添加启动种子节点地址 |
| `set -server remove <node_id> <ip>` | `s -server remove` | 删除启动种子节点地址 |
| `auto` | `a` | 快速启动（自动解锁所有账户，密码 "1"，跳过交互提示） |
| `help` | `h` | 显示帮助信息 |

### 4.2 启动方式

**交互式菜单模式**（用于管理操作）：

```bash
./openhive menu
# 或
./openhive m
```

**守护进程模式**（用于长期运行节点）：

```bash
./openhive daemon
# 或
./openhive d
```

**快速启动模式**（开发/测试环境，自动解锁所有账户）：

```bash
./openhive auto
# 或
./openhive a
```

> **注意**：`auto` 模式使用固定密码 `"1"` 解锁所有 keystore 账户，跳过交互式密码提示。仅适用于开发/测试环境，生产环境请使用标准启动方式。

### 4.3 生成配置文件

首次部署时，使用 `gen` 命令生成配置文件模板：

```bash
# 生成 config.json
./openhive gen config

# 生成 genesis.json（开发网络）
./openhive gen genesis dev

# 生成 genesis.json（测试网络）
./openhive gen genesis test

# 生成 genesis.json（主网络）
./openhive gen genesis primary

# 生成账户密钥对
./openhive gen key
```

### 4.4 运行时配置

```bash
# 开启 RPC 服务
./openhive set -rpc true

# 关闭 RPC 服务
./openhive set -rpc false

# 添加启动种子节点地址（IPv4，默认端口 13133）
./openhive set -server add node1 192.168.1.11

# 添加启动种子节点地址（IPv6，默认端口 13133）
./openhive set -server add node1 2001:db8::1

# 删除启动种子节点地址
./openhive set -server remove node1 192.168.1.11
```

`set -server` 只维护 `config.json` 中的 `server_endpoints`。新增地址会自动识别 IPv4/IPv6 并写入 `family`，端口固定为 `13133`，新增或重复添加的地址会排到最高优先级（`priority: 0`）。如果删除后某个节点没有任何 endpoint，该节点分组会从 `server_endpoints` 中移除。

> **说明**：`server_endpoints` 是节点启动时使用的种子节点配置。节点运行一段时间后，程序可能根据已发现的节点列表刷新该字段。

---

## 5. 配置文件说明

### 5.1 config.json

节点运行配置文件，控制网络、日志、RPC 等运行参数。

```json
{
    "http_callback": {
        "ip": "",
        "path": "",
        "port": 0
    },
    "http_port": 13134,
    "enable_https": false,
    "https_port": 443,
    "ssl_cert_path": "",
    "ssl_key_path": "",
    "ssl_ca_bundle": "",
    "enable_mtls": false,
    "enable_block_rate_probe": false,
    "rpc": true,
    "endpoints": [
        {
            "addr": "192.168.1.100",
            "port": 13133,
            "family": 4,
            "priority": 0
        }
    ],
    "server_endpoints": [
        {
            "id": "node1",
            "endpoints": [
                {
                    "addr": "192.168.1.11",
                    "port": 13133,
                    "family": 4,
                    "priority": 0
                }
            ]
        }
    ],
    "log": {
        "console": false,
        "level": "OFF",
        "path": "./logs"
    },
    "info": {
        "logo": "",
        "name": ""
    },
    "version": "1.0.0"
}
```

**字段说明**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `endpoints` | object[] | 本节点对外监听地址列表，包含 `addr`、`port`、`family`、`priority` |
| `server_endpoints` | object[] | 启动种子节点地址列表，每个分组包含节点 `id` 和 `endpoints` |
| `http_port` | int | HTTP/RPC 服务端口，默认 13134 |
| `rpc` | bool | 是否开启 RPC 接口，`true` 开启后可通过 HTTP 访问 |
| `enable_https` | bool | 是否启用 HTTPS |
| `https_port` | int | HTTPS 端口，默认 443 |
| `ssl_cert_path` | string | SSL 证书文件路径 |
| `ssl_key_path` | string | SSL 私钥文件路径 |
| `ssl_ca_bundle` | string | CA 证书包路径 |
| `enable_mtls` | bool | 是否启用双向 TLS 认证 |
| `enable_block_rate_probe` | bool | 是否启用区块上链率探测 |
| `log.console` | bool | 日志是否输出到控制台 |
| `log.level` | string | 日志级别：TRACE / DEBUG / INFO / WARN / ERROR / OFF |
| `log.path` | string | 日志文件存储路径 |
| `http_callback` | object | HTTP 回调配置（ip/path/port） |
| `info` | object | 节点自定义信息（名称、Logo） |
| `version` | string | 配置文件版本号 |

### 5.2 genesis.json

创世配置文件，定义链的初始状态和网络类型。

```json
{
    "genesis": {
        "blockData": {
            "Name": "DevChain",
            "Type": "Genesis"
        },
        "genesisTime": 1769736708175000,
        "initAccountAddr": "755Ccf704E17570b64E247f0794314e4C8E542CA",
        "vrfWhitelist": [],
        "initialBalance": {
            "OHI": 0
        }
    },
    "network": {
        "name": "devnet",
        "type": "dev"
    },
    "version": "1.0.0"
}
```

**字段说明**：

| 字段 | 说明 |
|------|------|
| `genesis.blockData.Name` | 链名称（DevChain / TestChain / MainChain） |
| `genesis.genesisTime` | 创世时间戳（微秒级） |
| `genesis.initAccountAddr` | 创世账户地址，拥有提案权限 |
| `genesis.vrfWhitelist` | VRF 准入池白名单，白名单中的地址始终以 100% 概率通过准入筛选 |
| `genesis.initialBalance` | 初始资产分配（当前实现中余额强制为 0） |
| `network.name` | 网络名称 |
| `network.type` | 网络类型：`dev`（开发）/ `test`（测试）/ `primary`（主网） |

**网络类型差异**：

| 网络类型 | 编译宏 | kConsensus | send_node_threshold |
|---------|--------|-----------|-------------------|
| DevNet | (默认) | 7 | 15 |
| TestNet | `TESTCHAIN=ON` | 7 | 15 |
| Primary | `PRIMARYCHAIN=ON` | 7 | 15 |

> Primary（主网）版本额外要求至少 10 个节点参与共识，以保障主网安全性。

---

## 6. 目录结构

节点运行后，在工作目录下生成以下文件和目录：

| 文件或目录 | 类型 | 说明 |
|-----------|------|------|
| `cert/` | 目录 | 存放生成的私钥文件（keystore） |
| `data.db/` | 目录 | RocksDB 数据库文件 |
| `logs/` | 目录 | 日志文件 |
| `contract/` | 目录 | 合约相关文件 |
| `config.json` | 文件 | 节点配置文件 |
| `genesis.json` | 文件 | 创世配置文件 |
| `ntp_server.conf` | 文件 | NTP 服务器配置 |

---

## 7. 交互式菜单操作

启动交互式菜单后，首先显示当前节点的基本信息：

```
*********************************************************************************
Version: x.x.x
Block top: 12345
Address: 0x755Ccf704E17570b64E247f0794314e4C8E542CA
Balance: OHI: 5000.00000000
Staked: yes
Delegated: no
Locked: yes
*********************************************************************************
```

### 菜单总览

```
1.Transaction          — 发起转账交易
2.Staking              — 质押
3.Unstaking            — 解质押
4.Delegating           — 投资
5.Undelegating         — 解投资
6.Get Bonus            — 申领奖励
7.Print Account Info   — 账户信息
8.Deploy contract      — 部署合约
9.Call contract        — 调用合约
10.Lock                — 锁定
11.UnLock              — 解锁
12.Proposal            — 发起提案
13.Revoke proposal     — 撤销提案
14.Vote                — 投票
15.Fund                — 申领国库奖励
16.Account Manager     — 账户管理
0.Exit                 — 退出
```

---

### 7.1 Transaction（发起转账）

**功能**：实现资产点对点转移。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 交易笔数 | 支持一次发起 1-3 笔转账 |
| 转账资产类型 | 指定转账的资产类型（如 OHI 或 Native Token） |
| 发送地址 | 发送方地址 |
| 接收地址 | 接收方地址 |
| 金额 | 转账金额（标准精度） |
| Gas 单独支付 | 是否使用不同资产类型支付 Gas |

**前置条件**：账户余额 ≥ 转账金额 + Gas 费。

---

### 7.2 Staking（质押）

**功能**：锁定 OHI 以参与网络共识，获得打包和验证交易的资格。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 质押地址 | 默认使用当前账户地址 |
| 资产类型 | 仅支持 OHI |
| 质押金额 | 最低 3,500 OHI |
| 佣金率 | 1% - 35%，节点从投资者奖励中抽取的佣金比例 |

**前置条件**：
- 账户持有 ≥ 3,500 OHI
- 一个地址同一时间只能进行一次质押

**注意**：质押后需等待 1 天方可发起解质押，解质押成功后资产延后 30 天可用（`STAKE_RELEASE_WAIT_TIME`）。

---

### 7.3 Unstaking（解质押）

**功能**：解除质押，赎回锁定的 OHI。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 解质押地址 | 需要解质押的账户地址 |
| 资产类型 | 质押时使用的资产类型 |
| 质押 UTXO | 从显示的质押列表中粘贴对应的 UTXO 哈希 |

**前置条件**：
- 质押满 1 天后方可操作
- 需提供原始质押交易的 UTXO 哈希

**注意**：解质押成功后资金即时返回，但需等待 30 天（`STAKE_RELEASE_WAIT_TIME`）后方可用于新的交易或质押。

---

### 7.4 Delegating（投资）

**功能**：将资产投入特定节点，获取投资收益。这是 OpenHive DPoS 激励机制的核心。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 发送地址 | 投资者地址 |
| 资产类型 | 投资使用的资产类型 |
| 目标地址 | 被投资的节点地址 |
| 投资金额 | 最低 500 OHI |

**前置条件**：
- 账户持有 ≥ 500 OHI
- 一个地址可以对多个其他地址（包括自己）进行投资

**注意**：投资后需等待 1 天方可发起解投资，解投资成功后资产延后 1 天可用（`DELEGATE_RELEASE_WAIT_TIME`）。

---

### 7.5 Undelegating（解投资）

**功能**：撤回投资，赎回投入的资产。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 发送地址 | 投资者地址 |
| 资产类型 | 投资时使用的资产类型 |
| 目标地址 | 被投资的节点地址 |
| 投资 UTXO | 从显示的投资列表中粘贴对应的 UTXO 哈希 |

**前置条件**：
- 投资满 1 天后方可操作
- 需提供原始投资交易的 UTXO 哈希

---

### 7.6 Get Bonus（申领奖励）

**功能**：领取质押/投资产生的每日奖励。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 资产类型 | 申领的奖励资产类型 |
| Gas 支付 | 可选择是否使用其他资产支付 Gas |

**前置条件**：
- 必须是质押账户
- 质押后 24 小时方可首次申领

**奖励计算**：
- 每日申领前日奖励
- 签名达标率 ≥ 平均值时全额发放，未达标则按比例扣减

---

### 7.7 Print Account Info（账户信息）

**功能**：显示当前节点的详细信息，包括：
- 版本号
- 当前区块高度
- 默认账户地址
- OHI 余额
- 质押/投资/锁定状态
- 可跃入/跃出的资产类型列表

---

### 7.8 Deploy Contract（部署合约）

**功能**：部署 Solidity 智能合约到链上。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 部署者地址 | 部署合约的账户地址 |
| 合约路径 | 合约二进制文件路径（默认 `./contract/contract`） |
| 构造函数参数 | 合约构造函数的输入参数（十六进制，可跳过） |
| Gas 支付 | 可选择是否使用其他资产支付 Gas |

**前置条件**：
- 合约编译后的二进制码保存在指定路径
- 账户有足够余额支付 Gas

---

### 7.9 Call Contract（调用合约）

**功能**：调用已部署的智能合约。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 调用者地址 | 调用合约的账户地址 |
| 部署者地址 | 合约部署者的地址（从列表选择） |
| 合约地址 | 要调用的合约地址（从列表选择） |
| 调用参数 | 函数签名和参数（十六进制） |
| 转账金额 | 向合约地址转账的金额（可为 0） |
| Gas 支付 | 可选择是否使用其他资产支付 Gas |

---

### 7.10 Lock（锁定）

**功能**：锁定 OHI 获得投票权，用于参与提案投票和国库奖励分配。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 锁定地址 | 默认使用当前账户地址 |
| 锁定金额 | 最低 1 OHI（标准精度），无上限 |

**前置条件**：
- 账户持有足够的 OHI
- 锁定金额 ≥ 1 OHI

**注意**：锁定后获得投票权，票数 = 锁定 OHI 量。锁定后 1 天方可发起解锁。

---

### 7.11 UnLock（解锁）

**功能**：释放锁定的 OHI，恢复资产流动性。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 解锁地址 | 需要解锁的账户地址 |
| 锁定 UTXO | 从显示的锁定列表中粘贴对应的 UTXO 哈希 |

**前置条件**：
- 锁定满 1 天后方可操作
- 需提供原始锁定交易的 UTXO 哈希

**注意**：解锁成功后，OHI 即时返回，投票权同步失效。解锁后资产需等待 30 天（`LOCK_RELEASE_WAIT_TIME`）方可用于新的交易。

---

### 7.12 Proposal（发起提案）

**功能**：发起治理提案，决定是否允许某个 Token 跃入 UTXO 层成为 Native Token。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 资产名称 | 提案的资产名称（如 "nHIVE"） |
| 是否允许跃入 | 是否允许合约层 Token 跃入 UTXO 层 |
| 跃入合约地址 | 跨链合约地址 |
| 是否允许跨链投资 | 是否允许跨链投资功能 |
| 跨链投资合约地址 | 跨链投资合约地址 |
| 对端链 Token 地址 | 对端链上的 Token 地址 |
| 汇率 | Token → Native Token 的转换比例（最多 8 位小数） |
| 最小投票人数 | 提案通过所需的最小投票人数 |
| 投票时长 | 投票持续时间（小时，保留 1 位小数） |
| 标识符 | 提案标识信息（≤ 1KB） |
| 标题 | 提案标题（≤ 1KB） |

**前置条件**：
- **仅限创世账户操作**，默认账户必须是 genesis.json 中的 `initAccountAddr`

**注意**：投票周期不能短于系统最小值（KVoteCycle）。

---

### 7.13 Revoke Proposal（撤销提案）

**功能**：撤回已通过的准入提案。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 撤销提案哈希 | 从可撤销提案列表中选择 |
| 最小投票人数 | 撤销提案通过所需的最小投票人数 |
| 投票时长 | 投票持续时间（小时） |

**前置条件**：
- **仅限创世账户操作**
- 只能撤销已通过且可撤销的提案

**效果**：撤销后 Native Token 只能跃出，不能跃入。

---

### 7.14 Vote（投票）

**功能**：对提案投赞成或反对票。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 投票地址 | 投票者地址（默认账户） |
| 投票哈希 | 从待投票提案列表中选择 |
| 投票类型 | 0 = 反对（Against），1 = 赞成（Approve） |
| Gas 支付地址 | 支付 Gas 的地址 |

**前置条件**：
- 账户必须处于有效锁定状态（已执行 Lock 操作）
- 票数 = 锁定 OHI 量
- 单账户单提案仅能投票一次

**注意**：投票使用 OHI 支付 Gas，不能使用其他资产。

---

### 7.15 Fund（申领国库奖励）

**功能**：领取国库奖励，来源于前一日全网消耗的 Gas 费用。

**关键参数**：

| 参数 | 说明 |
|------|------|
| 申领地址 | 默认使用当前账户地址 |

**分配规则**：
- 50% 由各账号 OHI 锁定占比进行分配
- 50% 按前一日的达标节点分配（按签名数的百分比）

**前置条件**：
- 需满足锁定门槛或质押+投资门槛

---

### 7.16 Account Manager（账户管理）

**功能**：管理本地账户，包括创建、删除、导出等操作。

进入账户管理子菜单后显示：

```
0.Exit                        — 退出子菜单
1.Set Default Account         — 设置默认账户
2.Add Account                 — 添加新账户
3.Remove                      — 删除账户
4.Export SeedKey              — 导出私钥（含二维码）
5.Change Account Password     — 修改账户密码
6.Export All Private Keys     — 批量导出所有私钥
```

#### 7.16.1 Set Default Account（设置默认账户）

**功能**：更改节点的默认账户地址。默认账户用于质押、提案等需要身份的操作。

**参数**：目标地址（必须是已存在的本地账户）。

#### 7.16.2 Add Account（添加账户）

**功能**：生成新的账户密钥对并添加到本地账户列表。

#### 7.16.3 Remove（删除账户）

**功能**：从本地账户列表中删除指定账户。

#### 7.16.4 Export SeedKey（导出私钥）

**功能**：导出指定账户的私钥，同时生成二维码便于扫描导入。

**参数**：目标地址、账户密码。

**输出**：在控制台显示私钥和二维码，同时保存到当前目录的文本文件中。

#### 7.16.5 Change Account Password（修改密码）

**功能**：修改指定账户的 keystore 密码。

**参数**：目标地址、当前密码、新密码。

#### 7.16.6 Export All Private Keys（批量导出）

**功能**：将所有本地账户的私钥导出到一个文件中。

**参数**：统一密码（所有账户使用相同密码时）。

**输出**：保存到 `all_private_keys.txt` 文件。

---

### 7.17 Transaction Tests（交易集成测试）

> 仅在编译时启用 `ENABLE_TX_TESTS` 宏时可见（菜单编号 46）。

**功能**：提供 GTest 交易集成测试子菜单，支持按交易类型运行自动化测试（TX、STAKE、UNSTAKE、DELEGATE、UNDELEGATE、LOCK、UNLOCK、VOTE、BONUS、FUND）。

---

### 7.18 Exit（退出）

**功能**：安全退出程序。执行清理操作后退出。

---

## 8. 通用操作说明

### 8.1 Gas 费单独支付

大部分交易菜单都支持「是否单独支付 Gas」选项：

- 选择 `[0] no`：使用交易涉及的同一资产类型支付 Gas
- 选择 `[1] yes`：指定不同的资产类型和地址支付 Gas

当选择单独支付时，需要额外输入：
- Gas 支付的资产类型
- Gas 支付的地址

> **注意**：用于支付 Gas 的资产类型不能与交易涉及的资产类型相同（避免冲突）。

### 8.2 全网 UTXO 状态查询

大部分交易菜单都包含「是否查找全网 UTXO 状态」选项：

- `0`：不查找（默认），使用本地 UTXO 数据
- `1`：查找，从全网获取最新 UTXO 状态

> **建议**：一般情况下使用默认值 `0` 即可。当交易失败提示 UTXO 相关问题时，可尝试设为 `1`。

### 8.3 交易备注

大部分交易菜单都支持输入交易备注信息：

- 备注内容不超过 1KB
- 直接回车跳过（不输入备注）
- 备注内容会进行 Base64 编码后存储在链上

---

## 参考资料

- [Wiki 文档 — 节点部署](../wiki_new/09-node-deployment.md)
- [Wiki 文档 — 交易与特殊功能](../wiki_new/06-transactions.md)
- [协议规范 — §4 创世与初始状态](../../spec/spec_dev.md)
- [RPC API 文档](../../rpc/rpc_api_get_doc.md) | [POST 接口文档](../../rpc/rpc_api_post_doc.md)
