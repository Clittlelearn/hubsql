# RPC API POST 接口文档

本文档整理了 `rpc/api/post/` 目录下已注册的 RPC POST 接口。

**注册文件**: `rpc/http_api.cpp` (subscribeToHttpCallbacks 函数)

---

## 目录

### 基础查询接口
| 路径 | 功能 | 源文件 |
|------|------|--------|
| [GetVersion](#getversion) | 获取版本信息 | rpc_api_getVersion |
| [GetBalance](#getbalance) | 获取余额 | rpc_api_getBalance |
| [GetBlockHeight](#getblockheight) | 获取区块高度 | rpc_api_getBlockHeight |
| [GetChainId](#getchainid) | 获取链 ID | rpc_api_getChainId |
| [GetAccounts](#getaccounts) | 获取账户列表 | rpc_api_getAccounts |
| [GetNodeList](#getnodelist) | 获取节点列表 | rpc_api_getNodeList |
| [GetAllStakeNodeList](#getallstakenodelist) | 获取所有质押节点列表 | rpc_api_getAllStakeNodeList |
| [GetAddrType](#getaddrtype) | 获取地址类型 | rpc_api_getAddrType |
| [GetYieldInfo](#getyieldinfo) | 获取收益信息 | rpc_api_getYieldInfo |
| [GetBonusInfo](#getbonusinfo) | 获取奖励信息 | rpc_api_getBonusInfo |
| [GetAssetTypeByContractAddr](#getassettypebycontractaddr) | 根据合约地址获取资产类型 | rpc_api_getAssetTypeByContractAddr |

### 投票查询接口
| 路径 | 功能 | 源文件 |
|------|------|--------|
| [GetVoteAddrs](#getvoteaddrs) | 获取投票地址 | rpc_api_getVoteAddrs |
| [GetVoteTxHash](#getvotetxhash) | 获取投票交易 hash | rpc_api_getVoteTxHash |
| [GetAllAssetType](#getallassettype) | 获取所有资产类型 | rpc_api_getAllAssetType |
| [GetAssetTypeInfo](#getassettypeinfo) | 获取资产类型信息 | rpc_api_getAssetTypeInfo |

### 区块交易查询接口
| 路径 | 功能 | 源文件 |
|------|------|--------|
| [GetTransactionByHash](#gettransactionbyhash) | 根据 hash 获取交易 | rpc_api_getTransactionByHash |
| [GetBlockByHash](#getblockbyhash) | 根据 hash 获取区块 | rpc_api_getBlockByHash |
| [GetBlockByHeight](#getblockbyheight) | 根据高度获取区块 | rpc_api_getBlockByHeight |
| [GetBlockByTransactionHash](#getblockbytransactionhash) | 根据交易 hash 获取区块 | rpc_api_getBlockByTransactionHash |
| [GetDelegatingUtxo](#getdelegatingutxo) | 获取委托 UTXO | rpc_api_getDelegatingUtxo |
| [GetStakingUtxo](#getstakingutxo) | 获取质押 UTXO | rpc_api_getStakingUtxo |
| [GetLockUtxo](#getlockutxo) | 获取锁定 UTXO | rpc_api_getLockUtxo |
| [GetBlockTransactionCountByHash](#getblocktransactioncountbyhash) | 获取区块交易数量 | rpc_api_getTransactionCount |
| [GetDelegatingAddrsByBonusAddr](#getdelegatingaddrsbybonusaddr) | 根据奖励地址获取委托地址 | rpc_api_getDelegatingAddrs |
| [GetUtxoDeployerByConAddr](#getutxodeployerbyconaddr) | 根据合约地址获取部署者 | rpc_api_getUtxoDeployer |
| [IsContract](#iscontract) | 判断是否为合约 | rpc_api_isContract |
| [GetTxByHash](#gettxbyhash) | 根据 hash 获取交易详情 | rpc_api_getTransactions |
| [GetBlockNumberByHash](#getblocknumberbyhash) | 根据 hash 获取区块编号 | rpc_api_getBlocks |

### 创建交易接口
| 路径 | 功能 | 源文件 |
|------|------|--------|
| [CreateTransaction](#createtransaction) | 创建普通交易 | rpc_api_Transaction |
| [CreateStakingTransaction](#createstakingtransaction) | 创建质押交易 | rpc_api_stake |
| [CreateUnstakingTransaction](#createunstakingtransaction) | 创建解押交易 | rpc_api_unStake |
| [CreateDelegatingTransaction](#createdelegatingtransaction) | 创建委托交易 | rpc_api_delegating |
| [CreateUndelegatingTransaction](#createundelegatingtransaction) | 创建取消委托交易 | rpc_api_undelegating |
| [CreateBonusTransaction](#createbonustransaction) | 创建奖励交易 | rpc_api_bonus |
| [CreateCallContractTransaction](#createcallcontracttransaction) | 创建调用合约交易 | rpc_api_callContract |
| [CreateDeployContractTransaction](#createdeploycontracttransaction) | 创建部署合约交易 | rpc_api_deployContract |
| [SendMessage](#sendmessage) | 发送消息 | rpc_api_post_message |
| [SendContractMessage](#sendcontractmessage) | 发送合约消息 | rpc_api_postContractMsg |
| [CreateLockTransaction](#createlocktransaction) | 创建锁定交易 | rpc_api_lock |
| [CreateUnLockTransaction](#createunlocktransaction) | 创建解锁交易 | rpc_api_unlock |
| [CreateVoteTransaction](#createvotetransaction) | 创建投票交易 | rpc_api_vote |
| [CreateFundTransaction](#createfundtransaction) | 创建资金交易 | rpc_api_fund |

### Slashing 查询接口
| 路径 | 功能 | 源文件 |
|------|------|--------|
| [GetEvidenceDetail](#getevidencedetail) | 获取证据交易详情 | rpc_api_slashing |
| [GetPunishmentDetail](#getpunishmentdetail) | 获取处罚交易详情 | rpc_api_slashing |
| [GetEvidenceCount](#getevidencecount) | 获取节点证据数量 | rpc_api_slashing |
| [GetNodeSignRate](#getnodesignrate) | 获取节点签名率 | rpc_api_slashing |

### 自动化测试接口
| 路径 | 功能 | 源文件 |
|------|------|--------|
| [StartAutoTransactionTest](#startautotransactiontest) | 启动自动交易压力测试 | rpc_api_startAutoTransactionTest |
| [StartContractPoolTest](#startcontractpooltest) | 启动合约调用池压力测试 | rpc_api_startContractPoolTest |

---

## 接口详情

### GetVersion

**功能**: 获取客户端、配置、网络和数据库版本信息

**处理函数**: `ohi::rpc::getVersion`

**源文件**: `rpc_api_getVersion.h`, `rpc_api_getVersion.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**响应内容**:
```json
{
  "clientVersion": "1.0.0",
  "configVersion": "1.0.0",
  "netVersion": "1.0.0",
  "dbVersion": "1.0.0"
}
```

**调用示例**:
```bash
curl -X POST http://localhost:port/GetVersion \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetVersion","params":[],"id":1}'
```

---

### GetBalance

**功能**: 获取指定地址的余额

**处理函数**: `ohi::rpc::getBalance`

**源文件**: `rpc_api_getBalance.h`, `rpc_api_getBalance.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 账户地址 |
| asset_type | string | 是 | 资产类型 |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetBalance \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetBalance",
    "params":[{"addr":"0x1234567890abcdef","asset_type":"0x01"}],
    "id":1
  }'
```

**响应示例**:
```json
{
  "addr": "0x1234567890abcdef",
  "asset_type": "0x01",
  "balance": "1000000000"
}
```

---

### GetBlockHeight

**功能**: 获取当前区块高度

**处理函数**: `ohi::rpc::getBlockHeight`

**源文件**: `rpc_api_getBlockHeight.h`, `rpc_api_getBlockHeight.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetBlockHeight \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetBlockHeight","params":[],"id":1}'
```

**响应示例**:
```json
{
  "height": "1234567"
}
```

---

### GetChainId

**功能**: 获取链 ID（创世区块 hash 前 8 位）

**处理函数**: `ohi::rpc::getChainId`

**源文件**: `rpc_api_getChainId.h`, `rpc_api_getChainId.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetChainId \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetChainId","params":[],"id":1}'
```

**响应示例**:
```json
{
  "chainId": "0x12345678"
}
```

---

### GetAccounts

**功能**: 获取本地账户列表

**处理函数**: `ohi::rpc::getAccounts`

**源文件**: `rpc_api_getAccounts.h`, `rpc_api_getAccounts.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**响应内容**: 账户地址列表（默认账户排在首位）

**调用示例**:
```bash
curl -X POST http://localhost:port/GetAccounts \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetAccounts","params":[],"id":1}'
```

**响应示例**:
```json
{
  "acccountlist": [
    "0x1234567890abcdef",
    "0xfedcba0987654321",
    "0xabcdef1234567890"
  ]
}
```

---

### GetNodeList

**功能**: 获取节点列表

**处理函数**: `ohi::rpc::getNodelist`

**源文件**: `rpc_api_getNodeList.h`, `rpc_api_getNodeList.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**响应内容**:
- addr: 节点地址
- ip: 节点 IP
- port: 节点端口
- kind: 连接类型
- fd: 文件描述符
- pulse: 脉冲值
- height: 节点高度
- name: 节点名称
- version: 版本号
- logo: 节点 Logo（Base64 编码）

**调用示例**:
```bash
curl -X POST http://localhost:port/GetNodeList \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetNodeList","params":[],"id":1}'
```

---

### GetAllStakeNodeList

**功能**: 获取所有质押节点列表

**处理函数**: `ohi::rpc::getAllStakeNodeList`

**源文件**: `rpc_api_getAllStakeNodeList.h`, `rpc_api_getAllStakeNodeList.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**响应内容**: 已质押的节点列表，包含节点地址、名称、高度、身份、IP、版本等信息

**调用示例**:
```bash
curl -X POST http://localhost:port/GetAllStakeNodeList \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetAllStakeNodeList","params":[],"id":1}'
```

---

### GetAddrType

**功能**: 获取地址状态类型

**处理函数**: `ohi::rpc::getAddrType`

**源文件**: `rpc_api_getAddrType.h`, `rpc_api_getAddrType.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 账户地址 |

**响应格式**: `application/json`

**响应内容**:
- isBonus: 是否已领取奖励
- isDelegated: 是否已委托
- isLocked: 是否已锁定
- isPackaged: 是否已打包
- isStaked: 是否已质押
- canReward: 是否可获得奖励

**调用示例**:
```bash
curl -X POST http://localhost:port/GetAddrType \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetAddrType",
    "params":[{"addr":"0x1234567890abcdef"}],
    "id":1
  }'
```

---

### GetYieldInfo

**功能**: 获取收益信息（年化收益率）

**处理函数**: `ohi::rpc::getYieldInfo`

**源文件**: `rpc_api_getYieldInfo.h`, `rpc_api_getYieldInfo.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**响应内容**: 年化收益率

**调用示例**:
```bash
curl -X POST http://localhost:port/GetYieldInfo \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetYieldInfo","params":[],"id":1}'
```

**响应示例**:
```json
{
  "annualizedRate": "5.25"
}
```

---

### GetBonusInfo

**功能**: 获取奖励信息

**处理函数**: `ohi::rpc::getBonusInfo`

**源文件**: `rpc_api_getBonusInfo.h`, `rpc_api_getBonusInfo.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**响应内容**:
- 地址签名计数列表
- 周期时间

**调用示例**:
```bash
curl -X POST http://localhost:port/GetBonusInfo \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetBonusInfo","params":[],"id":1}'
```

---

### GetAssetTypeByContractAddr

**功能**: 根据合约地址获取对应的资产类型

**处理函数**: `ohi::rpc::getAssetTypeByContractAddr`

**源文件**: `rpc_api_getAssetTypeByContractAddr.h`, `rpc_api_getAssetTypeByContractAddr.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| contractAddr | string | 是 | 合约地址（支持带 `0x` 前缀） |

**响应格式**: `application/json`

**响应内容**:
- contractAddr: 合约地址（带 `0x` 前缀）
- assetType: 资产类型（带 `0x` 前缀）

**调用示例**:
```bash
curl -X POST http://localhost:port/GetAssetTypeByContractAddr \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetAssetTypeByContractAddr",
    "params":[{"contractAddr":"0x1234567890abcdef1234567890abcdef12345678"}],
    "id":1
  }'
```

**成功响应示例**:
```json
{
  "id": "1",
  "jsonrpc": "2.0",
  "result": {
    "contractAddr": "0x1234567890abcdef1234567890abcdef12345678",
    "assetType": "0xabcdef1234567890abcdef1234567890abcdef12"
  },
  "status": {
    "code": "0",
    "errorCallstack": ["success"]
  }
}
```

**失败响应示例**:
```json
{
  "id": "1",
  "jsonrpc": "2.0",
  "result": {},
  "status": {
    "code": "错误码",
    "errorCallstack": ["Failed to get asset type"]
  }
}
```

**说明**:
- 该接口用于查询合约地址对应的资产类型
- 输入的 `contractAddr` 支持带 `0x` 前缀，内部会自动去除前缀后查询
- 返回的 `contractAddr` 和 `assetType` 都会添加 `0x` 前缀
- 如果查询失败，会返回错误信息

---

---

### GetVoteAddrs

**功能**: 根据资产类型 hash 获取投票地址列表

**处理函数**: `ohi::rpc::getVoteAddrs`

**源文件**: `rpc_api_getVoteAddrs.h`, `rpc_api_getVoteAddrs.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 资产类型 hash |

**响应格式**: `application/json`

**响应内容**:
- approveAddrs: 赞成地址列表（地址、投票数）
- againstAddrs: 反对地址列表（地址、投票数）

**调用示例**:
```bash
curl -X POST http://localhost:port/GetVoteAddrs \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetVoteAddrs",
    "params":[{"hash":"0xabc123..."}],
    "id":1
  }'
```

---

### GetVoteTxHash

**功能**: 根据资产类型获取投票交易 hash 列表

**处理函数**: `ohi::rpc::getVoteTxHash`

**源文件**: `rpc_api_getVoteTxHash.h`, `rpc_api_getVoteTxHash.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| asset_type | string | 是 | 资产类型 |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetVoteTxHash \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetVoteTxHash",
    "params":[{"asset_type":"0x01"}],
    "id":1
  }'
```

---

### GetAllAssetType

**功能**: 获取所有资产类型

**处理函数**: `ohi::rpc::getAllAssetType`

**源文件**: `rpc_api_getAllAssetType.h`, `rpc_api_getAllAssetType.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**响应内容**: 资产类型 hash 列表

**调用示例**:
```bash
curl -X POST http://localhost:port/GetAllAssetType \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetAllAssetType","params":[],"id":1}'
```

---

### GetAssetTypeInfo

**功能**: 获取资产类型详细信息

**处理函数**: `ohi::rpc::getAssetTypeInfo`

**源文件**: `rpc_api_getAssetTypeInfo.h`, `rpc_api_getAssetTypeInfo.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| asset_type | string | 是 | 资产类型 |

**响应格式**: `application/json`

**响应内容**:
- proposalInfo: 提案信息（Base64 解码）
- revokeProposalInfo: 撤销提案信息列表

**调用示例**:
```bash
curl -X POST http://localhost:port/GetAssetTypeInfo \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetAssetTypeInfo",
    "params":[{"asset_type":"0x01"}],
    "id":1
  }'
```

---

### GetTransactionByHash

**功能**: 根据 hash 获取交易详情

**处理函数**: `ohi::rpc::getTransactionByHash`

**源文件**: `rpc_api_getTransactionByHash.h`, `rpc_api_getTransactionByHash.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 交易 hash |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetTransactionByHash \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetTransactionByHash",
    "params":[{"hash":"0xabc123..."}],
    "id":1
  }'
```

---

### GetBlockByHash

**功能**: 根据 hash 获取区块信息

**处理函数**: `ohi::rpc::getBlockByHash`

**源文件**: `rpc_api_getBlockByHash.h`, `rpc_api_getBlockByHash.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 区块 hash |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetBlockByHash \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetBlockByHash",
    "params":[{"hash":"0xabc123..."}],
    "id":1
  }'
```

---

### GetBlockByHeight

**功能**: 根据高度范围获取区块列表

**处理函数**: `ohi::rpc::getBlockByHeight`

**源文件**: `rpc_api_getBlockByHeight.h`, `rpc_api_getBlockByHeight.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| begin | uint64 | 是 | 起始高度 |
| end | uint64 | 是 | 结束高度 |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetBlockByHeight \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetBlockByHeight",
    "params":[{"begin":1000,"end":1100}],
    "id":1
  }'
```

---

### GetBlockByTransactionHash

**功能**: 根据交易 hash 获取区块信息

**处理函数**: `ohi::rpc::getBlockByTransactionHash`

**源文件**: `rpc_api_getBlockByTransactionHash.h`, `rpc_api_getBlockByTransactionHash.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 交易 hash |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetBlockByTransactionHash \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetBlockByTransactionHash",
    "params":[{"hash":"0xabc123..."}],
    "id":1
  }'
```

---

### GetDelegatingUtxo

**功能**: 获取委托 UTXO 列表

**处理函数**: `ohi::rpc::getDelegatingUtxo`

**源文件**: `rpc_api_getDelegatingUtxo.h`, `rpc_api_getDelegatingUtxo.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| toAddr | string | 是 | 目标地址（奖励地址） |
| fromAddr | string | 是 | 源地址（委托地址） |
| asset_type | string | 是 | 资产类型 |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetDelegatingUtxo \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetDelegatingUtxo",
    "params":[{
      "toAddr":"0x1234567890abcdef",
      "fromAddr":"0xfedcba0987654321",
      "asset_type":"0x01"
    }],
    "id":1
  }'
```

---

### GetStakingUtxo

**功能**: 获取质押 UTXO 列表

**处理函数**: `ohi::rpc::getStakingUtxo`

**源文件**: `rpc_api_getStakingUtxo.h`, `rpc_api_getStakingUtxo.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| fromAddr | string | 是 | 源地址 |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetStakingUtxo \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetStakingUtxo",
    "params":[{"fromAddr":"0x1234567890abcdef"}],
    "id":1
  }'
```

---

### GetLockUtxo

**功能**: 获取锁定 UTXO 列表

**处理函数**: `ohi::rpc::getLockUtxo`

**源文件**: `rpc_api_getLockUtxo.h`, `rpc_api_getLockUtxo.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| fromAddr | string | 是 | 源地址 |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetLockUtxo \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetLockUtxo",
    "params":[{"fromAddr":"0x1234567890abcdef"}],
    "id":1
  }'
```

---

### GetBlockTransactionCountByHash

**功能**: 获取区块中的交易数量

**处理函数**: `ohi::rpc::getTransactionCount`

**源文件**: `rpc_api_getTransactionCount.h`, `rpc_api_getTransactionCount.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 区块 hash |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetBlockTransactionCountByHash \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetBlockTransactionCountByHash",
    "params":[{"hash":"0xabc123..."}],
    "id":1
  }'
```

**响应示例**:
```json
{
  "txCount": "150"
}
```

---

### GetDelegatingAddrsByBonusAddr

**功能**: 根据奖励地址获取委托地址列表

**处理函数**: `ohi::rpc::getDelegatingAddrs`

**源文件**: `rpc_api_getDelegatingAddrs.h`, `rpc_api_getDelegatingAddrs.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 奖励地址 |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/GetDelegatingAddrsByBonusAddr \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetDelegatingAddrsByBonusAddr",
    "params":[{"addr":"0x1234567890abcdef"}],
    "id":1
  }'
```

---

### GetUtxoDeployerByConAddr

**功能**: 根据合约地址获取部署者信息

**处理函数**: `ohi::rpc::getUtxoDeployer`

**源文件**: `rpc_api_getUtxoDeployer.h`, `rpc_api_getUtxoDeployer.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| contractAddr | string | 是 | 合约地址 |

**响应格式**: `application/json`

**响应内容**:
- utxo: 部署 UTXO
- deployer: 部署者地址

**调用示例**:
```bash
curl -X POST http://localhost:port/GetUtxoDeployerByConAddr \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetUtxoDeployerByConAddr",
    "params":[{"contractAddr":"0x1234567890abcdef"}],
    "id":1
  }'
```

---

### IsContract

**功能**: 判断地址是否为合约地址

**处理函数**: `ohi::rpc::isContract`

**源文件**: `rpc_api_isContract.h`, `rpc_api_isContract.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 地址 |

**响应格式**: `application/json`

**响应内容**:
- isContract: boolean，是否为合约地址

**调用示例**:
```bash
curl -X POST http://localhost:port/IsContract \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"IsContract",
    "params":[{"addr":"0x1234567890abcdef"}],
    "id":1
  }'
```

---

### GetTxByHash

**功能**: 根据 hash 获取交易详细信息（CALL 类型交易）

**处理函数**: `ohi::rpc::getTransactions`

**源文件**: `rpc_api_getTransactions.h`, `rpc_api_getTransactions.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 交易 hash |

**响应格式**: `application/json`

**响应内容**:
- input: 输入数据
- sender: 发送者地址
- recipient: 接收者地址
- gas: gas 数量
- hash: 交易 hash
- nonce: nonce 值
- cumulativeGas: 累计 gas

**调用示例**:
```bash
curl -X POST http://localhost:port/GetTxByHash \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetTxByHash",
    "params":[{"hash":"0xabc123..."}],
    "id":1
  }'
```

---

### GetBlockNumberByHash

**功能**: 根据区块 hash 获取区块编号信息

**处理函数**: `ohi::rpc::getBlocks`

**源文件**: `rpc_api_getBlocks.h`, `rpc_api_getBlocks.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 区块 hash |

**响应格式**: `application/json`

**响应内容**:
- hash: 区块 hash
- timestamp: 时间戳（秒）
- number: 区块高度

**调用示例**:
```bash
curl -X POST http://localhost:port/GetBlockNumberByHash \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetBlockNumberByHash",
    "params":[{"hash":"0xabc123..."}],
    "id":1
  }'
```

---

### CreateTransaction

**功能**: 创建普通转账交易

**处理函数**: `ohi::rpc::createTransaction`

**源文件**: `rpc_api_Transaction.h`, `rpc_api_Transaction.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| tx_table | array | 是 | 交易列表（from_addr, to_addrs, asset_type） |
| gas_asset | object | 否 | gas 支付资产（addr, asset_type） |
| encoded_info | string | 否 | 附加信息 |
| is_find_utxo | bool | 否 | 是否自动查找 UTXO |
| sponsor_gas | bool | 否 | 是否代付 gas |

**响应格式**: `application/json`

**响应内容**:
- tx: 交易 JSON 字符串

**调用示例**:
```bash
curl -X POST http://localhost:port/CreateTransaction \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"CreateTransaction",
    "params":[{
      "tx_table":[{
        "from_addr":"0x1234567890abcdef",
        "to_addrs":[{"addr":"0xfedcba0987654321","amount":"100"}],
        "asset_type":"0x01"
      }],
      "gas_asset":{"addr":"0x1234567890abcdef","asset_type":"0x01"},
      "is_find_utxo":true,
      "sponsor_gas":false
    }],
    "id":1
  }'
```

---

### CreateStakingTransaction

**功能**: 创建质押交易

**处理函数**: `ohi::rpc::createStake`

**源文件**: `rpc_api_stake.h`, `rpc_api_stake.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 质押地址 |
| asset_type | string | 是 | 资产类型 |
| amount | string | 是 | 质押数量 |
| reward_rank_string | string | 是 | 奖励排名 |
| encoded_info | string | 否 | 附加信息 |
| gas_asset | object | 否 | gas 支付资产 |
| is_find_utxo | bool | 否 | 是否自动查找 UTXO |
| sponsor_gas | bool | 否 | 是否代付 gas |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/CreateStakingTransaction \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"CreateStakingTransaction",
    "params":[{
      "addr":"0x1234567890abcdef",
      "asset_type":"0x01",
      "amount":"1000",
      "reward_rank_string":"1",
      "is_find_utxo":true,
      "sponsor_gas":false
    }],
    "id":1
  }'
```

---

### CreateUnstakingTransaction

**功能**: 创建解押交易

**处理函数**: `ohi::rpc::createUnStake`

**源文件**: `rpc_api_unStake.h`, `rpc_api_unStake.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 地址 |
| assert_type | string | 是 | 资产类型 |
| stake_utxo_hash | string | 是 | 质押 UTXO hash |
| encoded_info | string | 否 | 附加信息 |
| gas_asset | object | 否 | gas 支付资产 |
| is_find_utxo | bool | 否 | 是否自动查找 UTXO |
| sponsor_gas | bool | 否 | 是否代付 gas |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/CreateUnstakingTransaction \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"CreateUnstakingTransaction",
    "params":[{
      "addr":"0x1234567890abcdef",
      "assert_type":"0x01",
      "stake_utxo_hash":"0xabc123...",
      "is_find_utxo":true,
      "sponsor_gas":false
    }],
    "id":1
  }'
```

---

### CreateDelegatingTransaction

**功能**: 创建委托交易

**处理函数**: `ohi::rpc::createDelegating`

**源文件**: `rpc_api_delegating.h`, `rpc_api_delegating.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| from_addr | string | 是 | 委托地址 |
| to_addr | string | 是 | 目标地址 |
| asset_type | string | 是 | 资产类型 |
| delegatinged_amount | string | 是 | 委托数量 |
| delegate_type | int | 是 | 委托类型 |
| encoded_info | string | 否 | 附加信息 |
| gas_asset | object | 否 | gas 支付资产 |
| is_find_utxo | bool | 否 | 是否自动查找 UTXO |
| sponsor_gas | bool | 否 | 是否代付 gas |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/CreateDelegatingTransaction \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"CreateDelegatingTransaction",
    "params":[{
      "from_addr":"0x1234567890abcdef",
      "to_addr":"0xfedcba0987654321",
      "asset_type":"0x01",
      "delegatinged_amount":"100",
      "delegate_type":1,
      "is_find_utxo":true,
      "sponsor_gas":false
    }],
    "id":1
  }'
```

---

### CreateUndelegatingTransaction

**功能**: 创建取消委托交易

**处理函数**: `ohi::rpc::createUndelegating`

**源文件**: `rpc_api_undelegating.h`, `rpc_api_undelegating.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| from_addr | string | 是 | 源地址 |
| to_addr | string | 是 | 目标地址 |
| asset_type | string | 是 | 资产类型 |
| utxo_hash | string | 是 | UTXO hash |
| encoded_info | string | 否 | 附加信息 |
| gas_asset | object | 否 | gas 支付资产 |
| is_find_utxo | bool | 否 | 是否自动查找 UTXO |
| sponsor_gas | bool | 否 | 是否代付 gas |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/CreateUndelegatingTransaction \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"CreateUndelegatingTransaction",
    "params":[{
      "from_addr":"0x1234567890abcdef",
      "to_addr":"0xfedcba0987654321",
      "asset_type":"0x01",
      "utxo_hash":"0xabc123...",
      "is_find_utxo":true,
      "sponsor_gas":false
    }],
    "id":1
  }'
```

---

### CreateBonusTransaction

**功能**: 创建奖励领取交易

**处理函数**: `ohi::rpc::createBonus`

**源文件**: `rpc_api_bonus.h`, `rpc_api_bonus.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 地址 |
| asset_type | string | 是 | 资产类型 |
| encoded_info | string | 否 | 附加信息 |
| gas_asset | object | 否 | gas 支付资产 |
| first_choose | bool | 否 | 是否首次领取 |
| is_find_utxo | bool | 否 | 是否自动查找 UTXO |
| sponsor_gas | bool | 否 | 是否代付 gas |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/CreateBonusTransaction \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"CreateBonusTransaction",
    "params":[{
      "addr":"0x1234567890abcdef",
      "asset_type":"0x01",
      "first_choose":false,
      "is_find_utxo":true,
      "sponsor_gas":false
    }],
    "id":1
  }'
```

---

### CreateCallContractTransaction

**功能**: 创建调用合约交易

**处理函数**: `ohi::rpc::createCall`

**源文件**: `rpc_api_callContract.h`, `rpc_api_callContract.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 调用者地址 |
| deployer | string | 是 | 部署者地址 |
| deployutxo | string | 是 | 部署 UTXO hash |
| args | string | 是 | 调用参数 |
| contract_address | string | 是 | 合约地址 |
| money | string | 是 | 转账金额 |
| gas_asset | object | 是 | gas 支付资产 |
| encoded_info | string | 否 | 附加信息 |
| istochain | bool | 否 | 是否上链 |
| is_find_utxo | bool | 否 | 是否自动查找 UTXO |
| pubstr | string | 否 | 公钥字符串（Base64） |

**响应格式**: `application/json`

**响应内容**:
- tx: 交易 JSON 字符串
- contract_msg: 合约消息 JSON 字符串

**调用示例**:
```bash
curl -X POST http://localhost:port/CreateCallContractTransaction \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"CreateCallContractTransaction",
    "params":[{
      "addr":"0x1234567890abcdef",
      "deployer":"0xfedcba0987654321",
      "deployutxo":"0xabc123...",
      "args":"0x1234",
      "contract_address":"0x1111111111111111",
      "money":"0",
      "gas_asset":{"addr":"0x1234567890abcdef","asset_type":"0x01"},
      "istochain":true,
      "is_find_utxo":true
    }],
    "id":1
  }'
```

---

### CreateDeployContractTransaction

**功能**: 创建部署合约交易

**处理函数**: `ohi::rpc::createDeploy`

**源文件**: `rpc_api_deployContract.h`, `rpc_api_deployContract.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 部署者地址 |
| contract | string | 是 | 合约代码 |
| data | string | 是 | 初始化数据 |
| contract_type | int | 是 | 合约类型（0=EVM） |
| gas_asset | object | 是 | gas 支付资产 |
| encoded_info | string | 否 | 附加信息 |
| is_find_utxo | bool | 否 | 是否自动查找 UTXO |
| pubstr | string | 否 | 公钥字符串（Base64） |

**响应格式**: `application/json`

**响应内容**:
- tx: 交易 JSON 字符串
- contract_msg: 合约消息 JSON 字符串

**调用示例**:
```bash
curl -X POST http://localhost:port/CreateDeployContractTransaction \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"CreateDeployContractTransaction",
    "params":[{
      "addr":"0x1234567890abcdef",
      "contract":"0x60806040...",
      "data":"0x",
      "contract_type":0,
      "gas_asset":{"addr":"0x1234567890abcdef","asset_type":"0x01"},
      "is_find_utxo":true
    }],
    "id":1
  }'
```

---

### SendMessage

**功能**: 发送交易消息

**处理函数**: `ohi::rpc::createPostMessage`

**源文件**: `rpc_api_post_message.h`, `rpc_api_post_message.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| tx | string | 是 | 交易 JSON 字符串 |
| sleep_time | string | 否 | 等待时间（秒，0-10） |

**响应格式**: `application/json`

**响应内容**:
- tx_hash: 交易 hash
- percent: 确认百分比
- receivedsize: 接收数量
- sendsize: 发送数量

**调用示例**:
```bash
curl -X POST http://localhost:port/SendMessage \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"SendMessage",
    "params":[{
      "tx":"{\"hash\":\"0xabc...\",\"utxos\":[...]}",
      "sleep_time":"3"
    }],
    "id":1
  }'
```

---

### SendContractMessage

**功能**: 发送合约交易消息

**处理函数**: `ohi::rpc::createContractMsg`

**源文件**: `rpc_api_postContractMsg.h`, `rpc_api_postContractMsg.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| contract_msg | string | 是 | 合约消息 JSON 字符串 |
| tx | string | 是 | 交易 JSON 字符串 |
| sleeptime | string | 否 | 等待时间（秒，0-10） |

**响应格式**: `application/json`

**响应内容**:
- tx_hash: 交易 hash
- percent: 确认百分比
- receivedsize: 接收数量
- sendsize: 发送数量
- tx: 确认后的交易

**调用示例**:
```bash
curl -X POST http://localhost:port/SendContractMessage \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"SendContractMessage",
    "params":[{
      "contract_msg":"{\"txmsgreq\":{...}}",
      "tx":"{\"hash\":\"0xabc...\",\"utxos\":[...]}",
      "sleeptime":"3"
    }],
    "id":1
  }'
```

---

### CreateLockTransaction

**功能**: 创建锁定交易

**处理函数**: `ohi::rpc::createLock`

**源文件**: `rpc_api_lock.h`, `rpc_api_lock.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| lock_addr | string | 是 | 锁定地址 |
| lock_amount | string | 是 | 锁定数量 |
| lock_type | int | 是 | 锁定类型 |
| encoded_info | string | 否 | 附加信息 |
| gas_asset | object | 否 | gas 支付资产 |
| is_find_utxo | bool | 否 | 是否自动查找 UTXO |
| sponsor_gas | bool | 否 | 是否代付 gas |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/CreateLockTransaction \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"CreateLockTransaction",
    "params":[{
      "lock_addr":"0x1234567890abcdef",
      "lock_amount":"1000",
      "lock_type":1,
      "is_find_utxo":true,
      "sponsor_gas":false
    }],
    "id":1
  }'
```

---

### CreateUnLockTransaction

**功能**: 创建解锁交易

**处理函数**: `ohi::rpc::createUnlock`

**源文件**: `rpc_api_unlock.h`, `rpc_api_unlock.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| lock_addr | string | 是 | 锁定地址 |
| utxo_hash | string | 是 | UTXO hash |
| encoded_info | string | 否 | 附加信息 |
| gas | object | 否 | gas 支付资产 |
| is_find_utxo | bool | 否 | 是否自动查找 UTXO |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/CreateUnLockTransaction \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"CreateUnLockTransaction",
    "params":[{
      "lock_addr":"0x1234567890abcdef",
      "utxo_hash":"0xabc123...",
      "gas":{"addr":"0x1234567890abcdef","asset_type":"0x01"},
      "is_find_utxo":true
    }],
    "id":1
  }'
```

---

### CreateVoteTransaction

**功能**: 创建投票交易

**处理函数**: `ohi::rpc::createVote`

**源文件**: `rpc_api_vote.h`, `rpc_api_vote.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 投票地址 |
| vote_hash | string | 是 | 投票提案 hash |
| vote_type | int | 是 | 投票类型（1=赞成，2=反对） |
| encoded_info | string | 否 | 附加信息 |
| gas_asset | object | 否 | gas 支付资产 |
| is_find_utxo | bool | 否 | 是否自动查找 UTXO |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/CreateVoteTransaction \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"CreateVoteTransaction",
    "params":[{
      "addr":"0x1234567890abcdef",
      "vote_hash":"0xabc123...",
      "vote_type":1,
      "gas_asset":{"addr":"0x1234567890abcdef","asset_type":"0x01"},
      "is_find_utxo":true
    }],
    "id":1
  }'
```

---

### CreateFundTransaction

**功能**: 创建资金交易

**处理函数**: `ohi::rpc::createFund`

**源文件**: `rpc_api_fund.h`, `rpc_api_fund.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 地址 |
| encoded_info | string | 否 | 附加信息 |
| is_find_utxo | bool | 否 | 是否自动查找 UTXO |

**响应格式**: `application/json`

**调用示例**:
```bash
curl -X POST http://localhost:port/CreateFundTransaction \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"CreateFundTransaction",
    "params":[{
      "addr":"0x1234567890abcdef",
      "encoded_info":"fund for development",
      "is_find_utxo":true
    }],
    "id":1
  }'
```

---

### GetEvidenceDetail

**功能**: 根据交易 hash 获取 EVIDENCE 类型交易的详细信息

**处理函数**: `ohi::rpc::getEvidenceDetail`

**源文件**: `rpc_api_slashing.h`, `rpc_api_slashing.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| tx_hash | string | 是 | 证据交易 hash |

**响应格式**: `application/json`

**响应内容**:
- tx_hash: 交易 hash
- target_addr: 被举报地址
- violation_type: 违规类型（DOUBLE_SIGN_VRF / DOUBLE_SIGN_BLOCK / LOW_SIGN_RATE）
- evidence_hash: 证据 hash
- reporter_count: 举报人数量（签名数）
- block_hash: 所在区块 hash
- status: 状态

**调用示例**:
```bash
curl -X POST http://localhost:port/GetEvidenceDetail \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetEvidenceDetail",
    "params":[{"tx_hash":"0xabc123..."}],
    "id":1
  }'
```

**响应示例**:
```json
{
  "tx_hash": "0xabc123...",
  "target_addr": "0x1234567890abcdef",
  "violation_type": "DOUBLE_SIGN_VRF",
  "evidence_hash": "0xdef456...",
  "reporter_count": 3,
  "block_hash": "0x789abc...",
  "status": "success"
}
```

---

### GetPunishmentDetail

**功能**: 根据交易 hash 或处罚 ID 获取 PUNISHMENT 类型交易的详细信息

**处理函数**: `ohi::rpc::getPunishmentDetail`

**源文件**: `rpc_api_slashing.h`, `rpc_api_slashing.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| tx_hash | string | 否 | 处罚交易 hash（与 punishment_id 二选一） |
| punishment_id | string | 否 | 处罚 ID（与 tx_hash 二选一） |

**响应格式**: `application/json`

**响应内容**:
- tx_hash: 交易 hash
- target_addr: 被处罚地址
- penalty_level: 处罚等级
- violation_type: 违规类型
- evidence_refs: 证据引用
- punishment_id: 处罚 ID
- stake_refs: 质押引用
- block_hash: 所在区块 hash

**调用示例**:
```bash
curl -X POST http://localhost:port/GetPunishmentDetail \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetPunishmentDetail",
    "params":[{"tx_hash":"0xabc123..."}],
    "id":1
  }'
```

**响应示例**:
```json
{
  "tx_hash": "0xabc123...",
  "target_addr": "0x1234567890abcdef",
  "penalty_level": 2,
  "violation_type": "LOW_SIGN_RATE",
  "evidence_refs": "ref1,ref2",
  "punishment_id": "pun_001",
  "stake_refs": [],
  "block_hash": "0x789abc..."
}
```

---

### GetEvidenceCount

**功能**: 获取指定地址的违规证据数量统计

**处理函数**: `ohi::rpc::getEvidenceCount`

**源文件**: `rpc_api_slashing.h`, `rpc_api_slashing.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 节点地址 |
| type | string | 否 | 违规类型过滤（DOUBLE_SIGN_VRF / DOUBLE_SIGN_BLOCK / LOW_SIGN_RATE），不传则返回所有类型 |

**响应格式**: `application/json`

**响应内容**:
- addr: 节点地址
- evidence_counts: 各类违规证据数量
- status: 状态

**调用示例**:
```bash
# 获取所有类型的证据数量
curl -X POST http://localhost:port/GetEvidenceCount \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetEvidenceCount",
    "params":[{"addr":"0x1234567890abcdef"}],
    "id":1
  }'

# 获取特定类型的证据数量
curl -X POST http://localhost:port/GetEvidenceCount \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetEvidenceCount",
    "params":[{"addr":"0x1234567890abcdef","type":"LOW_SIGN_RATE"}],
    "id":1
  }'
```

**响应示例**:
```json
{
  "addr": "0x1234567890abcdef",
  "evidence_counts": {
    "DOUBLE_SIGN_VRF": 0,
    "DOUBLE_SIGN_BLOCK": 1,
    "LOW_SIGN_RATE": 3
  },
  "status": "success"
}
```

---

### GetNodeSignRate

**功能**: 获取指定节点在一段时间范围内的签名率

**处理函数**: `ohi::rpc::getNodeSignRate`

**源文件**: `rpc_api_slashing.h`, `rpc_api_slashing.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 节点地址 |
| start_period | uint64 | 否 | 起始周期（默认当前周期前 100） |
| end_period | uint64 | 否 | 结束周期（默认当前周期） |

**响应格式**: `application/json`

**响应内容**:
- addr: 节点地址
- start_period: 起始周期
- end_period: 结束周期
- signed_count: 签名次数
- total_periods: 总周期数
- sign_rate: 签名率（0.0 ~ 1.0）
- status: 状态

**调用示例**:
```bash
curl -X POST http://localhost:port/GetNodeSignRate \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"GetNodeSignRate",
    "params":[{"addr":"0x1234567890abcdef","start_period":12000,"end_period":12100}],
    "id":1
  }'
```

**响应示例**:
```json
{
  "addr": "0x1234567890abcdef",
  "start_period": 12000,
  "end_period": 12100,
  "signed_count": 85,
  "total_periods": 101,
  "sign_rate": 0.8416,
  "status": "success"
}
```

---

### StartAutoTransactionTest

**功能**: 启动自动交易压力测试。在后台线程中，使用节点账户列表中的地址，按指定频率持续创建交易，运行指定时长后自动停止，并生成 TPS 报告。

**处理函数**: `ohi::rpc::startAutoTransactionTest`

**源文件**: `rpc_api_startAutoTransactionTest.h`, `rpc_api_startAutoTransactionTest.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| time_s | int | 是 | 测试持续时间（秒） |
| TxNum | int | 是 | 每秒创建的交易数量 |
| timeout | int | 是 | 交易超时时间（秒），默认 1 |
| asset_type | string | 是 | 资产类型标识 |

**响应格式**: `application/json`

**响应内容**:
- height: 固定返回 `"started"` 表示测试已启动

**说明**:
- 接口立即返回，实际测试在后台线程中运行
- 测试结束后自动生成 TPS 报告，tag 格式: `6_t{time_s}s_f{TxNum}_i{timeout}s`

**调用示例**:
```bash
curl -X POST http://localhost:port/StartAutoTransactionTest \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"StartAutoTransactionTest",
    "params":[{"time_s":60,"TxNum":10,"timeout":1,"asset_type":"0x01"}],
    "id":1
  }'
```

**响应示例**:
```json
{
  "id": "1",
  "jsonrpc": "2.0",
  "result": {
    "height": "started"
  },
  "status": {
    "code": "0",
    "errorCallstack": ["success"]
  }
}
```

---

### StartContractPoolTest

**功能**: 启动合约调用池压力测试。从 `contract.json` 加载合约任务列表，循环调用合约，使用不同账户轮转发起调用，运行指定时长后生成 TPS 报告。

**处理函数**: `ohi::rpc::startContractPoolTest`

**源文件**: `rpc_api_startContractPoolTest.h`, `rpc_api_startContractPoolTest.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| time_s | int | 是 | 测试持续时间（秒） |
| second | long long | 是 | 时间窗口（秒），默认 1 |
| much | long long | 是 | 每个时间窗口内的调用次数，默认 1 |

**响应格式**: `application/json`

**响应内容**:
- height: 固定返回 `"started"` 表示测试已启动

**说明**:
- 接口立即返回，实际测试在后台线程中运行
- 从 `contract.json` 读取合约任务，使用账户列表轮转
- 测试结束后自动生成 TPS 报告，tag 格式: `33_t{time_s}s_m{much}_s{second}`
- 预期交易数 = `time_s * much`

**调用示例**:
```bash
curl -X POST http://localhost:port/StartContractPoolTest \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"StartContractPoolTest",
    "params":[{"time_s":60,"second":1,"much":10}],
    "id":1
  }'
```

**响应示例**:
```json
{
  "id": "1",
  "jsonrpc": "2.0",
  "result": {
    "height": "started"
  },
  "status": {
    "code": "0",
    "errorCallstack": ["success"]
  }
}
```

---

## 附录

### 公共响应格式说明

所有接口均使用 JSON-RPC 2.0 格式响应：

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    // 具体响应内容
  }
}
```

### 错误处理

错误响应包含错误码和错误信息：

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32000,
    "message": "错误描述"
  }
}
```

---

### 命名空间

所有 RPC 接口均位于 `ohi::rpc` 命名空间下。

### 注册代码位置

接口注册位于 `rpc/http_api.cpp` 的 `subscribeToHttpCallbacks` 函数中：

```cpp
// 本机查询
HttpServer::RegisterCallback("/GetVersion", ohi::rpc::getVersion);
HttpServer::RegisterCallback("/GetBalance", ohi::rpc::getBalance);
HttpServer::RegisterCallback("/GetBlockHeight", ohi::rpc::getBlockHeight);
HttpServer::RegisterCallback("/GetChainId", ohi::rpc::getChainId);
HttpServer::RegisterCallback("/GetAccounts", ohi::rpc::getAccounts);
HttpServer::RegisterCallback("/GetNodeList", ohi::rpc::getNodelist);
HttpServer::RegisterCallback("/GetAllStakeNodeList", ohi::rpc::getAllStakeNodeList);
HttpServer::RegisterCallback("/GetAddrType", ohi::rpc::getAddrType);
HttpServer::RegisterCallback("/GetYieldInfo", ohi::rpc::getYieldInfo);
HttpServer::RegisterCallback("/GetBonusInfo", ohi::rpc::getBonusInfo);

HttpServer::RegisterCallback("/GetVoteAddrs", ohi::rpc::getVoteAddrs);
HttpServer::RegisterCallback("/GetVoteTxHash", ohi::rpc::getVoteTxHash);
HttpServer::RegisterCallback("/GetAllAssetType", ohi::rpc::getAllAssetType);
HttpServer::RegisterCallback("/GetAssetTypeInfo", ohi::rpc::getAssetTypeInfo);
HttpServer::RegisterCallback("/GetAssetTypeByContractAddr", ohi::rpc::getAssetTypeByContractAddr);

// 区块交易查询
HttpServer::RegisterCallback("/GetTransactionByHash", ohi::rpc::getTransactionByHash);
HttpServer::RegisterCallback("/GetBlockByHash", ohi::rpc::getBlockByHash);
HttpServer::RegisterCallback("/GetBlockByHeight", ohi::rpc::getBlockByHeight);
HttpServer::RegisterCallback("/GetBlockByTransactionHash", ohi::rpc::getBlockByTransactionHash);
HttpServer::RegisterCallback("/GetDelegatingUtxo", ohi::rpc::getDelegatingUtxo);
HttpServer::RegisterCallback("/GetStakingUtxo", ohi::rpc::getStakingUtxo);
HttpServer::RegisterCallback("/GetLockUtxo", ohi::rpc::getLockUtxo);
HttpServer::RegisterCallback("/GetBlockTransactionCountByHash", ohi::rpc::getTransactionCount);
HttpServer::RegisterCallback("/GetDelegatingAddrsByBonusAddr", ohi::rpc::getDelegatingAddrs);
HttpServer::RegisterCallback("/GetUtxoDeployerByConAddr", ohi::rpc::getUtxoDeployer);
HttpServer::RegisterCallback("/IsContract", ohi::rpc::isContract);
HttpServer::RegisterCallback("/GetTxByHash", ohi::rpc::getTransactions);
HttpServer::RegisterCallback("/GetBlockNumberByHash", ohi::rpc::getBlocks);

// 创建交易
HttpServer::RegisterCallback("/CreateTransaction", ohi::rpc::createTransaction);
HttpServer::RegisterCallback("/CreateStakingTransaction", ohi::rpc::createStake);
HttpServer::RegisterCallback("/CreateUnstakingTransaction", ohi::rpc::createUnStake);
HttpServer::RegisterCallback("/CreateDelegatingTransaction", ohi::rpc::createDelegating);
HttpServer::RegisterCallback("/CreateUndelegatingTransaction", ohi::rpc::createUndelegating);
HttpServer::RegisterCallback("/CreateBonusTransaction", ohi::rpc::createBonus);
HttpServer::RegisterCallback("/CreateCallContractTransaction", ohi::rpc::createCall);
HttpServer::RegisterCallback("/CreateDeployContractTransaction", ohi::rpc::createDeploy);
HttpServer::RegisterCallback("/SendMessage", ohi::rpc::createPostMessage);
HttpServer::RegisterCallback("/SendContractMessage", ohi::rpc::createContractMsg);
HttpServer::RegisterCallback("/CreateLockTransaction", ohi::rpc::createLock);
HttpServer::RegisterCallback("/CreateUnLockTransaction", ohi::rpc::createUnlock);
HttpServer::RegisterCallback("/CreateVoteTransaction", ohi::rpc::createVote);
HttpServer::RegisterCallback("/CreateFundTransaction", ohi::rpc::createFund);

// Slashing 查询接口 (POST)
HttpServer::RegisterCallback("/GetEvidenceDetail", ohi::rpc::getEvidenceDetail);
HttpServer::RegisterCallback("/GetPunishmentDetail", ohi::rpc::getPunishmentDetail);
HttpServer::RegisterCallback("/GetEvidenceCount", ohi::rpc::getEvidenceCount);
HttpServer::RegisterCallback("/GetNodeSignRate", ohi::rpc::getNodeSignRate);

// 自动化测试接口
HttpServer::RegisterCallback("/StartContractPoolTest", ohi::rpc::startContractPoolTest);
HttpServer::RegisterCallback("/StartAutoTransactionTest", ohi::rpc::startAutoTransactionTest);
```

---

*文档更新日期：2026 年 7 月 14 日*
