# RPC API Ethereum 兼容 JSON-RPC 接口文档

本文档整理了 OpenHive 节点支持的以太坊兼容 JSON-RPC 接口。这些接口遵循以太坊 JSON-RPC 2.0 规范，允许使用标准以太坊工具（如 MetaMask、web3.js、ethers.js 等）与 OpenHive 节点交互。

**注册文件**: `rpc/http_api.cpp` (subscribeToHttpCallbacks 函数，通过 `RegisterEthCallback` 注册)

**实现文件**: `rpc/eth/eth_rpc.cpp`, `rpc/eth/eth_impl.cpp`

---

## 目录

### 链信息接口
| 方法名 | 功能 | 参数 |
|--------|------|------|
| [eth_chainId](#eth_chainid) | 获取链 ID | 无 |
| [net_version](#net_version) | 获取网络版本 | 无 |
| [web3_clientVersion](#web3_clientversion) | 获取客户端版本 | 无 |
| [eth_accounts](#eth_accounts) | 获取节点管理的账户列表 | 无 |

### 区块查询接口
| 方法名 | 功能 | 参数 |
|--------|------|------|
| [eth_blockNumber](#eth_blocknumber) | 获取当前区块高度 | 无 |
| [eth_getBlockByNumber](#eth_getblockbynumber) | 按区块号获取区块 | number, isFull |
| [eth_getBlockByHash](#eth_getblockbyhash) | 按区块 hash 获取区块 | hash, isFull |

### 账户查询接口
| 方法名 | 功能 | 参数 |
|--------|------|------|
| [eth_getBalance](#eth_getbalance) | 获取账户余额 | address |
| [eth_getTransactionCount](#eth_gettransactioncount) | 获取账户交易计数 (nonce) | address |
| [eth_getCode](#eth_getcode) | 获取合约代码 | address |

### 交易接口
| 方法名 | 功能 | 参数 |
|--------|------|------|
| [eth_sendRawTransaction](#eth_sendrawtransaction) | 发送签名原始交易 | signed tx data |
| [eth_call](#eth_call) | 执行合约只读调用 | tx object |
| [eth_getTransactionByHash](#eth_gettransactionbyhash) | 按 hash 获取交易详情 | tx hash |
| [eth_getTransactionReceipt](#eth_gettransactionreceipt) | 获取交易回执 | tx hash |

### Gas 相关接口
| 方法名 | 功能 | 参数 |
|--------|------|------|
| [eth_gasPrice](#eth_gasprice) | 获取当前 Gas 价格 | 无 |
| [eth_estimateGas](#eth_estimategas) | 估算交易所需 Gas | tx data |
| [eth_maxPriorityFeePerGas](#eth_maxpriorityfeepergas) | 获取建议最大优先 Gas 费 | 无 |
| [eth_feeHistory](#eth_feehistory) | 获取历史 Gas 费信息 | blockCount, newestBlock, percentiles |

---

## 通用说明

### 请求格式

所有接口遵循以太坊 JSON-RPC 2.0 规范：

```json
{
  "jsonrpc": "2.0",
  "method": "eth_methodName",
  "params": [...],
  "id": 1
}
```

### 成功响应格式

```json
{
  "jsonrpc": "2.0",
  "result": ...,
  "id": 1
}
```

### 错误响应格式

```json
{
  "jsonrpc": "2.0",
  "error": {
    "code": -32603,
    "message": "错误描述",
    "data": "详细信息"
  },
  "id": 1
}
```

### 区块标签

部分接口支持以下区块标签：
- `"latest"` — 最新区块
- `"earliest"` — 创世区块
- `"pending"` — 待处理区块
- Hex 编码的区块号，如 `"0x1a4"`

### 调用方式

所有接口通过 POST 请求发送到节点 HTTP 端口：

```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"METHOD_NAME","params":[...],"id":1}'
```

---

## 接口详情

---

### eth_chainId

**功能**: 返回当前链的 Chain ID

**请求参数**: 无

**响应格式**: Hex 编码的链 ID 字符串

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": "0x301b",
  "id": 1
}
```

**说明**: Chain ID 为 12315（十六进制 `0x301b`）

---

### net_version

**功能**: 返回当前网络版本

**请求参数**: 无

**响应格式**: 网络版本字符串

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"net_version","params":[],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": "12315",
  "id": 1
}
```

---

### web3_clientVersion

**功能**: 返回当前客户端版本信息

**请求参数**: 无

**响应格式**: 版本字符串

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"web3_clientVersion","params":[],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": "",
  "id": 1
}
```

---

### eth_accounts

**功能**: 返回节点管理的账户地址列表

**请求参数**: 无

**响应格式**: 地址数组

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_accounts","params":[],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": ["0x1234567890abcdef1234567890abcdef12345678"],
  "id": 1
}
```

**说明**: 返回节点的默认账户地址，地址带 `0x` 前缀

---

### eth_blockNumber

**功能**: 返回当前最新区块高度

**请求参数**: 无

**响应格式**: Hex 编码的区块高度字符串

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": "0x1a4",
  "id": 1
}
```

---

### eth_getBlockByNumber

**功能**: 按区块号获取区块信息

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| params[0] | string | 是 | 区块号（hex）或区块标签（`"latest"` / `"earliest"` / `"pending"`） |
| params[1] | bool | 是 | 是否返回完整交易对象（`true`）或仅返回交易 hash（`false`） |

**响应格式**: 区块 JSON 对象，找不到时返回 `null`

**响应内容**:
| 字段 | 类型 | 说明 |
|------|------|------|
| number | string | 区块高度（hex） |
| hash | string | 区块 hash |
| parentHash | string | 父区块 hash |
| timestamp | string | 时间戳（hex） |
| gasLimit | string | Gas 上限（hex） |
| gasUsed | string | Gas 使用量（hex） |
| miner | string | 矿工地址 |
| difficulty | string | 难度（hex） |
| totalDifficulty | string | 总难度（hex） |
| size | string | 区块大小（hex） |
| extraData | string | 附加数据 |
| logsBloom | string | 日志 bloom 过滤器 |
| transactionsRoot | string | 交易树根 hash |
| stateRoot | string | 状态树根 hash |
| receiptsRoot | string | 回执树根 hash |
| sha3Uncles | string | 叔块 hash |
| mixHash | string | Mix hash |
| nonce | string | Nonce |
| transactions | array | 交易列表（hash 数组或完整交易对象数组） |
| uncles | array | 叔块列表（始终为空） |

**调用示例**:
```bash
# 获取最新区块（仅交易 hash）
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_getBlockByNumber","params":["latest",false],"id":1}'

# 获取指定高度区块（完整交易对象）
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_getBlockByNumber","params":["0x1a4",true],"id":1}'
```

---

### eth_getBlockByHash

**功能**: 按区块 hash 获取区块信息

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| params[0] | string | 是 | 区块 hash（hex） |
| params[1] | bool | 是 | 是否返回完整交易对象 |

**响应格式**: 区块 JSON 对象（字段同 `eth_getBlockByNumber`），找不到时返回 `null`

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_getBlockByHash","params":["0xabc123...",false],"id":1}'
```

---

### eth_getBalance

**功能**: 获取指定地址的账户余额

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| params[0] | string | 是 | 账户地址（hex，带 `0x` 前缀） |

**响应格式**: Hex 编码的余额字符串（18 位精度，单位 wei）

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_getBalance","params":["0x1234567890abcdef1234567890abcdef12345678"],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": "0x38d7ea4c68000",
  "id": 1
}
```

**说明**: 内部以 8 位精度存储，返回时自动转换为 18 位精度（乘以 10^10）。余额为 0 时返回 `"0x0"`。

---

### eth_getTransactionCount

**功能**: 获取指定地址的交易计数（nonce）

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| params[0] | string | 是 | 账户地址（hex，带 `0x` 前缀） |

**响应格式**: Hex 编码的 nonce 值

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_getTransactionCount","params":["0x1234567890abcdef1234567890abcdef12345678"],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": "0x5",
  "id": 1
}
```

**说明**: 如果地址不存在，返回 `"0x0"`

---

### eth_getCode

**功能**: 获取指定合约地址的合约代码

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| params[0] | string | 是 | 合约地址（hex，带 `0x` 前缀） |

**响应格式**: Hex 编码的合约字节码，带 `0x` 前缀。无合约时返回 `"0x"`

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_getCode","params":["0x1234567890abcdef1234567890abcdef12345678"],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": "0x6080604052...",
  "id": 1
}
```

---

### eth_sendRawTransaction

**功能**: 提交签名后的原始交易（RLP 编码）。支持多种交易类型，根据交易内容自动分发处理。

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| params[0] | string | 是 | RLP 编码的签名交易 hex 字符串 |

**响应格式**: 交易 hash（hex，带 `0x` 前缀）

**交易类型分发逻辑**:

| 条件 | 交易类型 | 说明 |
|------|----------|------|
| `to` 为空 | 合约部署 (DEPLOY) | 自动计算合约地址，创建部署交易 |
| `data` 为合法 JSON | 业务菜单交易 | 根据 JSON 中的 `type` 字段分发到对应处理器 |
| `data` 非 JSON 且 `to` 是合约地址 | 合约调用 (CALL) | 创建 EVM 合约调用交易 |
| `data` 为空 | 普通转账 | 使用 OHI 资产类型创建转账交易 |

**业务菜单交易支持的 type 值**:

| type | 说明 |
|------|------|
| `tx` / `transaction` | 普通转账 |
| `stake` | 质押 |
| `unstake` | 解除质押 |
| `delegating` / `delegate` | 委托 |
| `undelegating` / `undelegate` | 撤销委托 |
| `bonus` | 领取奖励 |
| `lock` | 锁定（投票质押） |
| `unlock` | 解除锁定 |
| `vote` | 投票（赞成/反对提案） |
| `proposal` | 发起提案 |
| `revoke_proposal` | 撤销提案 |
| `fund` / `treasury` | 申领国库奖励 |

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_sendRawTransaction","params":["0xf86c0a8502540be40082520894..."],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": "0xabc123def456...",
  "id": 1
}
```

---

### eth_call

**功能**: 执行合约只读调用，不产生链上交易

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| params[0] | object | 是 | 调用参数对象 |
| params[0].to | string | 是 | 合约地址 |
| params[0].data | string | 是 | 调用数据（函数选择器 + 参数） |
| params[0].from | string | 否 | 调用者地址，默认使用节点默认账户 |

**响应格式**: Hex 编码的返回值，带 `0x` 前缀。合约不存在时返回 `"0x"`

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "method":"eth_call",
    "params":[{
      "to":"0x1234567890abcdef1234567890abcdef12345678",
      "data":"0x70a08231000000000000000000000000abcdef..."
    }],
    "id":1
  }'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": "0x000000000000000000000000000000000000000000000000000000000000000c",
  "id": 1
}
```

---

### eth_getTransactionByHash

**功能**: 按 hash 查询交易详情

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| params[0] | string | 是 | 交易 hash（hex） |

**响应格式**: 交易 JSON 对象，找不到时返回 `null`

**响应内容**:
| 字段 | 类型 | 说明 |
|------|------|------|
| blockHash | string | 区块 hash |
| blockNumber | string | 区块高度（hex） |
| hash | string | 交易 hash |
| from | string | 发送者地址 |
| to | string | 接收者地址（部署交易为 `null`） |
| nonce | string | Nonce |
| value | string | 转账金额（hex） |
| gas | string | Gas 限制（hex） |
| gasPrice | string | Gas 价格（hex） |
| maxFeePerGas | string | 最大 Gas 费（hex） |
| maxPriorityFeePerGas | string | 最大优先 Gas 费（hex） |
| input | string | 输入数据 |
| type | string | 交易类型 |
| chainId | string | 链 ID（hex） |
| transactionIndex | string | 交易索引（hex） |
| v | string | 签名 v 值 |
| r | string | 签名 r 值 |
| s | string | 签名 s 值 |
| accessList | array | 访问列表 |

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_getTransactionByHash","params":["0xabc123..."],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": {
    "blockHash": "0xdef456...",
    "blockNumber": "0x1a4",
    "hash": "0xabc123...",
    "from": "0x1111...",
    "to": "0x2222...",
    "nonce": "0x0",
    "value": "0x0",
    "gas": "0x1",
    "gasPrice": "0x1",
    "maxFeePerGas": "0x1",
    "maxPriorityFeePerGas": "0x1",
    "input": "0x",
    "type": "0x2",
    "chainId": "0x301b",
    "transactionIndex": "0x0",
    "v": "0x0",
    "r": "0x0",
    "s": "0x0",
    "accessList": []
  },
  "id": 1
}
```

**说明**: 同时支持内部交易 hash 和 RLP hash（钱包通过 keccak256(signedRlp) 计算的 hash）查询

---

### eth_getTransactionReceipt

**功能**: 获取交易回执

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| params[0] | string | 是 | 交易 hash（hex） |

**响应格式**: 交易回执 JSON 对象，找不到时返回 `null`

**响应内容**:
| 字段 | 类型 | 说明 |
|------|------|------|
| transactionHash | string | 交易 hash |
| blockHash | string | 区块 hash |
| blockNumber | string | 区块高度（hex） |
| from | string | 发送者地址（checksum 格式） |
| to | string | 接收者地址（部署交易为 `null`） |
| contractAddress | string | 合约地址（仅部署交易有值，其他为 `null`） |
| transactionIndex | string | 交易索引 |
| cumulativeGasUsed | string | 累计 Gas 使用量（hex） |
| gasUsed | string | Gas 使用量（hex） |
| effectiveGasPrice | string | 有效 Gas 价格（hex） |
| status | string | 交易状态（`"0x1"` = 成功） |
| logs | array | 事件日志列表 |
| logsBloom | string | 日志 bloom 过滤器 |
| type | string | 交易类型 |

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_getTransactionReceipt","params":["0xabc123..."],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": {
    "transactionHash": "0xabc123...",
    "blockHash": "0xdef456...",
    "blockNumber": "0x1a4",
    "from": "0x1111...",
    "to": "0x2222...",
    "contractAddress": null,
    "transactionIndex": "0x0",
    "cumulativeGasUsed": "0xb",
    "gasUsed": "0xb",
    "effectiveGasPrice": "0x1",
    "status": "0x1",
    "logs": [],
    "logsBloom": "0x0000...0000",
    "type": "0x2"
  },
  "id": 1
}
```

**说明**: 同时支持内部交易 hash 和 RLP hash 查询。根据交易类型自动设置 `to` 和 `contractAddress`：
- 普通交易/合约调用：`to` 有值，`contractAddress` 为 `null`
- 合约部署：`to` 为 `null`，`contractAddress` 有值

---

### eth_gasPrice

**功能**: 返回当前 Gas 价格

**请求参数**: 无

**响应格式**: Hex 编码的 Gas 价格字符串（单位 wei）

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_gasPrice","params":[],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": "0x1",
  "id": 1
}
```

---

### eth_estimateGas

**功能**: 估算交易所需 Gas 数量

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| params | array | 否 | 交易数据数组（当前实现返回固定值） |

**响应格式**: Hex 编码的 Gas 估算值

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_estimateGas","params":[],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": "0x7a120",
  "id": 1
}
```

**说明**: 当前返回固定值 500000（`0x7a120`）

---

### eth_maxPriorityFeePerGas

**功能**: 返回建议的最大优先 Gas 费（tip）

**请求参数**: 无

**响应格式**: Hex 编码的 Gas 价格字符串（单位 wei）

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_maxPriorityFeePerGas","params":[],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": "0x1",
  "id": 1
}
```

---

### eth_feeHistory

**功能**: 返回历史 Gas 费信息

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| params[0] | string | 是 | 请求的区块数量（hex） |
| params[1] | string | 是 | 最新区块号（hex）或区块标签 |
| params[2] | array | 否 | 奖励百分位数列表 |

**响应格式**: Gas 费历史 JSON 对象

**响应内容**:
| 字段 | 类型 | 说明 |
|------|------|------|
| oldestBlock | string | 最旧区块号（hex） |
| baseFeePerGas | array | 每个区块的基础 Gas 费数组 |
| gasUsedRatio | array | 每个区块的 Gas 使用率数组 |
| reward | array | 奖励数据数组 |

**调用示例**:
```bash
curl -X POST http://localhost:port \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_feeHistory","params":["0xa","latest",[25,75]],"id":1}'
```

**响应示例**:
```json
{
  "jsonrpc": "2.0",
  "result": {
    "oldestBlock": "0x1",
    "baseFeePerGas": ["0x1", "0x1"],
    "gasUsedRatio": [0.0],
    "reward": [["0x1"]]
  },
  "id": 1
}
```

---

## 附录

### 注册代码位置

ETH 兼容接口注册位于 `rpc/http_api.cpp` 的 `subscribeToHttpCallbacks` 函数中：

```cpp
HttpServer::RegisterEthCallback(ETH_LAMDA(eth_chainId));
HttpServer::RegisterEthCallback(ETH_LAMDA(net_version));
HttpServer::RegisterEthCallback(ETH_LAMDA(eth_blockNumber));
HttpServer::RegisterEthCallback(ETH_LAMDA(eth_gasPrice));
HttpServer::RegisterEthCallback(ETH_LAMDA(eth_getBalance));
HttpServer::RegisterEthCallback(ETH_LAMDA(eth_getTransactionCount));
HttpServer::RegisterEthCallback(ETH_LAMDA(eth_sendRawTransaction));
HttpServer::RegisterEthCallback({"eth_call", ...});
HttpServer::RegisterEthCallback({"eth_getBlockByNumber", ...});
HttpServer::RegisterEthCallback({"eth_maxPriorityFeePerGas", ...});
HttpServer::RegisterEthCallback({"eth_feeHistory", ...});
HttpServer::RegisterEthCallback(ETH_LAMDA(web3_clientVersion));
HttpServer::RegisterEthCallback(ETH_LAMDA(eth_getCode));
HttpServer::RegisterEthCallback(ETH_LAMDA(eth_getTransactionReceipt));
HttpServer::RegisterEthCallback(ETH_LAMDA(eth_getBlockByHash));
HttpServer::RegisterEthCallback(ETH_LAMDA(eth_estimateGas));
HttpServer::RegisterEthCallback(ETH_LAMDA(eth_getTransactionByHash));
HttpServer::RegisterEthCallback(ETH_LAMDA(eth_accounts));
```

### 关键源文件

| 文件 | 用途 |
|------|------|
| `rpc/eth/eth_rpc.cpp` | 所有 ETH 接口的主实现 |
| `rpc/eth/eth_rpc.h` | ETH 接口函数声明 |
| `rpc/eth/eth_rpc_json_def.h` | 请求/响应 JSON 结构体定义 |
| `rpc/eth/eth_impl.cpp` | 底层数据库查询实现 |
| `rpc/eth/eth_impl.h` | 底层实现函数声明 |
| `rpc/eth/eth.h` | 基础框架结构体 |

### 与原生 RPC 的关系

ETH 兼容接口与 OpenHive 原生 RPC 接口并行存在，功能上有部分重叠：

| ETH 接口 | 对应的原生接口 |
|----------|----------------|
| `eth_chainId` | `/GetChainId` |
| `eth_blockNumber` | `/GetBlockHeight` |
| `eth_getBalance` | `/GetBalance` |
| `eth_accounts` | `/GetAccounts` |
| `web3_clientVersion` | `/GetVersion` |
| `eth_getBlockByHash` | `/GetBlockByHash` |
| `eth_getTransactionByHash` | `/GetTransactionByHash` |

ETH 接口主要面向以太坊生态工具（MetaMask、web3.js 等），原生接口提供更丰富的 OpenHive 特有功能。

---

*文档生成日期：2026 年 7 月 14 日*
