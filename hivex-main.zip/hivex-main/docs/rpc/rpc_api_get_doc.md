# RPC API GET 接口文档

本文档整理了 `rpc/api/get/` 目录下已注册的 RPC GET 接口。

**注册文件**: `rpc/http_api.cpp` (subscribeToHttpCallbacks 函数)

---

## 目录

| 路径 | 功能 | 源文件 |
|------|------|--------|
| [/block](#block) | 获取区块列表 | rpc_api_getBlock |
| [/get_block](#get_block) | 获取区块数据 (JSON) | rpc_api_getBlockRequest |
| [/pub](#pub) | 获取线程和请求统计 | rpc_api_getPub |
| [/account](#account) | 获取账户列表 | rpc_api_getAccount |
| [/Node](#node) | 获取节点列表 | rpc_api_getNode |
| [/ShowVRFInfo](#showvrfinfo) | 获取 VRF 验证信息 | rpc_api_getVrfInfo |
| [/printCalcHash](#printcalchash) | 打印千块汇总 hash | rpc_api_printCalcHash |
| [/printhundredhash](#printhundredhash) | 打印百块汇总 hash | rpc_api_printHundredSumHash |
| [/printblock](#printblock) | 打印区块 hash 到文件 | rpc_api_printBlock |
| [/SystemInfo](#systeminfo) | 获取系统信息 | rpc_api_getSystemInfo |
| [/printVoteInfo](#printvoteinfo) | 打印投票信息 | rpc_api_printVoteInfo |
| [/printLockAddrs](#printlockaddrs) | 打印锁定地址 | rpc_api_printLockAddrs |
| [/printProposalInfoByHash](#printproposalinfobyhash) | 打印提案详细信息 | rpc_api_printProposalInfo |
| [/printAvailableAssetType](#printavailableassettype) | 打印可用资产类型 | rpc_api_printAssetType |
| [/printAsseTypeByContractAddr](#printassettypebycontractaddr) | 根据合约地址查资产类型 | rpc_api_getAssetType |
| [/GetPublicIp](#getpublicip) | 获取公网 IP | rpc_api_getPublicIp |
| [/GetRollbackBlocks](#getrollbackblocks) | 获取回滚区块信息 | rpc_api_getAllRollBackBlocks |
| [/api](#api) | API 模板（参数/响应示例） | rpc_template |
| [/Get30daylockdatas](#get30daylockdatas) | 获取 30 天锁定 UTXO 数据 | rpc_api_get30dayLockUtxos |
| [/Confirm](#confirm) | 查询交易上链确认状态 | rpc_api_getBlockRateByTxHash |
| [/GetBlockRateProbeResults](#getblockrateproberesults) | 获取区块上链率探测结果 | rpc_api_getBlockRateProbeResults |

### Slashing 监控接口
| 路径 | 功能 | 源文件 |
|------|------|--------|
| [/GetSlashNodeStatus](#getslashnodestatus) | 查询节点 Slashing 状态 | rpc_api_slashing_get |
| [/GetEvidenceList](#getevidencelist) | 获取节点证据列表 | rpc_api_slashing_get |
| [/GetPunishmentList](#getpunishmentlist) | 获取节点处罚列表 | rpc_api_slashing_get |
| [/GetThresholdNodes](#getthresholdnodes) | 获取超阈值节点列表 | rpc_api_slashing_get |
| [/GetSlashStats](#getslashstats) | 获取 Slashing 统计概览 | rpc_api_slashing_get |
| [/GetJailedNodes](#getjailednodes) | 获取被监禁节点列表 | rpc_api_slashing_get |
| [/GetTombstonedNodes](#gettombstonednodes) | 获取被永久惩罚节点列表 | rpc_api_slashing_get |

---

## 接口详情

### /block

**功能**: 获取区块列表信息

**处理函数**: `ohi::rpc::getBlock`

**源文件**: `rpc_api_getBlock.h`, `rpc_api_getBlock.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| num | int | 否 | 100 | 获取区块数量 |
| height | int | 否 | 0 | 起始区块高度（从顶部开始） |
| hash | int | 否 | 0 | hash 显示标志 |
| html | bool | 否 | false | 是否返回 HTML 格式 |
| pre_hash_flag | bool | 否 | false | 是否显示前块 hash |

**响应格式**: `text/html` 或 `text/plain`

**调用示例**:
```bash
# 获取最近 100 个区块（HTML 格式）
curl "http://localhost:port/block?html=true"

# 获取从高度 1000 开始的 50 个区块
curl "http://localhost:port/block?height=1000&num=50"

# 获取区块 hash 列表（纯文本）
curl "http://localhost:port/block?hash=1&num=20"

# 显示前块 hash
curl "http://localhost:port/block?pre_hash_flag=true&num=10"
```

---

### /get_block

**功能**: 获取区块请求数据（JSON 格式）

**处理函数**: `ohi::rpc::getBlockRequest`

**源文件**: `rpc_api_getBlockRequest.h`, `rpc_api_getBlockRequest.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| top | int | 否 | 0 | 起始区块高度 |
| num | int | 否 | 0 | 获取区块数量（最大 500） |

**响应格式**: `application/json`

**调用示例**:
```bash
# 获取从高度 0 开始的 100 个区块
curl "http://localhost:port/get_block?top=0&num=100"

# 获取从高度 500 开始的 50 个区块
curl "http://localhost:port/get_block?top=500&num=50"
```

**响应示例**:
```json
[
  {
    "height": 100,
    "hash": "0xabc123...",
    "prevhash": "0xdef456...",
    "timestamp": 1234567890,
    "txs": [...]
  }
]
```

---

### /pub

**功能**: 获取线程任务统计和请求统计信息

**处理函数**: `ohi::rpc::getPub`

**源文件**: `rpc_api_getPub.h`, `rpc_api_getPub.cpp`

**请求参数**: 无

**响应格式**: `text/html`

**响应内容**:
- 程序名称
- 线程任务统计（按模块分类：ca、net、broadcast 等）
- 队列状态（Read Queue、Work Queue、Write Queue）
- 请求统计（请求类型、数量、数据大小）

**调用示例**:
```bash
# 获取线程和请求统计信息
curl "http://localhost:port/pub"
```

---

### /account

**功能**: 获取账户列表及资产信息

**处理函数**: `ohi::rpc::getAccount`

**源文件**: `rpc_api_getAccount.h`, `rpc_api_getAccount.cpp`

**请求参数**: 无

**响应格式**: `text/html`

**响应内容**:
- 账户地址列表
- 每个账户的 Vote Assets 和 MM Balance
- 账户总数统计

**调用示例**:
```bash
# 获取所有账户信息
curl "http://localhost:port/account"
```

---

### /Node

**功能**: 获取节点列表信息

**处理函数**: `ohi::rpc::getNode`

**源文件**: `rpc_api_getNode.h`, `rpc_api_getNode.cpp`

**请求参数**: 无

**响应格式**: `text/html`

**响应内容**:
- 节点地址
- 节点 IP
- 节点高度
- 节点端口
- 连接类型
- 文件描述符
- 脉冲值
- 版本号

**调用示例**:
```bash
# 获取节点列表
curl "http://localhost:port/Node"
```

---

### /ShowVRFInfo

**功能**: 获取 VRF 验证信息

**处理函数**: `ohi::rpc::getVrfInfo`

**源文件**: `rpc_api_getVrfInfo.h`, `rpc_api_getVrfInfo.cpp`

**请求参数**: 无

**响应格式**: `text/plain`

**响应内容**: VRF 验证信息字符串

**调用示例**:
```bash
# 获取 VRF 验证信息
curl "http://localhost:port/ShowVRFInfo"
```

---

### /printCalcHash

**功能**: 打印千块汇总 hash 信息

**处理函数**: `ohi::rpc::printCalcHash`

**源文件**: `rpc_api_printCalcHash.h`, `rpc_api_printCalcHash.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| startHeight | int | 否 | 1000 | 起始高度（必须是 1000 的倍数） |
| endHeight | int | 否 | 0 | 结束高度（必须是 1000 的倍数） |

**响应格式**: `text/plain`

**调用示例**:
```bash
# 获取从高度 1000 到 5000 的千块汇总 hash
curl "http://localhost:port/printCalcHash?startHeight=1000&endHeight=5000"

# 获取从高度 2000 到 10000 的千块汇总 hash
curl "http://localhost:port/printCalcHash?startHeight=2000&endHeight=10000"
```

**响应示例**:
```
blockHeight: 1000     sumHash: 0xabc123...
blockHeight: 2000     sumHash: 0xdef456...
blockHeight: 3000     sumHash: 0x789abc...
```

---

### /printhundredhash

**功能**: 打印百块汇总 hash 信息

**处理函数**: `ohi::rpc::printHundredSumHash`

**源文件**: `rpc_api_printHundredSumHash.h`, `rpc_api_printHundredSumHash.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| startHeight | int | 否 | 100 | 起始高度（必须是 100 的倍数） |
| endHeight | int | 否 | 0 | 结束高度（必须是 100 的倍数） |

**响应格式**: `text/plain`

**调用示例**:
```bash
# 获取从高度 100 到 1000 的百块汇总 hash
curl "http://localhost:port/printhundredhash?startHeight=100&endHeight=1000"

# 获取从高度 500 到 2000 的百块汇总 hash
curl "http://localhost:port/printhundredhash?startHeight=500&endHeight=2000"
```

**响应示例**:
```
blockHeight: 100      sumHash: 0xabc123...
blockHeight: 200      sumHash: 0xdef456...
blockHeight: 300      sumHash: 0x789abc...
```

---

### /printblock

**功能**: 打印指定高度范围的区块 hash 到文件

**处理函数**: `ohi::rpc::printBlock`

**源文件**: `rpc_api_printBlock.h`, `rpc_api_printBlock.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| startHeight | int | 否 | 1 | 起始高度 |
| endHeight | int | 否 | 0 | 结束高度 |

**响应格式**: `text/plain`

**输出文件**: `block_hash_{startHeight}_{endHeight}.txt`

**调用示例**:
```bash
# 打印高度 1 到 100 的区块 hash 到文件
curl "http://localhost:port/printblock?startHeight=1&endHeight=100"

# 打印高度 500 到 600 的区块 hash 到文件
curl "http://localhost:port/printblock?startHeight=500&endHeight=600"
```

**响应**:
- 成功：`print success`
- 失败：相应错误信息

---

### /SystemInfo

**功能**: 获取系统信息

**处理函数**: `ohi::rpc::getSystemInfo`

**源文件**: `rpc_api_getSystemInfo.h`, `rpc_api_getSystemInfo.cpp`

**请求参数**: 无

**响应格式**: `text/plain`

**响应内容**:
- 内存使用情况（MemTotal, MemFree, MemAvailable, Buffers, Cached 等）
- 磁盘类型（HDD/SSD）
- CPU 信息（使用率、频率、型号、核心数）
- 网络速率（下载/上传速度、接口、MAC 地址）
- 操作系统版本
- 时间信息
- 进程信息

**调用示例**:
```bash
# 获取系统信息
curl "http://localhost:port/SystemInfo"
```

**响应示例**:
```
==================================================================
GetMemOccupy
MemTotal:    16384000
MemFree:     8192000
MemAvailable: 12288000
...
CPU Usage: 15.5%
CPU Frequency: 3.200 GHZ
CPU Model: Intel(R) Core(TM) i7-xxxx CPU @ 3.20GHz
CPU Cores: 8
...
Download speed: 100.50 Mbps
Upload speed: 50.25 Mbps
...
```

---

### /printVoteInfo

**功能**: 打印投票信息

**处理函数**: `ohi::rpc::printVoteInfo`

**源文件**: `rpc_api_printVoteInfo.h`, `rpc_api_printVoteInfo.cpp`

**请求参数**: 无

**响应格式**: `text/html`

**响应内容**:
- 所有资产类型的投票信息
- 提案详细信息

**调用示例**:
```bash
# 获取投票信息
curl "http://localhost:port/printVoteInfo"
```

---

### /printLockAddrs

**功能**: 打印锁定地址及 UTXO 信息

**处理函数**: `ohi::rpc::printLockAddrs`

**源文件**: `rpc_api_printLockAddrs.h`, `rpc_api_printLockAddrs.cpp`

**请求参数**: 无

**响应格式**: `text/plain`

**响应内容**:
- 锁定地址数量
- 每个锁定地址及其 UTXO 列表

**调用示例**:
```bash
# 获取锁定地址信息
curl "http://localhost:port/printLockAddrs"
```

**响应示例**:
```
5
addr: abc123...
 - utxo1
 - utxo2
addr: def456...
 - utxo3
```

---

### /printProposalInfoByHash

**功能**: 根据 hash 打印提案详细信息

**处理函数**: `ohi::rpc::printProposalInfo`

**源文件**: `rpc_api_printProposalInfo.h`, `rpc_api_printProposalInfo.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 提案 hash（支持 0x 前缀） |

**响应格式**: `text/html`

**响应内容**:
- 提案 Hash
- 提案类型
- 汇率
- 开始时间
- 结束时间
- 合约地址
- canBeStake 标志
- MIN_VOTE_NUM
- 地址列表
- 投票信息

**调用示例**:
```bash
# 根据 hash 获取提案信息
curl "http://localhost:port/printProposalInfoByHash?hash=0xabc123..."

# 不带 0x 前缀
curl "http://localhost:port/printProposalInfoByHash?hash=abc123..."
```

---

### /printAvailableAssetType

**功能**: 打印可用资产类型信息

**处理函数**: `ohi::rpc::printAssetType`

**源文件**: `rpc_api_printAssetType.h`, `rpc_api_printAssetType.cpp`

**请求参数**: 无

**响应格式**: `text/html`

**响应内容**:
- 资产 Hash
- 提案类型
- 汇率
- 开始时间
- 结束时间
- 合约地址
- canBeStake 标志
- MIN_VOTE_NUM

**调用示例**:
```bash
# 获取可用资产类型列表
curl "http://localhost:port/printAvailableAssetType"
```

---

### /printAsseTypeByContractAddr

**功能**: 根据合约地址查询资产类型

**处理函数**: `ohi::rpc::getAssetType`

**源文件**: `rpc_api_getAssetType.h`, `rpc_api_getAssetType.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| contractAddr | string | 是 | 合约地址（支持 0x 前缀） |

**响应格式**: `text/plain`

**调用示例**:
```bash
# 根据合约地址查询资产类型
curl "http://localhost:port/printAsseTypeByContractAddr?contractAddr=0xabc123..."

# 不带 0x 前缀
curl "http://localhost:port/printAsseTypeByContractAddr?contractAddr=abc123..."
```

**响应**:
- 成功：返回资产类型字符串
- 失败：返回错误信息

---

### /GetPublicIp

**功能**: 获取请求者的公网 IP 地址

**处理函数**: `ohi::rpc::getPublicIp`

**源文件**: `rpc_api_getPublicIp.h`, `rpc_api_getPublicIp.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**调用示例**:
```bash
# 获取本机公网 IP
curl "http://localhost:port/GetPublicIp"
```

**响应示例**:
```
192.168.1.100
```

---

### /GetRollbackBlocks

**功能**: 获取回滚区块信息

**处理函数**: `ohi::rpc::getAllRollbackBlocks`

**源文件**: `rpc_api_getAllRollBackBlocks.h`, `rpc_api_getAllRollBackBlocks.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| blockNumber | uint64 | 否 | 区块高度（当 allRollbackNumber 为 false 时使用） |
| allRollbackNumber | bool | 是 | 是否获取所有回滚区块编号 |

**响应格式**: `application/json`

**响应内容**:
- blocks: 区块信息列表
  - 当 allRollbackNumber=true 时，返回回滚区块编号列表
  - 当 allRollbackNumber=false 时，返回指定高度的回滚区块详细信息（JSON 格式）

**调用示例**:
```bash
# 获取所有回滚区块编号
curl "http://localhost:port/GetRollbackBlocks?allRollbackNumber=true"

# 获取指定高度的回滚区块信息
curl "http://localhost:port/GetRollbackBlocks?blockNumber=1000&allRollbackNumber=false"
```

**响应示例**:
```json
{
  "blocks": [
    {
      "height": 1000,
      "hash": "0xabc123...",
      "prevhash": "0xdef456...",
      "timestamp": 1234567890,
      "txs": [...]
    }
  ]
}
```

---

### /api

**功能**: 返回所有已注册 POST 接口的参数模板和响应模板示例，用于开发调试

**处理函数**: `ohi::rpc::api_template`

**源文件**: `rpc_template.h`, `rpc_template.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**响应内容**: 各接口的 JSON-RPC 参数模板（含 method 和 params）及响应模板（含 result 和 status）拼接字符串

**调用示例**:
```bash
# 获取所有 API 模板
curl "http://localhost:port/api"
```

---

### /Get30daylockdatas

**功能**: 获取指定地址的 30 天锁定 UTXO 数据

**处理函数**: `ohi::rpc::get30daylockdatas`

**源文件**: `rpc_api_get30dayLockUtxos.h`, `rpc_api_get30dayLockUtxos.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 账户地址 |

**响应格式**: `application/json`

**响应内容**:
- utxodatas: 锁定 UTXO 数据列表（JSON 数组）

**调用示例**:
```bash
curl "http://localhost:port/Get30daylockdatas?addr=0x1234567890abcdef"
```

**响应示例**:
```json
{
  "utxodatas": [
    {
      "utxo_hash": "0xabc123...",
      "amount": "1000",
      "lock_time": 1234567890
    }
  ]
}
```

---

### /Confirm

**功能**: 根据交易 hash 查询该交易是否已上链确认（上链率 >= 80% 视为已确认）

**处理函数**: `ohi::rpc::getBlockRateByTxHash`

**源文件**: `rpc_api_getBlockRateByTxHash.h`, `rpc_api_getBlockRateByTxHash.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| txHash | string | 是 | 交易 hash（支持 0x 前缀） |

**响应格式**: `application/json`

**响应内容**:
- confirmed: boolean，交易是否已确认上链

**调用示例**:
```bash
curl "http://localhost:port/Confirm?txHash=0xabc123..."
```

**响应示例**:
```json
{
  "confirmed": true
}
```

---

### /GetBlockRateProbeResults

**功能**: 获取区块上链率探测的所有历史记录，包含每个区块 hash 的确认状态和各级上链率

**处理函数**: `ohi::rpc::getBlockRateProbeResults`

**源文件**: `rpc_api_getBlockRateProbeResults.h`, `rpc_api_getBlockRateProbeResults.cpp`

**请求参数**: 无

**响应格式**: `text/plain`

**响应内容**:
- 当前 UTC 时间戳
- 总探测记录数
- 每条记录包含：区块 hash、创建时间、是否已确认、探测次数、各级上链率百分比

**调用示例**:
```bash
curl "http://localhost:port/GetBlockRateProbeResults"
```

**响应示例**:
```
=== Block Rate Probe Results ===
Time: 1718000000
Total records: 2
----------------------------------------
[1] Hash: abc123...
    Create Time: 1717999000
    Confirmed: YES
    Probe Count: 5
    Rates: 20.0% -> 40.0% -> 60.0% -> 80.0% -> 100.0%
----------------------------------------
[2] Hash: def456...
    Create Time: 1717999500
    Confirmed: NO
    Probe Count: 2
    Rates: 10.0% -> 30.0%
----------------------------------------
```

---

### /GetSlashNodeStatus

**功能**: 查询指定节点的 Slashing 状态（活跃/监禁/永久惩罚）及证据统计

**处理函数**: `ohi::rpc::getSlashNodeStatus`

**源文件**: `rpc_api_slashing_get.h`, `rpc_api_slashing_get.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 节点地址 |

**响应格式**: `application/json`

**响应内容**:
- addr: 节点地址
- status: 节点状态（`ACTIVE` / `JAILED` / `TOMBSTONED`）
- last_active_period: 最后活跃周期（可选）
- evidence_counts: 各类违规证据数量（DOUBLE_SIGN_VRF、DOUBLE_SIGN_BLOCK、LOW_SIGN_RATE）
- total_evidence: 证据总数
- has_punishment_history: 是否有处罚历史

**调用示例**:
```bash
curl "http://localhost:port/GetSlashNodeStatus?addr=0x1234567890abcdef"
```

**响应示例**:
```json
{
  "addr": "0x1234567890abcdef",
  "status": "ACTIVE",
  "last_active_period": 12345,
  "evidence_counts": {
    "DOUBLE_SIGN_VRF": 0,
    "DOUBLE_SIGN_BLOCK": 0,
    "LOW_SIGN_RATE": 1
  },
  "total_evidence": 1,
  "has_punishment_history": false,
  "status_code": "success"
}
```

---

### /GetEvidenceList

**功能**: 获取指定节点的违规证据列表，按违规类型分类

**处理函数**: `ohi::rpc::getEvidenceList`

**源文件**: `rpc_api_slashing_get.h`, `rpc_api_slashing_get.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 节点地址 |
| type | string | 否 | 违规类型过滤（DOUBLE_SIGN_VRF / DOUBLE_SIGN_BLOCK / LOW_SIGN_RATE），不传则返回所有类型 |

**响应格式**: `application/json`

**响应内容**:
- addr: 节点地址
- evidence_list: 证据列表（包含 violation_type 和 count）
- status: 状态

**调用示例**:
```bash
# 获取所有类型的证据
curl "http://localhost:port/GetEvidenceList?addr=0x1234567890abcdef"

# 只获取特定类型
curl "http://localhost:port/GetEvidenceList?addr=0x1234567890abcdef&type=LOW_SIGN_RATE"
```

**响应示例**:
```json
{
  "addr": "0x1234567890abcdef",
  "evidence_list": [
    { "violation_type": "LOW_SIGN_RATE", "count": 3 }
  ],
  "status": "success"
}
```

---

### /GetPunishmentList

**功能**: 获取指定节点的处罚历史记录列表

**处理函数**: `ohi::rpc::getPunishmentList`

**源文件**: `rpc_api_slashing_get.h`, `rpc_api_slashing_get.cpp`

**请求参数**:
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 节点地址 |

**响应格式**: `application/json`

**响应内容**:
- addr: 节点地址
- has_punishment: 是否有处罚记录
- punishments: 处罚列表（包含 punishment_id、target_addr、period、penalty_level、tx_hash）
- status: 状态

**调用示例**:
```bash
curl "http://localhost:port/GetPunishmentList?addr=0x1234567890abcdef"
```

**响应示例**:
```json
{
  "addr": "0x1234567890abcdef",
  "has_punishment": true,
  "punishments": [
    {
      "punishment_id": "pun_001",
      "target_addr": "0x1234567890abcdef",
      "period": "12345",
      "penalty_level": 2,
      "tx_hash": "0xabc123..."
    }
  ],
  "status": "success"
}
```

---

### /GetThresholdNodes

**功能**: 获取违规证据超过阈值的节点列表，包含违规等级和证据引用

**处理函数**: `ohi::rpc::getThresholdNodes`

**源文件**: `rpc_api_slashing_get.h`, `rpc_api_slashing_get.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**响应内容**:
- threshold_nodes: 超阈值节点列表（包含 addr、level、violation_type、evidence_refs）
- status: 状态

**调用示例**:
```bash
curl "http://localhost:port/GetThresholdNodes"
```

**响应示例**:
```json
{
  "threshold_nodes": [
    {
      "addr": "0x1234567890abcdef",
      "level": "3",
      "violation_type": "LOW_SIGN_RATE",
      "evidence_refs": "ref1,ref2"
    }
  ],
  "status": "success"
}
```

---

### /GetSlashStats

**功能**: 获取 Slashing 系统全局统计概览

**处理函数**: `ohi::rpc::getSlashStats`

**源文件**: `rpc_api_slashing_get.h`, `rpc_api_slashing_get.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**响应内容**:
- total_stake_nodes: 总质押节点数
- jailed_nodes: 被监禁节点数
- tombstoned_nodes: 被永久惩罚节点数
- active_nodes: 活跃节点数
- status: 状态

**调用示例**:
```bash
curl "http://localhost:port/GetSlashStats"
```

**响应示例**:
```json
{
  "total_stake_nodes": 100,
  "jailed_nodes": 3,
  "tombstoned_nodes": 1,
  "active_nodes": 96,
  "status": "success"
}
```

---

### /GetJailedNodes

**功能**: 获取当前被监禁的节点列表

**处理函数**: `ohi::rpc::getJailedNodes`

**源文件**: `rpc_api_slashing_get.h`, `rpc_api_slashing_get.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**响应内容**:
- jailed_nodes: 被监禁节点列表（包含 addr 和 jail_info）
- count: 被监禁节点数量
- status: 状态

**调用示例**:
```bash
curl "http://localhost:port/GetJailedNodes"
```

**响应示例**:
```json
{
  "jailed_nodes": [
    {
      "addr": "0x1234567890abcdef",
      "jail_info": "{\"reason\":\"LOW_SIGN_RATE\",\"period\":12345}"
    }
  ],
  "count": 1,
  "status": "success"
}
```

---

### /GetTombstonedNodes

**功能**: 获取被永久惩罚（tombstoned）的节点列表

**处理函数**: `ohi::rpc::getTombstonedNodes`

**源文件**: `rpc_api_slashing_get.h`, `rpc_api_slashing_get.cpp`

**请求参数**: 无

**响应格式**: `application/json`

**响应内容**:
- tombstoned_nodes: 被永久惩罚节点列表（包含 addr 和 tombstone_info）
- count: 被永久惩罚节点数量
- status: 状态

**调用示例**:
```bash
curl "http://localhost:port/GetTombstonedNodes"
```

**响应示例**:
```json
{
  "tombstoned_nodes": [
    {
      "addr": "0xfedcba0987654321",
      "tombstone_info": "{\"reason\":\"DOUBLE_SIGN_VRF\",\"period\":12000}"
    }
  ],
  "count": 1,
  "status": "success"
}
```

---

## 附录

### 公共响应格式说明

| 格式 | Content-Type | 说明 |
|------|-------------|------|
| HTML | text/html | 带样式的网页响应，包含 MeMeChain 品牌标识 |
| JSON | application/json | 结构化数据响应 |
| Plain | text/plain | 纯文本响应 |

### 错误处理

各接口在发生错误时通常返回相应的错误信息字符串，部分接口返回错误状态码。

### 命名空间

所有 RPC 接口均位于 `ohi::rpc` 命名空间下。

### 注册代码位置

接口注册位于 `rpc/http_api.cpp` 的 `subscribeToHttpCallbacks` 函数中：

```cpp
// 本机查询
HttpServer::RegisterCallback("/GetVersion", ohi::rpc::getVersion);
HttpServer::RegisterCallback("/GetBalance", ohi::rpc::getBalance);
HttpServer::RegisterCallback("/GetBlockHeight", ohi::rpc::getBlockHeight);
HttpServer::RegisterCallback("/GetChainId", ohi::rpc::getChainId);
HttpServer::RegisterCallback("/GetAccounts", ohi::rpc::getAccounts);
HttpServer::RegisterCallback("/GetNodeList", ohi::rpc::getNodelist);
HttpServer::RegisterCallback("/GetAllStakeNodeList", ohi::rpc::getAllStakeNodeList);
HttpServer::RegisterCallback("/GetAddrType", ohi::rpc::getAddrType);
HttpServer::RegisterCallback("/GetYieldInfo", ohi::rpc::getYieldInfo);
HttpServer::RegisterCallback("/GetBonusInfo", ohi::rpc::getBonusInfo);

HttpServer::RegisterCallback("/GetVoteAddrs", ohi::rpc::getVoteAddrs);
HttpServer::RegisterCallback("/GetVoteTxHash", ohi::rpc::getVoteTxHash);
HttpServer::RegisterCallback("/GetAllAssetType", ohi::rpc::getAllAssetType);
HttpServer::RegisterCallback("/GetAssetTypeInfo", ohi::rpc::getAssetTypeInfo);
HttpServer::RegisterCallback("/GetAssetTypeByContractAddr", ohi::rpc::getAssetTypeByContractAddr);

// 区块交易查询
HttpServer::RegisterCallback("/GetTransactionByHash", ohi::rpc::getTransactionByHash);
HttpServer::RegisterCallback("/GetBlockByHash", ohi::rpc::getBlockByHash);
HttpServer::RegisterCallback("/GetBlockByHeight", ohi::rpc::getBlockByHeight);
HttpServer::RegisterCallback("/GetBlockByTransactionHash", ohi::rpc::getBlockByTransactionHash);
HttpServer::RegisterCallback("/GetDelegatingUtxo", ohi::rpc::getDelegatingUtxo);
HttpServer::RegisterCallback("/GetStakingUtxo", ohi::rpc::getStakingUtxo);
HttpServer::RegisterCallback("/GetLockUtxo", ohi::rpc::getLockUtxo);
HttpServer::RegisterCallback("/GetBlockTransactionCountByHash", ohi::rpc::getTransactionCount);
HttpServer::RegisterCallback("/GetDelegatingAddrsByBonusAddr", ohi::rpc::getDelegatingAddrs);
HttpServer::RegisterCallback("/GetUtxoDeployerByConAddr", ohi::rpc::getUtxoDeployer);
HttpServer::RegisterCallback("/IsContract", ohi::rpc::isContract);
HttpServer::RegisterCallback("/GetTxByHash", ohi::rpc::getTransactions);
HttpServer::RegisterCallback("/GetBlockNumberByHash", ohi::rpc::getBlocks);

// 创建交易
HttpServer::RegisterCallback("/CreateTransaction", ohi::rpc::createTransaction);
HttpServer::RegisterCallback("/CreateStakingTransaction", ohi::rpc::createStake);
HttpServer::RegisterCallback("/CreateUnstakingTransaction", ohi::rpc::createUnStake);
HttpServer::RegisterCallback("/CreateDelegatingTransaction", ohi::rpc::createDelegating);
HttpServer::RegisterCallback("/CreateUndelegatingTransaction", ohi::rpc::createUndelegating);
HttpServer::RegisterCallback("/CreateBonusTransaction", ohi::rpc::createBonus);
HttpServer::RegisterCallback("/CreateCallContractTransaction", ohi::rpc::createCall);
HttpServer::RegisterCallback("/CreateDeployContractTransaction", ohi::rpc::createDeploy);
HttpServer::RegisterCallback("/SendMessage", ohi::rpc::createPostMessage);
HttpServer::RegisterCallback("/SendContractMessage", ohi::rpc::createContractMsg);
HttpServer::RegisterCallback("/CreateLockTransaction", ohi::rpc::createLock);
HttpServer::RegisterCallback("/CreateUnLockTransaction", ohi::rpc::createUnlock);
HttpServer::RegisterCallback("/CreateVoteTransaction", ohi::rpc::createVote);
HttpServer::RegisterCallback("/CreateFundTransaction", ohi::rpc::createFund);

// 浏览器查询
HttpServer::RegisterCallback("/api", ohi::rpc::api_template);
HttpServer::RegisterCallback("/block", ohi::rpc::getBlock);
HttpServer::RegisterCallback("/get_block", ohi::rpc::getBlockRequest);
HttpServer::RegisterCallback("/pub", ohi::rpc::getPub);
HttpServer::RegisterCallback("/account", ohi::rpc::getAccount);
HttpServer::RegisterCallback("/Node", ohi::rpc::getNode);
HttpServer::RegisterCallback("/ShowVRFInfo", ohi::rpc::getVrfInfo);
HttpServer::RegisterCallback("/printCalcHash", ohi::rpc::printCalcHash);
HttpServer::RegisterCallback("/printhundredhash", ohi::rpc::printHundredSumHash);
HttpServer::RegisterCallback("/printblock", ohi::rpc::printBlock);
HttpServer::RegisterCallback("/SystemInfo", ohi::rpc::getSystemInfo);
// vote ===========================================
HttpServer::RegisterCallback("/printVoteInfo", ohi::rpc::printVoteInfo);
HttpServer::RegisterCallback("/printLockAddrs", ohi::rpc::printLockAddrs);
HttpServer::RegisterCallback("/printProposalInfoByHash", ohi::rpc::printProposalInfo);
HttpServer::RegisterCallback("/printAvailableAssetType", ohi::rpc::printAssetType);
HttpServer::RegisterCallback("/printAsseTypeByContractAddr", ohi::rpc::getAssetType);
HttpServer::RegisterCallback("/GetPublicIp", ohi::rpc::getPublicIp);
HttpServer::RegisterCallback("/GetRollbackBlocks", ohi::rpc::getAllRollbackBlocks);
HttpServer::RegisterCallback("/Get30daylockdatas", ohi::rpc::get30daylockdatas);
// 区块上链率探测接口
HttpServer::RegisterCallback("/Confirm", ohi::rpc::getBlockRateByTxHash);
HttpServer::RegisterCallback("/GetBlockRateProbeResults", ohi::rpc::getBlockRateProbeResults);

// Slashing 监控接口 (GET)
HttpServer::RegisterCallback("/GetSlashNodeStatus", ohi::rpc::getSlashNodeStatus);
HttpServer::RegisterCallback("/GetEvidenceList", ohi::rpc::getEvidenceList);
HttpServer::RegisterCallback("/GetPunishmentList", ohi::rpc::getPunishmentList);
HttpServer::RegisterCallback("/GetThresholdNodes", ohi::rpc::getThresholdNodes);
HttpServer::RegisterCallback("/GetSlashStats", ohi::rpc::getSlashStats);
HttpServer::RegisterCallback("/GetJailedNodes", ohi::rpc::getJailedNodes);
HttpServer::RegisterCallback("/GetTombstonedNodes", ohi::rpc::getTombstonedNodes);
```

---

*文档生成日期：2026 年 7 月 3 日*
