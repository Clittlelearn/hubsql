# openhive-rpcd 开发文档

**版本**: 1.0.0-draft
**日期**: 2026-06-18
**状态**: Draft
**维护者**: OpenHive Core Team

---

## 目录

- [1. 技术栈](#1-技术栈)
- [2. 项目结构](#2-项目结构)
- [3. 开发环境搭建](#3-开发环境搭建)
- [4. 配置管理](#4-配置管理)
- [5. 核心模块开发指南](#5-核心模块开发指南)
- [6. 构建与运行](#6-构建与运行)
- [7. Docker 部署](#7-docker-部署)
- [8. 数据库迁移](#8-数据库迁移)
- [9. 测试策略](#9-测试策略)
- [10. 开发规范](#10-开发规范)
- [11. 监控与告警](#11-监控与告警)
- [12. CI/CD 建议](#12-cicd-建议)
- [13. 常见问题](#13-常见问题)

---

## 1. 技术栈

### 1.1 核心依赖

| 类别 | 技术 | 版本 | 说明 |
|------|------|------|------|
| **语言** | Go | ≥ 1.22 | 主开发语言 |
| **HTTP 框架** | Gin | v1.10+ | 高性能 HTTP 路由框架 |
| **PostgreSQL 驱动** | pgx/v5 | v5.6+ | 高性能 PG 驱动，支持连接池 |
| **Redis 客户端** | go-redis/v9 | v9.5+ | Redis 客户端 |
| **JSON-RPC** | 自实现 | — | 基于 Gin 中间件的 JSON-RPC 分发器 |
| **配置管理** | Viper | v1.18+ | 支持 YAML/ENV/Flag 多来源配置 |
| **日志** | slog (标准库) | Go 1.21+ | 结构化日志 |
| **指标** | prometheus/client_golang | v1.19+ | Prometheus 指标暴露 |
| **链路追踪** | OpenTelemetry | v1.27+ | 分布式追踪 |
| **数据库迁移** | golang-migrate | v4.3+ | SQL 迁移管理 |

### 1.2 选型理由

| 决策 | 理由 |
|------|------|
| Go 而非 Rust | 增强 RPC 服务层是 IO 密集型（查 PG、查 Redis），不是 CPU 密集型。Go 的 PG 生态更成熟，开发效率更高 |
| Gin 而非 Echo/Fiber | Gin 社区最大，中间件最丰富，性能足够（不是瓶颈） |
| pgx 而非 database/sql + lib/pq | pgx 是 PG 专用驱动，支持连接池、批量操作、JSON/JSONB 原生处理，性能比通用 database/sql 接口好 |
| go-redis 而非 redigo | go-redis 支持 context、pipeline、cluster，API 更现代 |
| slog 而非 zap/logrus | Go 1.21 标准库内置，零外部依赖，结构化日志够用 |

### 1.3 不引入的依赖

| 技术 | 不引入的理由 |
|------|-------------|
| GORM / ent | ORM 对于这个项目的查询复杂度来说过重，直接用 pgx 写 SQL 更清晰、性能更好 |
| gRPC | 当前阶段不需要，所有对外接口都是 HTTP。rpcd 与链节点通信也走 HTTP |
| Kafka / RabbitMQ | Indexer 直接回调+扫块，不需要消息队列中间件 |

---

## 2. 项目结构

```
openhive-rpcd/
│
├── cmd/
│   └── rpcd/
│       └── main.go                  # 程序入口
│
├── internal/
│   ├── config/
│   │   └── config.go                # 配置结构定义与加载
│   │
│   ├── server/
│   │   ├── server.go                # HTTP Server 启动与路由注册
│   │   ├── middleware.go            # 中间件（日志、指标、恢复、CORS）
│   │   └── jsonrpc.go               # JSON-RPC 2.0 分发器
│   │
│   ├── handler/
│   │   ├── jsonrpc_handler.go       # JSON-RPC 查询请求处理器
│   │   ├── rest_handler.go          # REST 增强 API 处理器
│   │   └── proxy_handler.go         # 写操作透传处理器
│   │
│   ├── indexer/
│   │   ├── indexer.go               # Indexer 主循环（回调+扫块协调）
│   │   ├── callback.go              # 回调接收器
│   │   ├── poller.go                # 扫块追赶器
│   │   └── rollback.go              # 回滚处理器
│   │
│   ├── parser/
│   │   ├── parser.go                # 区块/交易解析主入口
│   │   ├── block_parser.go          # 区块元数据解析
│   │   ├── tx_parser.go             # 交易解析（按类型分发）
│   │   └── utxo_parser.go           # UTXO 输入/输出解析
│   │
│   ├── store/
│   │   ├── store.go                 # Store 接口定义
│   │   ├── postgres.go              # PostgreSQL 实现
│   │   ├── block_store.go           # 区块 CRUD
│   │   ├── tx_store.go              # 交易 CRUD
│   │   ├── address_store.go         # 地址交易索引 CRUD
│   │   ├── utxo_store.go            # UTXO 状态 CRUD
│   │   ├── balance_store.go         # 余额 CRUD
│   │   ├── stake_store.go           # 质押记录 CRUD
│   │   ├── delegate_store.go        # 委托记录 CRUD
│   │   ├── contract_store.go        # 合约信息 CRUD
│   │   └── sync_store.go            # 同步状态 CRUD
│   │
│   ├── cache/
│   │   ├── cache.go                 # Cache 接口定义
│   │   ├── redis.go                 # Redis 实现
│   │   └── keys.go                  # 缓存 Key 定义
│   │
│   ├── query/
│   │   ├── router.go                # 查询路由（PG → Redis → Fallback）
│   │   ├── fallback.go              # 回源链节点查询
│   │   └── queries.go               # 各查询方法实现
│   │
│   ├── proxy/
│   │   ├── proxy.go                 # 写操作透传
│   │   └── balancer.go              # 链节点负载均衡
│   │
│   └── types/
│       ├── block.go                 # 区块数据结构
│       ├── transaction.go           # 交易数据结构
│       ├── utxo.go                  # UTXO 数据结构
│       ├── address.go               # 地址相关结构
│       └── jsonrpc.go               # JSON-RPC 请求/响应结构
│
├── migrations/
│   └── postgres/
│       ├── 001_create_blocks.sql
│       ├── 002_create_transactions.sql
│       ├── 003_create_address_transactions.sql
│       ├── 004_create_utxo_states.sql
│       ├── 005_create_address_balances.sql
│       ├── 006_create_stake_records.sql
│       ├── 007_create_delegate_records.sql
│       ├── 008_create_contracts.sql
│       ├── 009_create_contract_events.sql
│       ├── 010_create_asset_types.sql
│       ├── 011_create_vote_records.sql
│       └── 012_create_sync_status.sql
│
├── config/
│   ├── config.yaml                  # 默认配置
│   └── config.example.yaml          # 配置示例
│
├── Dockerfile
├── docker-compose.yaml
├── go.mod
├── go.sum
├── Makefile
└── README.md
```

### 2.1 目录职责说明

| 目录 | 职责 | 依赖方向 |
|------|------|---------|
| `cmd/rpcd/` | 程序入口，组装所有组件 | → internal/* |
| `internal/server/` | HTTP 服务器、路由、中间件 | → handler |
| `internal/handler/` | 请求处理，协议适配 | → query, proxy |
| `internal/indexer/` | 数据同步引擎 | → parser, store |
| `internal/parser/` | 区块/交易解析 | → types |
| `internal/store/` | 数据库读写 | → types |
| `internal/cache/` | 缓存读写 | → types |
| `internal/query/` | 查询路由与业务逻辑 | → store, cache, proxy |
| `internal/proxy/` | 写操作透传 | → config |
| `internal/types/` | 数据结构定义 | 无外部依赖 |

**依赖原则**：上层可以依赖下层，下层不能依赖上层。`types` 是纯数据结构，不依赖任何业务模块。

---

## 3. 开发环境搭建

### 3.1 前置条件

| 工具 | 版本 | 说明 |
|------|------|------|
| Go | ≥ 1.22 | `go version` 检查 |
| PostgreSQL | ≥ 15 | `psql --version` 检查 |
| Redis | ≥ 7 | `redis-server --version` 检查 |
| Docker | ≥ 24 | 可选，用于容器化部署 |
| golang-migrate | 最新 | `migrate -version` 检查 |

### 3.2 快速启动

```bash
# 1. 克隆项目
git clone <repo-url> openhive-rpcd
cd openhive-rpcd

# 2. 启动依赖服务（PostgreSQL + Redis）
docker compose up -d postgres redis

# 3. 等待数据库就绪
sleep 3

# 4. 执行数据库迁移
make migrate-up

# 5. 复制并编辑配置文件
cp config/config.example.yaml config/config.yaml
# 编辑 config.yaml，设置链节点地址等

# 6. 启动服务
make run

# 7. 验证
curl http://localhost:8080/rpc \
  -X POST \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetBlockHeight","params":[],"id":1}'
```

### 3.3 使用 Docker Compose 一键启动（含链节点模拟）

```bash
# 启动全部服务
docker compose up -d

# 查看日志
docker compose logs -f rpcd

# 停止
docker compose down
```

---

## 4. 配置管理

### 4.1 配置文件格式

```yaml
# config.yaml

server:
  listen_addr: ":8080"
  read_timeout: 30s
  write_timeout: 30s
  shutdown_timeout: 10s

chain:
  # 链节点 RPC 地址（支持多个，用于负载均衡和 fallback）
  nodes:
    - url: "http://chain-node-1:13134"
      weight: 1
    - url: "http://chain-node-2:13134"
      weight: 1
  # 回调监听地址（链节点推送新区块到此地址）
  callback_listen_addr: ":8081"
  # 连接超时
  connect_timeout: 5s
  # 读取超时
  read_timeout: 30s

indexer:
  # 扫块间隔（兜底追赶）
  poll_interval: 30s
  # 启动时是否从创世块全量同步
  sync_from_genesis: false
  # 批量写入大小
  batch_size: 100
  # 回调超时（超时后认为回调丢失，由扫块补回）
  callback_timeout: 60s

postgres:
  dsn: "postgres://rpcd:rpcd@localhost:5432/rpcd?sslmode=disable"
  max_conns: 100
  min_conns: 10
  max_conn_lifetime: 30m
  max_conn_idle_time: 5m
  statement_timeout: 5s

redis:
  url: "redis://localhost:6379/0"
  password: ""
  db: 0
  pool_size: 50
  max_retries: 3

cache:
  # 热缓存 TTL（最新区块、热门余额）
  hot_ttl: 10s
  # 温缓存 TTL（已确认交易）
  warm_ttl: 5m
  # 冷缓存 TTL（历史数据）
  cold_ttl: 1h
  # 空值缓存 TTL（防穿透）
  null_ttl: 30s

proxy:
  # 写操作转发超时
  timeout: 30s
  # 负载均衡策略: round_robin | least_conn
  balancer: round_robin

log:
  level: info          # debug | info | warn | error
  format: json         # json | text

metrics:
  enabled: true
  path: /metrics

tracing:
  enabled: false
  endpoint: "http://jaeger:4318"  # OTLP HTTP 端点
  sample_rate: 0.1                # 采样率 10%
```

### 4.2 环境变量覆盖

所有配置项均可通过环境变量覆盖，规则：`RPCD_` 前缀 + 大写 + 下划线分隔。

```bash
# 示例
export RPCD_SERVER_LISTEN_ADDR=:9090
export RPCD_POSTGRES_DSN=postgres://user:pass@host:5432/db
export RPCD_REDIS_URL=redis://host:6379/0
export RPCD_LOG_LEVEL=debug
export RPCD_CHAIN_NODES_0_URL=http://node1:13134
export RPCD_CHAIN_NODES_1_URL=http://node2:13134
```

### 4.3 配置加载优先级

```
命令行参数 > 环境变量 > 配置文件 > 默认值
```

---

## 5. 核心模块开发指南

### 5.1 JSON-RPC 分发器

JSON-RPC 分发器负责解析 `POST /rpc` 请求，按 `method` 字段路由到对应处理器。

```go
// internal/server/jsonrpc.go

// JSON-RPC 方法分类
var (
    // 写操作方法集合 → 透传到链节点
    writeMethods = map[string]bool{
        "CreateTransaction":               true,
        "CreateStakingTransaction":        true,
        "CreateUnstakingTransaction":      true,
        "CreateDelegatingTransaction":     true,
        "CreateUndelegatingTransaction":   true,
        "CreateBonusTransaction":          true,
        "CreateCallContractTransaction":   true,
        "CreateDeployContractTransaction": true,
        "SendMessage":                     true,
        "SendContractMessage":             true,
        "CreateLockTransaction":           true,
        "CreateUnLockTransaction":         true,
        "CreateVoteTransaction":           true,
        "CreateFundTransaction":           true,
        "eth_sendRawTransaction":          true,
    }

    // 查询方法集合 → rpcd 本地处理
    queryMethods = map[string]bool{
        // 自定义查询
        "GetVersion":                     true,
        "GetBalance":                     true,
        "GetBlockHeight":                 true,
        "GetChainId":                     true,
        "GetAccounts":                    true,
        "GetNodeList":                    true,
        "GetAllStakeNodeList":            true,
        "GetAddrType":                    true,
        "GetYieldInfo":                   true,
        "GetBonusInfo":                   true,
        "GetVoteAddrs":                   true,
        "GetVoteTxHash":                  true,
        "GetAllAssetType":                true,
        "GetAssetTypeInfo":               true,
        "GetAssetTypeByContractAddr":     true,
        "GetTransactionByHash":           true,
        "GetBlockByHash":                 true,
        "GetBlockByHeight":               true,
        "GetBlockByTransactionHash":      true,
        "GetDelegatingUtxo":              true,
        "GetStakingUtxo":                 true,
        "GetLockUtxo":                    true,
        "GetBlockTransactionCountByHash": true,
        "GetDelegatingAddrsByBonusAddr":  true,
        "GetUtxoDeployerByConAddr":       true,
        "IsContract":                     true,
        "GetTxByHash":                    true,
        "GetBlockNumberByHash":           true,
        "GetRollbackBlocks":              true,
        // ETH 兼容查询
        "eth_chainId":                    true,
        "eth_blockNumber":                true,
        "eth_gasPrice":                   true,
        "eth_feeHistory":                 true,
        "eth_getBalance":                 true,
        "eth_getTransactionCount":        true,
        "eth_call":                       true,
        "eth_getBlockByNumber":           true,
        "eth_getBlockByHash":             true,
        "eth_getCode":                    true,
        "eth_getTransactionReceipt":      true,
        "eth_getTransactionByHash":       true,
        "eth_estimateGas":                true,
        "eth_accounts":                   true,
        "net_version":                    true,
        "web3_clientVersion":             true,
    }
)

// Dispatch 分发 JSON-RPC 请求
func (s *Server) Dispatch(c *gin.Context) {
    var req JSONRPCRequest
    if err := c.ShouldBindJSON(&req); err != nil {
        c.JSON(200, jsonrpcError(nil, -32700, "Parse error"))
        return
    }

    if writeMethods[req.Method] {
        // 写操作 → 透传到链节点
        s.proxyHandler.Handle(c, &req)
    } else if queryMethods[req.Method] {
        // 查询操作 → 本地处理
        s.jsonrpcHandler.Handle(c, &req)
    } else {
        c.JSON(200, jsonrpcError(req.ID, -32601, "Method not found"))
    }
}
```

### 5.2 Indexer 主循环

```go
// internal/indexer/indexer.go

func (idx *Indexer) Run(ctx context.Context) {
    // 1. 启动时全量追赶
    idx.catchUp(ctx)

    // 2. 启动回调接收器
    go idx.callbackReceiver.Run(ctx)

    // 3. 启动扫块追赶器（低频）
    go idx.poller.Run(ctx, idx.config.PollInterval)

    // 4. 主循环：监控同步状态
    ticker := time.NewTicker(10 * time.Second)
    defer ticker.Stop()
    for {
        select {
        case <-ctx.Done():
            return
        case <-ticker.C:
            idx.reportSyncStatus()
        }
    }
}

// catchUp 启动时追赶
func (idx *Indexer) catchUp(ctx context.Context) {
    syncedHeight := idx.store.GetSyncedHeight(ctx)
    chainHeight := idx.fetchChainHeight(ctx)

    if syncedHeight >= chainHeight {
        return
    }

    log.Info("catching up blocks",
        "from", syncedHeight,
        "to", chainHeight,
        "gap", chainHeight-syncedHeight)

    for h := syncedHeight + 1; h <= chainHeight; h++ {
        block := idx.fetchBlock(ctx, h)
        idx.parseAndStore(ctx, block)
    }

    log.Info("catch up complete", "synced_height", chainHeight)
}
```

### 5.3 查询路由

```go
// internal/query/router.go

func (r *Router) Query(ctx context.Context, method string, params json.RawMessage) (any, error) {
    // 1. 查 Redis
    cacheKey := r.buildCacheKey(method, params)
    if cached, err := r.cache.Get(ctx, cacheKey); err == nil {
        metrics.CacheHit.Inc()
        return cached, nil
    }
    metrics.CacheMiss.Inc()

    // 2. 查 PostgreSQL
    if result, err := r.queryFromPG(ctx, method, params); err == nil && result != nil {
        // 回填缓存
        r.cache.Set(ctx, cacheKey, result, r.ttlFor(method))
        return result, nil
    }

    // 3. Fallback 到链节点
    result, err := r.fallback.QueryChainNode(ctx, method, params)
    if err != nil {
        return nil, fmt.Errorf("all data sources failed: %w", err)
    }

    // 异步回填 PG + Redis
    go r.backfill(ctx, method, params, result)

    return result, nil
}
```

### 5.4 写操作透传

```go
// internal/proxy/proxy.go

func (p *Proxy) Forward(ctx context.Context, req *types.JSONRPCRequest) (*types.JSONRPCResponse, error) {
    // 选择链节点
    node := p.balancer.Select()

    // 构造转发请求
    body, _ := json.Marshal(req)
    httpReq, _ := http.NewRequestWithContext(ctx, "POST", node.URL, bytes.NewReader(body))
    httpReq.Header.Set("Content-Type", "application/json")

    // 转发
    resp, err := p.client.Do(httpReq)
    if err != nil {
        return nil, fmt.Errorf("chain node unreachable: %w", err)
    }
    defer resp.Body.Close()

    // 解析响应
    var rpcResp types.JSONRPCResponse
    if err := json.NewDecoder(resp.Body).Decode(&rpcResp); err != nil {
        return nil, fmt.Errorf("invalid response from chain node: %w", err)
    }

    return &rpcResp, nil
}
```

---

## 6. 构建与运行

### 6.1 Makefile

```makefile
.PHONY: build run test lint clean migrate-up migrate-down

# 构建
build:
	go build -o bin/rpcd ./cmd/rpcd

# 运行
run: build
	./bin/rpcd --config config/config.yaml

# 测试
test:
	go test -v -race -cover ./...

# 测试（含集成测试）
test-all:
	go test -v -race -cover -tags=integration ./...

# 代码检查
lint:
	golangci-lint run ./...

# 格式化
fmt:
	gofmt -w .
	goimports -w .

# 数据库迁移
migrate-up:
	migrate -path migrations/postgres -database "$(POSTGRES_DSN)" up

migrate-down:
	migrate -path migrations/postgres -database "$(POSTGRES_DSN)" down 1

migrate-status:
	migrate -path migrations/postgres -database "$(POSTGRES_DSN)" status

# 清理
clean:
	rm -rf bin/

# Docker
docker-build:
	docker build -t openhive-rpcd:latest .

docker-run:
	docker compose up -d
```

### 6.2 运行参数

```bash
./bin/rpcd \
  --config config/config.yaml \
  --log-level info \
  --listen-addr :8080
```

---

## 7. Docker 部署

### 7.1 Dockerfile（多阶段构建）

```dockerfile
# 构建阶段
FROM golang:1.22-alpine AS builder

WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download

COPY . .
RUN CGO_ENABLED=0 GOOS=linux go build -ldflags="-s -w" -o /rpcd ./cmd/rpcd

# 运行阶段
FROM alpine:3.19

RUN apk add --no-cache ca-certificates tzdata

COPY --from=builder /rpcd /usr/local/bin/rpcd
COPY config/config.yaml /etc/rpcd/config.yaml
COPY migrations/ /etc/rpcd/migrations/

EXPOSE 8080 8081

ENTRYPOINT ["rpcd"]
CMD ["--config", "/etc/rpcd/config.yaml"]
```

### 7.2 生产环境 Docker Compose

```yaml
version: '3.8'

services:
  rpcd-1:
    image: openhive-rpcd:latest
    environment:
      - RPCD_SERVER_LISTEN_ADDR=:8080
      - RPCD_POSTGRES_DSN=postgres://rpcd:${PG_PASSWORD}@postgres-primary:5432/rpcd?sslmode=require
      - RPCD_REDIS_URL=redis://:${REDIS_PASSWORD}@redis-sentinel:26379/0?sentinelMasterID=mymaster
      - RPCD_CHAIN_NODES_0_URL=http://chain-node-1:13134
      - RPCD_CHAIN_NODES_1_URL=http://chain-node-2:13134
      - RPCD_LOG_LEVEL=info
    ports:
      - "8080:8080"
      - "8081:8081"
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "wget", "-q", "--spider", "http://localhost:8080/health"]
      interval: 10s
      timeout: 3s
      retries: 3

  rpcd-2:
    image: openhive-rpcd:latest
    environment:
      - RPCD_SERVER_LISTEN_ADDR=:8080
      - RPCD_POSTGRES_DSN=postgres://rpcd:${PG_PASSWORD}@postgres-primary:5432/rpcd?sslmode=require
      - RPCD_REDIS_URL=redis://:${REDIS_PASSWORD}@redis-sentinel:26379/0?sentinelMasterID=mymaster
      - RPCD_CHAIN_NODES_0_URL=http://chain-node-1:13134
      - RPCD_CHAIN_NODES_1_URL=http://chain-node-2:13134
      - RPCD_LOG_LEVEL=info
    ports:
      - "8081:8080"
      - "8082:8081"
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "wget", "-q", "--spider", "http://localhost:8080/health"]
      interval: 10s
      timeout: 3s
      retries: 3
```

**注意**：多实例部署时，只有一个实例运行 Indexer（通过配置 `indexer.enabled: true` 控制），其他实例只做查询服务。避免多个 Indexer 同时写入 PG。

---

## 8. 数据库迁移

### 8.1 迁移文件命名规范

```
序号_描述.sql

示例:
001_create_blocks.sql
002_create_transactions.sql
003_create_address_transactions.sql
```

### 8.2 迁移操作

```bash
# 执行所有待执行的迁移
make migrate-up

# 回退一步
make migrate-down

# 查看迁移状态
make migrate-status
```

### 8.3 迁移注意事项

- 所有迁移必须是**幂等的**（使用 `IF NOT EXISTS` / `IF EXISTS`）
- 大表加索引时使用 `CREATE INDEX CONCURRENTLY`（不锁表）
- 迁移文件一旦提交到仓库，**不可修改**，只能新增

---

## 9. 测试策略

### 9.1 测试分层

| 层级 | 范围 | 工具 | 运行频率 |
|------|------|------|---------|
| **单元测试** | 单个函数/方法 | `testing` + `testify` | 每次提交 |
| **集成测试** | 模块间交互（PG、Redis） | `testcontainers-go` | 每次 MR |
| **端到端测试** | 完整请求链路 | `httptest` + 真实 PG/Redis | 每日/发版前 |

### 9.2 单元测试示例

```go
// internal/parser/tx_parser_test.go

func TestParseTransferTx(t *testing.T) {
    tx := types.Transaction{
        Hash: "abc123",
        Type: "TX",
        UTXOs: []types.UTXOGroup{
            {
                Vin:  []types.Input{{PrevOut: types.PrevOutput{Hash: "prev1", N: 0}}},
                Vout: []types.Output{{Value: 100000000, Addr: "addr1"}},
                AssetType: "OHI",
            },
        },
    }

    records := ParseTransaction(tx, 100)

    assert.Len(t, records.AddressTxs, 2)
    assert.Equal(t, "in", records.AddressTxs[0].Direction)
    assert.Equal(t, int64(100000000), records.AddressTxs[0].Value)
}
```

### 9.3 集成测试（使用 testcontainers）

```go
//go:build integration

func TestStoreBlockIntegration(t *testing.T) {
    ctx := context.Background()

    // 启动临时 PostgreSQL
    pgContainer, err := postgres.RunContainer(ctx,
        testcontainers.WithImage("postgres:16-alpine"),
        postgres.WithDatabase("rpcd_test"),
        postgres.WithUsername("test"),
        postgres.WithPassword("test"),
    )
    defer pgContainer.Terminate(ctx)

    // 连接并测试
    dsn, _ := pgContainer.ConnectionString(ctx, "sslmode=disable")
    store := NewPostgresStore(dsn)

    block := types.Block{Hash: "test_hash", Height: 1, Timestamp: 1000}
    err = store.InsertBlock(ctx, &block)
    assert.NoError(t, err)

    got, err := store.GetBlockByHash(ctx, "test_hash")
    assert.NoError(t, err)
    assert.Equal(t, int64(1), got.Height)
}
```

---

## 10. 开发规范

### 10.1 代码风格

- 遵循 [Effective Go](https://go.dev/doc/effective_go) 和 [Go Code Review Comments](https://go.dev/wiki/CodeReviewComments)
- 使用 `golangci-lint` 进行静态检查
- 错误处理：不使用 `panic`，所有错误显式返回
- 命名：导出函数用 CamelCase，内部函数用 camelCase，常量用 CamelCase（不用 UPPER_SNAKE）

### 10.2 错误处理

```go
// 定义业务错误类型
var (
    ErrBlockNotFound    = errors.New("block not found")
    ErrTxNotFound       = errors.New("transaction not found")
    ErrInvalidAddress   = errors.New("invalid address format")
    ErrChainNodeDown    = errors.New("chain node unreachable")
    ErrSyncLagTooLarge  = errors.New("sync lag exceeds threshold")
)

// Handler 层统一错误响应
func respondError(c *gin.Context, rpcID any, err error) {
    code := -32000
    msg := err.Error()

    switch {
    case errors.Is(err, ErrBlockNotFound), errors.Is(err, ErrTxNotFound):
        code = -32001  // 数据不存在
    case errors.Is(err, ErrInvalidAddress):
        code = -32602  // 参数无效
    case errors.Is(err, ErrChainNodeDown):
        code = -32003  // 服务不可用
    }

    c.JSON(200, gin.H{
        "jsonrpc": "2.0",
        "id":      rpcID,
        "error": gin.H{
            "code":    code,
            "message": msg,
        },
    })
}
```

### 10.3 日志规范

```go
// 使用 slog 结构化日志
log.Info("block synced",
    "height", block.Height,
    "hash", block.Hash,
    "tx_count", len(block.Txs),
    "duration_ms", elapsed.Milliseconds())

log.Error("failed to parse block",
    "height", height,
    "error", err)

// 禁止使用 fmt.Println 或 log.Println
```

### 10.4 Git 规范

- 分支命名：`feature/xxx`、`fix/xxx`、`refactor/xxx`
- Commit message 格式：`type(scope): description`
  - `feat(indexer): add callback receiver`
  - `fix(parser): handle empty UTXO group`
  - `refactor(store): extract block store`
- 每个 MR 必须包含测试

---

## 11. 监控与告警

### 11.1 Prometheus 指标暴露

```go
// 在 /metrics 端点暴露 Prometheus 指标
mux.Handle("/metrics", promhttp.Handler())
```

### 11.2 关键告警规则

```yaml
# Prometheus alerting rules
groups:
  - name: rpcd
    rules:
      # 同步延迟过大
      - alert: SyncLagTooLarge
        expr: rpcd_chain_height - rpcd_sync_height > 10
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "rpcd 同步延迟超过 10 个区块"

      # 链节点不可达
      - alert: ChainNodeDown
        expr: rpcd_fallback_total{status="error"} > 5
        for: 2m
        labels:
          severity: critical
        annotations:
          summary: "链节点连续不可达"

      # 请求延迟过高
      - alert: HighRequestLatency
        expr: histogram_quantile(0.95, rpcd_request_duration_seconds) > 2
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "P95 请求延迟超过 2 秒"

      # 回滚事件
      - alert: ChainRollback
        expr: increase(rpcd_rollback_total[1h]) > 0
        labels:
          severity: info
        annotations:
          summary: "检测到链回滚事件"

      # PG 连接池耗尽
      - alert: PGConnectionPoolExhausted
        expr: rpcd_pg_active_conns / rpcd_pg_max_conns > 0.9
        for: 2m
        labels:
          severity: critical
        annotations:
          summary: "PostgreSQL 连接池使用率超过 90%"
```

---

## 12. CI/CD 建议

### 12.1 CI Pipeline

```yaml
# .github/workflows/ci.yaml (示例)
name: CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-go@v5
        with:
          go-version: '1.22'
      - uses: golangci/golangci-lint-action@v6

  test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16-alpine
        env:
          POSTGRES_USER: test
          POSTGRES_PASSWORD: test
          POSTGRES_DB: rpcd_test
        ports:
          - 5432:5432
      redis:
        image: redis:7-alpine
        ports:
          - 6379:6379
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-go@v5
        with:
          go-version: '1.22'
      - run: go test -v -race -cover ./...

  build:
    runs-on: ubuntu-latest
    needs: [lint, test]
    steps:
      - uses: actions/checkout@v4
      - run: go build -o bin/rpcd ./cmd/rpcd
```

### 12.2 发版流程

```
1. MR 合并到 main
2. CI 通过（lint + test + build）
3. 打 tag: git tag v1.0.0
4. CI 自动构建 Docker 镜像并推送到 Registry
5. 生产环境拉取新镜像，滚动更新
```

---

## 13. 常见问题

### Q1: 多个 rpcd 实例同时运行 Indexer 会怎样？

**A**: 会导致重复写入。解决方案：通过配置 `indexer.enabled: true/false` 控制，只允许一个实例运行 Indexer。其他实例只做查询服务。未来可引入分布式锁（Redis SETNX）实现自动选主。

### Q2: PG 数据与链节点数据不一致怎么办？

**A**: 正常现象，因为 Indexer 有 1-2 秒的同步延迟。对于实时性要求极高的场景，查询路由会自动 fallback 到链节点。响应中可通过 `x-data-source` 头标识数据来源（`index` 或 `chain`）。

### Q3: 回滚后数据多久能恢复？

**A**: 回滚后扫块线程会在下一个轮询周期（30s 内）检测到 gap 并自动追赶。追赶完成后数据即恢复一致。

### Q4: 如何添加新的 RPC 方法？

**A**: 三步：
1. 在 `internal/handler/jsonrpc_handler.go` 中注册新方法到 `queryMethods` map
2. 在 `internal/query/queries.go` 中实现查询逻辑
3. 如果需要新的数据库表，添加迁移文件

### Q5: 如何添加新的增强 API？

**A**: 三步：
1. 在 `internal/handler/rest_handler.go` 中注册新的 REST 路由
2. 在 `internal/query/queries.go` 中实现查询逻辑
3. 更新接口文档

---

*文档版本: 1.0.0-draft | 最后更新: 2026-06-18*
