# openhive-rpcd 接口文档

**版本**: 1.0.0-draft
**日期**: 2026-06-18
**状态**: Draft
**维护者**: OpenHive Core Team

---

## 目录

- [1. 概述](#1-概述)
- [2. JSON-RPC 查询接口](#2-json-rpc-查询接口)
- [3. ETH 兼容接口](#3-eth-兼容接口)
- [4. REST 增强 API 接口](#4-rest-增强-api-接口)
- [5. 错误码定义](#5-错误码定义)
- [6. 附录](#6-附录)

---

## 1. 概述

### 1.1 接口架构

openhive-rpcd 提供两种接口风格，通过路径前缀区分：

| 路径 | 协议 | 说明 |
|------|------|------|
| `POST /rpc` | JSON-RPC 2.0 | 兼容原有链节点的所有查询接口 + 写操作透传 |
| `GET/POST /api/v1/*` | RESTful | 新增增强 API（地址追踪、统计分析等） |

### 1.2 请求路由

```
客户端请求
  │
  ├── POST /rpc (JSON-RPC)
  │     ├── 写操作方法 → 透传到链节点
  │     └── 查询方法 → rpcd 本地处理（PG / Redis / fallback）
  │
  └── GET/POST /api/v1/* (REST)
        └── 全部由 rpcd 处理
```

### 1.3 通用说明

**基础 URL**：

```
http://<rpcd-host>:8080
```

**鉴权**：

通过 APISIX 网关层统一管理。请求需携带 API Key：

```
Header: apikey: <your-api-key>
```

**通用响应头**：

| Header | 说明 |
|--------|------|
| `x-data-source` | 数据来源：`index`（PG 索引）、`chain`（链节点 fallback）、`cache`（Redis 缓存） |
| `x-sync-height` | rpcd 当前同步到的区块高度 |
| `x-chain-height` | 链节点最新区块高度 |

---

## 2. JSON-RPC 查询接口

### 2.1 协议规范

所有 JSON-RPC 接口遵循 [JSON-RPC 2.0 规范](https://www.jsonrpc.org/specification)。

**请求格式**：

```json
{
  "jsonrpc": "2.0",
  "method": "方法名",
  "params": [参数] 或 {参数},
  "id": 1
}
```

**成功响应**：

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": { ... }
}
```

**错误响应**：

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32000,
    "message": "错误描述"
  }
}
```

**端点**：`POST /rpc`

---

### 2.2 基础查询接口

#### GetVersion

获取版本信息。

**参数**：无

**响应**：

```json
{
  "clientVersion": "1.0.0",
  "configVersion": "1.0.0",
  "netVersion": "1.0.0",
  "dbVersion": "1.0.0"
}
```

**数据来源**：缓存（版本信息不频繁变化）

**调用示例**：

```bash
curl -X POST http://localhost:8080/rpc \
  -H "Content-Type: application/json" \
  -H "apikey: your-key" \
  -d '{"jsonrpc":"2.0","method":"GetVersion","params":[],"id":1}'
```

---

#### GetBalance

获取指定地址的余额。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 账户地址 |
| asset_type | string | 是 | 资产类型 |

**响应**：

```json
{
  "addr": "0x1234567890abcdef",
  "asset_type": "0x01",
  "balance": "1000000000"
}
```

**数据来源**：PG `address_balances` 表（Indexer 同步），缓存 10s

**调用示例**：

```bash
curl -X POST http://localhost:8080/rpc \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetBalance","params":[{"addr":"0x1234567890abcdef","asset_type":"0x01"}],"id":1}'
```

---

#### GetBlockHeight

获取当前区块高度。

**参数**：无

**响应**：

```json
{
  "height": "1234567"
}
```

**数据来源**：Redis 缓存（`rpcd:block:latest`），每 2s 更新

**调用示例**：

```bash
curl -X POST http://localhost:8080/rpc \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"GetBlockHeight","params":[],"id":1}'
```

---

#### GetChainId

获取链 ID（创世区块 hash 前 8 位）。

**参数**：无

**响应**：

```json
{
  "chainId": "0x12345678"
}
```

**数据来源**：缓存

---

#### GetAccounts

获取本地账户列表。

**参数**：无

**响应**：

```json
{
  "acccountlist": [
    "0x1234567890abcdef",
    "0xfedcba0987654321"
  ]
}
```

**数据来源**：透传到链节点（此接口依赖链节点的本地密钥管理）

---

#### GetNodeList

获取节点列表。

**参数**：无

**响应**：节点列表，包含 addr、ip、port、height、version 等字段。

**数据来源**：透传到链节点（节点列表是 P2P 层实时数据，不适合索引）

---

#### GetAllStakeNodeList

获取所有质押节点列表。

**参数**：无

**响应**：已质押的节点列表，包含节点地址、名称、高度、身份、IP、版本等信息。

**数据来源**：PG `stake_records` 表

---

#### GetAddrType

获取地址状态类型。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 账户地址 |

**响应**：

```json
{
  "isBonus": true,
  "isDelegated": false,
  "isLocked": false,
  "isPackaged": false,
  "isStaked": true,
  "canReward": true
}
```

**数据来源**：PG 多表联合查询（`address_balances` + `stake_records` + `delegate_records` + `utxo_states`）

---

#### GetYieldInfo

获取收益信息（年化收益率）。

**参数**：无

**响应**：

```json
{
  "annualizedRate": "5.25"
}
```

**数据来源**：PG 计算或缓存

---

#### GetBonusInfo

获取奖励信息。

**参数**：无

**响应**：地址签名计数列表、周期时间。

**数据来源**：PG 查询

---

### 2.3 投票查询接口

#### GetVoteAddrs

根据资产类型 hash 获取投票地址列表。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 资产类型 hash |

**响应**：

```json
{
  "approveAddrs": [
    {"addr": "0xabc...", "count": 5}
  ],
  "againstAddrs": [
    {"addr": "0xdef...", "count": 2}
  ]
}
```

**数据来源**：PG `vote_records` 表

---

#### GetVoteTxHash

根据资产类型获取投票交易 hash 列表。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| asset_type | string | 是 | 资产类型 |

**数据来源**：PG `vote_records` 表

---

#### GetAllAssetType

获取所有资产类型。

**参数**：无

**响应**：资产类型 hash 列表。

**数据来源**：PG `asset_types` 表

---

#### GetAssetTypeInfo

获取资产类型详细信息。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| asset_type | string | 是 | 资产类型 |

**响应**：proposalInfo（提案信息）、revokeProposalInfo（撤销提案信息列表）。

**数据来源**：PG `asset_types` 表

---

#### GetAssetTypeByContractAddr

根据合约地址获取对应的资产类型。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| contractAddr | string | 是 | 合约地址（支持带 `0x` 前缀） |

**响应**：

```json
{
  "contractAddr": "0x1234567890abcdef1234567890abcdef12345678",
  "assetType": "0xabcdef1234567890abcdef1234567890abcdef12"
}
```

**数据来源**：PG `contracts` 表

---

### 2.4 区块交易查询接口

#### GetTransactionByHash

根据 hash 获取交易详情。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 交易 hash |

**数据来源**：Redis 缓存 → PG `transactions` 表 → fallback 链节点

---

#### GetBlockByHash

根据 hash 获取区块信息。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 区块 hash |

**数据来源**：Redis 缓存 → PG `blocks` 表 → fallback 链节点

---

#### GetBlockByHeight

根据高度范围获取区块列表。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| begin | uint64 | 是 | 起始高度 |
| end | uint64 | 是 | 结束高度 |

**限制**：`end - begin` 最大 100，超过返回错误。

**数据来源**：PG `blocks` 表

---

#### GetBlockByTransactionHash

根据交易 hash 获取区块信息。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 交易 hash |

**数据来源**：PG `transactions` → `blocks` 关联查询

---

#### GetDelegatingUtxo

获取委托 UTXO 列表。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| toAddr | string | 是 | 目标地址（奖励地址） |
| fromAddr | string | 是 | 源地址（委托地址） |
| asset_type | string | 是 | 资产类型 |

**数据来源**：PG `utxo_states` 表（`utxo_type = 'delegate'`）

---

#### GetStakingUtxo

获取质押 UTXO 列表。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| fromAddr | string | 是 | 源地址 |

**数据来源**：PG `utxo_states` 表（`utxo_type = 'stake'`）

---

#### GetLockUtxo

获取锁定 UTXO 列表。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| fromAddr | string | 是 | 源地址 |

**数据来源**：PG `utxo_states` 表（`utxo_type = 'lock'`）

---

#### GetBlockTransactionCountByHash

获取区块中的交易数量。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 区块 hash |

**响应**：

```json
{
  "txCount": "150"
}
```

**数据来源**：PG `blocks` 表（`tx_count` 字段）

---

#### GetDelegatingAddrsByBonusAddr

根据奖励地址获取委托地址列表。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 奖励地址 |

**数据来源**：PG `delegate_records` 表

---

#### GetUtxoDeployerByConAddr

根据合约地址获取部署者信息。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| contractAddr | string | 是 | 合约地址 |

**响应**：

```json
{
  "utxo": "0xabc123...",
  "deployer": "0xfedcba0987654321"
}
```

**数据来源**：PG `contracts` 表

---

#### IsContract

判断地址是否为合约地址。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| addr | string | 是 | 地址 |

**响应**：

```json
{
  "isContract": true
}
```

**数据来源**：PG `contracts` 表

---

#### GetTxByHash

根据 hash 获取交易详细信息（CALL 类型交易）。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 交易 hash |

**响应**：

```json
{
  "input": "0x...",
  "sender": "0x...",
  "recipient": "0x...",
  "gas": "100000",
  "hash": "0xabc...",
  "nonce": "5",
  "cumulativeGas": "200000"
}
```

**数据来源**：PG `transactions` 表

---

#### GetBlockNumberByHash

根据区块 hash 获取区块编号信息。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| hash | string | 是 | 区块 hash |

**响应**：

```json
{
  "hash": "0xabc123...",
  "timestamp": 1234567890,
  "number": 1000
}
```

**数据来源**：PG `blocks` 表

---

#### GetRollbackBlocks

获取回滚区块信息。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| blockNumber | uint64 | 否 | 区块高度（当 allRollbackNumber 为 false 时使用） |
| allRollbackNumber | bool | 是 | 是否获取所有回滚区块编号 |

**数据来源**：PG（rpcd 记录的回滚历史）

---

### 2.5 写操作接口（透传）

以下接口由 rpcd 透传到链节点处理，rpcd 不做任何业务逻辑：

| 方法 | 功能 | 说明 |
|------|------|------|
| `CreateTransaction` | 创建普通交易 | 透传 |
| `CreateStakingTransaction` | 创建质押交易 | 透传 |
| `CreateUnstakingTransaction` | 创建解押交易 | 透传 |
| `CreateDelegatingTransaction` | 创建委托交易 | 透传 |
| `CreateUndelegatingTransaction` | 创建取消委托交易 | 透传 |
| `CreateBonusTransaction` | 创建奖励交易 | 透传 |
| `CreateCallContractTransaction` | 创建调用合约交易 | 透传 |
| `CreateDeployContractTransaction` | 创建部署合约交易 | 透传 |
| `SendMessage` | 发送消息 | 透传 |
| `SendContractMessage` | 发送合约消息 | 透传 |
| `CreateLockTransaction` | 创建锁定交易 | 透传 |
| `CreateUnLockTransaction` | 创建解锁交易 | 透传 |
| `CreateVoteTransaction` | 创建投票交易 | 透传 |
| `CreateFundTransaction` | 创建资金交易 | 透传 |

**注意**：写操作接口的参数和响应格式与链节点完全一致，请参考 [RPC POST 接口文档](../rpc/rpc_api_post_doc.md) 中的详细说明。

---

## 3. ETH 兼容接口

OpenHive 兼容以太坊工具链（MetaMask、Hardhat、Web3.js 等），提供 17 个标准 ETH JSON-RPC 方法。

**端点**：`POST /rpc`（与自定义接口共用同一端点，通过 `method` 字段区分）

### 3.1 查询接口（rpcd 本地处理）

#### eth_chainId

获取链 ID。

**参数**：无

**响应**：`"0x3027"` (12315)

---

#### eth_blockNumber

获取当前区块高度。

**参数**：无

**响应**：`"0x12d687"` (十六进制区块高度)

**数据来源**：Redis 缓存

---

#### eth_gasPrice

获取 Gas 价格。

**参数**：无

**响应**：`"0x1"`

---

#### eth_feeHistory

获取费用历史（EIP-1559）。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| blockCount | string | 是 | 请求的区块数量 |
| newestBlock | string | 是 | 最新区块号（"latest"） |
| rewardPercentiles | array | 否 | 奖励百分位 |

---

#### eth_getBalance

获取账户余额。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| address | string | 是 | 账户地址 |
| blockNumber | string | 是 | 区块号（"latest" / "earliest" / 十六进制） |

**精度转换**：链上最小精度（10⁸）→ ETH 精度（10¹⁸），`balance × 10¹⁰`

**数据来源**：PG `address_balances` 表

---

#### eth_getTransactionCount

获取账户 nonce。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| address | string | 是 | 账户地址 |
| blockNumber | string | 是 | 区块号 |

---

#### eth_call

只读合约调用。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| transaction | object | 是 | 调用参数（to, data, from, gas 等） |
| blockNumber | string | 否 | 区块号 |

---

#### eth_getBlockByNumber

按区块号获取区块。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| blockNumber | string | 是 | 区块号（十六进制 / "latest" / "earliest"） |
| fullTransactions | boolean | 是 | 是否返回完整交易对象 |

**数据来源**：PG `blocks` 表

---

#### eth_getBlockByHash

按区块哈希获取区块。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| blockHash | string | 是 | 区块哈希 |
| fullTransactions | boolean | 是 | 是否返回完整交易对象 |

**数据来源**：PG `blocks` 表

---

#### eth_getCode

获取合约代码。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| address | string | 是 | 合约地址 |
| blockNumber | string | 是 | 区块号 |

---

#### eth_getTransactionReceipt

获取交易收据。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| txHash | string | 是 | 交易哈希 |

**数据来源**：PG `transactions` 表

---

#### eth_getTransactionByHash

按哈希获取交易。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| txHash | string | 是 | 交易哈希 |

**数据来源**：Redis → PG `transactions` 表 → fallback 链节点

---

#### eth_estimateGas

估算 Gas。

**参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| transaction | object | 是 | 交易参数 |

---

#### eth_accounts

获取账户列表。

**参数**：无

**数据来源**：透传到链节点

---

#### net_version

获取网络版本。

**参数**：无

**响应**：`"12315"`

---

#### web3_clientVersion

获取客户端版本。

**参数**：无

**响应**：`"OpenHive/v1.0.0"`

---

### 3.2 写操作接口（透传）

| 方法 | 功能 | 说明 |
|------|------|------|
| `eth_sendRawTransaction` | 发送原始交易 | 透传到链节点 |

---

## 4. REST 增强 API 接口

增强 API 提供链节点无法高效支撑的复杂查询能力。

**基础路径**：`/api/v1`

**通用分页参数**（适用于所有列表接口）：

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| page | int | 否 | 1 | 页码（从 1 开始） |
| page_size | int | 否 | 20 | 每页条数（最大 100） |
| order | string | 否 | desc | 排序方向（asc / desc） |

**通用分页响应**：

```json
{
  "data": [ ... ],
  "pagination": {
    "page": 1,
    "page_size": 20,
    "total": 1500,
    "total_pages": 75
  }
}
```

---

### 4.1 地址相关

#### GET /api/v1/address/:address/overview

获取地址综合概览信息。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| address | string | 账户地址（40 字符十六进制） |

**响应**：

```json
{
  "address": "755Ccf704E17570b64E247f0794314e4C8E542CA",
  "balances": [
    {
      "asset_type": "OHI",
      "balance": "10000000000",
      "balance_display": "100.00000000",
      "utxo_count": 5
    }
  ],
  "is_staked": true,
  "is_delegated": false,
  "is_locked": false,
  "is_contract": false,
  "first_seen_height": 100,
  "last_seen_height": 1234567,
  "total_tx_count": 42
}
```

**数据来源**：PG 多表联合查询

---

#### GET /api/v1/address/:address/transactions

获取地址的交易历史（分页）。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| address | string | 账户地址 |

**查询参数**：

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| page | int | 否 | 1 | 页码 |
| page_size | int | 否 | 20 | 每页条数（最大 100） |
| tx_type | string | 否 | — | 交易类型过滤（TX/STAKE/DELEGATE/CALL 等） |
| direction | string | 否 | — | 方向过滤（in/out） |
| asset_type | string | 否 | — | 资产类型过滤 |
| start_height | int | 否 | — | 起始区块高度 |
| end_height | int | 否 | — | 结束区块高度 |

**响应**：

```json
{
  "data": [
    {
      "tx_hash": "abc123def456...",
      "block_height": 1234500,
      "timestamp": 1718000000,
      "tx_type": "TX",
      "direction": "in",
      "value": "100000000",
      "value_display": "1.00000000",
      "asset_type": "OHI",
      "counterparty": "0xfedcba0987654321",
      "confirmations": 67
    }
  ],
  "pagination": {
    "page": 1,
    "page_size": 20,
    "total": 42,
    "total_pages": 3
  }
}
```

**数据来源**：PG `address_transactions` 表

---

#### GET /api/v1/address/:address/utxos

获取地址的 UTXO 列表。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| address | string | 账户地址 |

**查询参数**：

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| status | string | 否 | unspent | UTXO 状态（unspent / spent） |
| utxo_type | string | 否 | — | UTXO 类型（normal / stake / delegate / lock） |
| asset_type | string | 否 | — | 资产类型过滤 |

**响应**：

```json
{
  "data": [
    {
      "utxo_hash": "abc123...",
      "utxo_index": 0,
      "value": "500000000",
      "value_display": "5.00000000",
      "asset_type": "OHI",
      "status": "unspent",
      "utxo_type": "normal",
      "create_height": 1234000,
      "confirmations": 500
    }
  ],
  "pagination": {
    "page": 1,
    "page_size": 20,
    "total": 5,
    "total_pages": 1
  }
}
```

**数据来源**：PG `utxo_states` 表

---

#### GET /api/v1/address/:address/stakes

获取地址的质押记录。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| address | string | 质押地址 |

**查询参数**：

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| status | string | 否 | active | 状态（active / unstaked） |

**响应**：

```json
{
  "data": [
    {
      "utxo_hash": "abc123...",
      "amount": "350000000000",
      "amount_display": "3500.00000000",
      "asset_type": "OHI",
      "stake_height": 100000,
      "status": "active",
      "staking_duration_blocks": 1134567
    }
  ]
}
```

**数据来源**：PG `stake_records` 表

---

#### GET /api/v1/address/:address/delegates

获取地址的委托记录。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| address | string | 委托地址 |

**查询参数**：

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| role | string | 否 | delegator | 角色（delegator=我委托的 / bonus=委托给我的） |
| status | string | 否 | active | 状态 |

**响应**：

```json
{
  "data": [
    {
      "from_addr": "0xabc...",
      "to_addr": "0xdef...",
      "utxo_hash": "123...",
      "amount": "100000000000",
      "amount_display": "1000.00000000",
      "asset_type": "OHI",
      "delegate_type": 1,
      "delegate_height": 200000,
      "status": "active"
    }
  ]
}
```

**数据来源**：PG `delegate_records` 表

---

#### GET /api/v1/address/:address/locks

获取地址的锁定记录。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| address | string | 锁定地址 |

**响应**：

```json
{
  "data": [
    {
      "utxo_hash": "abc123...",
      "amount": "100000000",
      "amount_display": "1.00000000",
      "lock_type": 1,
      "lock_until": 1720000000,
      "create_height": 100000,
      "status": "locked"
    }
  ]
}
```

**数据来源**：PG `utxo_states` 表（`utxo_type = 'lock'`）

---

### 4.2 区块相关

#### GET /api/v1/blocks/latest

获取最新区块信息。

**响应**：

```json
{
  "block_hash": "abc123...",
  "height": 1234567,
  "prev_hash": "def456...",
  "merkle_root": "789abc...",
  "timestamp": 1718000000,
  "tx_count": 42,
  "packager": "0xabc...",
  "size_bytes": 12345
}
```

**数据来源**：Redis 缓存

---

#### GET /api/v1/blocks/:height

获取指定高度的区块信息。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| height | int | 区块高度 |

**响应**：同 `/api/v1/blocks/latest`

**数据来源**：PG `blocks` 表

---

#### GET /api/v1/blocks/:height/transactions

获取指定区块的交易列表（分页）。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| height | int | 区块高度 |

**查询参数**：

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| page | int | 否 | 1 | 页码 |
| page_size | int | 否 | 20 | 每页条数（最大 100） |
| tx_type | string | 否 | — | 交易类型过滤 |

**响应**：

```json
{
  "data": [
    {
      "tx_hash": "abc123...",
      "tx_index": 0,
      "tx_type": "TX",
      "sender": "0xabc...",
      "gas_used": "21000",
      "timestamp": 1718000000
    }
  ],
  "pagination": {
    "page": 1,
    "page_size": 20,
    "total": 42,
    "total_pages": 3
  }
}
```

**数据来源**：PG `transactions` 表

---

#### GET /api/v1/blocks/range

获取区块列表（范围查询）。

**查询参数**：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| start | int | 是 | 起始高度 |
| end | int | 是 | 结束高度（最大跨度 100） |

**响应**：

```json
{
  "data": [
    {
      "block_hash": "abc...",
      "height": 1234500,
      "tx_count": 35,
      "timestamp": 1718000000,
      "packager": "0xabc..."
    }
  ]
}
```

---

### 4.3 交易相关

#### GET /api/v1/transactions/:tx_hash

获取交易详情。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| tx_hash | string | 交易哈希 |

**响应**：

```json
{
  "tx_hash": "abc123...",
  "block_hash": "def456...",
  "block_height": 1234500,
  "tx_index": 0,
  "tx_type": "TX",
  "sender": "0xabc...",
  "timestamp": 1718000000,
  "gas_used": "21000",
  "gas_price": "10",
  "confirmations": 67,
  "inputs": [
    {
      "utxo_hash": "prev1...",
      "utxo_index": 0,
      "address": "0xabc...",
      "value": "200000000"
    }
  ],
  "outputs": [
    {
      "utxo_hash": "abc123...",
      "utxo_index": 0,
      "address": "0xdef...",
      "value": "100000000"
    },
    {
      "utxo_hash": "abc123...",
      "utxo_index": 1,
      "address": "0xabc...",
      "value": "99000000"
    }
  ],
  "raw_data": { ... }
}
```

**数据来源**：Redis → PG `transactions` + `utxo_states` → fallback 链节点

---

#### GET /api/v1/transactions/:tx_hash/confirmations

查询交易确认状态。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| tx_hash | string | 交易哈希 |

**响应**：

```json
{
  "tx_hash": "abc123...",
  "confirmed": true,
  "confirmations": 67,
  "block_height": 1234500,
  "chain_height": 1234567
}
```

---

### 4.4 合约相关

#### GET /api/v1/contracts/:contract_address

获取合约信息。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| contract_address | string | 合约地址 |

**响应**：

```json
{
  "contract_address": "0x111...",
  "deployer": "0xabc...",
  "deploy_tx_hash": "def456...",
  "deploy_height": 100000,
  "asset_type": "0xabc...",
  "contract_type": 0,
  "is_contract": true
}
```

**数据来源**：PG `contracts` 表

---

#### GET /api/v1/contracts/:contract_address/events

获取合约事件列表（分页）。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| contract_address | string | 合约地址 |

**查询参数**：

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| page | int | 否 | 1 | 页码 |
| page_size | int | 否 | 20 | 每页条数 |
| event_type | string | 否 | — | 事件类型过滤 |
| start_height | int | 否 | — | 起始区块高度 |
| end_height | int | 否 | — | 结束区块高度 |

**响应**：

```json
{
  "data": [
    {
      "tx_hash": "abc123...",
      "block_height": 1234500,
      "event_type": "Transfer",
      "log_index": 0,
      "data": {
        "from": "0xabc...",
        "to": "0xdef...",
        "value": "100000000"
      },
      "timestamp": 1718000000
    }
  ],
  "pagination": { ... }
}
```

**数据来源**：PG `contract_events` 表

---

### 4.5 治理相关

#### GET /api/v1/governance/proposals

获取提案列表。

**查询参数**：

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| page | int | 否 | 1 | 页码 |
| page_size | int | 否 | 20 | 每页条数 |

**响应**：

```json
{
  "data": [
    {
      "proposal_hash": "abc123...",
      "asset_type": "0x01",
      "proposal_type": 1,
      "start_time": 1718000000,
      "end_time": 1718604800,
      "contract_addr": "0x111...",
      "approve_count": 5,
      "against_count": 2,
      "status": "active"
    }
  ],
  "pagination": { ... }
}
```

**数据来源**：PG `asset_types` + `vote_records` 表

---

#### GET /api/v1/governance/proposals/:proposal_hash

获取提案详情。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| proposal_hash | string | 提案哈希 |

**响应**：

```json
{
  "proposal_hash": "abc123...",
  "asset_type": "0x01",
  "proposal_type": 1,
  "exchange_rate": "1.0",
  "start_time": 1718000000,
  "end_time": 1718604800,
  "contract_addr": "0x111...",
  "can_be_stake": true,
  "min_vote_num": 3,
  "votes": {
    "approve": [
      {"addr": "0xabc...", "count": 1}
    ],
    "against": [
      {"addr": "0xdef...", "count": 1}
    ]
  },
  "approve_total": 5,
  "against_total": 2
}
```

---

### 4.6 网络统计

#### GET /api/v1/network/stats

获取网络统计信息。

**响应**：

```json
{
  "chain_height": 1234567,
  "chain_id": "0x12345678",
  "total_nodes": 15,
  "staked_nodes": 10,
  "total_staked": "35000000000000",
  "total_staked_display": "350000.00000000",
  "avg_block_time_seconds": 10.2,
  "tx_count_24h": 43200,
  "active_addresses_24h": 150,
  "sync_status": {
    "rpcd_synced_height": 1234565,
    "chain_height": 1234567,
    "sync_lag": 2,
    "is_synced": true
  }
}
```

**数据来源**：PG 多表聚合 + Redis 缓存

---

#### GET /api/v1/network/nodes

获取节点列表。

**响应**：

```json
{
  "data": [
    {
      "address": "0xabc...",
      "ip": "192.168.1.100",
      "port": 13133,
      "height": 1234567,
      "version": "1.0.0",
      "is_staked": true,
      "is_active": true
    }
  ]
}
```

**数据来源**：透传到链节点（P2P 实时数据）

---

### 4.7 资产相关

#### GET /api/v1/assets

获取所有资产类型列表。

**响应**：

```json
{
  "data": [
    {
      "asset_hash": "0x01",
      "proposal_type": 1,
      "contract_addr": "0x111...",
      "can_be_stake": true,
      "start_time": 1718000000,
      "end_time": 1718604800
    }
  ]
}
```

**数据来源**：PG `asset_types` 表

---

#### GET /api/v1/assets/:asset_hash

获取资产类型详情。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| asset_hash | string | 资产类型哈希 |

---

#### GET /api/v1/assets/by-contract/:contract_address

根据合约地址查询资产类型。

**路径参数**：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| contract_address | string | 合约地址 |

**响应**：

```json
{
  "contract_address": "0x111...",
  "asset_hash": "0xabc..."
}
```

---

### 4.8 系统状态

#### GET /api/v1/status/sync

获取 Indexer 同步状态。

**响应**：

```json
{
  "synced_height": 1234565,
  "chain_height": 1234567,
  "sync_lag": 2,
  "sync_mode": "callback",
  "last_sync_time": "2026-06-18T10:30:00Z",
  "is_synced": true,
  "blocks_parsed_today": 8640,
  "txs_parsed_today": 432000
}
```

---

#### GET /api/v1/status/health

健康检查端点。

**响应**：

```json
{
  "status": "healthy",
  "components": {
    "postgres": "connected",
    "redis": "connected",
    "chain_node": "reachable",
    "indexer": "running"
  },
  "sync_lag": 2,
  "uptime_seconds": 86400
}
```

**HTTP 状态码**：
- `200`：所有组件正常
- `503`：任一组件异常

---

## 5. 错误码定义

### 5.1 JSON-RPC 标准错误码

| 错误码 | 含义 | 说明 |
|--------|------|------|
| -32700 | Parse error | JSON 解析失败 |
| -32600 | Invalid Request | 不符合 JSON-RPC 2.0 规范 |
| -32601 | Method not found | 方法不存在 |
| -32602 | Invalid params | 参数无效 |
| -32603 | Internal error | 内部错误 |

### 5.2 业务错误码

| 错误码 | 含义 | 说明 |
|--------|------|------|
| -32001 | Data not found | 请求的区块/交易/地址不存在 |
| -32002 | Invalid address | 地址格式无效 |
| -32003 | Service unavailable | 服务不可用（PG/Redis/链节点不可达） |
| -32004 | Rate limit exceeded | 请求频率超限（由 APISIX 返回） |
| -32005 | Query range exceeded | 查询范围超过限制（如区块跨度 > 100） |
| -32006 | Sync lag too large | 同步延迟过大，数据可能不准确 |
| -32007 | Chain node error | 链节点返回错误（透传写操作时） |

### 5.3 REST API 错误响应格式

```json
{
  "error": {
    "code": "DATA_NOT_FOUND",
    "message": "Block at height 99999999 not found",
    "status": 404
  }
}
```

### 5.4 HTTP 状态码

| 状态码 | 含义 | 使用场景 |
|--------|------|---------|
| 200 | OK | 请求成功 |
| 400 | Bad Request | 参数无效 |
| 401 | Unauthorized | 缺少或无效 API Key |
| 403 | Forbidden | IP 不在白名单 |
| 404 | Not Found | 资源不存在 |
| 429 | Too Many Requests | 限流触发 |
| 500 | Internal Server Error | 服务内部错误 |
| 503 | Service Unavailable | 依赖服务不可用 |

---

## 6. 附录

### 6.1 接口总览

#### JSON-RPC 查询接口（rpcd 本地处理）

| 方法 | 功能 | 数据来源 |
|------|------|---------|
| `GetVersion` | 获取版本信息 | 缓存 |
| `GetBalance` | 获取余额 | PG |
| `GetBlockHeight` | 获取区块高度 | Redis |
| `GetChainId` | 获取链 ID | 缓存 |
| `GetAllStakeNodeList` | 获取所有质押节点 | PG |
| `GetAddrType` | 获取地址状态类型 | PG |
| `GetYieldInfo` | 获取收益信息 | PG/缓存 |
| `GetBonusInfo` | 获取奖励信息 | PG |
| `GetVoteAddrs` | 获取投票地址 | PG |
| `GetVoteTxHash` | 获取投票交易 hash | PG |
| `GetAllAssetType` | 获取所有资产类型 | PG |
| `GetAssetTypeInfo` | 获取资产类型详情 | PG |
| `GetAssetTypeByContractAddr` | 合约地址→资产类型 | PG |
| `GetTransactionByHash` | 根据 hash 获取交易 | Redis→PG→fallback |
| `GetBlockByHash` | 根据 hash 获取区块 | Redis→PG→fallback |
| `GetBlockByHeight` | 根据高度获取区块 | PG |
| `GetBlockByTransactionHash` | 根据交易 hash 获取区块 | PG |
| `GetDelegatingUtxo` | 获取委托 UTXO | PG |
| `GetStakingUtxo` | 获取质押 UTXO | PG |
| `GetLockUtxo` | 获取锁定 UTXO | PG |
| `GetBlockTransactionCountByHash` | 获取区块交易数量 | PG |
| `GetDelegatingAddrsByBonusAddr` | 奖励地址→委托地址 | PG |
| `GetUtxoDeployerByConAddr` | 合约地址→部署者 | PG |
| `IsContract` | 判断是否为合约 | PG |
| `GetTxByHash` | 获取交易详情 | PG |
| `GetBlockNumberByHash` | 区块 hash→编号 | PG |
| `GetRollbackBlocks` | 获取回滚区块 | PG |

#### JSON-RPC 透传接口（转发到链节点）

| 方法 | 功能 |
|------|------|
| `GetAccounts` | 获取本地账户列表 |
| `GetNodeList` | 获取节点列表 |
| `Create*` (14 个) | 创建各类交易 |
| `SendMessage` | 发送消息 |
| `SendContractMessage` | 发送合约消息 |
| `eth_sendRawTransaction` | 发送原始 ETH 交易 |

#### ETH 兼容查询接口（rpcd 本地处理）

| 方法 | 功能 |
|------|------|
| `eth_chainId` | 获取链 ID |
| `eth_blockNumber` | 获取区块高度 |
| `eth_gasPrice` | 获取 Gas 价格 |
| `eth_feeHistory` | 获取费用历史 |
| `eth_getBalance` | 获取余额 |
| `eth_getTransactionCount` | 获取 nonce |
| `eth_call` | 只读合约调用 |
| `eth_getBlockByNumber` | 按区块号获取区块 |
| `eth_getBlockByHash` | 按区块哈希获取区块 |
| `eth_getCode` | 获取合约代码 |
| `eth_getTransactionReceipt` | 获取交易收据 |
| `eth_getTransactionByHash` | 获取交易 |
| `eth_estimateGas` | 估算 Gas |
| `net_version` | 获取网络版本 |
| `web3_clientVersion` | 获取客户端版本 |

#### REST 增强 API 接口

| 端点 | 功能 |
|------|------|
| `GET /api/v1/address/:addr/overview` | 地址综合概览 |
| `GET /api/v1/address/:addr/transactions` | 地址交易历史 |
| `GET /api/v1/address/:addr/utxos` | 地址 UTXO 列表 |
| `GET /api/v1/address/:addr/stakes` | 地址质押记录 |
| `GET /api/v1/address/:addr/delegates` | 地址委托记录 |
| `GET /api/v1/address/:addr/locks` | 地址锁定记录 |
| `GET /api/v1/blocks/latest` | 最新区块 |
| `GET /api/v1/blocks/:height` | 指定高度区块 |
| `GET /api/v1/blocks/:height/transactions` | 区块交易列表 |
| `GET /api/v1/blocks/range` | 区块范围查询 |
| `GET /api/v1/transactions/:tx_hash` | 交易详情（含输入输出） |
| `GET /api/v1/transactions/:tx_hash/confirmations` | 交易确认状态 |
| `GET /api/v1/contracts/:addr` | 合约信息 |
| `GET /api/v1/contracts/:addr/events` | 合约事件列表 |
| `GET /api/v1/governance/proposals` | 提案列表 |
| `GET /api/v1/governance/proposals/:hash` | 提案详情 |
| `GET /api/v1/network/stats` | 网络统计 |
| `GET /api/v1/network/nodes` | 节点列表 |
| `GET /api/v1/assets` | 资产类型列表 |
| `GET /api/v1/assets/:hash` | 资产类型详情 |
| `GET /api/v1/assets/by-contract/:addr` | 合约→资产类型 |
| `GET /api/v1/status/sync` | 同步状态 |
| `GET /api/v1/status/health` | 健康检查 |

### 6.2 精度说明

OpenHive 使用双精度系统：

| 精度类型 | 说明 | 使用场景 |
|---------|------|---------|
| 标准精度 | 单位为 1 OHI | UI 展示（`*_display` 字段） |
| 最小精度 | 1 OHI = 10⁸ 最小单位 | 数据库存储、API 返回（`balance`、`value` 等字段） |

**转换**：`最小精度 = 标准精度 × 100,000,000`

ETH 兼容接口额外转换：链上 10⁸ → ETH 10¹⁸（`× 10¹⁰`）

### 6.3 数据一致性说明

| 数据来源 | 一致性 | 延迟 |
|---------|--------|------|
| PG（Indexer 同步） | 最终一致 | 1-2 秒（出块周期 10s，回调驱动） |
| Redis 缓存 | 最终一致 | 取决于缓存 TTL（10s ~ 1h） |
| 链节点 fallback | 强一致 | 实时 |

对于刚发起的交易，在增强 API 中可能暂时查不到（Indexer 还没同步到）。此时查询路由会自动 fallback 到链节点获取最新数据。

响应头 `x-data-source` 标识了本次请求的实际数据来源：
- `index`：来自 PG 索引（可能有 1-2s 延迟）
- `chain`：来自链节点 fallback（实时）
- `cache`：来自 Redis 缓存

---

*文档版本: 1.0.0-draft | 最后更新: 2026-06-18*
