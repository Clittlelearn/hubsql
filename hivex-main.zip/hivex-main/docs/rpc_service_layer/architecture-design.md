# openhive-rpcd 架构设计文档

**版本**: 1.0.0-draft
**日期**: 2026-06-18
**状态**: Draft
**维护者**: OpenHive Core Team

---

## 目录

- [1. 概述](#1-概述)
- [2. 系统架构](#2-系统架构)
- [3. 核心组件设计](#3-核心组件设计)
- [4. 数据模型设计](#4-数据模型设计)
- [5. 回滚处理机制](#5-回滚处理机制)
- [6. 缓存策略](#6-缓存策略)
- [7. 安全纵深设计](#7-安全纵深设计)
- [8. 部署架构](#8-部署架构)
- [9. 可观测性](#9-可观测性)
- [10. 容量规划](#10-容量规划)

---

## 1. 概述

### 1.1 项目定位

`openhive-rpcd` 是 OpenHive 区块链的增强型 RPC 服务守护进程（RPC Daemon），作为独立于链节点的服务层，承担以下职责：

1. **RPC 代理**：兼容转发原有 JSON-RPC 查询接口，写操作透传至链节点
2. **数据索引**：通过回调 + 扫块双模式实时同步链上数据，构建离链索引
3. **增强 API**：提供地址追踪、交易历史、统计分析等链节点无法高效支撑的复杂查询
4. **协议桥接**：同时支持 JSON-RPC 2.0 和 RESTful 两种接口风格

### 1.2 设计目标

| 目标 | 指标 |
|------|------|
| 查询延迟 | 标准查询 < 50ms，增强查询 < 200ms |
| 数据同步延迟 | 回调模式下 < 2s（出块周期 10s） |
| 可用性 | 99.9%（链节点短暂不可用时服务仍可查询历史数据） |
| 吞吐量 | 单实例支撑 5000 QPS 查询 |
| 数据一致性 | 最终一致，支持链回滚后自动修正 |

### 1.3 与链节点的关系

```
┌──────────────────────┐          ┌──────────────────────┐
│   区块链节点 (C++)     │          │   openhive-rpcd      │
│   - 共识、打包、状态转换 │ ──回调──→ │   - 独立进程          │
│   - RocksDB           │          │   - PostgreSQL        │
│   - P2P 网络           │ ←─扫块── │   - Redis             │
│   - 不关心查询压力      │          │   - 双协议 API         │
└──────────────────────┘          └──────────────────────┘
        ↑                                    ↑
   只处理写请求                          处理所有查询请求
        │                                    │
        └────────── [ APISIX 网关 ] ──────────┘
```

**关键原则**：
- rpcd 不编译进 C++ 节点进程
- rpcd 不链接 RocksDB，不接触共识代码
- rpcd 通过 HTTP RPC 接口与链节点通信，保持完全解耦
- 链节点不需要为 rpcd 做任何代码改造（使用现有 RPC 接口）

---

## 2. 系统架构

### 2.1 整体架构

```
                              [ 外部用户 / DApp / 钱包 / 浏览器 ]
                                              │
                                              ▼
========================================================================================
                     【 边缘网关层 (Apache APISIX) 】
  - TLS 卸载、DDoS 防护（L3/L4 配合云厂商）
  - 鉴权（API Key / JWT）
  - 限流（按 IP、按路由、按消费者）
  - IP 黑白名单、CORS 控制、WAF
  - 智能路由（写操作 → 链节点，查询 → rpcd）
========================================================================================
          │                                    │                         │
          │ 写操作                              │ JSON-RPC 查询           │ REST 增强查询
          │ /rpc/Create*, /rpc/Send*           │ POST /rpc               │ GET/POST /api/v1/*
          │ eth_sendRawTransaction             │ eth_getBalance, ...     │
          ▼                                    ▼                         ▼
┌─────────────────────┐          ┌─────────────────────────────────────────────────┐
│  链节点集群 (C++)     │          │            openhive-rpcd (Go)                  │
│  - Create* / Send*  │          │                                                 │
│  - 交易验证、打包     │          │  ┌──────────┐  ┌──────────┐  ┌──────────────┐  │
│  - RocksDB          │          │  │ JSON-RPC │  │   REST   │  │   Proxy      │  │
└─────────────────────┘          │  │ Handler  │  │ Handler  │  │  (透传链节点) │  │
                                  │  └────┬─────┘  └────┬─────┘  └──────┬───────┘  │
                                  │       │              │               │          │
                                  │       └──────┬───────┘               │          │
                                  │              │                       │          │
                                  │       ┌──────▼──────┐               │          │
                                  │       │  Query      │◄──────────────┘          │
                                  │       │  Router     │                          │
                                  │       └──┬─────┬───┘                          │
                                  │          │     │                               │
                                  │   ┌──────▼┐ ┌──▼───────┐                      │
                                  │   │ Redis │ │PostgreSQL│                      │
                                  │   │ Cache │ │  Index   │                      │
                                  │   └───────┘ └──────────┘                      │
                                  │          ▲                                     │
                                  │          │ 写入                                │
                                  │   ┌──────┴──────────┐                         │
                                  │   │    Indexer       │                         │
                                  │   │ (回调+扫块双模式) │                         │
                                  │   └──────┬──────────┘                         │
                                  │          │ 监听                                │
                                  └──────────┼────────────────────────────────────┘
                                             │
                                  ┌──────────▼──────────┐
                                  │   区块链节点 (回调源)  │
                                  │   - 出块后推送新区块   │
                                  └─────────────────────┘
```

### 2.2 请求流转路径

#### 写操作（交易提交）

```
客户端 → APISIX → 链节点（直转，不经过 rpcd）
```

写操作由 APISIX 直接路由到链节点集群，rpcd 不参与。

#### JSON-RPC 查询

```
客户端 → APISIX → rpcd (POST /rpc)
                    │
                    ├── eth_* 方法 → ETH 兼容处理器 → 查 PG/Redis → 返回
                    ├── 标准查询方法 → 查询处理器 → 查 PG/Redis → 返回
                    └── 实时性要求高的查询 → 查 PG → cache miss → fallback 链节点 → 返回
```

#### REST 增强查询

```
客户端 → APISIX → rpcd (GET/POST /api/v1/*)
                    │
                    └── REST 处理器 → 查 PG/Redis → 返回增强结果
```

### 2.3 接口风格共存

rpcd 同时支持两种接口风格，按路径前缀分流：

| 路径前缀 | 协议 | 说明 |
|----------|------|------|
| `POST /rpc` | JSON-RPC 2.0 | 兼容原有链节点的所有查询接口，老客户端零改动 |
| `GET/POST /api/v1/*` | RESTful | 新增增强 API，地址追踪、统计分析等 |

**内部路由逻辑**：

```
请求进入 rpcd
  │
  ├── 路径 = /rpc → JSON-RPC 分发器
  │       │
  │       ├── method 属于写操作集合
  │       │       → Proxy 模块 HTTP 转发到链节点
  │       │
  │       └── method 属于查询操作集合
  │               → Query Router 分发到对应 Handler
  │               → 查 PG / Redis / fallback 链节点
  │
  └── 路径前缀 = /api/v1 → REST 分发器
          → 全部由 rpcd 处理（增强 API）
```

---

## 3. 核心组件设计

### 3.1 组件总览

| 组件 | 职责 | 依赖 |
|------|------|------|
| **Indexer** | 数据同步引擎，回调+扫块双模式 | 链节点回调接口、链节点 RPC |
| **Parser** | 区块/交易解析器，UTXO 模型解析 | — |
| **Store** | PostgreSQL 读写层 | PostgreSQL |
| **Cache** | Redis 缓存层 | Redis |
| **Query Router** | 查询路由，决定查 PG、查 Redis 还是 fallback | Store, Cache |
| **JSON-RPC Handler** | JSON-RPC 协议处理 | Query Router, Proxy |
| **REST Handler** | RESTful 协议处理 | Query Router |
| **Proxy** | HTTP 透传模块，转发写操作到链节点 | 链节点 HTTP RPC |
| **Fallback** | 回源模块，PG 数据不足时回链节点查询 | 链节点 HTTP RPC |

### 3.2 Indexer — 数据同步引擎

#### 3.2.1 双模式架构

```
┌─────────────────────────────────────────────────────────────┐
│                      Indexer                                │
│                                                             │
│  ┌─────────────────────┐     ┌──────────────────────────┐  │
│  │  回调接收器 (主通道)   │     │  扫块追赶器 (兜底保险)     │  │
│  │                     │     │                          │  │
│  │  - 监听链节点回调     │     │  - 低频轮询 (30s 一次)    │  │
│  │  - 实时接收新区块     │     │  - 对比 synced_height     │  │
│  │  - 解析 → 入库       │     │  - 发现 gap 则补块        │  │
│  │                     │     │  - 启动时全量追赶          │  │
│  └──────────┬──────────┘     └────────────┬─────────────┘  │
│             │                              │                │
│             └──────────┬───────────────────┘                │
│                        │                                    │
│               ┌────────▼────────┐                           │
│               │  sync_height    │                           │
│               │  状态管理器      │                           │
│               └─────────────────┘                           │
└─────────────────────────────────────────────────────────────┘
```

#### 3.2.2 回调模式（主通道）

链节点出块后通过回调通知 rpcd。rpcd 收到回调后：

1. 从回调数据中提取区块高度
2. 调用链节点 `GetBlockByHeight` 获取完整区块数据
3. 交给 Parser 解析
4. 解析结果批量写入 PostgreSQL
5. 更新 `synced_height`

**回调数据最小化**：回调只需传递区块高度和区块哈希，rpcd 主动拉取完整数据。这样回调通道保持轻量，即使回调数据丢失也可通过扫块补回。

#### 3.2.3 扫块模式（兜底保险）

后台低频线程，每 30 秒执行一次：

```
sync_gap = chain_height - synced_height

if sync_gap == 0:
    return  // 已同步到最新

if sync_gap == 1:
    // 单块差距，可能是回调延迟，等待
    return

if sync_gap > 1:
    // 检测到 gap，补块
    for h in (synced_height+1 .. chain_height):
        block = fetch_block(h)
        parse_and_store(block)
        synced_height = h
```

**启动时全量追赶**：

```
服务启动
  → 读取本地 synced_height
  → 查询链节点 GetBlockHeight
  → 如果 synced_height == 0: 从创世块开始全量同步
  → 如果 synced_height < chain_height: 追赶缺失区块
  → 追赶完成后切到回调驱动模式
```

#### 3.2.4 同步状态存储

```sql
CREATE TABLE sync_status (
    id              INTEGER PRIMARY KEY DEFAULT 1,
    synced_height   BIGINT NOT NULL DEFAULT 0,
    chain_height    BIGINT NOT NULL DEFAULT 0,
    last_sync_time  TIMESTAMP,
    sync_mode       VARCHAR(16) DEFAULT 'callback',  -- 'callback' | 'polling' | 'catching_up'
    updated_at      TIMESTAMP DEFAULT NOW()
);
```

### 3.3 Parser — 区块/交易解析器

Parser 负责将链节点的原始区块数据解析为结构化记录，核心是处理 UTXO 模型。

#### 3.3.1 解析流程

```
原始区块数据 (JSON from GetBlockByHeight)
  │
  ├── 提取区块元数据 → BlockRecord
  │
  └── 遍历区块内交易
        │
        ├── 提取交易元数据 → TransactionRecord
        │
        └── 遍历交易的 UTXO
              │
              ├── 解析 vin (输入) → 标记哪些 UTXO 被消费
              │     → 更新 address_transactions (direction='out')
              │     → 更新 utxo_states (status='spent')
              │
              └── 解析 vout (输出) → 标记新产生的 UTXO
                    → 更新 address_transactions (direction='in')
                    → 插入 utxo_states (status='unspent')
                    → 更新 address_balances
```

#### 3.3.2 交易类型识别

根据交易的 `type` 字段分类：

| 类型码 | 类型名 | 解析逻辑 |
|--------|--------|---------|
| GENESIS | 创世交易 | 初始化地址余额 |
| TX | 普通转账 | 解析 vin/vout，更新地址映射 |
| STAKE | 质押 | 记录质押关系 addr → stake_utxo |
| UNSTAKE | 解押 | 删除质押记录 |
| DELEGATE | 委托 | 记录委托关系 from_addr → to_addr |
| UNDELEGATE | 取消委托 | 删除委托记录 |
| DEPLOY | 部署合约 | 记录合约地址 → 部署者映射 |
| CALL | 调用合约 | 记录合约调用日志 |
| BONUS | 领取奖励 | 记录奖励发放 |
| LOCK | 锁定 | 记录锁定 UTXO |
| UNLOCK | 解锁 | 解除锁定记录 |
| PROPOSAL | 提案 | 记录提案信息 |
| VOTE | 投票 | 记录投票记录 |
| FUND | 国库 | 记录国库支出 |

### 3.4 Proxy — 透传模块

Proxy 负责将写操作请求透传到链节点：

```
写操作请求 (Create*, Send*, eth_sendRawTransaction)
  │
  ├── 1. 基本校验（JSON 格式合法性）
  ├── 2. 选择目标链节点（负载均衡：轮询/最少连接）
  ├── 3. HTTP POST 转发到链节点
  ├── 4. 返回链节点的原始响应
  └── 5. 记录转发日志
```

**设计原则**：
- Proxy 不做任何业务逻辑处理，纯透传
- 支持多链节点负载均衡
- 链节点不可用时返回 503，不缓存写请求
- 超时配置：连接超时 5s，读取超时 30s（与链节点一致）

### 3.5 Query Router — 查询路由

Query Router 决定每个查询请求的数据来源：

```
查询请求
  │
  ├── 1. 查 Redis 缓存
  │       ├── 命中 → 直接返回
  │       └── 未命中 → 继续
  │
  ├── 2. 查 PostgreSQL
  │       ├── 命中 → 写入 Redis 缓存 → 返回
  │       └── 未命中 → 继续
  │
  └── 3. Fallback 到链节点
          ├── 调用链节点 RPC 查询
          ├── 结果写入 Redis + PG（异步）
          └── 返回
```

**Fallback 触发条件**：
- PG 中查不到数据（可能是 Indexer 还没同步到）
- 请求参数中指定了 `confirmations=0`（要求最新数据）
- 查询的是 mempool 中的交易（未上链）

### 3.6 Fallback — 回源模块

```
Fallback 触发
  │
  ├── 1. 选择链节点（与 Proxy 共享负载均衡配置）
  ├── 2. 调用对应的链节点 RPC 接口
  ├── 3. 解析响应，转换为统一格式
  ├── 4. 异步更新 PG 和 Redis（回填缓存）
  └── 5. 返回结果
```

**Fallback 保护**：
- 单个请求最多 fallback 一次，不递归
- Fallback 失败返回 503，不重试
- Fallback 请求数纳入监控指标，异常增长时告警

---

## 4. 数据模型设计

### 4.1 核心表结构

#### 4.1.1 区块表 (blocks)

```sql
CREATE TABLE blocks (
    block_hash      VARCHAR(64) PRIMARY KEY,
    height          BIGINT NOT NULL,
    prev_hash       VARCHAR(64),
    merkle_root     VARCHAR(64),
    timestamp       BIGINT NOT NULL,          -- 微秒级时间戳
    tx_count        INT NOT NULL DEFAULT 0,
    packager        VARCHAR(64),              -- 打包节点地址
    version         INT,
    size_bytes      INT,
    created_at      TIMESTAMP DEFAULT NOW(),

    CONSTRAINT uq_block_height UNIQUE (height)
);

CREATE INDEX idx_blocks_height ON blocks(height DESC);
CREATE INDEX idx_blocks_timestamp ON blocks(timestamp DESC);
```

#### 4.1.2 交易表 (transactions)

```sql
CREATE TABLE transactions (
    tx_hash         VARCHAR(64) PRIMARY KEY,
    block_hash      VARCHAR(64) NOT NULL,
    block_height    BIGINT NOT NULL,
    tx_index        INT NOT NULL,             -- 区块内交易序号
    tx_type         VARCHAR(16) NOT NULL,     -- TX, STAKE, DELEGATE, CALL, etc.
    sender          VARCHAR(64),              -- 发送者地址
    timestamp       BIGINT NOT NULL,
    gas_used        BIGINT DEFAULT 0,
    gas_price       BIGINT DEFAULT 0,
    nonce           BIGINT,
    raw_data        TEXT,                     -- 原始 JSON（完整交易数据）
    created_at      TIMESTAMP DEFAULT NOW(),

    CONSTRAINT fk_tx_block FOREIGN KEY (block_hash) REFERENCES blocks(block_hash)
);

CREATE INDEX idx_tx_block_height ON transactions(block_height DESC);
CREATE INDEX idx_tx_type ON transactions(tx_type);
CREATE INDEX idx_tx_sender ON transactions(sender);
CREATE INDEX idx_tx_timestamp ON transactions(timestamp DESC);
```

#### 4.1.3 地址交易索引表 (address_transactions) — 核心索引

这是解决 UTXO 模型下地址查询性能问题的关键表。

```sql
CREATE TABLE address_transactions (
    address         VARCHAR(64) NOT NULL,
    tx_hash         VARCHAR(64) NOT NULL,
    block_height    BIGINT NOT NULL,
    tx_index        INT NOT NULL,
    tx_type         VARCHAR(16) NOT NULL,
    asset_type      VARCHAR(64) NOT NULL DEFAULT 'OHI',
    value           BIGINT NOT NULL DEFAULT 0,  -- 涉及金额（最小精度）
    direction       VARCHAR(4) NOT NULL,        -- 'in' / 'out'
    timestamp       BIGINT NOT NULL,
    created_at      TIMESTAMP DEFAULT NOW(),

    PRIMARY KEY (address, tx_hash, direction),
    CONSTRAINT fk_addr_tx FOREIGN KEY (tx_hash) REFERENCES transactions(tx_hash)
);

-- 核心查询索引：按地址 + 高度倒序（地址交易历史分页查询）
CREATE INDEX idx_addr_tx_height ON address_transactions(address, block_height DESC);
-- 按资产类型筛选
CREATE INDEX idx_addr_tx_asset ON address_transactions(address, asset_type, block_height DESC);
-- 按方向筛选
CREATE INDEX idx_addr_tx_direction ON address_transactions(address, direction, block_height DESC);
```

#### 4.1.4 UTXO 状态表 (utxo_states)

```sql
CREATE TABLE utxo_states (
    utxo_hash       VARCHAR(64) NOT NULL,
    utxo_index      INT NOT NULL,
    owner_address   VARCHAR(64) NOT NULL,
    asset_type      VARCHAR(64) NOT NULL DEFAULT 'OHI',
    value           BIGINT NOT NULL,
    status          VARCHAR(8) NOT NULL DEFAULT 'unspent',  -- 'unspent' | 'spent'
    spend_tx_hash   VARCHAR(64),              -- 消费该 UTXO 的交易 hash
    spend_height    BIGINT,                   -- 消费时的区块高度
    create_height   BIGINT NOT NULL,          -- 创建时的区块高度
    utxo_type       VARCHAR(16) DEFAULT 'normal',  -- 'normal' | 'stake' | 'delegate' | 'lock'
    lock_until      BIGINT,                   -- 锁定截止时间（锁定 UTXO）
    created_at      TIMESTAMP DEFAULT NOW(),

    PRIMARY KEY (utxo_hash, utxo_index)
);

CREATE INDEX idx_utxo_owner ON utxo_states(owner_address, status);
CREATE INDEX idx_utxo_asset ON utxo_states(owner_address, asset_type, status);
CREATE INDEX idx_utxo_type ON utxo_states(owner_address, utxo_type, status);
```

#### 4.1.5 地址余额表 (address_balances)

```sql
CREATE TABLE address_balances (
    address         VARCHAR(64) NOT NULL,
    asset_type      VARCHAR(64) NOT NULL DEFAULT 'OHI',
    balance         BIGINT NOT NULL DEFAULT 0,  -- 最小精度余额
    utxo_count      INT NOT NULL DEFAULT 0,
    last_updated    BIGINT NOT NULL,            -- 最后更新的区块高度

    PRIMARY KEY (address, asset_type)
);

CREATE INDEX idx_balance_asset ON address_balances(asset_type, balance DESC);
```

#### 4.1.6 质押记录表 (stake_records)

```sql
CREATE TABLE stake_records (
    staker_addr     VARCHAR(64) NOT NULL,
    utxo_hash       VARCHAR(64) NOT NULL,
    asset_type      VARCHAR(64) NOT NULL DEFAULT 'OHI',
    amount          BIGINT NOT NULL,
    stake_height    BIGINT NOT NULL,            -- 质押时的区块高度
    status          VARCHAR(16) NOT NULL DEFAULT 'active',  -- 'active' | 'unstaked'
    unstake_height  BIGINT,
    created_at      TIMESTAMP DEFAULT NOW(),

    PRIMARY KEY (staker_addr, utxo_hash)
);

CREATE INDEX idx_stake_status ON stake_records(status);
```

#### 4.1.7 委托记录表 (delegate_records)

```sql
CREATE TABLE delegate_records (
    from_addr       VARCHAR(64) NOT NULL,       -- 委托地址
    to_addr         VARCHAR(64) NOT NULL,       -- 奖励地址
    utxo_hash       VARCHAR(64) NOT NULL,
    asset_type      VARCHAR(64) NOT NULL DEFAULT 'OHI',
    amount          BIGINT NOT NULL,
    delegate_type   INT NOT NULL,
    delegate_height BIGINT NOT NULL,
    status          VARCHAR(16) NOT NULL DEFAULT 'active',  -- 'active' | 'undelegated'
    undelegate_height BIGINT,
    created_at      TIMESTAMP DEFAULT NOW(),

    PRIMARY KEY (from_addr, to_addr, utxo_hash)
);

CREATE INDEX idx_delegate_from ON delegate_records(from_addr, status);
CREATE INDEX idx_delegate_to ON delegate_records(to_addr, status);
```

#### 4.1.8 合约信息表 (contracts)

```sql
CREATE TABLE contracts (
    contract_addr   VARCHAR(64) PRIMARY KEY,
    deployer_addr   VARCHAR(64) NOT NULL,
    deploy_tx_hash  VARCHAR(64) NOT NULL,
    deploy_height   BIGINT NOT NULL,
    asset_type      VARCHAR(64),                -- 关联的资产类型
    contract_type   INT DEFAULT 0,              -- 0 = EVM
    created_at      TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_contract_deployer ON contracts(deployer_addr);
```

#### 4.1.9 合约事件表 (contract_events)

```sql
CREATE TABLE contract_events (
    id              BIGSERIAL PRIMARY KEY,
    contract_addr   VARCHAR(64) NOT NULL,
    tx_hash         VARCHAR(64) NOT NULL,
    block_height    BIGINT NOT NULL,
    event_type      VARCHAR(64),
    log_index       INT,
    data            JSONB,                      -- 事件数据
    timestamp       BIGINT NOT NULL,
    created_at      TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_event_contract ON contract_events(contract_addr, block_height DESC);
CREATE INDEX idx_event_type ON contract_events(event_type);
```

#### 4.1.10 资产类型表 (asset_types)

```sql
CREATE TABLE asset_types (
    asset_hash      VARCHAR(64) PRIMARY KEY,
    proposal_type   INT,
    exchange_rate   VARCHAR(32),
    start_time      BIGINT,
    end_time        BIGINT,
    contract_addr   VARCHAR(64),
    can_be_stake    BOOLEAN DEFAULT FALSE,
    min_vote_num    INT,
    created_at      TIMESTAMP DEFAULT NOW()
);
```

#### 4.1.11 投票记录表 (vote_records)

```sql
CREATE TABLE vote_records (
    voter_addr      VARCHAR(64) NOT NULL,
    proposal_hash   VARCHAR(64) NOT NULL,
    vote_type       INT NOT NULL,               -- 1=赞成, 2=反对
    vote_height     BIGINT NOT NULL,
    tx_hash         VARCHAR(64) NOT NULL,
    created_at      TIMESTAMP DEFAULT NOW(),

    PRIMARY KEY (voter_addr, proposal_hash)
);

CREATE INDEX idx_vote_proposal ON vote_records(proposal_hash, vote_type);
```

### 4.2 数据关系图

```
blocks (1) ──── (N) transactions
                        │
                        ├── (N) address_transactions
                        ├── (N) utxo_states (create)
                        ├── (N) utxo_states (spend)
                        │
                        ├── (1) stake_records (if STAKE)
                        ├── (1) delegate_records (if DELEGATE)
                        ├── (1) contracts (if DEPLOY)
                        ├── (N) contract_events (if CALL)
                        └── (1) vote_records (if VOTE)

address_balances ← (聚合自 utxo_states)
sync_status ← (Indexer 维护)
```

---

## 5. 回滚处理机制

### 5.1 回滚触发

rpcd 通过两种方式检测链回滚：

1. **回调通知**：链节点回滚时发送回滚回调
2. **扫块校验**：扫块线程对比 `blocks` 表中 `top_height` 的 `prev_hash` 与链节点返回的数据

### 5.2 回滚处理流程

```
检测到回滚（回滚高度 = rollback_height）
  │
  ├── 1. 开启 PostgreSQL 事务
  │
  ├── 2. 删除 rollback_height 及以上的所有数据
  │       ├── DELETE FROM address_transactions WHERE block_height >= rollback_height
  │       ├── DELETE FROM transactions WHERE block_height >= rollback_height
  │       ├── DELETE FROM blocks WHERE height >= rollback_height
  │       ├── 恢复被消费的 UTXO（spend_height >= rollback_height 的 UTXO 改回 unspent）
  │       ├── 删除新产生的 UTXO（create_height >= rollback_height）
  │       ├── 回退 address_balances 到 rollback_height - 1 的状态
  │       └── 删除 stake_records / delegate_records / vote_records 中对应高度的记录
  │
  ├── 3. 更新 sync_status.synced_height = rollback_height - 1
  │
  ├── 4. 清除 Redis 中受影响的缓存
  │
  └── 5. 提交事务，触发扫块追赶重新同步
```

### 5.3 回滚安全保证

- **事务性**：所有回滚操作在单个 PostgreSQL 事务中完成，要么全部成功，要么全部回退
- **幂等性**：对同一回滚高度重复执行不会产生副作用
- **数据重建**：回滚后扫块线程自动重新同步新链上的区块，数据自动修复

---

## 6. 缓存策略

### 6.1 缓存分层

| 层级 | 存储 | TTL | 适用场景 |
|------|------|-----|---------|
| **L1 热缓存** | Redis | 10s | 最新区块高度、最新区块信息、热门地址余额 |
| **L2 温缓存** | Redis | 5min | 已确认交易详情、区块详情、地址余额 |
| **L3 冷缓存** | Redis | 1h | 历史区块、历史交易（不会变化的数据） |
| **持久存储** | PostgreSQL | — | 全量索引数据 |

### 6.2 缓存 Key 设计

```
# 区块
rpcd:block:hash:{block_hash}          → 区块完整 JSON
rpcd:block:height:{height}            → 区块 hash（高度→hash 映射）
rpcd:block:latest                     → 最新区块高度 + hash

# 交易
rpcd:tx:{tx_hash}                     → 交易完整 JSON

# 地址
rpcd:balance:{address}:{asset_type}   → 余额
rpcd:addr_type:{address}              → 地址状态类型

# 链信息
rpcd:chain:id                         → 链 ID
rpcd:chain:version                    → 版本信息
```

### 6.3 缓存更新策略

| 事件 | 缓存操作 |
|------|---------|
| Indexer 同步新区块 | 更新 `rpcd:block:latest`，写入区块缓存（L3） |
| Indexer 解析交易 | 更新相关地址余额缓存（L2），写入交易缓存（L3） |
| 查询命中 fallback | 回填缓存（L2） |
| 回滚发生 | 删除受影响高度范围内的所有缓存 |

### 6.4 缓存穿透防护

- **空值缓存**：查询结果为空时，缓存空值（TTL 30s），防止恶意查询不存在的地址/交易导致每次都穿透到 PG
- **布隆过滤器**：对 `tx_hash` 和 `block_hash` 维护布隆过滤器，快速判断数据是否存在，避免无效查询打到 PG

---

## 7. 安全纵深设计

### 7.1 安全分层

```
┌─────────────────────────────────────────────┐
│  L1: APISIX 网关层（通用安全）                │
│  - 鉴权（API Key / JWT）                     │
│  - 限流（按 IP / 按路由 / 按消费者）           │
│  - IP 黑白名单                               │
│  - CORS 控制                                 │
│  - 请求体大小限制                             │
│  - WAF 基础防护                              │
└──────────────────────┬──────────────────────┘
                       │
┌──────────────────────▼──────────────────────┐
│  L2: rpcd 服务层（业务安全）                   │
│  - 输入参数校验                               │
│  - 查询范围限制                               │
│  - 参数化查询（防 SQL 注入）                   │
│  - 数据库连接池保护                            │
│  - 查询超时控制                               │
│  - 优雅降级                                  │
└──────────────────────┬──────────────────────┘
                       │
┌──────────────────────▼──────────────────────┐
│  L3: 基础设施层                               │
│  - PostgreSQL: 独立网络，仅 rpcd 可访问        │
│  - Redis: 独立网络，仅 rpcd 可访问             │
│  - 链节点: 内网通信，mTLS（可选）              │
└─────────────────────────────────────────────┘
```

### 7.2 rpcd 服务层安全措施

#### 输入校验

```go
// 地址格式校验
func ValidateAddress(addr string) error {
    // 40 字符十六进制（与以太坊地址格式一致）
    if len(addr) != 40 && !isValidHex(addr) {
        return ErrInvalidAddress
    }
    return nil
}

// 区块高度范围校验
func ValidateBlockHeight(height int64) error {
    if height < 0 {
        return ErrInvalidHeight
    }
    return nil
}

// 分页参数校验
func ValidatePagination(page, pageSize int) (int, int) {
    if page < 1 { page = 1 }
    if pageSize < 1 { pageSize = 10 }
    if pageSize > 100 { pageSize = 100 }  // 硬上限
    return page, pageSize
}
```

#### 查询范围限制

| 接口 | 限制 | 说明 |
|------|------|------|
| `GetBlockByHeight` | begin 和 end 差值 ≤ 100 | 防止查询放大攻击 |
| 地址交易历史分页 | page_size ≤ 100 | 单次最多返回 100 条 |
| 批量地址查询 | 单次 ≤ 20 个地址 | 防止批量枚举 |

#### 数据库保护

```
PostgreSQL 配置:
  - statement_timeout = 5000        # 查询超时 5 秒
  - idle_in_transaction_session_timeout = 10000  # 空闲事务超时 10 秒
  - max_connections = 200           # 连接池上限

Go 连接池配置:
  - pgxpool: max_conns = 100
  - min_conns = 10
  - max_conn_lifetime = 30min
  - max_conn_idle_time = 5min
```

#### 优雅降级

```
PG 不可用:
  → 返回 503 Service Unavailable
  → 不崩溃，不 panic
  → 日志记录错误，Prometheus 指标 +1

Redis 不可用:
  → 跳过缓存，直接查 PG
  → 性能下降但服务可用

链节点不可用:
  → Fallback 失败，返回 PG 中的数据（可能略有延迟）
  → 标注响应中 data_freshness = "eventually_consistent"
```

---

## 8. 部署架构

### 8.1 推荐部署拓扑

```
┌─────────────────────────────────────────────────────────┐
│                    公网 / DMZ                            │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │  APISIX 集群 (2+ 节点)                           │    │
│  │  - 端口 443 (HTTPS)                              │    │
│  │  - TLS 卸载                                      │    │
│  └────────────────────┬────────────────────────────┘    │
│                       │                                 │
└───────────────────────┼─────────────────────────────────┘
                        │ 内网
┌───────────────────────┼─────────────────────────────────┐
│                       │                                 │
│  ┌────────────────────▼────────────────────────────┐    │
│  │  openhive-rpcd 集群 (2+ 实例)                    │    │
│  │  - 端口 8080 (HTTP)                              │    │
│  │  - Docker 容器部署                                │    │
│  └──────┬──────────────────────────┬───────────────┘    │
│         │                          │                    │
│  ┌──────▼──────┐          ┌───────▼───────┐            │
│  │ PostgreSQL  │          │    Redis      │            │
│  │ (主从复制)   │          │  (Sentinel)   │            │
│  └─────────────┘          └───────────────┘            │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │  链节点集群 (C++)                                 │    │
│  │  - 交易节点 (写)                                  │    │
│  │  - 查询节点 (读，可选)                             │    │
│  └─────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
```

### 8.2 Docker Compose（开发/测试环境）

```yaml
version: '3.8'

services:
  rpcd:
    build: .
    ports:
      - "8080:8080"
    environment:
      - RPCD_CHAIN_RPC_URL=http://chain-node:13134
      - RPCD_PG_DSN=postgres://rpcd:rpcd@postgres:5432/rpcd
      - RPCD_REDIS_URL=redis://redis:6379/0
      - RPCD_LISTEN_ADDR=:8080
      - RPCD_LOG_LEVEL=info
    depends_on:
      - postgres
      - redis
    restart: unless-stopped

  postgres:
    image: postgres:16-alpine
    environment:
      - POSTGRES_USER=rpcd
      - POSTGRES_PASSWORD=rpcd
      - POSTGRES_DB=rpcd
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./migrations/postgres:/docker-entrypoint-initdb.d
    ports:
      - "5432:5432"

  redis:
    image: redis:7-alpine
    command: redis-server --maxmemory 256mb --maxmemory-policy allkeys-lru
    volumes:
      - redisdata:/data
    ports:
      - "6379:6379"

volumes:
  pgdata:
  redisdata:
```

---

## 9. 可观测性

### 9.1 指标 (Metrics)

通过 Prometheus `/metrics` 端点暴露：

| 指标 | 类型 | 说明 |
|------|------|------|
| `rpcd_sync_height` | Gauge | 当前同步高度 |
| `rpcd_chain_height` | Gauge | 链节点最新高度 |
| `rpcd_sync_lag` | Gauge | 同步延迟（chain_height - synced_height） |
| `rpcd_request_total` | Counter | 请求总数（按 method、status 分） |
| `rpcd_request_duration_seconds` | Histogram | 请求延迟分布 |
| `rpcd_fallback_total` | Counter | Fallback 到链节点的次数 |
| `rpcd_cache_hit_total` | Counter | 缓存命中次数 |
| `rpcd_cache_miss_total` | Counter | 缓存未命中次数 |
| `rpcd_pg_query_duration_seconds` | Histogram | PG 查询延迟 |
| `rpcd_rollback_total` | Counter | 回滚事件次数 |
| `rpcd_indexer_block_parsed_total` | Counter | Indexer 已解析区块数 |
| `rpcd_indexer_tx_parsed_total` | Counter | Indexer 已解析交易数 |

### 9.2 日志 (Logging)

- 结构化日志（JSON 格式），使用 `slog` 或 `zap`
- 日志级别：`debug` / `info` / `warn` / `error`
- 关键事件日志：
  - Indexer 同步新区块：`info`
  - Fallback 触发：`warn`
  - 回滚发生：`warn`
  - 数据库错误：`error`
  - 链节点不可达：`error`

### 9.3 链路追踪 (Tracing)

- 支持 OpenTelemetry，可接入 Jaeger / Tempo
- 每个请求生成 trace_id，贯穿 rpcd → PG / Redis / 链节点

---

## 10. 容量规划

### 10.1 存储估算

假设出块间隔 10 秒，每区块平均 50 笔交易：

| 数据 | 每日增量 | 每月增量 | 每年增量 |
|------|---------|---------|---------|
| 区块数 | 8,640 | 259,200 | 3,153,600 |
| 交易数 | 432,000 | 12,960,000 | 157,680,000 |
| address_transactions | ~864,000 行 (每笔交易涉及 2 个地址) | ~25,920,000 行 | ~315,360,000 行 |
| utxo_states | ~432,000 行 | ~12,960,000 行 | ~157,680,000 行 |

**PostgreSQL 存储**：
- 每行 address_transactions 约 200 字节
- 每月 address_transactions 约 5 GB
- 每年约 60 GB
- 建议：SSD 存储，预留 200 GB

### 10.2 内存估算

| 组件 | 内存 |
|------|------|
| rpcd 进程 | 256 MB |
| PostgreSQL (work_mem + shared_buffers) | 2 GB |
| Redis (缓存) | 256 MB - 1 GB |
| **总计** | **约 3 GB** |

### 10.3 扩缩容策略

| 维度 | 策略 |
|------|------|
| **rpcd 水平扩展** | 无状态服务，加实例 + LB 即可 |
| **PostgreSQL 垂直扩展** | 优先升级 CPU 和 SSD IOPS |
| **PostgreSQL 读写分离** | 数据量超过 1 亿行后考虑加只读副本 |
| **Redis 扩展** | 数据量大后切 Redis Cluster |

---

*文档版本: 1.0.0-draft | 最后更新: 2026-06-18*
