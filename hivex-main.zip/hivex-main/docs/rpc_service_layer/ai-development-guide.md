# openhive-rpcd AI 编程指导手册

**版本**: 1.0.0
**日期**: 2026-06-18
**目标读者**: AI 编程助手（作为资深区块链 + Go 开发专家）

---

## 重要声明

你是一位资深的区块链基础设施开发专家和 Go 语言高级开发者。你的任务是根据本文档和相关设计文档，完成 `openhive-rpcd`（OpenHive RPC Daemon）的完整开发。

**必须严格遵守**：
1. 所有实现必须与本文档中的设计完全一致
2. 禁止引入文档中未提及的第三方依赖
3. 禁止使用 ORM（如 GORM、ent），必须使用 pgx 直接写 SQL
4. 所有代码必须包含完整的错误处理和日志记录
5. 所有公共函数必须有单元测试

---

## 目录

- [1. 项目概述](#1-项目概述)
- [2. 技术栈约束](#2-技术栈约束)
- [3. 项目结构](#3-项目结构)
- [4. 开发阶段与任务分解](#4-开发阶段与任务分解)
- [5. 阶段一：基础框架搭建](#5-阶段一基础框架搭建)
- [6. 阶段二：数据模型与存储层](#6-阶段二数据模型与存储层)
- [7. 阶段三：Indexer 数据同步引擎](#7-阶段三indexer-数据同步引擎)
- [8. 阶段四：JSON-RPC 接口实现](#8-阶段四json-rpc-接口实现)
- [9. 阶段五：REST 增强 API 实现](#9-阶段五rest-增强-api-实现)
- [10. 阶段六：缓存与 Fallback](#10-阶段六缓存与-fallback)
- [11. 阶段七：测试与部署](#11-阶段七测试与部署)
- [12. 代码规范与约束](#12-代码规范与约束)
- [13. 验收标准](#13-验收标准)

---

## 1. 项目概述

### 1.1 项目定位

`openhive-rpcd` 是 OpenHive 区块链的增强型 RPC 服务守护进程，作为独立于链节点的服务层，承担以下职责：

1. **RPC 代理**：兼容转发原有 JSON-RPC 查询接口，写操作透传至链节点
2. **数据索引**：通过回调 + 扫块双模式实时同步链上数据，构建离链索引
3. **增强 API**：提供地址追踪、交易历史、统计分析等复杂查询
4. **协议桥接**：同时支持 JSON-RPC 2.0 和 RESTful 两种接口风格

### 1.2 设计目标

| 目标 | 指标 | 验收标准 |
|------|------|---------|
| 查询延迟 | 标准查询 < 50ms，增强查询 < 200ms | P95 延迟测试 |
| 数据同步延迟 | 回调模式下 < 2s | 出块后 2s 内可查询到 |
| 可用性 | 99.9% | 链节点短暂不可用时仍可查询历史数据 |
| 吞吐量 | 单实例 5000 QPS | 压测验证 |
| 数据一致性 | 最终一致 | 支持链回滚后自动修正 |

### 1.3 关键约束

- **完全独立**：rpcd 是独立进程，不编译进 C++ 链节点
- **完全解耦**：通过 HTTP RPC 接口与链节点通信，不直接访问 RocksDB
- **双协议支持**：JSON-RPC（`POST /rpc`）+ REST（`GET/POST /api/v1/*`）
- **写操作透传**：所有写操作（Create*、Send*）直接转发到链节点，不做业务处理
- **查询本地化**：所有查询优先查本地 PG/Redis，必要时 fallback 到链节点

---

## 2. 技术栈约束

### 2.1 必须使用的依赖

```go
// go.mod 必须包含以下依赖
require (
    github.com/gin-gonic/gin v1.10.0          // HTTP 框架
    github.com/jackc/pgx/v5 v5.6.0            // PostgreSQL 驱动
    github.com/redis/go-redis/v9 v9.5.0       // Redis 客户端
    github.com/spf13/viper v1.18.0            // 配置管理
    github.com/prometheus/client_golang v1.19.0 // Prometheus 指标
    go.opentelemetry.io/otel v1.27.0          // OpenTelemetry
    github.com/golang-migrate/migrate/v4 v4.3.0 // 数据库迁移
)
```

### 2.2 禁止使用的依赖

| 禁止使用 | 原因 | 替代方案 |
|---------|------|---------|
| GORM / ent / sqlx | ORM 过重，性能不如原生 SQL | 使用 pgx 直接写 SQL |
| gRPC | 当前阶段不需要 | 所有接口使用 HTTP |
| Kafka / RabbitMQ | 不需要消息队列 | Indexer 直接回调+扫块 |
| zap / logrus | 标准库够用 | 使用 slog（Go 1.21+） |

### 2.3 Go 版本要求

```
Go >= 1.22
```

必须使用 Go 1.22+ 的新特性：
- `slog` 结构化日志
- `range over func`（如需要）
- 新的 `net/http` 路由增强（如需要）

---

## 3. 项目结构

### 3.1 完整目录结构

**必须严格按照以下结构创建项目**：

```
openhive-rpcd/
│
├── cmd/
│   └── rpcd/
│       └── main.go                  # 程序入口，组装所有组件
│
├── internal/
│   ├── config/
│   │   └── config.go                # 配置结构定义与加载
│   │
│   ├── server/
│   │   ├── server.go                # HTTP Server 启动与路由注册
│   │   ├── middleware.go            # 中间件（日志、指标、恢复、CORS）
│   │   └── jsonrpc.go               # JSON-RPC 2.0 分发器
│   │
│   ├── handler/
│   │   ├── jsonrpc_handler.go       # JSON-RPC 查询请求处理器
│   │   ├── rest_handler.go          # REST 增强 API 处理器
│   │   └── proxy_handler.go         # 写操作透传处理器
│   │
│   ├── indexer/
│   │   ├── indexer.go               # Indexer 主循环（回调+扫块协调）
│   │   ├── callback.go              # 回调接收器
│   │   ├── poller.go                # 扫块追赶器
│   │   └── rollback.go              # 回滚处理器
│   │
│   ├── parser/
│   │   ├── parser.go                # 区块/交易解析主入口
│   │   ├── block_parser.go          # 区块元数据解析
│   │   ├── tx_parser.go             # 交易解析（按类型分发）
│   │   └── utxo_parser.go           # UTXO 输入/输出解析
│   │
│   ├── store/
│   │   ├── store.go                 # Store 接口定义
│   │   ├── postgres.go              # PostgreSQL 连接池管理
│   │   ├── block_store.go           # 区块 CRUD
│   │   ├── tx_store.go              # 交易 CRUD
│   │   ├── address_store.go         # 地址交易索引 CRUD
│   │   ├── utxo_store.go            # UTXO 状态 CRUD
│   │   ├── balance_store.go         # 余额 CRUD
│   │   ├── stake_store.go           # 质押记录 CRUD
│   │   ├── delegate_store.go        # 委托记录 CRUD
│   │   ├── contract_store.go        # 合约信息 CRUD
│   │   └── sync_store.go            # 同步状态 CRUD
│   │
│   ├── cache/
│   │   ├── cache.go                 # Cache 接口定义
│   │   ├── redis.go                 # Redis 实现
│   │   └── keys.go                  # 缓存 Key 定义
│   │
│   ├── query/
│   │   ├── router.go                # 查询路由（PG → Redis → Fallback）
│   │   ├── fallback.go              # 回源链节点查询
│   │   ├── jsonrpc_queries.go       # JSON-RPC 查询方法实现
│   │   └── eth_queries.go           # ETH 兼容查询实现
│   │
│   ├── proxy/
│   │   ├── proxy.go                 # 写操作透传
│   │   └── balancer.go              # 链节点负载均衡
│   │
│   └── types/
│       ├── block.go                 # 区块数据结构
│       ├── transaction.go           # 交易数据结构
│       ├── utxo.go                  # UTXO 数据结构
│       ├── address.go               # 地址相关结构
│       ├── jsonrpc.go               # JSON-RPC 请求/响应结构
│       └── errors.go                # 业务错误定义
│
├── migrations/
│   └── postgres/
│       ├── 001_create_blocks.sql
│       ├── 002_create_transactions.sql
│       ├── 003_create_address_transactions.sql
│       ├── 004_create_utxo_states.sql
│       ├── 005_create_address_balances.sql
│       ├── 006_create_stake_records.sql
│       ├── 007_create_delegate_records.sql
│       ├── 008_create_contracts.sql
│       ├── 009_create_contract_events.sql
│       ├── 010_create_asset_types.sql
│       ├── 011_create_vote_records.sql
│       └── 012_create_sync_status.sql
│
├── config/
│   ├── config.yaml                  # 默认配置
│   └── config.example.yaml          # 配置示例
│
├── Dockerfile
├── docker-compose.yaml
├── go.mod
├── go.sum
├── Makefile
└── README.md
```

### 3.2 依赖方向约束

**必须遵守的依赖方向**（上层可以依赖下层，下层不能依赖上层）：

```
cmd/rpcd → internal/*
internal/server → internal/handler
internal/handler → internal/query, internal/proxy
internal/query → internal/store, internal/cache, internal/proxy
internal/indexer → internal/parser, internal/store
internal/parser → internal/types
internal/store → internal/types
internal/cache → internal/types
internal/proxy → internal/config
internal/types → (无外部依赖)
```

---

## 4. 开发阶段与任务分解

### 4.1 开发阶段概览

| 阶段 | 任务 | 预计文件数 | 依赖 |
|------|------|-----------|------|
| **阶段一** | 基础框架搭建 | 10 | 无 |
| **阶段二** | 数据模型与存储层 | 15 | 阶段一 |
| **阶段三** | Indexer 数据同步引擎 | 8 | 阶段二 |
| **阶段四** | JSON-RPC 接口实现 | 8 | 阶段二、三 |
| **阶段五** | REST 增强 API 实现 | 5 | 阶段二、三 |
| **阶段六** | 缓存与 Fallback | 6 | 阶段四、五 |
| **阶段七** | 测试与部署 | 10 | 全部 |

### 4.2 开发顺序

**必须按以下顺序开发**，每个阶段完成后才能进入下一阶段：

```
阶段一 → 阶段二 → 阶段三 → 阶段四 → 阶段五 → 阶段六 → 阶段七
```

---

## 5. 阶段一：基础框架搭建

### 5.1 任务清单

- [ ] 创建项目目录结构
- [ ] 初始化 go.mod
- [ ] 实现配置管理（config/config.go）
- [ ] 实现数据类型定义（types/*）
- [ ] 实现 HTTP Server 框架（server/server.go）
- [ ] 实现中间件（server/middleware.go）
- [ ] 实现 JSON-RPC 分发器（server/jsonrpc.go）
- [ ] 实现程序入口（cmd/rpcd/main.go）
- [ ] 创建 Makefile
- [ ] 创建配置文件（config/config.yaml）

### 5.2 配置管理实现要求

**文件**: `internal/config/config.go`

```go
package config

import (
    "time"
    "github.com/spf13/viper"
)

// Config 是全局配置结构
type Config struct {
    Server   ServerConfig   `mapstructure:"server"`
    Chain    ChainConfig    `mapstructure:"chain"`
    Indexer  IndexerConfig  `mapstructure:"indexer"`
    Postgres PostgresConfig `mapstructure:"postgres"`
    Redis    RedisConfig    `mapstructure:"redis"`
    Cache    CacheConfig    `mapstructure:"cache"`
    Proxy    ProxyConfig    `mapstructure:"proxy"`
    Log      LogConfig      `mapstructure:"log"`
    Metrics  MetricsConfig  `mapstructure:"metrics"`
    Tracing  TracingConfig  `mapstructure:"tracing"`
}

type ServerConfig struct {
    ListenAddr      string        `mapstructure:"listen_addr"`
    ReadTimeout     time.Duration `mapstructure:"read_timeout"`
    WriteTimeout    time.Duration `mapstructure:"write_timeout"`
    ShutdownTimeout time.Duration `mapstructure:"shutdown_timeout"`
}

type ChainConfig struct {
    Nodes              []ChainNode   `mapstructure:"nodes"`
    CallbackListenAddr string        `mapstructure:"callback_listen_addr"`
    ConnectTimeout     time.Duration `mapstructure:"connect_timeout"`
    ReadTimeout        time.Duration `mapstructure:"read_timeout"`
}

type ChainNode struct {
    URL    string `mapstructure:"url"`
    Weight int    `mapstructure:"weight"`
}

type IndexerConfig struct {
    PollInterval    time.Duration `mapstructure:"poll_interval"`
    SyncFromGenesis bool          `mapstructure:"sync_from_genesis"`
    BatchSize       int           `mapstructure:"batch_size"`
    CallbackTimeout time.Duration `mapstructure:"callback_timeout"`
    Enabled         bool          `mapstructure:"enabled"` // 是否启用 Indexer（多实例部署时只有一个启用）
}

type PostgresConfig struct {
    DSN             string        `mapstructure:"dsn"`
    MaxConns        int32         `mapstructure:"max_conns"`
    MinConns        int32         `mapstructure:"min_conns"`
    MaxConnLifetime time.Duration `mapstructure:"max_conn_lifetime"`
    MaxConnIdleTime time.Duration `mapstructure:"max_conn_idle_time"`
    StatementTimeout time.Duration `mapstructure:"statement_timeout"`
}

type RedisConfig struct {
    URL        string `mapstructure:"url"`
    Password   string `mapstructure:"password"`
    DB         int    `mapstructure:"db"`
    PoolSize   int    `mapstructure:"pool_size"`
    MaxRetries int    `mapstructure:"max_retries"`
}

type CacheConfig struct {
    HotTTL  time.Duration `mapstructure:"hot_ttl"`
    WarmTTL time.Duration `mapstructure:"warm_ttl"`
    ColdTTL time.Duration `mapstructure:"cold_ttl"`
    NullTTL time.Duration `mapstructure:"null_ttl"`
}

type ProxyConfig struct {
    Timeout  time.Duration `mapstructure:"timeout"`
    Balancer string        `mapstructure:"balancer"` // round_robin | least_conn
}

type LogConfig struct {
    Level  string `mapstructure:"level"`  // debug | info | warn | error
    Format string `mapstructure:"format"` // json | text
}

type MetricsConfig struct {
    Enabled bool   `mapstructure:"enabled"`
    Path    string `mapstructure:"path"`
}

type TracingConfig struct {
    Enabled    bool    `mapstructure:"enabled"`
    Endpoint   string  `mapstructure:"endpoint"`
    SampleRate float64 `mapstructure:"sample_rate"`
}

// Load 加载配置
func Load(configPath string) (*Config, error) {
    v := viper.New()
    
    // 设置默认值
    setDefaults(v)
    
    // 读取配置文件
    v.SetConfigFile(configPath)
    if err := v.ReadInConfig(); err != nil {
        return nil, err
    }
    
    // 环境变量覆盖
    v.SetEnvPrefix("RPCD")
    v.AutomaticEnv()
    
    var cfg Config
    if err := v.Unmarshal(&cfg); err != nil {
        return nil, err
    }
    
    return &cfg, nil
}

func setDefaults(v *viper.Viper) {
    v.SetDefault("server.listen_addr", ":8080")
    v.SetDefault("server.read_timeout", 30*time.Second)
    v.SetDefault("server.write_timeout", 30*time.Second)
    v.SetDefault("server.shutdown_timeout", 10*time.Second)
    
    v.SetDefault("chain.connect_timeout", 5*time.Second)
    v.SetDefault("chain.read_timeout", 30*time.Second)
    
    v.SetDefault("indexer.poll_interval", 30*time.Second)
    v.SetDefault("indexer.batch_size", 100)
    v.SetDefault("indexer.callback_timeout", 60*time.Second)
    v.SetDefault("indexer.enabled", true)
    
    v.SetDefault("postgres.max_conns", 100)
    v.SetDefault("postgres.min_conns", 10)
    v.SetDefault("postgres.max_conn_lifetime", 30*time.Minute)
    v.SetDefault("postgres.max_conn_idle_time", 5*time.Minute)
    v.SetDefault("postgres.statement_timeout", 5*time.Second)
    
    v.SetDefault("redis.pool_size", 50)
    v.SetDefault("redis.max_retries", 3)
    
    v.SetDefault("cache.hot_ttl", 10*time.Second)
    v.SetDefault("cache.warm_ttl", 5*time.Minute)
    v.SetDefault("cache.cold_ttl", 1*time.Hour)
    v.SetDefault("cache.null_ttl", 30*time.Second)
    
    v.SetDefault("proxy.timeout", 30*time.Second)
    v.SetDefault("proxy.balancer", "round_robin")
    
    v.SetDefault("log.level", "info")
    v.SetDefault("log.format", "json")
    
    v.SetDefault("metrics.enabled", true)
    v.SetDefault("metrics.path", "/metrics")
    
    v.SetDefault("tracing.sample_rate", 0.1)
}
```

### 5.3 数据类型定义要求

**文件**: `internal/types/jsonrpc.go`

```go
package types

import "encoding/json"

// JSONRPCRequest JSON-RPC 2.0 请求
type JSONRPCRequest struct {
    JSONRPC string          `json:"jsonrpc"`
    Method  string          `json:"method"`
    Params  json.RawMessage `json:"params"`
    ID      any             `json:"id"`
}

// JSONRPCResponse JSON-RPC 2.0 成功响应
type JSONRPCResponse struct {
    JSONRPC string `json:"jsonrpc"`
    ID      any    `json:"id"`
    Result  any    `json:"result"`
}

// JSONRPCError JSON-RPC 2.0 错误响应
type JSONRPCError struct {
    JSONRPC string        `json:"jsonrpc"`
    ID      any           `json:"id"`
    Error   RPCError      `json:"error"`
}

type RPCError struct {
    Code    int    `json:"code"`
    Message string `json:"message"`
}
```

**文件**: `internal/types/errors.go`

```go
package types

import "errors"

// 业务错误定义
var (
    ErrBlockNotFound   = errors.New("block not found")
    ErrTxNotFound      = errors.New("transaction not found")
    ErrInvalidAddress  = errors.New("invalid address format")
    ErrChainNodeDown   = errors.New("chain node unreachable")
    ErrSyncLagTooLarge = errors.New("sync lag exceeds threshold")
    ErrQueryRangeExceeded = errors.New("query range exceeded")
)

// 错误码映射
const (
    CodeParseError       = -32700
    CodeInvalidRequest   = -32600
    CodeMethodNotFound   = -32601
    CodeInvalidParams    = -32602
    CodeInternalError    = -32603
    CodeDataNotFound     = -32001
    CodeInvalidAddress   = -32002
    CodeServiceUnavail   = -32003
    CodeRateLimitExceed  = -32004
    CodeQueryRangeExceed = -32005
    CodeSyncLagLarge     = -32006
    CodeChainNodeError   = -32007
)
```

**文件**: `internal/types/block.go`

```go
package types

// Block 区块数据
type Block struct {
    BlockHash  string `json:"hash"`
    Height     int64  `json:"height"`
    PrevHash   string `json:"prevhash"`
    MerkleRoot string `json:"merkleroot"`
    Timestamp  int64  `json:"time"` // 微秒级
    TxCount    int    `json:"tx_count"`
    Version    int    `json:"version"`
    Txs        []Transaction `json:"txs"`
}
```

**文件**: `internal/types/transaction.go`

```go
package types

// Transaction 交易数据
type Transaction struct {
    Hash        string    `json:"hash"`
    BlockHash   string    `json:"block_hash"`
    BlockHeight int64     `json:"height"`
    TxIndex     int       `json:"tx_index"`
    Type        string    `json:"type"` // TX, STAKE, DELEGATE, CALL, etc.
    Sender      string    `json:"identity"`
    Timestamp   int64     `json:"time"` // 微秒级
    Gas         int64     `json:"gas"`
    Nonce       uint64    `json:"nonce"`
    UTXOs       []UTXOGroup `json:"utxos"`
    RawData     string    `json:"data"` // 原始 JSON
}

// UTXOGroup UTXO 组
type UTXOGroup struct {
    Owner     []string `json:"owner"`
    Vin       []Input  `json:"vin"`
    Vout      []Output `json:"vout"`
    AssetType string   `json:"assettype"`
    Gas       int64    `json:"gas"`
}

type Input struct {
    PrevOut PrevOutput `json:"prevOut"`
}

type Output struct {
    Value int64  `json:"value"`
    Addr  string `json:"addr"`
}

type PrevOutput struct {
    Hash string `json:"hash"`
    N    int    `json:"n"`
}
```

### 5.4 HTTP Server 实现要求

**文件**: `internal/server/server.go`

必须实现：
1. 路由注册：`POST /rpc` → JSON-RPC 分发器
2. 路由注册：`GET/POST /api/v1/*` → REST 处理器（阶段五实现）
3. 路由注册：`GET /health` → 健康检查
4. 路由注册：`GET /metrics` → Prometheus 指标（如果启用）
5. 优雅关闭：监听 SIGINT/SIGTERM，等待现有请求完成

```go
// Server HTTP 服务器
type Server struct {
    cfg        *config.Config
    httpServer *http.Server
    jsonrpc    *JSONRPCDispatcher
    rest       *RESTHandler      // 阶段五实现
    proxy      *proxy.Proxy
    query      *query.Router
}

func NewServer(cfg *config.Config, ...) *Server { ... }

func (s *Server) Start() error {
    // 注册路由
    s.registerRoutes()
    
    // 启动 HTTP 服务器
    go func() {
        if err := s.httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
            log.Error("server error", "error", err)
        }
    }()
    
    return nil
}

func (s *Server) Stop(ctx context.Context) error {
    return s.httpServer.Shutdown(ctx)
}

func (s *Server) registerRoutes() {
    router := gin.New()
    
    // 中间件
    router.Use(s.recoveryMiddleware())
    router.Use(s.loggingMiddleware())
    router.Use(s.metricsMiddleware())
    router.Use(s.corsMiddleware())
    router.Use(s.responseHeaderMiddleware())
    
    // 路由
    router.POST("/rpc", s.jsonrpc.Dispatch)
    router.GET("/health", s.healthHandler)
    
    if s.cfg.Metrics.Enabled {
        router.GET(s.cfg.Metrics.Path, gin.WrapH(promhttp.Handler()))
    }
    
    // REST 路由在阶段五添加
    // s.rest.RegisterRoutes(router.Group("/api/v1"))
    
    s.handler = router
}
```

### 5.5 JSON-RPC 分发器实现要求

**文件**: `internal/server/jsonrpc.go`

必须实现：
1. 解析 JSON-RPC 2.0 请求
2. 根据 method 字段判断是写操作还是查询操作
3. 写操作 → 转发到 Proxy
4. 查询操作 → 转发到 JSONRPCHandler

```go
// 写操作方法集合
var writeMethods = map[string]bool{
    "CreateTransaction":               true,
    "CreateStakingTransaction":        true,
    "CreateUnstakingTransaction":      true,
    "CreateDelegatingTransaction":     true,
    "CreateUndelegatingTransaction":   true,
    "CreateBonusTransaction":          true,
    "CreateCallContractTransaction":   true,
    "CreateDeployContractTransaction": true,
    "SendMessage":                     true,
    "SendContractMessage":             true,
    "CreateLockTransaction":           true,
    "CreateUnLockTransaction":         true,
    "CreateVoteTransaction":           true,
    "CreateFundTransaction":           true,
    "eth_sendRawTransaction":          true,
}

func (d *JSONRPCDispatcher) Dispatch(c *gin.Context) {
    var req types.JSONRPCRequest
    if err := c.ShouldBindJSON(&req); err != nil {
        c.JSON(200, types.JSONRPCError{
            JSONRPC: "2.0",
            ID:      nil,
            Error:   types.RPCError{Code: types.CodeParseError, Message: "Parse error"},
        })
        return
    }
    
    // 验证 JSON-RPC 版本
    if req.JSONRPC != "2.0" {
        c.JSON(200, types.JSONRPCError{
            JSONRPC: "2.0",
            ID:      req.ID,
            Error:   types.RPCError{Code: types.CodeInvalidRequest, Message: "Invalid JSON-RPC version"},
        })
        return
    }
    
    // 路由分发
    if writeMethods[req.Method] {
        // 写操作 → 透传到链节点
        d.proxyHandler.Handle(c, &req)
    } else {
        // 查询操作 → 本地处理
        d.queryHandler.Handle(c, &req)
    }
}
```

### 5.6 阶段一验收标准

- [ ] `go build ./cmd/rpcd` 编译成功
- [ ] `./bin/rpcd --config config/config.yaml` 启动成功
- [ ] `curl http://localhost:8080/health` 返回 200
- [ ] `curl -X POST http://localhost:8080/rpc -d '{"jsonrpc":"2.0","method":"unknown","params":[],"id":1}'` 返回 Method not found 错误
- [ ] 日志输出格式正确（JSON 格式）
- [ ] Prometheus 指标端点可访问（`/metrics`）

---

## 6. 阶段二：数据模型与存储层

### 6.1 任务清单

- [ ] 创建数据库迁移脚本（migrations/postgres/*.sql）
- [ ] 实现 Store 接口（store/store.go）
- [ ] 实现 PostgreSQL 连接池（store/postgres.go）
- [ ] 实现各表的 CRUD 操作（store/*_store.go）

### 6.2 数据库迁移脚本

**必须严格按照架构设计文档中的表结构创建**。以下是关键表的迁移脚本示例：

**文件**: `migrations/postgres/001_create_blocks.sql`

```sql
-- 向上迁移
CREATE TABLE IF NOT EXISTS blocks (
    block_hash      VARCHAR(64) PRIMARY KEY,
    height          BIGINT NOT NULL,
    prev_hash       VARCHAR(64),
    merkle_root     VARCHAR(64),
    timestamp       BIGINT NOT NULL,
    tx_count        INT NOT NULL DEFAULT 0,
    packager        VARCHAR(64),
    version         INT,
    size_bytes      INT,
    created_at      TIMESTAMP DEFAULT NOW(),
    
    CONSTRAINT uq_block_height UNIQUE (height)
);

CREATE INDEX IF NOT EXISTS idx_blocks_height ON blocks(height DESC);
CREATE INDEX IF NOT EXISTS idx_blocks_timestamp ON blocks(timestamp DESC);
```

**所有 12 个迁移文件必须创建**，对应架构设计文档中的 11 张业务表 + 1 张同步状态表。

### 6.3 Store 接口定义

**文件**: `internal/store/store.go`

```go
package store

import (
    "context"
    "openhive-rpcd/internal/types"
)

// Store 数据存储接口
type Store interface {
    // 生命周期
    Close() error
    
    // 区块
    InsertBlock(ctx context.Context, block *types.Block) error
    GetBlockByHash(ctx context.Context, hash string) (*types.Block, error)
    GetBlockByHeight(ctx context.Context, height int64) (*types.Block, error)
    GetBlocksByHeightRange(ctx context.Context, start, end int64) ([]*types.Block, error)
    DeleteBlocksAboveHeight(ctx context.Context, height int64) error
    
    // 交易
    InsertTransaction(ctx context.Context, tx *types.Transaction) error
    GetTransactionByHash(ctx context.Context, hash string) (*types.Transaction, error)
    GetTransactionsByBlockHeight(ctx context.Context, height int64, page, pageSize int) ([]*types.Transaction, int, error)
    DeleteTransactionsAboveHeight(ctx context.Context, height int64) error
    
    // 地址交易索引
    InsertAddressTransactions(ctx context.Context, ats []*types.AddressTransaction) error
    GetAddressTransactions(ctx context.Context, addr string, page, pageSize int, filters ...AddressTxFilter) ([]*types.AddressTransaction, int, error)
    DeleteAddressTransactionsAboveHeight(ctx context.Context, height int64) error
    
    // UTXO
    InsertUTXO(ctx context.Context, utxo *types.UTXOState) error
    SpendUTXO(ctx context.Context, utxoHash string, utxoIndex int, spendTxHash string, spendHeight int64) error
    GetUTXOsByAddress(ctx context.Context, addr string, status string, utxoType string) ([]*types.UTXOState, error)
    RestoreUTXOsAboveHeight(ctx context.Context, height int64) error
    DeleteUTXOsCreatedAboveHeight(ctx context.Context, height int64) error
    
    // 余额
    UpdateBalance(ctx context.Context, addr, assetType string, delta int64, height int64) error
    GetBalance(ctx context.Context, addr, assetType string) (*types.AddressBalance, error)
    
    // 质押
    InsertStakeRecord(ctx context.Context, record *types.StakeRecord) error
    UpdateStakeRecord(ctx context.Context, stakerAddr, utxoHash string, status string, unstakeHeight int64) error
    GetStakeRecords(ctx context.Context, addr string, status string) ([]*types.StakeRecord, error)
    DeleteStakeRecordsAboveHeight(ctx context.Context, height int64) error
    
    // 委托
    InsertDelegateRecord(ctx context.Context, record *types.DelegateRecord) error
    UpdateDelegateRecord(ctx context.Context, fromAddr, toAddr, utxoHash string, status string, undelegateHeight int64) error
    GetDelegateRecords(ctx context.Context, addr string, role string, status string) ([]*types.DelegateRecord, error)
    DeleteDelegateRecordsAboveHeight(ctx context.Context, height int64) error
    
    // 合约
    InsertContract(ctx context.Context, contract *types.Contract) error
    GetContract(ctx context.Context, addr string) (*types.Contract, error)
    
    // 同步状态
    GetSyncedHeight(ctx context.Context) (int64, error)
    UpdateSyncedHeight(ctx context.Context, height int64) error
    
    // 回滚（事务）
    RollbackToHeight(ctx context.Context, height int64) error
}

// AddressTxFilter 地址交易过滤条件
type AddressTxFilter struct {
    TxType    string
    Direction string
    AssetType string
    StartHeight int64
    EndHeight   int64
}
```

### 6.4 PostgreSQL 实现要求

**文件**: `internal/store/postgres.go`

必须使用 pgx 连接池：

```go
package store

import (
    "context"
    "github.com/jackc/pgx/v5/pgxpool"
    "openhive-rpcd/internal/config"
)

type PostgresStore struct {
    pool *pgxpool.Pool
    cfg  *config.PostgresConfig
}

func NewPostgresStore(ctx context.Context, cfg *config.PostgresConfig) (*PostgresStore, error) {
    poolConfig, err := pgxpool.ParseConfig(cfg.DSN)
    if err != nil {
        return nil, err
    }
    
    poolConfig.MaxConns = cfg.MaxConns
    poolConfig.MinConns = cfg.MinConns
    poolConfig.MaxConnLifetime = cfg.MaxConnLifetime
    poolConfig.MaxConnIdleTime = cfg.MaxConnIdleTime
    
    pool, err := pgxpool.NewWithConfig(ctx, poolConfig)
    if err != nil {
        return nil, err
    }
    
    // 测试连接
    if err := pool.Ping(ctx); err != nil {
        return nil, err
    }
    
    // 设置 statement_timeout
    _, err = pool.Exec(ctx, fmt.Sprintf("SET statement_timeout = '%dms'", cfg.StatementTimeout.Milliseconds()))
    if err != nil {
        return nil, err
    }
    
    return &PostgresStore{pool: pool, cfg: cfg}, nil
}

func (s *PostgresStore) Close() error {
    s.pool.Close()
    return nil
}
```

### 6.5 回滚操作实现要求

**文件**: `internal/store/postgres.go` 中的 `RollbackToHeight` 方法

```go
func (s *PostgresStore) RollbackToHeight(ctx context.Context, height int64) error {
    // 必须在单个事务中完成所有回滚操作
    tx, err := s.pool.Begin(ctx)
    if err != nil {
        return err
    }
    defer tx.Rollback(ctx)
    
    // 1. 恢复被消费的 UTXO
    _, err = tx.Exec(ctx, `
        UPDATE utxo_states 
        SET status = 'unspent', spend_tx_hash = NULL, spend_height = NULL
        WHERE spend_height >= $1
    `, height)
    if err != nil { return err }
    
    // 2. 删除新产生的 UTXO
    _, err = tx.Exec(ctx, `DELETE FROM utxo_states WHERE create_height >= $1`, height)
    if err != nil { return err }
    
    // 3. 删除地址交易索引
    _, err = tx.Exec(ctx, `DELETE FROM address_transactions WHERE block_height >= $1`, height)
    if err != nil { return err }
    
    // 4. 删除交易
    _, err = tx.Exec(ctx, `DELETE FROM transactions WHERE block_height >= $1`, height)
    if err != nil { return err }
    
    // 5. 删除区块
    _, err = tx.Exec(ctx, `DELETE FROM blocks WHERE height >= $1`, height)
    if err != nil { return err }
    
    // 6. 删除质押/委托/投票记录
    _, err = tx.Exec(ctx, `DELETE FROM stake_records WHERE stake_height >= $1`, height)
    if err != nil { return err }
    _, err = tx.Exec(ctx, `DELETE FROM delegate_records WHERE delegate_height >= $1`, height)
    if err != nil { return err }
    _, err = tx.Exec(ctx, `DELETE FROM vote_records WHERE vote_height >= $1`, height)
    if err != nil { return err }
    
    // 7. 更新同步状态
    _, err = tx.Exec(ctx, `UPDATE sync_status SET synced_height = $1 WHERE id = 1`, height-1)
    if err != nil { return err }
    
    return tx.Commit(ctx)
}
```

### 6.6 阶段二验收标准

- [ ] 所有迁移脚本可正确执行（`make migrate-up`）
- [ ] 所有迁移脚本可正确回退（`make migrate-down`）
- [ ] Store 接口所有方法有单元测试
- [ ] 回滚操作测试：插入数据 → 回滚 → 验证数据已删除
- [ ] 连接池配置正确，并发查询测试通过

---

## 7. 阶段三：Indexer 数据同步引擎

### 7.1 任务清单

- [ ] 实现 Parser 解析器（parser/*.go）
- [ ] 实现 Indexer 主循环（indexer/indexer.go）
- [ ] 实现回调接收器（indexer/callback.go）
- [ ] 实现扫块追赶器（indexer/poller.go）
- [ ] 实现回滚处理器（indexer/rollback.go）

### 7.2 Parser 实现要求

**文件**: `internal/parser/parser.go`

```go
package parser

import (
    "openhive-rpcd/internal/types"
)

// ParseResult 解析结果
type ParseResult struct {
    Block            *types.Block
    Transactions     []*types.Transaction
    AddressTxs       []*types.AddressTransaction
    UTXOCreates      []*types.UTXOState
    UTXOSpends       []UTXOSpend // utxo_hash, utxo_index, spend_tx_hash
    BalanceUpdates   []BalanceUpdate
    StakeRecords     []*types.StakeRecord
    DelegateRecords  []*types.DelegateRecord
    Contracts        []*types.Contract
}

type UTXOSpend struct {
    UTXOHash    string
    UTXOIndex   int
    SpendTxHash string
}

type BalanceUpdate struct {
    Address   string
    AssetType string
    Delta     int64 // 正数增加，负数减少
}

// ParseBlock 解析区块
func ParseBlock(block *types.Block) *ParseResult {
    result := &ParseResult{
        Block: block,
    }
    
    for i, tx := range block.Txs {
        tx.BlockHash = block.BlockHash
        tx.BlockHeight = block.Height
        tx.TxIndex = i
        
        result.Transactions = append(result.Transactions, &tx)
        
        // 根据交易类型解析
        switch tx.Type {
        case "TX":
            parseTransferTx(&tx, result)
        case "STAKE":
            parseStakeTx(&tx, result)
        case "UNSTAKE":
            parseUnstakeTx(&tx, result)
        case "DELEGATE":
            parseDelegateTx(&tx, result)
        case "UNDELEGATE":
            parseUndelegateTx(&tx, result)
        case "DEPLOY":
            parseDeployTx(&tx, result)
        case "CALL":
            parseCallTx(&tx, result)
        case "LOCK":
            parseLockTx(&tx, result)
        case "UNLOCK":
            parseUnlockTx(&tx, result)
        case "VOTE":
            parseVoteTx(&tx, result)
        }
    }
    
    return result
}
```

**文件**: `internal/parser/tx_parser.go`

```go
// parseTransferTx 解析普通转账交易
func parseTransferTx(tx *types.Transaction, result *ParseResult) {
    for _, utxoGroup := range tx.UTXOs {
        // 解析输入（消费 UTXO）
        for _, vin := range utxoGroup.Vin {
            result.UTXOSpends = append(result.UTXOSpends, UTXOSpend{
                UTXOHash:    vin.PrevOut.Hash,
                UTXOIndex:   vin.PrevOut.N,
                SpendTxHash: tx.Hash,
            })
            
            // 记录输出方向的地址交易（out）
            // 注意：需要从之前的 UTXO 状态中获取 owner 地址
            // 这里简化处理，实际需要从 store 查询
        }
        
        // 解析输出（产生新 UTXO）
        for i, vout := range utxoGroup.Vout {
            result.UTXOCreates = append(result.UTXOCreates, &types.UTXOState{
                UTXOHash:     tx.Hash, // 简化，实际应该是计算出来的
                UTXOIndex:    i,
                OwnerAddress: vout.Addr,
                AssetType:    utxoGroup.AssetType,
                Value:        vout.Value,
                Status:       "unspent",
                CreateHeight: tx.BlockHeight,
                UTXOType:     "normal",
            })
            
            // 记录地址交易（in）
            result.AddressTxs = append(result.AddressTxs, &types.AddressTransaction{
                Address:     vout.Addr,
                TxHash:      tx.Hash,
                BlockHeight: tx.BlockHeight,
                TxIndex:     tx.TxIndex,
                TxType:      tx.Type,
                AssetType:   utxoGroup.AssetType,
                Value:       vout.Value,
                Direction:   "in",
                Timestamp:   tx.Timestamp,
            })
            
            // 更新余额
            result.BalanceUpdates = append(result.BalanceUpdates, BalanceUpdate{
                Address:   vout.Addr,
                AssetType: utxoGroup.AssetType,
                Delta:     vout.Value,
            })
        }
    }
}

// parseStakeTx 解析质押交易
func parseStakeTx(tx *types.Transaction, result *ParseResult) {
    // 类似 parseTransferTx，但 UTXOType 设为 "stake"
    // 并创建 StakeRecord
}

// parseDelegateTx 解析委托交易
func parseDelegateTx(tx *types.Transaction, result *ParseResult) {
    // 创建 DelegateRecord
}

// ... 其他交易类型解析函数
```

### 7.3 Indexer 主循环实现要求

**文件**: `internal/indexer/indexer.go`

```go
package indexer

import (
    "context"
    "log/slog"
    "time"
    "openhive-rpcd/internal/config"
    "openhive-rpcd/internal/store"
    "openhive-rpcd/internal/parser"
    "openhive-rpcd/internal/proxy"
)

type Indexer struct {
    cfg      *config.IndexerConfig
    store    store.Store
    proxy    *proxy.Proxy
    callback *CallbackReceiver
    poller   *BlockPoller
    rollback *RollbackHandler
    
    syncedHeight int64
    chainHeight  int64
}

func NewIndexer(cfg *config.IndexerConfig, store store.Store, proxy *proxy.Proxy) *Indexer {
    return &Indexer{
        cfg:   cfg,
        store: store,
        proxy: proxy,
    }
}

func (idx *Indexer) Run(ctx context.Context) error {
    // 1. 读取同步状态
    syncedHeight, err := idx.store.GetSyncedHeight(ctx)
    if err != nil {
        return err
    }
    idx.syncedHeight = syncedHeight
    
    // 2. 启动时全量追赶
    if err := idx.catchUp(ctx); err != nil {
        return err
    }
    
    // 3. 启动回调接收器
    idx.callback = NewCallbackReceiver(idx.cfg, idx)
    go idx.callback.Run(ctx)
    
    // 4. 启动扫块追赶器
    idx.poller = NewBlockPoller(idx.cfg, idx)
    go idx.poller.Run(ctx)
    
    // 5. 主循环：监控同步状态
    ticker := time.NewTicker(10 * time.Second)
    defer ticker.Stop()
    
    for {
        select {
        case <-ctx.Done():
            return ctx.Err()
        case <-ticker.C:
            idx.reportSyncStatus()
        }
    }
}

// catchUp 启动时追赶
func (idx *Indexer) catchUp(ctx context.Context) error {
    chainHeight, err := idx.fetchChainHeight(ctx)
    if err != nil {
        return err
    }
    idx.chainHeight = chainHeight
    
    if idx.syncedHeight >= chainHeight {
        return nil
    }
    
    slog.Info("catching up blocks",
        "from", idx.syncedHeight,
        "to", chainHeight,
        "gap", chainHeight-idx.syncedHeight)
    
    for h := idx.syncedHeight + 1; h <= chainHeight; h++ {
        if err := idx.syncBlock(ctx, h); err != nil {
            return err
        }
    }
    
    slog.Info("catch up complete", "synced_height", chainHeight)
    return nil
}

// syncBlock 同步单个区块
func (idx *Indexer) syncBlock(ctx context.Context, height int64) error {
    // 1. 从链节点获取区块
    block, err := idx.proxy.GetBlockByHeight(ctx, height)
    if err != nil {
        return err
    }
    
    // 2. 解析区块
    result := parser.ParseBlock(block)
    
    // 3. 存储到数据库（使用事务）
    if err := idx.storeResult(ctx, result); err != nil {
        return err
    }
    
    // 4. 更新同步状态
    idx.syncedHeight = height
    if err := idx.store.UpdateSyncedHeight(ctx, height); err != nil {
        return err
    }
    
    slog.Info("block synced",
        "height", height,
        "hash", block.BlockHash,
        "tx_count", len(block.Txs))
    
    return nil
}

// OnNewBlock 回调接收器调用
func (idx *Indexer) OnNewBlock(ctx context.Context, height int64) error {
    // 检查是否有 gap
    if height > idx.syncedHeight+1 {
        slog.Warn("block gap detected",
            "expected", idx.syncedHeight+1,
            "received", height)
        // 补块
        for h := idx.syncedHeight + 1; h < height; h++ {
            if err := idx.syncBlock(ctx, h); err != nil {
                return err
            }
        }
    }
    
    return idx.syncBlock(ctx, height)
}

// OnRollback 回调接收器调用
func (idx *Indexer) OnRollback(ctx context.Context, rollbackHeight int64) error {
    slog.Warn("rollback detected", "height", rollbackHeight)
    
    // 执行回滚
    if err := idx.store.RollbackToHeight(ctx, rollbackHeight); err != nil {
        return err
    }
    
    idx.syncedHeight = rollbackHeight - 1
    
    // 触发追赶
    go idx.catchUp(ctx)
    
    return nil
}
```

### 7.4 阶段三验收标准

- [ ] Indexer 可从创世块全量同步
- [ ] Indexer 可接收回调并实时同步新区块
- [ ] Indexer 可检测并处理区块 gap
- [ ] Indexer 可处理回滚事件
- [ ] 同步后的数据与链节点一致（抽查验证）
- [ ] 同步延迟 < 2s（回调模式下）

---

## 8. 阶段四：JSON-RPC 接口实现

### 8.1 任务清单

- [ ] 实现 JSON-RPC Handler（handler/jsonrpc_handler.go）
- [ ] 实现 Proxy 透传模块（proxy/proxy.go, proxy/balancer.go）
- [ ] 实现 Query Router（query/router.go）
- [ ] 实现 Fallback 模块（query/fallback.go）
- [ ] 实现所有 JSON-RPC 查询方法（query/jsonrpc_queries.go）
- [ ] 实现所有 ETH 兼容查询方法（query/eth_queries.go）

### 8.2 JSON-RPC Handler 实现要求

**文件**: `internal/handler/jsonrpc_handler.go`

```go
package handler

import (
    "github.com/gin-gonic/gin"
    "openhive-rpcd/internal/query"
    "openhive-rpcd/internal/types"
)

type JSONRPCHandler struct {
    router *query.Router
}

func NewJSONRPCHandler(router *query.Router) *JSONRPCHandler {
    return &JSONRPCHandler{router: router}
}

func (h *JSONRPCHandler) Handle(c *gin.Context, req *types.JSONRPCRequest) {
    // 根据 method 分发到具体处理函数
    result, err := h.router.Query(c.Request.Context(), req.Method, req.Params)
    if err != nil {
        h.respondError(c, req.ID, err)
        return
    }
    
    c.JSON(200, types.JSONRPCResponse{
        JSONRPC: "2.0",
        ID:      req.ID,
        Result:  result,
    })
}

func (h *JSONRPCHandler) respondError(c *gin.Context, id any, err error) {
    code := types.CodeInternalError
    msg := err.Error()
    
    switch {
    case errors.Is(err, types.ErrBlockNotFound), errors.Is(err, types.ErrTxNotFound):
        code = types.CodeDataNotFound
    case errors.Is(err, types.ErrInvalidAddress):
        code = types.CodeInvalidParams
    case errors.Is(err, types.ErrChainNodeDown):
        code = types.CodeServiceUnavail
    case errors.Is(err, types.ErrQueryRangeExceeded):
        code = types.CodeQueryRangeExceed
    }
    
    c.JSON(200, types.JSONRPCError{
        JSONRPC: "2.0",
        ID:      id,
        Error:   types.RPCError{Code: code, Message: msg},
    })
}
```

### 8.3 Query Router 实现要求

**文件**: `internal/query/router.go`

```go
package query

import (
    "context"
    "encoding/json"
    "openhive-rpcd/internal/store"
    "openhive-rpcd/internal/cache"
    "openhive-rpcd/internal/proxy"
)

type Router struct {
    store    store.Store
    cache    cache.Cache
    fallback *Fallback
}

func (r *Router) Query(ctx context.Context, method string, params json.RawMessage) (any, error) {
    // 1. 查 Redis 缓存
    cacheKey := r.buildCacheKey(method, params)
    if cached, err := r.cache.Get(ctx, cacheKey); err == nil {
        return cached, nil
    }
    
    // 2. 查 PostgreSQL
    result, err := r.queryFromPG(ctx, method, params)
    if err != nil {
        return nil, err
    }
    if result != nil {
        // 回填缓存
        r.cache.Set(ctx, cacheKey, result, r.ttlFor(method))
        return result, nil
    }
    
    // 3. Fallback 到链节点
    result, err = r.fallback.QueryChainNode(ctx, method, params)
    if err != nil {
        return nil, err
    }
    
    // 异步回填
    go r.backfill(ctx, method, params, result)
    
    return result, nil
}

// queryFromPG 根据 method 查询 PG
func (r *Router) queryFromPG(ctx context.Context, method string, params json.RawMessage) (any, error) {
    switch method {
    case "GetBlockHeight":
        return r.queryGetBlockHeight(ctx)
    case "GetBalance":
        return r.queryGetBalance(ctx, params)
    case "GetBlockByHash":
        return r.queryGetBlockByHash(ctx, params)
    case "GetBlockByHeight":
        return r.queryGetBlockByHeight(ctx, params)
    case "GetTransactionByHash":
        return r.queryGetTransactionByHash(ctx, params)
    // ... 其他方法
    default:
        return nil, nil // 未知方法，交给 fallback
    }
}
```

### 8.4 阶段四验收标准

- [ ] 所有 27 个 JSON-RPC 查询方法可正确响应
- [ ] 写操作可正确透传到链节点
- [ ] 查询优先走 PG，cache miss 时走 Redis，都 miss 时 fallback 到链节点
- [ ] Fallback 结果可正确回填到 PG 和 Redis
- [ ] 错误码正确返回

---

## 9. 阶段五：REST 增强 API 实现

### 9.1 任务清单

- [ ] 实现 REST Handler（handler/rest_handler.go）
- [ ] 实现所有 REST 增强 API 端点

### 9.2 REST Handler 实现要求

**文件**: `internal/handler/rest_handler.go`

```go
package handler

import (
    "github.com/gin-gonic/gin"
    "openhive-rpcd/internal/query"
)

type RESTHandler struct {
    router *query.Router
}

func NewRESTHandler(router *query.Router) *RESTHandler {
    return &RESTHandler{router: router}
}

func (h *RESTHandler) RegisterRoutes(rg *gin.RouterGroup) {
    // 地址相关
    rg.GET("/address/:address/overview", h.getAddressOverview)
    rg.GET("/address/:address/transactions", h.getAddressTransactions)
    rg.GET("/address/:address/utxos", h.getAddressUTXOs)
    rg.GET("/address/:address/stakes", h.getAddressStakes)
    rg.GET("/address/:address/delegates", h.getAddressDelegates)
    rg.GET("/address/:address/locks", h.getAddressLocks)
    
    // 区块相关
    rg.GET("/blocks/latest", h.getLatestBlock)
    rg.GET("/blocks/:height", h.getBlockByHeight)
    rg.GET("/blocks/:height/transactions", h.getBlockTransactions)
    rg.GET("/blocks/range", h.getBlocksByRange)
    
    // 交易相关
    rg.GET("/transactions/:tx_hash", h.getTransaction)
    rg.GET("/transactions/:tx_hash/confirmations", h.getTransactionConfirmations)
    
    // 合约相关
    rg.GET("/contracts/:contract_address", h.getContract)
    rg.GET("/contracts/:contract_address/events", h.getContractEvents)
    
    // 治理相关
    rg.GET("/governance/proposals", h.getProposals)
    rg.GET("/governance/proposals/:proposal_hash", h.getProposalDetail)
    
    // 网络统计
    rg.GET("/network/stats", h.getNetworkStats)
    rg.GET("/network/nodes", h.getNetworkNodes)
    
    // 资产相关
    rg.GET("/assets", h.getAssets)
    rg.GET("/assets/:asset_hash", h.getAssetDetail)
    rg.GET("/assets/by-contract/:contract_address", h.getAssetByContract)
    
    // 系统状态
    rg.GET("/status/sync", h.getSyncStatus)
    rg.GET("/status/health", h.getHealthStatus)
}

// 实现每个 handler 方法...
```

### 9.3 阶段五验收标准

- [ ] 所有 23 个 REST 增强 API 端点可正确响应
- [ ] 分页参数正确解析和返回
- [ ] 过滤条件正确应用
- [ ] 响应格式符合接口文档

---

## 10. 阶段六：缓存与 Fallback

### 10.1 任务清单

- [ ] 实现 Cache 接口（cache/cache.go）
- [ ] 实现 Redis 缓存（cache/redis.go）
- [ ] 实现缓存 Key 管理（cache/keys.go）
- [ ] 实现 Fallback 模块（query/fallback.go）

### 10.2 Cache 实现要求

**文件**: `internal/cache/cache.go`

```go
package cache

import (
    "context"
    "time"
)

type Cache interface {
    Get(ctx context.Context, key string) (any, error)
    Set(ctx context.Context, key string, value any, ttl time.Duration) error
    Delete(ctx context.Context, key string) error
    Close() error
}
```

**文件**: `internal/cache/keys.go`

```go
package cache

import "fmt"

// 缓存 Key 定义
func BlockHashKey(blockHash string) string {
    return fmt.Sprintf("rpcd:block:hash:%s", blockHash)
}

func BlockHeightKey(height int64) string {
    return fmt.Sprintf("rpcd:block:height:%d", height)
}

func LatestBlockKey() string {
    return "rpcd:block:latest"
}

func TxKey(txHash string) string {
    return fmt.Sprintf("rpcd:tx:%s", txHash)
}

func BalanceKey(address, assetType string) string {
    return fmt.Sprintf("rpcd:balance:%s:%s", address, assetType)
}

func AddrTypeKey(address string) string {
    return fmt.Sprintf("rpcd:addr_type:%s", address)
}

func ChainIDKey() string {
    return "rpcd:chain:id"
}

func VersionKey() string {
    return "rpcd:chain:version"
}
```

### 10.3 阶段六验收标准

- [ ] Redis 连接正常
- [ ] 缓存命中时直接返回，不查 PG
- [ ] 缓存未命中时查 PG 并回填缓存
- [ ] 缓存 TTL 正确生效
- [ ] Fallback 到链节点正常工作
- [ ] Fallback 结果正确回填

---

## 11. 阶段七：测试与部署

### 11.1 任务清单

- [ ] 编写单元测试
- [ ] 编写集成测试
- [ ] 创建 Dockerfile
- [ ] 创建 docker-compose.yaml
- [ ] 创建 README.md

### 11.2 测试要求

**单元测试**：每个公共函数必须有单元测试

**集成测试**：使用 testcontainers-go 启动临时 PG 和 Redis

```go
//go:build integration

func TestFullFlowIntegration(t *testing.T) {
    // 1. 启动临时 PG 和 Redis
    // 2. 执行迁移
    // 3. 启动 rpcd
    // 4. 模拟链节点回调
    // 5. 验证数据同步
    // 6. 验证查询接口
}
```

### 11.3 Dockerfile 要求

**必须使用多阶段构建**：

```dockerfile
FROM golang:1.22-alpine AS builder
WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 GOOS=linux go build -ldflags="-s -w" -o /rpcd ./cmd/rpcd

FROM alpine:3.19
RUN apk add --no-cache ca-certificates tzdata
COPY --from=builder /rpcd /usr/local/bin/rpcd
COPY config/config.yaml /etc/rpcd/config.yaml
COPY migrations/ /etc/rpcd/migrations/
EXPOSE 8080 8081
ENTRYPOINT ["rpcd"]
CMD ["--config", "/etc/rpcd/config.yaml"]
```

### 11.4 阶段七验收标准

- [ ] 单元测试覆盖率 > 80%
- [ ] 集成测试全部通过
- [ ] Docker 镜像构建成功
- [ ] docker-compose up 可正常启动
- [ ] README.md 包含完整的启动说明

---

## 12. 代码规范与约束

### 12.1 必须遵守的规范

1. **错误处理**：所有错误必须显式处理，禁止使用 `panic`
2. **日志**：使用 `slog` 结构化日志，禁止使用 `fmt.Println`
3. **Context**：所有涉及 IO 的函数必须接受 `context.Context` 参数
4. **命名**：遵循 Go 命名规范（CamelCase）
5. **注释**：所有公共函数必须有注释
6. **测试**：所有公共函数必须有单元测试

### 12.2 禁止的行为

1. 禁止引入文档未提及的第三方依赖
2. 禁止使用 ORM
3. 禁止在 handler 层直接写 SQL
4. 禁止硬编码配置值
5. 禁止忽略错误（`_ = someFunc()`）

---

## 13. 验收标准

### 13.1 功能验收

- [ ] 所有 JSON-RPC 查询接口正常工作
- [ ] 所有写操作正确透传到链节点
- [ ] 所有 REST 增强 API 正常工作
- [ ] Indexer 可正确同步链上数据
- [ ] 回滚处理正确
- [ ] 缓存正常工作
- [ ] Fallback 正常工作

### 13.2 性能验收

- [ ] 标准查询 P95 < 50ms
- [ ] 增强查询 P95 < 200ms
- [ ] 单实例可支撑 5000 QPS
- [ ] 同步延迟 < 2s

### 13.3 稳定性验收

- [ ] 连续运行 7 天无内存泄漏
- [ ] 链节点短暂不可用时服务仍可查询
- [ ] PG/Redis 短暂不可用时服务可降级

---

## 附录：参考文档

开发过程中必须参考以下文档：

1. **架构设计文档**: `architecture-design.md`
2. **开发文档**: `development-guide.md`
3. **接口文档**: `api-reference.md`

所有实现细节以这三份文档为准，本文档是执行指导。

---

*文档版本: 1.0.0 | 最后更新: 2026-06-18*
