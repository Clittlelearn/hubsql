# ParamHandle 参数校验分析与处理方案

> **创建日期**: 2026-06-07  
> **涉及模块**: `rpc/param_handle.h` 和 `rpc/param_handle.cpp`  
> **状态**: 分析完成，待实现

---

## 目录

1. [问题背景](#1-问题背景)
2. [ParamHandle 架构分析](#2-paramhandle-架构分析)
3. [参数校验缺失问题详情](#3-参数校验缺失问题详情)
4. [校验规则定义](#4-校验规则定义)
5. [处理方案](#5-处理方案)
6. [实施计划](#6-实施计划)

---

## 1. 问题背景

### 1.1 问题描述

在代码审计中发现，`ParamHandle` 类的 `parse()` 方法存在大量**空函数实现**或**基础校验不足**的问题，导致 RPC 层参数校验缺失，存在以下安全风险：

- **地址、hash 等字符串参数未做长度和格式校验**
- **amount 参数未做范围检查，存在整数溢出风险**
- **未检查必要参数是否存在（空指针风险）**
- **存在注入攻击风险**

### 1.2 问题范围

涉及以下 ParamHandle 类：

| ParamHandle 类 | parse() 状态 | 风险等级 |
|---------------|-------------|---------|
| `GetAllStakeNodeListParam` | 空函数 | ⚠️ 中 |
| `GetYieldInfoParam` | 空函数 | ⚠️ 中 |
| `GetBonusInfoParam` | 空函数 | ⚠️ 中 |
| `GetBlockHeightParam` | 空函数 | ⚠️ 中 |
| `GetChainIdParam` | 空函数 | ⚠️ 中 |
| `GetAccountsParam` | 空函数 | ⚠️ 中 |
| `GetNodeListPararm` | 空函数 | ⚠️ 中 |
| `PostMessageParam` | 空函数 | ⚠️ 中 |
| `PostContractMessageParam` | 空函数 | ⚠️ 中 |
| `StakeParam` | 部分校验 | 🔴 高（amount 校验被注释） |
| `DelegatingParam` | 部分校验 | 🔴 高（缺少字段依赖） |
| `UndelegatingParam` | 部分校验 | 🔴 高（缺少 utxo_hash 校验） |
| `BonusParam` | 部分校验 | 🔴 高（缺少 first_choose 依赖） |
| `FundParam` | 基础校验 | 🔴 高（缺少完整校验） |
| `UnStakeTransParam` | 基础校验 | 🔴 高（缺少 stake_utxo_hash 校验） |
| `LockTransParam` | 基础校验 | 🔴 高（缺少 lock_amount 校验） |
| `UnLockParam` | 空函数 | 🔴 高（完全无校验） |
| `VoteParam` | 空函数 | 🔴 高（完全无校验） |
| `DeployParam` | 基础校验 | 🔴 高（缺少 contract_type 校验） |
| `CallParam` | 基础校验 | 🔴 高（缺少 args 校验） |
| `TransactionParam` | 未实现 | 🔴 高（完全无校验） |

---

## 2. ParamHandle 架构分析

### 2.1 类结构

`ParamHandle` 是 RPC 层的参数处理类，位于 `rpc/param_handle.h` 和 `rpc/param_handle.cpp`。

```cpp
namespace mmc {
    namespace rpc {
        class StakeParam : public ReqDataBase {
            std::string addr;
            std::string asset_type;
            std::string amount;
            // ...
        };
    }
}
```

### 2.2 职责定位

**ParamHandle `parse()` 的职责：RPC 层参数校验**

```
┌─────────────┐
│  RPC 请求   │
└──────┬──────┘
       │
       ▼
┌─────────────────────┐
│ ParamHandle::parse()│  ← 第一层校验：JSON 参数格式、类型、范围
└──────┬──────────────┘
       │
       ▼
┌─────────────────────┐
│ 交易类型::trans()   │  ← 第二层校验：区块链状态、UTXO 查询
└──────┬──────────────┘
       │
       ▼
┌─────────────────────┐
│   区块链处理        │
└─────────────────────┘
```

### 2.3 校验分层

| 层级 | 校验位置 | 校验内容 |
|-----|---------|---------|
| **第一层** | `ParamHandle::parse()` | JSON 参数格式、类型、范围、非空检查 |
| **第二层** | `Transaction::trans()` | 区块链状态、UTXO 查询、业务逻辑 |

---

## 3. 参数校验缺失问题详情

### 3.1 空函数实现类（无任何校验）

#### GetVersionParam
```cpp
expected<int> GetVersionParam::parse(const nlohmann::json &json) {
    return 0; // 空实现
}
```
- **风险**: 无参数需要校验，可接受

#### GetAllStakeNodeListParam
```cpp
expected<int> GetAllStakeNodeListParam::parse(const nlohmann::json &json) {
    return 0; // 空实现
}
```
- **风险**: 无参数需要校验，可接受

#### GetBonusInfoParam
```cpp
expected<int> GetBonusInfoParam::parse(const nlohmann::json &json) {
    return 0; // 空实现
}
```
- **风险**: 无参数需要校验，可接受

#### PostMessageParam
```cpp
expected<int> PostMessageParam::parse(const nlohmann::json &json) {
    return 0; // 空实现
}
```
- **风险**: ⚠️ `tx` 字段未做格式校验
- **建议**: 检查 tx 是否为空，长度限制

#### PostContractMessageParam
```cpp
expected<int> PostContractMessageParam::parse(const nlohmann::json &json) {
    return 0; // 空实现
}
```
- **风险**: ⚠️ `contract_msg` 和 `tx` 字段未做格式校验

### 3.2 基础校验类（仅基础 JSON 解析）

#### FundParam
```cpp
expected<int> FundParam::parse(const nlohmann::json &json) {
    auto ret = reflect::Deserialize(json, *this);
    if (!ret.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, ret.error.value());
    }
    
    if (!isValidAddress((addr))) {
        return PERROR(MEM::INVALID_ADDR, " addr:{}", addr);
    }
    
    return 0; // ❌ 缺少 encoded_info 非空检查
}
```
- **缺失校验**:
  - `encoded_info` 字段未做非空检查
  - 缺少字段完整性校验

#### UnStakeTransParam
```cpp
expected<int> UnStakeTransParam::parse(const nlohmann::json &json) {
    auto ret = reflect::Deserialize(json, *this);
    if (!ret.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, ret.error.value());
    }
    
    if (!isValidAddress((addr))) {
        return PERROR(MEM::INVALID_ADDR, " from_addr");
    }
    
    if (!Util::isValidAssetType((assert_type))) {
        return PERROR(MEM::INVALID_HASH, "asset_type");
    }
    
    if (!Util::isValidAssetType((stake_utxo_hash))) {
        return PERROR(MEM::INVALID_HASH, "stake_utxo_hash");
    }
    
    return 0; // ❌ stake_utxo_hash 格式校验不完整
}
```
- **缺失校验**:
  - `stake_utxo_hash` 应为 64 字符 hex，而非 asset_type 格式
  - `stake_utxo_hash` 非空检查

#### LockTransParam
```cpp
expected<int> LockTransParam::parse(const nlohmann::json &json) {
    auto ret = reflect::Deserialize(json, *this);
    if (!ret.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, ret.error.value());
    }
    
    if (!isValidAddress((lock_addr))) {
        return PERROR(MEM::INVALID_ADDR, " lock_addr");
    }
    
    return 0; // ❌ 缺少 lock_amount 范围和格式校验
}
```
- **缺失校验**:
  - `lock_amount` 应为正整数，范围检查
  - `lock_type` 合法值检查（0 或其他）

#### UnLockParam
```cpp
expected<int> UnLockParam::parse(const nlohmann::json &json) {
    auto re = reflect::Deserialize(json, *this);
    
    if (!re.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, re.error.value());
    }
    
    return 0; // ❌ 完全无校验
}
```
- **缺失校验**:
  - `lock_addr` 地址格式
  - `utxo_hash` 格式（64 字符 hex）
  - 必要字段非空检查

#### VoteParam
```cpp
expected<int> VoteParam::parse(const nlohmann::json &json) {
    auto re = reflect::Deserialize(json, *this);
    
    if (!re.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, re.error.value());
    }
    
    return 0; // ❌ 完全无校验
}
```
- **缺失校验**:
  - `addr` 地址格式
  - `vote_hash` 格式（64 字符 hex）
  - `vote_type` 合法值检查（0, 1）

### 3.3 部分校验类（有校验但不完整）

#### StakeParam
```cpp
expected<int> StakeParam::parse(const nlohmann::json &json) {
    auto ret = reflect::Deserialize(json, *this);
    if (!ret.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, ret.error.value());
    }
    
    // ... gas_asset 校验 ...
    
    if (!isValidAddress((addr))) {
        return PERROR(MEM::INVALID_ADDR, " addr");
    }
    
    if (!Util::isValidAssetType((asset_type))) {
        return PERROR(MEM::INVALID_HASH, "asset_type");
    }
    
    // ❌ amount 校验被注释
    // if(amount <=0){
    //     return PERROR(MEM::INVALID_ADDR,"amount:",amount);
    // }
    
    return 0;
}
```
- **缺失校验**:
  - `amount` 范围检查（> 0, ≤ uint64_max）
  - `amount` 格式检查（正整数字符串）

#### DelegatingParam
```cpp
expected<int> DelegatingParam::parse(const nlohmann::json &json) {
    auto ret = reflect::Deserialize(json, *this);
    if (!ret.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, ret.error.value());
    }
    
    // ... gas_asset 校验 ...
    
    if (!isValidAddress((from_addr))) {
        return PERROR(MEM::INVALID_ADDR, " from_addr");
    }
    
    if (!isValidAddress((to_addr))) {
        return PERROR(MEM::INVALID_ADDR, " to_addr");
    }
    
    if (!Util::isValidAssetType((asset_type))) {
        return PERROR(MEM::INVALID_HASH, "asset_type");
    }
    
    return 0; // ❌ 缺少 delegate_type 范围检查
}
```
- **缺失校验**:
  - `delegate_type` 合法值检查（0, -1）
  - `delegatinged_amount` 格式和范围检查

#### UndelegatingParam
```cpp
expected<int> UndelegatingParam::parse(const nlohmann::json &json) {
    auto ret = reflect::Deserialize(json, *this);
    if (!ret.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, ret.error.value());
    }
    
    // ... gas_asset 校验 ...
    
    if (!isValidAddress((from_addr))) {
        return PERROR(MEM::INVALID_ADDR, " from_addr");
    }
    
    if (!isValidAddress((to_addr))) {
        return PERROR(MEM::INVALID_ADDR, " to_addr");
    }
    
    if (!Util::isValidAssetType((asset_type))) {
        return PERROR(MEM::INVALID_HASH, "asset_type");
    }
    
    return 0; // ❌ 缺少 utxo_hash 格式校验
}
```
- **缺失校验**:
  - `utxo_hash` 格式（64 字符 hex）

#### BonusParam
```cpp
expected<int> BonusParam::parse(const nlohmann::json &json) {
    auto ret = reflect::Deserialize(json, *this);
    if (!ret.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, ret.error.value());
    }
    
    if(sponsor_gas){
        // ... gas_asset 校验 ...
    }
    
    if (!isValidAddress((addr))) {
        return PERROR(MEM::INVALID_ADDR, " from_addr");
    }
    
    if (!Util::isValidAssetType((asset_type))) {
        return PERROR(MEM::INVALID_HASH, "asset_type");
    }
    
    return 0; // ❌ 缺少 first_choose 字段依赖校验
}
```
- **缺失校验**:
  - `first_choose == true` 时：
    - `asset_type` 必须是 "Vote"
    - `sponsor_gas` 必须是 true

#### DeployParam
```cpp
expected<int> DeployParam::parse(const nlohmann::json &json) {
    auto ret = reflect::Deserialize(json, *this);
    if (!ret.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, ret.error.value());
    }
    
    // ... gas_asset 校验 ...
    
    if (!isValidAddress((addr))) {
        return PERROR(MEM::INVALID_ADDR, " addr");
    }
    
    return 0; // ❌ 缺少 contract_type 校验
}
```
- **缺失校验**:
  - `contract_type` 合法值检查（0 = EVM）
  - `contract` 字段非空检查

#### CallParam
```cpp
expected<int> CallParam::parse(const nlohmann::json &json) {
    auto re = reflect::Deserialize(json, *this);
    
    if (!re.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, re.error.value());
    }
    
    // ... gas_asset 校验 ...
    
    if (!isValidAddress((addr))) {
        return PERROR(MEM::INVALID_ADDR, " addr");
    }
    
    return 0; // ❌ 缺少 args 校验
}
```
- **缺失校验**:
  - `args` 字段非空检查
  - `deployer`, `deployutxo`, `contract_address` 地址格式

#### TransactionParam
- **状态**: 未实现 `parse()` 方法
- **缺失校验**:
  - `tx_table` 非空检查
  - `gas_asset` 格式校验

---

## 4. 校验规则定义

### 4.1 地址校验规则

```cpp
// 校验地址格式
bool isValidAddress(const std::string& address) {
    // 1. 长度检查：40 字符
    if (address.size() != 40) {
        return false;
    }
    
    // 2. 十六进制格式
    for (char c : address) {
        if (!isxdigit(c)) {
            return false;
        }
    }
    
    // 3. EIP-55 校验（可选）
    // ...
    
    return true;
}
```

**校验规则**:
- 长度：40 字符
- 格式：十六进制（0-9, a-f, A-F）
- 可选：EIP-55 大小写校验

### 4.2 Hash 校验规则

```cpp
// 校验 hash 格式（64 字符十六进制）
bool isValidHash(const std::string& hash) {
    // 1. 长度检查：64 字符
    if (hash.size() != 64) {
        return false;
    }
    
    // 2. 十六进制格式
    for (char c : hash) {
        if (!isxdigit(c)) {
            return false;
        }
    }
    
    return true;
}
```

**校验规则**:
- 长度：64 字符
- 格式：十六进制（0-9, a-f, A-F）

### 4.3 Amount 校验规则

```cpp
// 校验金额格式和范围
expected<int> validateAmount(const std::string& amount_str) {
    // 1. 非空检查
    if (amount_str.empty()) {
        return PERROR(MEM::INVALID_AMOUNT, "amount is empty");
    }
    
    // 2. 格式检查：正整数
    for (char c : amount_str) {
        if (!isdigit(c)) {
            return PERROR(MEM::INVALID_AMOUNT, "amount must be positive integer");
        }
    }
    
    // 3. 范围检查：> 0 && <= UINT64_MAX
    uint64_t amount;
    try {
        amount = std::stoull(amount_str);
    } catch (const std::exception& e) {
        return PERROR(MEM::INVALID_AMOUNT, "amount overflow");
    }
    
    if (amount == 0) {
        return PERROR(MEM::INVALID_AMOUNT, "amount must be > 0");
    }
    
    if (amount > UINT64_MAX) {
        return PERROR(MEM::INVALID_AMOUNT, "amount overflow");
    }
    
    return 0;
}
```

**校验规则**:
- 格式：正整数字符串
- 范围：> 0 && ≤ UINT64_MAX

### 4.4 AssetType 校验规则

```cpp
// 校验资产类型格式
bool isValidAssetType(const std::string& asset_type) {
    // 1. "Vote" 是合法的资产类型
    if (asset_type == "Vote") {
        return true;
    }
    
    // 2. 其他必须是 64 字符 hash
    if (asset_type.size() != 64) {
        return false;
    }
    
    // 3. 十六进制格式
    for (char c : asset_type) {
        if (!isxdigit(c)) {
            return false;
        }
    }
    
    return true;
}
```

**校验规则**:
- 特殊值："Vote"
- 其他：64 字符十六进制

### 4.5 枚举值校验规则

```cpp
// 校验枚举值合法性
bool isValidVoteType(int vote_type) {
    return (vote_type == 0 || vote_type == 1); // Against or Approve
}

bool isValidDelegateType(int delegate_type) {
    return (delegate_type == -1 || delegate_type == 0); // Unknown or NetLicence
}

bool isValidLockType(int lock_type) {
    return (lock_type == 0); // kLock_Node
}
```

---

## 5. 处理方案

### 5.1 校验函数封装

建议在 `param_handle.cpp` 中添加统一的校验辅助函数：

```cpp
namespace mmc {
    namespace rpc {
        
        // 地址格式校验
        expected<int> validateAddress(const std::string& addr, const std::string& field_name) {
            if (addr.empty()) {
                return PERROR(MEM::FIELD_EMPTY, "{} is empty", field_name);
            }
            
            if (!isValidAddress(addr)) {
                return PERROR(MEM::INVALID_ADDR, "{} format error", field_name);
            }
            
            return 0;
        }
        
        // Hash 格式校验
        expected<int> validateHash(const std::string& hash, const std::string& field_name) {
            if (hash.empty()) {
                return PERROR(MEM::FIELD_EMPTY, "{} is empty", field_name);
            }
            
            if (hash.size() != 64) {
                return PERROR(MEM::INVALID_HASH, "{} length must be 64", field_name);
            }
            
            for (char c : hash) {
                if (!isxdigit(c)) {
                    return PERROR(MEM::INVALID_HASH, "{} must be hex", field_name);
                }
            }
            
            return 0;
        }
        
        // Amount 格式和范围校验
        expected<int> validateAmount(const std::string& amount_str, const std::string& field_name) {
            if (amount_str.empty()) {
                return PERROR(MEM::FIELD_EMPTY, "{} is empty", field_name);
            }
            
            // 检查是否为正整数
            for (char c : amount_str) {
                if (!isdigit(c)) {
                    return PERROR(MEM::INVALID_AMOUNT, "{} must be positive integer", field_name);
                }
            }
            
            // 范围检查
            uint64_t amount;
            try {
                amount = std::stoull(amount_str);
            } catch (const std::exception& e) {
                return PERROR(MEM::INVALID_AMOUNT, "{} overflow", field_name);
            }
            
            if (amount == 0) {
                return PERROR(MEM::INVALID_AMOUNT, "{} must be > 0", field_name);
            }
            
            return 0;
        }
        
        // 枚举值校验
        expected<int> validateVoteType(int vote_type) {
            if (vote_type < 0 || vote_type > 1) {
                return PERROR(MEM::INVALID_PARAM, "vote_type must be 0 or 1");
            }
            return 0;
        }
        
        // 字段非空校验
        expected<int> validateNotEmpty(const std::string& str, const std::string& field_name) {
            if (str.empty()) {
                return PERROR(MEM::FIELD_EMPTY, "{} is empty", field_name);
            }
            return 0;
        }
        
    }
}
```

### 5.2 分类处理方案

#### 方案 A：查询类 RPC（无参数或简单参数）

**处理方式**: 保持空实现或仅做 JSON 解析

```cpp
expected<int> GetAllStakeNodeListParam::parse(const nlohmann::json &json) {
    auto re = reflect::Deserialize(json, *this);
    if (!re.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, re.error.value());
    }
    return 0;
}
```

#### 方案 B：交易类 RPC（复杂参数）

**处理方式**: 添加完整的参数校验

```cpp
expected<int> StakeParam::parse(const nlohmann::json &json) {
    auto ret = reflect::Deserialize(json, *this);
    if (!ret.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, ret.error.value());
    }
    
    // 1. 地址校验
    if (sponsor_gas) {
        auto gas_addr_ret = validateAddress(gas_asset.addr.str(), "gas_asset.addr");
        if (!gas_addr_ret.isOk()) {
            return gas_addr_ret;
        }
        
        auto gas_asset_type_ret = Util::isValidAssetType(gas_asset.asset_type.str());
        if (!gas_asset_type_ret) {
            return PERROR(MEM::INVALID_ASSET_TYPE, "gas_asset.asset_type");
        }
    }
    
    // 2. 地址校验
    auto addr_ret = validateAddress(addr, "addr");
    if (!addr_ret.isOk()) {
        return addr_ret;
    }
    
    // 3. 资产类型校验
    if (!Util::isValidAssetType(asset_type)) {
        return PERROR(MEM::INVALID_ASSET_TYPE, "asset_type");
    }
    
    // 4. Amount 校验
    auto amount_ret = validateAmount(amount, "amount");
    if (!amount_ret.isOk()) {
        return amount_ret;
    }
    
    // 5. 额外校验
    if (!reward_rank_string.empty()) {
        // 检查 reward_rank_string 格式
    }
    
    return 0;
}
```

#### 方案 C：字段依赖校验

```cpp
expected<int> BonusParam::parse(const nlohmann::json &json) {
    auto ret = reflect::Deserialize(json, *this);
    if (!ret.ok) {
        return PERROR(MEM::PARSE_JSON_FAIL, ret.error.value());
    }
    
    // 字段依赖校验
    if (first_choose) {
        if (asset_type != "Vote") {
            return PERROR(MEM::FIRST_BONUS_ERROR, 
                         "When first_choose is true, asset_type must be Vote");
        }
        
        if (!sponsor_gas) {
            return PERROR(MEM::FIRST_BONUS_ERROR,
                         "When first_choose is true, sponsor_gas must be true");
        }
    }
    
    return 0;
}
```

---

## 6. 实施计划

### 阶段 1：校验函数封装（1 天）

**任务**:
- [ ] 在 `param_handle.cpp` 中添加统一的校验辅助函数
- [ ] 编写单元测试验证校验函数

**交付物**:
- `param_handle.cpp` 中的辅助函数
- 校验函数单元测试

### 阶段 2：ParamHandle 类校验实现（3 天）

**任务**:
- [ ] 实现 `StakeParam::parse()` 完整校验
- [ ] 实现 `DelegatingParam::parse()` 完整校验
- [ ] 实现 `UndelegatingParam::parse()` 完整校验
- [ ] 实现 `BonusParam::parse()` 完整校验（含字段依赖）
- [ ] 实现 `FundParam::parse()` 完整校验
- [ ] 实现 `UnStakeTransParam::parse()` 完整校验
- [ ] 实现 `LockTransParam::parse()` 完整校验
- [ ] 实现 `UnLockParam::parse()` 完整校验
- [ ] 实现 `VoteParam::parse()` 完整校验
- [ ] 实现 `DeployParam::parse()` 完整校验
- [ ] 实现 `CallParam::parse()` 完整校验
- [ ] 实现 `TransactionParam::parse()` 完整校验

**交付物**:
- 所有 ParamHandle 类的 `parse()` 方法实现

### 阶段 3：测试与验证（1 天）

**任务**:
- [ ] 编写集成测试
- [ ] 验证参数校验生效
- [ ] 验证错误处理正确

**交付物**:
- 集成测试用例
- 测试报告

### 阶段 4：文档更新（0.5 天）

**任务**:
- [ ] 更新 ParamHandle 使用文档
- [ ] 添加参数校验规则说明

**交付物**:
- ParamHandle 使用文档
- 参数校验规则说明

---

## 7. HTTP API 请求大小限制

### 7.1 当前实现状态

根据对 `httplib.h` 的分析，当前 HTTP 服务器的请求大小限制如下：

```cpp
// httplib.h 默认配置
#ifndef CPPHTTPLIB_PAYLOAD_MAX_LENGTH
#define CPPHTTPLIB_PAYLOAD_MAX_LENGTH ((std::numeric_limits<size_t>::max)())
#endif
```

**结论**: 默认情况下，**没有请求大小限制**（使用 `size_t::max`）。

### 7.2 可配置的限制方法

`httplib::Server` 提供了 `set_payload_max_length()` 方法来设置请求体大小限制：

```cpp
// 设置最大请求体大小（例如：10MB）
server.set_payload_max_length(10 * 1024 * 1024);
```

### 7.3 当前项目中的使用情况

在 `openhive` 项目中：

1. **HTTP 服务器实现**: 使用 `httplib.h` 库
2. **配置位置**: 需要检查 `HttpServer::Start()` 或 `HttpServer::Work()` 中是否设置了 `payload_max_length`
3. **风险**: 如果未设置限制，恶意用户可以发送超大请求体导致 OOM

### 7.4 建议的配置方案

```cpp
// 在 HttpServer::Start() 中添加请求大小限制
void HttpServer::Start() {
    // ... 其他初始化代码 ...
    
    // 设置最大请求体大小：10MB
    server.set_payload_max_length(10 * 1024 * 1024);
    
    // ... 启动服务器 ...
}
```

---

## 8. 风险与注意事项

### 8.1 安全风险

| 风险 | 描述 | 缓解措施 |
|-----|------|---------|
| 整数溢出 | amount 参数未做范围检查 | 使用 `validateAmount()` 进行范围校验 |
| 空指针 | 字段未做非空检查 | 添加 `validateNotEmpty()` 辅助函数 |
| 格式错误 | 地址/hash 长度不正确 | 添加长度检查和格式验证 |
| 注入攻击 | 未对输入做限制 | 添加长度限制和字符白名单 |
| OOM 攻击 | HTTP 请求体无大小限制 | 使用 `set_payload_max_length()` 限制请求体 |

### 8.2 兼容性风险

| 风险 | 描述 | 缓解措施 |
|-----|------|---------|
| 旧版本兼容性 | 新增校验可能导致旧客户端失败 | 添加配置选项允许关闭严格校验 |
| 字段变更 | 新增必填字段可能导致旧客户端失败 | 使用可选字段或提供默认值 |

### 8.3 性能风险

| 风险 | 描述 | 缓解措施 |
|-----|------|---------|
| 校验开销 | 过多的校验可能影响性能 | 仅对关键字段进行必要校验 |

---

## 附录 A：常量定义

### 最小金额常量（来自 `ca/global.h`）

```cpp
const uint64_t kDecimalNum = 100000000;                    // 小数精度
const uint64_t MIN_STAKE_AMOUNT = 3500 * kDecimalNum;     // 最小质押金额：3500 MM
const uint64_t kMinDelegatingAmt = 500 * kDecimalNum;     // 最小投资金额：500 MM
const uint64_t kMinKGetBonusDelegatingAmt = 500000 * kDecimalNum; // 领取奖励的最小投资：500000 MM
const uint64_t KInvestmentCap = 3500000 * kDecimalNum;    // 投资上限
const uint64_t kMaximum_number_of_investments = 1000;     // 最大投资次数
const uint32_t LOCK_AMOUNT = 1;                           // 锁定单位
```

### 枚举类型定义（来自 `ca/txhelper.h`）

```cpp
typedef enum emdelegateType {
    kdelegateType_Unknown = -1,  // unknown
    kdelegateType_NetLicence = 0, // NetLicence
} delegateType;

typedef enum emLockType {
    LOCK_UNKNOWN = -1,  // unknown
    kLock_Node = 0,     // Node lock
} LockType;

enum class VoteType {
    Against = 0,   // 反对
    Approve = 1,   // 赞成
    Count          // 特殊的枚举元素，用于标记枚举元素的个数
};
```

---

## 附录 A：HTTP API 请求大小限制配置

### A.1 httplib.h 默认配置

```cpp
// httplib.h 默认没有请求大小限制
#ifndef CPPHTTPLIB_PAYLOAD_MAX_LENGTH
#define CPPHTTPLIB_PAYLOAD_MAX_LENGTH ((std::numeric_limits<size_t>::max)())
#endif
```

### A.2 推荐配置

```cpp
// 在 HttpServer::Start() 中添加限制
void HttpServer::Start() {
    // 设置最大请求体大小：10MB
    server.set_payload_max_length(10 * 1024 * 1024);
    
    // ... 启动服务器 ...
}
```

---

## 附录 B：参考文档

- [交易池容量和超时淘汰原则](feedback_transaction_pool_capacity.md)
- [VRF验证检查结果](feedback_vrf_verification_check.md)
- [dispatcher_vrf验证原则](feedback_dispatcher_vrf_verification.md)

---

## 附录 C：ParamHandle 校验实施检查清单

### C.1 阶段 1：校验函数封装
- [ ] 在 `param_handle.cpp` 中添加 `validateAddress()` 辅助函数
- [ ] 添加 `validateHash()` 辅助函数
- [ ] 添加 `validateAmount()` 辅助函数
- [ ] 添加 `validateVoteType()` 辅助函数
- [ ] 添加 `validateDelegateType()` 辅助函数
- [ ] 添加 `validateLockType()` 辅助函数
- [ ] 添加 `validateNotEmpty()` 辅助函数

### C.2 阶段 2：ParamHandle 类校验实现
- [ ] `StakeParam::parse()` - 实现完整校验（包括 amount 范围）
- [ ] `DelegatingParam::parse()` - 实现完整校验（包括 delegate_type）
- [ ] `UndelegatingParam::parse()` - 实现完整校验（包括 utxo_hash）
- [ ] `BonusParam::parse()` - 实现字段依赖校验
- [ ] `FundParam::parse()` - 实现完整校验（包括 encoded_info）
- [ ] `UnStakeTransParam::parse()` - 实现完整校验（包括 stake_utxo_hash）
- [ ] `LockTransParam::parse()` - 实现完整校验（包括 lock_amount）
- [ ] `UnLockParam::parse()` - 实现完整校验
- [ ] `VoteParam::parse()` - 实现完整校验（包括 vote_type）
- [ ] `DeployParam::parse()` - 实现完整校验（包括 contract_type）
- [ ] `CallParam::parse()` - 实现完整校验（包括 args）
- [ ] `TransactionParam::parse()` - 实现完整校验

### C.3 阶段 3：HTTP API 安全加固
- [ ] 检查 `HttpServer::Start()` 中是否设置了 `payload_max_length`
- [ ] 添加请求大小限制（推荐 10MB）
- [ ] 测试超大请求的拒绝处理

### C.4 阶段 4：测试与验证
- [ ] 编写单元测试验证所有校验函数
- [ ] 编写集成测试验证所有 ParamHandle 类
- [ ] 测试超大请求的拒绝处理
- [ ] 验证错误处理正确性

---
