# Slashing 测试用例

本文档只列当前实现应覆盖的测试项。早期设计中的举证奖励、显式 PUNISHMENT UTXO 守恒、未支持证据类型等不作为当前通过条件。

## 1. EVIDENCE 验证

| 编号 | 场景 | 预期 |
|------|------|------|
| E-1 | `evidence_hash != SHA256(evidence_data)` | 拒绝 |
| E-2 | 签名数量小于 `kSlashEvidenceQuorum` | 拒绝 |
| E-3 | 签名无法验证 `evidence_hash` | 拒绝 |
| E-4 | 重复签名地址 | 拒绝 |
| E-5 | 签名者不是当前质押节点 | 拒绝 |
| E-6 | 相同 `evidence_hash` 已上链 | 幂等跳过 |
| E-7 | `DOUBLE_SIGN_VRF` payload 字段完整且签名不同 | 通过 |
| E-8 | `DOUBLE_SIGN_BLOCK` 两个 block hash 相同 | 拒绝 |
| E-9 | `LOW_SIGN_RATE` 的 `sign_rate >= kJailLowThreshold` | 拒绝 |
| E-10 | `MALICIOUS_REPORTING` | 当前拒绝 |
| E-11 | `INVALID_BLOCK` / `VRF_VERIFY_FAIL` / `FREQUENT_DISCONNECT` | 当前拒绝 |

## 2. PUNISHMENT 验证

| 编号 | 场景 | 预期 |
|------|------|------|
| P-1 | `punishment_id` 与本地计算不一致 | 拒绝 |
| P-2 | 分发者签名无效 | 拒绝 |
| P-3 | 签名地址不等于 `tx.identity` | 拒绝 |
| P-4 | 签名者不是当前质押节点 | 拒绝 |
| P-5 | 目标节点无 `EVIDENCE_THRESHOLD` | 拒绝 |
| P-6 | level/type/evidence_refs 与 threshold 不一致 | 拒绝 |
| P-7 | `stake_refs` 缺失或不是数组 | 拒绝 |
| P-8 | `stake_refs` 与当前 stake refs 不一致 | 拒绝 |
| P-9 | `PUNISHMENT_HISTORY:{punishment_id}` 已存在 | 拒绝 |
| P-10 | 合法 PUNISHMENT | 通过并执行 |

## 3. 执行与回滚

| 编号 | 场景 | 预期 |
|------|------|------|
| X-1 | EVIDENCE 上链 | 写 `EVIDENCE_ON_CHAIN` 并递增 count |
| X-2 | count 达到 L3/L4 阈值 | 写 `EVIDENCE_THRESHOLD` |
| X-3 | L3 首次惩罚 | 删除原 stake refs，创建剩余合成 stake 或升级 L4 |
| X-4 | L3 后剩余低于 `MIN_STAKE_AMOUNT` | 自动升级 L4 |
| X-5 | L4 惩罚 | tombstone，移除 stake addr，退回委托 |
| X-6 | EVIDENCE 回滚 | 删除上链记录，递减 count，必要时移除 threshold |
| X-7 | PUNISHMENT 回滚 | 删除 history，删除合成剩余 stake，恢复 `stake_refs`，递减 L3 count，恢复 threshold，L4 删除 tombstone 并反向处理委托退款快照 |

## 4. VRF 批次

| 编号 | 场景 | 预期 |
|------|------|------|
| V-1 | 系统交易插入位置 | 在 gas 过滤后、input hash 前 |
| V-2 | EVIDENCE/PUNISHMENT 参与 input hash | 验证端 VRF 通过 |
| V-3 | 打包者丢弃系统交易 | 验证端 input hash 不一致，VRF 失败 |
| V-4 | EVIDENCE identity | 使用分发者地址，ContractPackagerMsg identity 一致 |

## 5. RPC 和查询

| 编号 | 场景 | 预期 |
|------|------|------|
| R-1 | `GetThresholdNodes` | 返回 level、violation_type、evidence_refs |
| R-2 | `GetPunishmentList` | 按地址索引返回 punishment_id、tx_hash、level、period |
| R-3 | `GetPunishmentDetail` | 返回 target、level、violation_type、evidence_refs、punishment_id |

## 6. 回归

- 普通 TX/STAKE/UNSTAKE/DELEGATE/VOTE/BONUS 正常。
- DEPLOY/CALL 分发和打包正常。
- 无系统交易时 VRF 行为不变。
- ExclusionProof 行为不变。
- 构建通过：`cmake --build build -j$(nproc)`。
