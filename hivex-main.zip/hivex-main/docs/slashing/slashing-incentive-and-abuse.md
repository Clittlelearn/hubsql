# 举证激励与恶意举证防护

## 1. 当前实现状态

当前代码重点实现证据可靠性和惩罚确定性，尚未实现举证奖励发放。文档中早期设计的 L3 50% / L4 20% 举证奖励、PUNISHMENT vout 分配、显式 burn vout 等内容不属于当前实现。

当前实现中：

- EVIDENCE 签名者只作为证据 quorum，不获得链上奖励。
- L3 扣减部分通过不重建对应质押状态实现，不显式写 burn UTXO。
- L4 删除节点质押资格并退回委托。

## 2. 恶意举证防护

当前防护分为三层：

1. 证据消息层：`SlashEvidencePool::verifyEvidence` 检查必填字段、hash、reporter 签名、reporter 地址匹配。
2. 链上 EVIDENCE 层：`ValidateSlashEvidenceTx` 检查 payload、quorum 签名、签名者质押资格和唯一性。
3. `MALICIOUS_REPORTING` 当前保留但不启用，原因是缺少可跨节点一致复验的 report 列表和统计来源。

## 3. 恶意举证 payload

当前不支持 `MALICIOUS_REPORTING` 上链。后续启用前必须定义 report 列表、每条 report 的证据 hash、验真结果来源，并由链上验证重新计算统计值。


## 4. 后续举证奖励设计要求

如要启用举证奖励，必须先补充以下设计并修改代码：

- 奖励来源：明确来自 L3 扣减额或 L4 没收额，不得增发。
- 奖励接收者：从 EVIDENCE 签名地址集合派生，并排序去重。
- 金额计算：全部使用整数最小精度，避免浮点误差。
- 状态更新：明确是通过 UTXO 输出、余额索引还是系统账户完成。
- 回滚：PUNISHMENT data 必须保存足够快照以反向恢复奖励和 burn 状态。
- 测试：覆盖整除、不整除、重复签名、奖励接收者不是质押节点等情况。

在这些规则完成前，文档和代码都应认为“举证奖励未实现”。
