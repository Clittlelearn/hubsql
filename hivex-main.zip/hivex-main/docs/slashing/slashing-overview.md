# Slashing 总体设计与当前实现

## 1. 目标

Slashing 机制用于约束恶意行为和长期惰性行为。当前实现优先保证共识安全：任何会导致惩罚的交易，都必须能被所有验证节点根据链上交易内容和本地链状态确定性复验。

## 2. 惩罚等级

| 等级 | 名称 | 当前实现状态 | 说明 |
|------|------|--------------|------|
| L0 | 奖励扣减 | 沿用已有逻辑 | 签名低于平均会影响奖励 |
| L1 | Jailing | 已有相关状态接口和过滤逻辑 | 暂停共识资格，不扣质押 |
| L2 | Forfeit | 已有相关状态/计数接口 | 奖励没收类惩罚 |
| L3 | Stake Slash | 已实现核心路径 | 按 1%/3%/5% 递增扣减节点自有质押 |
| L4 | Tombstone | 已实现核心路径 | 永久除名，移除质押资格，退回委托 |

## 3. 支持的违规类型

| 类型 | 当前链上 EVIDENCE 是否接受 | 当前 payload 校验 |
|------|----------------------------|-------------------|
| `DOUBLE_SIGN_VRF` | 是 | `seed`、两个不同 VRF 签名、可选签名 hash 且 hash 匹配 |
| `DOUBLE_SIGN_BLOCK` | 是 | 非零 `height`、两个不同 64 字节区块 hash |
| `LOW_SIGN_RATE` | 是 | `valid_periods >= 50`，`signed_count <= valid_periods`，`sign_rate < kJailLowThreshold` |
| `MALICIOUS_REPORTING` | 否 | 缺少可跨节点一致复验的 report 列表和统计来源 |
| `INVALID_BLOCK` | 否 | 缺少确定性 evidence_data 格式和复验规则 |
| `VRF_VERIFY_FAIL` | 否 | 缺少确定性 evidence_data 格式和复验规则 |
| `FREQUENT_DISCONNECT` | 否 | 缺少可跨节点一致复验的证据格式 |

未支持类型不是删除设计，而是暂时禁止作为可靠惩罚证据。后续启用前必须先定义 payload 字段和验证算法。

## 4. EVIDENCE

`EVIDENCE` 是证据记录交易，不直接惩罚。

```json
{
  "target_addr": "被举报节点地址",
  "violation_type": "DOUBLE_SIGN_VRF | DOUBLE_SIGN_BLOCK | LOW_SIGN_RATE",
  "evidence_hash": "SHA256(evidence_data)",
  "evidence_data": "序列化 JSON 字符串"
}
```

要求：

- `tx.type = TxType::EVIDENCE`。
- `tx.identity` 是构造系统交易的分发者地址。
- `tx.signature` 保存举证节点对 `evidence_hash` 的签名。
- 有效签名数量不少于 `global::ca::kSlashEvidenceQuorum`。
- 签名者必须是不重复的当前质押节点。
- `evidence_hash` 必须等于 `SHA256(evidence_data)`。
- `evidence_data` 必须通过对应 `violation_type` 的结构校验。

## 5. PUNISHMENT

`PUNISHMENT` 是惩罚执行交易。

```json
{
  "target_addr": "被惩罚节点地址",
  "penalty_level": 3,
  "violation_type": "LOW_SIGN_RATE",
  "evidence_refs": "触发阈值的 evidence_hash",
  "punishment_id": "确定性惩罚 ID",
  "stake_refs": ["执行前目标节点的 stake UTXO hash 列表"]
}
```

`punishment_id` 计算规则：

```text
punishment_id = SHA256(target_addr + "|" + violation_type + "|" + penalty_level + "|" + SHA256(evidence_refs))
```

当前 `evidence_refs` 是字符串，通常为触发阈值时的 evidence hash；如后续改为证据集合，必须先定义排序和序列化规范。

## 6. 数据库状态

| Key | 当前语义 |
|-----|----------|
| `evidence_on_chain_{evidenceHash}` | EVIDENCE 已上链，value 为 `targetAddr,violationType` |
| `evidence_count_{addr}:{type}` | 某节点某类型 EVIDENCE 累计数 |
| `evidence_threshold_list_` | 已达到惩罚阈值的地址列表 |
| `evidence_threshold_{addr}` | `level,violationType,evidenceRefs` |
| `punishment_history_{punishmentId}` | 已执行惩罚，value 为 `targetAddr,period,level` |
| `punishment_history_by_addr_{addr}` | RPC 查询用地址到 punishment_id 列表 |
| `slash_jail_{addr}` | Jailed 状态 |
| `slash_tombstone_{addr}` | Tombstone 状态 |

## 7. 惩罚执行摘要

L3：从 `stake_refs` 快照读取目标节点执行前的质押 UTXO，按 1%/3%/5% 递增扣减，删除原 stake refs。若剩余质押不低于 `MIN_STAKE_AMOUNT`，创建 `tx.hash() + "_remaining"` 合成 stake 交易和 UTXO value 索引；否则升级为 L4。

L4：写入 tombstone，删除 stake refs 和 stake address，遍历委托关系，给委托者创建退款 UTXO 并更新余额。

当前实现没有举证奖励分配。扣减部分不显式构造 burn vout，而是通过不重建被扣减质押实现状态层面的扣减。

## 8. 关键不变量

- EVIDENCE 不能依赖本地内存池状态验证，必须由交易内容和链状态自洽验证。
- PUNISHMENT 不能信任 JSON 自报惩罚结果，必须匹配 `EVIDENCE_THRESHOLD` 和当前 `stake_refs`。
- 惩罚幂等主键是 `punishment_id`，不是 `target_addr`。
- 系统交易必须参与 VRF 输入，不能在 VRF 后追加。
- `EVIDENCE` 和 `PUNISHMENT` 不计入 gas 累计。
