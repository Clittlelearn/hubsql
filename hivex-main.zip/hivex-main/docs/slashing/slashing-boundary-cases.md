# Slashing 边界情况与异常处理

## 1. 网络初期

当前 `SaveBlock` 在处理 EVIDENCE 时会读取质押节点列表。如果质押节点数小于 `global::ca::kConsensus`，只记录 `EVIDENCE_ON_CHAIN`，不递增计数、不触发 threshold、不执行惩罚。

目的：网络未达到最小共识规模时，避免少数节点形成惩罚共识。

## 2. 普通交易并发举证

普通交易是 DAG 并发结构，多个节点可能同时发起相同证据的 EVIDENCE。当前通过两层幂等处理：

- 内存层：`SlashEvidencePool` 按 `evidence_hash` 聚合并去重。
- 链上层：`EVIDENCE_ON_CHAIN:{evidence_hash}` 已存在时跳过。

因此允许多个节点竞争提交相同证据，最终链上只接受一次。

## 3. 合约批次和 VRF 一致性

系统交易在 gas 过滤后、VRF `input_hash` 计算前插入，打包者和验证者都使用完整交易列表重算 input hash。EVIDENCE 的 `identity` 使用分发者地址，避免 `ContractPackagerMsg` 中出现多个 identity 导致验证失败。

禁止在 VRF 后追加 EVIDENCE/PUNISHMENT。

## 4. 未支持证据类型

`INVALID_BLOCK`、`VRF_VERIFY_FAIL`、`FREQUENT_DISCONNECT`、`MALICIOUS_REPORTING` 当前缺少确定性 payload 规则，链上 EVIDENCE 会被拒绝。

后续启用这些类型时必须补充：

- payload schema。
- 本地链状态如何复验。
- 失败/通过的确定性条件。
- 正反测试用例。

## 5. PUNISHMENT 并发

同一 target 可能被多个分发者同时构造 PUNISHMENT。当前幂等主键是 `punishment_id`，验证时还要求：

- `EVIDENCE_THRESHOLD` 当前状态与交易字段一致。
- `stake_refs` 与目标节点当前 stake refs 一致。
- `PUNISHMENT_HISTORY:{punishment_id}` 不存在。

一旦某个 PUNISHMENT 执行并改变 stake refs 或写入 history，后续重复交易会被拒绝。

## 6. L3 后再次惩罚

L3 执行后会删除原 stake refs，并在剩余质押足够时创建 `tx.hash() + "_remaining"` 合成 stake 交易。该合成交易写入 transaction raw、stake UTXO 索引和 UTXO value 索引，使后续质押查询和再次惩罚能识别剩余质押。

注意：合成 stake tx 的时间为惩罚交易时间，因此剩余质押的 30 天解质押计时会从惩罚时间开始。若后续要保留原始质押时间，需要扩展快照字段。

## 7. 回滚

EVIDENCE 回滚：删除上链记录、递减计数、必要时移除 threshold。

PUNISHMENT 回滚：

- 删除 `PUNISHMENT_HISTORY` 和地址查询索引。
- 删除 L3 可能创建的合成剩余 stake。
- 将 `stake_refs` 恢复到目标地址。
- L4 时删除 tombstone。

当前 L4 委托退款会写入 DB 回滚快照，回滚时删除 refund UTXO、扣回 delegator balance，并恢复 delegation 索引。

## 8. Tombstone 后重新质押

L4 tombstone 是永久状态。后续 STAKE 入口必须继续检查 tombstone，避免被除名节点重新进入共识。

## 9. 分发者包庇

单个分发者不构造 EVIDENCE/PUNISHMENT 时，后续分发者仍可基于证据池或链上 threshold 继续处理。当前不单独惩罚“包庇分发者”，因为无法稳定区分恶意包庇和任期内来不及处理。
