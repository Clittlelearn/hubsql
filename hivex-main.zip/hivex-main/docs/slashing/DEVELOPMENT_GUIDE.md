# Slashing 开发指南

## 1. 必须遵守的核心规则

1. EVIDENCE 必须自包含验证，不能依赖本地证据池。
2. PUNISHMENT 必须从链上 DB 状态确定性派生，不能信任交易 JSON 自报。
3. 系统交易必须在 gas 过滤后、VRF input hash 计算前插入。
4. `kSlashEvidenceQuorum` 必须跟随 `global::ca::kConsensus`。
5. 惩罚幂等主键必须是 `punishment_id`，不是地址。
6. EVIDENCE/PUNISHMENT 当前不参与 gas 累计。
7. PUNISHMENT 必须携带 `stake_refs`，验证时必须与当前 stake refs 完全一致。

## 2. 不变量检查清单

### EVIDENCE

- [ ] `evidence_hash == SHA256(evidence_data)`。
- [ ] payload 类型在当前支持范围内。
- [ ] payload 字段满足确定性校验。
- [ ] 签名数量 `>= kSlashEvidenceQuorum`。
- [ ] 每个签名都能验证 `evidence_hash`。
- [ ] 签名地址不重复且属于当前质押节点。
- [ ] 相同 `evidence_hash` 不重复上链。

### PUNISHMENT

- [ ] `punishment_id` 本地重算一致。
- [ ] 分发者签名有效且签名者是当前质押节点。
- [ ] `EVIDENCE_THRESHOLD:{target}` 存在。
- [ ] threshold 中的 level/type/refs 与交易一致。
- [ ] `stake_refs` 与目标节点当前 stake refs 一致。
- [ ] `PUNISHMENT_HISTORY:{punishment_id}` 不存在。
- [ ] 执行后写入 history 和地址索引。

### VRF 批次

- [ ] 系统交易已经加入 `filtered_tx_msgs`。
- [ ] 系统交易 hash 已加入 `tx_hash_time`。
- [ ] `input_hash` 覆盖完整交易集合。
- [ ] EVIDENCE/PUNISHMENT identity 使用分发者地址。

## 3. 禁止行为

- 禁止重新引入 `slash_amount` 作为可信字段。
- 禁止按地址判断惩罚幂等，必须使用 `punishment_id`。
- 禁止让未定义 payload 校验的类型通过链上 EVIDENCE 验证。
- 禁止在 VRF 后追加系统交易。
- 禁止把本地证据池作为链上验证依据。
- 禁止在没有快照的情况下新增不可回滚状态。

## 4. 当前未实现但可扩展项

- `INVALID_BLOCK`、`VRF_VERIFY_FAIL`、`FREQUENT_DISCONNECT`、`MALICIOUS_REPORTING` payload 规则。
- 多 evidence refs 的排序、序列化和哈希规则。
- 举证奖励和 burn 账户显式记账。
- 如未来把 L4 委托退款快照从 DB 迁移到交易 data，必须同步更新验证规则。

## 5. 修改后必须执行

```bash
git diff --check
cmake --build build -j$(nproc)
```

并扫描旧逻辑残留，重点确认以下内容没有重新进入共识代码：

- 可信的自报惩罚金额字段。
- 按地址而不是按 `punishment_id` 做惩罚幂等。
- 硬编码举证 quorum。
- 恶意举证的简化放行逻辑。
