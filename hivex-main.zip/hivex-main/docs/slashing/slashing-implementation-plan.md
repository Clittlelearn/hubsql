# Slashing 当前实现清单与后续计划

## 1. 已完成里程碑

| 里程碑 | 内容 | 提交 |
|--------|------|------|
| M1 | 惩罚身份模型：`kSlashEvidenceQuorum = kConsensus`，`punishment_id`，threshold 增加 violation type/refs，地址查询索引 | `f880daf` |
| M2 | EVIDENCE 签名验证：hash、payload、quorum、签名有效性、签名者质押资格和唯一性 | `510824e` |
| M3 | PUNISHMENT 确定性验证：匹配 threshold、punishment_id、分发者签名、history 幂等 | `ed4368f` |
| M4 | 惩罚质押状态：`stake_refs` 快照、L3 合成剩余 stake、回滚恢复 stake refs | `61ae856` |
| M5 | EVIDENCE payload 校验：支持四类 payload，拒绝未定义类型 | `d9631f3` |
| M6 | 系统批次一致性：EVIDENCE identity 改为分发者地址，保持 VRF 批次 identity 一致 | `3be4241` |

## 2. 当前交易类型

| 类型 | 值 | 说明 |
|------|----|------|
| `TxType::PUNISHMENT` | 100 | 惩罚执行交易 |
| `TxType::EVIDENCE` | 101 | 证据记录交易 |

## 3. 当前 DB 模型

| 接口/Key | 说明 |
|----------|------|
| `EVIDENCE_ON_CHAIN` | 按 evidence hash 幂等记录 |
| `EVIDENCE_COUNT` | 按 target/type 计数 |
| `EVIDENCE_THRESHOLD_LIST` | 已达到阈值的 target 列表 |
| `EVIDENCE_THRESHOLD` | `level,violationType,evidenceRefs` |
| `PUNISHMENT_HISTORY` | keyed by `punishment_id` |
| `PUNISHMENT_HISTORY_BY_ADDR` | RPC 查询索引 |

## 4. 当前验证函数

| 函数 | 职责 |
|------|------|
| `CalculateSlashEvidenceHash` | 计算 evidence_data hash |
| `BuildSlashPunishmentId` | 构造确定性 punishment id |
| `ValidateSlashEvidenceTx` | 链上 EVIDENCE 确定性验证 |
| `ValidateSlashPunishmentTx` | 链上 PUNISHMENT 确定性验证 |

## 5. 当前支持和限制

已支持：

- VRF 双签、区块双签、低签名率、恶意举证统计的 payload 结构校验。
- EVIDENCE/PUNISHMENT 进入 VRF 统一批次。
- PUNISHMENT 对 threshold 和 stake refs 的确定性验证。
- L3/L4 基础状态迁移和部分回滚。

限制：

- `INVALID_BLOCK`、`VRF_VERIFY_FAIL`、`FREQUENT_DISCONNECT`、`MALICIOUS_REPORTING` 尚未启用。
- 举证奖励未实现。
- L4 委托退款已写入 DB 快照用于回滚；后续如迁移到交易内快照，需要同步更新验证规则。
- `evidence_refs` 当前为字符串，不是规范化证据集合。

## 6. 后续建议计划

P0：为未支持类型定义 payload schema 和验证函数。
P1：规范化 `evidence_refs` 为排序后的证据集合，并更新 `punishment_id` 计算。
P2：如未来需要，把 L4 委托退款回滚快照从 DB 状态迁移到交易 data，并同步共识验证。
P3：设计并实现举证奖励。
P4：补充自动化集成测试和多节点仿真测试。
