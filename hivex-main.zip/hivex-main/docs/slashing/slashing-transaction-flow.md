# EVIDENCE/PUNISHMENT 交易流程

## 1. 总体流程

当前实现采用统一通道：系统交易与普通/合约交易一起进入候选交易列表，并参与同一套 VRF 输入计算。

1. 检测节点发送 `SlashEvidenceMsg` 给分发者。
2. 分发者在 `SlashEvidencePool` 中聚合签名。
3. 达到 `kSlashEvidenceQuorum` 后构造 `EVIDENCE` 交易。
4. 分发者查询 `EVIDENCE_THRESHOLD`，为达到阈值的节点构造 `PUNISHMENT` 交易。
5. 在 `DistributionContractTransactionRequest` 中，普通交易 gas 过滤完成后，插入 EVIDENCE/PUNISHMENT 系统交易。
6. 基于包含系统交易的完整 `tx_hash_time` 计算 `input_hash`。
7. 使用该 `input_hash` 生成/验证 `selection_vrf`。

系统交易必须在 VRF 前插入，不能在 VRF 后追加。

## 2. 系统交易插入位置

```text
解析用户交易 -> 按时间排序 -> gas 过滤 -> buildEvidenceTransactions()
-> buildPunishmentTransactions() -> 加入 filtered_tx_msgs 和 tx_hash_time
-> 计算 input_hash -> VRF 选择打包者 -> ContractPackagerMsg 发送
```

`EVIDENCE` 和 `PUNISHMENT` 不参与 gas 累计，不会被 ExclusionProof 排除。

## 3. ContractPackagerMsg identity 一致性

验证端要求同一 `ContractPackagerMsg` 中交易的 `identity()` 一致。因此：

- EVIDENCE 的 `identity` 使用当前分发者地址。
- PUNISHMENT 的 `identity` 使用当前分发者地址。
- EVIDENCE 的举证者身份保存在 `signature` 列表中。

## 4. EVIDENCE 执行

`SaveBlock` 中：

1. 调用 `ValidateSlashEvidenceTx(tx, &dbWriter)`。
2. 如果质押节点数小于 `kConsensus`，只记录 `EVIDENCE_ON_CHAIN`，不触发惩罚阈值。
3. 如果 `evidence_hash` 已上链，则幂等跳过。
4. 否则写入 `EVIDENCE_ON_CHAIN`，递增 `EVIDENCE_COUNT:{target}:{type}`。
5. 如果计数达到阈值，写入 `EVIDENCE_THRESHOLD:{target}`，value 为 `level,violationType,evidenceRefs`。

`DOUBLE_SIGN_VRF`、`DOUBLE_SIGN_BLOCK` 当前对应 L4；其他已支持类型当前对应 L3。

## 5. PUNISHMENT 构造

分发者通过 `buildPunishmentTransactions()`：读取 `EVIDENCE_THRESHOLD_LIST`，读取 `level,violationType,evidenceRefs`，计算 `punishment_id`，检查历史，读取并排序 `stake_refs`，构造并签名交易。

```json
{
  "target_addr": "addr",
  "penalty_level": 3,
  "violation_type": "LOW_SIGN_RATE",
  "evidence_refs": "evidence_hash",
  "punishment_id": "deterministic id",
  "stake_refs": ["stake_utxo_hash_1", "stake_utxo_hash_2"]
}
```

当前没有 `slash_amount` 字段，惩罚金额由执行阶段根据链上 stake refs 和 L3 次数确定。

## 6. PUNISHMENT 验证

验证函数会检查：必填字段、level 只能为 3/4、`punishment_id` 匹配、分发者签名有效、签名者为当前质押节点、`EVIDENCE_THRESHOLD` 状态与交易字段完全一致、`stake_refs` 等于目标节点当前 stake refs、`PUNISHMENT_HISTORY:{punishment_id}` 不存在。

## 7. PUNISHMENT 执行

1. 写 `PUNISHMENT_HISTORY:{punishment_id}` 和地址查询索引。
2. 根据 `stake_refs` 读取原 stake 交易，计算总质押。
3. L3 按 1%/3%/5% 扣减，删除原 stake refs。
4. L3 剩余质押不低于 `MIN_STAKE_AMOUNT` 时，创建 `tx.hash() + "_remaining"` 合成 stake 交易和 UTXO value 索引。
5. L3 剩余质押低于 `MIN_STAKE_AMOUNT` 时升级为 L4。
6. L4 写 tombstone，删除 stake refs 和 stake address，退回委托并删除委托映射。
7. 清理该目标地址的 evidence count 和 threshold 状态。

当前实现没有举证奖励发放，也没有显式构造 burn UTXO。扣减部分通过不重建对应质押状态实现。

## 8. 回滚

EVIDENCE 回滚会删除 `EVIDENCE_ON_CHAIN`、递减 `EVIDENCE_COUNT`，必要时删除 threshold。

PUNISHMENT 回滚会删除惩罚历史和地址索引，删除 `tx.hash() + "_remaining"` 合成 stake 状态，恢复 `stake_refs`，递减 L3 slash count，恢复 threshold 状态；L4 时删除 tombstone，并通过 `punishment_delegation_refunds_` 快照删除退款 UTXO、扣回 delegator balance、恢复 delegation 索引。

## 9. 幂等性

| 对象 | 幂等主键 | 说明 |
|------|----------|------|
| EVIDENCE | `evidence_hash` | `EVIDENCE_ON_CHAIN` 阻止重复上链 |
| PUNISHMENT | `punishment_id` | 同一惩罚对象只执行一次 |
| RPC 查询 | `target_addr -> punishment_id list` | 仅查询索引，不作为共识幂等主键 |
