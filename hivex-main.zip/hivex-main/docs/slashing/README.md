# OpenHive Slashing 文档

**状态**: 与当前代码实现同步
**分支**: `tmp_merge_dev_slashing_2026-6-20_2_main`
**最后同步**: 2026-06-30

本目录描述 OpenHive 当前 slashing 实现和后续开发约束。核心原则：证据必须可复验，惩罚必须从链上状态确定性派生，系统交易必须参与 VRF 输入。

## 文档索引

| 文档 | 内容 |
|------|------|
| [slashing-overview.md](slashing-overview.md) | 当前总体设计、已支持/未支持违规类型、数据模型和不变量 |
| [slashing-evidence-collection.md](slashing-evidence-collection.md) | 证据收集、证据池、EVIDENCE 交易、payload 校验规则 |
| [slashing-transaction-flow.md](slashing-transaction-flow.md) | EVIDENCE/PUNISHMENT 上链流程、VRF 统一性、执行和回滚 |
| [slashing-boundary-cases.md](slashing-boundary-cases.md) | 并发、重复、回滚、网络初期、未支持证据类型等边界情况 |
| [slashing-incentive-and-abuse.md](slashing-incentive-and-abuse.md) | 恶意举证防护、当前未实现的举证奖励、后续设计要求 |
| [slashing-implementation-plan.md](slashing-implementation-plan.md) | 当前实现清单、已完成里程碑和后续待办 |
| [IMPLEMENTATION_PROGRESS.md](IMPLEMENTATION_PROGRESS.md) | 本轮审计修改的提交记录和验证结果 |
| [DEVELOPMENT_GUIDE.md](DEVELOPMENT_GUIDE.md) | 后续开发必须遵守的约束、不变量和检查清单 |
| [slashing-test-cases.md](slashing-test-cases.md) | 与当前实现匹配的测试矩阵 |

## 当前核心结论

1. `EVIDENCE` 必须包含自洽的 `evidence_data`、`evidence_hash` 和不少于 `global::ca::kSlashEvidenceQuorum` 个有效且不重复的质押节点签名。
2. `kSlashEvidenceQuorum = global::ca::kConsensus`，开发阶段随当前共识值为 3，主网改为 7 时自动跟随。
3. 当前链上可接受的 evidence payload 类型为 `DOUBLE_SIGN_VRF`、`DOUBLE_SIGN_BLOCK`、`LOW_SIGN_RATE`。
4. `INVALID_BLOCK`、`VRF_VERIFY_FAIL`、`FREQUENT_DISCONNECT`、`MALICIOUS_REPORTING` 保留枚举，但当前缺少确定性 payload 校验规则，链上验证会拒绝这些类型。
5. `PUNISHMENT` 不信任交易 JSON 自报结果，验证者会从 `EVIDENCE_THRESHOLD`、`PUNISHMENT_HISTORY`、当前 stake refs 等 DB 状态重新校验。
6. 惩罚幂等主键是 `punishment_id`，不是地址。RPC 查询额外维护 `punishment_history_by_addr_` 地址索引。
7. 系统交易在 gas 过滤之后、VRF `input_hash` 计算之前插入，与普通/合约交易统一进入 `ContractPackagerMsg`。
8. 当前实现没有发放举证奖励；L3 扣减部分通过不重建对应质押来隐式销毁，L4 会 tombstone 并退回委托。
