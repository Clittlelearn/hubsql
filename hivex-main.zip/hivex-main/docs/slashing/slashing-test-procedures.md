# Slashing 测试流程手册

**分支**: `tmp_merge_dev_slashing_2026-6-20_2_main`
**编写日期**: 2026-07-01
**配套文档**: `slashing-test-cases.md`（测试矩阵）

本文档为每条测试用例提供完整的操作步骤、观察指标和判定标准。所有 RPC 请求均指向节点 HTTP 端口（默认 `13134`），日志路径为 `/home/test/biz/logs/openhive_YYYY-MM-DD.log`（远程）或 `build/bin/logs/openhive_YYYY-MM-DD.log`（本地）。

---

## 1. 测试环境

### 1.1 节点拓扑

| 角色 | 地址 | 说明 |
|------|------|------|
| 正常节点 ×6 | 192.168.1.161 – 192.168.1.166 | 运行标准编译产物，全部质押 |
| 作恶节点（本机） | 192.168.1.x（本机 IP） | 运行修改后的编译产物，按需模拟不同违规行为 |
| 测试控制端 | 本机 | 发起 RPC 查询、SSH 收集日志 |

### 1.2 关键常量（当前值）

| 常量 | 值 | 说明 |
|------|----|------|
| `kConsensus` | 3 | 共识节点数 / 证据 quorum |
| `kSlashEvidenceQuorum` | 3 | EVIDENCE 所需最少签名数 |
| `kPunishmentThresholdL3` | 3 | 触发 L3 所需 evidence 累计数 |
| `kPunishmentThresholdL4` | 5 | 触发 L4 所需 evidence 累计数 |
| `MIN_STAKE_AMOUNT` | 3500 OHI | 最低质押量 |
| `kJailLowThreshold` | 0.50 | 低签名率阈值（平均的 50%） |
| `kSlashRateFirst/Second/Third` | 1%/3%/5% | L3 递增扣减率 |

### 1.3 违规类型与惩罚等级映射

| 违规类型 | 触发 level | 阈值（evidence 数） | 说明 |
|----------|-----------|---------------------|------|
| `DOUBLE_SIGN_VRF` | L4 | 5 | 直接 tombstone |
| `DOUBLE_SIGN_BLOCK` | L4 | 5 | 直接 tombstone |
| `LOW_SIGN_RATE` | L3 | 3 | 递增扣减质押 |
| `MALICIOUS_REPORTING` | — | — | 当前不可用 |
| `INVALID_BLOCK` / `VRF_VERIFY_FAIL` / `FREQUENT_DISCONNECT` | — | — | 当前不可用 |

### 1.4 测试分层策略

惩罚机制测试分为两类，不应混用：

| 阶段 | 目标 | 使用版本 | 执行时机 | 通过标准 |
|------|------|----------|----------|----------|
| 开发阶段轻量验证 | 验证结构、日志、RPC、空状态、基础交易与合约池不被破坏 | 标准代码编译产物 | 每次修改 slashing、网络、交易池、合约池、DB 回滚相关代码后 | 基础功能正常，无异常 slashing 日志，RPC 字段结构正确 |
| 上线前完整恶意节点测试 | 验证真实作恶检测、证据 quorum、EVIDENCE/PUNISHMENT、L3/L4、回滚、VRF 批次 | 从 release candidate 临时派生的作恶节点补丁程序 | 功能冻结后、正式发布前 | `slashing-test-cases.md` 全部场景通过 |

开发阶段不要求构造真实作恶节点，也不应把作恶开关、注入 RPC、测试配置长期合入主程序。上线前如需作恶节点，应从同一 release commit 临时派生补丁版本，测试完成后丢弃，正式版本必须从干净 release commit 重新编译。

---

## 2. 环境准备

### 2.1 编译

```bash
# 正常节点二进制（标准代码）
cmake --build build -j$(nproc)

# 作恶节点二进制（按需修改代码后编译，见附录 A）
# 每次修改后重新编译
cmake --build build -j$(nproc)
```

### 2.2 部署到 LAN 节点

```bash
# 部署标准二进制到 6 个 LAN 节点
~/code/send_to_nodes.sh openhive_v0.0.0_xxxxxx

# 验证部署
for i in 161 162 163 164 165 166; do
  ssh test@192.168.1.$i "ls -la /home/test/biz/openhive"
done
```

### 2.3 清理日志

```bash
# 清理远程日志
for i in 161 162 163 164 165 166; do
  ssh test@192.168.1.$i "rm -f /home/test/biz/logs/openhive_*.log"
done

# 清理本地日志
rm -f build/bin/logs/openhive_*.log
```

### 2.4 启动/重启节点

```bash
# 重启 LAN 节点（按实际启动方式调整）
for i in 161 162 163 164 165 166; do
  ssh test@192.168.1.$i "cd /home/test/biz && ./restart.sh"
done

# 启动本机作恶节点
./build/bin/openhive --config <作恶节点配置>
```

### 2.5 确认网络正常

```bash
# 检查所有节点 RPC 可达
for i in 161 162 163 164 165 166; do
  curl -s http://192.168.1.$i:13134/GetSlashStats | python3 -m json.tool
done

# 确认所有节点为 ACTIVE 状态
curl -s http://192.168.1.161:13134/GetSlashStats
# 预期：total_stake_nodes >= 6, active_nodes >= 6, jailed_nodes = 0, tombstoned_nodes = 0
```

### 2.6 收集日志

```bash
# 测试结束后收集所有日志到本地
mkdir -p test_logs/run_$(date +%Y%m%d_%H%M%S)
for i in 161 162 163 164 165 166; do
  scp test@192.168.1.$i:/home/test/biz/logs/openhive_*.log \
    test_logs/run_*/${i}.log
done
cp build/bin/logs/openhive_*.log test_logs/run_*/local.log
```

---

## 3. 通用 RPC 参考

### 3.1 查询类（GET）

```bash
# 节点 slashing 状态（ACTIVE/JAILED/TOMBSTONED）
curl -s "http://<NODE>:13134/GetSlashNodeStatus?addr=<ADDR>"

# 全局统计
curl -s "http://<NODE>:13134/GetSlashStats"

# 已达阈值的节点列表（响应字段：threshold_nodes）
curl -s "http://<NODE>:13134/GetThresholdNodes"

# 按地址查 evidence 计数聚合（当前返回 violation_type/count，不返回完整 tx 列表）
curl -s "http://<NODE>:13134/GetEvidenceList?addr=<ADDR>&type=<TYPE>"

# 按地址查 punishment 列表
curl -s "http://<NODE>:13134/GetPunishmentList?addr=<ADDR>"

# 被 jail 的节点
curl -s "http://<NODE>:13134/GetJailedNodes"

# 被 tombstone 的节点
curl -s "http://<NODE>:13134/GetTombstonedNodes"
```

### 3.2 查询类（POST）

```bash
# Evidence 详情（按 tx_hash）
curl -s -X POST http://<NODE>:13134/GetEvidenceDetail \
  -H "Content-Type: application/json" \
  -d '{"tx_hash":"<TX_HASH>"}'

# Punishment 详情（按 tx_hash 或 punishment_id）
curl -s -X POST http://<NODE>:13134/GetPunishmentDetail \
  -H "Content-Type: application/json" \
  -d '{"tx_hash":"<TX_HASH>"}'
# 或
curl -s -X POST http://<NODE>:13134/GetPunishmentDetail \
  -H "Content-Type: application/json" \
  -d '{"punishment_id":"<PUNISHMENT_ID>"}'

# Evidence 累计数（响应字段：evidence_counts）
curl -s -X POST http://<NODE>:13134/GetEvidenceCount \
  -H "Content-Type: application/json" \
  -d '{"addr":"<ADDR>","type":"<TYPE>"}'

# 节点签名率
curl -s -X POST http://<NODE>:13134/GetNodeSignRate \
  -H "Content-Type: application/json" \
  -d '{"addr":"<ADDR>","start_period":0,"end_period":999999}'
```

### 3.3 日志过滤关键字

所有 slashing 日志以 `[SLASH]` 为前缀。测试时实时过滤：

```bash
# SSH 到节点实时过滤 slashing 日志
ssh test@192.168.1.161 "tail -f /home/test/biz/logs/openhive_*.log | grep '\[SLASH\]'"
```

关键日志模式速查：

| 日志片段 | 含义 |
|----------|------|
| `EVIDENCE tx validation passed` | EVIDENCE 链上验证通过 |
| `PUNISHMENT tx validation passed` | PUNISHMENT 链上验证通过 |
| `Threshold reached! addr:..., level:...` | 证据累计达到惩罚阈值 |
| `L3 Stake slash #N executed!` | L3 扣减执行成功 |
| `L3→L4 cascade!` | L3 剩余质押不足，升级 L4 |
| `L4 Tombstoning executed!` | L4 tombstone 执行成功 |
| `EVIDENCE already on chain` | 幂等跳过 |
| `Invalid EVIDENCE tx: ...` | EVIDENCE 验证失败（后跟具体原因） |
| `Invalid PUNISHMENT tx: ...` | PUNISHMENT 验证失败（后跟具体原因） |
| `Evidence consensus reached` | 证据池达成共识 |
| `Built EVIDENCE tx` | 分发者构造了 EVIDENCE 交易 |
| `Built PUNISHMENT tx` | 分发者构造了 PUNISHMENT 交易 |
| `Network too young` | 质押节点不足 kConsensus |
| `Inserted N EVIDENCE + M PUNISHMENT system transactions` | 系统交易插入完成 |


### 3.4 RPC 响应字段速查

当前 RPC 返回字段以代码实现为准，基础测试时按以下字段判定：

| RPC | 关键响应字段 | 空状态预期 |
|-----|--------------|------------|
| `GetSlashStats` | `total_stake_nodes`, `active_nodes`, `jailed_nodes`, `tombstoned_nodes`, `status` | `jailed_nodes=0`, `tombstoned_nodes=0` |
| `GetSlashNodeStatus?addr=<ADDR>` | `addr`, `status`, `evidence_counts`, `total_evidence`, `has_punishment_history` | `status=ACTIVE`, `total_evidence=0` |
| `GetThresholdNodes` | `threshold_nodes`, `status` | `threshold_nodes=[]` |
| `GetEvidenceList?addr=<ADDR>&type=<TYPE>` | `addr`, `evidence_list`, `status` | `evidence_list=[]` |
| `GetPunishmentList?addr=<ADDR>` | `addr`, `has_punishment`, `punishments`, `status` | `has_punishment=false`, `punishments=[]` |
| `GetJailedNodes` | `jailed_nodes`, `count`, `status` | `count=0` |
| `GetTombstonedNodes` | `tombstoned_nodes`, `count`, `status` | `count=0` |
| `GetEvidenceCount` | `addr`, `evidence_counts`, `status` | 指定类型值为 `0` |
| `GetNodeSignRate` | `addr`, `signed_count`, `total_periods`, `sign_rate`, `status` | 返回合法 JSON，数值字段存在 |

### 3.5 开发阶段轻量验证（当前优先执行）

本节用于日常开发和普通合并后的基础验证，不要求构造真实作恶行为，也不证明惩罚机制完整有效。目标是快速确认 slashing 基础设施没有破坏主流程。

#### LITE-1: 编译与启动

```bash
cmake --build build -j$(nproc)
```

预期：编译通过；6 个 LAN 节点和本机节点可启动；启动日志中不出现 slashing 初始化错误。

#### LITE-2: 日志路径与异常扫描

```bash
# 远端
for i in 161 162 163 164 165 166; do
  ssh test@192.168.1.$i "grep -E '\[SLASH\].*(Invalid|rejected|failed)|VRF verification failed|input hash mismatch|buildTxs.empty' /home/test/biz/logs/openhive_*.log"
done

# 本地
rg '\[SLASH\].*(Invalid|rejected|failed)|VRF verification failed|input hash mismatch|buildTxs.empty' build/bin/logs/openhive_*.log
```

预期：在未触发作恶测试的干净网络中，不应出现持续的 slashing 拒绝、VRF input hash mismatch 或合约池反复 `buildTxs.empty()`。如果只是历史日志残留，应先清理日志后复测。

#### LITE-3: RPC 可用性与空状态

```bash
NODE=192.168.1.161
ADDR=<待检查节点地址>

curl -s "http://$NODE:13134/GetSlashStats" | python3 -m json.tool
curl -s "http://$NODE:13134/GetSlashNodeStatus?addr=$ADDR" | python3 -m json.tool
curl -s "http://$NODE:13134/GetThresholdNodes" | python3 -m json.tool
curl -s "http://$NODE:13134/GetEvidenceList?addr=$ADDR" | python3 -m json.tool
curl -s "http://$NODE:13134/GetPunishmentList?addr=$ADDR" | python3 -m json.tool
curl -s "http://$NODE:13134/GetJailedNodes" | python3 -m json.tool
curl -s "http://$NODE:13134/GetTombstonedNodes" | python3 -m json.tool
curl -s -X POST "http://$NODE:13134/GetEvidenceCount" \
  -H "Content-Type: application/json" \
  -d "{\"addr\":\"$ADDR\",\"type\":\"DOUBLE_SIGN_VRF\"}" | python3 -m json.tool
curl -s -X POST "http://$NODE:13134/GetNodeSignRate" \
  -H "Content-Type: application/json" \
  -d "{\"addr\":\"$ADDR\",\"start_period\":0,\"end_period\":0}" | python3 -m json.tool
```

干净网络预期：`GetSlashStats` 中 `jailed_nodes=0`、`tombstoned_nodes=0`；`GetThresholdNodes.threshold_nodes=[]`；`GetPunishmentList.punishments=[]`；`GetJailedNodes.count=0`；`GetTombstonedNodes.count=0`；指定 evidence count 为 0。

#### LITE-4: 基础交易与合约池回归

至少验证以下场景：

| 编号 | 场景 | 预期 |
|------|------|------|
| LITE-4.1 | 普通转账 | 可上链，节点不掉线 |
| LITE-4.2 | STAKE / DELEGATE / VOTE / BONUS | 基础业务流程不受 slashing 影响 |
| LITE-4.3 | DEPLOY / CALL | 合约交易可上链 |
| LITE-4.4 | 高级菜单 `33. test contract pool`，参数 `30/1/1` | 合约池交易正常上链 |
| LITE-4.5 | UTC `00:00-01:00` 窗口内执行 CALL/DEPLOY 或合约池测试 | 不因 `CanReward=false` 导致合约交易全部失败 |
| LITE-4.6 | 无 EVIDENCE/PUNISHMENT 的普通轮次 | VRF 验证通过，无系统交易副作用 |
| LITE-4.7 | ExclusionProof 相关原有流程 | 行为与 slashing 合入前一致 |

#### LITE-5: 系统交易空路径

在没有 evidence/punishment 的环境中，合约分发和普通出块不应插入无效系统交易，不应影响 VRF input hash，不应产生无效 EVIDENCE/PUNISHMENT 日志。

---

## 4. EVIDENCE 验证测试

> **通用前提**：6 个 LAN 节点全部在线、已质押、运行标准代码。作恶节点（本机）运行修改后的代码。
>
> **通用验证方法**：作恶节点或被测节点构造 EVIDENCE 交易 → 分发者将其打包入块 → 所有节点在 `SaveBlock` 中执行 `ValidateSlashEvidenceTx` → 通过或拒绝。
>
> **对于验证拒绝类测试**：需要修改分发者节点（或将分发者逻辑修改到作恶节点）使其构造含有特定缺陷的 EVIDENCE 交易。其他节点在 `SaveBlock` 验证时会拒绝该交易。判定标准是：接收节点的日志出现对应 `ERRORLOG`，且 RPC 查询 `GetEvidenceCount` 返回 0。

### E-1: evidence_hash 不匹配

**目标**：验证 `evidence_hash != SHA256(evidence_data)` 时 EVIDENCE 被拒绝。

**前置条件**：
- 网络正常运行，所有节点已质押。
- 修改作恶节点代码：在 `buildEvidenceTransactions()` 中对 `evidence_data` 计算 hash 后，人为篡改 `evidence_hash` 字段（如反转字符串或追加字符）。

**步骤**：
1. 清理日志。
2. 作恶节点向分发者发送一条合法的 `SlashEvidenceMsg`（hash 和签名正确，可通过证据池验证）。
3. 分发者（作恶节点）在构造 EVIDENCE 交易时篡改 `evidence_hash`。
4. 等待该 EVIDENCE 交易被打包入块并广播。
5. 在其他 LAN 节点上检查日志。

**观察**：

```bash
# 在 162 节点上检查
ssh test@192.168.1.162 "grep '\[SLASH\]' /home/test/biz/logs/openhive_*.log"
```

**预期日志**：
```
ERRORLOG [SLASH] Invalid EVIDENCE tx evidence hash, tx_hash:<HASH>, evidence_hash:<BAD_HASH>
```

**RPC 验证**：
```bash
curl -s -X POST http://192.168.1.162:13134/GetEvidenceCount \
  -d '{"addr":"<TARGET_ADDR>"}'
# 预期：`evidence_counts.<TYPE> = 0`
```

**判定**：日志出现 `Invalid EVIDENCE tx evidence hash` 且 evidence count 为 0 → **通过**。

---

### E-2: 签名数量不足

**目标**：验证签名数 < `kSlashEvidenceQuorum`（3）时 EVIDENCE 被拒绝。

**前置条件**：
- 修改作恶节点代码：在 `buildEvidenceTransactions()` 中只保留 2 个签名（而非 3 个）。

**步骤**：
1. 清理日志。
2. 触发一个违规事件（如作恶节点产生 VRF 双签）。
3. 等待 2 个正常节点发送 `SlashEvidenceMsg` 到分发者。
4. 分发者（作恶节点）在只收集到 2 个签名时就构造 EVIDENCE 交易并广播。
5. 检查其他节点日志。

**预期日志**：
```
ERRORLOG [SLASH] EVIDENCE tx has insufficient signatures: 2 < 3, hash:<HASH>
```

**RPC 验证**：
```bash
curl -s -X POST http://192.168.1.161:13134/GetEvidenceCount \
  -d '{"addr":"<TARGET_ADDR>"}'
# 预期：`evidence_counts.<TYPE> = 0`
```

**判定**：日志出现 `insufficient signatures: 2 < 3` 且 count 为 0 → **通过**。

---

### E-3: 签名无法验证 evidence_hash

**目标**：验证签名与 `evidence_hash` 不匹配时 EVIDENCE 被拒绝。

**前置条件**：
- 修改作恶节点代码：在构造 EVIDENCE 交易时，将某个签名的 `signature` 字段替换为对错误消息的签名（或随机字节）。

**步骤**：
1. 触发违规事件，收集正常签名。
2. 分发者（作恶节点）替换其中一个签名为无效签名。
3. 广播 EVIDENCE 交易。

**预期日志**：
```
ERRORLOG [SLASH] EVIDENCE tx signature verification failed, hash:<HASH>, index:<N>
```

**判定**：日志出现 `signature verification failed` 且 evidence count 为 0 → **通过**。

---

### E-4: 重复签名地址

**目标**：验证同一地址出现多次签名时 EVIDENCE 被拒绝。

**前置条件**：
- 修改作恶节点代码：在 EVIDENCE 交易的签名列表中，将同一个签名复制两次（或同一地址的两个不同签名）。

**步骤**：
1. 收集 3 个签名，但其中 2 个来自同一地址。
2. 构造 EVIDENCE 交易并广播。

**预期日志**：
```
ERRORLOG [SLASH] EVIDENCE tx duplicate signer, hash:<HASH>, signer:<ADDR>
```
或
```
ERRORLOG [SLASH] EVIDENCE tx unique signer count too low: 2 < 3, hash:<HASH>
```

**判定**：日志出现 `duplicate signer` 或 `unique signer count too low` 且 count 为 0 → **通过**。

---

### E-5: 签名者不是当前质押节点

**目标**：验证签名者不在当前质押节点列表中时 EVIDENCE 被拒绝。

**前置条件**：
- 准备一个未质押的地址和对应密钥。
- 修改作恶节点代码：使用未质押地址的密钥生成签名，加入 EVIDENCE 交易。

**步骤**：
1. 构造 EVIDENCE 交易，其中 1 个签名来自未质押地址。
2. 广播并检查日志。

**预期日志**：
```
ERRORLOG [SLASH] EVIDENCE tx signer is not eligible, hash:<HASH>, signer:<ADDR>
```

**判定**：日志出现 `signer is not eligible` 且 count 为 0 → **通过**。

---

### E-6: 重复 evidence_hash 幂等跳过

**目标**：验证相同 `evidence_hash` 第二次上链时被幂等跳过。

**前置条件**：
- 无需修改代码。利用正常的违规检测流程。

**步骤**：
1. 作恶节点产生一次 VRF 双签。
2. 等待 EVIDENCE 成功上链。
3. 确认 EVIDENCE 已记录：

```bash
curl -s -X POST http://192.168.1.161:13134/GetEvidenceCount \
  -d '{"addr":"<TARGET_ADDR>","type":"DOUBLE_SIGN_VRF"}'
# 预期：count >= 1
```

4. 作恶节点用相同的 `evidence_data` 再次尝试提交（或另一个节点重新发送相同证据）。
5. 检查日志。

**预期日志**：
```
DEBUGLOG [SLASH] EVIDENCE already on chain, hash:<HASH>
```

**RPC 验证**：
```bash
curl -s -X POST http://192.168.1.161:13134/GetEvidenceCount \
  -d '{"addr":"<TARGET_ADDR>","type":"DOUBLE_SIGN_VRF"}'
# 预期：count 不变（仍为 1）
```

**判定**：日志出现 `EVIDENCE already on chain` 且 count 未递增 → **通过**。

---

### E-7: DOUBLE_SIGN_VRF payload 合法

**目标**：验证完整的 DOUBLE_SIGN_VRF payload 能通过链上验证。

**前置条件**：
- 无需修改代码。

**步骤**：
1. 作恶节点对同一 VRF seed 产生两个不同的 VRF 签名。
2. 其他节点检测到双签，构造 `SlashEvidenceMsg`，payload 包含：
   ```json
   {
     "seed": "<VRF_SEED>",
     "existing_sig": "<SIG_1>",
     "new_sig": "<SIG_2>",
     "existing_sig_hash": "<SHA256(SIG_1)>",
     "new_sig_hash": "<SHA256(SIG_2)>"
   }
   ```
3. 等待 quorum 达成共识，EVIDENCE 上链。

**预期日志**（在验证节点上）：
```
DEBUGLOG [SLASH] EVIDENCE tx validation passed: type=DOUBLE_SIGN_VRF, hash=<HASH>, signatures=3
```

**RPC 验证**：
```bash
curl -s -X POST http://192.168.1.161:13134/GetEvidenceCount \
  -d '{"addr":"<TARGET_ADDR>","type":"DOUBLE_SIGN_VRF"}'
# 预期：`evidence_counts.DOUBLE_SIGN_VRF >= 1`

# 查看 evidence 详情
curl -s "http://192.168.1.161:13134/GetEvidenceList?addr=<TARGET_ADDR>&type=DOUBLE_SIGN_VRF"
```

**判定**：日志出现 `validation passed` 且 evidence count 递增 → **通过**。

---

### E-8: DOUBLE_SIGN_BLOCK 两个 block hash 相同

**目标**：验证 `existing_block_hash == new_block_hash` 时 EVIDENCE 被拒绝。

**前置条件**：
- 修改作恶节点代码：在构造 DOUBLE_SIGN_BLOCK evidence_data 时，将 `new_block_hash` 设为与 `existing_block_hash` 相同的值。

**步骤**：
1. 触发区块双签检测。
2. 分发者（作恶节点）构造 evidence_data 时复制 block hash。
3. 广播 EVIDENCE 交易。

**预期日志**：
```
ERRORLOG [SLASH] Invalid EVIDENCE tx data: DOUBLE_SIGN_BLOCK identical block hashes, hash:<HASH>
```
（具体错误文本以实际代码为准，关键为 `[SLASH]` + payload 校验失败相关日志）

**判定**：EVIDENCE 被拒绝，evidence count 为 0 → **通过**。

---

### E-9: LOW_SIGN_RATE sign_rate 不满足条件

**目标**：验证 `sign_rate >= kJailLowThreshold`（0.50）时 EVIDENCE 被拒绝。

**前置条件**：
- 修改作恶节点代码：在构造 LOW_SIGN_RATE evidence_data 时，将 `sign_rate` 设为 0.60（高于阈值 0.50）。

**步骤**：
1. 等待低签名率检测触发。
2. 分发者（作恶节点）篡改 `sign_rate` 为 0.60。
3. 广播 EVIDENCE 交易。

**预期日志**：
```
ERRORLOG [SLASH] Invalid EVIDENCE tx data: LOW_SIGN_RATE sign_rate above threshold, hash:<HASH>
```

**判定**：EVIDENCE 被拒绝，evidence count 为 0 → **通过**。

---

### E-10: MALICIOUS_REPORTING 当前拒绝

**目标**：验证 `MALICIOUS_REPORTING` 类型的 EVIDENCE 当前被拒绝。

**前置条件**：
- 修改作恶节点代码：强制构造 `violation_type = MALICIOUS_REPORTING` 的 EVIDENCE 交易。

**步骤**：
1. 构造 `violation_type = 6`（MALICIOUS_REPORTING）的 EVIDENCE 交易。
2. 广播并检查日志。

**预期日志**：
```
ERRORLOG [SLASH] Invalid EVIDENCE tx violation type: MALICIOUS_REPORTING, hash:<HASH>
```

**判定**：EVIDENCE 被拒绝 → **通过**。

---

### E-11: INVALID_BLOCK / VRF_VERIFY_FAIL / FREQUENT_DISCONNECT 当前拒绝

**目标**：验证这三种类型的 EVIDENCE 当前被拒绝。

**前置条件**：
- 修改作恶节点代码：分别构造 `violation_type = INVALID_BLOCK(2)` / `VRF_VERIFY_FAIL(3)` / `FREQUENT_DISCONNECT(5)` 的 EVIDENCE 交易。

**步骤**：
1. 依次构造三种类型的 EVIDENCE 交易并广播。
2. 检查日志。

**预期日志**（每种类型各一条）：
```
ERRORLOG [SLASH] Invalid EVIDENCE tx violation type: INVALID_BLOCK, hash:<HASH>
ERRORLOG [SLASH] Invalid EVIDENCE tx violation type: VRF_VERIFY_FAIL, hash:<HASH>
ERRORLOG [SLASH] Invalid EVIDENCE tx violation type: FREQUENT_DISCONNECT, hash:<HASH>
```

**判定**：三种类型全部被拒绝 → **通过**。

---

## 5. PUNISHMENT 验证测试

> **通用前提**：目标节点已有 `EVIDENCE_THRESHOLD` 状态（即证据累计已达到阈值）。这需要先完成至少一轮完整的 evidence 积累流程。
>
> **通用验证方法**：修改分发者节点使其在构造 PUNISHMENT 交易时引入特定缺陷 → 广播包含该 PUNISHMENT 交易的区块 → 其他节点在 `SaveBlock` 中执行 `ValidateSlashPunishmentTx` → 拒绝或接受。

### P-1: punishment_id 不匹配

**目标**：验证本地重算的 `punishment_id` 与交易中的不一致时 PUNISHMENT 被拒绝。

**前置条件**：
- 目标节点已达到 L3 阈值（3 条 LOW_SIGN_RATE evidence）。
- 修改分发者节点代码：在 `buildPunishmentTransactions()` 中篡改 `punishment_id`（如追加字符）。

**步骤**：
1. 等待分发者构造 PUNISHMENT 交易。
2. 检查其他节点日志。

**预期日志**：
```
ERRORLOG [SLASH] Invalid PUNISHMENT tx: id mismatch, expected:<CORRECT_ID>, got:<WRONG_ID>, hash:<HASH>
```

**RPC 验证**：
```bash
curl -s "http://192.168.1.161:13134/GetPunishmentList?addr=<TARGET_ADDR>"
# 预期：返回空列表
```

**判定**：日志出现 `id mismatch` 且 punishment list 为空 → **通过**。

---

### P-2: 分发者签名无效

**目标**：验证分发者签名无法通过验证时 PUNISHMENT 被拒绝。

**前置条件**：
- 目标节点已达到阈值。
- 修改分发者节点代码：使用错误密钥签名 PUNISHMENT 交易。

**预期日志**：
```
ERRORLOG [SLASH] Invalid PUNISHMENT tx: signature verification failed, hash:<HASH>
```

**判定**：日志出现 `signature verification failed` 且 punishment list 为空 → **通过**。

---

### P-3: 签名地址不等于 tx.identity

**目标**：验证签名者地址与 `tx.identity` 不一致时 PUNISHMENT 被拒绝。

**前置条件**：
- 修改分发者节点代码：`tx.identity` 设为地址 A，但用地址 B 的密钥签名。

**预期日志**：
```
ERRORLOG [SLASH] Invalid PUNISHMENT tx: signer mismatch, identity:<ADDR_A>, signer:<ADDR_B>, hash:<HASH>
```

**判定**：日志出现 `signer mismatch` → **通过**。

---

### P-4: 签名者不是当前质押节点

**目标**：验证分发者签名地址不在当前质押节点列表中时 PUNISHMENT 被拒绝。

**前置条件**：
- 使用一个已取消质押的地址的密钥签名 PUNISHMENT 交易。

**预期日志**：
```
ERRORLOG [SLASH] Invalid PUNISHMENT tx: signer is not eligible, hash:<HASH>, signer:<ADDR>
```

**判定**：日志出现 `signer is not eligible` → **通过**。

---

### P-5: 目标节点无 EVIDENCE_THRESHOLD

**目标**：验证目标节点没有达到阈值状态时 PUNISHMENT 被拒绝。

**前置条件**：
- 选择一个从未被举证的正常节点作为 target。
- 修改分发者节点代码：强制为该节点构造 PUNISHMENT 交易。

**预期日志**：
```
ERRORLOG [SLASH] Invalid PUNISHMENT tx: target has no threshold state, addr:<ADDR>, hash:<HASH>
```

**判定**：日志出现 `target has no threshold state` → **通过**。

---

### P-6: level/type/evidence_refs 与 threshold 不一致

**目标**：验证 PUNISHMENT 交易中的 level、violation_type 或 evidence_refs 与链上 `EVIDENCE_THRESHOLD` 状态不一致时被拒绝。

**前置条件**：
- 目标节点已达到 L3 阈值（LOW_SIGN_RATE）。
- 修改分发者节点代码：将 `penalty_level` 改为 4（实际应为 3），或将 `violation_type` 改为其他值。

**预期日志**：
```
ERRORLOG [SLASH] Invalid PUNISHMENT tx: threshold mismatch, hash:<HASH>
```

**判定**：日志出现 `threshold mismatch` → **通过**。

---

### P-7: stake_refs 缺失或格式错误

**目标**：验证 `stake_refs` 字段缺失或不是数组时 PUNISHMENT 被拒绝。

**前置条件**：
- 修改分发者节点代码：从 PUNISHMENT 交易 JSON 中删除 `stake_refs` 字段，或将其设为字符串而非数组。

**预期日志**：
```
ERRORLOG [SLASH] Invalid PUNISHMENT tx: missing stake_refs snapshot, hash:<HASH>
```

**判定**：日志出现 `missing stake_refs` → **通过**。

---

### P-8: stake_refs 与当前状态不一致

**目标**：验证 `stake_refs` 与目标节点当前链上 stake refs 不一致时 PUNISHMENT 被拒绝。

**前置条件**：
- 修改分发者节点代码：在 `stake_refs` 数组中替换或追加一个不存在的 stake UTXO hash。

**预期日志**：
```
ERRORLOG [SLASH] Invalid PUNISHMENT tx: stake_refs mismatch, hash:<HASH>
```

**判定**：日志出现 `stake_refs mismatch` → **通过**。

---

### P-9: PUNISHMENT_HISTORY 已存在（重复执行）

**目标**：验证同一 `punishment_id` 已执行过时 PUNISHMENT 被拒绝。

**前置条件**：
- 无需修改代码。利用正常的惩罚执行流程。

**步骤**：
1. 等待一个合法的 PUNISHMENT 成功执行。
2. 确认已执行：

```bash
curl -s "http://192.168.1.161:13134/GetPunishmentList?addr=<TARGET_ADDR>"
# 预期：返回至少一条记录
```

3. 重新构造并提交相同 `punishment_id` 的 PUNISHMENT 交易（可通过修改节点使其重复构造）。

**预期日志**：
```
ERRORLOG [SLASH] Invalid PUNISHMENT tx: already executed, punishment_id:<ID>, hash:<HASH>
```

**判定**：日志出现 `already executed` 且 punishment list 不增加新记录 → **通过**。

---

### P-10: 合法 PUNISHMENT 通过并执行

**目标**：验证完全合法的 PUNISHMENT 交易能通过所有验证并成功执行。

**前置条件**：
- 无需修改代码。使用正常流程。

**步骤**：
1. 作恶节点产生 LOW_SIGN_RATE 违规（保持离线足够长时间）。
2. 等待 3 条 evidence 上链，达到 L3 阈值。
3. 等待分发者自动构造 PUNISHMENT 交易。
4. 检查所有节点日志。

**预期日志**（分发者）：
```
INFOLOG [SLASH] Built PUNISHMENT tx for addr:<ADDR>, level:3
```

**预期日志**（验证节点）：
```
DEBUGLOG [SLASH] PUNISHMENT tx validation passed: type=LOW_SIGN_RATE, hash=<HASH>
INFOLOG [SLASH] L3 Stake slash #1 executed! addr:<ADDR>, totalStake:<AMOUNT>, slashRate:1%, slashAmount:<AMOUNT>, remaining:<AMOUNT>
```

**RPC 验证**：
```bash
# 查看 punishment 详情
curl -s -X POST http://192.168.1.161:13134/GetPunishmentDetail \
  -d '{"punishment_id":"<PUNISHMENT_ID>"}'
# 预期：返回完整 punishment 信息，level=3, violation_type=LOW_SIGN_RATE

# 查看节点状态
curl -s "http://192.168.1.161:13134/GetSlashNodeStatus?addr=<TARGET_ADDR>"
# 预期：节点仍为 ACTIVE（L3 不 jail/tombstone），但质押减少

# 查看全局统计
curl -s "http://192.168.1.161:13134/GetSlashStats"
```

**判定**：日志出现 `validation passed` + `L3 Stake slash #1 executed` 且 RPC 返回正确 punishment 详情 → **通过**。

---

## 6. 执行与回滚测试

### X-1: EVIDENCE 上链记录

**目标**：验证 EVIDENCE 写入 `EVIDENCE_ON_CHAIN` 并递增 count。

**前置条件**：
- 无需修改代码。

**步骤**：
1. 作恶节点产生 VRF 双签。
2. 等待 EVIDENCE 被打包入块。
3. 在任意 LAN 节点查询。

**预期日志**：
```
DEBUGLOG [SLASH] EVIDENCE tx validation passed: type=DOUBLE_SIGN_VRF, hash=<HASH>, signatures=3
```

**RPC 验证**：
```bash
# 查 count
curl -s -X POST http://192.168.1.161:13134/GetEvidenceCount \
  -d '{"addr":"<TARGET_ADDR>","type":"DOUBLE_SIGN_VRF"}'
# 预期：`evidence_counts.DOUBLE_SIGN_VRF = 1`

# 查 evidence 列表
curl -s "http://192.168.1.161:13134/GetEvidenceList?addr=<TARGET_ADDR>&type=DOUBLE_SIGN_VRF"
# 预期：返回对应 `violation_type` 的聚合 count；完整 EVIDENCE 详情需通过 `GetEvidenceDetail` 按 tx_hash 查询
```

**判定**：count 从 0 变为 1 → **通过**。

---

### X-2: 达到 L3 阈值

**目标**：验证 LOW_SIGN_RATE evidence count 达到 3 时写入 `EVIDENCE_THRESHOLD`。

**前置条件**：
- 作恶节点保持离线/低签名率。
- 需要等待足够多的 period 使检测触发（`valid_periods >= 50`）。

**步骤**：
1. 作恶节点停止签名，保持在线但不参与共识签名。
2. 等待第一个 evidence 上链（count=1）。
3. 等待第二个 evidence 上链（count=2）。
4. 等待第三个 evidence 上链（count=3）。
5. 观察第三个 evidence 上链时的日志。

**预期日志**（count 达到 3 时）：
```
INFOLOG [SLASH] Threshold reached! addr:<ADDR>, type:LOW_SIGN_RATE, count:3, level:3
```

**RPC 验证**：
```bash
# 查阈值节点列表
curl -s "http://192.168.1.161:13134/GetThresholdNodes"
# 预期：列表中包含目标节点，level=3, violation_type=LOW_SIGN_RATE

# 查 evidence count
curl -s -X POST http://192.168.1.161:13134/GetEvidenceCount \
  -d '{"addr":"<TARGET_ADDR>","type":"LOW_SIGN_RATE"}'
# 预期：`evidence_counts.LOW_SIGN_RATE = 3`
```

**判定**：日志出现 `Threshold reached` 且 `GetThresholdNodes` 包含目标节点 → **通过**。

---

### X-3: L3 首次惩罚

**目标**：验证 L3 首次执行：删除原 stake refs，创建合成剩余 stake。

**前置条件**：
- 目标节点已达到 L3 阈值。
- 无需修改代码，等待分发者自动构造 PUNISHMENT。

**步骤**：
1. 等待 PUNISHMENT 交易被打包执行。
2. 检查日志。

**预期日志**：
```
INFOLOG [SLASH] L3 Stake slash #1 executed! addr:<ADDR>, totalStake:<TOTAL>, slashRate:1%, slashAmount:<SLASH>, remaining:<REMAINING>
INFOLOG [SLASH] L3 remaining stake UTXO created: hash=<TX_HASH>_remaining, value=<VALUE>
```

**RPC 验证**：
```bash
# 查 punishment 详情
curl -s -X POST http://192.168.1.161:13134/GetPunishmentDetail \
  -d '{"punishment_id":"<ID>"}'
# 预期：level=3, violation_type=LOW_SIGN_RATE, stake_refs 非空

# 查节点状态
curl -s "http://192.168.1.161:13134/GetSlashNodeStatus?addr=<ADDR>"
# 预期：status=ACTIVE, punishment_history 包含本次记录
```

**判定**：日志出现 `L3 Stake slash #1 executed` + `L3 remaining stake UTXO created` → **通过**。

---

### X-4: L3 剩余质押不足 → 升级 L4

**目标**：验证 L3 扣减后剩余质押 < `MIN_STAKE_AMOUNT`（3500 OHI）时自动升级 L4。

**前置条件**：
- **关键**：目标节点的质押量需要接近最低值。建议在测试前将目标节点的质押设为略高于 3500 OHI 的值（如 3600 OHI），这样经过 1-2 次 L3 扣减后就会低于 3500。
- 需要多轮 evidence 积累：第一轮 3 条 evidence 触发 L3（1%），清理后第二轮再 3 条 evidence 触发 L3（3%），此时 3600 × 0.97 × 0.97 ≈ 3389 < 3500，触发升级。

**步骤**：
1. 第一轮：3 条 LOW_SIGN_RATE evidence → L3 扣减 1%。
2. 第二轮：再 3 条 LOW_SIGN_RATE evidence → L3 扣减 3%。
3. 观察第二次 L3 执行时的日志。

**预期日志**：
```
ERRORLOG [SLASH] L3→L4 cascade! addr:<ADDR> remaining stake <AMOUNT> < MIN_STAKE_AMOUNT 350000000000
```

随后应出现 L4 执行日志（见 X-5）。

**判定**：日志出现 `L3→L4 cascade` → **通过**。

---

### X-5: L4 Tombstone 执行

**目标**：验证 L4 执行：tombstone、移除质押、退回委托。

**前置条件**：
- 方式 A：通过 X-4 的 L3→L4 升级自然触发。
- 方式 B：直接触发 DOUBLE_SIGN_VRF，积累 5 条 evidence 直接达到 L4 阈值。

**步骤**（方式 B）：
1. 作恶节点产生 5 次 VRF 双签（每次产生不同的 seed 双签）。
2. 等待 5 条 evidence 上链。
3. 观察日志。

**预期日志**：
```
INFOLOG [SLASH] Threshold reached! addr:<ADDR>, type:DOUBLE_SIGN_VRF, count:5, level:4
INFOLOG [SLASH] Built PUNISHMENT tx for addr:<ADDR>, level:4
INFOLOG [SLASH] L4 Tombstoning executed! addr:<ADDR>, period:<PERIOD>
```

如果有委托者：
```
INFOLOG [SLASH] L4 refund <AMOUNT> to delegator:<DELEGATOR_ADDR>, new balance:<BALANCE>
```

**RPC 验证**：
```bash
# 查节点状态
curl -s "http://192.168.1.161:13134/GetSlashNodeStatus?addr=<ADDR>"
# 预期：status = "TOMBSTONED"

# 查 tombstoned 节点列表
curl -s "http://192.168.1.161:13134/GetTombstonedNodes"
# 预期：列表中包含目标节点

# 查全局统计
curl -s "http://192.168.1.161:13134/GetSlashStats"
# 预期：tombstoned_nodes 递增，total_stake_nodes 递减

# 查 punishment 详情
curl -s -X POST http://192.168.1.161:13134/GetPunishmentDetail \
  -d '{"punishment_id":"<ID>"}'
# 预期：level=4, violation_type=DOUBLE_SIGN_VRF
```

**判定**：日志出现 `L4 Tombstoning executed`，RPC 返回 `TOMBSTONED` 状态 → **通过**。

---

### X-6: EVIDENCE 回滚

**目标**：验证 EVIDENCE 回滚时删除上链记录、递减 count、必要时移除 threshold。

**前置条件**：
- 需要触发链回滚（区块重组）。这通常需要制造分叉：
  1. 让部分节点暂时隔离（如断开网络）。
  2. 在隔离的节点上产生包含 EVIDENCE 的区块。
  3. 恢复网络，让更长的链覆盖。

**步骤**：
1. 先让 EVIDENCE 成功上链（确认 count=1）。
2. 制造分叉使包含该 EVIDENCE 的区块被回滚。
3. 检查日志。

**预期日志**（回滚路径）：
```
DEBUGLOG [SLASH] EVIDENCE rollback: removed evidence_on_chain_<HASH>
DEBUGLOG [SLASH] EVIDENCE rollback: decremented evidence_count_<ADDR>:<TYPE>
```

**RPC 验证**：
```bash
curl -s -X POST http://192.168.1.161:13134/GetEvidenceCount \
  -d '{"addr":"<TARGET_ADDR>","type":"<TYPE>"}'
# 预期：count 回退到回滚前的值
```

**判定**：日志出现回滚相关日志且 count 正确回退 → **通过**。

> **注意**：链回滚测试需要精确控制网络拓扑和区块生产，是较复杂的集成测试。如果当前环境不支持便捷的分叉制造，可以标记为"待实现分叉测试工具后执行"。

---

### X-7: PUNISHMENT 回滚

**目标**：验证 PUNISHMENT 回滚时恢复所有状态。

**前置条件**：
- 同 X-6，需要触发链回滚。
- 已有一个成功执行的 L3 或 L4 PUNISHMENT。

**步骤**：
1. 确认 PUNISHMENT 已执行（L3 扣减已完成）。
2. 记录当前状态：punishment list、节点质押量。
3. 制造分叉使包含 PUNISHMENT 的区块被回滚。
4. 检查日志和状态。

**预期日志**（L3 回滚）：
```
DEBUGLOG [SLASH] PUNISHMENT rollback: deleted punishment_history_<ID>
DEBUGLOG [SLASH] PUNISHMENT rollback: deleted remaining stake <TX_HASH>_remaining
DEBUGLOG [SLASH] PUNISHMENT rollback: restored stake_refs for <ADDR>
DEBUGLOG [SLASH] PUNISHMENT rollback: decremented L3 slash count for <ADDR>
DEBUGLOG [SLASH] PUNISHMENT rollback: restored threshold for <ADDR>
```

**RPC 验证**：
```bash
# 查 punishment list
curl -s "http://192.168.1.161:13134/GetPunishmentList?addr=<ADDR>"
# 预期：被回滚的 punishment 消失

# 查节点状态
curl -s "http://192.168.1.161:13134/GetSlashNodeStatus?addr=<ADDR>"
# 预期：质押恢复到扣减前水平
```

**判定**：日志出现回滚日志，punishment 消失，质押恢复 → **通过**。

> **注意**：同 X-6，需要分叉测试工具支持。

---

## 7. VRF 批次测试

### V-1: 系统交易插入位置

**目标**：验证 EVIDENCE/PUNISHMENT 在 gas 过滤后、input hash 计算前插入。

**前置条件**：
- 无需修改代码。

**步骤**：
1. 触发 evidence 和 punishment 流程。
2. 在分发者节点日志中查找系统交易插入记录。

**预期日志**：
```
DEBUGLOG [SLASH] Inserted <N> EVIDENCE + <M> PUNISHMENT system transactions
```

**验证方法**：
- 确认该日志出现在 VRF input hash 计算日志之前。
- 确认其他节点也能正常验证 VRF（说明 input hash 一致）。

**判定**：日志出现 `Inserted ... system transactions` 且后续 VRF 验证通过 → **通过**。

---

### V-2: EVIDENCE/PUNISHMENT 参与 input hash

**目标**：验证系统交易参与 VRF input hash 计算后，所有节点的 VRF 验证能通过。

**前置条件**：
- 无需修改代码。

**步骤**：
1. 在有系统交易的批次中，观察所有节点的 VRF 验证结果。
2. 确认没有因 input hash 不一致导致的 VRF 失败。

**预期**：
- 所有节点日志中不出现因 slashing 系统交易导致的 VRF 验证失败。
- 区块正常确认。

**判定**：VRF 验证全部通过，区块正常出块 → **通过**。

---

### V-3: 打包者丢弃系统交易

**目标**：验证如果打包者丢弃系统交易，验证端 input hash 不一致导致 VRF 失败。

**前置条件**：
- 修改打包者节点代码：在构造 `ContractPackagerMsg` 时，故意不包含已插入的 EVIDENCE/PUNISHMENT 系统交易。

**步骤**：
1. 触发 evidence/punishment 流程。
2. 修改后的打包者丢弃系统交易，发送不包含系统交易的区块。
3. 检查验证节点日志。

**预期**：
- 验证节点计算的 input hash 与打包者不同。
- VRF 验证失败，区块被拒绝。

**预期日志**（验证节点）：
```
VRF verification failed: input hash mismatch
```
（具体日志文本以实际代码为准）

**判定**：验证节点 VRF 失败，区块被拒绝 → **通过**。

---

### V-4: EVIDENCE identity 使用分发者地址

**目标**：验证 EVIDENCE 交易的 `identity` 等于当前分发者地址，保持 `ContractPackagerMsg` 内 identity 一致。

**前置条件**：
- 无需修改代码。

**步骤**：
1. 触发 evidence 流程。
2. 获取 EVIDENCE 交易的原始数据（通过 RPC 或日志）。
3. 确认 `identity` 字段等于当前分发者地址。

**预期日志**：
```
INFOLOG [SLASH] Built EVIDENCE tx: hash=<HASH>, signatures=<N>
```

**验证方法**：
- 从 EVIDENCE 交易数据中提取 `identity` 字段。
- 与当前轮次的分发者地址对比。
- 确认 `ContractPackagerMsg` 中所有交易（普通交易、合约交易、EVIDENCE、PUNISHMENT）的 identity 一致。

**判定**：所有交易 identity 一致，区块正常打包 → **通过**。

---

## 8. RPC 查询测试

### R-1: GetThresholdNodes

**目标**：验证返回正确的 level、violation_type、evidence_refs。

**前置条件**：
- 至少一个节点已达到惩罚阈值。

**步骤**：
```bash
curl -s "http://192.168.1.161:13134/GetThresholdNodes"
```

**预期响应**：
```json
{
  "threshold_nodes": [
    {
      "addr": "<TARGET_ADDR>",
      "level": "3",
      "violation_type": "LOW_SIGN_RATE",
      "evidence_refs": "<EVIDENCE_HASH>"
    }
  ],
  "status": "success"
}
```

**判定**：返回的节点列表包含目标节点，字段值与预期一致 → **通过**。

---

### R-2: GetPunishmentList

**目标**：验证按地址返回 punishment_id、tx_hash、level、period。

**前置条件**：
- 目标节点至少有一次 punishment 记录。

**步骤**：
```bash
curl -s "http://192.168.1.161:13134/GetPunishmentList?addr=<ADDR>"
```

**预期响应**：
```json
{
  "punishments": [
    {
      "punishment_id": "<ID>",
      "target_addr": "<ADDR>",
      "period": <PERIOD>,
      "penalty_level": 3,
      "tx_hash": "<TX_HASH>"
    }
  ]
}
```

**判定**：返回的列表包含已执行的 punishment，字段完整 → **通过**。

---

### R-3: GetPunishmentDetail

**目标**：验证返回 target、level、violation_type、evidence_refs、punishment_id。

**前置条件**：
- 已知 punishment_id 或 tx_hash。

**步骤**：
```bash
curl -s -X POST http://192.168.1.161:13134/GetPunishmentDetail \
  -d '{"punishment_id":"<ID>"}'
```

**预期响应**：
```json
{
  "target_addr": "<ADDR>",
  "penalty_level": 3,
  "violation_type": "LOW_SIGN_RATE",
  "evidence_refs": "<EVIDENCE_HASH>",
  "punishment_id": "<ID>",
  "stake_refs": ["<STAKE_UTXO_HASH_1>", "<STAKE_UTXO_HASH_2>"]
}
```

**判定**：所有字段非空且值正确 → **通过**。

---

## 9. 回归测试

### 基础功能回归

| 编号 | 场景 | 操作 | 预期 |
|------|------|------|------|
| REG-1 | 普通转账 | 通过 RPC 发起正常转账交易 | 交易成功确认，余额正确变化 |
| REG-2 | 质押 | 发起 STAKE 交易 | 质押成功，节点出现在质押列表 |
| REG-3 | 解除质押 | 发起 UNSTAKE 交易 | 解除质押成功 |
| REG-4 | 委托 | 发起 DELEGATE 交易 | 委托成功 |
| REG-5 | 投票 | 发起 VOTE 交易 | 投票成功 |
| REG-6 | 部署合约 | 发起 DEPLOY 交易 | 合约部署成功 |
| REG-7 | 调用合约 | 发起 CALL 交易 | 合约调用成功 |
| REG-8 | 合约池 00:00-01:00 回归 | 在 UTC `00:00-01:00` 执行 CALL/DEPLOY 或 `33. test contract pool` | 合约交易正常上链，不受 `CanReward=false` 影响 |
| REG-9 | ExclusionProof 回归 | 执行原有 ExclusionProof 相关流程 | 行为与 slashing 合入前一致 |

### 构建验证

```bash
# 编译通过
cmake --build build -j$(nproc)
# 预期：0 errors, 0 warnings

# 无内存/地址 sanitizer 报错（如启用了 ASAN）
```

### 无系统交易时的 VRF

```bash
# 在没有 evidence/punishment 的普通轮次中
# 确认 VRF 行为不变：区块正常出块，VRF 验证通过
```

---

## 10. 测试执行建议

### 10.1 推荐测试顺序

1. **回归测试**：先确认基础功能正常。
2. **E-7, P-10**：先验证正常路径能走通。
3. **E-1 ~ E-5, E-8 ~ E-11**：EVIDENCE 验证拒绝类测试。
4. **E-6**：EVIDENCE 幂等测试。
5. **P-1 ~ P-9**：PUNISHMENT 验证拒绝类测试。
6. **X-1 ~ X-5**：执行流程测试（按顺序，因为后续测试依赖前面的状态）。
7. **V-1 ~ V-4**：VRF 批次测试。
8. **R-1 ~ R-3**：RPC 查询测试（可在任何阶段执行）。
9. **X-6, X-7**：回滚测试（需要分叉工具，最后执行）。

### 10.2 每轮测试前检查清单

- [ ] 所有 6 个 LAN 节点在线且运行标准代码。
- [ ] 日志已清理。
- [ ] `GetSlashStats` 显示所有节点 ACTIVE。
- [ ] 作恶节点（如需）已编译并启动。
- [ ] 确认当前分发者是谁（影响谁构造系统交易）。

### 10.3 测试记录模板

每条测试用例执行后记录：

```
测试编号: E-1
执行时间: 2026-07-01 14:30
作恶节点修改: 篡改 evidence_hash（dispatchtx.cpp:XXXX）
结果: 通过/失败
关键日志:
  [162] ERRORLOG [SLASH] Invalid EVIDENCE tx evidence hash, tx_hash:abc..., evidence_hash:bad...
RPC 响应:
  GetEvidenceCount → {"evidence_counts":{"DOUBLE_SIGN_VRF":0},"status":"success"}
备注: 无
```


### 10.4 开发阶段与上线前执行边界

开发阶段优先执行第 3.5 节轻量验证。轻量验证只证明基础结构、RPC、日志、交易路径和空状态正常，不等同于完整惩罚机制覆盖。

上线前完整测试应在功能冻结后执行：

1. 从 release candidate commit 临时派生作恶节点补丁程序。
2. 用作恶节点执行 E/P/X/V/R 全部测试项。
3. 测试结束后丢弃作恶节点补丁，不合入正式发布分支。
4. 回到干净 release commit 重新编译正式版本。
5. 对正式版本再次执行轻量验证和基础回归，确认无作恶开关、注入 RPC 或测试配置残留。

作恶节点补丁程序只允许用于测试网，不作为主网候选版本发布。

---

## 附录 A: 作恶节点修改指南

以下是上线前完整测试阶段作恶节点临时补丁的修改位置和思路。具体行号以当前分支代码为准。作恶节点补丁只从 release candidate 临时派生，测试完成后丢弃，不合入正式发布分支。

### A.1 VRF 双签（E-7, X-5）

**修改文件**：`ca/vrf_consensus.cpp`
**思路**：在 VRF 签名函数中，对同一 seed 产生两个不同的签名。保留原签名，额外生成一个不同签名并广播。
**注意**：其他节点在验证 VRF 时会检测到双签并构造 `SlashEvidenceMsg`。

### A.2 区块双签（E-8）

**修改文件**：`ca/algorithm.cpp`（区块签名相关逻辑）
**思路**：在同一高度签署两个不同的区块 hash。

### A.3 低签名率（X-2, X-3, X-4）

**无需修改代码**。最简单的方法是让作恶节点保持在线但不参与签名：
- 方法 A：修改节点使其跳过签名步骤（在签名逻辑前加 `return`）。
- 方法 B：直接停止作恶节点，等待足够长时间后重启。

### A.4 构造无效 EVIDENCE（E-1 ~ E-5, E-8 ~ E-11）

**修改文件**：`ca/dispatchtx.cpp`（`buildEvidenceTransactions()` 函数）
**思路**：根据不同测试需求，在构造 EVIDENCE 交易后、广播前，篡改特定字段：

| 测试 | 修改点 |
|------|--------|
| E-1 | 篡改 `evidence_hash` 字段 |
| E-2 | 删除一个签名，只保留 2 个 |
| E-3 | 替换某个签名为无效签名 |
| E-4 | 复制同一地址的签名 |
| E-5 | 使用非质押节点的密钥签名 |
| E-8 | DOUBLE_SIGN_BLOCK 中复制 block hash |
| E-9 | LOW_SIGN_RATE 中设 `sign_rate = 0.60` |
| E-10 | 设 `violation_type = MALICIOUS_REPORTING` |
| E-11 | 分别设 `violation_type` 为 INVALID_BLOCK 等 |

### A.5 构造无效 PUNISHMENT（P-1 ~ P-8）

**修改文件**：`ca/dispatchtx.cpp`（`buildPunishmentTransactions()` 函数）
**思路**：在构造 PUNISHMENT 交易后、签名前或签名后，篡改特定字段：

| 测试 | 修改点 |
|------|--------|
| P-1 | 篡改 `punishment_id` |
| P-2 | 使用错误密钥签名 |
| P-3 | identity 和签名使用不同地址 |
| P-4 | 使用已取消质押的地址签名 |
| P-5 | 选择无 threshold 状态的节点作为 target |
| P-6 | 修改 `penalty_level` 或 `violation_type` |
| P-7 | 删除或错误设置 `stake_refs` |
| P-8 | 替换 `stake_refs` 中的 hash |

### A.6 丢弃系统交易（V-3）

**修改文件**：`ca/dispatchtx.cpp`（系统交易插入后、构造 `ContractPackagerMsg` 前）
**思路**：在插入 EVIDENCE/PUNISHMENT 到 `filtered_tx_msgs` 后，在构造最终 `ContractPackagerMsg` 时将其移除。

---

## 附录 B: 快速验证脚本

以下脚本可用于自动化部分检查：

```bash
#!/bin/bash
# check_slashing_status.sh — 快速检查所有节点的 slashing 状态

NODES="161 162 163 164 165 166"

echo "=== Global Stats ==="
curl -s "http://192.168.1.161:13134/GetSlashStats" | python3 -m json.tool

echo ""
echo "=== Threshold Nodes ==="
curl -s "http://192.168.1.161:13134/GetThresholdNodes" | python3 -m json.tool

echo ""
echo "=== Tombstoned Nodes ==="
curl -s "http://192.168.1.161:13134/GetTombstonedNodes" | python3 -m json.tool

echo ""
echo "=== Jailed Nodes ==="
curl -s "http://192.168.1.161:13134/GetJailedNodes" | python3 -m json.tool

echo ""
echo "=== Per-Node Status ==="
for i in $NODES; do
  ADDR=$(curl -s "http://192.168.1.$i:13134/GetSlashNodeStatus?addr=" | python3 -c "import sys,json; print(json.load(sys.stdin).get('addr','?'))" 2>/dev/null)
  echo "192.168.1.$i: checking..."
  curl -s "http://192.168.1.$i:13134/GetSlashStats" | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(f'  stake={d.get(\"total_stake_nodes\",\"?\")} active={d.get(\"active_nodes\",\"?\")} jailed={d.get(\"jailed_nodes\",\"?\")} tombstoned={d.get(\"tombstoned_nodes\",\"?\")}')
" 2>/dev/null
done
```

```bash
#!/bin/bash
# collect_logs.sh — 收集所有节点日志到本地目录

RUN_DIR="test_logs/run_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$RUN_DIR"

for i in 161 162 163 164 165 166; do
  scp test@192.168.1.$i:/home/test/biz/logs/openhive_*.log "$RUN_DIR/${i}.log" 2>/dev/null
  echo "Collected from 192.168.1.$i"
done

cp build/bin/logs/openhive_*.log "$RUN_DIR/local.log" 2>/dev/null
echo "Collected local logs"

echo "All logs in $RUN_DIR"
ls -la "$RUN_DIR"
```

```bash
#!/bin/bash
# grep_slash_logs.sh — 从收集的日志中提取所有 [SLASH] 条目
# 用法: ./grep_slash_logs.sh <log_dir>

LOG_DIR=${1:-test_logs/run_latest}

echo "=== Slashing Log Summary ==="
for f in "$LOG_DIR"/*.log; do
  NODE=$(basename "$f" .log)
  COUNT=$(grep -c '\[SLASH\]' "$f" 2>/dev/null || echo 0)
  echo "$NODE: $COUNT slashing log entries"
  if [ "$COUNT" -gt 0 ]; then
    grep '\[SLASH\]' "$f" | while read -r line; do
      echo "  $line"
    done
  fi
done
```
