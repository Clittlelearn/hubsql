# 证据收集与 EVIDENCE 校验

## 1. 设计原则

1. 检测节点可以发现并提交证据，但不能单点决定惩罚。
2. 分发者只负责收集、聚合和构造系统交易，不能绕过链上验证。
3. 上链后的 EVIDENCE 必须自包含，验证者不能依赖自己的内存证据池判断真假。

## 2. SlashEvidenceMsg

```protobuf
message SlashEvidenceMsg {
  string version = 1;
  string target_addr = 2;
  SlashViolationType violation_type = 3;
  bytes evidence_data = 4;
  string evidence_hash = 5;
  uint64 period = 6;
  string reporter = 7;
  CSign signature = 8;
}
```

要求：`evidence_hash = SHA256(evidence_data)`；`signature` 是 reporter 对 `evidence_hash` 的签名；`GenerateAddr(signature.pub()) == reporter`。

## 3. 证据池行为

`SlashEvidencePool` 按 `evidence_hash` 聚合签名：

1. 收到消息后验证 hash、签名、reporter 地址匹配。
2. 同一 `evidence_hash` 下按签名地址去重。
3. 签名数达到 `global::ca::kSlashEvidenceQuorum` 后标记 `consensusReached`。
4. 分发者构造 EVIDENCE 交易后从 pool 移除。
5. 如果 `evidence_on_chain_{hash}` 已存在，则跳过并清理内存项。

`kSlashEvidenceQuorum = global::ca::kConsensus`。开发网络当前为 3，主网共识改为 7 时自动跟随。

## 4. EVIDENCE 交易

- `type = TxType::EVIDENCE`。
- `identity = 当前分发者地址`，用于保持 `ContractPackagerMsg` 内交易 identity 一致。
- `data` 包含 `target_addr`、`violation_type`、`evidence_hash`、`evidence_data`。
- `signature` 列表包含达到 quorum 的举证签名。

链上验证会检查交易 hash、payload、签名数量、签名有效性、签名者是否为不重复的当前质押节点。

## 5. 当前支持的 evidence_data 格式

### DOUBLE_SIGN_VRF

```json
{
  "seed": "VRF seed",
  "existing_sig": "原签名",
  "new_sig": "新签名",
  "existing_sig_hash": "可选，SHA256(existing_sig)",
  "new_sig_hash": "可选，SHA256(new_sig)",
  "detection_time": "可选"
}
```

### DOUBLE_SIGN_BLOCK

```json
{
  "height": 100,
  "existing_block_hash": "64 hex chars",
  "new_block_hash": "64 hex chars"
}
```

### LOW_SIGN_RATE

```json
{
  "sign_rate": 0.42,
  "period": 123,
  "signed_count": 42,
  "valid_periods": 100
}
```

## 6. 暂未启用的类型

`INVALID_BLOCK`、`VRF_VERIFY_FAIL`、`FREQUENT_DISCONNECT`、`MALICIOUS_REPORTING` 保留枚举，但链上 payload 校验未实现，当前 EVIDENCE 会被拒绝。启用前必须补充证据 JSON schema、复验算法和测试用例。

## 7. 防风暴策略

设计意图是单播给当前分发者并使用随机退避，避免全网广播。即使多个节点同时构造相同 EVIDENCE，也会通过 `evidence_hash` 和 `EVIDENCE_ON_CHAIN` 幂等去重。
