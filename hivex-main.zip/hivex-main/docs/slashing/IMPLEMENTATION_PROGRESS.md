# Slashing 实施进度

**分支**: `tmp_merge_dev_slashing_2026-6-20_2_main`
**最后同步**: 2026-06-30

## 本轮审计修复已完成

| 提交 | 内容 |
|------|------|
| `f880daf` | `refactor(slashing): establish punishment identity model` |
| `510824e` | `fix(slashing): validate evidence signatures` |
| `ed4368f` | `fix(slashing): validate deterministic punishments` |
| `61ae856` | `fix(slashing): preserve stake state during punishments` |
| `d9631f3` | `fix(slashing): validate evidence payloads` |
| `3be4241` | `fix(slashing): align evidence identity for system batches` |

## 验证结果

- `cmake --build build -j$(nproc)` 通过。
- `git diff --check` 通过。
- 工作区在最终检查时为 clean。
- 旧字段/旧逻辑扫描无命中：可信自报惩罚金额、按地址惩罚幂等、硬编码 quorum、简化恶意举报校验等。

## 当前状态

Slashing 核心路径已从早期设计稿修正为确定性实现：

- EVIDENCE 自包含验证。
- PUNISHMENT 从链上 threshold 和 stake refs 派生。
- 幂等主键从地址切换为 `punishment_id`。
- 系统交易在 VRF 前插入并参与统一 input hash。
- 未定义证据格式的类型暂时拒绝上链。

## 后续未完成项

- `INVALID_BLOCK`、`VRF_VERIFY_FAIL`、`FREQUENT_DISCONNECT`、`MALICIOUS_REPORTING` 的确定性 payload 规则。
- 规范化多证据 `evidence_refs` 集合。
- 举证奖励设计与实现。
- 多节点集成测试。
