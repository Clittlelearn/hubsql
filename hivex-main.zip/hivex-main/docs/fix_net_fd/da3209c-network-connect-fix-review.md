# `da3209c` 网络连接修复审查记录

## 基本信息

- 分支：`fix_consensus`
- 审查提交：`da3209c00ccc39d88b3cc21cf08be471cc86d866`
- 提交说明：`fix net connect failed`
- 审查日期：2026-07-11
- 涉及文件：
  - `net/epoll_mode.cpp`
  - `net/unregister_node.cpp`

## 总体结论

该提交找到了 16 节点局域网互连失败的一个真实原因，但修复并不完整，bootstrap 部分仍有明显逻辑问题。因此，不建议直接认定该提交完全正确。

如果现场是 16 台独立机器，每台机器使用不同的 `192.168.x.x` 地址，那么针对私网取消 `/16` 连接限制是对症的，能够解决主要连接瓶颈。

如果现场是同机多端口，或者多个节点经同一 NAT、代理表现为相同源 IP，该提交不能解决问题。

## 提交修改内容

### 1. 私网 IPv4 不再受 `/16` 子网连接数量限制

`net/epoll_mode.cpp` 新增 `IsPrivateOrLocalIPv4()`，识别以下地址：

- `127.0.0.1`
- `0.0.0.0`
- `10.0.0.0/8`
- `172.16.0.0/12`
- `192.168.0.0/16`
- `169.254.0.0/16`

只有公网来源才执行 `kMaxConnectionsPerSubnet16` 检查；统计公网 `/16` 连接数量时也跳过私网节点和 `publicIp == 0` 的节点。

### 2. 调整入站连接比例限制的启用条件

原条件为：

```cpp
inboundCount >= maxInbound && totalConnections > kMinOutboundConnections
```

修改后为：

```cpp
outboundCount >= kMinOutboundConnections && inboundCount >= maxInbound
```

这意味着只有节点已经建立至少 8 条出站连接后，才启用 70% 入站比例限制。

### 3. 增强 bootstrap 自连接过滤

`net/unregister_node.cpp` 新增：

- `isLocalEndpoint()`：识别无效 endpoint、本地地址、自身监听地址、自身公网地址及 loopback 地址。
- `buildBootstrapNode()`：构造 bootstrap 节点时统一过滤自身 endpoint。

过滤后不存在远端 bootstrap endpoint 时，函数直接返回成功。

### 4. 保存干净的重试节点对象

首次连接前复制一份 `retryNode`。这是因为 `registerNodeRequest()` 最终调用 `PeerNode::ConnectNode(Node&)`，成功建立 TCP 连接后会修改：

- `node.fd`
- `node.publicPort`
- `node.listenPort`
- `node.connectedEndpoint`
- `node.publicIp`

保留调用前副本，可以避免后续重试直接使用已经被修改的 `Node`。

## 16 节点无法连接的原因分析

代码定义：

```cpp
constexpr int kMaxConnectionsPerSubnet16 = 5;
```

假设 16 台机器地址分别为：

```text
192.168.1.1
192.168.1.2
...
192.168.1.16
```

对任一节点而言，所有对端都属于同一个 `/16`。旧代码统计到 5 条同子网连接后，会从第 6 条相关入站连接开始拒绝，因此无法形成完整的节点连接拓扑。

本提交对私网来源跳过 `/16` 限制，确实可以解决“16 台机器拥有不同私网 IP”这一特定场景。

## 审查发现

### 高：全部首次连接失败时不会执行重试

`startRegistrationNode()` 首次等待响应后存在以下逻辑：

```cpp
if (!dataMgrPtr.WaitData(msgId, returnDatas))
{
    if (returnDatas.empty())
    {
        return false;
    }
}
```

重试逻辑位于这段代码之后。因此：

- 所有 bootstrap 节点首次连接失败时，`returnDatas` 为空，函数直接返回，不会重试。
- 只有部分节点成功、部分节点失败时，才可能进入重试。

这与“失败 endpoint group 重试一次”的设计目标不一致。

建议先执行 `failedNodes` 重试，再综合首次和重试响应判断最终结果。

### 高：同机不同端口的节点会被误判为自身

`isLocalEndpoint()` 只比较地址，没有同时比较监听端口。例如：

```text
127.0.0.1:10001
127.0.0.1:10002
127.0.0.1:10003
```

在同一主机运行多个节点时，所有 `127.0.0.1` endpoint 都会被过滤，而不只是当前节点自己的 endpoint。

自身 endpoint 判断应同时匹配地址和端口。对于存在公网映射的场景，还应明确比较 listen endpoint 和 public endpoint 各自对应的端口。

### 高：同源 IP 仍然最多只允许 3 条连接

当前代码仍然定义：

```cpp
constexpr int kMaxConnectionsPerIP = 3;
```

因此以下环境仍无法完成 16 节点连接：

- 同一主机不同端口；
- Docker 或容器网络经同一个源地址到达；
- 多个节点经同一个 NAT 或代理连接。

私网 `/16` 豁免不会绕过每 IP 连接限制。

是否需要调整该限制，应根据现场连接看到的实际源 IP 判断，不宜直接永久取消。可以考虑在明确的可信 LAN/test 模式下配置化放宽。

### 中：入站比例计算没有考虑正在接收的新连接

当前实现根据现有连接计算：

```cpp
int maxInbound = totalConnections * kMaxInboundRatio / 100;
if (outboundCount >= kMinOutboundConnections && inboundCount >= maxInbound)
```

正在判断的新入站连接尚未计入，且整数除法与 `>=` 会产生边界偏差。

更准确的判断形式是：

```cpp
const bool exceedsInboundRatio =
    (inboundCount + 1) * 100 >
    (totalConnections + 1) * kMaxInboundRatio;
```

然后再结合最小出站连接条件决定是否拒绝。

### 中：私网自动绕过安全策略不够灵活

`/16` 限制原本用于降低 eclipse attack 风险。本提交只要发现来源属于私网，就全面跳过该限制。

这对可信局域网测试环境合理，但不适合作为所有部署环境的固定策略。建议改成显式配置，例如：

```text
enable_private_subnet_limit=false
```

或者提供 `lan/test` 网络模式，只有在管理员明确启用时才放宽限制。

### 中：IPv4 地址分类不完整

当前函数只识别精确的 `127.0.0.1`，没有覆盖整个 `127.0.0.0/8`；也没有处理 `100.64.0.0/10` 等共享地址空间。

建议不要通过字符串前缀和 `stoi()` 实现地址分类，应将地址转换到主机字节序后用掩码判断，或者复用一个统一、经过测试的 IP 分类函数。

### 中：公网 `/16` 的整数计算依赖字节序

`IpPort::IpNum()` 使用 `inet_addr()`，保存的是网络字节序值。当前代码直接执行：

```cpp
(u32_ip >> 16) & 0xFFFF
```

这种写法不够明确，并可能导致不同主机字节序下的语义问题。建议先使用 `ntohl()` 转为主机字节序，再取得高 16 位；或者直接比较 IPv4 地址的前两个网络字节。

## 场景判断

| 部署场景 | 本提交是否有效 | 原因 |
| --- | --- | --- |
| 16 台机器，各自使用不同的 `192.168.x.x` | 大概率有效 | 私网不再受同 `/16` 最多 5 条连接限制 |
| 同一主机、相同 IP、不同端口 | 无效 | endpoint 会被误判为自身，且每 IP 最多 3 条连接 |
| 多容器对端显示为相同源 IP | 无效或不完整 | 仍受每 IP 3 条连接限制 |
| 多节点经相同 NAT/代理源 IP | 无效或不完整 | 仍受每 IP 3 条连接限制 |
| 所有 bootstrap 首次连接均失败 | 重试无效 | 首次等待无响应时提前返回 |
| 公网节点 | 行为基本保持不变 | 仍执行 `/16` 限制，但字节序实现需要修正 |

## 建议的后续修改顺序

1. 修正全部首次失败时提前返回，确保失败节点真正执行重试。
2. 自连接判断改为 endpoint 级比较，即地址与端口同时匹配。
3. 明确 16 节点现场是否每台机器有独立源 IP；若没有，设计可配置的可信 LAN 每 IP 限制。
4. 使用接收新连接后的数量计算入站比例。
5. 将私网 `/16` 豁免改为显式配置，而不是自动永久放宽。
6. 统一实现 IPv4 网段分类及 `/16` 比较，消除字符串判断和字节序风险。
7. 补充自动化测试及真实 16 节点部署验证。

## 建议测试用例

至少增加以下测试：

1. 16 个不同 `192.168.1.x` 地址均可通过 `/16` 检查。
2. 公网同 `/16` 的第 6 条连接仍被拒绝。
3. 同地址不同端口时，只过滤当前节点自身端口。
4. 全部 bootstrap 首次失败时仍会执行一次重试。
5. 部分 bootstrap 成功、部分失败时仅重试失败节点。
6. `registerNodeRequest()` 修改 `Node` 后，重试使用未污染的 endpoint 数据。
7. 入站比例在 70% 边界以下允许，超过边界拒绝。
8. IPv4-mapped IPv6、原生 IPv6 和 `publicIp == 0` 场景行为明确。
9. 同源 IP 超过 3 条连接时，在默认模式与可信 LAN 模式下分别符合配置预期。

## 验证状态

本次审查基于提交差异、连接限制常量及相关调用链进行静态分析。仓库中未发现覆盖上述 16 节点网络场景的现成自动化测试，也尚未在真实 16 节点环境中验证。

在修改前，建议先收集现场日志中的以下拒绝原因：

```text
Connection rejected: subnet /16 limit reached
Connection rejected: per-IP limit reached
Connection rejected: inbound ratio limit reached
Skip self endpoint during bootstrap
wait startRegistrationNode time out
```

通过实际日志可以确定现场主要受 `/16`、每 IP 限制、自连接过滤还是 bootstrap 超时影响。
