# 网络连接与 FD 生命周期修复方案

## 1. 文档目的

本文档记录基于 `655fe8920b848c577fe0aaa918f93ea9b843ec2c` 开始实施的网络连接修复方案、设计约束、实施阶段、检查点和测试计划。

本次修改来源于对 `da3209c00ccc39d88b3cc21cf08be471cc86d866` 的审查，以及对后续 `23b3ba63b26bae86e496f9f421cfb8036c03c862` 中 FD 去重修改的分析。

相关审查文档：

- `docs/fix_net_fd/da3209c-network-connect-fix-review.md`

工作分支：

- `fix_network_connection_lifecycle`
- 起点：`655fe8920b848c577fe0aaa918f93ea9b843ec2c`

## 2. 背景与主要问题

`da3209c` 修复了 16 个不同私网 IP 节点受同一 `/16` 最多 5 条连接限制的问题，但仍存在以下缺陷：

1. bootstrap 首次全部失败时提前返回，函数内部重试不会执行。
2. bootstrap 重试没有完整描述 TCP、密钥交换、注册请求和 ACK 的状态，可能产生重复连接。
3. 密钥交换或注册超时后，已创建的 FD 可能没有被关闭。
4. bootstrap 自连接判断只比较地址，会误伤同机不同端口节点。
5. Docker、NAT 或代理后的多个节点可能共享来源 IP，现有 per-IP 和注册检查会错误拒绝不同身份节点。
6. 入站比例没有把正在接收的新连接计入计算。
7. IPv4 私网分类和公网 `/16` 比较依赖字符串解析及不明确的字节序。
8. Primary、Test、Dev 三类网络的准入策略没有统一；当前只有 Primary 明确拒绝内网地址。
9. 现有等待器以 `IP:port` 匹配响应，在 Docker、NAT、IPv6 和端口字段被改写的场景中不够可靠。

`23b3ba6` 尝试解决同一身份对应重复 FD 的问题，但采用“新 FD 绑定后立即关闭旧 FD”的方式，可能产生稳定旧连接被不稳定新连接替换、延迟事件操作复用 FD、指标不一致等风险。本次修复不得直接复制该方案，也不得依赖心跳超时来掩盖连接状态错误。

## 3. 已确定的设计原则

### 3.1 身份、来源地址和 endpoint 分离

必须区分：

- TCP 来源地址：接收端实际看到的 source IP 和临时端口；
- advertised endpoint：节点声明的可连接地址和监听端口；
- 节点身份：经过签名验证的节点 address、identity 和公钥。

节点的逻辑唯一键应为经过验证的节点身份，不能使用 IP、端口或 endpoint 代替身份。

### 3.2 网络类型决定准入策略

网络类型来源于 genesis：

- `Genesis::NetworkType::Primary`
- `Genesis::NetworkType::Test`
- `Genesis::NetworkType::Dev`

计划采用以下默认策略：

| 策略 | Primary | Test | Dev |
| --- | --- | --- | --- |
| 允许内网来源 | 否 | 否 | 是 |
| 要求可用公网 advertised endpoint | 是 | 是 | 否 |
| 允许不同身份共享来源 IP | 否 | 否 | 是 |
| per-IP 限制 | 启用 | 启用 | 关闭 |
| 公网 `/16` 多样性限制 | 启用 | 启用 | 关闭 |
| 入站比例限制 | 启用 | 启用 | 默认关闭 |
| endpoint 级自连接过滤 | 启用 | 启用 | 启用 |
| 身份级自连接与重复身份检查 | 启用 | 启用 | 启用 |
| 全局连接/节点上限 | 启用 | 启用 | 启用 |

本次不再增加可能和 genesis 网络类型冲突的 `trusted_lan` 开关。

### 3.3 Dev 网络允许共享 IP，不允许共享身份

Dev 网络需要支持多个容器经同一个 Docker 网络、NAT 或代理连接，允许：

- 不同身份使用相同来源 IP；
- 同 IP 不同端口节点；
- 私网 IPv4、IPv6 ULA 和 loopback 测试 endpoint。

Dev 网络仍然禁止：

- 同一经过验证的身份作为多个逻辑节点存在；
- 使用 `0.0.0.0`、`::` 等不可连接地址作为远端 endpoint；
- 未通过 identity、address 和签名验证的节点加入。

如果多个容器公布完全相同的 `IP:port`，协议无法把该 endpoint 路由到不同容器。部署侧必须提供不同容器 IP、不同宿主机映射端口、不同可解析服务名或具备目标路由能力的代理。

### 3.4 自连接采用两阶段判断

连接前只能过滤明确的本机 endpoint：

```text
标准化地址相同 && 监听端口相同
```

本机 endpoint 集合应包含：

- `Config::GetEndpoints()` 中的全部 endpoint；
- `selfNode.endpoints`；
- 兼容字段中的 listen/public 地址和对应端口。

不能因为目标 IP 等于本机 IP、loopback 或 `global::g_localIp` 就直接认定为自己。

握手和身份验证完成后，使用经过验证的节点 address 与本节点 address 比较，最终拒绝自连接。

### 3.5 掩码只负责地址分类，不负责节点数量

IPv4 地址统一转换为主机字节序后使用数值掩码判断。至少覆盖：

- `0.0.0.0/8` 中需要明确拒绝的未指定/保留地址；
- `10.0.0.0/8`；
- `100.64.0.0/10`；
- `127.0.0.0/8`；
- `169.254.0.0/16`；
- `172.16.0.0/12`；
- `192.168.0.0/16`。

公网 `/16` 计算必须先执行 `ntohl()`，再取高 16 位。

“Dev 最多允许 255 个节点”应由独立的 peer/connection 上限表达，不能通过 `/24`、`/16` 或 per-IP 掩码间接表达。若上限包含本节点，每个节点最多有 254 个远端 peer；实现前需明确常量口径。

## 4. Bootstrap 与 FD 生命周期设计

### 4.1 批次 ID 与 attempt ID

统一重新部署所有节点，不考虑旧协议兼容。因此在注册协议中增加独立 `attempt_id`。

语义：

```text
msg_id      = 一轮 bootstrap/registration 批次
attempt_id  = 批次中一条具体连接尝试
```

计划修改：

```protobuf
message RegisterNodeReq {
  NodeInfo mynode = 1;
  bool is_get_nodelist = 2;
  string msg_id = 3;
  string attempt_id = 4;
}

message RegisterNodeAck {
  repeated NodeInfo nodes = 1;
  string msg_id = 2;
  uint32 from_ip = 3;
  uint32 from_port = 4;
  uint32 fd = 5;
  string from_addr = 6;
  string attempt_id = 7;
}
```

远端必须原样回传 `msg_id` 和 `attempt_id`。

`attempt_id` 应覆盖完整连接尝试：

```text
TCP connect → ECDH key exchange → registration → identity verified
```

密钥交换协议也应携带相同的 `attempt_id`，同时保留密钥交换阶段自己的 `msg_id`，用于阶段等待。

### 4.2 本地 AttemptContext

计划建立显式状态对象，概念结构如下：

```cpp
enum class AttemptState
{
    Created,
    Connecting,
    TcpConnected,
    KeyExchanging,
    KeyEstablished,
    RegisterSent,
    Registered,
    Closing,
    Closed
};

struct ConnectionAttempt
{
    std::string roundId;
    std::string attemptId;
    std::string endpointGroupKey;
    AttemptState state{AttemptState::Created};
    int fd{-1};
    Node originalNode;
    Node connectedNode;
};
```

本地至少维护：

```text
attempt_id → ConnectionAttempt
fd         → attempt_id
group_key  → 当前有效 attempt_id
msg_id     → 当前 bootstrap round
```

### 4.3 状态机

正常路径：

```text
Created
  → Connecting
  → TcpConnected
  → KeyExchanging
  → KeyEstablished
  → RegisterSent
  → Registered
```

任意失败路径：

```text
非终态
  → Closing
  → 清理 buffer/epoll/key/fd/mutex/index
  → Closed
```

必须满足以下不变量：

1. 每个成功创建的 FD 只有一个明确 owner。
2. 任一失败路径都必须关闭并清理该 FD。
3. 只有 `Registered` FD 才能进入 `PeerNode`。
4. 同一 endpoint group 在上一 attempt 未进入 `Closed` 或 `Registered` 前不得重拨。
5. ACK 必须与同一 attempt 和同一本地 FD 对应。
6. `Closing` 或 `Closed` attempt 不得被迟到 ACK 恢复。
7. 重试必须使用未被 `ConnectNode()` 修改的 `originalNode`。

### 4.4 ACK 校验

收到注册 ACK 时必须同时满足：

```text
ACK.msg_id == attempt.roundId
ACK.attempt_id == attempt.attemptId
from.fd == attempt.fd
attempt.state == RegisterSent
```

之后仍需完成：

- 网络类型准入验证；
- NodeInfo 版本验证；
- address、identity、公钥和签名验证；
- 非本节点身份验证。

只有以上全部成功，才允许原子执行：

```text
RegisterSent → Registered
```

协议中的 ID 是关联信息，不是身份凭证，不能替代签名和 FD 校验。

### 4.5 Timeout 与迟到 ACK 竞态

timeout 线程与 ACK 线程必须在同一状态锁下竞争：

```text
ACK 先完成：RegisterSent → Registered
timeout 不能再关闭 FD

timeout 先完成：RegisterSent → Closing → Closed
迟到 ACK 不能再注册节点
```

AttemptContext 的终态记录不能随 `WaitData()` 立即删除，应保留有限时间，便于拒绝迟到 ACK 和排查日志。

不得只在 timeout 后无条件调用 `CloseFd(fd)`，否则可能关闭已经完成注册的连接。

### 4.6 批次等待规则

现有代码在拨号前使用 bootstrap group 数作为期望响应数，这是不准确的。只有进入 `RegisterSent` 的 attempt 才可能产生注册 ACK。

计划流程：

1. 为每个远端 endpoint group 创建 attempt。
2. 并发或顺序完成 TCP 和密钥交换，但不产生重叠 attempt。
3. 收集进入 `KeyEstablished` 的 attempt。
4. 以这些 attempt 的实际数量创建注册批次等待。
5. 使用 `attempt_id` 作为等待器 response ID，而不是 `IP:port`。
6. 发送 RegisterNodeReq，并进入 `RegisterSent`。
7. 在统一 round deadline 内收集响应。
8. 成功 ACK 转为 `Registered`；其余 attempt 原子关闭。

不得为每个 attempt 顺序等待完整 timeout，避免最坏情况下出现 `N × timeout`。

### 4.7 重试策略

移除或停用 `startRegistrationNode()` 内部固定 `sleep(3)` 的重叠重试，统一由现有外层指数退避流程负责下一轮 bootstrap。

重试前必须确认：

- 对应 endpoint group 没有 `Connecting`、`KeyExchanging` 或 `RegisterSent` attempt；
- 上一 attempt 已为 `Closed`，或已经 `Registered` 而无需重试；
- 未确认 FD 已完成清理；
- 已连接的 bootstrap endpoint 不再拨号。

## 5. 入站比例修正

在启用该策略的网络中，使用接收新连接后的数量判断：

```cpp
const bool exceedsInboundRatio =
    (inboundCount + 1) * 100 >
    (totalConnections + 1) * kMaxInboundRatio;
```

然后结合最小出站连接条件：

```cpp
outboundCount >= kMinOutboundConnections
```

正好达到 70% 不应拒绝，只有超过 70% 才拒绝。日志必须打印接收新连接后的数量。

Primary 和 Test 默认启用该策略；Dev 默认关闭。

## 6. 重复连接与 `23b3ba6` 的边界

本次不得直接采用“同一身份出现新 FD 时立即关闭旧 FD”的策略。

原因包括：

- 新连接可能尚未完整验证或很快失败；
- 稳定旧连接可能被不稳定新连接替换；
- epoll/工作队列可能仍有旧 FD 的延迟事件；
- FD 数字可能被操作系统复用；
- 指标和逻辑节点状态可能失真。

本次优先确保 bootstrap 不主动制造重叠连接，并保证失败 attempt 的 FD 被明确清理。

如果同一验证身份仍出现两个成功连接，应独立设计确定性的连接仲裁，例如根据双方 address 排序决定保留主动或被动方向。该仲裁必须在新连接完成身份验证后进行，不能以 FD 数字大小决定，也不能与 bootstrap timeout 清理混合。

除非实现与测试明确要求，本次不大规模重构：

- `PeerNode::Add()`；
- `PeerNode::Update()`；
- `PeerNode::DeleteNode()`；
- `PeerNode::delete_by_fd()`；
- `_fdToAddress` 的整体语义。

## 7. Primary/Test 网络规模与拓扑注意事项

公网网络同样可能形成完整 mesh。255 个节点每对只保留一条连接时：

```text
255 × 254 / 2 = 32385 条 TCP 连接
```

若每对节点同时保留两个方向，短期可能接近 64770 条连接。

当前节点发现和 `Register(nodeMap)` 流程具有趋向全互联的可能。公网准入、per-IP、`/16` 和入站比例限制不等同于拓扑控制。

长期应考虑有限邻居拓扑，但该工作不纳入本次修复，以避免扩大范围。本文档实施期间只记录和验证当前拓扑行为，不改变共识层或节点发现总体策略。

## 8. 实施计划与检查点

### 阶段 0：基线与可观测性

任务：

- 固定起点和相关提交差异；
- 梳理 TCP、ECDH、registration、PeerNode 的当前路径；
- 为连接阶段定义统一日志字段；
- 记录现有测试和编译方式。

检查点 CP0：

- 工作分支起点为 `655fe892`；
- 没有带入 `23b3ba6` 的 FD 重构；
- 能从日志关联 round、attempt、fd、group 和状态。

### 阶段 1：统一地址分类与网络策略

任务：

- 实现数值化 IPv4 掩码判断；
- 完善 IPv6 local/private/public 分类；
- 定义统一 NetworkConnectionPolicy；
- Primary/Test 只允许公网节点；
- Dev 允许不同身份共享来源 IP；
- Dev 关闭 per-IP、`/16` 和入站比例限制；
- 修正入站比例公式。

检查点 CP1：

- 所有 IP 判断不再依赖字符串前缀和 `stoi()`；
- `/16` 计算明确使用主机字节序；
- Test 不再意外允许内网节点；
- Dev 共享 IP 的不同身份不会被注册前规则拒绝；
- Primary/Test 的默认安全限制保持生效。

### 阶段 2：endpoint 级自连接过滤

任务：

- 收集完整本机 endpoint 集合；
- 标准化 IPv4、IPv6、loopback 和 hostname；
- 仅对地址和端口同时匹配的本机 endpoint 进行拨号前过滤；
- 保留握手后的身份级自连接拒绝。

检查点 CP2：

- `127.0.0.1:10001` 不会误过滤 `127.0.0.1:10002`；
- 相同 IP 的不同 Docker 节点不会被当成本节点；
- 本节点完整 endpoint 仍会被过滤；
- `0.0.0.0` 和 `::` 不会成为远端连接目标。

### 阶段 3：协议 attempt_id

任务：

- 修改 protobuf；
- 注册请求和 ACK 携带并回显 `attempt_id`；
- 密钥交换请求和响应关联同一 `attempt_id`；
- 增加 ID 格式、长度和唯一性校验；
- 更新生成代码和协议测试。

检查点 CP3：

- round ID 和 attempt ID 语义分离；
- ACK 的 attempt ID 与请求完全一致；
- response ID 不再依赖 `IP:port`；
- 无 attempt 或错误 attempt 的响应不会改变连接状态。

### 阶段 4：AttemptContext 与失败清理

任务：

- 实现 attempt 状态机；
- 建立 attempt、FD、group 和 round 索引；
- 确保 ConnectNode 后所有失败出口统一清理；
- 密钥交换失败、发送失败和验证失败均关闭 FD；
- 使用干净 originalNode 重试。

检查点 CP4：

- 每个创建成功的 FD 都能追溯到 owner；
- 每个非 Registered 终止路径都进入 Closed；
- buffer、epoll、ECDH key、FD mutex 和 socket 清理一致；
- 不通过心跳超时回收 bootstrap 遗留 FD；
- 不出现无 owner 的 epoll socket。

### 阶段 5：Bootstrap round、timeout 与重试

任务：

- 仅按实际 RegisterSent 数量等待；
- 使用统一 round deadline；
- 实现 ACK/timeout 原子状态竞争；
- 清理未确认 attempt；
- 移除内部固定延时重试；
- 外层指数退避只重试已关闭且未注册的 group。

检查点 CP5：

- 全部首次连接失败时不会错误提前跳过清理；
- 部分成功时只处理失败 group；
- ACK 超时不会留下未注册 FD；
- 迟到 ACK 不会复活已关闭 attempt；
- 同一 group 不存在重叠拨号；
- 等待时间不会退化为 `N × timeout`。

### 阶段 6：重复身份连接评估

任务：

- 验证上述修改后是否仍出现同一身份多 FD；
- 区分 bootstrap 重复、双向同时连接和正常重连；
- 若仍需要，设计并实现确定性方向仲裁；
- 不采用新 FD 无条件覆盖旧 FD。

检查点 CP6：

- 同一身份最多保留一个 canonical 连接；
- 稳定连接不会被未完成的新连接替换；
- 落选 FD 被完整清理；
- FD 反向索引、心跳和指标一致。

### 阶段 7：综合验证

任务：

- 单元测试；
- 协议测试；
- 并发和竞态测试；
- Docker 多节点测试；
- Primary/Test 公网策略测试；
- 长时间稳定性测试；
- FD、epoll、buffer、密钥和线程资源检查。

检查点 CP7：

- 所有必测场景通过；
- 无持续增长的 FD、buffer 或 key；
- 无重复身份节点；
- 无明显连接震荡；
- 日志可以解释每次关闭和重试原因；
- 未引入共识或交易路径回归。

## 9. 测试矩阵

### 9.1 地址和策略测试

1. Primary/Test 拒绝 IPv4 私网、loopback、link-local 和未指定地址。
2. Primary/Test 拒绝 IPv6 ULA、loopback、link-local 和未指定地址。
3. Dev 接受有效私网 IPv4、IPv6 ULA 和 loopback endpoint。
4. Dev 拒绝不可连接的 `0.0.0.0` 和 `::` endpoint。
5. 公网同 `/16` 第 6 条连接在 Primary/Test 仍被拒绝。
6. Dev 不受 per-IP 和 `/16` 限制。
7. IPv4-mapped IPv6 分类结果明确且一致。
8. `/16` 结果不依赖主机字节序。

### 9.2 自连接与共享 IP 测试

1. 同地址同端口的本机 endpoint 被过滤。
2. 同地址不同端口不会被过滤。
3. 多个不同身份节点共享来源 IP 时，Dev 全部允许注册。
4. 多个不同身份节点共享来源 IP 时，Primary/Test 按策略拒绝。
5. 远端身份等于本节点身份时，无论 endpoint 如何都拒绝。
6. advertised endpoint 完全相同但身份不同的场景产生明确日志，不误认为同一身份。

### 9.3 attempt 与 FD 测试

1. TCP connect 失败：无 FD 遗留。
2. ECDH 请求发送失败：FD 完整清理。
3. ECDH ACK 超时：FD 完整清理。
4. ECDH ACK 迟到：不能恢复 Closed attempt。
5. RegisterNodeReq 发送失败：FD 完整清理。
6. RegisterNodeAck 超时：FD 完整清理。
7. RegisterNodeAck 迟到：不能注册已关闭 attempt。
8. 错误 round ID：拒绝。
9. 错误 attempt ID：拒绝。
10. 正确 ID 但错误 FD：拒绝。
11. 重复 ACK：幂等处理。
12. 身份或签名验证失败：FD 完整清理。
13. 同一 group 上一 attempt Pending 时禁止重拨。
14. 上一 attempt Closed 后允许下一轮重试。

### 9.4 Bootstrap 行为测试

1. 全部首次 TCP 失败。
2. 全部密钥交换失败。
3. 全部注册 ACK 超时。
4. 部分成功、部分失败。
5. 多个 endpoint 的 group 首选失败、备用成功。
6. 已连接 bootstrap 不再拨号。
7. 统一 deadline 不产生 `N × timeout`。
8. 外层指数退避间隔符合配置。
9. 多轮重试没有重复 FD。

### 9.5 部署测试

1. 16 台不同 `192.168.x.x` 的 Dev 节点。
2. 同一宿主机不同端口的多个 Dev 节点。
3. Docker 共享出口 IP 的多个 Dev 节点。
4. 经过 NAT/代理表现为相同来源 IP 的 Dev 节点。
5. Primary/Test 公网节点互联。
6. Primary/Test 节点试图使用内网 endpoint 加入。
7. 节点同时双向拨号。
8. 网络抖动、延迟 ACK、断开和恢复。
9. 长时间运行后 FD 数、内存、buffer 和 ECDH key 数量稳定。

## 10. 可观测性要求

连接相关日志应尽量统一携带：

```text
network_type
round_id
attempt_id
endpoint_group
endpoint
fd
state_from
state_to
peer_address（验证后）
close_reason
retry_number
```

拒绝原因应明确区分：

- private address rejected；
- per-IP limit；
- subnet limit；
- inbound ratio；
- self endpoint；
- self identity；
- duplicate identity；
- attempt mismatch；
- FD mismatch；
- key exchange timeout；
- registration timeout；
- late ACK；
- invalid signature/identity；
- cleanup failure。

不得记录私钥、完整密钥材料或其他敏感信息。

## 11. 实施注意事项

1. 优先增加纯函数和单元测试，再接入 epoll 和注册流程。
2. 公共 `GlobalDataManager` 被大量共识和交易代码使用，除非必要，不进行破坏性重构。
3. protobuf 修改后必须确认生成代码、构建脚本和所有消息处理路径同步更新。
4. 连接状态和 FD 清理必须由单一 owner 执行，避免多处重复 `close()`。
5. 清理操作应具备幂等性，但不能依赖重复 close；应先原子取得清理所有权。
6. 注意 FD 数字复用，不得仅凭整数 FD 判断事件一定属于原连接。
7. 不以心跳超时作为正常 bootstrap 失败清理机制。
8. 不以新 FD 无条件替换稳定旧 FD。
9. 不以 socket 来源端口当作远端监听端口。
10. 网络准入发生在身份验证前后两个阶段，不能只检查一处。
11. Primary/Test 的公网判断应同时考虑 socket 来源和 advertised endpoint，但不能要求 NAT 场景二者地址完全相同。
12. 修改期间每个阶段独立提交和验证，便于回退及二分定位。
13. 不在本次修复中同时改变共识、交易或完整网络拓扑策略。

## 12. 暂不纳入本次的工作

- Primary/Test 的有限邻居拓扑设计；
- gossip/随机邻居选择；
- 全网最大节点数协议；
- 大规模改写 `PeerNode` FD 索引；
- 未经验证直接合入 `23b3ba6`；
- 依赖旧协议节点的滚动升级兼容；
- 共识层和交易层行为修改。

如综合测试证明同一身份多 FD 仍然存在，再在阶段 6 中单独评审确定性连接仲裁方案。

## 13. 完成标准

本次修复只有同时满足以下条件才视为完成：

1. Primary/Test/Dev 的网络准入行为符合已确定策略。
2. Dev 的 Docker/NAT 共享 IP 不再误拒绝不同身份节点。
3. 自连接过滤不会误伤同 IP 不同端口节点。
4. IPv4/IPv6 地址分类和 `/16` 计算统一、可测试。
5. 入站比例使用接收新连接后的数量计算。
6. 每次连接 attempt 可由 round、attempt 和 FD 精确关联。
7. 所有失败与超时路径都能确定性清理 FD 和相关资源。
8. 迟到 ACK 不会恢复已关闭连接。
9. 同一 endpoint group 不产生重叠 bootstrap 拨号。
10. 不依赖心跳超时使网络最终“碰巧稳定”。
11. 不引入 `23b3ba6` 所暴露的新 FD 覆盖风险。
12. 自动化测试和真实多节点部署验证均通过。
