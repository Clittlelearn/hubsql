# 网络连接生命周期修复进度检查点（2026-07-11）

## 1. 当前状态

- 工作分支：`fix_network_connection_lifecycle`
- 分支起点：`655fe8920b848c577fe0aaa918f93ea9b843ec2c`
- 当前已推送 HEAD：`052ce2b`
- 当前阶段：CP7（专项测试与最终审计）进行中
- CP0 至 CP6 已完成实现和阶段性编译检查
- CP0 至 CP6 已提交并推送；第 8 节记录的 CP7 续接改动尚未提交、尚未推送

今天停止工作时没有运行中的编译或测试进程。原计划开始增加的 `global_data_test` 在命令中断前没有落盘，因此明天可以从干净的测试设计步骤继续，不需要清理半成品文件。

## 2. 检查点完成情况

| 检查点 | 状态 | 内容 |
| --- | --- | --- |
| CP0 | 已完成 | 仓库、分支、protobuf、构建和测试基线确认 |
| CP1 | 已完成 | 按网络类型统一地址分类与准入策略，修正 IPv4 字节序和 `/16` 计算 |
| CP2 | 已完成 | 自连接判断改为标准化 endpoint（地址与端口）级判断 |
| CP3 | 已完成 | 注册与密钥交换协议增加并校验独立 `attempt_id`，同时校验 `network_name` |
| CP4 | 已完成 | 引入 `ConnectionAttempt` 状态机，明确 attempt、FD、round 和清理生命周期 |
| CP5 | 已完成 | 修正 bootstrap 实际发送计数、提前返回、内部重试和 pending attempt 清理 |
| CP6 | 已完成 | 对重复身份连接实施确定性的连接方向仲裁，避免不稳定新 FD 任意替换稳定连接 |
| CP7 | 进行中 | 专项测试、生命周期审计、运行时多节点验证和最终差异检查 |

## 3. 已实施的核心修改

1. 新增统一的网络策略和地址分类模块，区分 Primary、Test、Dev 的公网/内网准入、per-IP、`/16`、入站比例和节点上限策略。
2. Dev 网络允许不同身份共享来源 IP，并以 255 个节点（本节点加最多 254 个远端 peer）作为独立容量约束，不再借助地址掩码表达节点数量。
3. bootstrap 连接前只过滤明确相同的本机 endpoint；握手后再以经过验证的节点身份拒绝自连接。
4. 注册协议及 ECDH 密钥交换携带同一个 `attempt_id`，注册 ACK 必须匹配 round、attempt、本地 FD 和状态。
5. 新增显式连接尝试状态机，失败路径统一清理 PeerNode、ECDH key、索引和 FD；迟到 ACK 不能恢复已关闭 attempt。
6. bootstrap 按实际成功发送的请求数等待响应，移除函数内部睡眠和隐式重试，并在轮次结束时清理未完成 attempt。
7. 修正入站比例公式，把当前正在进入的连接计入比例。
8. 同一节点身份出现重复连接时，根据双方节点地址确定唯一首选连接方向，保留稳定首选连接，不采用“新 FD 无条件替换旧 FD”的方式。
9. 等待 ID 改用单调时钟和原子序列生成，并增加调整期望响应数和取消等待的能力。

## 4. 已完成验证

- `network_policy_test`：7 项全部通过。
- `network_protocol_test`：2 项全部通过。
- 主程序 `openhive`：在多轮关键修改后均成功编译链接。
- 编译统一使用全部 CPU 核心：`cmake --build build --target <target> -j$(nproc)`。
- `git diff --check` 已通过，没有发现空白错误。

聚合 `test` target 当前被既有测试文件 `tests/test_transaction_cache_concurrency.cpp` 中重复的 GTest 用例名阻塞，包括：

- `MultiReaderSingleWriter`
- `WriterMutualExclusion`
- `ReadWriteInterleaving`
- `HighConcurrencyStressTest`

该问题属于本分支起点已有的测试问题，与本次网络修改无关；专项测试通过独立 target 运行。

## 5. 明天继续的顺序

1. 为 `GlobalDataManager` 的动态响应计数、取消等待和 predicate wait 增加独立专项测试。
2. 为 `ConnectionAttemptManager` 增加状态迁移、错误 FD/attempt ACK、超时清理、迟到 ACK、重复关闭等测试。
3. 重跑 `network_policy_test`、`network_protocol_test` 和新增专项测试。
4. 使用 `-j$(nproc)` 完整重编译 `openhive`。
5. 沿 `registerNodeRequest → RegisterNodeAck → WaitData → PeerNode::Add/Update` 再做一次逐路径审计，重点检查 FD 所有权、重复清理、迟到事件和指标变化。
6. 检查所有 diff，确认 protobuf 字段、CMake 源文件、错误返回值和日志语义一致。
7. 规划并执行 Primary/Test 公网策略与 Dev Docker 多节点运行时测试；若本地环境无法搭建，则明确记录未验证项和复现命令。
8. 更新方案文档和本检查点。完成全部验证后再讨论是否提交和推送。

## 6. 尚需重点关注的风险

- 尚未执行真实的多节点或 Docker 共享网络端到端测试。
- FD 数字被操作系统复用时，事件队列中非常陈旧的历史事件仍需在最终审计中重点检查；`attempt_id` 解决协议响应关联，但不能自动给内核 FD 增加 generation token。
- `ConnectionAttemptManager` 和 `GlobalDataManager` 的专项并发/边界测试尚未完成。
- 聚合测试 target 的既有重复用例问题尚未修复，不应误判为本次修改回归。
- 网络拓扑仍是全互联设计；255 个节点产生的大量 TCP 连接属于拓扑层问题，不在本次 FD 生命周期修复范围内。
- protobuf 生成文件未纳入版本控制，构建时需要继续确认生成脚本正确执行。

## 7. 停止点说明

当前适合从 CP7 的第一项继续。不要重新实施 CP0 至 CP6，也不要采用 `23b3ba6` 中“新连接直接关闭旧 FD、等待心跳恢复”的处理方式。下一步首先补齐等待器测试，然后补齐 attempt 生命周期测试；测试或审计发现设计问题时，先讨论再调整核心状态机。

## 8. 续接实施记录

从提交 `052ce2b` 恢复 CP7 后，已完成以下工作：

1. 新增 `GlobalDataManager` 独立专项测试，覆盖实际发送数调整、非法期望数、重复/未知响应、取消唤醒和超时部分响应。
2. 修正 `CancelWait()` 只删除索引却不唤醒活动 waiter 的问题；取消后等待线程会立即返回失败。
3. 新增隔离的 `ConnectionAttemptManager` 专项测试，覆盖出站/入站状态链、round/attempt/FD 匹配、group 并发、迟到 ACK、重复关闭和 FD 唯一绑定。
4. 修正入站 FD 可覆盖既有 attempt binding 的问题。
5. 修正入站注册在 ACK 发送前提前进入 `Registered` 且忽略发送失败的问题；现在 ACK 成功入队后才进入终态，失败由 scope guard 清理 peer、key 和 FD。
6. 修正 `KeyExchangeManager::getKey()` 对同一 `shared_mutex` 递归获取共享锁的问题。
7. 移除 `connection_attempt.cpp` 未使用的重型 include，降低生命周期模块的编译耦合。

本轮验证结果：

- `network_policy_test`：7/7 通过。
- `network_protocol_test`：2/2 通过。
- `global_data_test`：5/5 通过。
- `connection_attempt_test`：6/6 通过。
- 共 20 项专项测试通过。
- `openhive` 使用 `-j$(nproc)` 完整编译链接成功。

运行时多节点验证仍未执行。仓库内没有适用于本修复的 Docker compose 测试环境；现有 VRF 本地多节点脚本共享同一 keystore，会导致所有进程使用相同节点身份，不符合“不同身份可共享 IP、相同身份禁止重复”的验证条件。远程 benchmark 脚本会操作外部 SSH 节点，因此未在本轮擅自运行。

下一步需要准备至少 3 个独立身份的 Dev 节点环境，验证同 IP 不同端口、同时双向连接、bootstrap 部分失败、超时重连、迟到 ACK 和 FD 不重复；Primary/Test 还需在公网地址环境验证内网拒绝策略。

## 9. 三节点测试反馈后的收敛修复（2026-07-12）

虚拟机三节点测试中，少量节点约 30 秒仍缺一个 peer，约 1 分钟后才补齐。审查确认延迟由多项因素共同造成：

- bootstrap 退避间隔为 5、10、20、30 秒；
- 旧逻辑连接任意一个配置 endpoint 即永久认为 bootstrap 完成；
- 周期节点同步默认间隔为 100 秒；
- registration/sync 路径会丢失 advertised endpoints，非默认端口下尤其明显。

本轮未提交修改：

1. 修正非阻塞 socket 使用 `F_GETFD` 的错误，改用 `F_GETFL`。
2. 将 `epoll_wait` 返回值改为有符号整数，并明确处理 3 秒 timeout，避免 pending socket 被误判为连接成功。
3. bootstrap 改为按 endpoint group 计算缺失集合，只重试缺失 group；本轮有进展时退避重置为 5 秒。
4. 已完成的配置 group 后续断开时会重新进入补连状态。
5. 本机 endpoint group 被视为已满足，避免配置包含自身时无限重试。
6. bootstrap 增加单轮互斥，避免首次 round 与后台 retry 重叠拨号。
7. 注册 ACK 验证和节点同步均保留、传播完整 advertised endpoints。
8. 周期同步按实际成功发送数等待；零响应仍进入配置 endpoint 恢复路径。
9. 增加 bootstrap round、缺失 group、TCP timeout、迟到 ACK 和同步失败日志。
10. 增加 registration/sync endpoint protobuf 往返测试。

验证结果：

- `network_policy_test`：7/7 通过。
- `network_protocol_test`：3/3 通过。
- `global_data_test`：5/5 通过。
- `connection_attempt_test`：6/6 通过。
- 共 21 项专项测试通过。
- `openhive` 使用 `-j$(nproc)` 完整编译链接成功。
- `git diff --check` 通过。
- 环境未安装 `clang-format`，未执行自动格式化；没有进行全仓手工格式化。
