# 什么是Transformer Chain

## 引言

Transformer Chain（TFSC）旨在打造一个高性能、具有弹性的公共区块链基础设施、支持各种场景下的分布式应用。任何人或组织都可以在其上创新和建设、共同打造一个去中心化且安全的区块链生态。

## 优点

为了满足这些需求、TFSC专注于以下核心概念：

- 速度：TFSC采用了C/C++语言来编写、众所周知、C/C++具有运行效率高、可移植性好等优点。在TFSC中、交易上链速度非常快 、最快1秒内达到全网共识上链。

- 安全性：TFSC在共识层采用了大量可验证随机函数（VRF）、拜占庭容错算法、Ed25519圆锥曲线签名算法以及自主研发的浪花协议等、在保证速度的情况下也同时保证其安全性、使得每个节点的地位、权利是同等的、哪怕单个或少量节点出现问题、也不会对交易和网络运行造成较大的影响。

- 可扩展性 ：TFSC使有向无循环图的区块链结构来提供更高的带宽处理能力，并允许交易事务中携带自定义数据。

- 高度定制化：业务链可以根据不同的交易类型或业务实体独立运作、TFSC的应用范围也可以无限拓展。

- 无法篡改 : TFSC是高度去中心化的分布式账本、篡改交易数据几乎是不可能的。

- 所有交易数据公开、透明 : 虽然公有链上所有节点是匿名加入网络、但任何节点都可以查看其他节点的账户余额以及交易活动。验证节点遍布于世界各地、所有人共同参与记账、维护区块链上的所有交易数据。

- 支持智能合约：目前TFSC支持以太坊虚拟机（EVM），大部分在太坊部署的智能合约不加修改或者少量修改后在即可在TFSC上执行运作。

# 搭建TFSC网络

## 二进制包部署

### 二进制包下载

如果想快速接入tfsc网络，可以通过以下链接直接下载当前最新tfsc二进制可执行程序进行节点部署

```
https://fastcdn.tfsc.io/testnet/tfs_v1.0.0_830f4b9_testnet.zip
```

解压下载好的程序压缩包，压缩包的类型可能为.zip类型或.tar.gz类型，解压命令对应如下：

```shell
unzip tfs_XXX.zip 
tar zxvf tfs_XXX.tar.gz 
```

### 启动程序

添加 -m 参数以启动程序 显示菜单

```shell
./tfs_xxx -m
```

程序启动后会额外生成一些文件，生成文件说明

| 文件或目录  | 类型     | 描述               |
| ----------- | -------- | ------------------ |
| cert        | 文件夹   | 存放生成的私钥文件 |
| data.db     | 文件夹   | 存放数据库文件     |
| logs        | 文件夹   | 存放日志文件       |
| config.json | json文件 | 配置文件           |
| contracts   | 文件夹   | 合约文件夹         |

## 编译部署

### 开发环境搭建

需要安装的软件包有：

- gcc （11.2.1）
- cmake（v3.21及以上）
- git 
- unzip 
- zip
- autoconf 
- automake 
- libtool
- perl-IPC-Cmd


依赖库：

- zlib 
- zlib-devel

centos 7 安装命令：

```shell
yum install -y zlib zlib-devel unzip zip  
yum install -y autoconf automake libtool perl-IPC-Cmd
yum install centos-release-scl -y
yum install -y devtoolset-11-toolchain
scl enable devtoolset-11 bash 
```

CMake升级（注：CMake版本至少要保证3.15.x以上、推荐版本为3.21.x）

```shell
curl -O https://cmake.org/files/v3.21/cmake-3.21.4.tar.gz
tar zxvf cmake-3.21.4.tar.gz
cd cmake-3.21.4
./configure 
gmake && make install
```

ubuntu 22.04 安装命令：

```shell
apt install g++   	      #默认更新到 11.4.0
apt-get install zlib1g-dev 
apt-get install autoconf  #防止在安装protobuf时失败
apt install libtool	      #防止在安装protobuf时失败
apt install cmake
```

### 程序编译

获取源码

```
git clone http://36.153.135.206:8090/root/X-Eco.git
```

进入tfs目录并编译（源码目录下有README.md文件有详细说明）

```shell
cd X-Eco/ 				   #进入tfs/目录
mkdir build && cd build 	# 创建并进入build目录
cmake .. && make 		    # 编译dev版本
cmake .. -DTESTCHAIN=ON -DCMAKE_BUILD_TYPE=Release && make		# 或编译test版本
cmake .. -DPRIMARYCHAIN=ON -DCMAKE_BUILD_TYPE=Release && make	# 或编译primary版本
```

编译完成后程序将在bin目录下生成

### 启动程序

使用 -m 参数启动程序并显示菜单

```shell
cd bin/
./tfs_xxx -m
```

## 配置网络

### 斥候节点

当有新节点要加入tfsc网络时，会自动向斥候节点进行注册，通过斥候节点返回的当前网络的节点列表，新加入节点再根据节点列表依次网络中的其他节点。

### 连接外部网络

使用 -m 程序启动后会生成 config.json 配置文件，并自动配置网络

config.json 配置文件说明

```json
{
    "http_callback": {
        "ip": "",
        "path": "",
        "port": 0
    },
    "http_port": 20620,
    "info": {
        "logo": "",
        "name": ""
    },
    "ip": "",
    "log": {
        "console": false,
        "level": "OFF",
        "path": "./logs"
    },
    "rpc": true,
    "server": [
        "52.8.162.216",
        "50.18.55.167"
    ],
    "server_port": 20619,
    "version": "1.0.0"
}
```
|    字段名     |                             描述                             |
| :-----------: | :----------------------------------------------------------: |
|    server     |       此字段自动生成，保存当前网络中默认的斥候节点 ip        |
|  server_port  |         此字段填写通用网络连接端口号(默认不需要修改)         |
|      log      | "console" 表示log是否输出在屏幕 、"level" 表示输出日志的等级 （日志等级包括：trace、debug、info、warn、err、critical、off）、"path"表示默认日志生成的路径。 |
|      ip       | -m启动时系统会通过斥候节点检测本机外网ip，并自动填入此字段，如果斥候节点没有启动或网络不通，则检测本机内网ip进行填写（内网ip无法连接外网节点，这时需要手动填入本机的外网ip） |
|   http_port   |                       http服务的端口。                       |
|      rpc      |         访问接口的开关、开启即可访问接口、默认关闭。         |
|     info      |              由用户设置的节点的 logo 和 name。               |
| http_callback | http回调接口，使用 post 为配置的服务端发送存块和回滚块的块信息。"ip" 表示服务端的ip地址，"path" 表示服务端的监听路径，当路径为空时，存块默认路径为：/addblock，回滚块默认路径为：/rollbackblock。"port" 表示服务端监听的端口号 |
|    version    |                       config文件的版本                       |



### 配置内部网络

搭建内部网络时，需要编译dev版本的程序，详见[编译部署](##编译部署)

启动程序时添加 -c 参数 在程序当前目录下如果没有配置文件时将会自动生成配置文件 config.json，将 "server" 斥候节点ip字段改为内部网络ip，"ip" 字段填写本机内网ip，填写完成后用 -m 参数启动程序即可

修改示例

```json
{
    "http_callback": {
        "ip": "",
        "path": "",
        "port": 0
    },
    "http_port": 20620,
    "info": {
        "logo": "",
        "name": ""
    },
    "ip": "192.168.1.200",
    "log": {
        "console": false,
        "level": "OFF",
        "path": "./logs"
    },
    "rpc": true,
    "server": [
        "192.168.1.100",
        "192.168.1.101"
    ],
    "server_port": 20619,
    "version": "1.0.0"
}
```
示例：本机IP为192.168.1.200，使用192.168.1.100和192.168.1.101 作为斥候节点。

# 账户

TFSC确保每一个账号都是独一无二的，利用OpenSSL中的散列随机函数，生成具有高度随机性的种子数据，对种子数据进行不可逆的SHA256哈希计算并使用ED25519秘钥算法得到私钥对象和账账户地址。账户地址类似以太坊格式地址，即40个字符的十六进制字符串。

------

# 菜单操作

| 序号 | 菜单条目         | 功能     |
| :--- | ---------------- | -------- |
| 1    | Transaction      | 发起交易 |
| 2    | Stake            | 质押     |
| 3    | Unstake          | 解质押   |
| 4    | Delegate         | 投资     |
| 5    | Withdraw         | 解投资   |
| 6    | Get Bonus        | 申领     |
| 7    | PrintAccountInfo | 账户信息 |
| 8    | Deploy contract  | 部署合约 |
| 9    | Call contract    | 执行合约 |
| 10   | Account Manager  | 账户管理 |
| 0    | Exit             | 退出程序 |


#### **Transaction** 

输入自己的账户地址。

```plaintext
input FromAddr: 0x2A3526f605803526f7af2B268111897470BAe2F7
```

输入对方账号地址：

```plaintext
input ToAddress: 0xCA66A76E2a279050EF6b57797ac53199379abB9F 
```

输入交易金额、这里的范围是在您账户余额范围内的任意数、输入值等于实际值、即为币数：

```plaintext
input amount: 999 
```

是否查找全网utxo状态，0为不查找（默认），1为查找

```plaintext
Whether to look for network-wide utxo status (1 means yes, 0 means no)
0
```

可输入对交易的描述信息，描述信息不能超过1kb，直接回车代表不输入描述信息：

```plaintext
Enter a description of the transaction, no more than 1 kb

```

输入回车

#### **Stake**

按2进入质押界面、输入质押金额、最小质押金额为1000：

```plaintext
stake addr: 0xCA66A76E2a279050EF6b57797ac53199379abB9F
Please enter the amount to stake:
1000
```

输入奖励抽水比例，输入5-20，代表5%-20%：

```plaintext
Please input the bonus pumping percentage to stake (5 - 20):
5
```

是否查找全网utxo状态，0为不查找（默认），1为查找：

```plaintext
Whether to look for network-wide utxo status (1 means yes, 0 means no)
0
```

输入对交易的描述信息，描述信息不能超过1kb，直接回车代表不输入描述信息：

```plaintext
Enter a description of the transaction, no more than 1 kb

```

输入回车

#### **Unstake**

按3进入解质押界面。

输入解质押的账号：

```plaintext
Please enter unstake addr:
0xCA66A76E2a279050EF6b57797ac53199379abB9F
```

然后会显示已质押的utxo、选择要解质押的utxo将其拷贝输入到控制台：

```plaintext
-- Current pledge amount: -- 
utxo: 3f4607d9e1ca341b3bee45110eecd2aaf1be5bba60bbdfe3ca44d68afae1b570 value: 500000000000

utxo：3f4607d9e1ca341b3bee45110eecd2aaf1be5bba60bbdfe3ca44d68afae1b570
```

是否查找全网utxo状态，0为不查找（默认），1为查找：

```plaintext
Whether to look for network-wide utxo status (1 means yes, 0 means no)
0
```

输入对交易的描述信息，描述信息不能超过1kb，直接回车代表不输入描述信息：

```plaintext
Enter a description of the transaction, no more than 1 kb

```

输入回车

#### **Delegate**

按4进入投资界面 ，会显示本机账户列表，输入投资方地址。

```plaintext
AddrList:
0xCA66A76E2a279050EF6b57797ac53199379abB9F [default]
Please enter your addr:
0xCA66A76E2a279050EF6b57797ac53199379abB9F
```

输入被投资的目标地址

~~~plaintext
Please enter the addr you want to delegate to:
0xCA66A76E2a279050EF6b57797ac53199379abB9F
~~~

输入要投资的金额（投资金额最低为10000）

~~~plaintext
Please enter the amount to delegate:
10000
~~~

是否查找全网utxo状态，0为不查找（默认），1为查找：

```plaintext
Whether to look for network-wide utxo status (1 means yes, 0 means no)
0
```

输入对交易的描述信息，描述信息不能超过1kb，直接回车代表不输入描述信息：

```plaintext
Enter a description of the transaction, no more than 1 kb

```

输入回车

#### **Withdraw**

按5进入解投资界面。

会显示地址列表、输入解投资的源地址

~~~plaintext
AddrList : 
0xCA66A76E2a279050EF6b57797ac53199379abB9F [default]
Please enter your addr:
0xCA66A76E2a279050EF6b57797ac53199379abB9F
~~~

输入解投资的目标地址

~~~plaintext
Please enter the addr you want to withdraw from:
0xCA66A76E2a279050EF6b57797ac53199379abB9F
~~~

会显示解投资的utxo，输入解投资的utxo

~~~plaintext
-- Current delegate amount: -- 
utxo:0x366afab7d3931ff5e17cfc25c2dcaf2cf382b8623f22a605c4acc9fbba611dde

Please enter the utxo you want to withdraw:
0x366afab7d3931ff5e17cfc25c2dcaf2cf382b8623f22a605c4acc9fbba611dde
~~~

是否查找全网utxo状态，0为不查找（默认），1为查找：

```plaintext
Whether to look for network-wide utxo status (1 means yes, 0 means no)
0
```

输入对交易的描述信息，描述信息不能超过1kb，直接回车代表不输入描述信息：

```plaintext
Enter a description of the transaction, no more than 1 kb

```

输入回车


#### **Get Bonus**

按6做申领交易、自动申领金额

是否查找全网utxo状态，0为不查找（默认），1为查找：

```plaintext
Whether to look for network-wide utxo status (1 means yes, 0 means no)
0
```

输入对交易的描述信息，描述信息不能超过1kb，直接回车代表不输入描述信息：

```plaintext
Enter a description of the transaction, no more than 1 kb

```

显示能申领的地址和对应金额(该金额是以标准单位显示)，最上面的代表这个账户一共能申领的金额，下面代表每一个账户(自身和投资人)所能申领的金额

~~~plaintext
Claim Addr : Claim Amount
Commission: 0.05000000
CA66A76E2a279050EF6b57797ac53199379abB9F:3.52691224
CA66A76E2a279050EF6b57797ac53199379abB9F:0.17634561
~~~



#### **PrintAccountInfo**

​	按7显示本机信息


#### **Deploy contract** 

  按8部署合约

1.合约编译后的二进制码保存在contract目录下的contract文件中
2.运行节点

输入要部署合约人的地址

```plaintext
AddrList : 
0x6a72ad3e9762d67D45a311954CdC6ad4693203a9 [default]
Please enter your addr:0x6a72ad3e9762d67D45a311954CdC6ad4693203a9
```

是否查找全网utxo状态，0为不查找（默认），1为查找：

```plaintext
Whether to look for network-wide utxo status (1 means yes, 0 means no)
0
```

输入对交易的描述信息，描述信息不能超过1kb，直接回车代表不输入描述信息：

```plaintext
Enter a description of the transaction, no more than 1 kb

```

填写合约路径，若输入0则使用./contract/contract下的合约

```plaintext
Please enter contract path : (enter 0 use default path ./contract/contract)
0
```

若合约构造函数有传入参数，输入部署时所需的Parameters二进制码（若contract.txt中为Calldata可直接跳过），否则输入 0 跳过：

```plaintext
Please enter input data (enter 0 to skip):0
```

#### **Call contract**

按9执行合约

输入要执行合约人的地址

```plaintext
AddrList : 
0x6a72ad3e9762d67D45a311954CdC6ad4693203a9 [default]
Please enter your addr:0x6a72ad3e9762d67D45a311954CdC6ad4693203a9
```

会显示合约部署人的地址列表，输入合约部署人地址
```plaintext
=====================deployers======================
deployer: 0x855052fa258B463AEAd1E5abD55F2ffbCBb3F022
deployer: 0xcED97dA085527Fe7e1772CA59Aa1e64A78143128
=====================deployers======================

Please enter to addr:
0xeB3D7EBcc235A5B053F2735B18E16705a82216a3
```

会显示合约地址列表，输入要执行的合约地址

```plaintext
=====================contract addresses=====================
contract address: 0xE5370bF327AC024f0DF1d5d69dcd0B1a45f307B5
=====================contract addresses=====================

Please enter contract address:0xE5370bF327AC024f0DF1d5d69dcd0B1a45f307B5 
```

输入要执行合约的参数

```plaintext
Please enter args:
0xa0712d680000000000000000000000000000000000000000000000000000000000000001
```

输入给布置合约账户的小费金额，默认为9

```plaintext
input contract tip amount :100
```

给合约地址转账，如果不需要转账则输入0

```plaintext
input contract transfer amount :0
```

是否查找全网utxo状态，0为不查找（默认），1为查找：

```plaintext
Whether to look for network-wide utxo status (1 means yes, 0 means no)
0
```

输入对交易的描述信息，描述信息不能超过1kb，直接回车代表不输入描述信息：

```plaintext
Enter a description of the transaction, no more than 1 kb

```

#### **Account Manager**

按10做账户管理

1. Set Default Account
2. Add Account
3. Remove 
4. Import SeedKey
5. Export SeedKey



| 序号 | 菜单条目            | 功能               |
| ---- | :------------------ | ------------------ |
| 1    | Set Default Account | 设置默认账户       |
| 2    | Add Account         | 增加账户           |
| 3    | Remove              | 移除账户           |
| 4    | Import SeedKey      | 导入种子，生成账户 |
| 5    | Export SeedKey      | 导出种子           |

##### Set Default Account
按1设置默认账户,输入想要设置账户的地址，只有在这一次程序中有用，下一次程序重新启动，还是最开始的默认账户。

~~~plaintext
Please enter the address you want to set :
0xf535227CCA5487776e666374c839de8b7005892B
~~~

##### Add Account

按2增加账户，直接输入想要增加的账户数量的值。

~~~plaintext
Please enter the number of accounts to be generated: 2
~~~

#####   Remove 

按3删除账户，直接输入想要删除的账户的地址，按Y进行确认。

~~~plaintext
Please enter the address you want to remove :
0xf535227CCA5487776e666374c839de8b7005892B
Are you sure to delete (Y / N) 
Y
~~~

#####   Import SeedKey

按4导入种子，生成账户,输入账户的16进制种子，这样在cert目录下就会生成这个账户。

~~~plaintext
Please input SeedKey string: 0dea52bcaea7ac7b9ff04b2b7732777e
~~~

##### Export SeedKey
按5导出账户的种子（16进制字符串）和二维码和12位助记词，直接输入想要导出的账户的地址，本地目录下就会生成一个addr.txt(addr为账户地址)文件，里面就包含这些信息。

~~~plaintext
please input the addr you want to export
0xf535227CCA5487776e666374c839de8b7005892B
~~~



# 



### **备份种子**

按照菜单操作里面的选项10中选项5进行操作。

在菜单中选择选项10，然后选择选项5。进入后，输入您要备份账户种子的地址。系统将生成一个包含种子（16进制字符串）、二维码和12位助记词的文件。该文件名为 `addr.txt`(addr为账户地址)，并将保存在当前目录下。



### **备份数据**

只需要备份data.db这个数据就可以了:

```plaintext
tar -cvzf data.db.tar.gz data.db
```



# **问题排除**

#### **程序配置**

**可能问题**：

**编译程序失败**

  ​需要确保依赖库齐全，检查所有必需的库是否已安装，如果缺少库文件则需要下载相应的库文件，如果某些库文件按报错，可以删除相关编译生成的库文件，再重新编译。

​	处理 bz2 库：如果有 bz2 库，则需要启用它,在 `CMakeLists.txt` 文件中

```cmake
target_link_libraries(${PROJECT_NAME} bz2)
```

如果没有 bz2 库，可以注释掉这一行：

```cmake
#target_link_libraries(${PROJECT_NAME} bz2)
```



#### **程序启动失败**

**可能原因**：

**数据库过大导致文件打开数不足**

```shell
	通过ulimit -n 查看文件打开数
	可以通过ulimit -n 65535 临时修改文件的打开数为65535。
	也可以通过下面方式永久修改
	编辑 /etc/security/limits.conf 文件，为特定用户或所有用户设置文件描述符限制
```

**数据库版本不对**：

​	可以删除数据库，去官网重新下载新的数据库，或者重新启动等待从零同步下载数据。

**配置文件问题**：

​	检查config配置文件的格式和版本。可以删除config文件，重新启动程序自动生成新的config配置文件，再进行配置。

**节点软件版本不兼容或安装不完整**

​	检查程序版本，确保使用的是适合所需环境的版本,例如普通机器程序版本在矿机上无法启动。

**依赖库或环境变量未正确设置**

​	设置依赖库和环境变量，确保所有依赖库已正确安装，并且环境变量已正确配置。



#### **节点无法加入到网络**

**可能原因**：

**配置文件问题**

​	检查 config 文件中的 IP、端口、斥候节点配置，可以删除config 文件，重新启动程序自动生成新的 config 文件进行配置。

**节点从网路中一会连接一会断开**

​	检查是否使用了重复的账户。如果你有多个账户，并在不同节点中使用，确保每个账户仅能被一个节点使用。不能多个节点使用同一个账户。

**网络配置错误或防火墙阻止**。

​	配置防火墙规则，允许节点端口通信。



#### **交易失败**  

**可能原因：**

**网络问题**：

​	确保节点有稳定的网络连接，并且能够访问互联网。没有网络阻塞或延迟，确保网络带宽充足，以支持高频交易和数据传输。

**交易参数问题**：

​	检查交易参数是否符合规定要求。如确保传递的地址格式正确，交易金额在允许范围内，Gas费用设置合理等。

**程序版本不一致**：

​	不同版本的程序可能存在较大差异，导致兼容性问题。可以通过Ppc接口中的`GetVersion`方法查询自己节点与其他节点的程序版本，确保与其他节点的程序版本一致。

**账户资产不足**：

​	账户资产不足可能导致转账金额或Gas费用不足，进而导致交易失败。可以通过菜单选项7或Rpc接口中的`GetBalance`方法查询账户资产，确保账户中有足够的资金以避免交易失败。

**节点高度未同步**：

​	节点高度未与全网节点一致会导致节点无法做起来交易，通过菜单选项 7 查询节点的高度，或者通过接口中的 `GetBlockNumber` 查询节点的高度。如果节点高度不一致，等待节点同步完成后再进行交易

**节点未投资质押**

​	如果是在全网节点500高度之后加入网络的节点，需要进行投资质押之后才能做交易。可以通过菜单中的选项2和选项5来进行投资质押。

**节点启动直接做交易未成功**

​	  节点在程序启动后需要时间与其他节点建立连接和注册再进行交易，大约100秒可以确保节点间的连接和注册完成，然后再开始进行交易。

**连续做交易导致交易失败**

​	交易上链需要时间，通常需要1-5秒（视网络情况而定）。在短时间内连续执行交易可能导致失败。建议在每次交易成功上链后再进行下一笔交易。可以通过Rpc接口中的`ConfirmTransaction`方法查询交易是否成功上链。


**硬件资源不足**：

​	节点所在的硬件资源不足，如CPU、内存或存储空间不足，无法处理交易所需的计算和存储需求。增加节点的硬件资源，确保有足够的计算能力和存储空间。

**合约交易问题**：

​	检查合约部署和合约调用参数是否正确，确保合约字节码无误。

**节点时间不一致**

​	节点的系统时间不同步，会导致交易失败，通过配置NTP服务，确保节点系统时间与网络时间一致。可以使用下面命令来更新时间：
```shell
ntpdate Pool.ntp.org
```

**节点同步不上去**

​		如果节点长时间未同步到最高高度，可能是节点从自己数据库读取数据失败，可以删除自己的数据库，去官网去下载最新的数据库，或者从零开始同步。

#### 其他

**如果程序打开没有菜单**

使用 `-m` 参数启动程序：确保程序启动时有菜单显示。

**Rpc接口使用出错**

确保 RPC 使用 Post请求时 json格式正确，端口与 config 文件中的http端口一致。

**日志关闭与启用**

如果想看查看日志，在config配置文件中可以选择启用日志记录功能，并且可以设置日志级别，以便查看和分析日志文件。



# 共识机制 

## 共识机制的概念

虚拟货币和区块链相辅相成。同时，区块链又是虚拟货币的基础技术架构，构成区块链的基础是共识机制。作为一个基于互联网的去中心化记账的系统，区块链在没有强有力中心化角色控制的情况下，维护区块链中的所有节点需要达成共同认知机制，建立起相互信任的关系。

## 浪花协议

TFSC在共识层使用了浪花协议为共识方式，目前主流的共识机制无法兼顾到效率和去中心化。与传统POW[^11]相比更高效，不会产生算力竞争。每个节点在网络中都有自己唯一的节点ID，每个节点在主网中通过离散随机数进行选取验证。

TFSC使用的浪花协议以离散随机数算法从验证池中随机选举的验证节点进行多线性广播的数据校验，通过最终满足的签名校验，确定区块的合法性。

## ED22519曲线

ED25519是一种EdDSA签名，基于SHA-512和Curve25519。可以看出他的命名取自EdDSA和Curve25519的前半和后半。EdDSA(Edwards-curve Digital Signature Algorithm)是基于扭曲爱德华兹曲线(twisted Edwards curves)的一类签名算法，而Curve25519是扭曲爱德华兹曲线的一种。在我们之前介绍到的VRF流程中，在创建VRF亦或验证VRF中都有ED22519的参与。在创建VRF过程中会把交易或块的哈希同私钥的sha256哈希进行一次ED22519加密，相反的验证时会对签名结果进行ED22519验证。

### 数字签名

数字签名的基本特性：不可伪造性，不可否认性，消息完整性。

数字签名（又称公钥数字签名，电子签章）有别于写在纸上的物理签名，使用了公钥加密领域的技术，是一种用于鉴别数字信息的方法。一套数字签名通常定义两种互补的运算，一个用于签名，另一个用于验证。数字签名，就是只有信息的发送者才能产生的别人无法伪造的一段数字串，这段数字串同时也是对信息的发送者发送信息真实性的一个有效证明。数字签名是非对称密钥加密技术与数字摘要技术的应用。数字签名是个加密的过程，数字签名验证是个解密的过程。

TFSC采用数字签名是因为其不可伪造性，因为他人假冒不了发送方的私钥签名。发送方是用自己的私钥对信息进行加密的，只有使用发送方的公钥才能解密。它能保障消息的完整性。一次数字签名采用一个特定的哈希函数，它对不同文件产生的数字摘要的值也是不相同的。

TFSC使用的浪花协议以离散随机数算法从验证池中随机选举的验证节点进行多线性广播的数据校验，通过最终满足的签名校验，确定区块的合法性。

## VRF随机验证算法

可验证随机函数(Verifiable Random Function，简写 VRF)是一种将输入映射为可验证的伪随机输出的加密方案。

VRF随机验证算法在TFSC整个浪花协议中不可或缺，基本涉及到随机选取节点的场景就会用到VRF随机算法。无论是交易流转还是块流转过程中都有VRF的参与，在创建VRF时，会把当前节点的私钥，交易或者块的哈希作为入参，对哈希字符串本身进行一次获取sha256加密，并把加密结果同私钥一起作为VRF的签名(证明)。对签名(证明)结果再次进行一次sha256加密，并把返回结果作为创建vrf的传出参数。

当验证VRF时，流程会反过来，把签名结果和当前的块或交易哈希作为入参传入，并把验证结果和私钥的sha256哈希进行比对。如果一致则VRF验证成功。

## 加密算法和安全性考虑

TFSC为保护链上资产的安全性，采用了目前应用较多、通过广泛检验的安全算法。其主要包含两方面：ED25519圆锥曲线签名算法和可验证随机函数(VRF)。

ED25519圆锥曲线其安全性已经从数学和实践两个向量上通过了广泛的认可，同时还拥有极快的生成速度和验证速度，在保证了安全性的前提下提高了交易的验证速度。关于ED25519圆锥曲线[^12]的更多内容可参考相关文献。

TFSC链在交易流转过程中使用了大量的随机来保证其公平性，但普通的随机方法无法阻止修改源代码产生的作恶行为。所以，TFSC链引入了VRF[^13]对随机的结果进行验证。其相关原理也可查阅相关文件。

## 共识过程

### 节点角色

在TFSC网络中共有四种节点角色，但节点角色只是某一节点在某一交易过程中扮演的角色， 并不是一种身份。即：

**发起节点**：发起交易的节点。组织交易并发送给打包节点。

**打包节点(代发节点)**：负责发起交易的流转并将交易打包成块的节点。交易打包成块后会将块发送给验证节点，验证通过后再将块广播至全网。

**验证节点(候选代发节点)**：对打包节点发来的块进行验证的节点。若验证通过，则通知打包节点。

**其他节点**：不参与交易过程的节点。这些节点只负责将广播来的块存入数据库中。

在TFSC中每个节点都有可能扮演上述四种角色，在交易过程中，一个节点可能同时扮演上述四种角色。

### 交易过程

在整个交易过程中，需要在全网节点内进行若干节点的选取。所有的选取过程遵循公平随机的原则，使用VRF进行选取并验证。过程如下：

1.发起节点A根据块信息通过VRF选取打包节点，并将交易发送给打包节点B。

2.打包节点B进行VRF验证确保自己为发起节点A选定的节点，并在全网节点中选取若干节点，将交易发给这些节点。

3.收到交易的节点对交易和VRF进行验证。若验证成功，则通知打包节点B。

4.打包节点B收到的通知数达到共识数时，将交易放入缓存中。打包节点B每隔特定的时间周期会将缓存中的所有交易打包成块。

5.打包节点B使用VRF选择若干节点作为验证节点并将块发送给验证节点。

6.验证节点对块和VRF进行验证。若验证成功，则通知打包节点B。

7.打包节点B收到的通知数达到共识数时，全网广播。

8.其他节点收到广播后，进行VRF验证以确定打包节点B（即广播发起人）为发起节点A指定的打包节点。

------

# 网络

## 分布式网络和节点通信

TFSC采用了全连接的，去中心化的，分布式的P2P网络结构。

TFSC通过 P2P 的方式与区块链网络连接，在区块链网络中，所有的全节点都是平等的，既充当客户端又充当服务器。

TFSC中所有节点都是平等的，具备了所有的节点特性

* 归档    保存了所有区块的历史状态的节点，历史上任何一个区块对应的世界状态都被保存在节点上
* 验证    可以直接在本地验证交易数据的有效性。
* 广播    全程参与区块信息和交易信息的全网广播
* 心跳    验证网络中节点的连接状态健壮性
* 接口    开放查询接口，提供基本的准确的当前信息
* 同步节点    新节点加入区块后，发现新节点并连接广播当其他节点

## 网络通信流程

TFSC采用了比较稳定的TCP点对点通信。使用TCP通信时，消息首先被存入缓存中，然后经由事务分发器进行分发，最后由各个函数处理。

### 通信实现

节点列表(Peerlist)：在其他的P2P网络中，每个节点都保存了其他节点的信息。

当请求其中一个节点时，需要循环遍历所有节点直到找到请求的节点。目前部分区块链项目共存的问题是当网络节点数量不断扩张时，不可能在每个节点上都存储所有其他节点的信息。 随着节点位数的增加，层数也不断增加，而更高层存储的信息也就越多。这样对后续数据的读取将造成很大的困难，会降低网络数据的及时性。TFSC为了解决这个问题，在应用层面牺牲节点数量级提高了网络节点的传播效率,在服务数量级内可以快速完成全网络通信,如果数量超出阈值,会导致交易变慢，TFSC则会踢出一部分未质押节点来解决这个问题。

当节点A收到一个请求消息时，发送者B的节点信息就被用来更新对应的节点列表，具体步骤如下：

1. 节点A记录发送节点B的IP，区块高度等信息。
2. 若发送者B已经存在于节点列表中，则更新节点A列表信息。
3. 若B节点不在节点列表中，则添加B节点信息到A节点列表中。
4. 向其他节点广播B节点信息。

节点列表内为A节点所记录的节点信息，主要用于查看节点信息，判断节点间的通信方式是直接发送还是转发并（公网）行使路由功能，节点信息有ip，名称，标识等。节点会保存所有已连接的节点信息。

## 网络功能模块

### TCP注册步骤

1. 注册发送节点向被注册节点发送注册请求，若两个节点之间未连接则会先进行连接，若连接失败则重新发起注册。
2. 被注册节点处理注册请求返回特定的节点信息。
3. 注册发送节点处理被注册节点发回的注册响应并记录相应的节点信息。

### 心跳机制

 节点掉线后在规定时间内若未重新连接则心跳数变为0，删除该节点

  + 步骤
    1.节点将所有已知节点心跳数减1并发送ping请求
    2.当接受节点成功收到ping请求，重置发送节点心跳数并发送pong请求
    3.当发送节点成功收到pong请求，重置接收节点心跳数并更新接收节点信息

### 块高度更改通知

* 步骤
  当节点高度变更时将自身的节点高度发送给自身所连接的节点，接收节点处理块高度更改请求，更新对应节点的块高度。

------

# 数据结构

## 区块链中的DAG

区块链是一种特殊的DAG结构[^10]，在《从区块链到DAG（一）--区块链的账本结构和共识机制》中讲到，区块链是否分叉和出块速度以及广播速度有关。当出块速度超过广播速度的时候，会出现多个区块同时在广播的情况，分叉也就产生了，分叉越多安全性越差。比特币为了减少分叉，在性能和安全性中找到的平衡点为：每十分钟出一个块。现在我们假定每次出块的时间足够长，长到不会出现前一个区块还没广播结束就有新区块挖出的情况。那么这个区块链的结构就是一条单链。

![DAG2](DAG2.png)

实际上，由于网络延迟等原因难免出现分叉的情况，所以实际的区块链结构会如图所示，再通过账本共识只取其中一条有效的主链（黄色），剩下的区块（红色）里的交易信息都是无效的，不会被采纳。

![DAG3](DAG3.png)

TFSC采用DAG结构避免了传统区块链中，打包出块无法并发执行。如果改变区块的链式存储结构，变成DAG的网状拓扑可以并发写入。在区块打包时间不变的情况下，网络中可以并行打包N个区块，网络中的交易就可以容纳N倍。DAG跟区块链的结合就是为了解决效率问题，交易发起后直接广播网络确认，从图论拓扑模型宏观地看，从单链进化到树状和网状，从区块粒度细化到交易粒度，从单点跃迁到并发写入，都使得TFSC效率得到了质的飞跃。

------

# 同步

## 双重花费

在加密货币系统中，由于数据的可复制性，使得系统可能存在同一笔数字资产被重复使用的情况，这也称之为双花（double spend attack），又叫双重消费攻击。正是因为这种现象的产生，所以TFSC会采用纠错同步解决双重花费的一部分问题。

## 校验同步

校验同步是TFSC链上即是同步数据块的主要方式，也是纠错数据块的主要方式。在节点因网络、性能、分叉或其他不可抗力因素导致的，节点链上高度未能与全网大多数节点达成一致的情况下，并且当且节点高度和链上高度之差小于100的情况下，此时节点会进行校验同步。校验同步的运作流程如下：

同步节点通过拜占庭向全网节点请求特定高度的数据，把相关请求回来的数据进行校验，如果当前块在本地不存在会运行补块逻辑，当数据校验通过后，将数据写入缓存而当本地出现了本不该存在的块时，此时会把多出来的块添加到回滚缓存中，在接下来的回滚逻辑中把错块消除。无论时少块还是错块都会对修复结果添加到本地数据库的修改中。

## 补块同步

补块同步是对前两种机制的补充，在当前节点区块高度与全网差距过大，当前数据库丢失，会通过补块同步快速的拉去块并添加到本地数据库中。补块会拉取千高度的哈希和本地进行对比，验证通过后会直接把丢失的块添加到缓存当中，在之后添加到数据库中。在千高度哈希和本地不一致时，此时会再次进行拜占庭拉去块当拜占庭也失败时，会在当前高度再次进行一次校验同步。

## 快速同步

快速同步发生在当存块时发现块前置块哈希不存在，此时会通过快速同步迅速查找块哈希并把当前块哈希添加到数据库中，同时快速同步也是其他两种同步方式的一次逻辑补充。

## 拜占庭同步

无论是校验同步还是补块同步都会用到拜占庭方式，校验同步拜占庭有三个阶段，第一个阶段询问全网的25个节点，在成功后，即和本地数据比对一致后会进行下一次同步，如果失败则会进入下个阶段的拜占庭，第二个阶段的拜占庭会询问全网的250个节点，同样的成功会进行下一次同步失败则进行下一次拜占庭。第三阶段会对全网节点进行拜占庭，在拉取到全网的节点数据信息后，根据不同的同步方式会采取不同的策略。补块同步拜占庭方式是每次都是全网拜占庭。校验同步会把错块回滚，少块补充，补块同步会把最后一次的数据作为依据最后添加到本地数据库中。

同时因为最后一次拜占庭访问全网节点是几乎可以做到防止恶意节点作恶的最终手段，大大提高的作恶成本和作恶难度。因此TFSC独特的拜占庭暗示着TFSC是一条安全性很高的共链。

------


# 经济模型

## 代币经济和激励机制

在TFSC区块链中、我们需要质押入网、为避免用户波动不稳、需要质押一定金额才算入网成功。质押的币可以在一定时间后进行解质押。在解质押的过程中，质押金额不限、金额越大、得到的奖励比例则越大。        

## 节点奖励和治理机制

### 申领机制

当用户满足入网，并被其他节点累计投资10000以上，便可以给节点交易签名。除了立刻能够得到一笔手续费以外，还可以根据当天的签名次数在第二天进行申领，由投资签名者，与签名者共同得到一笔额外奖励。具体申领公式可以看[申领公式](申领公式/%E7%94%B3%E9%A2%86.md)

### 奖励规则

收益率(ER) = IR / SR

当前流通总量 = 全网总流通金额 - 当天全网申领金额
当前质押总量 = 全网总质押金额 - 当天全网质押金额

质押率(SR) = 当前质押总量 / 当前流通总量

注:SR的值最大为0.90 大于0.90按0.90计算

注:SR的值最小为0.35 小于0.35按0.35计算

注:IR的值最小为0.02 小于0.02按0.02计算

| SR           | 2021年度通胀率(IR) |
| :----------:|-------:|
|0.35   |          0.077|
|0.36   |         0.077 * 0.9865|
|0.37   |        0.077 * 0.9865 * 0.9865|
|......   |  ............|

| SR           | 2022年度通胀率(IR) |
| :----------:|-------:|
|0.35   |          0.077 * 0.88|
|0.36   |         0.077 * 0.88 * 0.9865|
|0.37   |        0.077 * 0.88 * 0.9865 * 0.9865|
|......   |  ............|

| SR           | 2023年度通胀率(IR) |
| :----------:|-------:|
|0.35   |          0.077 * 0.88 * 0.88|
|0.36   |         0.077 * 0.88 * 0.88 * 0.9865|
|0.37   |       0.077 * 0.88 * 0.88 * 0.9865 * 0.9865|
|......   |  ............|

| R           | 2032年度通胀率(IR) |
| :----------:|-------:|
|......   |    0.02(注:最小通胀率为0.02)|

个人当前质押金额(N) = 个人总质押金额 - 个人当天质押金额

个人可申领金额(S)

注:质押(投资)
SR结果保留两位小数(不做四舍五入)
ER结果保留八位小数(不做四舍五入)

```
S = N * ER / 365
```

## 资源消耗和费用模型

### Gas费用

为了防止本地漏块和高度不一致造成计算的燃料费不一致，燃料费采用本地计算。gas的计算公式根据当前交易的字节流量进行统计，并根据字节流量大小计算准确的gas费用。

### 销毁机制

#### 什么是代币销毁

销毁代币的行为涉及将其转移到一个永远无法被检索到的地方，也被称为销毁地址。销毁代币通过永久锁定数字资产，有效地阻止了这类数字资产的流通。销毁代币会导致仍在流通的代币价格上涨，资产的价格可被认为是一种供求关系。如果投资者可获得的资产少于需求，该资产在交易时会获得更高的价格。相反，如果有大量的资产不能满足需求，资产价格就会下跌。 通过减少代币的供应，销毁代币可造成需求的不平衡，由于资产的稀缺性增加，通常会抬高代币的价格。

#### 为什么要销毁代币

1. 有时，加密项目会像公司回购股票一样销毁代币，吸收股票成本并以更高的证券价格形式将价值返还给投资者。
2. 一些算法稳定币使用销毁作为将资产固定在某个价格的方法。当资产价格较低时，这种机制通过销毁代币来减少供应并更好地匹配需求。
3. 有些用户节点或矿场会通过自己交易空跑来达到赚取奖励，这样的行为对于区块链毫无意义。使得网络处理速度缓慢，增大了普通交易时间。通过小小的销币来阻止这种行为。对于个人影响不大。因为销毁的只是很小的一部分。

#### 销毁机制的原理与应用

销毁地址是一个无法访问的数字钱包，因为其没有附带私钥，就像一把从未有人为其建造过钥匙孔的锁。销毁机制向销毁地址发送代币实际上将数字资产从其整体供应中移除，将其锁定在任何人的手中，并防止该资产再次被交易。如上，TFSC销毁代币主要是为了应对掌控大多节点的用户恶意交易赚取gas费。

------

# 虚拟机

TFSC项目是一个基于以太坊区块链平台的应用，通过完全集成以太坊虚拟机（EVM），实现了智能合约的执行和应用逻辑的实现。目前,TFSC虚拟机已经支持市面上大部分合约(如ERC-721,ERC-20,ERC-1155等)。

以太坊虚拟机（EVM）是以太坊区块链平台的核心组件之一。它是一个基于堆栈的虚拟机环境，用于执行智能合约代码。EVM采用字节码指令集和堆栈结构，提供了一个沙盒环境来隔离智能合约的执行。通过访问和修改以太坊网络中的状态数据，EVM实现了智能合约的状态管理。作为以太坊的核心技术，EVM的规则和功能由以太坊社区共同决定和演进。通过EVM，开发者可以构建各种去中心化应用和智能合约来实现复杂的业务逻辑和协议。

# 引用

1.智能合约[^1]:https://en.wikipedia.org/wiki/Smart_contract

2.Solidity[^2]:https://en.wikipedia.org/wiki/Solidity

3.密码学[^3]:https://en.wikipedia.org/wiki/Cryptography

4.共识机制[^4]:https://en.wikipedia.org/wiki/Consensus_(computer_science)

5.双重花费[^5]:https://en.wikipedia.org/wiki/Double-spending

6.拜占庭方式[^6]:https://en.wikipedia.org/wiki/Byzantine_fault

7.ED22519圆锥曲线[^7]:https://en.wikipedia.org/wiki/Curve25519

8.EVM[^8]:https://en.wikipedia.org/wiki/Ethereum#Virtual_machine

9.wasm[^9]:https://en.wikipedia.org/wiki/WebAssembly

10.DAG[^10]:https://en.wikipedia.org/wiki/Directed_acyclic_graph

11.POW[^11]:https://en.wikipedia.org/wiki/Proof_of_work

12.ED22519[^12]:http://ed25519.cr.yp.to/

13.VRF[^13]:https://en.wikipedia.org/wiki/Verifiable_random_function

14.零知识证明[^14]：https://en.wikipedia.org/wiki/Zero-knowledge_proof

15.环签名[^15]:https://en.wikipedia.org/wiki/Ring_signature

16.盲签名[^16]：https://en.wikipedia.org/wiki/Blind_signature



# TFSC 智能合约

## 介绍

智能合约是一种旨在以信息化方式传播、验证或执行合同的计算机协议。智能合约允许在没有第三方的情况下进行可信交易、这些交易可追踪且不可逆转。

智能合约的目的、利用共识机制和不可篡改的账本技术、可以有效防止交易数据被篡改、确保交易过程的完整性和结果的不可逆转性。和传统合约相比、智能合约将合同条款以编程代码的方式实现、并在特定条件满足时自动执行相关行为、无需人工参与。在不同主体之间缔造信任关系、避免因不信任而导致的交易成本上升。

### 特点

- 规范性。智能合约以计算机代码为基础、能够最大限度减少语言的模糊性、通过严密的逻辑结构来呈现。内容及其执行过程对所有节点均是透明可见的、后者能够通过用户界面去观察、记录、验证合约状态。

- 不可逆性。一旦满足条件、合约便自动执行预期计划、在给定的事实输入下、智能合约必然输出正确的结果、并在显示视界中被具象化。

- 不可违约性。区块链上的交易信息公开透明、每个节点都可以追溯记录在区块链上的交易过程、违约行为发生的几率极低。

- 匿名性。根据非对称加密的密码学原理、零知识证明、环签名、盲签名等技术、在区块链上、虽然交易过程是公开的、但交易双方却是匿名的。

### 优势

1.去掉了中介、可以完全依托技术让用户之间自主建立合约。

2.透明公平、智能合约会用代码将条件写得清清楚楚并记录在区块链上、整个过程由程序执行、连包括编写这个代码的开发者都不能篡改。

3.灵活、让用户之间可以自由的建立合约、哪怕是与一个陌生的人也可以通过智能合约建立联系、总的来说、智能合约是区块链的核心技术之一、不仅在区块链中起到了执行的作用、他更是区块链的一个应用发展方向、拓宽了区块链的使用场景、正是因为它的存在、才使区块链有了一个更加广阔的舞台。

## 开发流程

TFSC使用的智能合约编写语言为Solidity。Solidity是一种面向对象的高级编程语言。TFSC所采用的EVM支持Solidity标准的绝大部份特性，且已经支持ERC-20、ERC-721、ERC-3525等等合约标准。相对于以太坊来说，TFSC合约的执行费用更低、上链速度更快。

1.使用智能合约相关功能需要熟悉Solidity语言，有关Solidity的链接如下：

  - [Solidity文档](https://docs.soliditylang.org/en/latest/)
  - [EVM操作码](https://ethervm.io/)
  - [Solidity编写事例](https://solidity-by-example.org/)

2.智能合约需要编译成EVM字节码才能进行部署和执行，有关Solidity智能合约的编译相关链接如下：

  - [Remix](https://remix.ethereum.org/)
  - [Remix文档](https://remix-ide.readthedocs.io/en/latest/)

3.TFSC因架构模型的原因与Solidity标准不同的特性如下：

  - 合约内TFSC币的转账基本单位为1e-8 TFSC
  - 合约不支持block变量
  - TFSC账户地址包括多个智能合约地址

## 部署合约

### 先决要求

  TFSC目前支持在节点上进行合约的部署和执行，所以要部署合约，要求有一个可进行交易的、正在运行的节点及一个拥有一定数量TFSC币的账号来支付部署过程中产生的手续费。
  智能合约的二进制码。在Remix IDE中为BYTECODE.object或Calldata，表现为一串16进制的数字。

### 部署合约

  1.新建空白文本文件contract.txt，将合约二进制码粘贴进文件中
  2.将文件contract.txt复制到TFSC节点所在文件夹
  3.运行节点
  4.运行菜单选项 **8.Deploy contract** 
  5.选择运行合约的虚拟机类型
  6.若合约构造函数有传入参数，输入部署时所需的Parameters二进制码（若contract.txt中为Calldata可直接跳过），否则输入 0 跳过。

## 执行合约

### 先决要求

  同部署合约一样，合约的执行暂时只能在节点上进行。除此之外，执行合约还需要知道合约的部署人账号和部署交易产生的交易哈希。

### 执行合约

  1.运行菜单 **9.Call contract**
  2.输入合约部署人账号
  3.输入所有运行合约部署时的交易哈希
  4.输入运行合约所需的input即可完成合约的执行

## 异同点

由于TFSC是DAG网络结构，而以太坊是单链结构，并且其共识机制并不完全一致，solidity的某些指令在EVM虚拟机的进行了一定的调整，具体差别如下：

block.basefee：1
block.chainid：518
block.coinbase: 打包者
block.prevrandao: 交易所用utxo hash拼接加和产生的随机数
block.gaslimit (uint): 9223372036854776028
block.number：区块高度
block.timestamp: TxInfo内blockTimestamp字段，一般情况下为块时间戳精确到秒，也可能存在若干秒误差
gasleft(): 剩余gas费
tx.gasprice: 1
tx.origin: 交易发起人
blockhash：因block.number语义不同，故返回0

# TFSC 其他应用

tfsc的节点为第三方开发者提供了很多rpc接口，所有的接口在rpc文档中都有详细的描述，这里着重讲述第三方开发者接入tfsc发送交易的流程，以web端为例，移动端和web的交易流程相同，使用的接口略有差异，后面有对移动端接口的详细介绍。

web端和移动端开发需要下载sdk，下载链接:

TODO 补充链接
```
git.xxx
```



## web端

1.生成种子并返回种子的16进制字符串

```
seedBase64 = api.export_new_seed();
```

2.传入种子，返回私钥句柄

```
privatePkey = api.import_prikey_handler_from_seed(seedBase64);
```

3.传入私钥句柄，返回私钥的16 进制编码

```
hexprikey = api.export_new_prikey_to_hex(privatePkey);
```

4.传入私钥的16进制编码，返回私钥句柄

```
api.import_prikey_handler_from_hex(hexprikey);
```

5.传入私钥句柄，返回私钥的addr账号地址

```
addr = api.get_addr(privatePkey);
resultaddr = api.get_addr(hexresultHandler);
console.assert(addr == resultaddr, "fail to recover private key");
```

6.释放私钥句柄

```
api.free_prikey_handler(hexresultHandler);
```

7.传入16 进制种子，返回种子助记词

```
mnemonic = api.export_mnemonic_from_seed(seedBase64);
```

8.传入种子助记词， 返回16 进制种子

```
mnemonicresultHandler = api.import_seed_from_mnemonic(mnemonic);
```

9.传入私钥句柄，返回公钥的base64编码

```
base64pubkey = api.get_pubstr_base64(privatePkey);
```

10.获取交易体，这里以普通交易为例，通过 CreateTransaction  rpc 接口获取普通交易体（详见rpc文档）

```json
//req
{
    "id": "",
    "jsonrpc": "",
    "params": {
        "fromAddr": [
            "cED97dA085527Fe7e1772CA59Aa1e64A78143128"
        ],
        "isFindUtxo": false,
        "toAddr": [
            {
                "addr": "06BA76F46631d4F344d1344303895001F1E3Af29",
                "value": "13.5"
            }
        ],
        "txInfo": ""
    }
}
//ack
{
  "id": "",
  "jsonrpc": "",
  "method": "GetTransaction",
  "result": {
    "code": 0,
    "gas": "20200",
    "height": "2506",
    "message": "success",
    "time": "1717557136905780",
    "txJson": "{\"time\":\"1717557136905780\",\"identity\":\"0796B6DB27e5eb1e9F8Bd2c4d03191C902D22F0f\",\"utxo\":{\"owner\":[\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"],\"vin\":[{\"prevOut\":[{\"hash\":\"26cc05fef65e94c15d759a27a24a57793253f25a3dece8e7761024ab0d0220dd\"}]}],\"vout\":[{\"value\":\"1350000000\",\"addr\":\"06BA76F46631d4F344d1344303895001F1E3Af29\"},{\"value\":\"1978395583553\",\"addr\":\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"},{\"value\":\"20200\",\"addr\":\"VirtualBurnGas\"}]},\"type\":\"Tx\",\"consensus\":7,\"txType\":1}",
    "txType": "0",
    "vrfJson": "{}"
  }
}
```

11.为交易返回值"result"字段中的"txJson"进行签名,传入要签名的消息和私钥句柄，返回签名后的消息

```
txJson = ...;
message = txJson;
message_size = message.length;
signature = api.sign(message, message_size, privatePkey);
```

12.传入公钥，消息和签名后的消息，返回签名后的消息的验证结果，0为成功，-1为失败

```
result = api.verif_by_public_str(base64pubkey, base64pubkey.length, message, message_size, signature, signature.length);
```

13.将签名后的信息放回到交易体通 txJson 中，并通过 SendMessage  rpc 接口将交易发送到节点即可完成发送交易（详见rpc文档）

```json
//对GetTransaction返回数据进行签名后的数据
{
    "id": "",
    "jsonrpc": "",
    "result": {
        "code": "",
        "gas": "20200",
        "height": "600",
        "message": "",
        "time": "1717148047269517",
        "txJson": "{\"time\":\"1717148047269517\",\"identity\":\"2eb2F635320c3Dbf29eadD35E894c13EE3F20bd5\",\"utxo\":{\"owner\":[\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"],\"vin\":[{\"prevOut\":[{\"hash\":\"3f1342e96e426e2905021ad991787131ec70d31298646b1e80da9d912eeff274\"}],\"vinSign\":{\"sign\":\"ApxL8NDgh9YYDuUXpdbsbVv0cEAr3HyXmr2TICkD4mfuDIZqVlZJNUmaPAKHCs5kkn7JnZx7r12+CpnnR4ZpAg==\",\"pub\":\"MCowBQYDK2VwAyEA89VSBQU7d4uL+jvqAKeCRbgYz2tzk/Rf8DNRhB0sLbg=\"}}],\"vout\":[{\"value\":\"1350000000\",\"addr\":\"06BA76F46631d4F344d1344303895001F1E3Af29\"},{\"value\":\"1982446992477\",\"addr\":\"cED97dA085527Fe7e1772CA59Aa1e64A78143128\"},{\"value\":\"20200\",\"addr\":\"VirtualBurnGas\"}],\"multiSign\":[{\"sign\":\"WCoFsLKML69x1rSpQc7pwbnd+GMfZ0Ce3wTPg96Rdb1v7ezFw9KuEBXwvGecTz264pVZB6T8hzgJIx26GuKVAA==\",\"pub\":\"MCowBQYDK2VwAyEA89VSBQU7d4uL+jvqAKeCRbgYz2tzk/Rf8DNRhB0sLbg=\"}]},\"type\":\"Tx\",\"consensus\":7,\"txType\":1}",
        "txType": "1",
        "vrfJson": "{\"vrfdata\":{\"hash\":\"6cf89d80c98eecd9138caca4f55d7ad0fda2aed9d8e68dd4642543ae3ee056d6\"},\"Vrfsign\":{\"sign\":\"u5dNZ16Rd77B4nLd8gAcKTwz+GxeHH1HIlcGennGbPaKgIFXUkmFzS/EnVxRC4nmSfESAdWyMEmj4pKBhwuqAg==\",\"pub\":\"MCowBQYDK2VwAyEAcUcydwF7CSr9bjBiUbd3drV+WMd4yd8xFL7HWGA4FTw=\"}}"
    }
}
```

14.其他接口 返回sdk版本号

```
version = api.get_version()
```

## 移动端

### IOS

**注：除 get_version 接口外，其他返回值为 char* 的接口都要使用 free 释放返回值占用的堆区空间**

```c
/**
* @brief       返回sdk版本号
* @return      const char* : 版本信息
*/
const char *get_version();

/**
* @brief       传入私钥的base64编码，返回私钥句柄
* @param       buf: 私钥的base64编码
* @param       buf_size: 私钥的base64编码长度
* @return      long long ：私钥句柄
*/
long long import_base64_prikey_handler(const char *buf, int buf_size);

/**
* @brief       导出私钥的base64编码
* @return      char* ：私钥的base64编码
*/
char *export_new_prikey_base64();

/**
* @brief       生成种子并返回种子的16进制字符串
* @return      char* ：种子的16进制字符串
*/
char *export_new_seed();

/**
* @brief       传入私钥的16进制编码，返回私钥句柄
* @param       str: 私钥的16进制编码
* @return      long long 私钥句柄
*/
long long import_prikey_handler_from_hex(const char *str);

/**
* @brief       根据16进制种子字符串获取私钥句柄
* @param       seed: 
* @return      long long 
*/
long long import_prikey_handler_from_seed(char *seed);

/**
* @brief       传入私钥句柄，返回私钥的16进制编码
* 
* @param       pkey: 句柄
* @return      char* 私钥的16进制编码
*/
char *export_new_prikey_to_hex(long long pkey);

/**
* @brief       传入种子，返回助记词
* @param       seed: 种子
* @return      char* 私钥句柄
*/
char *export_mnemonic_from_seed(const char *seed);

/**
* @brief       传入种子助记词， 返回16进制种子
* @param       mnemonic: 种子助记词
* @return      char* 种子
*/
char *import_seed_from_mnemonic(const char *mnemonic);

/**
* @brief       传入私钥句柄，返回私钥的addr账号地址
* @param       pkey: 私钥句柄
* @return      char* addr账号地址
*/
char *get_addr(long long pkey);

/**
* @brief       传入私钥句柄，返回公钥的base64编码
* @param       pkey: 私钥句柄
* @return      char* 公钥的base64编码
*/
char *get_pubstr_base64(long long pkey);

/**
* @brief       释放私钥句柄
* @param       pkey: 私钥句柄
*/
void free_prikey_handler(long long pkey);

/**
* @brief       为交易返回值"result"字段中的"txJson"进行签名
* @param       txjson: "txJson"信息
* @param       pkey: 私钥句柄
* @return      char* 签名后的消息
*/
char* txJsonSign(const char* txjson, void *pkey);

/**
* @brief	  对信息签名
* @param       message	要签名的信息
* @param       mesage_size	信息长度
* @param       pkey	私钥句柄
* @return      char*	签名后的信息
*/
char *sign(const char *message, int mesage_size, long long pkey);

/**
* @brief	  对信息验签
* @param       pubstr	公钥
* @param       pubsize	公钥长度
* @param       message	签名后的信息
* @param       messagesize	签名后的信息长度
* @param       signature	要签名的信息
* @param       signature_size 要签名的信息长度
* @return      int	0为成功，-1为失败
*/
int verif_by_public_str(const char *pubstr, int pubsize, const char *message, int messagesize, const char *signature, int signature_size);
```



### Android

```c
/**
* @brief	  创建16进制种子
* @return      jbyteArray : 16进制种子
*/
JNIEXPORT jbyteArray JNICALL Java_com_example_jni_sig_newSeed
  (JNIEnv *env , jobject);


/**
* @brief	  根据私钥导出私钥16进制数组
* @param       jlong : 私钥
* @return      jstring : 私钥16进制数组
*/
JNIEXPORT jstring JNICALL Java_com_example_jni_sig_ExportPriHexStr
  (JNIEnv *, jobject, jlong);


/**
* @brief	  根据私钥16进制数组导出私钥
* @param       jstring : 私钥16进制数组
* @return      jlong : 私钥
*/
JNIEXPORT jlong JNICALL Java_com_example_jni_sig_ImportPriHexStr
  (JNIEnv *, jobject, jstring);


/**
* @brief	  根据私钥16进制数组导出私钥
* @param       jbyteArray : 私钥16进制数组
* @return      jlong : 私钥
*/
JNIEXPORT jlong JNICALL Java_com_example_jni_sig_importSeed
  (JNIEnv * env, jobject, jbyteArray str);


/**
* @brief	  根据种子的16进制数组导出助记词
* @param       jbyteArray : 种子的16进制数组
* @return      jstring : 助记词
*/
JNIEXPORT jstring JNICALL Java_com_example_jni_sig_ExportMnemoic
  (JNIEnv *, jobject, jbyteArray);

/**
* @brief	  根据助记词导出种子的16进制数组
* @param       jstring : 助记词
* @return      jbyteArray : 种子的16进制数组
*/
JNIEXPORT jbyteArray JNICALL Java_com_example_jni_sig_ImportMnemoic
  (JNIEnv *, jobject, jstring);


/**
* @brief	  获取公钥base64
* @param       jlong : 公钥 
* @return      jstring : 公钥base64
*/
JNIEXPORT jstring JNICALL Java_com_example_jni_sig_GetPubStr
  (JNIEnv *, jobject, jlong);


/**
* @brief	  获取公钥base64
* @param       jlong pkey: 公钥 
* @return      jstring : 公钥base64
*/
JNIEXPORT jstring JNICALL Java_com_example_jni_sig_GetContractPubStr
 (JNIEnv *env, jobject, jlong pkey);


/**
* @brief	  根据私钥获取地址
* @param       jlong : 私钥 
* @return      jstring : 地址
*/
JNIEXPORT jstring JNICALL Java_com_example_jni_sig_GetAddr
  (JNIEnv *, jobject, jlong);


/**
* @brief	  对数据签名
* @param       jlong : 私钥
* @param       jstring : 要签名的数据   
* @return      jstring : 签名后的数据
*/
JNIEXPORT jstring JNICALL Java_com_example_jni_sig_sigmessage
    (JNIEnv *, jobject, jlong, jstring);


/**
* @brief	  对数据签名
* @param       jlong pkey : 私钥
* @param       jstring message : 要签名的数据
* @return      jstring : 签名后的数据
*/
JNIEXPORT jstring JNICALL Java_com_example_jni_sig_sigMessage
        (JNIEnv *env, jobject, jlong pkey, jstring message);


/**
* @brief	  验证签名
* @param       jlong : 私钥
* @param       jstring : 签名后的信息  
* @param       jstring : 验签结果
* @return      jboolean :  验签是否成功
*/
JNIEXPORT jboolean JNICALL Java_com_example_jni_sig_vefmessage
  (JNIEnv *, jobject, jlong, jstring, jstring);


/**
* @brief	  为交易返回值"result"字段中的"txJson"进行签名
* @param       jlong : 私钥
* @param       jstring : "txJson"信息
* @return      jstring : 返回签名后的txjson
*/
JNIEXPORT jstring JNICALL Java_com_example_jni_sig_sigTx
  (JNIEnv *, jobject, jlong, jstring);


/**
* @brief	  对base64字符串进行加密
* @param       jstring : 要加密的base64字符串
* @return      jstring : 加密后的数据
*/
JNIEXPORT jstring JNICALL Java_com_example_jni_sig_Base64Encode
  (JNIEnv *, jobject, jstring);


/**
* @brief	  对加密后的base64字符串进行解密
* @param       jstring : 要解密的base64字符串
* @return      jstring : 解密后的数据
*/
JNIEXPORT jstring JNICALL Java_com_example_jni_sig_Base64Decode
  (JNIEnv *, jobject, jstring);


/**
* @brief	  释放私钥
* @param       jlong pkey ：私钥
*/
JNIEXPORT void JNICALL Java_com_example_jni_sig_freePrikey
        (JNIEnv *env, jobject, jlong pkey);
```



## 区块浏览器

这里简述一些开发区块浏览器可能用到的接口，详细描述见rpc文档

### 交易相关

GetYieldInfo	获取利率信息

GetDelegateInfo	根据地址获取该地址的被投资信息

GetAccounts	返回客户端拥有的地址列表

getTransactionByHash	根据交易hash获取交易信息

ConfirmTransaction	确认交易是否上链

GetAllStakeNodeList	获取质押节点列表

GetBalance	返回给定地址的帐户余额

### 区块相关

GetBlockByHash	根据块hash获取块信息

GetBlockByHeight	根据块高度获取块信息

GetBlockTransactionCountByHash	返回匹配给定区块哈希的区块中的交易数量

### 网络相关

GetVersion	返回当前客户端版本、网络版本、数据库版本和config版本

GetChainId	返回链 ID

GetNodeList	返回当前连接到客户端的节点列表

GetBlockNumber	返回最新区块的编号  

