# VRF 分发者选择一致性确认协议 — 开发文档

**配套文档**: `docs/vrf/design.md`（方案设计）
**目标分支**: 基于 `fix_10_vrf` 创建新分支开发
**预估复杂度**: 中高（涉及共识层核心路径、新增 protobuf 消息、网络通信协议）

---

## 0. 开发前准备

### 0.1 需要理解的现有代码

在开始编码之前，必须彻底理解以下代码路径：

**VRF 核心**（`ca/vrf_consensus.cpp` + `ca/vrf_consensus.h`）：
- `VRFConsensusNode::run()` — 主循环，每 10 秒（将改为 15 秒）执行一次
- `VRFConsensusNode::generateVRFStructure()` — 生成 VRF 数据
- `VRFConsensusNode::vrfBroadcastMessage()` — 广播 VRF 给所有 peer
- `VRFConsensusNode::receiveVRRequest()` — 接收并验证 VRF，存入 `validatedVRfs`
- `VRFConsensusNode::addVRFStructure()` — 将 VRF 存入内存映射
- `VRFConsensusNode::extractVRFData()` — 提取 VRF 数据供分发者选择使用
- `VRFConsensusNode::extractPackagerVRFData()` — 提取 VRF 数据供区块打包者选择使用（本次不改，但需理解）
- `selectRandomNodes()` — SHA256 确定性洗牌选择（本次不改，但需理解）

**分发者选择**（`ca/transaction.cpp`）：
- `calculatePackerByTime()` — 合约分发者选择函数，调用 `extractVRFData`
- `get_contract_distribution_manager()` — 分发者选择入口
- `get_block_packager()` — 区块打包者选择函数（本次不改）

**Protobuf 定义**（`proto/ca_protomsg.proto`）：
- `VRFConsensusInfo` — 现有 VRF 消息格式
- 需要新增 `VRFSummaryMsg`

**消息注册**（`ca/interface.cpp`）：
- `HandleVRFConsensusInfoReq` — 现有 VRF 消息处理回调
- 需要新增 `HandleVRFSummaryMsgReq`

**全局常量**（`ca/global.h`）：
- `kConsensus = 3` — 最小共识节点数
- `CYCLE_DURATION_SECONDS` — 在 `vrf_consensus.h` 中定义为 10

### 0.2 关键数据结构

```cpp
// 现有数据结构（不修改）
std::map<std::string, std::map<std::string, VRFStructure>> validatedVRfs;
//   key1: seed (周期标识)
//   key2: nodeId (VRF 来源节点地址)
//   value: VRFStructure (VRF 数据)

// 需要新增的数据结构
std::map<std::string, std::map<std::string, VRFSummary>> validatedSummaries;
//   key1: seed (周期标识)
//   key2: nodeId (摘要来源节点地址)
//   value: VRFSummary (摘要数据，包含该节点收到的 VRF 来源列表)
```

---

## 1. 分阶段开发计划

整体分为 5 个阶段（Milestone），每个阶段完成后必须通过对应的验证点（Checkpoint）才能进入下一阶段。

```
M1: 基础设施    →  CP1: 编译通过 + 单测通过
M2: 摘要交换    →  CP2: 多节点部署，摘要正常收发
M3: 共识计算    →  CP3: 所有节点选出相同分发者
M4: 自适应与降级 →  CP4: 异常场景正确处理
M5: 集成与回归   →  CP5: 全功能测试通过，性能达标
```

---

### M1: 基础设施（周期调整 + Protobuf + 数据结构）

**目标**：将周期从 10 秒改为 15 秒，新增摘要消息定义和存储结构，确保现有功能不受影响。

**具体任务**：

1. **修改周期常量**
   - `ca/vrf_consensus.h`: `CYCLE_DURATION_SECONDS` 从 10 改为 15
   - `ca/global.h`: 新增阶段时间常量（`PHASE1_DURATION`, `PHASE2_DURATION` 等）
   - `ca/global.h`: 新增阈值常量（`THRESHOLD_RATIO_LARGE` 等）
   - 检查所有引用 `CYCLE_DURATION_SECONDS` 的地方，确认语义仍然正确
   - 特别注意：`getPreviousCycleTime()`、`generateVRSeed()`、`cycleStartTimestamp()` 中的时间计算

2. **新增 Protobuf 消息**
   - `proto/ca_protomsg.proto`: 新增 `VRFSummaryMsg` 消息定义
   ```protobuf
   message VRFSummaryMsg {
     string seed = 1;
     repeated string received_node_ids = 2;
     CSign sign = 3;
   }
   ```
   - 重新编译 protobuf 生成 C++ 代码

3. **新增数据结构**
   - `ca/vrf_consensus.h`: 新增 `VRFSummary` 结构体
   - `ca/vrf_consensus.h`: 在 `VRFConsensusNode` 类中新增 `validatedSummaries` 成员
   - 新增摘要的增删查方法声明

4. **修改 `run()` 函数框架**
   - 将原来的单阶段循环改为三阶段框架
   - 阶段1 保持原有 VRF 广播逻辑不变
   - 阶段2、阶段3 暂时留空（后续 M2/M3 实现）
   - 添加阶段切换的时间判断逻辑

5. **日志框架**
   - 新增 VRF 确认协议专用日志标签：`VRF_CONFIRM`
   - 每个阶段开始/结束时输出日志
   - 格式：`[VRF_CONFIRM][PHASE{n}] seed={} action={} detail={}`

**Checkpoint CP1**：
- [ ] 编译通过（`cmake --build .`）
- [ ] 现有单元测试全部通过
- [ ] 单节点启动后 VRF 广播正常（周期变为 15 秒）
- [ ] 日志正确输出阶段切换信息
- [ ] `validatedSummaries` 结构可正常增删查（通过单测验证）

---

### M2: 摘要交换协议

**目标**：实现摘要的生成、签名、广播、接收、验证和 gossip 转发。

**具体任务**：

1. **摘要生成** (`generateVRFSummary`)
   - 在阶段1 结束时（第 6 秒），遍历 `validatedVRfs[currentSeed]`
   - 收集所有已收到 VRF 的节点地址，排序
   - 构造 `VRFSummaryMsg`，序列化后签名
   - 存入本地 `validatedSummaries[currentSeed][自己地址]`

2. **摘要广播** (`broadcastVRFSummary`)
   - 与 `vrfBroadcastMessage` 类似，遍历 peer 列表发送摘要
   - 注册 `VRFSummaryMsg` 的网络回调（`ca/interface.cpp`）

3. **摘要接收** (`handleVRFSummaryMsg`)
   - 验签：检查 `VRFSummaryMsg.sign` 的有效性
   - 验证 seed 是否为当前周期或上一周期（防止过期摘要）
   - 验证 `received_node_ids` 中的地址是否合理（不超过已知质押节点总数）
   - 存入 `validatedSummaries[seed][nodeId]`
   - gossip 转发给所有 peer

4. **摘要修剪**
   - 与 VRF 数据修剪类似，当 `validatedSummaries.size() > MAX_VRFS_SIZE` 时删除最旧数据

5. **统计日志**
   - 每收到一条摘要，输出：`[VRF_CONFIRM][PHASE2] received summary from={} seed={} count={}`
   - 阶段2 结束时，输出：`[VRF_CONFIRM][PHASE2] complete seed={} total_summaries={}`

**Checkpoint CP2**：
- [ ] 编译通过
- [ ] 部署 3+ 节点，观察摘要交换
- [ ] 每个节点都能收到其他节点的摘要
- [ ] 日志显示摘要数量随时间增长（gossip 扩散）
- [ ] 伪造摘要（错误签名）被正确拒绝
- [ ] 过期摘要（非当前/上一周期）被正确拒绝

---

### M3: 共识计算与分发者选择集成

**目标**：实现共识集合计算，并将其接入分发者选择路径。

**具体任务**：

1. **共识集合计算** (`computeConsensusSet`)
   - 在阶段3 开始时（第 10 秒），遍历 `validatedSummaries[currentSeed]`
   - 统计每个地址被多少个摘要包含
   - 根据动态阈值（见 design.md 2.4 节）筛选出共识集合
   - 对共识集合中的地址排序，确保确定性输出
   - 输出格式：`std::vector<std::string>`

2. **动态阈值计算** (`computeDynamicThreshold`)
   - 根据当前节点数量 N 确定阈值
   - 实现滞后区间逻辑（避免档位跳变）
   - 记录上一周期使用的档位，本周期在此基础上判断是否切换

3. **边界确定性裁决** (`resolveBoundaryEntries`)
   - 识别处于阈值边界（`threshold - δ ≤ count < threshold`）的条目
   - 使用 `SHA256(VRF_seed + 周期号 + addr)` 做确定性裁决

4. **修改 `extractVRFData` / `calculatePackerByTime`**
   - 将原来直接使用 `validatedVRfs` 的逻辑改为使用共识集合
   - 如果共识集合为空或不足 → 触发降级（M4 实现）
   - 共识集合足够 → 用共识集合替代原来的 `dataSource`

5. **集成日志**
   - 共识计算结果：`[VRF_CONFIRM][PHASE3] consensus_set seed={} size={} members=[...]`
   - 分发者选择结果：`[VRF_CONFIRM] dispatcher seed={} selected={} consensus_size={}`
   - 与旧路径对比（调试用）：同时计算旧路径的分发者，如果不同则告警

**Checkpoint CP3**：
- [ ] 编译通过
- [ ] 部署 5+ 节点
- [ ] **核心验证**：所有节点在同一周期选出相同的分发者
- [ ] 日志中 `dispatcher selected=` 在所有节点上输出相同结果
- [ ] 旧路径对比日志显示新旧选择可能不同（验证新路径确实在改变结果）
- [ ] 连续运行 100 个周期，分发者选择不一致次数 = 0

---

### M4: 自适应机制与降级

**目标**：实现多级降级、分区感知、时钟偏差处理、冷启动等异常场景。

**具体任务**：

1. **时间驱动的多级降级**
   - Level 0（0-15s）：正常模式
   - Level 1（15-20s）：threshold 降低 10%
   - Level 2（20-25s）：threshold 降到 max(N×1/2, 1)
   - Level 3（>25s）：回退到原始 VRF 数据（等同于修改前的逻辑）
   - 降级由绝对时间驱动，所有节点同步降级

2. **分区感知**
   - 计算覆盖率 = 收到的摘要数 / 预估全网节点数
   - 覆盖率 < 60% 时标记为可能分区
   - 分区状态下不产出区块

3. **时钟偏差检测**
   - 对比本地时间与 peer 报告的时间
   - 偏差 > 2 秒时标记为时钟异常
   - 异常节点的摘要降权

4. **冷启动处理**
   - 新节点在第一个完整周期只收集不选择
   - 使用上一周期的共识结果（从区块获取或回退到旧逻辑）

5. **共识集合不足的兜底**
   - 共识集合 < kConsensus 时触发降级
   - Level 3 仍不足时跳过本周期

6. **降级日志**
   - 降级触发：`[VRF_CONFIRM][DEGRADE] level={} seed={} reason={} threshold={}`
   - 分区检测：`[VRF_CONFIRM][PARTITION] coverage={} status={}`
   - 时钟异常：`[VRF_CONFIRM][CLOCK_SKEW] node={} skew={}s`

**Checkpoint CP4**：
- [ ] 编译通过
- [ ] 模拟节点离线（关闭 30% 节点），系统正确降级
- [ ] 模拟网络分区（隔离部分节点），分区内节点检测到分区状态
- [ ] 新节点加入后第一个周期不产出区块，第二个周期正常参与
- [ ] 所有节点在同一时刻处于相同的降级 Level
- [ ] Level 3 回退后行为与修改前完全一致

---

### M5: 集成测试与性能验证

**目标**：全功能集成测试，验证性能指标和稳定性。

**具体任务**：

1. **多规模测试**
   - 20 节点环境：验证小网络自适应
   - 50 节点环境：验证中等网络
   - 100 节点环境：验证大网络
   - 500 节点环境（如果条件允许）：验证极限规模

2. **稳定性测试**
   - 连续运行 24 小时
   - 监控内存增长（摘要数据修剪是否正常）
   - 监控分发者选择不一致次数（应为 0）

3. **性能测试**
   - 测量各阶段耗时是否符合预期
   - 测量摘要交换的网络开销
   - 确认区块产出间隔稳定在 15 秒

4. **异常恢复测试**
   - 节点重启后能否快速恢复
   - 网络中断恢复后能否重新收敛
   - 大量节点同时离线后恢复

**Checkpoint CP5**：
- [ ] 所有规模环境测试通过
- [ ] 连续 24 小时无崩溃、无内存泄漏
- [ ] 分发者选择不一致次数 = 0
- [ ] 区块产出间隔标准差 < 1 秒
- [ ] 摘要交换阶段在 4 秒内完成（500 节点）
- [ ] 内存增长 < 100 MB/24h

---

## 2. 代码修改清单

| 文件 | 阶段 | 修改类型 | 说明 |
|------|------|---------|------|
| `ca/vrf_consensus.h` | M1 | 修改 | 新增数据结构、方法声明、修改周期常量 |
| `ca/vrf_consensus.cpp` | M1-M4 | 修改 | 核心改动：run()、新增摘要交换/共识计算/降级逻辑 |
| `ca/global.h` | M1 | 修改 | 新增阈值、阶段时间等常量 |
| `proto/ca_protomsg.proto` | M1 | 修改 | 新增 VRFSummaryMsg |
| `ca/interface.cpp` | M2 | 修改 | 注册 VRFSummaryMsg 回调 |
| `ca/transaction.cpp` | M3 | 修改 | calculatePackerByTime 使用共识集合 |
| `ca/transaction.h` | M3 | 修改 | 函数签名可能需要调整 |

---

## 3. 注意事项

### 3.1 不要改动的部分

- `extractPackagerVRFData` — 区块打包者选择路径本次不改
- `selectRandomNodes` — SHA256 洗牌算法不改
- VRF 数据的生成/签名/验证逻辑不改
- 合约打包者 (`CONTRACT_PACKAGER`) 和区块验证者 (`BLOCK_VALIDATOR`) 的 VRF proof 机制不改

### 3.2 线程安全

- `validatedSummaries` 与 `validatedVRfs` 共享同一个 `mutex_`（`std::shared_mutex`）
- 摘要的读写需要加锁
- 共识计算在阶段3 执行，此时阶段2 已结束，可以使用读锁

### 3.3 向后兼容

- 旧节点不识别 `VRFSummaryMsg`，会自动忽略
- 新节点在摘要数量不足时降级到 Level 3，行为与旧节点一致
- 可以滚动升级，不需要全网同时切换

### 3.4 日志规范

所有新增日志使用 `[VRF_CONFIRM]` 前缀，便于 grep 过滤：

```bash
# 查看所有确认协议日志
grep "VRF_CONFIRM" mm_*.log

# 查看共识集合
grep "VRF_CONFIRM.*PHASE3" mm_*.log

# 查看降级事件
grep "VRF_CONFIRM.*DEGRADE" mm_*.log

# 查看分发者选择结果
grep "VRF_CONFIRM.*dispatcher" mm_*.log
```

---

## 附录 A：与 origin/fix_menu_vrf 分支的合并注意事项

`origin/fix_menu_vrf` 分支（提交 `582bc5e`）对 VRF 准入池做了优化，涉及 3 个文件。当前设计文档只涉及文档新增，与 fix_menu_vrf 无文件级冲突，但**后续编码阶段必须注意以下三点**：

### A.1 白名单 API 返回类型已变更

fix_menu_vrf 将 `Genesis::GetVRFWhitelist()` 的返回类型从 `std::vector<std::string>` 改为 `std::unordered_set<std::string>`。

**影响**：本设计文档中引用 `GetVRFWhitelist()` 的地方（如 `calculateStakeProbability` 中的白名单检查）必须基于 `unordered_set` 接口编写，使用 `.find()` 而非 `std::find()`。

**涉及文件**：`common/genesis.h`、`common/genesis.cpp`

### A.2 准入池快速路径必须保留

fix_menu_vrf 在 `extractPackagerVRFData` 的 Stage1 新增了"全员白名单快速路径"——当 dataSource 中所有节点都在白名单里时，跳过准入池过滤直接进入后续流程。

**影响**：本次开发虽然不改 `extractPackagerVRFData`（区块打包者路径不在范围内），但合并代码时必须确保这个快速路径不被覆盖或破坏。

**涉及文件**：`ca/vrf_consensus.cpp` — `extractPackagerVRFData` 函数内 Stage1 区块

### A.3 阈值比较符已从 > 改为 >=

fix_menu_vrf 将准入池过滤条件从 `stakeProb > vrfThreshold` 改为 `stakeProb >= vrfThreshold`，避免 `vrfThreshold == 1.0` 时白名单节点被误排除。

**影响**：后续实现共识计算的边界裁决逻辑（`resolveBoundaryEntries`）时，阈值比较必须基于 `>=` 语义，不能回退到 `>`。

**涉及文件**：`ca/vrf_consensus.cpp` — `extractPackagerVRFData` 函数内 Stage1 过滤条件
