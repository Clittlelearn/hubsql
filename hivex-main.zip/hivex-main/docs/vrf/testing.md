# VRF 分发者选择一致性确认协议 — 测试文档

**配套文档**: `docs/vrf/design.md`（方案设计）、`docs/vrf/development.md`（开发文档）
**测试脚本**: `tests/vrf_confirm/multi_node_test.sh`、`tests/vrf_confirm/verify_logs.sh`
**详细测试计划**: `tests/vrf_confirm/TEST_PLAN.md`

---

## 0. 快速开始

```bash
# 编译
cd build && cmake --build . --parallel $(nproc)

# 创建 5 节点测试集群
./tests/vrf_confirm/multi_node_test.sh setup 5

# 启动 → 等待 3 周期 → 查看状态 → 运行验证
./tests/vrf_confirm/multi_node_test.sh start
sleep 45
./tests/vrf_confirm/multi_node_test.sh status
./tests/vrf_confirm/multi_node_test.sh verify

# 停止 & 清理
./tests/vrf_confirm/multi_node_test.sh stop
./tests/vrf_confirm/multi_node_test.sh clean
```

---

## 1. 测试环境要求

### 1.1 节点规模

| 测试场景 | 节点数 | 目的 |
|---------|--------|------|
| 基础功能 | 3-5 | 验证协议基本流程 |
| 小网络 | 20 | 验证小网络自适应阈值 |
| 中等网络 | 50 | 验证标准场景 |
| 大网络 | 100-500 | 验证极限规模和性能 |

### 1.2 网络拓扑

- 基础测试：全互联（所有节点互相连接）
- 分区测试：人为隔离部分节点（防火墙规则或网络配置）
- 高延迟测试：使用 `tc netem` 模拟延迟

### 1.3 监控工具

```bash
# 日志实时监控
tail -f mm_*.log | grep "VRF_CONFIRM"

# 分发者选择一致性检查（多节点对比）
grep "VRF_CONFIRM.*dispatcher selected" mm_node*.log | awk '{print $NF}' | sort | uniq -c

# 摘要数量监控
grep "VRF_CONFIRM.*PHASE2.*complete" mm_*.log

# 降级事件监控
grep "VRF_CONFIRM.*DEGRADE" mm_*.log
```

---

## 2. 各阶段测试用例

### 2.1 M1 基础设施工测试

| 编号 | 测试项 | 操作 | 预期结果 | 关键日志 |
|------|--------|------|---------|---------|
| M1-01 | 周期变更 | 启动单节点 | VRF 广播间隔为 15 秒 | `vrSeed:` 时间间隔 ~15s |
| M1-02 | 阶段切换 | 启动单节点 | 日志显示阶段1开始/结束 | `[VRF_CONFIRM][PHASE1]` |
| M1-03 | 数据结构 | 单元测试 | VRFSummary 增删查正常 | 单测输出 |
| M1-04 | 时间计算 | 检查各时间函数 | getPreviousCycleTime 基于 15s 对齐 | 调试日志 |

### 2.2 M2 摘要交换测试

| 编号 | 测试项 | 操作 | 预期结果 | 关键日志 |
|------|--------|------|---------|---------|
| M2-01 | 摘要生成 | 3 节点部署 | 每周期生成 1 条摘要 | `[VRF_CONFIRM][PHASE2] generated summary count=` |
| M2-02 | 摘要传播 | 3 节点部署 | 所有节点收到所有摘要 | `[VRF_CONFIRM][PHASE2] received summary from=` |
| M2-03 | 签名验证 | 发送伪造摘要 | 被拒绝 | `VerifySign fail` |
| M2-04 | 过期拒绝 | 发送旧周期摘要 | 被拒绝 | `expired summary seed` |
| M2-05 | Gossip 扩散 | 5 节点部署 | 摘要数量随时间增长 | 每秒钟摘要数量递增 |
| M2-06 | 修剪 | 长时间运行 | 旧摘要被清理 | `pruned summaries, size=` |

### 2.3 M3 共识计算测试

| 编号 | 测试项 | 操作 | 预期结果 | 关键日志 |
|------|--------|------|---------|---------|
| M3-01 | **一致性** | 5 节点运行 100 周期 | 所有节点选出相同分发者 | `dispatcher selected=` 全部相同 |
| M3-02 | 阈值计算 | 不同规模网络 | 阈值符合 design.md 2.4 节 | `threshold={} ratio={}` |
| M3-03 | 边界裁决 | 构造边界场景 | 裁决结果确定且一致 | `boundary resolve addr={} result=` |
| M3-04 | 新旧对比 | 同时运行新旧路径 | 日志显示差异（如有） | `dispatcher_diff old={} new={}` |
| M3-05 | 空共识集 | 模拟摘要全部丢失 | 触发降级 | `[VRF_CONFIRM][DEGRADE]` |

### 2.4 M4 异常场景测试

| 编号 | 测试项 | 操作 | 预期结果 | 关键日志 |
|------|--------|------|---------|---------|
| M4-01 | 节点离线 | 关闭 30% 节点 | 系统降级但继续运行 | `[VRF_CONFIRM][DEGRADE] level=` |
| M4-02 | 网络分区 | 隔离部分节点 | 分区被检测到 | `[VRF_CONFIRM][PARTITION] coverage=` |
| M4-03 | 时钟偏差 | 调整节点时钟 +3s | 时钟异常被检测 | `[VRF_CONFIRM][CLOCK_SKEW]` |
| M4-04 | 冷启动 | 新节点加入 | 首周期不产出区块 | `cold_start skip selection` |
| M4-05 | 降级恢复 | 离线节点重新上线 | 自动恢复到 Level 0 | `[VRF_CONFIRM][DEGRADE] level=0` |
| M4-06 | Level 3 回退 | 大量节点离线 | 回退到原始 VRF 逻辑 | `[VRF_CONFIRM][DEGRADE] level=3 fallback` |
| M4-07 | 档位滞后 | 节点数在阈值边界波动 | 档位不频繁切换 | `hysteresis keep level=` |

### 2.5 M5 集成测试

| 编号 | 测试项 | 操作 | 预期结果 | 关键日志 |
|------|--------|------|---------|---------|
| M5-01 | 长期稳定 | 运行 24 小时 | 无崩溃、无内存泄漏 | 进程存活、内存稳定 |
| M5-02 | 性能基准 | 100 节点 | 摘要交换 < 4s | PHASE2 开始到结束 < 4s |
| M5-03 | 区块间隔 | 所有规模 | 间隔稳定 15s ± 1s | 区块时间戳差值 |
| M5-04 | 零不一致 | 100 节点运行 1000 周期 | 分发者选择不一致 = 0 | 对比所有节点的 dispatcher 日志 |

---

## 3. 关键日志说明与排查指南

### 3.1 正常流程日志序列

一个正常周期的日志应该按以下顺序出现：

```
[VRF_CONFIRM][PHASE1] start seed=1719200000
[VRF_CONFIRM][PHASE1] broadcast_vrf seed=1719200000
[VRF_CONFIRM][PHASE1] end seed=1719200000 vrf_count=45
[VRF_CONFIRM][PHASE2] start seed=1719200000
[VRF_CONFIRM][PHASE2] generated summary seed=1719200000 received_count=45
[VRF_CONFIRM][PHASE2] received summary from=0xABC... seed=1719200000 count=43
[VRF_CONFIRM][PHASE2] received summary from=0xDEF... seed=1719200000 count=44
...（更多摘要接收日志）
[VRF_CONFIRM][PHASE2] complete seed=1719200000 total_summaries=48
[VRF_CONFIRM][PHASE3] start seed=1719200000
[VRF_CONFIRM][PHASE3] consensus_set seed=1719200000 size=42 threshold=32
[VRF_CONFIRM][PHASE3] complete seed=1719200000 consensus_size=42
[VRF_CONFIRM] dispatcher selected seed=1719200000 dispatcher=0xABC... consensus_size=42
[VRF_CONFIRM][BUFFER] start seed=1719200000
[VRF_CONFIRM][BUFFER] end seed=1719200000
```

### 3.2 异常日志模式与排查

#### 模式1：摘要数量远低于预期

```
症状:
  [VRF_CONFIRM][PHASE2] complete seed=X total_summaries=5  (预期 ~50)

排查步骤:
  1. 检查阶段1 是否正常:
     grep "PHASE1.*end.*vrf_count" mm_*.log
     → 如果 vrf_count 也很低，说明 VRF 广播有问题（与本次改动无关）

  2. 检查网络连接:
     查看 peer 连接数是否正常
     → 如果 peer 数少，摘要传播受限

  3. 检查是否有验签失败:
     grep "VerifySign fail.*summary" mm_*.log
     → 如果大量验签失败，检查签名逻辑

  4. 检查是否被过期拒绝:
     grep "expired summary" mm_*.log
     → 如果大量过期，检查时钟同步
```

#### 模式2：不同节点选出不同分发者

```
症状:
  节点 A: dispatcher selected seed=X dispatcher=0xABC
  节点 B: dispatcher selected seed=X dispatcher=0xDEF

排查步骤:
  1. 对比共识集合:
     grep "PHASE3.*consensus_set.*seed=X" mm_nodeA.log mm_nodeB.log
     → 如果共识集合不同，说明摘要集合不同

  2. 对比摘要数量:
     grep "PHASE2.*complete.*seed=X" mm_nodeA.log mm_nodeB.log
     → 如果 total_summaries 不同，说明 gossip 未完全收敛

  3. 检查阈值:
     grep "threshold=" mm_nodeA.log mm_nodeB.log
     → 如果阈值不同，说明档位切换不一致（检查滞后逻辑）

  4. 检查时间:
     两个日志的时间戳差多少？
     → 如果差 > 2s，可能是时钟偏差导致阶段切换不同步

  5. 检查是否处于降级状态:
     grep "DEGRADE" mm_nodeA.log mm_nodeB.log
     → 如果一个在 Level 0 一个在 Level 3，说明网络条件差异大
```

#### 模式3：频繁降级

```
症状:
  [VRF_CONFIRM][DEGRADE] level=1 ...
  [VRF_CONFIRM][DEGRADE] level=2 ...
  [VRF_CONFIRM][DEGRADE] level=3 ...
  每个周期都在降级

排查步骤:
  1. 检查节点在线率:
     有多少节点在正常广播 VRF？
     → 如果 < 60%，说明网络本身有问题

  2. 检查摘要传播时间:
     PHASE2 开始到 complete 的时间差
     → 如果 > 4s，说明网络延迟过高或摘要太大

  3. 检查阈值是否过严:
     对于当前 N，threshold 是多少？
     → 如果 threshold 过高导致共识集合太小，考虑调整阈值参数

  4. 检查是否有节点发送空摘要:
     grep "generated summary.*received_count=0" mm_*.log
     → 如果有，说明这些节点阶段1 没收到任何 VRF
```

#### 模式4：内存持续增长

```
症状:
  进程 RSS 内存持续增长，不回落

排查步骤:
  1. 检查摘要修剪:
     grep "pruned summaries" mm_*.log
     → 如果没有修剪日志，说明修剪逻辑有 bug

  2. 检查 validatedSummaries 大小:
     在调试日志中查找 size 信息
     → 应该不超过 MAX_VRFS_SIZE

  3. 检查是否有内存泄漏:
     用 valgrind 或 AddressSanitizer 运行
     → 重点关注摘要相关的新增代码路径
```

#### 模式5：区块产出间隔异常

```
症状:
  区块间隔不是稳定的 15s，有时 20s、25s 甚至更长

排查步骤:
  1. 检查是否触发了降级扩展:
     grep "DEGRADE.*level=" mm_*.log
     → Level 1 会延长到 20s，Level 2 到 25s

  2. 检查共识计算耗时:
     PHASE3 开始到结束的时间差
     → 正常应该 < 1s，如果过长说明计算逻辑有问题

  3. 检查是否有周期跳过:
     grep "dispatcher selected" mm_*.log 的时间间隔
     → 如果有 > 30s 的间隔，说明某些周期没有产出区块
```

---

## 4. 性能基准

### 4.1 各阶段预期耗时

| 阶段 | 50 节点 | 100 节点 | 500 节点 |
|------|--------|---------|---------|
| 阶段1 (VRF 广播) | 1-2s | 2-3s | 3-5s |
| 阶段2 (摘要交换) | 1-2s | 2-3s | 3-4s |
| 阶段3 (共识计算) | <0.1s | <0.2s | <0.5s |
| 总计 | 2-4s | 4-6s | 6-9s |

### 4.2 网络开销

| 规模 | 摘要总量 | 每节点发送量 | 每节点接收量 |
|------|---------|------------|------------|
| 50 节点 | ~50 MB | ~1 MB | ~1 MB |
| 100 节点 | ~200 MB | ~2 MB | ~2 MB |
| 500 节点 | ~5 GB | ~10 MB | ~10 MB |

### 4.3 内存开销

```
每个周期的摘要存储:
  500 条摘要 × 20 KB = 10 MB
  保留 MAX_VRFS_SIZE(10) 个周期 = 100 MB 峰值

实际应该远低于此，因为不是每个周期都有 500 个节点参与
```

---

## 5. 回归测试清单

确保修改不影响现有功能：

- [ ] 非合约交易 (TX) 正常上链
- [ ] 质押交易 (STAKE) 正常上链
- [ ] 委托交易 (DELEGATE) 正常上链
- [ ] 奖励申领 (BONUS) 正常上链
- [ ] 合约部署 (DEPLOY) 正常上链
- [ ] 合约调用 (CALL) 正常上链
- [ ] 区块签名验证正常（≥ kConsensus 个签名）
- [ ] 分叉检测与同步正常
- [ ] 节点重启后能正常同步
- [ ] VRF 双签检测正常（slashing 相关）
