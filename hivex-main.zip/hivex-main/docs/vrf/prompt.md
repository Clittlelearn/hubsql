# VRF 分发者选择一致性确认协议 — AI 编程助手提示词

本文档是给 AI 编程助手的指令文档。请严格按照本文档的分阶段指引进行开发，每完成一个阶段必须通过对应的验证点后才能进入下一阶段。

---

## 项目背景

你正在为 OpenHive 区块链项目实现 **VRF 分发者选择一致性确认协议**。

**问题**：当前合约分发者的选择依赖 VRF 数据的本地收集（gossip 协议），不同节点在同一时刻可能看到不同的 VRF 数据集合，导致选出不同的分发者，交易验证失败。

**解决方案**：在 15 秒的 VRF 周期内增加"摘要交换 + 共识计算"阶段，让所有节点就"哪些 VRF 数据是有效的"达成共识，从而保证分发者选择的确定性。

**设计文档**：`docs/vrf/design.md` — 包含完整的方案设计、自适应机制、安全性分析
**开发文档**：`docs/vrf/development.md` — 包含分阶段任务、代码修改清单、注意事项
**测试文档**：`docs/vrf/testing.md` — 包含测试用例、日志排查指南、性能基准

**在开始编码之前，请先阅读以上三个文档。**

---

## 关键约束

### 绝对不能改动的代码

以下代码路径在本次开发中**不得修改**：

- `extractPackagerVRFData()` — 区块打包者选择路径
- `selectRandomNodes()` — SHA256 洗牌算法
- VRF 数据的生成 (`generateVRFStructure`)、签名、验证逻辑
- `receiveVRRequest()` 中的 VRF 验证逻辑
- 合约打包者 (`CONTRACT_PACKAGER`) 和区块验证者 (`BLOCK_VALIDATOR`) 的 VRF proof 机制

### 代码风格

- 遵循项目现有的 C++ 编码风格
- 日志使用 `DEBUGLOG` / `ERRORLOG` / `TRACELOG` 宏
- 新增日志统一使用 `[VRF_CONFIRM]` 前缀
- 线程安全：`validatedSummaries` 与 `validatedVRfs` 共享同一个 `std::shared_mutex mutex_`
- Protobuf 消息定义在 `proto/ca_protomsg.proto`

### 向后兼容

- 旧节点不识别 `VRFSummaryMsg`，会自动忽略
- 新节点在摘要不足时降级到 Level 3（使用原始逻辑），与旧节点行为一致
- 支持滚动升级

---

## 分阶段开发指引

### 阶段 M1：基础设施

**目标**：周期从 10 秒改为 15 秒，新增 Protobuf 消息和数据结构，搭建三阶段框架。

**执行步骤**：

1. 先阅读 `ca/vrf_consensus.h` 和 `ca/vrf_consensus.cpp`，理解现有 VRF 主循环 (`run()`) 的工作方式
2. 阅读 `ca/global.h`，了解现有常量定义
3. 修改 `CYCLE_DURATION_SECONDS` 为 15
4. 在 `ca/global.h` 中新增阶段时间和阈值常量（参见 design.md 第 6 节）
5. 在 `proto/ca_protomsg.proto` 中新增 `VRFSummaryMsg`
6. 在 `ca/vrf_consensus.h` 中新增 `VRFSummary` 结构体和 `validatedSummaries` 成员
7. 修改 `run()` 函数，搭建三阶段框架（阶段2、3 暂时留空）
8. 添加 `[VRF_CONFIRM][PHASE{n}]` 日志

**验证点 CP1**：
```bash
# 编译
cmake --build . 2>&1 | tail -5

# 启动单节点，观察日志
./mm_node 2>&1 | grep "VRF_CONFIRM"
# 预期：看到 PHASE1 start/end，间隔约 15 秒

# 运行现有单元测试
ctest --output-on-failure
# 预期：全部通过
```

**如果 CP1 不通过**：不要进入 M2。检查编译错误和测试失败原因，修复后重新验证。

---

### 阶段 M2：摘要交换协议

**目标**：实现摘要的生成、签名、广播、接收、验证和 gossip 转发。

**执行步骤**：

1. 先阅读 `vrfBroadcastMessage()` 和 `receiveVRRequest()`，理解现有 gossip 机制
2. 阅读 `ca/interface.cpp` 中 `HandleVRFConsensusInfoReq` 的注册方式
3. 实现 `generateVRFSummary()`：
   - 在阶段1 结束时，遍历 `validatedVRfs[currentSeed]`
   - 收集所有已收到 VRF 的节点地址，**排序**（排序很重要，保证确定性）
   - 构造 `VRFSummaryMsg`，序列化后签名
4. 实现 `broadcastVRFSummary()`：参考 `vrfBroadcastMessage()` 的模式
5. 在 `ca/interface.cpp` 中注册 `HandleVRFSummaryMsgReq` 回调
6. 实现 `handleVRFSummaryMsg()`：
   - 验签（使用 `ca_algorithm::VerifySign`）
   - 验证 seed 是否为当前或上一周期
   - 存入 `validatedSummaries`
   - gossip 转发
7. 实现摘要修剪（参考 `pruneOldData()`）

**验证点 CP2**：
```bash
# 部署 3+ 节点
# 观察摘要交换日志
grep "VRF_CONFIRM.*PHASE2" mm_node1.log
# 预期：看到 generated summary、received summary、complete

# 验证 gossip 扩散
grep "PHASE2.*complete" mm_node*.log
# 预期：所有节点的 total_summaries 接近（等于在线节点数）

# 验证签名拒绝
# （需要手动构造伪造摘要测试，或通过单元测试验证）
```

**如果 CP2 不通过**：
- 如果摘要数量为 0：检查摘要生成时机是否正确（阶段1 结束后）
- 如果摘要数量不一致：检查 gossip 转发逻辑
- 如果验签失败：检查签名/验签的数据是否一致（序列化时是否排除了签名字段）

---

### 阶段 M3：共识计算与分发者选择集成

**目标**：实现共识集合计算，接入分发者选择路径。

**执行步骤**：

1. 实现 `computeDynamicThreshold(N)`：
   - 根据 N 确定阈值比例（参见 design.md 2.4 节）
   - 实现滞后区间逻辑
2. 实现 `computeConsensusSet()`：
   - 遍历 `validatedSummaries[currentSeed]`
   - 统计每个地址的 count
   - 按阈值筛选，排序输出
3. 实现 `resolveBoundaryEntries()`：
   - 识别边界条目（`threshold - δ ≤ count < threshold`）
   - 用 `SHA256(seed + 周期号 + addr)` 做确定性裁决
4. 修改 `calculatePackerByTime()`：
   - 使用共识集合替代原来的 `dataSource`
   - 共识集合不足时返回错误码（触发降级）
5. 添加新旧路径对比日志（调试用，后续可移除）

**验证点 CP3**：
```bash
# 部署 5+ 节点，运行 100 个周期
# 核心验证：所有节点选出相同的分发者
grep "dispatcher selected" mm_node*.log | awk '{print $NF}' | sort | uniq -c
# 预期：只有一个唯一值，count = 节点数 × 100

# 如果不一致：
# 1. 对比共识集合
grep "PHASE3.*consensus_set" mm_node*.log
# 2. 对比阈值
grep "threshold=" mm_node*.log
# 3. 对比摘要数量
grep "PHASE2.*complete" mm_node*.log
```

**如果 CP3 不通过**：这是最关键的问题，必须彻底排查：
- 共识集合不同 → 摘要集合不同 → 检查 M2 的 gossip 完整性
- 阈值不同 → 检查档位切换逻辑和滞后区间
- 边界裁决不一致 → 检查裁决种子计算是否所有节点相同

---

### 阶段 M4：自适应机制与降级

**目标**：实现多级降级、分区感知、时钟偏差处理、冷启动。

**执行步骤**：

1. 实现时间驱动的多级降级：
   - 所有降级决策基于**绝对时间**（NTP 同步后），不基于本地摘要数量
   - Level 0/1/2/3 的时间点和阈值参见 design.md 3.1 节
2. 实现分区感知：
   - 覆盖率 = 收到的摘要数 / 预估全网节点数
   - 覆盖率 < 60% 时标记分区
3. 实现时钟偏差检测
4. 实现冷启动处理
5. 实现共识集合不足时的兜底逻辑

**验证点 CP4**：
```bash
# 模拟节点离线
# 关闭 30% 节点后观察
grep "DEGRADE" mm_*.log
# 预期：触发降级，但系统继续运行

# 模拟网络分区
# 隔离部分节点后观察
grep "PARTITION" mm_*.log
# 预期：被隔离节点检测到分区

# 新节点加入
# 观察第一个周期
grep "cold_start" mm_newnode.log
# 预期：首周期跳过选择
```

---

### 阶段 M5：集成测试与优化

**目标**：全功能测试，性能验证，长期稳定性。

**执行步骤**：

1. 在不同规模环境（20/50/100 节点）下运行测试
2. 运行回归测试（参见 testing.md 第 5 节）
3. 长期运行测试（24 小时），监控内存和性能
4. 根据测试结果调优参数

**验证点 CP5**：
```bash
# 24 小时稳定性
# 检查进程存活
ps aux | grep mm_node

# 检查内存
# RSS 增长 < 100 MB/24h

# 检查一致性
grep "dispatcher selected" mm_node*.log | awk '{print $NF}' | sort | uniq -c
# 预期：24 小时内零不一致

# 检查区块间隔
# 标准差 < 1 秒
```

---

## 日志排查速查表

开发过程中最常用的日志检查命令：

```bash
# 1. 确认协议整体状态
grep "VRF_CONFIRM" mm_*.log | tail -50

# 2. 分发者选择结果（核心指标）
grep "dispatcher selected" mm_*.log

# 3. 一致性检查（多节点对比）
grep "dispatcher selected.*seed=X" mm_node*.log | awk '{print $NF}' | sort | uniq -c

# 4. 摘要收集情况
grep "PHASE2.*complete" mm_*.log

# 5. 降级事件
grep "DEGRADE" mm_*.log

# 6. 分区检测
grep "PARTITION" mm_*.log

# 7. 时钟异常
grep "CLOCK_SKEW" mm_*.log

# 8. 错误和异常
grep -E "ERROR.*VRF_CONFIRM|FATAL" mm_*.log
```

---

## 问题分析决策树

当测试中发现问题时，按以下决策树排查：

```
分发者选择不一致？
├── 共识集合不同？
│   ├── 摘要数量不同 → M2 问题：gossip 未完全收敛
│   │   ├── 检查网络延迟
│   │   ├── 检查阶段2 时间是否足够
│   │   └── 检查是否有摘要被错误拒绝
│   └── 摘要数量相同但内容不同 → M2 问题：摘要内容不一致
│       ├── 检查 VRF 数据收集差异
│       └── 检查摘要生成逻辑
├── 阈值不同？
│   ├── 节点数统计不同 → 检查节点数获取方式
│   └── 档位不同 → 检查滞后区间逻辑
└── 边界裁决不同？
    └── 裁决种子不同 → 检查 seed 和周期号是否一致

频繁降级？
├── 摘要数量少 → 检查 gossip 传播
├── 阈值过严 → 调整阈值参数
└── 节点离线多 → 网络环境问题

内存增长？
├── 摘要未修剪 → 检查 pruneOldData 逻辑
└── 其他泄漏 → valgrind / AddressSanitizer

区块间隔异常？
├── 降级导致延长 → 检查 DEGRADE 日志
├── 共识计算慢 → 检查 PHASE3 耗时
└── 周期跳过 → 检查是否有周期未产出区块
```

---

## 重要提醒

1. **分阶段完成**：不要试图一次性实现所有功能。每完成一个阶段，编译、测试、验证，确保稳定后再进入下一阶段。

2. **每个 Checkpoint 必须通过**：如果 CP 不通过，不要跳过，必须找到根因并修复。尤其是 CP3（一致性验证），这是整个方案的核心价值。

3. **先读后写**：在修改任何代码之前，先完整阅读相关的现有代码。特别关注 `run()`、`extractVRFData()`、`calculatePackerByTime()` 这三个函数。

4. **日志先行**：每实现一个功能，先添加足够的日志，再验证功能。日志是排查问题的唯一手段。

5. **不要引入不必要的抽象**：遵循项目现有代码风格，不要为了"优雅"而引入额外的类层次或设计模式。三个阶段的逻辑可以直接写在 `run()` 函数中。

6. **线程安全**：`validatedSummaries` 的所有读写操作都必须在 `mutex_` 的保护下进行。读操作使用 `shared_lock`，写操作使用 `unique_lock`。

7. **向后兼容测试**：在 M5 阶段，需要测试新旧节点混合部署的场景。旧节点应该不受影响，新节点在摘要不足时降级到与旧节点相同的行为。
