# GetBlockByHeight JSON Key 命名规范化方案

## 背景

`GetBlockByHeight` RPC 接口返回的 JSON 中，key 的命名风格不统一，存在 camelCase、PascalCase、SCREAMING_SNAKE_CASE、全小写复合词等多种风格混用的问题。

**目标风格：统一 camelCase**（与 Ethereum、Solana、Cosmos、Polkadot 等主流公链一致，也是 JSON 生态的事实标准）。

## 需要修改的 Key 列表

### 一、PascalCase → camelCase

这些 key 位于 `txs[].data.txinfo` 中，当前为首字母大写的 PascalCase，需改为首字母小写的 camelCase。

| # | 旧名称 | 新名称 | 出现的交易类型 |
|---|--------|--------|---------------|
| 1 | `BeginTime` | `beginTime` | 跨链交易 |
| 2 | `BonusAddr` | `bonusAddr` | 出块奖励 |
| 3 | `CallType` | `callType` | 合约调用 |
| 4 | `CommissionRate` | `commissionRate` | 质押 |
| 5 | `CrossChainInvestmentContractAddr` | `crossChainInvestmentContractAddr` | 跨链交易 |
| 6 | `CrossChainTxType` | `crossChainTxType` | 跨链交易 |
| 7 | `EndTime` | `endTime` | 跨链交易 |
| 8 | `EnteringMoreContractAddr` | `enteringMoreContractAddr` | 跨链交易 |
| 9 | `ExchangeRate` | `exchangeRate` | 跨链交易 |
| 10 | `ExpirationDate` | `expirationDate` | 跨链交易 |
| 11 | `Identifier` | `identifier` | 跨链交易 |
| 12 | `LockAmount` | `lockAmount` | 锁仓 |
| 13 | `LockType` | `lockType` | 锁仓 |
| 14 | `MIN_VOTE_NUM` | `minVoteNum` | 跨链交易（SCREAMING_SNAKE_CASE → camelCase） |
| 15 | `Name` | `name` | 跨链交易 |
| 16 | `PeerChainTokenAddr` | `peerChainTokenAddr` | 跨链交易 |
| 17 | `ProposalHash` | `proposalHash` | 治理投票 |
| 18 | `StakeAmount` | `stakeAmount` | 质押 |
| 19 | `StakeType` | `stakeType` | 质押 |
| 20 | `Title` | `title` | 治理投票 |
| 21 | `UnLockUtxo` | `unLockUtxo` | 解锁 |
| 22 | `UndelegatingUtxo` | `undelegatingUtxo` | 取消委托 |
| 23 | `UnstakeUtxo` | `unstakeUtxo` | 取消质押 |
| 24 | `Version` | `version` | 跨链交易 |
| 25 | `VoteHash` | `voteHash` | 治理投票 |
| 26 | `VoteNumber` | `voteNumber` | 治理投票 |
| 27 | `VoteTxType` | `voteTxType` | 治理投票 |
| 28 | `VoteType` | `voteType` | 治理投票 |

### 二、全小写复合词 → camelCase

这些 key 由多个单词组成但全部小写，缺乏可读性，需改为 camelCase。

| # | 旧名称 | 新名称 | JSON 路径 |
|---|--------|--------|-----------|
| 29 | `assettype` | `assetType` | `txs[].utxos[].assettype` |
| 30 | `merkleroot` | `merkleRoot` | `blocks.blocks.merkleroot` |
| 31 | `prevhash` | `prevHash` | `blocks.blocks.prevhash` |
| 32 | `txinfo` | `txInfo` | `txs[].data.txinfo` |
| 33 | `vinsign` | `vinSign` | `txs[].utxos[].vin.vinsign` |

### 三、歧义名称修正

| # | 旧名称 | 新名称 | 说明 |
|---|--------|--------|------|
| 34 | `EnteringMoreContractAddr` | `tokenContractAddr` | 原名称含义不清，改为更准确的代币合约地址 |
| 35 | `canBeStake` | `genesisToken` | 原名称有歧义，改为创世代币 |

### 四、异常大小写修正

| # | 旧名称 | 新名称 | 说明 |
|---|--------|--------|------|
| 36 | `dependentCTx` | `dependentCtx` | `CTx` 大小写不规范，修正为 `Ctx` |

### 五、补充遗漏（代码扫描中发现 block.json 前 45 高度未覆盖的 key）

| # | 旧名称 | 新名称 | 出现的交易类型 |
|---|--------|--------|---------------|
| 37 | `BonusAmount` | `bonusAmount` | 出块奖励 |
| 38 | `BonusAddrList` | `bonusAddrList` | 出块奖励 |
| 39 | `FundLockedAmount` | `fundLockedAmount` | 基金分配 |
| 40 | `FundPackageAmount` | `fundPackageAmount` | 基金分配 |
| 41 | `MultiSignPub` | `multiSignPub` | 多签交易 |
| 42 | `SignAddrList` | `signAddrList` | 多签交易 |
| 43 | `SignThreshold` | `signThreshold` | 多签交易 |
| 44 | `RevokeProposalHash` | `revokeProposalHash` | 治理撤销 |

## 无需修改的 Key（已符合 camelCase 或单词规范）

### 已符合 camelCase 的复合词

`baseFee`, `blockCoinbase`, `blockPrevRandao`, `blockTimestamp`, `contractDeployer`, `delegateAmount`, `delegateType`, `errorCallstack`, `preHash`, `virtualMachine`

### 符合规范的全小写单词

`addr`, `blocks`, `bytes`, `code`, `consensus`, `creation`, `creator`, `data`, `destruction`, `gas`, `hash`, `height`, `id`, `identity`, `independence`, `info`, `input`, `jsonrpc`, `log`, `multisign`, `nonce`, `output`, `owner`, `prevout`, `pub`, `recipient`, `result`, `sender`, `sign`, `signature`, `status`, `storage`, `time`, `topics`, `transfer`, `txs`, `type`, `utxos`, `value`, `vin`, `vout`

## 统计

| 类别 | 数量 |
|------|------|
| PascalCase → camelCase | 28 + 8（补充遗漏）|
| 全小写复合词 → camelCase | 5 |
| 歧义名称修正 | 2 |
| 异常大小写修正 | 1 |
| **合计需修改** | **44** |
| 已符合规范（无需修改） | ~50 |

## 注意事项

1. **`preHash` 与 `prevhash`**：两者含义相近但当前命名不一致。`preHash` 已是 camelCase 无需改动，`prevhash` 改为 `prevHash` 后两者风格统一，但语义上仍有 `pre` vs `prev` 的差异，是否统一语义可另行讨论。
2. **`txinfo` → `txInfo`**：此 key 是 `txs[].data` 下的子对象名，改动后其内部所有子 key 的路径也会变化。
3. **`MIN_VOTE_NUM`**：这是唯一一个 SCREAMING_SNAKE_CASE 的 key，属于代码常量命名泄漏到 JSON 序列化输出的典型问题。
4. **数据衍生的 key 不在本次范围内**：`storage` 和 `data` 中以地址或 hash 作为 map key 的条目（如 `79D19E18..._rootHash`）是运行时数据，不属于命名规范问题。
5. **连带影响**：修改需同步更新 proto 定义 / JSON 序列化代码、RPC 文档、以及任何已对接的客户端工具。
