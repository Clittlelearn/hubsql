# Contract Repack Retry：Nonce 与部分确认恢复设计

## 1. 文档目的

本文固化第二轮讨论形成的设计边界，作为后续实现前的检查清单。内容覆盖：

- 原 VRF 批次原子性；
- pending nonce 与 pending UTXO；
- 区块内连续 nonce 验证；
- 跨 VRF 批次的 `WAITING_NONCE`；
- 部分原交易已经上链时的安全排除证明；
- 重试状态分类、落库、回滚、可观测性；
- 实施里程碑和测试用例。

本文不授权降低交易签名、UTXO、nonce、VRF 或区块验证要求。

## 2. 已确认的问题

30 TPS 回归中，节点侧形成 857 笔交易分组，最终上链 677 笔。两个完整批次被拒绝：

| 原批次数 | 实际建块数 | 失败原因 |
|---:|---:|---|
| 70 | 2 | 68 笔 `nonce mismatch` 后仍建块，dispatcher VRF `alpha mismatch` |
| 110 | 93 | 首次执行删除 17 笔后仍建块，dispatcher VRF `alpha mismatch` |

问题由三层组成：

1. 交易创建只读取已确认数据库 nonce，没有原子预留 pending nonce；
2. 区块验证按单笔交易读取数据库 nonce，不能验证同账户连续 nonce；
3. 执行阶段删除失败交易后仍构造缩减区块，破坏原 dispatcher VRF 集合。

重打包机制只能恢复“父状态变化后完整原交易集合仍然有效”的批次，不能使已被其他交易占用的 nonce 或已花费 UTXO重新有效。

## 3. 核心安全不变量

### 3.1 原始授权集合

默认要求：

```text
actual_build_set == original_dispatcher_vrf_set
```

任一交易验证或执行失败时，不得静默删除后继续使用原 dispatcher VRF。

允许的唯一例外是协议明确验证的“相同交易已经位于候选父链祖先”的排除：

```text
included_set ∩ confirmed_excluded_set == empty
included_set ∪ confirmed_excluded_set == original_dispatcher_vrf_set
```

### 3.2 证明、状态和执行

- 重试不修改原交易内容、哈希、签名、时间或 nonce；
- 重试不改变 dispatcher、packager 或原 dispatcher VRF；
- 每次重试基于最新父状态重新验证和执行；
- 旧执行结果、旧候选块和旧 validator VRF 不得复用；
- 新候选块重新生成 validator VRF；
- 同一批次只有一个活动执行者；
- 未知错误默认不缩减批次、不自动无限重试。

### 3.3 确定性

- 所有节点使用相同规范交易顺序；
- 同账户交易按 nonce 串行；
- 不同账户只有在合约依赖和 UTXO依赖允许时才可并行；
- nonce、UTXO和合约状态临时视图随整个区块原子提交或整体丢弃。

## 4. Pending Nonce 管理

### 4.1 分配规则

每个账户维护：

```text
confirmed_nonce
contiguous_pending_nonce
reserved_nonce_set
```

新交易 nonce 应通过账户级原子操作获得：

```text
next_nonce = max(confirmed_nonce, contiguous_pending_nonce)
reserve(next_nonce)
contiguous_pending_nonce = next_nonce + 1
```

禁止多个创建线程分别读取数据库后获得相同 nonce。

### 4.2 状态生命周期

建议状态：

```text
RESERVED
SIGNED
DISPATCHED
VRF_AUTHORIZED
WAITING_NONCE
EXECUTING
CONFIRMED
REPLACED
PERMANENT_FAILED
EXPIRED
```

状态必须能够在进程重启后恢复。内存计数器只能作为缓存，不能作为唯一事实来源。

### 4.3 多来源和 replacement

同一账户可能同时被菜单、RPC、SDK、MetaMask、OKX 或其他节点使用。本机 pending manager 无法独占外部账户。

进入 VRF 分组前必须处理：

```text
same sender + same nonce
```

只能有一个有效候选进入授权集合。进入 VRF 授权后不得本地替换或删改；若另一笔相同 nonce 先上链，原批次进入 `NONCE_CONFLICT`。

### 4.4 RPC 语义

```text
eth_getTransactionCount(latest)  = confirmed_nonce
eth_getTransactionCount(pending) = 连续 pending 序列末尾
```

存在很大的未来 nonce 不能令 `pending` 直接跳号。

## 5. Pending UTXO 管理

pending nonce 不能替代 UTXO预留。并发创建交易时必须避免：

```text
Tx A nonce N   spends UTXO X
Tx B nonce N+1 spends UTXO X
```

发送端需要原子预留输入 UTXO，并记录其所属交易、账户和释放条件。

释放条件包括：

- 交易确认；
- 交易被合法 replacement；
- 永久失败；
- 过期；
- 链回滚后的重新激活。

区块验证还必须维护区块内临时 `spent_utxo_set`，避免同一区块两笔交易在落库前都通过数据库检查。

## 6. 区块内连续 Nonce 验证

### 6.1 临时视图

对候选父状态中的每个账户初始化：

```text
temporary_nonce[address] = parent_state_nonce[address]
```

按规范区块顺序验证：

```text
require tx.nonce == temporary_nonce[sender]
temporary_nonce[sender]++
```

任一交易失败时丢弃整个临时视图，不得将剩余交易继续打包。

### 6.2 落库

整块成功后原子提交最终临时值。逻辑上同时满足：

```text
每笔交易 nonce == 当时期望值
最终 nonce == 最后一笔有效交易 nonce + 1
```

不得无验证地写入 `tx.nonce + 1`，也不得忽略交易 nonce 仅对数据库计数器加一。

### 6.3 回滚

回滚应恢复父状态或 undo 记录，不应统一只执行一次 `nonce--`。一个区块可包含同账户多笔交易，多区块回滚还必须按逆序恢复。

## 7. 跨 VRF 批次：WAITING_NONCE

不改变既有 VRF 分组和打包者的前提下，采用等待方案。

对每个批次中的账户，在最新父状态上分类：

```text
batch_first_nonce == chain_nonce -> READY
batch_first_nonce >  chain_nonce -> WAITING_NONCE
batch_first_nonce <  chain_nonce -> 检查相同交易是否已确认
```

### 7.1 整批等待

只要批次中任一账户存在 nonce 间隙，整个原 VRF 批次进入 `WAITING_NONCE`。不得让其他账户的交易先组成缩减区块。

等待记录至少持久化：

- 完整原始 `TxMsgReq`；
- 交易集合摘要和规范顺序；
- dispatcher VRF、dispatcher、packager；
- 每账户 nonce 范围及缺失前序；
- 创建时间、过期时间、最后原因；
- 当前父状态检查结果。

### 7.2 唤醒

新块落库、链回滚、前序交易确认、replacement 确认和定时到期均触发重新检查。唤醒后重新验证父块、VRF、nonce、UTXO、依赖和完整集合。

### 7.3 防 DoS

设置：

- 最大 nonce gap；
- 单账户等待批次数；
- 全局等待交易数及字节数；
- 批次 TTL；
- 原交易有效期；
- 后续批次不得越过同账户更早等待批次。

超过限制时明确终止，不允许无限持有。

## 8. 部分确认恢复证明

### 8.1 允许条件

原集合 `{A,B,C}` 中 A 只有在满足下列全部条件时才可作为确认排除项：

1. 上链交易哈希与原 A 完全相同；
2. A 所在区块是新候选块父块的祖先；
3. A 已成功执行并属于有效链状态；
4. B、C 在包含 A 结果的最新父状态上重新执行；
5. 包含集合与排除集合无重复，合并后恰好还原原 VRF 集合。

“相同账户及相同 nonce 的另一笔交易上链”不满足条件，必须标记 `NONCE_CONFLICT`。

### 8.2 建议证明内容

```text
reason = ALREADY_CONFIRMED
excluded transaction full bytes
confirmed block height
confirmed block hash
transaction index / inclusion proof
candidate parent hash
dispatcher VRF digest
original transaction-set digest
included-set digest
packager signature
```

若区块支持交易 Merkle commitment，应提供 inclusion proof；否则验证者按区块哈希查询完整区块。缺少祖先区块数据时应拒绝或等待，不得默认相信打包者。

### 8.3 现有 ExclusionProof 的边界

现有证明主要支持 Gas 超限部分块，不能直接作为已确认证明：

- 打包者签名不能证明链上存在性；
- `reason` 为自由字符串；
- 未绑定确认区块、候选父块和 dispatcher VRF 摘要；
- 未验证祖先关系；
- 当前时间公平规则不适用于排除更早的已确认交易；
- 缺少集合唯一性和跨候选块防重放约束。

应使用独立的严格原因类型及验证分支，不得用任意字符串绕过验证。

### 8.4 重组行为

若 A 的祖先区块随父链一起被重组，则以它为父状态构造的 B/C 后继块也不再属于新主链。重新处理时必须恢复 A 的 pending/等待状态并重新进行完整分类。

## 9. 重试决策表

| 状态 | 判断 | 动作 |
|---|---|---|
| `READY` | 最小 nonce 等于父状态 nonce，批内连续，UTXO有效 | 完整组重新执行 |
| `WAITING_NONCE` | 最小 nonce 大于父状态 nonce | 整批持久化等待 |
| `SAME_TX_CONFIRMED` | 较小 nonce 对应的相同哈希交易位于父链祖先 | 构造确认排除证明，剩余交易重执行 |
| `NONCE_CONFLICT` | 相同 nonce 被不同哈希交易占用 | 永久终止原批次 |
| `UTXO_SPENT` | 输入被不同交易消费 | 永久终止原批次 |
| `PARTIAL_UNPROVEN` | 声称已确认但无法证明祖先包含关系 | 拒绝或等待同步 |
| `DEPENDENCY_CONFLICT` | nonce 顺序与合约依赖形成环 | 进入 VRF 前拒绝；已授权批次终止 |
| `VRF_CONTEXT_CHANGED` | 候选集合或证明上下文变化 | 按既定策略直接放弃 |
| `STALE_PARENT` | 执行期间父状态变化 | 丢弃派生状态并有限重试 |

## 10. Nonce 与合约依赖

进入执行前合并：

```text
contract dependency edges
account nonce edges
UTXO dependency/conflict edges
```

合并图必须无环。出现：

```text
nonce requires A -> B
contract dependency requires B -> A
```

时不得通过改变节点本地执行顺序解决，应明确拒绝或等待重新构造。

## 11. 实施里程碑

### N0：证据和不变量固化

- 固化 70→2、110→93 的日志证据；
- 增加原授权集合与实际建块集合检查；
- 增加明确错误分类和审计日志；
- 暂不允许任何未证明的部分排除。

检查点：

- 缩减集合不能进入 BuildBlock；
- 本地 success 不再掩盖验证节点必然拒绝；
- 原有成功批次行为不变。

### N1：确定性批内 Nonce

- 定义规范交易顺序；
- 实现区块级临时 nonce 视图；
- 同账户串行验证；
- 整块原子提交和 undo 回滚；
- 打包者、流转验证和广播验证使用相同算法。

检查点：

- 同账户 `N,N+1,N+2` 可在一块中通过；
- 重复、跳号、倒序均被所有节点一致拒绝；
- 失败不污染数据库；
- 回滚恢复父状态 nonce。

### N2：Pending Nonce 与 Pending UTXO

- 账户级原子 nonce 预留；
- 输入 UTXO原子预留；
- 持久化生命周期；
- RPC latest/pending 语义；
- replacement 在 VRF 授权前完成。

检查点：

- 30 TPS 并发创建不产生本地重复 nonce；
- 同一 UTXO不被并发交易重复选择；
- 重启、确认、失败、替换和回滚后状态一致。

### N3：跨批次 WAITING_NONCE

- 整批等待及持久化；
- 新块、回滚和超时唤醒；
- 队头顺序；
- gap、容量、TTL 和防 DoS。

检查点：

- 后续 nonce 批次不会越过前序批次；
- 等待不改变原 VRF 上下文；
- 前序永久失败时后续批次明确终止；
- 节点重启后等待批次不丢失。

### N4：已确认交易排除证明

- 引入 `ALREADY_CONFIRMED` 严格证明；
- 验证相同哈希、区块包含、父链祖先和执行成功；
- 校验 included/excluded 集合唯一性及完整并集；
- 证明绑定父块、VRF 和集合摘要；
- 重组恢复。

检查点：

- 原 A 确认后 B/C 可安全继续；
- 相同 nonce 不同哈希不能冒充 A；
- 旁支、伪造、重复、跨父块重放证明均被拒绝；
- 所有节点对同一证明得到一致结果。

### N5：压力与故障回归

- 10 TPS 和 30 TPS；
- 同账户连续 nonce；
- 跨批次乱序；
- 父块连续变化；
- 部分相同交易确认；
- replacement 冲突；
- 节点重启、数据库同步和链回滚。

验收：

```text
unexplained_missing == 0
duplicate_onchain == 0
vrf_set_mismatch_broadcast == 0
nonce_state_divergence == 0
pending_state_loss == 0
```

## 12. 测试矩阵

| ID | 场景 | 期望 |
|---|---|---|
| ATOM-01 | 70 笔中 68 笔验证失败 | 整批不建块 |
| ATOM-02 | build 集合多/少一笔 | 建块前拒绝 |
| NONCE-01 | 父 nonce=N，批内 N/N+1/N+2 | 通过并提交 N+3 |
| NONCE-02 | 重复 N/N | 整批拒绝 |
| NONCE-03 | N/N+2 | `WAITING_NONCE` 或拒绝，不跳号 |
| NONCE-04 | 不同账户连续序列 | 可按依赖安全并行 |
| NONCE-05 | 执行中失败 | 临时 nonce 不落库 |
| NONCE-06 | 含同账户三笔的块回滚 | 恢复块前 nonce |
| PEND-01 | 多线程同账户创建 | nonce 唯一且连续 |
| PEND-02 | 并发选择 UTXO | 输入不重复预留 |
| PEND-03 | 进程重启 | pending 状态恢复 |
| WAIT-01 | 批次从 N+1 开始 | 整批等待 N |
| WAIT-02 | N 确认 | 原打包者重新检查并继续 |
| WAIT-03 | N 被不同交易占用 | 原批次 `NONCE_CONFLICT` |
| WAIT-04 | 超大 gap | 按限制拒绝 |
| WAIT-05 | 等待期间 VRF 上下文变化 | 直接放弃 |
| CONF-01 | 原 A 位于候选父链祖先 | 排除 A，B/C 重执行并验证原 VRF |
| CONF-02 | 同 nonce 不同交易 X 已确认 | 不得把 X 当作 A |
| CONF-03 | A 仅位于旁支 | 证明拒绝 |
| CONF-04 | A 同时 included/excluded | 证明拒绝 |
| CONF-05 | 排除证明跨父块重放 | 证明拒绝 |
| CONF-06 | 验证节点缺少引用区块 | 等待同步或拒绝，不默认通过 |
| DEP-01 | nonce 边与合约边无环 | 规范顺序一致 |
| DEP-02 | nonce 与合约依赖成环 | 明确拒绝 |
| REORG-01 | 已确认 A 及后继块被重组 | 恢复 pending 并重新分类 |

### 12.1 算法测试要求

每个里程碑必须同步增加可重复、无网络依赖的算法测试，不能只依靠 16 节点压力测试观察成功率。优先把下列逻辑提取为纯函数或可注入状态的组件：

- 原授权集合、included 集合和 excluded 集合的不变量检查；
- nonce 连续、重复、跳号、倒序及账户间独立性；
- `READY/WAITING_NONCE/SAME_TX_CONFIRMED/NONCE_CONFLICT` 分类；
- pending nonce 原子分配、连续 pending 计算和 replacement 决策；
- pending UTXO预留、释放及区块内冲突；
- nonce 边、合约依赖边和 UTXO边的合并与环检测；
- 确认排除证明的集合重构、祖先约束和防重放绑定；
- 临时状态提交、失败丢弃和回滚恢复。

算法测试必须包含成功路径、边界值和恶意输入，不得用跳过签名、VRF、nonce 或 UTXO校验的方式构造“通过”结果。

### 12.2 逐里程碑质量门禁

每个 N0–N5 里程碑遵循固定顺序：

```text
实现本里程碑最小变更
  -> 新增/更新对应算法测试
  -> 运行统一算法与组件测试
  -> 使用全部 CPU 核心编译 openhive
  -> 记录测试、编译结果和未决风险
  -> 全部通过后才能进入下一里程碑
```

任一测试或编译失败时必须停留在当前里程碑。不得把已知失败带入下一阶段，也不得通过删除断言、放宽安全条件或跳过测试解除门禁。

统一命令：

```bash
bash tests/contract_repack_retry/run_tests.sh
cmake --build build --target openhive -j$(nproc)
```

若某里程碑新增独立测试目标，统一脚本必须调用该目标。N5 除上述本地门禁外，还必须经过明确授权后执行 16 节点黑盒测试和逐哈希对账。

### 12.3 里程碑测试映射

| 里程碑 | 必须新增或完成的测试 | 进入下一阶段条件 |
|---|---|---|
| N0 | ATOM-01/02、错误分类、缩减集合禁止广播 | 算法测试、组件检查、全量编译全部通过 |
| N1 | NONCE-01–06、规范顺序、临时状态原子性 | 打包者与验证者对所有向量结果一致 |
| N2 | PEND-01–03、replacement、并发 UTXO预留 | 并发、重启和回滚测试无重复分配或状态丢失 |
| N3 | WAIT-01–05、TTL、gap、容量、唤醒和队头顺序 | 等待不改变 VRF 集合且不能被后续 nonce 越过 |
| N4 | CONF-01–06、集合唯一性、祖先证明和防重放 | 伪造、旁支、不同哈希和重放证明全部被拒绝 |
| N5 | 10/30 TPS、竞争、重启、同步、回滚和逐哈希对账 | 所有验收计数满足 N5 要求 |

## 13. 可观测性

每个批次至少记录：

- stable batch id 和原交易集合摘要；
- dispatcher/packager/VRF 摘要；
- attempt、父高度和父哈希；
- 每账户 confirmed/pending/first/last nonce；
- nonce 分类及缺失前序；
- pending UTXO数量；
- included 与 confirmed-excluded 摘要；
- 引用确认区块；
- READY、WAITING、RETRY、SUCCESS、ABORT 的明确状态；
- 最终错误分类。

禁止记录私钥或敏感签名材料。

## 14. 开始实现前的 Go/No-Go 检查

满足以下条件后再进入代码修改：

1. 明确唯一规范交易顺序；
2. 明确所有 nonce 验证入口并保证共用同一算法；
3. 明确区块内 UTXO冲突检查；
4. 明确 pending 状态持久化位置及恢复规则；
5. 明确 replacement 在 VRF 授权前后的边界；
6. 明确等待队列容量、gap 和 TTL；
7. 明确祖先关系查询和交易包含证明能力；
8. 明确 nonce 和 pending 状态的回滚/undo；
9. 明确协议版本和旧节点兼容策略；
10. 准备逐里程碑单测、组件测试和 16 节点回归。

任何一项未明确时，不应通过局部绕过 nonce 或放宽 VRF 验证来推进。
