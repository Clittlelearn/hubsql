# 模块1: 密码学与账户体系 - 核心调用链

## 1. 地址生成流程

```mermaid
flowchart TD
    A["Account::generatePkey()"] --> B["EVP_PKEY_paramgen\n(NID_secp256k1)"]
    B --> C["EVP_PKEY_keygen"]
    C --> D["generatePublicString()\ni2d_PUBKEY → DER编码"]
    C --> E["generatePrivateString()\nEVP_PKEY_get_bn_param → BIGNUM"]
    D --> F["_GenerateAddr()"]
    E --> F
    F --> G["GenerateAddr(_pubStr)"]
    G --> H{"检查AddressCache"}
    H -->|缓存命中| I["直接返回缓存地址"]
    H -->|缓存未命中| J{"公钥格式?"}
    J -->|"65B 0x04..."| K["raw_xy = [1:65]"]
    J -->|"33B 0x02/0x03"| L["EC_POINT_set_compressed_coordinates\n解压为未压缩XY"]
    J -->|DER格式| M["d2i_PUBKEY → EC_POINT_point2oct"]
    K --> N["keccak256_hex(raw_xy)"]
    L --> N
    M --> N
    N --> O["addr = hash.substr(-40)"]
    O --> P["evm_utils::ToChecksumAddress(addr)"]
    P --> Q["AddressCache.addPublicKey()\n写入缓存"]
    Q --> R["返回 EIP-55 地址 (40 hex)"]
```

**文件位置**: `utils/account_manager.cpp:405-465` (generatePkey), `1492-1552` (GenerateAddr)

## 2. 交易签名流程

```mermaid
flowchart TD
    A["Account::Sign(message)"] --> B["EthMessageHash(message)\nkeccak256(message)"]
    B --> C["EthSignRaw(hash32, pkey)"]
    C --> D["EVP_PKEY_get1_EC_KEY(pkey)"]
    D --> E["ECDSA_do_sign(hash, 32, ec_key)"]
    E --> F["获取r, s"]
    F --> G{"s > n/2 ?"}
    G -->|Yes| H["s = n - s\n(低s值归一化)"]
    G -->|No| I["保持原s值"]
    H --> J["暴力搜索 recovery id"]
    I --> J
    subgraph "Recovery ID 计算"
        J --> K["candidate ∈ {0,1}"]
        K --> L["x = r + candidate*n"]
        L --> M{"EC_POINT_set_compressed_coordinates\nybit ∈ {0,1}"}
        M --> N["EC_POINT_mul 恢复公钥Q"]
        N --> O{"Q == 原公钥?"}
        O -->|Yes| P["recid = ybit"]
        O -->|No| M
    end
    P --> Q["输出: r(32) || s(32) || v(27+recid)"]
```

**文件位置**: `utils/account_manager.cpp:150-163` (Sign), `165-288` (EthSignRaw), `726-741` (EthMessageHash)

## 3. 账户创建流程 (首次运行)

```mermaid
flowchart TD
    A["AccountManager::CreateInitialAccount()"] --> B["_createInitialAccountImpl()"]
    B --> C["Account(true)\n→ generatePkey()\n生成secp256k1密钥对"]
    C --> D["获取密码\nGetPasswordFromUser(true)"]
    D --> E{"密码非空?"}
    E -->|空| F["移除临时账户\n返回 CREATE_ACCOUNT_FAILED"]
    E -->|非空| G["获取私钥 account.GetPriStr()"]
    G --> H{"私钥非空?"}
    H -->|空| I["移除账户\n返回失败"]
    H -->|非空| J["SavePrivateKeyToKeystoreFile()"]
    J --> K["KeystoreManager::EncryptPrivateKey()"]
    subgraph "Keystore加密"
        K --> L["生成UUID"]
        K --> M["生成32B随机盐"]
        M --> N["scrypt(password, salt, n=262144, r=8, p=1)\n→ derivedKey(32B)"]
        N --> O["encryptKey = derivedKey[0:16]"]
        N --> P["生成16B随机IV"]
        O --> Q["AES-128-CTR 加密私钥"]
        P --> Q
        Q --> R["mac = keccak256(derivedKey[16:32] + ciphertext)"]
        R --> S["输出 JSON keystore 文件"]
    end
    J --> T["写入 keystore 文件\n~/.mm/keystore/<address>.json"]
    T --> U["返回 SUCCESS"]
```

**文件位置**: `utils/account_manager.cpp:1374-1452` (_createInitialAccountImpl), `utils/keystore.cpp:218-326` (EncryptPrivateKey)

## 4. 账户加载流程 (启动时)

```mermaid
flowchart TD
    A["AccountManager::Initialize()"] --> B["确保 keystore 目录存在"]
    B --> C["_scanKeystoreDirectory()\n扫描 *.json 文件"]
    C --> D{"文件列表为空?"}
    D -->|是| E["返回 EMPTY_KEYSTORE\n触发创建新账户"]
    D -->|否| F["loadExistingAccounts()"]
    F --> G{"文件数量 > 10 ?"}
    G -->|是| H["询问是否多线程批量处理"]
    H -->|是| I["UnlockAccountsBatchMode()"]
    G -->|否| J["逐个加载流程"]
    H -->|否| J
    subgraph "单个账户加载"
        J --> K["展示账户地址"]
        K --> L["获取密码(最多3次重试)"]
        L --> M["load_account_from_key_store()"]
        M --> N["读取 keystore JSON"]
        N --> O["KeystoreManager::DecryptPrivateKey()"]
        O --> P["验证MAC"]
        P --> Q["AES-128-CTR 解密"]
        Q --> R["hex私钥 → HexPrivateKeyToPkey()"]
        R --> S["创建 Account 对象\n设置密钥/公钥/私钥"]
        S --> T["GenerateAddr(pubStr)\n验证地址一致性"]
        T --> U["AddAccount()\n加入 _accountList"]
    end
    J --> V["设置默认账户"]
    V --> W["一致性检查\n确认所有账户有对应keystore文件"]
    W --> X["返回 SUCCESS"]
```

**文件位置**: `utils/account_manager.cpp:744-819` (Initialize), `863-1258` (loadExistingAccounts), `1876-1989` (load_account_from_key_store)

## 5. 密钥导入/导出流程

### 5.1 导入十六进制私钥

```mermaid
flowchart TD
    A["ImportHexPrivateKey(hexPrivateKey)"] --> B["Hex2Str → 原始字节"]
    B --> C["HexPrivateKeyToPkey()"]
    subgraph "HexPrivateKeyToPkey"
        C --> D["BN_bin2bn → BIGNUM priv"]
        D --> E["创建 secp256k1 EC_KEY"]
        E --> F["EC_KEY_set_private_key"]
        F --> G["EC_POINT_mul: Q = d*G"]
        G --> H["EC_KEY_set_public_key"]
        H --> I["EVP_PKEY_assign_EC_KEY"]
    end
    I --> J["i2d_PUBKEY → DER公钥"]
    J --> K["GenerateAddr(pubStr) → EIP-55地址"]
    K --> L["创建 Account 对象\n设置 key/pubStr/priStr/addr"]
    L --> M["AddAccount() → 加入 _accountList"]
```

**文件位置**: `utils/account_manager.cpp:685-724` (ImportHexPrivateKey), `1627-1751` (HexPrivateKeyToPkey)

### 5.2 密码加密导入

```mermaid
flowchart TD
    A["ImportEncryptedPrivateKey(hexPrivKey, password)"] --> B["ImportHexPrivateKey()\n(创建临时账户)"]
    B --> C["获取地址和私钥"]
    C --> D["SavePrivateKeyToKeystoreFile()\n(加密保存)"]
    D --> E["从 _accountList 移除临时账户?"]
    E --> F["load_account_from_key_store()\n(重新从keystore加载)"]
```

## 6. 签名验证流程

```mermaid
flowchart TD
    A["Account::Verify(message, signature)"] --> B{"signature.length() == 65?"}
    B -->|是: ETH格式| C["EthMessageHash(message)\n→ keccak256"]
    C --> D["提取 r(32), s(32), v(1)"]
    D --> E["v < 27 → v += 27"]
    E --> F{"v == 27 or 28?"}
    F -->|否| G["返回 false"]
    F -->|是| H["EVP_PKEY_get1_EC_KEY → EC_KEY"]
    H --> I["ECDSA_SIG_new + BN_bin2bn(r, s)"]
    I --> J["ECDSA_do_verify(hash, 32, sig, ec_key)"]
    J --> K["返回 ok==1"]
    B -->|否: DER格式| L["EVP_DigestVerifyInit"]
    L --> M["EVP_DigestVerify"]
    M --> N["返回是否成功"]
```

## 7. ECVRF 证明/验证流程

```mermaid
flowchart TD
    subgraph "ECVRF Prove"
        A1["Prove(sk_hex, alpha)"] --> A2["SecretHexToScalar"]
        A2 --> A3["DerivePublicPoint"]
        A3 --> A4["EncodeToCurveTryAndIncrement\n(pubkey_bytes, alpha) → h"]
        A4 --> A5["gamma = sk * h"]
        A5 --> A6["Rfc6979Nonce(sk_bytes, h_bytes, order) → k"]
        A6 --> A7["k*B, k*h → ChallengeGeneration → c"]
        A7 --> A8["s = k + c*sk (mod order)"]
        A8 --> A9["BuildProof(gamma, c, s)"]
        A9 --> A10["ProofToHash(gamma) → beta"]
    end
    subgraph "ECVRF Verify"
        B1["Verify(pk_hex, alpha, proof_hex)"] --> B2["BytesToPoint(pk, gamma)"]
        B2 --> B3["DecodeProof → gamma, c, s"]
        B3 --> B4["EncodeToCurveTryAndIncrement → h"]
        B4 --> B5["u = s*B - c*Y"]
        B5 --> B6["v = s*h - c*gamma"]
        B6 --> B7["ChallengeGeneration(Y, h, gamma, u, v) → c'"]
        B7 --> B8{"c == c' ?"}
        B8 -->|是| B9["ProofToHash(gamma) → beta"]
        B8 -->|否| B10["验证失败"]
    end
```

## 8. 数字信封流程

```mermaid
flowchart TD
    subgraph "EnvelopeWrapper (封装)"
        C1["数据 + 接收方公钥"] --> C2["Sha256(数据) → hash"]
        C2 --> C3["签名 hash → 签名值"]
        C1 --> C4["生成AES密钥+IV\nAES-128-CBC加密数据 → 密文"]
        C4 --> C5["RSA公钥加密AES密钥"]
        C5 --> C6["输出: 签名+RSA密文+AES密文"]
    end
    subgraph "OpenEnvelope (解封)"
        D1["输入: 签名+RSA密文+AES密文"] --> D2["RSA私钥解密 → AES密钥"]
        D2 --> D3["AES-128-CBC解密 → 原始数据"]
        D3 --> D4["Sha256(原始数据) → hash"]
        D4 --> D5["验证签名"]
        D5 --> D6["返回原始数据"]
    end
```
