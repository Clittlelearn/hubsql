# 模块1: 密码学与账户体系 - 重构建议与优先级

## 1. 整体架构问题

### 1.1 双曲线并存 (P0)

**现状**: crypto 模块使用 P-256 (`NID_X9_62_prime256v1`)，账户模块使用 secp256k1 (`NID_secp256k1`)
**影响**: 代码维护者容易混淆；可能误用曲线导致签名无法验证
**文件证据**:
- `utils/crypto.h:10` — `#define CRYPTO_CURVE_NID NID_X9_62_prime256v1`
- `utils/account_manager.cpp:431` — `EVP_PKEY_CTX_set_ec_paramgen_curve_nid(pctx, NID_secp256k1)`
- `utils/ecvrf_p256_sha256_tai.cpp:30` — `constexpr int kCurveNid = NID_X9_62_prime256v1`

**建议**:
1. 确认 `crypto::ecdsa_sign` / `crypto::ecdsa_verify` 的调用方是否与账户模块隔离
2. 若 crypto 模块仅供内部旧组件使用，标注 `[[deprecated]]`
3. 长期: 统一所有 ECDSA 操作到 secp256k1 或明确分离用途

**预估工时**: 2人周（含审计全部调用方 + 迁移）

### 1.2 AccountManager 职责过重 (P1)

**现状**: `AccountManager` 混杂了:
- 账户 CRUD (Add/Find/Delete/GetDefault)
- Keystore 文件管理 (Save/Load/ChangePassword)
- 密码交互逻辑 (重试/进度条/批量解锁UI)
- 公钥恢复

**文件证据**: `utils/account_manager.cpp` 约2165行，`loadExistingAccounts()` 独占~400行
**建议**: 拆分为 `AccountStore` (CRUD) + `KeystoreService` (文件操作) + `AccountUnlockUI` (密码交互)
**预估工时**: 1人周

## 2. 代码质量问题

### 2.1 线程安全问题

| 编号 | 问题 | 位置 | 优先级 | 工时 |
|------|------|------|--------|------|
| T-1 | `_accountList` 无锁保护，多线程同时 `AddAccount`/`FindAccount` | `account_manager.h:434` | **Critical** | 4h |
| T-2 | `_defaultAddress` 无原子性保证 | `account_manager.h:433` | High | 2h |
| T-3 | `GenerateUUID` 中 `static mt19937` 线程不安全 | `keystore.cpp:72` | Medium | 1h |

**T-1 详细修复方案**:
```cpp
// 当前: std::map<std::string, std::shared_ptr<Account>> _accountList;
// 建议:
std::shared_mutex _accountMutex;
std::map<std::string, std::shared_ptr<Account>> _accountList;

// 所有写操作加 unique_lock, 读操作加 shared_lock
```

### 2.2 错误处理不一致

| 问题 | 位置 | 说明 |
|------|------|------|
| 混用 `printf` 和 `ERRORLOG` | 多处 | `generateFilePkey():477` 用 printf, 其他地方用 ERRORLOG |
| 返回码语义混乱 | 全局 | 0=成功, 负值=失败, 但各函数错误码不统一 |
| 未检查 OpenSSL 返回值完整度 | `crypto.cpp` 多处 | `EC_KEY_set_private_key` 失败只打印不返回 |
| `EVP_PKEY_CTX_free(NULL)` 无保护 | `account_manager.cpp:413` | `ON_SCOPE_EXIT` 中无条件 free，但指针可能为 NULL |

### 2.3 死代码 / 废弃逻辑

| 位置 | 说明 | 状态 |
|------|------|------|
| `crypto.cpp:14-17` | `#define OPENSSL_1_1_0 0` — HKDF现代路径永不编译 | 死代码 |
| `account_manager.cpp:317-343` | DER格式签名验证分支 | 退役逻辑(ETH格式为主) |
| `account_manager.h:219` | `generatePkey()` 注释`generatePublicString(pkeyPtr);`但函数签名不对 | 注释残留 |
| `utils/hex_code.h:56-103` | `Test::hex_dump` 仅在测试中使用 | 建议移到 test 目录 |
| `crypto.h:28` | `CRYPTO_KEY_INFO "ENCRYPTION"` — 未在任何函数中使用 | 废弃未删 |

### 2.4 潜在安全风险

| 编号 | 风险 | 等级 | 位置 | 建议 |
|------|------|------|------|------|
| S-1 | 私钥明文在内存中 (`_priStr`) | Medium | `account_manager.cpp:387` | `mlock`/`VirtualLock`, 或用后清零 |
| S-2 | keystore 文件写入权限未显式设置 | Medium | `keystore.cpp:2011` | `chmod 0600` |
| S-3 | `EthMessageHash` 无 EIP-191 前缀 | Medium | `account_manager.cpp:728-729` | 链上交易没问题，链下签名需加前缀 |
| S-4 | `RAND_bytes` 返回值未检查 | Low | `account_manager.cpp:402` | 应添加错误处理 |
| S-5 | `GetPasswordFromUser` 递归 | Low | `keystore.cpp:458` | 改为循环 |
| S-6 | `std::string` 存储密钥无安全擦除 | Medium | 全局 | 使用 `OPENSSL_cleanse` 或 `SecureString` |

### 2.5 代码质量改进

| 编号 | 问题 | 位置 | 建议 | 工时 |
|------|------|------|------|------|
| Q-1 | `loadExistingAccounts()` 过复杂(~400行) | `account_manager.cpp:863-1258` | 抽取子函数 | 4h |
| Q-2 | `EthSignRaw()` 资源管理不完整(多处return前泄漏) | `account_manager.cpp:165-288` | 使用RAII封装BIGNUM/EC_POINT | 4h |
| Q-3 | `hex_code.cpp:8-32` `init_hexdigit_val` 每次调用重新初始化 | `hex_code.cpp:44-45` | 改为 `static const` 或 `constexpr` | 1h |
| Q-4 | `String` 到 OpenSSL buffer 的 unsafe cast | 多处 | 使用 `reinterpret_cast` 无检查 | 统一封装工具函数 | 2h |
| Q-5 | crypto.h 中所有函数参数为 C-array，调用不便 | `crypto.h` 全局 | 封装为 `std::array`/`std::span` | 4h |
| Q-6 | `keystore.h` 中 `#include` 过多且未使用 | `keystore.h:1-15` | 移除未使用的include | 0.5h |

## 3. 重构建议优先级排序

### P0 (Critical - 可能引发生产故障)

1. **线程安全修复**: `_accountList` 加锁 (4h)
2. **线程安全修复**: `_defaultAddress` 原子性 (2h)

### P1 (High - 架构改进)

3. **统一的返回码体系**: 定义统一错误码枚举，替换杂乱的 int 返回码 (8h)
4. **AccountManager 拆分**: AccountStore + KeystoreService + UnlockUI (40h)
5. **双曲线问题标注**: crypto模块加 `[[deprecated]]` 注释 (2h)

### P2 (Medium - 代码质量)

6. **Security: 私钥安全擦除** (4h)
7. **Security: keystore 文件权限** (1h)
8. **loadExistingAccounts 拆分子函数** (4h)
9. **EthSignRaw RAII 重构** (4h)
10. **Hex 验证改为 isxdigit** (1h)

### P3 (Low - 兼容性与清理)

11. **移除 crypto.cpp HKDF 死代码** (1h)
12. **统一 printf → ERRORLOG** (2h)
13. **移除 Test::hex_dump 到测试目录** (1h)
14. **移除 CRYPTO_KEY_INFO 无引用常量** (0.5h)
15. **GetPasswordFromUser 递归改循环** (1h)

## 4. 预估工时汇总

| 优先级 | 任务数 | 预估总工时 |
|--------|--------|-----------|
| P0 | 2 | 6h (~0.75人天) |
| P1 | 3 | 50h (~6.25人天) |
| P2 | 5 | 14h (~1.75人天) |
| P3 | 5 | 5.5h (~0.7人天) |
| **总计** | **15** | **75.5h (~9.5人天)** |

## 5. 推荐的阶段性重构路线

**阶段 A (1周, P0+P3)**:
- 线程安全修复 (P0)
- 清理死代码和废弃逻辑 (P3)
- 安全外围加固 (keystore 权限/密码循环)
- 验证: 并发压力测试

**阶段 B (2周, P1部分+P2)**:
- AccountManager 拆分
- 统一错误码
- RAII 重构
- 验证: 回归测试 + 安全审计

**阶段 C (可选, 1周)**:
- 双曲线废弃或迁移
- 性能优化 (地址缓存 LRU)

## 6. 需要人工验证的项

| 编号 | 问题 | 验证方法 |
|------|------|----------|
| V-1 | crypto::ecdsa_sign/verify 是否被账户模块间接调用 | `grep -r "crypto::ecdsa" mm/` |
| V-2 | `calculate_ecdh_shared_key` 双公钥设置是否正确 | 编写 ECDH 测试向量验证 |
| V-3 | `GetPasswordFromUser` 递归深度上限 | 压力测试: 输入不匹配密码50+次 |
| V-4 | OpenSSL 线程安全初始化是否完成 | 检查 `OPENSSL_init_crypto` 调用 |
| V-5 | `GenerateAddr` 三种公钥格式覆盖率 | 统计实际使用的公钥格式分布 |
| V-6 | spec_dev.md 2.4节 地址格式是否与当前实现完全一致 | 对比 EIP-55 测试向量 |
