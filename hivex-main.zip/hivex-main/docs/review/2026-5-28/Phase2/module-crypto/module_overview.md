# 模块1: 密码学与账户体系 - 模块概述

## 1. 模块职责与定位

本模块负责 MeMeChain 区块链的密码学基础设施，包含三层架构：

| 层级 | 职责 | 核心文件 |
|------|------|----------|
| 底层密码学 | ECDH/ECDSA/AES-GCM/HMAC/HKDF | `utils/crypto.cpp/h` |
| 账户体系 | 密钥生成/签名验证/地址生成/验证 | `utils/account_manager.cpp/h` |
| EVM预编译 | secp256k1恢复/SHA256/RIPEMD160/BN操作 | `silkpre/lib/silkpre/precompile.cpp/h` |

辅助模块：SHA256 `utils/sha256.cpp`、Hex编解码 `utils/hex_code.cpp`、Keystore加密存储 `utils/keystore.cpp`、Base64 `utils/base64.cpp`、地址缓存 `utils/address_cache.h`、已验证地址追踪 `utils/verified_address.h`、ECVRF `utils/ecvrf_p256_sha256_tai.cpp`、数字信封 `utils/envelop.cpp`、Keccak256 `utils/keccak_cryopp.hpp`、合约工具 `utils/contract_utils.cpp`。

## 2. 对外接口（导出函数/API/调用方）

### 2.1 crypto 模块 (P-256 曲线)

| 接口 | 说明 | 调用方 |
|------|------|--------|
| `rand_salt()` | 生成随机盐 | 内部使用 |
| `generate_ecdh_keys()` | 生成 ECDH 密钥对 | 密钥协商场景 |
| `calculate_ecdh_shared_key()` | 计算 ECDH 共享密钥 | 密钥协商场景 |
| `ecdsa_sign()` / `ecdsa_verify()` | ECDSA 签名/验签 | 内部使用 |
| `hmac_sha256()` | HMAC-SHA256 | HKDF/认证 |
| `createHkdfBytes()` | HKDF 密钥派生 | 加密密钥导出 |
| `aes_encrypt()` / `aes_decrypt()` | AES-256-GCM 加解密 | 数据加密 |

> **可信度: 高**。crypto.cpp 使用 P-256 曲线（NID_X9_62_prime256v1），与账户层的 secp256k1 不同。
> crypto.cpp:10 — `#define CRYPTO_CURVE_NID NID_X9_62_prime256v1`

### 2.2 账户管理模块 (secp256k1 曲线)

| 接口 | 说明 | 调用方 |
|------|------|--------|
| `Account::Sign()` | 以太坊格式签名 (65字节) | 交易签名/消息签名 |
| `Account::Verify()` | 签名验证 | 交易验证 |
| `Account::generatePkey()` | 生成 secp256k1 密钥对 | 账户创建 |
| `GenerateAddr()` | 从公钥生成 EIP-55 地址 | 地址派生 |
| `isValidAddress()` | EIP-55 校验和验证 | 地址合法性检查 |
| `AccountManager::Initialize()` | 账户系统初始化 | 节点启动 |
| `AccountManager::ImportHexPrivateKey()` | 导入十六进制私钥 | CLI/RPC |
| `AccountManager::SavePrivateKeyToKeystoreFile()` | 保存加密密钥 | 账户创建 |
| `AccountManager::load_account_from_key_store()` | 从 keystore 加载账户 | 启动时加载 |
| `EthMessageHash()` | 计算以太坊消息哈希 | 签名前预处理 |
| `EthSignRaw()` | 原始 ECDSA 签名(含 recovery id) | 签名底层 |
| `HexPrivateKeyToPkey()` | 私钥hex转EVP_PKEY | 导入/创建 |

> **可信度: 高**。account_manager.cpp:431 — `EVP_PKEY_CTX_set_ec_paramgen_curve_nid(pctx, NID_secp256k1)`

### 2.3 Silkpre EVM预编译 (外部库)

| 接口 | 对应EVM预编译地址 | 说明 |
|------|-------------------|------|
| `silkpre_ecrec_run()` | 0x01 | ECDSA公钥恢复 |
| `silkpre_sha256_run()` | 0x02 | SHA256 |
| `silkpre_rip160_run()` | 0x03 | RIPEMD160 |
| `silkpre_id_run()` | 0x04 | 恒等映射 |
| `silkpre_expmod_run()` | 0x05 | 模幂运算 |
| `silkpre_bn_add_run()` | 0x06 | alt_bn128点加法 |
| `silkpre_bn_mul_run()` | 0x07 | alt_bn128标量乘法 |
| `silkpre_snarkv_run()` | 0x08 | alt_bn128配对检查 |
| `silkpre_blake2_f_run()` | 0x09 | BLAKE2b压缩 |

## 3. 模块边界定义

```
┌─────────────────────────────────────────────────────┐
│  交易/共识/RPC 层 (上层)                             │
├─────────────────────────────────────────────────────┤
│  AccountManager (账户管理层 - secp256k1)             │
│  ┌──────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │ Account  │  │GenerateAddr  │  │isValidAddress│  │
│  │Sign/Verfy│  │ EIP-55校验和│  │ 地址验证     │  │
│  └────┬─────┘  └──────┬───────┘  └──────┬───────┘  │
│       │               │                 │           │
├───────┼───────────────┼─────────────────┼───────────┤
│  crypto 模块 (底层 - P-256)              │           │
│  ECDSA/ECDH/HKDF/AES-GCM/HMAC          │           │
├───────┴───────────────────────────────┴───────────┤
│  辅助模块                                         │
│  sha256 / hex_code / keystore / base64 / ecvrf    │
│  envelop / keccak / contract_utils / silkpre       │
├────────────────────────────────────────────────────┤
│  外部依赖                                         │
│  OpenSSL 3.x / ethash / libff / GMP / intx        │
│  secp256k1 / nlohmann-json                        │
└────────────────────────────────────────────────────┘
```

**边界说明**：
- crypto 模块（P-256）与账户层（secp256k1）使用不同曲线，彼此物理隔离
- 账户层不调用 `crypto::ecdsa_sign`，而是直接使用 OpenSSL EVP API
- keystore 模块使用独立的 AES-128-CTR + scrypt，不依赖 crypto 模块的 AES-256-GCM
- ECVRF 使用 P-256（符合 RFC 9381），与 crypto 模块共享 P-256 但独立实现

## 4. 规范对照表 (spec_dev.md vs 当前实现)

> 注: spec_dev.md 中 2.4 节定义地址生成, 8.7 节定义 MPT

| 功能点 | 规范定义(spec_dev.md) | 当前实现 | 偏差原因 |
|--------|----------------------|----------|----------|
| 底层ECDSA曲线 | 未明确定义 | crypto.cpp使用P-256, account_manager使用secp256k1 | 历史遗留——crypto模块可能是早期通用加密层，账户系统后来改用ETH标准 |
| 地址生成算法 | EIP-55标准: keccak256(pubkey_xy), 取末40字符, 校验和 | `GenerateAddr()`: keccak256(raw_xy), substr(-40), ToChecksumAddress | **一致** |
| 地址格式 | 0x + 40 hex | 内部存储无0x前缀，显示时加0x | **一致** — Ethereum惯例 |
| 签名格式 | ETH格式(65字节: r32+s32+v1) | EthSignRaw返回65字节，含低s归一化 | **一致** |
| 消息哈希 | EIP-191: "\x19Ethereum Signed Message:\n" + len + msg | EthMessageHash中前缀被注释掉, 直接keccak256 | 设计选择——当前仅用于链上交易(无需EIP-191前缀)，注释注明"链下交易增加的前缀" |
| VRF实现 | 未在spec_dev中详述 | RFC 9381 ECVRF-P256-SHA256-TAI | 额外特性 |
| Keystore格式 | 未明确定义 | 类Ethereum keystore: scrypt+AES-128-CTR+Keccak256 MAC | 与主流钱包兼容 |
| 密钥派生 | 未明确定义 | Keystore使用scrypt (n=262144, r=8, p=1) | 高安全性参数 |
| 预编译合约 | EVM Istanbul标准 | silkpre: 9个预编译(EIP-2/152/196/197/198/2565) | **一致** |
| 哈希函数 | Keccak-256 (SHA-3变体) | keccak_cryopp.hpp → evmone::keccak256 → ethash | **一致** |
| 公钥格式 | 65字节未压缩(0x04+X+Y)或33字节压缩 | GenerateAddr同时支持33/65/DER三种格式 | 兼容性增强【需人工验证】 |

## 5. 问题清单

| 编号 | 位置 | 现象 | 风险等级 | 触发场景 | 修复建议 | 验证方法 |
|------|------|------|----------|----------|----------|----------|
| C-001 | crypto.cpp:10 | crypto模块使用P-256曲线，账户系统用secp256k1，二者不互通 | High | 若代码试图用crypto::ecdsa_verify验证account签名的数据 | 统一到secp256k1或标记crypto模块为deprecated | grep调用crypto::ecdsa_*的地方确认无交叉使用 |
| C-002 | crypto.cpp:14 | `#define OPENSSL_1_1_0 0` — 现代HKDF路径永远不编译 | Low | 无运行时影响 | 移除dead code或改为版本检测宏 | 检查OpenSSL版本，决定保留哪个路径 |
| C-003 | keystore.cpp:72 | GenerateUUID使用`std::mt19937`(非加密PRNG) | Low | UUID仅为文件标识，不直接影响安全 | 改为`RAND_bytes`或`std::random_device` | 审计UUID的实际用途 |
| C-004 | keystore.cpp:458 | GetPasswordFromUser递归调用自身 | Medium | 用户反复输入不匹配的密码导致栈溢出 | 改为while循环 | 压力测试——连续输入错误密码50+次 |
| C-005 | account_manager.cpp:726-741 | EthMessageHash中EIP-191前缀被注释掉 | Medium | 与以太坊生态工具签名互操作时可能不兼容 | 增加参数控制是否加前缀 | 用ethers.js/ethereumjs验证签名兼容性 |
| C-006 | crypto.cpp:165 | `calculate_ecdh_shared_key`中对同一ecdh设置了两次public key(ecdh1和ecdh2覆盖) | Medium | 按OpenSSL实现ecdh2的public key覆盖了ecdh1的，但后续compute_key使用了p_ecdh2_public作为参数 | 确认OpenSSL ECDH_compute_key的语义是否正确 | 单元测试: 已知ECDH测试向量 |
| C-007 | hex_code.cpp:57-59 | decode_hex中`!v1 && (c1 != '0')`的验证逻辑依赖数组初始化为0 | Low | 非ASCII字符可能绕过验证 | 改用标准hex验证（如isxdigit） | 模糊测试hex输入 |
| C-008 | account_manager.cpp:153 | Account::Sign中EthMessageHash接受任意长度输入，但实际EIP-191格式要求 | Low | 若前端误传未哈希的数据，签名仍成功但不可验证 | 增加输入长度校验 | 单元测试 |
