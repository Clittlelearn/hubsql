# 模块1: 密码学与账户体系 - 状态机流转图

## 1. 账户生命周期状态机

```mermaid
stateDiagram-v2
    [*] --> 未初始化: 节点首次启动

    state 未初始化 {
        [*] --> 扫描Keystore目录
        扫描Keystore目录 --> 无Keystore文件: .json文件数=0
        扫描Keystore目录 --> 有Keystore文件: .json文件数>0
    }

    无Keystore文件 --> 创建初始账户: Initialize()返回EMPTY_KEYSTORE
    有Keystore文件 --> 加载中: 需要密码解锁

    state 创建初始账户 {
        [*] --> 生成密钥对: Account(true)
        生成密钥对 --> 输入密码: GetPasswordFromUser
        输入密码 --> 验证密码: 非空检查
        验证密码 --> Keystore加密: scrypt+AES
        Keystore加密 --> 写入文件: 保存到磁盘
        写入文件 --> 添加到内存: AddAccount
    }

    state 加载中 {
        [*] --> 逐个解锁: totalAccounts≤10
        [*] --> 批量解锁: totalAccounts>10且用户选择

        state 逐个解锁 {
            [*] --> 输入密码
            输入密码 --> 密码验证: load_account_from_key_store
            密码验证 --> 成功: MAC正确
            密码验证 --> 重试: MAC错误 && 重试<3
            重试 --> 输入密码
            密码验证 --> 跳过: MAC错误 && 重试>=3
            成功 --> 加载到内存: AddAccount
            跳过 --> 加载到内存: 标记失败
        }

        加载到内存 --> 下一个账户: 还有未处理文件
        下一个账户 --> 逐个解锁
        加载到内存 --> 完成: 所有文件已处理
    }

    创建初始账户 --> 已创建: 账户在内存+磁盘
    加载中 --> 已创建: 账户在内存+磁盘
    加载中 --> 部分加载: successCount>0 && failedAccounts>0

    已创建 --> 已创建: 继续等待
    部分加载 --> 已创建: 继续使用已解锁账户

    已创建 --> 已锁定: 节点关闭/私钥已加密存储
    已锁定 --> 已创建: 节点重启+密码解锁

    已创建 --> 已删除: DeleteAccount()
    已删除 --> [*]

    note right of 已创建
        内存: _pkey(明文私钥)
        磁盘: keystore JSON(加密私钥)
        _defaultAddress已设置
    end note

    note right of 已锁定
        内存: 私钥已释放
        磁盘: keystore JSON(加密私钥)
        重启需密码解锁
    end note
```

## 2. 密钥状态流转图

```mermaid
stateDiagram-v2
    [*] --> 未生成

    未生成 --> 生成中: Account(true)\nor generatePkey()
    生成中 --> 明文内存: EVP_PKEY_keygen成功

    明文内存 --> DER编码: generatePublicString()
    DER编码 --> 公钥文本(_pubStr)

    明文内存 --> BIGNUM提取: generatePrivateString()
    BIGNUM提取 --> 私钥文本(_priStr)

    私钥文本 --> 加密存储: SavePrivateKeyToKeystoreFile()
    加密存储 --> 加密磁盘: keystore JSON写入文件

    加密磁盘 --> Keystore解密: load_account_from_key_store()
    Keystore解密 --> 明文内存: 密码正确
    Keystore解密 --> 加密磁盘: 密码错误(保留重试)

    明文内存 --> 已释放: Account析构/~EVP_PKEY_free
    已释放 --> [*]

    state 加密存储 {
        [*] --> 生成盐: GenerateRandomBytes(32)
        生成盐 --> scrypt派生: DeriveKeyFromPassword
        scrypt派生 --> AES加密: AesCtrEncrypt
        AES加密 --> MAC计算: keccak256(derivedKey[16:]+ciphertext)
        MAC计算 --> JSON序列化: ToJson()
    }

    note right of 明文内存
        生命周期与节点进程绑定
        风险: 内存dump可泄露私钥
        _priStr字段存有原始私钥字节
    end note

    note right of 加密磁盘
        scrypt参数: n=262144, r=8, p=1
        暴力破解计算成本高
        文件路径: path_constants::KEYSTORE_PATH/<address>.json
    end note
```

## 3. 地址验证状态机

```mermaid
stateDiagram-v2
    [*] --> 未验证

    未验证 --> 格式检查: isValidAddress(address)

    state 格式检查 {
        [*] --> VerifiedAddress缓存查询
        VerifiedAddress缓存查询 --> 已验证: isAddressVerified=true
        VerifiedAddress缓存查询 --> 长度检查: length!=40时失败

        长度检查 --> EIP55校验: length==40

        EIP55校验 --> 通过: 大小写匹配keccak256结果
        EIP55校验 --> 失败: 大小写不匹配

        通过 --> markAddressAsVerified
        markAddressAsVerified --> 已验证
    }

    已验证 --> [*]
    失败 --> [*]

    note right of 已验证
        缓存: VerifiedAddress.verifiedAddresses
        后续验证直接命中缓存
        重启后缓存丢失, 需重新验证
    end note
```

## 4. EVP_PKEY 对象状态 (OpenSSL 内部)

```mermaid
stateDiagram-v2
    [*] --> NULL: EVP_PKEY_new()

    NULL --> 仅有参数: EVP_PKEY_paramgen
    仅有参数 --> 有密钥对: EVP_PKEY_keygen

    NULL --> 仅有私钥: EC_KEY_set_private_key
    仅有私钥 --> 密钥对完成: 推导公钥 EC_POINT_mul

    NULL --> DER导入: d2i_PUBKEY
    DER导入 --> 仅有公钥: 成功解析

    有密钥对 --> 签名: ECDSA_do_sign
    仅有公钥 --> 验签: ECDSA_do_verify

    有密钥对 --> 已释放: EVP_PKEY_free
    仅有公钥 --> 已释放: EVP_PKEY_free
    仅有私钥 --> 已释放: EVP_PKEY_free

    密钥对完成 --> 有密钥对
    已释放 --> [*]

    note right of 有密钥对
        Account::_pkey 状态
        unique_ptr<EVP_PKEY> 管理生命周期
        拷贝时使用 EVP_PKEY_dup
    end note
```

## 5. 地址缓存状态

```mermaid
stateDiagram-v2
    [*] --> 缓存为空: 系统启动

    缓存为空 --> 首次计算: GenerateAddr(pubKey)
    首次计算 --> 缓存命中: addPublicKey(pubKey, addr)

    缓存命中 --> 直接返回: getAddress(pubKey)
    直接返回 --> 缓存命中: 后续调用

    缓存命中 --> 缓存为空: 系统重启(内存缓存丢失)

    note right of 缓存为空
        AddressCache: unordered_map<string, string>
        线程安全: std::mutex
        单例生命周期
    end note
```
