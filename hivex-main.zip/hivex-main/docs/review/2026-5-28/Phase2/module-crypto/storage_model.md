# 模块1: 密码学与账户体系 - 存储模型

## 1. 存储架构总览

```
~/.mm/
├── keystore/
│   ├── <address1>.json           # EIP-55 校验和地址命名的 keystore 文件
│   ├── <address2>.json
│   └── ...
└── (其他数据目录: blocks/, state/, etc.)
```

## 2. Keystore 文件格式

### 2.1 完整 JSON 结构

```json
{
    "version": 1,
    "id": "a1b2c3d4-e5f6-4789-abcd-ef0123456789",
    "address": "Ab12Cd34Ef56Ab78Cd90Ef12Ab34Cd56Ef78Ab90",
    "crypto": {
        "cipher": "aes-128-ctr",
        "ciphertext": "hex_encoded_ciphertext",
        "cipherparams": {
            "iv": "hex_encoded_16byte_iv"
        },
        "kdf": "scrypt",
        "kdfparams": {
            "dklen": 32,
            "n": 262144,
            "r": 8,
            "p": 1,
            "salt": "hex_encoded_32byte_salt"
        },
        "mac": "hex_encoded_keccak256_mac"
    }
}
```

### 2.2 字段说明

| 字段 | 类型 | 说明 | 生成位置 |
|------|------|------|----------|
| `version` | int | Keystore格式版本，固定为1 | keystore.cpp:235 |
| `id` | string | UUID v4格式标识符 | keystore.cpp:236 |
| `address` | string(40 hex) | EIP-55校验和地址(无0x前缀) | keystore.cpp:237 |
| `crypto.cipher` | string | 加密算法: `aes-128-ctr` | keystore.cpp:240 |
| `crypto.ciphertext` | string(hex) | AES-CTR加密后的私钥密文 | keystore.cpp:280 |
| `crypto.cipherparams.iv` | string(hex) | 16字节初始化向量 | keystore.cpp:270 |
| `crypto.kdf` | string | 密钥派生函数: `scrypt` | keystore.cpp:247 |
| `crypto.kdfparams.dklen` | int | 派生密钥长度: 32 | keystore.cpp:248 |
| `crypto.kdfparams.n` | int | scrypt成本参数: 262144 (2^18) | keystore.cpp:250 |
| `crypto.kdfparams.r` | int | scrypt块大小: 8 | keystore.cpp:251 |
| `crypto.kdfparams.p` | int | scrypt并行度: 1 | keystore.cpp:252 |
| `crypto.kdfparams.salt` | string(hex) | 32字节随机盐值 | keystore.cpp:244 |
| `crypto.mac` | string(hex) | Keccak-256消息认证码 | keystore.cpp:290 |

### 2.3 加密算法参数

```
┌─────────────────────────────────────────────────────────┐
│                    Keystore 密钥派生                      │
│                                                           │
│  Password (用户输入)                                       │
│      │                                                    │
│      ▼                                                    │
│  scrypt(password, salt, N=262144, r=8, p=1, dklen=32)    │
│      │                                                    │
│      ▼                                                    │
│  derivedKey (32 bytes)                                    │
│      │                                                    │
│      ├──── derivedKey[0:16]  → AES-128-CTR 加密密钥       │
│      │                          encrypt(privKey, key, iv)  │
│      │                          → ciphertext               │
│      │                                                    │
│      └──── derivedKey[16:32] + ciphertext                 │
│              │                                             │
│              ▼                                             │
│           keccak256 → mac                                 │
└─────────────────────────────────────────────────────────┘
```

### 2.4 与 Ethereum Keystore 格式的对比

| 特性 | MeMeChain Keystore | Ethereum Keystore (v3) | 一致性 |
|------|-------------------|----------------------|--------|
| 加密算法 | AES-128-CTR | AES-128-CTR | **一致** |
| KDF | scrypt | scrypt(推荐) 或 pbkdf2 | **一致** |
| scrypt参数 | n=262144, r=8, p=1 | n=262144, r=8, p=1 (高安全) | **一致** |
| MAC算法 | keccak256(derivedKey[16:]+ciphertext) | keccak256(derivedKey[16:]+ciphertext) | **一致** |
| 版本号 | 1 | 3 | **不一致** — Ethereum用v3，MeMeChain用v1 |
| IV长度 | 16 | 16 | **一致** |
| UUID | mt19937生成 | 加密PRNG | **不一致** — UUID生成器质量不同 |
| 地址格式 | EIP-55 (无0x前缀) | EIP-55 (v3中为mixed-case) | **基本一致** |

## 3. 地址缓存存储模型

### 3.1 AddressCache

```
┌─────────────────────────────────────┐
│     AddressCache (内存, 非持久化)    │
│                                     │
│  unordered_map<string, string>:     │
│  ┌───────────────────────────────┐  │
│  │ DER编码公钥 → EIP-55地址      │  │
│  │ "0A1B2C.." → "Ab12Cd34.."   │  │
│  │ "FFEE.."   → "Ff01Ee23.."   │  │
│  │ ...                           │  │
│  └───────────────────────────────┘  │
│                                     │
│  锁: std::mutex (方法级)            │
│  生命周期: 进程生命周期              │
│  容量: 无上限 (潜在内存泄漏风险)     │
└─────────────────────────────────────┘
```

**存储位置**: `utils/address_cache.h:25-55`
**持久化**: **否** — 纯内存缓存，重启后重建
**写入时机**: `GenerateAddr()` 每次生成新地址后写入
**读取时机**: `GenerateAddr()` 首次查找缓存

### 3.2 VerifiedAddress

```
┌─────────────────────────────────────────┐
│  VerifiedAddress (内存, 非持久化)        │
│                                         │
│  unordered_set<string>:                 │
│  ┌─────────────────────────────────┐    │
│  │ 已验证地址集合                   │    │
│  │ "ab12cd34ef56ab78cd90ef12..."   │    │
│  │ ...                             │    │
│  └─────────────────────────────────┘    │
│                                         │
│  锁: std::mutex (方法级)                │
│  生命周期: 进程生命周期                  │
└─────────────────────────────────────────┘
```

**存储位置**: `utils/verified_address.h:24-50`
**持久化**: **否** — 纯内存缓存

## 4. 文件路径管理

**key**: `path_constants::KEYSTORE_PATH` （定义在 `utils/file_manager.h` 等位置）

文件命名规则：
- 文件名: `{EIP-55地址}.json`
- 地址大小写敏感（EIP-55 校验和混合大小写）
- 加载时从文件名提取地址: `filename.substr(0, filename.find(".json"))`

相关代码:
- `GetKeystoreFilePath(address)`: 拼接完整路径
- `_scanKeystoreDirectory()`: 扫描 `path_constants::KEYSTORE_PATH` 下所有 `.json` 文件
- `account_manager.cpp:822-860` — 扫描实现

## 5. 私钥文件 (旧格式/兼容)

除了 keystore JSON 格式，还存在一种旧的私钥存储格式:

```cpp
// account_manager.cpp:1753-1790 (ReadPrivateKey)
// 格式: 单个文件，第一行为十六进制私钥 (64 hex字符)
// 路径: path_constants::KEYSTORE_PATH + address
```

**用途**: `Account::generateFilePkey()` 在加载 keystore 不成功时回退到旧格式
**状态**: 废弃逻辑/兼容逻辑 (见代码注释中标注"Error: privateBioFile err"的错误分支)

## 6. 存储安全问题

| 问题 | 风险 | 位置 | 建议 |
|------|------|------|------|
| keystore JSON明文存储 | 文件权限不当导致泄露 | keystore.cpp:219 | 创建文件时设 0600 权限 |
| 私钥16进制明文存储(旧格式) | 无加密保护 | account_manager.cpp:1792-1820 | 移除旧格式，强制 keystore |
| 内存中 _priStr 明文 | 内存dump可泄露 | account_manager.cpp:387 | mlock防止交换 |
| UUID用mt19937生成 | UUID可预测 | keystore.cpp:72 | 不影响安全(UUID不是密钥) |
| 地址缓存无上限 | 内存耗尽 | address_cache.h:26 | 添加 LRU 淘汰策略 |

## 7. 数据流示意图

```mermaid
flowchart TD
    subgraph "磁盘存储"
        KS[keystore/*.json<br/>加密私钥]
        OLD[*.key 旧格式<br/>明文hex私钥]
    end

    subgraph "内存存储"
        AL[_accountList<br/>map<addr, Account>]
        AC[AddressCache<br/>pubKey→addr]
        VA[VerifiedAddress<br/>addr set]
    end

    subgraph "加载路径"
        Scan[扫描keystore目录] --> KS
        KS -->|密码解密| PKEY[EVP_PKEY对象]
        PKEY --> AL
    end

    subgraph "创建路径"
        New[生成新密钥对] --> PKEY2[EVP_PKEY对象]
        PKEY2 -->|密码加密| KS
        PKEY2 --> AL
        PKEY2 -->|生成地址| AC
    end

    subgraph "查询路径"
        AL -->|GetDefaultAccount| Sign[签名操作]
        AC -->|getAddress| Addr[地址查询]
        VA -->|isVerified| Valid[地址验证]
    end
```
