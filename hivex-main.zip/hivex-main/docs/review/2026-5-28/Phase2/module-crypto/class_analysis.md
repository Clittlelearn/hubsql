# 模块1: 密码学与账户体系 - 核心类与数据结构分析

## 1. crypto 命名空间 (utils/crypto.h/cpp)

### 1.1 常量定义

| 常量 | 值 | 说明 | 位置 |
|------|-----|------|------|
| `CRYPTO_CURVE_NID` | `NID_X9_62_prime256v1` | **P-256曲线** (与账户层secp256k1不同) | crypto.h:10 |
| `EC_PUBLIC_KEY_LENGTH` | 65 | 未压缩公钥长度 | crypto.h:13 |
| `EC_PRIVATE_KEY_LENGTH` | 32 | 私钥长度 | crypto.h:14 |
| `CRYPTO_ECDSA_SIG_LEN` | 64 | ECDSA签名(r32+s32) | crypto.h:24 |
| `CRYPTO_AES_KEY_LEN` | 32 | AES-256密钥长度 | crypto.h:18 |
| `AES_TAG_LENGTH` | 16 | GCM认证标签长度 | crypto.h:20 |
| `OPENSSL_1_1_0` | 0 | **硬编码为0**——现代HKDF路径永不编译 | crypto.cpp:14 |

### 1.2 函数分组

**密钥生成**: `generate_ecdh_keys()` (crypto.cpp:27-77)
- 生命周期: 每次调用创建/销毁 EC_KEY
- 使用 P-256 曲线
- 错误处理: goto err 模式

**密钥协商**: `calculate_ecdh_shared_key()` (crypto.cpp:79-187)
- 三参数: ecdh1的私钥+公钥 + ecdh2的公钥
- 内部设置两次public key到同一个EC_KEY对象（**可能有问题，见C-006**）
- 返回: `(ret==0)` — 真假值翻转，ret初始为false(int 0)，成功时ret=0，return (0==0)=true

**签名/验签**:
- `ecdsa_sign()`: 使用`ECDSA_do_sign` (crypto.cpp:189-241)
- `ecdsa_verify()`: 使用`ECDSA_do_verify` (crypto.cpp:243-317)
- 签名格式: r(32bytes) || s(32bytes) = 64 bytes，**不含v(recovery id)**

**HKDF**: `createHkdfBytes()` (crypto.cpp:352-443)
- 编译时分叉: `#if OPENSSL_1_1_0` 分支永不执行
- 实际使用的`#else`分支: 手动HMAC-extract + HMAC-expand
- **RETURN BUG**: `return (ret==0)` — 在现代路径中ret初始化为-1, 成功时赋out_len值(非0), `return (ret==0)` 实际返回false。只有手动实现(#else)返回true。**可信度: 高**

**AES-GCM**: `aes_encrypt()`/`aes_decrypt()` (crypto.cpp:446-544)
- 使用 EVP_aes_256_gcm
- 加密返回: `(ciphertext_len==plaintext_len)` — 验证所有数据被加密
- 解密返回: 先验证plaintext_len==ciphertext_len，再验证tag

## 2. Account 类 (utils/account_manager.h:65-263)

### 2.1 类定义

```cpp
class Account {
private:
    std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)> _pkey;  // secp256k1密钥对
    std::string _pubStr;   // DER编码公钥
    std::string _priStr;   // 32字节原始私钥
    std::string _Addr;     // EIP-55校验地址(40 hex, 无0x)
};
```

### 2.2 构造函数

| 构造形式 | 用途 | 位置 |
|----------|------|------|
| `Account(true)` | 生成全新随机密钥对 | account_manager.h:68 |
| `Account()` | 空构造(默认) | account_manager.h:71 |
| `Account(addressFileName)` | 从keystore文件加载 | account_manager.h:78 |
| `Account(const Account&)` | 深拷贝(使用EVP_PKEY_dup) | account_manager.cpp:75 |
| `Account(Account&&)` | 移动构造 | account_manager.cpp:87 |

### 2.3 关键方法

**generatePkey()** (account_manager.cpp:405-465)
- 使用 EVP_PKEY 参数生成 API (OpenSSL 3.x 风格)
- 曲线: `NID_secp256k1`
- 流程: paramgen → keygen → 提取公钥(i2d_PUBKEY) → 提取私钥(EVP_PKEY_get_bn_param) → 生成地址

**Sign(message, signature)** (account_manager.cpp:150-163)
- 输入: 任意字符串 message
- 输出: 65字节 ETH 签名 (r32 + s32 + v1)
- 签名前: `EthMessageHash(message)` → `EthSignRaw(hash32, pkey, sig)`
- v值范围: 27 或 28

**Verify(message, signature)** (account_manager.cpp:290-344)
- 双模式: 65字节ETH格式验证 / DER格式验证

**generateFilePkey(address)** (account_manager.cpp:467-502)
- 从 keystore 文件读取十六进制私钥
- 调用 `ReadPrivateKey` → `HexPrivateKeyToPkey` → `GenerateAddr`
- **bug/feature**: 若 derived 为空则用文件名的地址 (line 497-501)

**EthSignRaw()** (account_manager.cpp:165-288)
- 完整ECDSA签名流程:
  1. ECDSA_do_sign
  2. 低s值归一化 (BIP-62兼容): 若 s > n/2, s = n - s
  3. Recovery id 计算: 暴力尝试 ybit∈{0,1}, 通过 EC_POINT_mul 恢复公钥匹配
  4. 输出: r32||s32||v(27+recid)

## 3. AccountManager 类 (utils/account_manager.h:269-439)

### 3.1 数据结构

```cpp
class AccountManager {
private:
    std::string _defaultAddress;                                        // 默认账户地址
    std::map<std::string, std::shared_ptr<Account>> _accountList;      // 地址→账户映射
    // 注意: 非线程安全——_accountList无锁保护
};
```

### 3.2 生命周期

- 单例模式: `MagicSingleton<AccountManager>::GetInstance()`
- 初始化: `Initialize()` → `_scanKeystoreDirectory()` → `loadExistingAccounts()`
- 关闭: 隐式析构

### 3.3 关键方法

**Initialize()** (account_manager.cpp:744-819)
- 扫描 keystore 目录 → 加载账户 → 设置默认地址 → 一致性检查
- 返回值: `accountInitResult` (包含状态码+消息)

**loadExistingAccounts()** (account_manager.cpp:863-1258)
- **复杂度极高** (~400行): 混入了UI交互逻辑(密码输入/进度条/批量解锁/重试)
- 多种交互模式: Dev模式通用密码 / 批量多线程 / 逐个输入
- **问题**: 密码输入逻辑与业务逻辑耦合

**ImportHexPrivateKey()** (account_manager.cpp:685-724)
- hex私钥 → EVP_PKEY → 地址 → 加入_accountList
- **问题**: 未自动保存 keystore (调用者需手动调用 SavePrivateKeyToKeystoreFile)

### 3.4 全局函数

| 函数 | 用途 | 位置 |
|------|------|------|
| `GenerateAddr(pubKey)` | EIP-55地址生成, 带缓存 | account_manager.cpp:1492-1552 |
| `isValidAddress(address)` | EIP-55校验验证, 带缓存 | account_manager.cpp:1454-1490 |
| `EthMessageHash(msg)` | keccak256哈希 | account_manager.cpp:726-741 |
| `EthSignRaw(hash, pkey, sig)` | 原始ECDSA签名 | account_manager.cpp:165-288 |
| `HexPrivateKeyToPkey(hex)` | 私钥hex→EVP_PKEY | account_manager.cpp:1627-1751 |
| `Sha256Digest32(in, len, out)` | SHA256 32字节摘要 | account_manager.cpp:1616-1625 |

## 4. KeystoreManager 类 (utils/keystore.h:51-83)

### 4.1 Keystore 文件结构

```json
{
    "version": 1,
    "id": "<UUID>",
    "address": "<EIP-55 address>",
    "crypto": {
        "cipher": "aes-128-ctr",
        "ciphertext": "<hex>",
        "cipherparams": {"iv": "<hex>"},
        "kdf": "scrypt",
        "kdfparams": {
            "dklen": 32,
            "n": 262144,
            "r": 8,
            "p": 1,
            "salt": "<hex>"
        },
        "mac": "<keccak256 hex>"
    }
}
```

### 4.2 加密流程 (EncryptPrivateKey)

```
password → scrypt(salt, n=262144, r=8, p=1, dklen=32) → derivedKey(32B)
              ├── encryptKey = derivedKey[0:16] → AES-128-CTR(iv[0:16]) → ciphertext
              └── macKey = derivedKey[16:32] + ciphertext → keccak256 → mac
```

### 4.3 KeystoreFile 结构体 (keystore.h:18-49)

- POD结构体: 纯数据，无行为
- `ToJson()`/`FromJson()`: JSON序列化

## 5. 辅助类/结构体

### 5.1 AddressCache (utils/address_cache.h:25-55)

```cpp
namespace mm::addr {
class AddressCache {
    std::unordered_map<std::string, std::string> cache;  // pubKey→address
    mutable std::mutex mutex;                              // 线程安全
};
}
```
- 生命周期: 单例 (MagicSingleton)，全局存活
- 用途: 避免重复计算地址（EIP-55 校验和计算含 keccak256）
- 线程安全: 所有方法加锁

### 5.2 VerifiedAddress (utils/verified_address.h:24-50)

```cpp
namespace mm::addr {
class VerifiedAddress {
    std::unordered_set<std::string> verifiedAddresses;  // 已验证地址
    std::mutex mutex;
};
}
```
- 生命周期: 单例
- 用途: 缓存 EIP-55 校验和验证结果，避免重复验证

### 5.3 EcvrfP256Sha256Tai (utils/ecvrf_p256_sha256_tai.h:7-31)

- 全静态方法类
- P-256曲线, SHA-256, Try-and-Increment hash-to-curve
- RFC 9381 兼容
- 包含自测试(Example 10 测试向量)

### 5.4 accountInitResult (utils/account_manager.h:36-58)

```cpp
struct accountInitResult {
    enum class Status {
        SUCCESS, EMPTY_KEYSTORE, kAccountsNotInitialized,
        CREATE_ACCOUNT_FAILED, USER_REQUESTED_EXIT, FATAL_ERROR
    };
    Status status;
    std::string message;
    int errorCode;
};
```
- 值类型，非单例
- 用于 AccountManager::Initialize() 返回值

### 5.5 Envelop 类 (utils/envelop.h:16-95)

- 数字信封: RSA-2048 + AES-128-CBC + SHA256签名
- 拥有内部 RSA 密钥对（构造时生成）
- 非单例
- 封装: 签名数据 → AES加密 → RSA加密AES密钥
- 解封: RSA解密AES密钥 → AES解密 → 验签

## 6. Silkpre 预编译系统 (silkpre/)

### 6.1 核心结构

```cpp
typedef struct SilkpreContract {
    SilkpreGasFunction gas;  // gas计费函数
    SilkpreRunFunction run;  // 执行函数
} SilkpreContract;

extern const SilkpreContract kSilkpreContracts[9];  // Istanbul预编译
```

### 6.2 预编译合约列表

| 索引 | 合约 | EIP | 输入 | 输出 |
|------|------|-----|------|------|
| 0 | ecrecover | EIP-2 | 128B(hash+v+r+s) | 32B(在末20B) |
| 1 | SHA256 | - | 任意 | 32B |
| 2 | RIPEMD160 | - | 任意 | 32B(在末20B) |
| 3 | identity | - | 任意 | 输入拷贝 |
| 4 | modexp | EIP-198/2565 | bLen+eLen+mLen+base+exp+mod | mLen |
| 5 | bn_add | EIP-196 | 2x64B(G1点) | 64B |
| 6 | bn_mul | EIP-196 | 64B(G1)+32B(标量) | 64B |
| 7 | snarkv | EIP-197 | Nx192B | 32B |
| 8 | blake2b_f | EIP-152 | 213B(rounds+h+m+t+f) | 64B |
