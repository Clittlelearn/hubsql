# 模块1: 密码学与账户体系 - 线程模型与并发分析

## 1. 线程架构总览

```mermaid
graph TD
    Main[主线程] --> Init[AccountManager::Initialize]
    Init --> Scan[扫描keystore目录]
    Scan --> Load[loadExistingAccounts]

    Load -->|单线程| SingleThread[逐个账户密码输入+加载]
    Load -->|多线程| BatchMode[UnlockAccountsBatchMode]

    subgraph "批量解锁 - TaskPool"
        BatchMode --> PasswordLoop[主线程: 收集所有密码]
        PasswordLoop --> Submit[提交任务到 TaskPool]
        Submit --> Worker1[Worker1: processPasswordBatch]
        Submit --> Worker2[Worker2: processPasswordBatch]
        Submit --> WorkerN[WorkerN: processPasswordBatch]
        Worker1 --> MutexLock1[加锁: resultMutex]
        Worker2 --> MutexLock2[加锁: resultMutex]
    end

    subgraph "全局单例 - 无锁访问(高风险)"
        style Risk fill:#f66
        AccMgr[MagicSingleton-AccountManager]
        AccMgr --> AddAcc[AddAccount: 无锁 _accountList]
        AccMgr --> FindAcc[FindAccount: 无锁读取]
    end

    subgraph "地址缓存 - 有锁"
        AddrCache[AddressCache::addPublicKey]
        AddrCache --> CacheLock1[std::mutex lock]
        VerAddr[VerifiedAddress::markAddressAsVerified]
        VerAddr --> VerLock1[std::mutex lock]
    end
```

## 2. 锁机制与线程安全分析

### 2.1 线程安全的组件

| 组件 | 保护方式 | 锁粒度 | 可信度 | 位置 |
|------|----------|--------|--------|------|
| AddressCache | `std::mutex` + `lock_guard` | 全方法加锁 | 高 | `utils/address_cache.h:29,39,50` |
| VerifiedAddress | `std::mutex` + `lock_guard` | 全方法加锁 | 高 | `utils/verified_address.h:28,37,48` |
| Silkpre (libff) | `[[maybe_unused]] static bool` 初始化 | 内部使用 magic static (C++11 线程安全) | 高 | `silkpre/lib/silkpre/precompile.cpp:259` |
| Silkpre (secp256k1 context) | 函数内 `static` 变量 | magic static | 中 | `silkpre/lib/silkpre/precompile.cpp:70` |

### 2.2 线程不安全的组件 (风险点)

| 组件 | 共享资源 | 锁保护 | 风险等级 | 位置 |
|------|----------|--------|----------|------|
| **AccountManager::_accountList** | `std::map<addr, shared_ptr<Account>>` | **无锁** | **Critical** | `utils/account_manager.h:434` |
| **AccountManager::_defaultAddress** | `std::string` | **无锁** | **High** | `utils/account_manager.h:433` |
| `KeystoreManager::GenerateUUID` 静态变量 | `static mt19937 gen` | **无锁** | Medium | `utils/keystore.cpp:72-73` |
| `GenerateAddr → AddressCache` | 写入+读取 | 有锁(安全) | Low | `utils/address_cache.h` |
| `isValidAddress → VerifiedAddress` | 写入+读取 | 有锁(安全) | Low | `utils/verified_address.h` |

### 2.3 详细分析

#### AccountManager::_accountList (Critical)

```cpp
// account_manager.h:434
std::map<std::string /*addr*/, std::shared_ptr<Account>> _accountList;
```

**问题**: `_accountList` 没有任何锁保护，但在以下场景可能被并发访问:

1. **AddAccount()** (account_manager.cpp:504-514): 先 `find()` 再 `emplace()` — 典型的 check-then-act 竞态条件
2. **FindAccount()** (account_manager.cpp:625-636): 先 `find()` 再拷贝 — 迭代器可能被并发修改失效
3. **DeleteAccount()** (account_manager.cpp:534-579): 先 `find()` 再 `erase()` — 与 FindAccount 并发时可能 segfault
4. **GetDefaultAccount()** (account_manager.cpp:638-649): 读取 `_defaultAddress` + 读取 `_accountList` — 两个无原子性保证的操作
5. **loadExistingAccounts → UnlockAccountsBatchMode**: 多线程并发调用 `load_account_from_key_store → AddAccount` — 直接的并发写入

**触发场景**: 
- 批量解锁账户时，Worker1/Worker2同时调用 `AddAccount`
- RPC 调用 `ImportHexPrivateKey` 与 `FindAccount` 并发

**修复优先级**: Critical — 需要在 `_accountList` 所有访问路径加读写锁

#### GenerateUUID (Medium)

```cpp
// keystore.cpp:72-74
static std::random_device rd;
static std::mt19937 gen(rd());       // NOT thread-safe
static std::uniform_int_distribution<> dis(0, 15);
```

**问题**: `std::mt19937` 的 `operator()` 不是线程安全的。多线程同时调用 `EncryptPrivateKey → GenerateUUID` 时可能导致数据竞争。
**影响**: UUID 生成乱码或崩溃
**实际触发可能性**: 低 — 通常只有单线程调用 keystore 创建

## 3. 多线程访问场景

### 3.1 启动批量加载场景

```cpp
// account_manager.cpp:966-978
int startIdx = 0;
std::vector<std::future<void>> futures;
for (int i = 0; i < numThreads; i++) {
    int count = filesPerThread + (i < remainingFiles ? 1 : 0);
    auto task = std::make_shared<std::packaged_task<void()>>([startIdx, count, &processFiles]() {
        processFiles(startIdx, count);
    });
    futures.emplace_back(task->get_future());
    MagicSingleton<TaskPool>::GetInstance()->commitWorkTask([task](){(*task)();});
    startIdx += count;
}
for (auto &f : futures) { f.get(); }
```

**并发访问路径**:
1. 每个 Worker 线程中: `load_account_from_key_store` → `AddAccount` (无锁写 `_accountList`)
2. 每个 Worker 线程中: `GenerateAddr` → `AddressCache::addPublicKey` (有锁，安全)
3. 每个 Worker 线程中: `HexPrivateKeyToPkey` → OpenSSL (OpenSSL内部有锁？不确定)
4. 共享 `resultMutex` 保护 `successfulAddressList` 和 `failedAddresses` (有锁，安全)

### 3.2 Security Review: OpenSSL 线程安全

**OpenSSL 3.x**: 内置线程安全支持（需要初始化 locks）。需确认项目是否调用了 `OPENSSL_init_crypto()` 的线程相关参数。
**【需人工验证】** — 检查 `OPENSSL_init_crypto` 调用。

## 4. 并发安全性总结

```mermaid
graph LR
    subgraph "安全"
        A[AddressCache] -->|mutex| OK1[OK]
        B[VerifiedAddress] -->|mutex| OK2[OK]
        C[Silkpre init] -->|magic static| OK3[OK]
        D[resultMutex] -->|mutex| OK4[OK]
    end

    subgraph "不安全"
        E[_accountList] -->|NO LOCK| CRIT1[CRITICAL]
        F[_defaultAddress] -->|NO LOCK| HIGH1[HIGH]
        G[GenerateUUID mt19937] -->|NO LOCK| MED1[MEDIUM]
    end
```

## 5. 建议修复

| 优先级 | 组件 | 建议 |
|--------|------|------|
| P0 | `_accountList` | 添加 `std::shared_mutex`，写操作用 `unique_lock`，读操作用 `shared_lock` |
| P1 | `_defaultAddress` | 改为 `std::atomic` + 字符串拷贝，或纳入 `_accountList` 的锁范围 |
| P2 | `GenerateUUID` mt19937 | 改为 `thread_local` 或使用 `RAND_bytes` 替代 |
| P3 | `Account::_priStr` 明文存储 | 考虑使用 `mlock`/`VirtualLock` 防止交换到磁盘 |
