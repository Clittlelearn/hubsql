# 模块7: 交易池与特殊交易类型 - 状态流转分析

**可信度**: 高 (基于源码状态推导)
**分析日期**: 2026-05-26

---

## 1. 交易全局状态流转

```mermaid
stateDiagram-v2
    [*] --> Created: 本地构造交易
    Created --> Signed: 签名 (signUtxo)
    Signed --> Broadcasting: goMessage() 发送
    Broadcasting --> InMempool: AddCache() 入池
    InMempool --> Packaged: BuildBlock() 打包
    Packaged --> Confirmed: 区块确认 (handleBlock成功)
    Packaged --> Failed: 区块构建失败
    Failed --> InMempool: (恢复性错误) 等待下次
    Failed --> Discarded: (非恢复错误) 清除
    Broadcasting --> FailedCache: handleTransaction失败(高度不足)
    FailedCache --> Retrying: 定时检查(2s) 网络满足条件
    Retrying --> InMempool: 重试成功
    Retrying --> Expired: top > txHeight+3 过期
    Confirmed --> [*]: 持久化到 RocksDB
    Discarded --> [*]
    Expired --> [*]
```

**源码依据**:

| 状态转换 | 触发条件 | 位置 |
|----------|---------|------|
| Created -> Signed | `goMessage()` 前完成签名 | 各 trans.cpp `trans()` 末尾 |
| Signed -> Broadcasting | `goMessage()` 构造 TxMsgReq 并发送 | 各 trans.cpp `goMessage()` |
| Broadcasting -> InMempool | `TransactionCache::AddCache()` 成功 (ret=0) | transaction_cache.cpp:279 |
| InMempool -> Packaged | `processTransactionCacheFunc()` 调用 `BuildBlock()` | transaction_cache.cpp:431 |
| Packaged -> Confirmed | `handleBlock()` 返回 0 | transaction_cache.cpp:211 vs 213 |
| Packaged -> Failed | `BuildBlock()` 返回非0 | transaction_cache.cpp:432-444 |
| Failed -> InMempool | ret==-103/-104/-105 (恢复性错误) | transaction_cache.cpp:435-439 |
| Failed -> Discarded | 其他非0返回值 | transaction_cache.cpp:441-443 |
| Broadcasting -> FailedCache | `handleTransaction()` 失败 | failed_transaction_cache.cpp:123 |
| FailedCache -> Retrying | 75% 节点达到交易高度 | failed_transaction_cache.cpp:60-63 |
| Retrying -> Expired | `top > txHeight + 3` | failed_transaction_cache.cpp:71-74 |

---

## 2. 质押状态流转

```mermaid
stateDiagram-v2
    [*] --> Unstaked: 初始状态
    Unstaked --> Staked: 质押交易确认 (STAKE)
    Staked --> Staked: 质押中 (持续)
    Staked --> Unstakable: 满足 MIN_UNSTAKE_HEIGHT(500块)
    Unstakable --> Unstaking: 发起解押交易 (UNSTAKE)
    Unstaking --> Unstaked: 解押交易确认
    
    note right of Staked
        可获得 delegating 委托
        可获得 bonus 奖励
        可参与 Fund 分配
    end note
    
    note right of Unstakable
        条件: 质押高度+500 <= 当前高度
        IsQualifiedToUnstake() 返回 true
    end note
```

**源码依据**:

| 状态 | 检查条件 | 文件:行号 |
|------|---------|----------|
| Unstaked -> Staked | `!isStaked(addr)` + `amount >= MIN_STAKE_AMOUNT` + `commission_rate in [5%,35%]` | stake.cpp:163-177 |
| 已质押检查 | `isStaked(addr)` 返回 true 则拒绝新质押 | stake.cpp:163-168 |
| Staked -> Unstakable | `MIN_UNSTAKE_HEIGHT = 500` -- 需 500 个区块后方可解押 | global.h:51 |
| 解押资格 | `IsQualifiedToUnstake(addr, utxo_hash, stakeAmount, asset_type)` | unstake.cpp:39-48 |

**关键常量**:
- `MIN_STAKE_AMOUNT = 3500 * 10^8 = 350,000,000,000` (global.h:39)
- `MIN_UNSTAKE_HEIGHT = 500` (global.h:51)
- `MAX_COMMISSION_RATE = 0.35` (global.h:62)
- `MIN_COMMISSION_RATE = 0.05` (global.h:63)

---

## 3. 委托状态流转

```mermaid
stateDiagram-v2
    [*] --> UnDelegated: 初始状态
    UnDelegated --> Delegated: 委托交易确认 (DELEGATE)
    Delegated --> Delegated: 委托中 (持续)
    Delegated --> UnDelegating: 发起取消委托 (UNDELEGATE)
    UnDelegating --> UnDelegated: 取消委托确认
    
    note right of Delegated
        amount >= kMinDelegatingAmt (500MM)
        目标地址必须是已质押节点
        委托金额存入 VirtualDelegating
    end note
```

**源码依据**:

| 状态 | 检查条件 | 文件:行号 |
|------|---------|----------|
| UnDelegated -> Delegated | `delegatinged_amount >= kMinDelegatingAmt` + `CheckDelegatingQualification(from, to, asset_type, amount)` | delegating.cpp:60-72 |
| 最小委托量 | `kMinDelegatingAmt = 500 * 10^8 = 50,000,000,000` | global.h:41 |
| 资格检查 | `CheckDelegatingQualification` 验证目标节点是否已质押 | delegating.cpp:65 |
| Delegated -> UnDelegating | `IsQualifiedToUndelegating(from, asset_type, to, utxo_hash, amount)` | undelegating.cpp:62-65 |

---

## 4. 锁定/解锁状态流转 (投票权)

```mermaid
stateDiagram-v2
    [*] --> Unlocked: 初始状态
    Unlocked --> Locked: 锁定交易确认 (LOCK)
    Locked --> Locked: 锁定中 (拥有投票权)
    Locked --> Unlocking: 发起解锁 (UNLOCK)
    Unlocking --> Unlocked: 解锁交易确认
    
    note right of Locked
        lock_amount >= LOCK_AMOUNT * kDecimalNum
        资产类型固定为 "Vote"
        锁定到 VIRTUAL_LOCK_ADDRESS
        获得投票权: GetLockValue(addr) > 0
    end note
```

**源码依据**:

| 状态 | 检查条件 | 文件:行号 |
|------|---------|----------|
| Unlocked -> Locked | `lock_amount >= LOCK_AMOUNT * kDecimalNum` + 无已有锁定交易 (`getLockAddrUtxo` 返回 NOT_FOUND) | lock.cpp:37-61 |
| 锁定类型 | 仅支持 `LockType::kLock_Node` (对应 `kLockTypeNet = "LockNet"`) | lock.cpp:44-47 |
| 锁定地址 | `VIRTUAL_LOCK_ADDRESS = "LockVirtualStake"` | global.h:58 |
| Locked -> Unlocking | `IsQualifiedToUnLock(addr, utxo_hash, lock_amount, "Vote")` | unlock.cpp:40-45 |
| 投票权重 | `ca_algorithm::GetLockValue(addr, lockValue)` | vote.cpp:51 |

**关键常量**:
- `LOCK_AMOUNT = 1` (标准精度, global.h:37)
- 实际最小锁定量 = `1 * kDecimalNum = 100,000,000` (最小精度)
- 资产类型: `ASSET_TYPE_VOTE = "Vote"` (global.h:67)

---

## 5. 交易在 TransactionCache 中的状态

```mermaid
stateDiagram-v2
    [*] --> Cached: AddCache() 成功
    Cached --> Pending: 等待打包 (在 _transactionCache 中)
    Pending --> Building: processTransactionCacheFunc() 触发
    Building --> Built: BuildBlock() 返回 0
    Built --> Cleared: _transactionCache.clear()
    Building --> Retry: BuildBlock() 返回 -103/-104/-105
    Retry --> Building: 下次循环 (不清除缓存)
    Building --> Cleared: BuildBlock() 返回其他非0值 (清除)
    
    note right of Building
        get_build_block_height() 确认打包高度
        需 75% 质押节点达到交易高度
    end note
```

**源码依据**:

| 行为 | 条件 | 位置 |
|------|------|------|
| Cached -> Pending | `AddCache()` 返回 0 | transaction_cache.cpp:279 |
| Pending -> Building | `_blockBuilder.wait()` 被 `notify_one()` 唤醒 | transaction_cache.cpp:405 |
| 打包触发 | 每 3 秒 (BUILD_INTERVAL) 或 _transactionCache.size() >= 1000000 | transaction_cache.cpp:78,80,274-277 |
| 高度选择 | `get_build_block_height()` 分析全网节点高度分布 | transaction_cache.cpp:293 |
| Built -> Cleared | 打包成功 | transaction_cache.cpp:447 |
| Building -> Retry | `ret == -103 || ret == -104 || ret == -105` | transaction_cache.cpp:435-439 |

---

## 6. 合约交易状态流转

```mermaid
stateDiagram-v2
    [*] --> Cached: AddCache() to _contractCache
    Cached --> Processing: ProcessContract() 调用
    Processing --> PreHashSeek: fetchContractTxPreHash()
    PreHashSeek --> PreHashVerified: 66%节点确认preHash
    PreHashSeek --> PreHashFailed: preHash不匹配/超时
    PreHashVerified --> Building: BuildBlock()
    Building --> Confirmed: handleBlock() 成功
    Building --> Failed: handleBlock() 失败
    
    note right of Processing
        需通过 handleContractPackagerMessage
        验证 VRF 选择证明
        按 blockTimestamp 分组执行
    end note
```

**源码依据**:

| 状态转换 | 位置 |
|----------|------|
| Cached -> Processing | transaction_cache.cpp:454 (ProcessContract) |
| PreHash 请求 | transaction_cache.cpp:1444 (newSeekContractPreHash) |
| PreHash 共识 | transaction_cache.cpp:1549-1553 (66% 阈值, 即 rate >= 0.66) |
| PreHash 响应处理 | transaction_cache.cpp:1386 (handleSeekContractPreHashRequest) |
| 合约打包消息处理 | transaction_cache.cpp:976 (handleContractPackagerMessage) |
| 合约交易执行 | transaction_cache.cpp:1089 (ContractTransaction) |

---

## 7. 未完成/未定义的状态转换

| 状态 | 问题 | 影响 |
|------|------|------|
| **交易超时淘汰** | `_kTxExpireInterval=10` 定义但未使用. 无 `Pending -> Expired` 转换 | 过期交易永久留在池中 |
| **池溢出保护** | 无 `Cached -> Rejected` 转换. 池无大小上限 | 内存可无限制增长 |
| **DECLARATION (6)** | 无对应处理器源文件, 状态转换未实现 | 【需人工验证】 |
| **PROPOSAL (11)** | 无对应处理器源文件 | 【需人工验证】 |
| **REVOKEPROPOSAL (12)** | 无对应处理器源文件 | 【需人工验证】 |
