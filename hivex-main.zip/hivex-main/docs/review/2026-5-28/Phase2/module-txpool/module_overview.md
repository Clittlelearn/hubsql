# 模块7: 交易池与特殊交易类型 - 模块概览

**可信度**: 高 (基于源码直接分析)
**分析日期**: 2026-05-26
**分析范围**: MeMeChain 项目交易池子系统及16种交易类型

---

## 1. 交易池职责与定位

交易池 (Transaction Pool / Mempool) 是 MeMeChain 共识层的核心组件，负责：

1. **接收与缓存**: 从 RPC 层接收待处理交易，按类型分入普通交易池和合约交易池
2. **冲突检测**: 基于 UTXO 输入的双花检查，防止重复消费
3. **定时打包**: 每 3 秒或达到阈值 (1,000,000 笔) 时触发区块构建
4. **交易分发**: 合约交易通过 VRF 选择打包节点，按依赖关系分组投递
5. **失败重试**: 失败交易缓存，在条件满足时重新验证

**文件位置**: `//wsl$/wsl-mm/home/wbl/mm/ca/transaction_cache.cpp` (54.3KB)

---

## 2. 16种交易类型概览

| 类型 | 枚举值 | 说明 | 处理文件 | 关键参数 |
|------|--------|------|---------|---------|
| **UNKNOWN** | -1 | 未知/无效类型 | -- | -- |
| **GENESIS** | 0 | 创世交易, 初始化 UTXO | `genesis_helper` | MM, Vote 初始余额 |
| **TX** | 1 | 普通转账交易 | `ca/transaction/trans.cpp` | from, to, amount, asset_type |
| **STAKE** | 2 | 节点质押 | `ca/transaction/stake.cpp` | MIN_STAKE_AMOUNT=350000000000 (3500MM); commission_rate 5%-35% |
| **UNSTAKE** | 3 | 解押(需满500块) | `ca/transaction/unstake.cpp` | MIN_UNSTAKE_HEIGHT=500 |
| **DELEGATE** | 4 | 委托 | `ca/transaction/delegating.cpp` | kMinDelegatingAmt=500MM; delegateType=NetLicence |
| **UNDELEGATE** | 5 | 取消委托 | `ca/transaction/undelegating.cpp` | utxo_hash (委托UTXO哈希) |
| **DECLARATION** | 6 | 声明交易 | (未提供具体文件) | -- |
| **DEPLOY** | 7 | 部署合约(EVM) | `ca/transaction/contract.cpp` (被 #if 0 注释) | 合约代码, sender nonce |
| **CALL** | 8 | 调用合约(EVM) | `ca/transaction/contract.cpp` (被 #if 0 注释) | 合约地址, input data, transfer |
| **LOCK** | 9 | 锁定(获得投票权) | `ca/transaction/lock.cpp` | LOCK_AMOUNT=1 (标准精度,实际=1*kDecimalNum) |
| **UNLOCK** | 10 | 解锁 | `ca/transaction/unlock.cpp` | utxo_hash (锁定UTXO哈希) |
| **PROPOSAL** | 11 | 提案 | (未提供具体文件) | -- |
| **REVOKEPROPOSAL** | 12 | 撤销提案 | (未提供具体文件) | -- |
| **VOTE** | 13 | 投票 | `ca/transaction/vote.cpp` | vote_hash, tx_type, vote_type, lockValue |
| **FUND** | 98 | 领取国库奖励 | `ca/transaction/fund.cpp` | period gas amount, 按锁定/打包比例分配 |
| **BONUS** | 99 | 领取节点奖励 | `ca/transaction/bonus.cpp` | commission_rate, delegator_reward |

**注意**: FUND=98 和 BONUS=99 的枚举值不连续, 说明这些类型是后来添加的.

---

## 3. 规范 vs 实现对比

| 功能点 | 规范定义 | 当前实现 | 偏差原因 | 可信度 |
|--------|---------|---------|---------|--------|
| **交易超时验证** | KtxTimeout = 10秒 (global.h:60 `KtxTimeout = 10 * 1000000ull`) | `transaction_cache.h:79` 定义 `_kTxExpireInterval = 10` (秒), 但在 `processTransactionCacheFunc()` 中**未被引用** -- 无超时淘汰逻辑 | 超时常量存在但未使用, 为**未完成功能** | 高 |
| **双花检查** | `doubleSpendCheck(tx)` -- 基于 UTXO 输入碰撞检测 | `Checker::CheckConflict()` (checker.cpp:97) 按 `prevout.hash + pub + currency` 交集判断; `doubleSpendCache` (double_spend_cache.cpp:1) 独立维护 addr->utxos 缓存, 30秒 TTL | 双花检测存在两层: Checker 比较池内交易, doubleSpendCache 维护消费映射. 但两者**独立工作无联动** | 高 |
| **交易独立性标志** | `independence` 字段: FALSE(0)/TRUE(1)/NAN(2) (global.h:76-80) | 仅在合约交易中设置, 非合约交易**不使用该字段**. contract.cpp 第322行有使用 | 非合约交易未利用独立性标志做并行验证 | 高 |
| **交易池淘汰策略** | 规范提及但未定义 (spec_dev.md:2744 TODO) | 完全缺失. `processTransactionCacheFunc()` 打包后直接 clear 或继续循环, 无基于时间、Gas-price 或 nonce 的淘汰 | **关键缺失** -- 无 DoS 防护 | 高 |
| **池大小限制** | 规范提及但未具体化 | 仅有 `BUILD_THRESHOLD = 1000000` (transaction_cache.cpp:80), 但无硬上限 | 池可无限制增长 | 高 |
| **BUILD_INTERVAL** | 无规范定义 | `BUILD_INTERVAL = 3 * 1000` (3秒, transaction_cache.cpp:78) | 硬编码, 合理 | 高 |
| **合约交易缓存** | 规范提及 `ContractTransactionCache` | `ContractTransactionCache` (contract_transaction_cache.h) **完全被 #if 0 注释** | 合约交易重试机制被废弃 | 高 |
| **失败交易缓存** | 无规范定义 | `failedTransactionCache` 2秒定时检查, 网络节点75%高度达标后重试, top > txHeight+3 丢弃 | 额外实现, 合理但简陋 | 高 |
| **交易分发** | VRF 选择打包节点 | dispatchtx.cpp 通过并查集合并依赖合约交易组, 最多8组并发分发, VRF 选择唯一打包者 | 实现较完整 | 高 |
| **Gas 验证** | `Gas >= required` | 各交易类型在 `getGasValue()` 中按 UTXO 规模 + vout 数计算 | 实现与规范一致 | 中 |

---

## 4. 架构缺陷总结

### 4.1 关键缺陷
1. **无交易超时淘汰** (严重): `_kTxExpireInterval=10` 定义但从未在内存池清理逻辑中使用. 攻击者可发送过时交易填充内存池.
2. **无池大小硬上限** (严重): 仅设置 `BUILD_THRESHOLD=1000000`, 但无拒绝新交易的机制.
3. **双花检测双重实现但无协同** (中等): Checker 和 doubleSpendCache 各自独立检查, 存在冗余和遗漏的风险.

### 4.2 代码质量问题
1. `transaction_cache.cpp` 第78行 `_kTxExpireInterval` 声明为 `static const time_t`, 但 `.h` 中声明为 `static const time_t`, 两处名字一致 `_kTxExpireInterval` -- 实际**未被使用**.
2. `ContractTransactionCache` (contract_transaction_cache.h/cpp) 被整体注释 (约 178 行), 功能已废弃.
3. `contract.cpp` 被 `#if 0` 包围 (897 行), 说明合约交易构建功能可能已迁移到其他文件.

### 4.3 废弃/未完成代码
- `DependencyManager` 中 Broadcast 相关代码 (dispatchtx.cpp lines 449-860) 全部注释
- `ContractDispatcher` / `TimerProcessor` 中的 `SendTransactionInfoRequest` 依赖 VRF 选择, 但其内部 `CanSendTransaction` 检查已被注释

---

## 5. DoS 防护评估

| 攻击向量 | 防护措施 | 有效性 |
|----------|---------|--------|
| 发送垃圾交易填满池 | 无大小限制, 无交易超时淘汰 | **无防护** |
| 双花攻击 | Checker::CheckConflict + doubleSpendCache | 有效, UTXO 级别 |
| 过时交易重放 | 无超时校验 | **无防护** |
| 合约交易风暴(依赖环) | 依赖分组 + VRF 打包节点选择 | 有效 |
| 内存耗尽 | 无池上限 | **无防护** |
| Gas 价格操纵 | KTargetGasPrice=60000, GenerateGas 按实际 UTXO 规模 | 基本有效 |

**总体评分**: DoS 防护 **弱** (2/10). 最严重的问题是缺少交易池的容量和超时管理.

---

## 6. 源文件清单

| 文件 | 大小 | 状态 |
|------|------|------|
| `ca/transaction_cache.cpp/h` | 54.3KB / 8.4KB | 活跃 |
| `ca/dispatchtx.cpp/h` | 38.3KB / 5.2KB | 活跃 |
| `ca/failed_transaction_cache.cpp/h` | 3.7KB / 1.6KB | 活跃 |
| `ca/double_spend_cache.cpp/h` | 2.2KB / 1.2KB | 活跃 |
| `ca/contract_transaction_cache.cpp/h` | 6.5KB / 3.1KB | **已废弃(#if 0)** |
| `ca/checker.cpp/h` | 5.4KB / 2.2KB | 活跃 |
| `ca/transaction_entity.h` | 2.4KB | 活跃 |
| `ca/txhelper.cpp/h` | 138.6KB / 18.2KB | 活跃 |
| `ca/transaction/stake.cpp/h` | 7.2KB / 1.2KB | 活跃 |
| `ca/transaction/unstake.cpp/h` | 7.3KB / 0.9KB | 活跃 |
| `ca/transaction/delegating.cpp/h` | 9.8KB / 1.3KB | 活跃 |
| `ca/transaction/undelegating.cpp/h` | 9.5KB / 1.1KB | 活跃 |
| `ca/transaction/lock.cpp/h` | 7.6KB / 0.9KB | 活跃 |
| `ca/transaction/unlock.cpp/h` | 7.2KB / 0.8KB | 活跃 |
| `ca/transaction/vote.cpp/h` | 6.4KB / 0.9KB | 活跃 |
| `ca/transaction/bonus.cpp/h` | 13.5KB / 1.3KB | 活跃 |
| `ca/transaction/fund.cpp/h` | 11.3KB / 1.6KB | 活跃 |
| `ca/transaction/contract.cpp/h` | 29.6KB / 2.9KB | **已废弃(#if 0)** |
| `ca/global.h` | 5.6KB | 活跃 |
