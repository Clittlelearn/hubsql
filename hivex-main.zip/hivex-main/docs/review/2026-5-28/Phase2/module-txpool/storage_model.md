# 模块7: 交易池与特殊交易类型 - 存储模型分析

**可信度**: 高 (基于源码存储逻辑分析)
**分析日期**: 2026-05-26

---

## 1. 存储分层架构

```
┌─────────────────────────────────────────────────────────────┐
│                      内存层 (Volatile)                       │
│  ┌──────────────┐  ┌───────────────┐  ┌──────────────────┐   │
│  │TransactionCache│  │_contractCache │  │ contractInfoCache│   │
│  │ (普通交易缓存) │  │ (合约交易缓存) │  │ (合约执行结果)    │   │
│  │ vector<Ent>   │  │ vector<Ent>   │  │ map<str,pair>    │   │
│  └──────────────┘  └───────────────┘  └──────────────────┘   │
│  ┌──────────────┐  ┌───────────────┐  ┌──────────────────┐   │
│  │doubleSpendCache│ │failedTxCache  │  │ dirtyContractMap │   │
│  │ (双花检测)     │  │ (失败重试)     │  │ (合约脏数据)     │   │
│  │ map<str,str>  │  │ map<uint,vec> │  │ map<str,pair>    │   │
│  └──────────────┘  └───────────────┘  └──────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ 区块提交后
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                  持久层 (RocksDB)                             │
│  ┌──────────────┐  ┌───────────────┐  ┌──────────────────┐   │
│  │ TX:<txHash>  │  │ TXBH:<height> │  │ 各种UTXO索引      │   │
│  │ → 交易Raw数据 │  │ → 交易Hash列表 │  │ ...              │   │
│  └──────────────┘  └───────────────┘  └──────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. 内存存储详细分析

### 2.1 TransactionCache 普通交易池

**数据结构**: `std::vector<TransactionEntity> _transactionCache` (transaction_cache.h:42)

**TransactionEntity 成员**:
| 字段 | 类型 | 来源 |
|------|------|------|
| `_msg` | `TxMsgReq` | 网络消息 (含 nodeheight, txutxoheight) |
| `_transaction` | `CTransaction` | 反序列化的交易 |
| `txUtxoHeight_1` | `uint64_t` | UTXO 相关高度 |

**存储逻辑**:
```cpp
// transaction_cache.cpp:245-280
int TransactionCache::AddCache(CTransaction& transaction, const TxMsgReq& msg)
{
    // FUND 类型使用 nodeheight
    if (txType == FUND) {
        _transactionCache.push_back({ msg, transaction, msg.txmsginfo().nodeheight() });
    }
    // 其他类型使用 txutxoheight
    else {
        _transactionCache.push_back({ msg, transaction, msg.txmsginfo().txutxoheight() });
    }
    
    // 达到阈值触发打包
    if (_transactionCache.size() >= BUILD_THRESHOLD) {
        _blockBuilder.notify_one();
    }
}
```

**生命周期**:
- 创建: `AddCache()` push_back
- 消费: `processTransactionCacheFunc()` 遍历后 clear
- 清理: 打包成功后 `clear()`, 失败(非恢复)也 `clear()`

**容量**: 无上限, 仅 `BUILD_THRESHOLD = 1,000,000` 作为打包触发阈值.
实际容量完全由系统内存决定.

---

### 2.2 TransactionCache 合约交易池

**数据结构**: `std::vector<TransactionEntity> _contractCache` (transaction_cache.h:49)

**与普通池的区别**:
- 合约交易不入 `_transactionCache`, 直接入 `_contractCache`
- 由 `ProcessContract()` 消费, 而非 `processTransactionCacheFunc()`
- 打包前需要 `fetchContractTxPreHash()` 请求全网共识

---

### 2.3 contractInfoCache (合约执行结果缓存)

**数据结构**: `std::map<std::string, std::pair<nlohmann::json, uint64_t>>` (transaction_cache.h:66)
- key: 交易哈希
- value: {JSON执行结果, 时间戳}

**用途**:
- `addContractInfoCache()` -> 预执行合约, 存储结果 (transaction_cache.cpp:584)
- `get_contract_info_cache()` -> 打包时读取执行结果 (transaction_cache.cpp:842)
- `CreateBlock()` 中读取合约存储信息填入 block.data (transaction_cache.cpp:116)

---

### 2.4 dirtyContractMap (合约脏数据映射)

**数据结构**: `std::map<std::string, std::pair<uint64_t, std::set<std::string>>>` (transaction_cache.h:71)
- key: 交易哈希
- value: {添加时间, 受影响的合约地址集合}

**用途**:
- `ContractTransaction()` 中设置: 记录每笔交易的合约依赖 (transaction_cache.cpp:1110)
- `ProcessContract()` 中消费: 验证合约交易的预执行结果 (transaction_cache.cpp:488)
- `CreateBlock()` 中读取: 填入 block.data 的 dependentCTx (transaction_cache.cpp:123)

**清理机制**: `removeExpiredFromDirtyContractMap()` (transaction_cache.cpp:930-945)
- 遍历所有条目, 删除超过 60 秒未处理的记录
- `nowTime >= iter->second.first + 60 * 1000000ull`

---

### 2.5 doubleSpendCache (双花检测)

**数据结构**: `std::map<std::string, doubleSpendSuccess> _pending` (double_spend_cache.h:65)
- key: address (UTXO 所有者)
- value: {time, utxoVector}

```cpp
struct doubleSpendSuccess {
    uint64_t time;
    std::vector<std::string> utxoVector;
};
```

**TTL**: 30 秒 (CheckLoop, double_spend_cache.cpp:56)
**清理**: 每 1 秒扫描, 超时移除
**确认移除**: 区块确认后 `Detection(block)` 移除对应记录

---

### 2.6 failedTransactionCache (失败交易)

**数据结构**: `std::map<uint64_t, std::vector<TxMsgReq>> _txPending` (failed_transaction_cache.h:72)
- key: 节点高度
- value: 该高度下失败的交易列表

**清理条件** (failed_transaction_cache.cpp:71):
- `top > txHeight + 3` -> 当前区块高度超过交易高度 3 块后丢弃
- 重试后无论成功失败, 从列表中移除

---

## 3. 持久化存储 (RocksDB)

### 3.1 交易数据持久化

交易打包进区块后, 区块通过 `BlockHelper` 存储到 RocksDB. 具体 key 前缀:

| Key 前缀 | 说明 | 来源 |
|----------|------|------|
| `TX:<txHash>` | 交易原始数据 | ca/transaction.cpp |
| `TXBH:<height>` | 某高度下的交易哈希列表 | ca/transaction.cpp (推测) |
| `B:<blockHash>` | 区块数据 | ca/block_stroage.cpp |
| `BH:<height>` | 某高度下的区块哈希列表 | ca/block_stroage.cpp |

### 3.2 交易相关索引 (通过 DBReader 访问)

| 索引 | 用途 | 来源 |
|------|------|------|
| `getLockAddrUtxo(addr, "Vote", utxos)` | 锁定地址UTXO | lock.cpp:56 |
| `getNonceByAddr(addr, nonce)` | 地址 nonce | 各交易 makeTxInfor |
| `getLatestUtxoByContractAddr(addr, hash)` | 合约地址最新UTXO | transaction_cache.cpp:891 |
| `getUtxoHashsByAddress(addr, type, hashes)` | 地址的UTXO哈希列表 | contract.cpp (废弃) |
| `getGasAmountByPeriod(period, type, amount)` | 周期Gas总量 | fund.cpp:51 |
| `getPackagerCountByPeriod(period, addr, times)` | 地址打包次数 | fund.cpp:112 |
| `getBlockTop(top)` | 当前最高区块高度 | 多处 |

### 3.3 交易池不持久化

重要设计决策: **交易池内的交易不持久化**.
- 所有交易池数据 (TransactionCache, doubleSpendCache, failedTransactionCache) 均为纯内存结构
- 节点重启后交易池为空, 需重新从网络接收交易
- 已打包的交易通过区块持久化保留

---

## 4. 内存占用估算

| 组件 | 假设条件 | 估算大小 |
|------|---------|---------|
| _transactionCache | 10000 笔, 每笔 TransactionEntity ~1KB | ~10 MB |
| _contractCache | 100 合约交易, 每笔 + JSON 结果 ~5KB | ~0.5 MB |
| contractInfoCache | 同上 | ~0.5 MB |
| dirtyContractMap | 同上 | ~0.1 MB |
| doubleSpendCache | 最大并发 1000 地址 | ~1 MB |
| failedTransactionCache | 100 失败交易 | ~0.1 MB |

**总计**: 低负载约 ~12 MB, 但在无容量限制下可无限增长.

---

## 5. 存储问题清单

| 问题 | 位置 | 风险 | 说明 |
|------|------|------|------|
| 交易池无大小上限 | transaction_cache.cpp:268-272 | 高 | vector 无容量限制, push_back 无拒绝逻辑 |
| 交易无时效淘汰 | -- | 高 | `_kTxExpireInterval=10` 存在但未使用 |
| FUND 使用 nodeheight vs 其他使用 txutxoheight | transaction_cache.cpp:268-272 | 中 | 不一致的高度语义 |
| dirtyContractMap 60秒TTL | transaction_cache.cpp:934 | 中 | 硬编码, 不支持配置 |
| doubleSpendCache 30秒TTL | double_spend_cache.cpp:56 | 中 | 变量名 kTenSecond 实际30秒 |
| 内存数据重启丢失 | 全局 | 中 | 重启后交易池恢复依赖网络重新广播 |
