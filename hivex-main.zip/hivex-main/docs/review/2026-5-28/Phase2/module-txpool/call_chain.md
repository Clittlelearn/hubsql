# 模块7: 交易池与特殊交易类型 - 调用链分析

**可信度**: 高 (基于源码调用链分析)
**分析日期**: 2026-05-26

---

## 1. 交易入池流程

```mermaid
sequenceDiagram
    participant RPC as RPC 层
    participant HT as handleTransaction()
    participant TC as TransactionCache
    participant CK as Checker
    participant DSC as doubleSpendCache

    RPC->>HT: TxMsgReq (序列化交易)
    HT->>HT: 反序列化 CTransaction
    HT->>HT: 版本检查 (version)
    HT->>HT: 交易类型路由 (type)
    HT->>HT: 签名验证 (all signatures)
    HT->>CK: CheckConflict(tx, cache)
    CK-->>HT: 0=无冲突, -1=双花
    HT->>DSC: AddFromAddr(addr, utxos)
    DSC-->>HT: 0=成功, -1=冲突
    HT->>TC: AddCache(tx, msg)
    Note over TC: transaction_cache.cpp:245
    alt 合约交易 (CALL/DEPLOY)
        TC->>TC: lock(contractCacheMutex)
        TC->>CK: CheckConflict(tx, _contractCache)
        TC->>TC: _contractCache.push_back(...)
    else 普通交易
        TC->>TC: lock(transactionCacheMutex)
        TC->>CK: CheckConflict(tx, _transactionCache)
        Note over TC: FUND 类型使用 nodeheight
        Note over TC: 其他类型使用 txutxoheight
        TC->>TC: _transactionCache.push_back(...)
        opt size >= BUILD_THRESHOLD (100万)
            TC->>TC: _blockBuilder.notify_one()
        end
    end
```

**关键源码行**:
- 交易入池入口: `transaction_cache.cpp:245 (AddCache)`
- FUND 特殊路径: `transaction_cache.cpp:268-269` -- FUND 使用 `nodeheight` 而非 `txutxoheight`
- 双花检查: `checker.cpp:97 (CheckConflict)` -- 基于 `prevout.hash + pub + currency`

---

## 2. 交易打包流程

```mermaid
sequenceDiagram
    participant Timer as CTimer (3s)
    participant BuildTh as BuildThread
    participant TC as TransactionCache
    participant BS as BlockStorage
    participant BH as BlockHelper

    Timer->>BuildTh: _blockBuilder.notify_one()
    Note over BuildTh: transaction_cache.cpp:397
    BuildTh->>TC: lock(transactionCacheMutex)
    BuildTh->>TC: _blockBuilder.wait()
    
    BuildTh->>TC: get_build_block_height()
    Note over TC: transaction_cache.cpp:293
    TC->>TC: 收集质押节点列表
    TC->>TC: 统计满足高度条件的节点比例
    alt 合格节点75%达标
        TC-->>BuildTh: 返回打包高度
    else 不合格
        TC-->>BuildTh: -1 (清除缓存, 放弃)
    end

    BuildTh->>TC: 遍历 _transactionCache 构建 buildTxs
    BuildTh->>BS: commitLookupTask(buildHeight)
    BuildTh->>TC: BuildBlock(buildTxs, buildHeight)
    Note over BH: transaction_cache.cpp:173
    BH->>BH: CreateBlock() -- 填充区块字段
    BH->>BH: Getsha256Hash(block) -- 计算区块哈希
    BH->>BH: handleBlock(blockMsg) -- 分发区块
    alt 成功
        BuildTh->>TC: _transactionCache.clear()
    else 恢复性失败 (-103/-104/-105)
        BuildTh->>TC: continue (不清除)
    else 其他失败
        BuildTh->>TC: _transactionCache.clear()
    end
```

**关键源码行**:
- 打包触发: `transaction_cache.h:60 static const int BUILD_INTERVAL = 3*1000`
- 高度选择算法: `transaction_cache.cpp:293 (get_build_block_height)` -- 核心共识逻辑
- 区块创建: `transaction_cache.cpp:83 (CreateBlock)`
- 区块构建: `transaction_cache.cpp:173 (BuildBlock)`
- 失败恢复: `transaction_cache.cpp:435-444` -- 恢复性失败不清除缓存

---

## 3. 质押流程 (CreateStake -> 入池)

```mermaid
sequenceDiagram
    participant User as 用户/CLI
    participant RPC as RPC API
    participant ST as StakeTrans
    participant TH as TxHelper
    participant UC as UtxoCore
    participant TC as TransactionCache

    User->>RPC: CreateStakingTransaction(addr, amount, commission)
    RPC->>ST: StakeTrans(param)
    ST->>ST: checkParams()
    Note over ST: stake.cpp:157
    ST->>ST: 检查 isStaked(addr) -- 不可重复质押
    ST->>ST: 检查 amount >= MIN_STAKE_AMOUNT (3500MM)
    ST->>ST: 检查 commission_rate in [5%, 35%]
    
    ST->>UC: createUtxoTransferFrom() -- UTXO选择(VIN)
    Note over UC: 按资产类型查找可用UTXO
    UC-->>ST: 可用余额 balance
    
    ST->>ST: makeTxInfor() -- 设置交易元数据
    Note over ST: stake.cpp:116
    ST->>ST: nonce = getNonceByAddr()
    ST->>ST: data = {StakeType, StakeAmount, CommissionRate}
    
    ST->>ST: getGasValue() -- 计算Gas
    Note over ST: stake.cpp:181
    
    ST->>UC: createUtxoTransferTo()
    Note over UC: 输出1: -> VirtualStake (质押金额)
    Note over UC: 输出2: -> self (找零)
    Note over UC: 输出3: -> VirtualBurnGas (Gas销毁)
    
    ST->>ST: calculate_all_hash(&tx)
    ST->>TH: fetchIdentityNodes(vrf, hash, time, identity)
    Note over TH: VRF 选择打包节点
    TH-->>ST: identity (打包节点地址)
    ST->>ST: tx.set_identity(identity)
    
    ST->>ST: goMessage()
    Note over ST: stake.cpp:206
    alt identity == self
        ST->>TC: handleTransaction(msg, tx) -- 直接处理
    else identity != self
        ST->>TC: DropShippingTransaction(msg, tx, identity)
        Note over TC: 转发到目标打包节点
    end
    TC->>TC: AddCache() -- 交易入池
```

**关键源码行**:
- 质押参数检查: `stake.cpp:157-178`
- UTXO 选择: `stake.cpp:31-34`
- 输出构造: `stake.cpp:68-70` (3个输出: 质押/找零/销毁)
- 打包节点选择: `stake.cpp:101 (fetchIdentityNodes)`
- 交易发送: `stake.cpp:206-254 (goMessage)` -- 自打包 vs 转发

---

## 4. 委托流程 (CreateDelegating)

```mermaid
sequenceDiagram
    participant User as 用户
    participant DT as DelegatingTrans
    participant TH as TxHelper
    participant UT as UtxoCore

    User->>DT: CreateDelegatingTransaction(from, to, amount, asset_type)
    DT->>DT: trans()
    Note over DT: delegating.cpp:16
    
    DT->>TH: Check(address_vector, asset_type, height)
    TH-->>DT: 地址/资产/高度验证
    
    DT->>DT: isValidAddress(from) && isValidAddress(to)
    DT->>DT: delegatinged_amount >= kMinDelegatingAmt (500MM)
    Note over DT: delegating.cpp:60
    
    DT->>DT: CheckDelegatingQualification(from, to, asset_type, amount)
    Note over DT: delegating.cpp:65 -- 核心资格检查
    
    DT->>DT: delegate_type = kdelegateType_NetLicence
    Note over DT: delegating.cpp:74-81
    
    DT->>UT: createUtxoTransferFrom() -- UTXO选择
    UT-->>DT: 可用余额 total
    
    DT->>DT: makeTxInfor() -- nonce, data
    
    DT->>DT: getGasValue() -- Gas计算
    
    DT->>UT: createUtxoTransferTo()
    Note over UT: 输出1: -> VirtualDelegating (委托金额)
    Note over UT: 输出2: -> from_addr (找零)
    Note over UT: 输出3: -> VirtualBurnGas (Gas销毁)
    
    DT->>TH: fetchIdentityNodes(vrf, hash, time, identity)
    DT->>DT: tx.set_identity(identity)
    
    DT->>DT: goMessage()
    Note over DT: delegating.cpp:214
```

**关键源码行**:
- 委托量检查: `delegating.cpp:60` -- `kMinDelegatingAmt = 500 * kDecimalNum`
- 资格检查: `delegating.cpp:65` -- `CheckDelegatingQualification`
- 目标地址: `delegating.cpp:129` -- `kVirtualDelegatingAddr = "VirtualDelegating"`
- 委托类型: `delegating.cpp:74` -- 仅支持 `kdelegateType_NetLicence`

---

## 5. 投票流程 (CreateVote)

```mermaid
sequenceDiagram
    participant User as 用户
    participant VT as VoteTrans
    participant AL as ca_algorithm
    participant TH as TxHelper

    User->>VT: CreateVoteTransaction(addr, vote_hash, tx_type, vote_type)
    VT->>VT: trans()
    Note over VT: vote.cpp:13
    
    VT->>VT: isValidAddress(addr)
    VT->>TH: Check(fromaddr, asset_type, height+1)
    
    VT->>AL: GetLockValue(addr, lockValue)
    Note over AL: vote.cpp:51 -- 获取锁定金额=投票权重
    AL-->>VT: lockValue

    VT->>AL: CheckVoteTxInfo(vote_hash, tx_type, vote_type, time)
    Note over AL: vote.cpp:60 -- 验证投票信息
    
    VT->>VT: createUtxoGasBylameda() + lambda getGasValue
    Note over VT: vote.cpp:81-94 -- 投票交易无VIN, 仅有GAS UTXO
    
    VT->>VT: makeTxData() -> {VoteHash, VoteTxType, VoteType, VoteNumber}
    Note over VT: vote.cpp:233-245
    VT->>VT: makeTxInfor() -> nonce
    
    VT->>TH: getTransactionStartIdentity(height+1, time, vtype)
    Note over TH: vote.cpp:104
    VT->>TH: fetchIdentityNodes(vtype, hash, time, identity)
    TH-->>VT: identity
    VT->>VT: tx.set_identity(identity)
    
    VT->>VT: goMessage()
```

**关键源码行**:
- 投票权重获取: `vote.cpp:51` -- `ca_algorithm::GetLockValue()`
- 投票信息验证: `vote.cpp:60` -- `ca_algorithm::CheckVoteTxInfo()`
- 交易数据: `vote.cpp:233-245 (makeTxData)` -- 包含投票哈希、类型、票数
- 投票交易无普通 UTXO 输入: `vote.cpp:81-94` 仅创建 Gas UTXO

---

## 6. 合约交易打包全流程

```mermaid
sequenceDiagram
    participant Init as 交易发起方
    participant DP as DependencyManager
    participant TP as TimerProcessor
    participant MD as MessageDispatcher
    participant VRF as VRF 选择
    participant PK as 打包节点
    participant TC as TransactionCache

    Init->>DP: AddContractRequest(txHash, deps, msg)
    DP->>DP: contract_dep_cache_[txHash] = deps
    DP->>DP: contract_msg_cache_[txHash] = msg

    TP->>TP: 睡眠1秒, time_value+=1000000
    Note over TP: dispatchtx.cpp:373
    TP->>TP: time_value >= baseline + 3秒?
    
    TP->>DP: GetDependentData()
    DP->>DP: 构建并查集合并依赖组
    DP->>DP: 返回 vector<vector<TxMsgReq>>
    
    TP->>DP: GroupData(dependent_data, 8组)
    
    TP->>MD: DistributionContractTransactionRequest(distribution, grouped)
    loop 每组交易
        MD->>MD: 连接所有txHash -> sha256(hash_concat)
        MD->>VRF: FindContractPackNode(input_hash, max_time, pack_addr)
        VRF-->>MD: pack_addr (VRF选择)
        MD->>MD: distribution.emplace(pack_addr, tx_group)
    end

    loop 每个打包者
        MD->>VRF: BuildSelectionProof(contract_packager, owner, candidates, input, 1)
        VRF-->>MD: selectionVrf
        MD->>MD: msg.set_selection_vrf(selectionVrf)
        
        alt owner == packager
            MD->>TC: handleContractPackagerMessage(msg, msgdata)
        else owner != packager
            MD->>PK: NetSendMessage<ContractPackagerMsg>(packager, msg)
        end
    end

    PK->>TC: handleContractPackagerMessage(msg)
    TC->>TC: 验证 VRF SelectionProof
    TC->>TC: 按 blockTimestamp 分组
    
    loop 每组
        TC->>TC: ContractTransaction(msgs)
        Note over TC: 并行验证+执行合约交易
        TC->>TC: ProcessContract()
        Note over TC: 构建合约区块 + BuildBlock
    end
```

**关键源码行**:
- 定时器触发: `dispatchtx.cpp:373-441 (TimerProcessor::ProcessingFunc)`
- 并查集分组: `dispatchtx.cpp:113-177 (GetDependentData)`
- VRF 打包者选择: `dispatchtx.cpp:243 (FindContractPackNode)` + `dispatchtx.cpp:306 (BuildSelectionProof)`
- 打包节点处理: `transaction_cache.cpp:976 (handleContractPackagerMessage)`
- 合约交易分组: `transaction_cache.cpp:1089 (ContractTransaction)`

---

## 7. 失败交易重试流程

```mermaid
sequenceDiagram
    participant Handle as handleTransaction()
    participant FTC as failedTransactionCache
    participant Timer as CTimer (2s)
    participant TaskPool as TaskPool
    participant DB as DBReader

    Handle->>Handle: handleTransaction() 返回非0
    Handle->>FTC: Add(nodeHeight, txMsg)
    Note over FTC: failed_transaction_cache.cpp:123

    Timer->>FTC: AsyncLoop 2s -> _Check()
    Note over FTC: failed_transaction_cache.cpp:9
    
    FTC->>DB: getBlockTop(top)
    FTC->>FTC: 遍历 _txPending
    
    loop 每个高度条目
        FTC->>FTC: 计算 nodeHeight >= txHeight 的节点比例
        alt nodeHeight < nodelist.size() * 0.75
            Note over FTC: 跳过, 网络不够高
        else
            alt top > txHeight + 3
                Note over FTC: 过期, 标记删除
            else
                loop 每笔待重试交易
                    FTC->>TaskPool: CommitTransactionTask(重试任务)
                    TaskPool->>TaskPool: handleTransaction(txMsg, tx)
                    alt 验证成功
                        Note over TaskPool: 交易正常入池
                    else 验证失败
                        Note over TaskPool: 记录日志, 继续
                    end
                end
                FTC->>FTC: 删除已处理的交易
            end
        end
    end
```

**关键源码行**:
- 失败添加: `failed_transaction_cache.cpp:123 (Add)`
- 定时检查: `failed_transaction_cache.cpp:9-17 (_StartTimer)`
- 重试逻辑: `failed_transaction_cache.cpp:33-121 (_Check)`
- 过期丢弃: `failed_transaction_cache.cpp:71` -- `top > txHeight + 3`

**问题**:
- [failed_transaction_cache.cpp:85-87] 重试时 `tx.clear_hash()` + `tx.set_hash(新hash)` 可能导致签名失效
- [failed_transaction_cache.cpp:71] 硬编码 `+ 3` 无配置项
