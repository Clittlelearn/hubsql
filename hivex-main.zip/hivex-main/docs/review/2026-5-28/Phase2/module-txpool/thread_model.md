# 模块7: 交易池与特殊交易类型 - 线程模型分析

**可信度**: 高 (基于源码线程/锁分析)
**分析日期**: 2026-05-26

---

## 1. 线程总览

```mermaid
graph TD
    subgraph "主线程 / RPC 线程"
        RPC[RPC 请求处理]
        RPC -->|调用| TXCON[各交易类型 trans() + goMessage()]
        TXCON -->|入池| TC_ADD[TransactionCache::AddCache]
    end

    subgraph "TransactionCache 打包线程"
        T1[processTransactionCacheFunc]
        T1 -->|每3秒/阈值触发| BUILD[BuildBlock]
        T1 -->|mutex| TCM[transactionCacheMutex]
    end

    subgraph "CTimer 定时器 (主线程事件循环)"
        TIMER[_buildTimer: 3s]
        TIMER -->|notify_one| CV[_blockBuilder condition_variable]
    end

    subgraph "doubleSpendCache 清理线程"
        T2[CheckLoop 1s]
        T2 -->|mutex| DSM[doubleSpendMutex]
    end

    subgraph "failedTransactionCache 重试线程"
        T3[AsyncLoop 2s -> _Check]
        T3 -->|shared_mutex| FTM[txPendingMutex]
    end

    subgraph "TimerProcessor 合约分发线程"
        T4[ProcessingFunc 1s tick]
        T4 -->|mutex| TIM[_timer_mutex_]
        T4 -->|分发| DISPATCH[合约交易分发]
    end

    subgraph "TaskPool 工作线程池"
        T5[CommitTransactionTask]
        T5 -->|执行| EXEC[handleTransaction]
        T5 -->|执行| EXEC2[executeContracts]
    end

    T1 -.->|竞争| TCM
    TC_ADD -.->|竞争| TCM
    T1 -.->|竞争| CCM[contractCacheMutex]
    TC_ADD -.->|竞争| CCM
```

---

## 2. 各线程详细分析

### 2.1 processTransactionCacheFunc (打包主线程)

**创建**: `TransactionCache::Process()` (transaction_cache.cpp:284)
```cpp
transactionCacheBuildThread = std::thread(
    std::bind(&TransactionCache::processTransactionCacheFunc, this));
transactionCacheBuildThread.detach();  // detached thread
```

**生命周期**:
- 启动: `Process()` 调用
- 循环: `while (_threadRun)` (transaction_cache.cpp:403)
- 停止: `Stop()` 设置 `_threadRun = false` (transaction_cache.cpp:289-291)

**工作模式**:
1. `_blockBuilder.wait(locker)` 阻塞等待 (transaction_cache.cpp:405)
2. 被 `_buildTimer` (每3秒) 或 `AddCache` (size>=100万) 唤醒
3. `get_build_block_height()` 确定打包高度 (需75%节点达标)
4. `BuildBlock()` 创建并广播区块
5. 成功或非恢复失败后 `_transactionCache.clear()`

**线程安全**:
- 使用 `transactionCacheMutex` (std::mutex) 保护 `_transactionCache`
- `_blockBuilder` 作为条件变量关联上述 mutex
- 与 RPC 线程通过 mutex 互斥

---

### 2.2 CTimer 定时器 (_buildTimer)

**创建**: `TransactionCache::TransactionCache()` 构造函数 (transaction_cache.cpp:233)
```cpp
_buildTimer.AsyncLoop(
    BUILD_INTERVAL,  // 3000ms
    [=](){ _blockBuilder.notify_one(); }
);
```

**说明**: CTimer 在主事件循环线程中执行回调, 每3秒触发一次 `notify_one()`.

---

### 2.3 doubleSpendCache::CheckLoop (双花缓存清理)

**创建**: `doubleSpendCache::doubleSpendCache()` 构造函数 (double_spend_cache.h:20-24)
```cpp
_timer.AsyncLoop(1000, [this](){ CheckLoop(); });
```

**工作内容** (double_spend_cache.cpp:50-68):
- 每1秒扫描 `_pending` map
- 清理超过30秒的记录 (`kTenSecond = 30 * 1000000`)
- 使用 `doubleSpendMutex` 保护

**问题**: [double_spend_cache.cpp:56] 变量名 `kTenSecond` 但值为30秒, 命名误导.

---

### 2.4 failedTransactionCache::_StartTimer (失败交易重试)

**创建**: `failedTransactionCache::_StartTimer()` (failed_transaction_cache.cpp:9-17)
```cpp
_timer.AsyncLoop(2 * 1000, [this](){
    if(!_IsEmpty()) { _Check(); }
});
```

**工作内容** (failed_transaction_cache.cpp:33-121):
- 每2秒检查
- 验证网络条件后提交到 TaskPool 执行重试
- 使用 `shared_mutex txPendingMutex`

---

### 2.5 TimerProcessor::ProcessingFunc (合约分发定时器)

**创建**: `TimerProcessor::Start()` (dispatchtx.cpp:354-357)
```cpp
timer_thread_ = std::thread(&TimerProcessor::ProcessingFunc, this);
timer_thread_.detach();
```

**工作模式** (dispatchtx.cpp:373-441):
- 每秒 tick (`wait_for(1s)`)
- `time_value_ += 1000000`
- 累计达到 `kContractWaitingTime = 3秒` 后触发
- 分发流程: `GetDependentData() -> GroupData() -> DistributionContractTransactionRequest() -> SendTransactionInfoRequest()`
- 分发后 `ClearCaches()`, 重置计数器

**线程安全**:
- `timer_mutex_` 保护 `time_value_`
- `DependencyManager` 使用 `dep_mutex_` + `msg_mutex_` 双锁

---

### 2.6 TaskPool 工作线程 (异步任务执行)

**使用位置**:
- 合约交易验证并行化: `transaction_cache.cpp:1141` -- `commitWorkTask`
- 合约依赖组执行: `transaction_cache.cpp:1164` -- `CommitTransactionTask`
- 非依赖组合约执行: `transaction_cache.cpp:1191` -- `commit_block_task`
- 失败交易重试: `failed_transaction_cache.cpp:79` -- `CommitTransactionTask`

**线程安全影响**:
- ContractTransaction() 中创建 `packaged_task` 保存 `future`, 使用 `future::get()` 等待结果
- 多个合约依赖组可并行执行 (因为依赖组内通过依赖关系保证顺序)

---

## 3. 锁与并发访问分析

### 3.1 锁清单

| 锁变量 | 类型 | 保护对象 | 持有者 (线程) |
|--------|------|---------|--------------|
| `transactionCacheMutex` | `mutex` | `_transactionCache` | RPC线程 (AddCache), 打包线程 (process) |
| `contractCacheMutex` | `mutex` | `_contractCache` | RPC线程, ProcessContract |
| `contractInfoCacheMutex` | `shared_mutex` | `contractInfoCache` | ProcessContract(写), get_contract_info_cache(读) |
| `dirtyContractMapMutex` | `shared_mutex` | `dirtyContractMap` | ContractTransaction(写), ProcessContract(读) |
| `buildTxsMutex` | `mutex` | `buildTxs` | processTransactionCacheFunc |
| `doubleSpendMutex` | `mutex` | `_pending` | RPC线程 (AddFromAddr), CheckLoop |
| `txPendingMutex` | `shared_mutex` | `_txPending` | RPC线程 (Add), 重试线程 (_Check) |
| `_threadMutex` | `mutex` | handleContractPackagerMessage | 合约打包节点处理 |
| `_contractPackagerSelectionVrfMutex` | `mutex` | `_contractPackagerSelectionVrf` | 合约打包节点处理 (读写) |
| `timer_mutex_` (TimerProcessor) | `mutex` | `time_value_` | ProcessingFunc, SetTimeValue |
| `dep_mutex_` (DependencyManager) | `mutex` | `contract_dep_cache_` | ProcessingFunc, RPC线程 |
| `msg_mutex_` (DependencyManager) | `mutex` | `contract_msg_cache_` | ProcessingFunc, RPC线程 |

### 3.2 锁依赖图 (潜在死锁分析)

```
RPC线程 (AddCache):
  contractCacheMutex -> doubleSpendMutex (via CheckConflict->Checker)
  transactionCacheMutex -> doubleSpendMutex (via CheckConflict->Checker)

打包线程 (processTransactionCacheFunc):
  transactionCacheMutex (长时间持有, 在 wait 和 build 期间)

ProcessContract (可能被多个线程调用):
  contractCacheMutex -> contractInfoCacheMutex -> dirtyContractMapMutex
```

**死锁风险评估**: **低** -- 锁获取顺序一致, 不存在循环依赖.
但 `transactionCacheMutex` 在 `processTransactionCacheFunc()` 中持有时间较长 (transaction_cache.cpp:404-449),
可能阻塞 RPC 线程的 `AddCache()`.

### 3.3 共享数据竞争分析

| 共享数据 | 访问模式 | 风险 | 说明 |
|----------|---------|------|------|
| `_transactionCache` | mutex 保护 | 低 | 正确的互斥访问 |
| `_contractCache` | mutex 保护 | 低 | 但 ProcessContract 使用 `scoped_lock` 同时持有多个锁 |
| `contractInfoCache` | shared_mutex | 低 | 读写锁粒度合理 |
| `_threadRun` | atomic | 低 | `std::atomic<bool>` |
| contractInfoCache 在 removeContractInfoCacheRequest | shared_lock 但 erase 了元素 | **高** | `removeContractInfoCacheRequest()` 使用 `shared_lock` 却调用了 `erase()` (见下文) |

---

## 4. 并发 Bug 分析

### 4.1 [严重] shared_lock 下修改容器

**位置**: `transaction_cache.cpp:1354-1370 (removeContractInfoCacheRequest)`

```cpp
bool TransactionCache::removeContractInfoCacheRequest(
    const std::map<std::string, CTransaction>& contractTxs)
{
    std::shared_lock<std::shared_mutex> locker(contractInfoCacheMutex);  // 应该是 unique_lock!
    auto it = contractInfoCache.begin();
    while (it != contractInfoCache.end()) 
    {
        if (contractTxs.find(it->first) != contractTxs.end()) 
        {
            it = contractInfoCache.erase(it); // modify container under shared_lock!
        }
        ...
    }
}
```

**分析**: `shared_lock` 是读锁, 不允许修改容器. 此处 `erase()` 是非线程安全的修改操作.
应使用 `std::unique_lock` 或 `std::lock_guard` 配合 exclusive lock.

**风险**: 高 -- 与 `addContractInfoToCache` (unique_lock write) 和 `get_contract_info_cache` (读) 并发时数据竞争.

**修复**: 将 `shared_lock` 改为 `unique_lock`.

### 4.2 [中] processTransactionCacheFunc 中长时间持锁

**位置**: `transaction_cache.cpp:397-452 (processTransactionCacheFunc)`

`transactionCacheMutex` 在 `wait()` 返回后持续持有, 直到 `BuildBlock()` 完成并 `clear()` 后才 `unlock()`.
`BuildBlock()` 内部涉及数据库查询和网络广播, 可能耗时数百毫秒.

**影响**: 在此期间 RPC 线程的 `AddCache()` (添加普通交易) 将被阻塞.

**修复**: 考虑在读缓存后尽快释放锁, 使用拷贝+解锁+构建的模式.

---

## 5. 线程数量评估

| 线程 | 数量 | 类型 |
|------|------|------|
| processTransactionCacheFunc | 1 | detach |
| CTimer (_buildTimer) | 1 (在主线程事件循环) | 回调 |
| doubleSpendCache CheckLoop | 1 (在 CTimer 事件循环) | 回调 |
| failedTransactionCache _Check | 1 (在 CTimer 事件循环) | 回调 |
| TimerProcessor ProcessingFunc | 1 | detach |
| TaskPool workers | N (线程池) | 线程池 |
| RPC 处理线程 | M (HTTP 服务器线程) | HTTP |

**总线程数**: 约 3 + N + M, 其中 N 为线程池大小, M 为 HTTP 处理线程数.

CTimer 回调 (包括 _buildTimer, CheckLoop, _Check) 通常运行在同一个事件循环线程中, 因此这些定时任务不会并发执行.

---

## 6. 线程安全改进建议

1. **修复** `removeContractInfoCacheRequest` 的 shared_lock 问题 (见 4.1)
2. **减少** `transactionCacheMutex` 持有时间 (见 4.2)
3. **考虑** 使用 lock-free 数据结构 (如 concurrent queue) 替代 mutex-protected vector
4. **统一** CTimer 中 `CheckLoop` 和 `_Check` 不在同一线程执行的问题 (当前没问题, 但需文档化)
