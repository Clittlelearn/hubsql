# 模块7: 交易池与特殊交易类型 - 重构建议

**可信度**: 中 (基于架构分析和最佳实践, 具体工时需团队协商)
**分析日期**: 2026-05-26

---

## 1. 重构优先级矩阵

| 优先级 | 建议 | 影响范围 | 风险 | 预估工时 |
|--------|------|---------|------|---------|
| **P0(紧急)** | 添加交易池容量和超时管理 | 高(安全) | 低 | 3天 |
| **P0(紧急)** | 修复 shared_lock 下修改容器 bug | 高(数据竞争) | 低 | 0.5天 |
| **P1(高)** | 拆分 ca/txhelper.cpp (138KB) | 中(可维护性) | 中 | 5天 |
| **P1(高)** | 拆分 TransactionCache (职责过重) | 中(可维护性) | 中 | 4天 |
| **P2(中)** | 统一双花检测逻辑 | 中(性能) | 中 | 2天 |
| **P2(中)** | 失败交易重试机制改进 | 中(可靠性) | 低 | 2天 |
| **P3(低)** | 清理废弃代码 | 低(代码整洁) | 极低 | 1天 |

---

## 2. P0 - 交易池 DoS 防护 (紧急)

### 2.1 问题

当前代码中交易池完全没有 DoS 防护:
- 无大小上限
- 无超时淘汰 (虽然定义了 `_kTxExpireInterval=10`)
- 无 Gas-price 排序
- 池中交易可无限积累

### 2.2 建议方案

```cpp
// 新增常量 (建议放入 global.h)
const size_t MAX_TX_POOL_SIZE = 100000;        // 池最大容量: 10万笔
const time_t TX_POOL_EXPIRE_TIME = 10;         // 10秒超时
const size_t MIN_GAS_PRICE = 1;                // 最低 Gas 价格

// 修改 TransactionCache::AddCache
int TransactionCache::AddCache(CTransaction& transaction, const TxMsgReq& msg)
{
    // 1. 检查池容量
    if (_transactionCache.size() >= MAX_TX_POOL_SIZE) {
        // 淘汰策略: 移除最旧/最低Gas的交易
        evictTransactions();
        if (_transactionCache.size() >= MAX_TX_POOL_SIZE) {
            return -3; // 池满, 拒绝
        }
    }
    
    // 2. 超时检查 (使用已定义的 _kTxExpireInterval)
    uint64_t now = TimeUtil::GetInstance()->GetUTCTimestamp();
    if (now - transaction.time() > _kTxExpireInterval * 1000000ull) {
        return -4; // 交易已超时
    }
    
    // 3. 原有逻辑...
}

// 新增淘汰方法
void TransactionCache::evictTransactions()
{
    // 方案A: 按时间排序, 淘汰最旧的
    std::sort(_transactionCache.begin(), _transactionCache.end(),
        [](const auto& a, const auto& b) {
            return a.GetTransaction().time() < b.GetTransaction().time();
        });
    // 移除前25%
    size_t removeCount = _transactionCache.size() / 4;
    _transactionCache.erase(_transactionCache.begin(),
        _transactionCache.begin() + removeCount);
}
```

### 2.3 额外建议

- 定期清理过期交易: 在 `processTransactionCacheFunc()` 中每次循环前先清理
- Gas-price 优先: 池满时保留高 Gas 价格的交易 (未来支持)

**预估工时**: 3天 (含单元测试)

---

## 3. P0 - 修复并发Bug (紧急)

### 3.1 问题

`removeContractInfoCacheRequest()` 使用 `shared_lock` (读锁) 却执行 `erase()` (写操作):

**位置**: `transaction_cache.cpp:1354-1370`

### 3.2 修复

```cpp
bool TransactionCache::removeContractInfoCacheRequest(
    const std::map<std::string, CTransaction>& contractTxs)
{
    std::unique_lock<std::shared_mutex> locker(contractInfoCacheMutex);
    //  ^^^^^^^^^^ 改为 unique_lock
    auto it = contractInfoCache.begin();
    while (it != contractInfoCache.end()) 
    {
        if (contractTxs.find(it->first) != contractTxs.end()) 
        {
            it = contractInfoCache.erase(it);
        } 
        else 
        {
            ++it;
        }
    }
    return true;
}
```

**预估工时**: 0.5 天 (修改 + 审查类似问题)

---

## 4. P1 - 拆分 txhelper.cpp (138KB)

### 4.1 现状

`ca/txhelper.cpp` (138.6KB) 是项目中最大的单文件, 承载:
- 签名管理 (Sign, Verify, addMultipleSigns)
- UTXO 查找 (FindUtxo, GetUtxoValue)
- Gas 计算 (GenerateGas, CalculateGas)
- 交易身份获取 (fetchIdentityNodes)
- 交易参数验证 (Check)
- VRF 类型选择 (getTransactionStartIdentity)
- 提案/投票信息处理
- 合约分发管理

### 4.2 拆分方案

```
ca/
├── txhelper/
│   ├── tx_helper.h/cpp          -- 主入口 (保持兼容)
│   ├── tx_sign.cpp/h            -- 签名管理 (~20KB)
│   ├── tx_utxo.cpp/h            -- UTXO 查找与验证 (~25KB)
│   ├── tx_gas.cpp/h             -- Gas 计算与验证 (~15KB)
│   ├── tx_identity.cpp/h        -- 打包节点身份获取 (~20KB)
│   ├── tx_proposal.cpp/h        -- 提案/投票信息 (~25KB)
│   ├── tx_contract.cpp/h        -- 合约分发管理 (~15KB)
│   └── tx_types.cpp/h           -- 交易类型/结构定义 (~10KB)
```

### 4.3 拆分策略

1. 提取公共接口到 `tx_helper.h`, 保持向后兼容的 using 声明
2. 按功能域创建独立的 .cpp/.h 对
3. 内部工具函数放入 anonymous namespace 或 detail 命名空间
4. 更新 CMakeLists.txt 添加新文件

**预估工时**: 5天 (含编译验证和回归测试)

---

## 5. P1 - 拆分 TransactionCache (职责过重)

### 5.1 现状

`TransactionCache` 单类承担: 交易池管理、合约执行、区块构建、网络消息处理、依赖解析.

### 5.2 拆分方案

```
ca/
├── tx_pool.h/cpp               -- 普通交易池 (从 TransactionCache 提取)
│   ├── AddCache, Evict, Size, Clear
│   ├── processTransactionCacheFunc (简化版)
│   └── 仅管理 _transactionCache
│
├── contract_tx_pool.h/cpp      -- 合约交易池 (从 TransactionCache 提取)
│   ├── AddContractCache, ProcessContract
│   ├── executeContracts
│   └── 管理 _contractCache + contractInfoCache + dirtyContractMap
│
├── contract_packager.h/cpp     -- 合约打包节点管理 (从 dispatchtx 整合)
│   ├── handleContractPackagerMessage
│   ├── ContractTransaction
│   └── VRF 选择逻辑
│
├── block_builder.h/cpp         -- 区块构建 (提取)
│   ├── CreateBlock
│   ├── BuildBlock
│   └── get_build_block_height
│
└── transaction_cache.h/cpp     -- 保留为 Facade, 委托给子组件
```

### 5.3 接口保持

```cpp
class TransactionCache {
public:
    // 委托方法 (保持现有 API 兼容)
    int AddCache(...) { return _txPool.AddCache(...); }
    bool Process() { return _txPool.Process(); }
    
private:
    TxPool _txPool;
    ContractTxPool _contractPool;
    BlockBuilder _blockBuilder;
};
```

**预估工时**: 4天 (含测试)

---

## 6. P2 - 统一双花检测

### 6.1 现状

存在两套独立且功能重叠的双花检测:
1. `Checker::CheckConflict()` (checker.cpp) -- 基于 UTXO 输入 hash 交集
2. `doubleSpendCache` (double_spend_cache.cpp) -- 基于地址+UTXO 消费状态

两者独立工作, 无协同, 增加了维护成本和潜在遗漏.

### 6.2 建议

统一为一个 `DoubleSpendGuard` 类:

```cpp
class DoubleSpendGuard {
public:
    // 检查交易是否与池中交易冲突 (基于UTXO)
    bool CheckConflict(const CTransaction& tx,
                       const std::vector<TransactionEntity>& pool);
    
    // 注册 UTXO 消费 (交易入池时调用)
    bool RegisterUtxoUsage(const std::string& addr,
                           const std::vector<std::string>& utxos,
                           uint64_t timestamp);
    
    // 清理已确认的 UTXO (区块确认后调用)
    void OnBlockConfirmed(const CBlock& block);
    
    // 定期清理超时的注册记录
    void CleanExpired();
};
```

**预估工时**: 2天

---

## 7. P2 - 失败交易重试机制改进

### 7.1 现状问题

| 问题 | 位置 |
|------|------|
| 重试时重新计算 hash 但未重新签名 | failed_transaction_cache.cpp:85-87 |
| `top > txHeight + 3` 硬编码 | failed_transaction_cache.cpp:71 |
| 无重试次数限制 | failed_transaction_cache.cpp 整体 |
| 无退避策略 | failed_transaction_cache.cpp 整体 |

### 7.2 建议

```cpp
struct FailedTxEntry {
    TxMsgReq msg;
    uint64_t firstFailHeight;
    uint64_t lastRetryTime;
    int retryCount;
    static const int MAX_RETRIES = 5;
    static const uint64_t RETRY_BACKOFF_BASE = 2 * 1000000; // 2秒基础退避
};

void failedTransactionCache::_Check()
{
    // ...
    for (auto& entry : _txPending) {
        // 检查重试次数
        if (entry.retryCount >= FailedTxEntry::MAX_RETRIES) {
            shouldDelete = true;
            break;
        }
        
        // 退避策略: 指数退避
        uint64_t backoffTime = RETRY_BACKOFF_BASE * (1 << entry.retryCount);
        if (now - entry.lastRetryTime < backoffTime) {
            continue; // 未到退避时间
        }
        
        entry.lastRetryTime = now;
        entry.retryCount++;
        
        // 重试时保持原 hash (不要重新计算)
        CTransaction tx;
        tx.ParseFromString(entry.msg.txmsginfo().tx());
        // 使用原 hash 和签名直接重试
        handleTransaction(msg, tx);
    }
}
```

**预估工时**: 2天

---

## 8. P3 - 清理废弃代码

### 8.1 需清理的文件

| 文件 | 原因 |
|------|------|
| `ca/contract_transaction_cache.cpp/h` | 完全被 #if 0 注释 (178行) |
| `ca/transaction/contract.cpp` | 被 #if 0 包围 (897行) |
| `ca/dispatchtx.cpp` (lines 449-860) | 大量注释掉的 Broadcast/Dependency 代码 (约411行) |
| `ca/transaction_cache.cpp` (lines 49-76) | 注释掉的 ClearContractDependency 函数 (约27行) |

### 8.2 建议

1. 确认废弃代码无恢复计划后, 直接从代码库删除
2. 将仍有参考价值的代码移至归档分支或文档
3. 确认 `contract.cpp` 的替代实现位置

**预估工时**: 1天

---

## 9. 工时汇总

| 类别 | 建议 | 工时 |
|------|------|------|
| **安全修复** | 交易池DoS防护 | 3天 |
| **安全修复** | shared_lock bug修复 | 0.5天 |
| **重构** | 拆分 txhelper.cpp | 5天 |
| **重构** | 拆分 TransactionCache | 4天 |
| **改进** | 统一双花检测 | 2天 |
| **改进** | 失败交易重试 | 2天 |
| **清理** | 废弃代码删除 | 1天 |
| **总计** | | **17.5 天** |

---

## 10. 实施建议

**阶段1 (第1周)**: 安全修复优先
- 交易池 DoS 防护 (P0)
- shared_lock bug 修复 (P0)

**阶段2 (第2周)**: 核心重构
- 拆分 txhelper.cpp (P1)
- 统一双花检测 (P2)

**阶段3 (第3周)**: 深度重构
- 拆分 TransactionCache (P1)
- 失败交易重试改进 (P2)

**阶段4**: 清理收尾
- 废弃代码删除 (P3)
- 编写单元测试覆盖

### 10.1 测试覆盖建议

| 模块 | 测试场景 |
|------|---------|
| 交易池容量 | 填充超限 -> 淘汰旧交易 -> 新交易入池 |
| 交易超时 | 创建过期交易 -> AddCache 拒绝 |
| 双花检测 | 同一UTXO两笔交易 -> 第二笔拒绝 |
| 失败重试 | 注入失败 -> 验证退避策略 -> 验证最大重试次数 |
| 合约依赖分组 | 多笔关联合约交易 -> 验证合并到同组 |
