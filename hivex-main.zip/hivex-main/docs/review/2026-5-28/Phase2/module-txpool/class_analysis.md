# 模块7: 交易池与特殊交易类型 - 类体系分析

**可信度**: 高 (基于源码直接分析)
**分析日期**: 2026-05-26

---

## 1. 交易池核心类

### 1.1 TransactionCache (transaction_cache.h:35)

**职责**: 交易池的核心管理类, 负责交易的接收、分类存储、定时打包。

**成员变量**:
| 字段 | 类型 | 说明 |
|------|------|------|
| `_transactionCache` | `vector<TransactionEntity>` | 普通交易缓存 (transaction_cache.h:42) |
| `_contractCache` | `vector<TransactionEntity>` | 合约交易缓存 (transaction_cache.h:49) |
| `transactionCacheMutex` | `mutex` | 普通交易缓存锁 (transaction_cache.h:47) |
| `contractCacheMutex` | `mutex` | 合约交易缓存锁 (transaction_cache.h:51) |
| `_buildTimer` | `CTimer` | 定时打包触发器 (transaction_cache.h:56) |
| `transactionCacheBuildThread` | `thread` | 打包执行线程 (transaction_cache.h:58) |
| `contractInfoCache` | `map<string, pair<json, uint64>>` | 合约执行结果缓存 (transaction_cache.h:66) |
| `contractInfoCacheMutex` | `shared_mutex` | 合约信息缓存读写锁 (transaction_cache.h:68) |
| `dirtyContractMap` | `map<string, pair<uint64, set<string>>>` | 合约脏数据映射, 含时间戳自动清理 (transaction_cache.h:71) |
| `_contractPackagerSelectionVrf` | `string` | 合约打包者 VRF 选择证明 (transaction_cache.h:76) |

**关键方法**:
| 方法 | 返回值 | 说明 |
|------|--------|------|
| `AddCache(tx, msg)` | int | 入池, 0=成功, -1=合约双花, -2=普通双花 (transaction_cache.cpp:245) |
| `Process()` | bool | 启动打包线程, detach 模式 (transaction_cache.cpp:282) |
| `processTransactionCacheFunc()` | void | 打包主循环: 等待信号->构建区块->清除缓存 (transaction_cache.cpp:397) |
| `ProcessContract(topHeight)` | void | 合约交易打包 (transaction_cache.cpp:454) |
| `handleContractPackagerMessage(msg)` | int | 处理合约打包节点消息 (transaction_cache.cpp:976) |
| `executeContracts(map)` | pair<int,string> | 并行执行依赖组合约交易 (transaction_cache.cpp:526) |
| `ContractTransaction(msgs)` | int | 分组执行合约交易+依赖解析 (transaction_cache.cpp:1089) |

**类常量**:
```cpp
BUILD_INTERVAL = 3000;        // 3秒 (transaction_cache.cpp:78)
_kTxExpireInterval = 10;     // 10秒, 但未使用 (transaction_cache.cpp:79)
BUILD_THRESHOLD = 1000000;   // 100万笔触发 (transaction_cache.cpp:80)
```

**架构评价**:
- 类职责过重 (God Class 反模式): 同时管理普通交易、合约交易、合约预执行、依赖解析、网络消息
- 锁粒度合理: 普通池和合约池分开加锁, 合约信息缓存使用 shared_mutex
- **致命缺陷**: `_kTxExpireInterval` 定义了但从未在任何清理逻辑中使用

---

### 1.2 Checker (checker.cpp)

**职责**: 交易/区块冲突检测(双花检查核心逻辑)

**重要方法**:
```cpp
// checker.cpp:97-143 [核心]
// 冲突判定逻辑: 提取tx1和tx2的UTXO输入集合
// (prevout.hash + "_" + pub + "_" + currency)
// 取交集, 非空即冲突
bool CheckConflict(const CTransaction &tx1, const CTransaction &tx2);

// checker.cpp:145-177 [区块内双花检测]
// 遍历区块内所有交易的UTXO, 按 utxo_key 分组
// 每组 >1 笔即判定双花 (UNSTAKE/UNDELEGATE/UNLOCK 豁免)
void CheckConflict(const CBlock &block, vector<CTransaction> &doubles);
```

**双花检测豁免**: checker.cpp:159 -- UNSTAKE/UNDELEGATE/UNLOCK 类型即使输入相同 UTXO 也不判双花 (因为这些交易消费的是虚拟地址的 UTXO, 例如 VirtualStake)

---

### 1.3 doubleSpendCache (double_spend_cache.h:17)

**职责**: 基于地址的 UTXO 消费状态追踪, 防止同一地址的 UTXO 被同时消费.

**数据结构**:
```cpp
struct doubleSpendSuccess {
    uint64_t time;
    vector<string> utxoVector;  // 正在使用的UTXO哈希列表
};
map<string, doubleSpendSuccess> _pending;  // key=address (double_spend_cache.h:65)
```

**关键方法**:
| 方法 | 说明 |
|------|------|
| `AddFromAddr(pair)` | 添加地址的消费记录, 使用 set_intersection 检测冲突 (double_spend_cache.cpp:3) |
| `CheckLoop()` | 1秒定时清理: 30秒超时的记录移除 (double_spend_cache.cpp:50) |
| `Detection(block)` | 区块确认后移除对应地址的记录 (double_spend_cache.cpp:72) |
| `Remove(txTimeKey)` | 按时间键删除 (double_spend_cache.cpp:33) |

**线程安全**: 使用 `mutex doubleSpendMutex` (double_spend_cache.h:64), 但是**注意** CheckLoop 中 `kTenSecond=30秒` (double_spend_cache.cpp:56) -- 变量名与实际值不符 (以代码注释为准).

---

### 1.4 failedTransactionCache (failed_transaction_cache.h:25)

**职责**: 缓存因网络高度不满足而失败的交易, 定时重试.

**存储**: `map<uint64_t, vector<TxMsgReq>> _txPending` (failed_transaction_cache.h:72) -- key 为节点高度.

**重试逻辑** (failed_transaction_cache.cpp:33-121):
1. 每 2 秒触发 (failed_transaction_cache.cpp:12: `AsyncLoop(2*1000)`)
2. 检查 75% 网络节点是否达到交易高度
3. 若 `top > txHeight + 3` (已过 3 个块高度) 则丢弃
4. 合格者提交到 TaskPool 异步重试

**问题清单**:
- [failed_transaction_cache.cpp:71] **风险-中**: `top > txHeight + 3` 硬编码, 不可配置. 快速出块网络中可能过早丢弃.
- [failed_transaction_cache.cpp:80-95] **风险-中**: 重试时重新计算 hash (`tx.set_hash(Getsha256Hash(...))`), 但没有重新签名 -- 如果原交易有签名? hash 改变后旧签名将失效.

---

### 1.5 ContractTransactionCache (contract_transaction_cache.h) -- 已废弃

**状态**: **完全废弃**. 整个 `.h` 和 `.cpp` 文件内容被 `#if 0` 包围 (共约 178 行).

**原设计意图**:
- 缓存发送失败的合约交易 (contract_transaction_cache.h:27 注释)
- 1 秒定时检查 (CHECK_INTERVAL)
- 15 秒超时强制发送 (FORCE_SEND_TIMEOUT)
- 依赖 `DependencyManager::CanSendTransaction()` 检查

**废弃原因分析**: 依赖的 `DependencyManager::CanSendTransaction()` 在 dispatchtx.cpp 中也已被注释. 合约交易的依赖管理方案可能经过了重构, 新方案直接通过 VRF 选择打包节点 + `packDispatch` 的 `DependencyData` 完成.

---

## 2. 交易分发类

### 2.1 DependencyManager (dispatchtx.h:55)

**职责**: 管理合约交易间的依赖关系, 使用并查集 (Union-Find) 分组.

**核心数据结构**:
```cpp
unordered_map<string, vector<string>> contract_dep_cache_;  // txHash -> 依赖合约地址列表
unordered_map<string, TxMsgReq> contract_msg_cache_;         // txHash -> 交易消息
```

**核心算法** (dispatchtx.cpp:113-177):
```
GetDependentData():
  1. 快照 dep_cache + msg_cache
  2. 构建并查集 (Union-Find): 共享依赖地址的交易合并为同一组
  3. 按 root 分组, 组内按 txHash 排序
  4. 返回 vector<vector<TxMsgReq>>
```

**GroupData** (dispatchtx.cpp:179-208): 将分组结果均匀分配到最多 8 个子组 (PARTS=8) 以并行投递.

---

### 2.2 MessageDispatcher (dispatchtx.h:98)

**职责**: 为每组合约交易选择 VRV 打包节点并发送.

**核心方法**:
- `DistributionContractTransactionRequest()`: 对每组交易通过 `FindContractPackNode` 选择打包节点 (dispatchtx.cpp:220)
- `SendTransactionInfoRequest()`: 构造 `ContractPackagerMsg`, 带 VRF 选择证明, 发送到目标节点 (dispatchtx.cpp:260)

---

### 2.3 TimerProcessor (dispatchtx.h:109)

**职责**: 定时触发合约交易的分发流程.

**核心参数** (dispatchtx.h:123):
```cpp
kContractWaitingTime = 3 * 1000000ULL;  // 3秒等待时间
```
实际逻辑 (dispatchtx.cpp:373-441):
1. 每秒 tick, time_value_ += 1000000
2. 累计达到 3 秒后触发 GetDependentData + GroupData + 分发
3. 分发后清除缓存、重置计时器

---

## 3. 交易类型处理器类

### 3.1 类继承体系

所有特殊交易处理器继承自 `mmc::UtxoCore` (transaction/utxo_core.h):

```
mmc::UtxoCore (虚基类)
├── StakeTrans      (transaction/stake.h)
├── UnStake         (transaction/unstake.h)
├── DelegatingTrans (transaction/delegating.h)
├── UndelegatingTrans (transaction/undelegating.h)
├── LockTrans       (transaction/lock.h)
├── UnlockTrans     (transaction/unlock.h)
├── VoteTrans       (transaction/vote.h)
├── BonusTrans      (transaction/bonus.h)
└── FundTrans       (transaction/fund.h)
```

### 3.2 各处理器的统一接口

每个处理器必须实现以下虚函数:

| 方法 | 说明 |
|------|------|
| `trans()` | 交易构造主逻辑 |
| `goMessage()` | 交易发送/广播 |
| `makeTxInfor(CTx*)` | 设置交易元数据 (data/nonce) |
| `checkParams()` | 参数合法性检查 |
| `getGasValue(CTxUtxos*,int)` | Gas 计算 |

### 3.3 关键差异

| 处理器 | 特殊逻辑 | 文件:行号 |
|--------|---------|----------|
| **StakeTrans** | `checkParams()` 检查是否已质押 (`isStaked`), 验证佣金率 (5%-35%) | stake.cpp:157-177 |
| **UnStake** | `trans()` 需确认 500 块 (`MIN_UNSTAKE_HEIGHT`) 已过, 通过 `IsQualifiedToUnstake` 验证 | unstake.cpp:39-48 |
| **DelegatingTrans** | `trans()` 需 `CheckDelegatingQualification`, 最小委托量 `kMinDelegatingAmt` = 500MM | delegating.cpp:60-72 |
| **UndelegatingTrans** | 使用 `IsQualifiedToUndelegating` 验证 | undelegating.cpp:62-65 |
| **LockTrans** | 锁定 `Vote` 资产到 `VIRTUAL_LOCK_ADDRESS`, 检查重复锁定 (`getLockAddrUtxo`) | lock.cpp:56-61 |
| **UnlockTrans** | 需 `IsQualifiedToUnLock` | unlock.cpp:40-45 |
| **VoteTrans** | 通过 `GetLockValue` 获取投票权重, 用 `CheckVoteTxInfo` 验证投票信息 | vote.cpp:51-65 |
| **BonusTrans** | `CalcBonusValue` 计算奖励, `GetCommissionPercentage` 获取佣金率 | bonus.cpp:70-124 |
| **FundTrans** | `CheckFundQualificationAndGetRewardAmount`, 按锁定比例 + 打包比例分配国库 | fund.cpp:75-173 |

---

## 4. TransactionEntity (transaction_entity.h:17)

**职责**: 交易池中的交易实体封装.

**成员**:
| 字段 | 类型 | 说明 |
|------|------|------|
| `_msg` | `TxMsgReq` | 网络消息信息 |
| `_transaction` | `CTransaction` | 交易内容 |
| `txUtxoHeight_1` | `uint64_t` | UTXO 高度 |
| `_height` | `uint64_t` | 节点高度 |
| `_executedBefore` | `bool` | 是否已执行 |

**两个构造函数** (transaction_entity.h:27-30):
- 构造函数1: 接收 `TxMsgReq` + `CTransaction` (用于从网络接收的交易)
- 构造函数2: 仅接收 `CTransaction` (用于本地构造的交易, 不含 msg)

---

## 5. TxHelper (txhelper.h, 138KB)

**职责**: 交易构造的工具类, 提供签名、UTXO查找、身份获取等核心功能.

**关键结构体**:
| 结构体 | 说明 |
|--------|------|
| `ProposalInfo` | 提案信息 (txhelper.h:38) |
| `VoteInfo` | 投票信息 (txhelper.h:71) |
| `Utxo` | UTXO 查找结果 (txhelper.h:87) |
| `TransTable` | 交易转账表 (txhelper.h:95) |

**问题**: 138KB 的 `txhelper.cpp` 是项目中最大的单文件, 承载过多职责, 需要拆分 (见 refactor_suggestion.md).

---

## 6. 类间依赖关系

```
RPC Layer
   │
   ▼
handleTransaction()  ──→  TransactionCache::AddCache()
   │                            │
   │                  ┌─────────┴─────────┐
   │                  ▼                   ▼
   │         普通交易(_txnCache)    合约交易(_contractCache)
   │                  │                   │
   │                  ▼                   ▼
   │         processTxCacheFunc()   ProcessContract()
   │                  │                   │
   │                  ▼                   ▼
   │            BuildBlock()        handleContractPackagerMsg()
   │                  │                   │
   └──────────────────┴───────────────────┘
                      │
                      ▼
              BlockHelper (区块存储)
```

---

## 7. 类设计问题总结

| 问题 | 位置 | 严重度 | 建议 |
|------|------|--------|------|
| TransactionCache 职责过重 | transaction_cache.h:35 | 中 | 拆分为 TxPool, ContractTxPool, ContractExecutor |
| ContractTransactionCache 已废弃但未清理 | contract_transaction_cache.h | 低 | 移出代码库 |
| contract.cpp 被 #if 0 废弃 | contract.cpp:1 | 低 | 移出代码库或恢复 |
| TxHelper 超大文件 (138KB) | txhelper.cpp | 高 | 按交易类型拆分为多个文件 |
| CheckConflict 和 doubleSpendCache 功能重叠 | checker.cpp + double_spend_cache.cpp | 中 | 统一双花检测逻辑 |
| 部分交易类型无处理器 (DECLARATION/PROPOSAL/REVOKEPROPOSAL) | -- | 中 | 【需人工验证】确认是否已实现 |
