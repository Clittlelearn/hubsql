# 模块5: EVM集成与合约执行 -- 线程模型

## 1. 线程架构概览

```
┌──────────────────────────────────────────────────────────┐
│                     RPC + 网络消息线程                      │
│  (httplib: 每请求一线程 / P2P epoll事件处理)               │
├──────────────────────────────────────────────────────────┤
│  合约交易处理线程 (ca/contract.cpp)                        │
│  ├── execute_by_evmone: std::async 异步执行EVM (10s超时)   │
│  ├── VerifyContractBaseFee: 无额外线程                     │
│  └── transactionFillings/GetStorage: 单线程DB+/MPT操作     │
├──────────────────────────────────────────────────────────┤
│  TimerProcessor 线程 (dispatchtx.cpp)                     │
│  └── ProcessingFunc: 合约依赖分组与分发                     │
├──────────────────────────────────────────────────────────┤
│  [已注释] ContractTransactionCache 定时器线程              │
│  └── _CheckCachedTransactions: 1秒定时检查(未启用)          │
└──────────────────────────────────────────────────────────┘
```

---

## 2. 各组件线程安全性分析

### 2.1 EvmHost

**状态**: 线程不安全(设计为单线程使用)

**证据**:
- `evm_host.h:19` 注释明确说明: "Due to the Ethereum Virtual Machine (EVM) requiring access to most of variables within the host during contract deployment, setting these variables to private may cause the deployment to fail. To avoid this, member variables are temporarily set to public, and proper access control should be implemented in future versions."
- 所有成员变量为public/mutable, 无任何锁保护
- 通过`const_cast`修改mutable成员 (`evm_host.cpp:118-119, 254-255`)

**风险**: 若多个线程同时操作同一EvmHost实例, 会发生数据竞争。

**当前使用模式**: 每个合约交易创建独立的EvmHost实例, 在单个请求处理线程中使用, 因此实际不存在并发问题。

### 2.2 contractDataContainer (`trie.h:45-73`)

**线程安全**: 部分安全(使用shared_mutex)

```cpp
void set(const nlohmann::json& jStorage) {
    std::unique_lock<std::shared_mutex> lck(contractDataMapMutex_);
    // ...批量写入
}

bool get(const std::string& key, std::string& value) {
    std::shared_lock<std::shared_mutex> lck(contractDataMapMutex_);
    // ...读取
}
```

- **写入**: exclusive lock (unique_lock) -- 线程安全
- **读取**: shared lock (shared_lock) -- 多读并发安全

**风险**: 低。锁粒度合理。

### 2.3 Trie (MPT)

**线程安全**: 不安全(无锁)

**证据**:
- `trie.h:152-153`: `mutable nodePtr root;` 无锁保护
- `trie.h:154`: `std::map<std::string, std::string> dirtyHash;` 无锁保护
- `trie.h:155`: `mutable contractDataContainer* contractDataStorage;` 指向外部同步容器

**风险**: Trie本身无并发控制。如果在多线程中共享同一Trie实例, `Get`/`Update`/`Save`操作都会产生数据竞争。

**当前使用模式**: 每个EvmHost的accounts中每个合约有独立Trie实例, 在单请求线程中操作, 理论上安全。

### 2.4 DependencyManager (`dispatchtx.h:55-96`)

**线程安全**: 部分安全(使用mutex)

```cpp
std::unordered_map<string, vector<string>> contract_dep_cache_;
std::unordered_map<string, TxMsgReq> contract_msg_cache_;
mutable std::mutex dep_mutex_;
mutable std::mutex msg_mutex_;
```

- `AddContractInfo()`: `unique_lock<mutex>(dep_mutex_)` (`dispatchtx.cpp:88`)
- `AddMessageRequest()`: `unique_lock<mutex>(msg_mutex_)` (`dispatchtx.cpp:97`)
- `AddContractRequest()`: `scoped_lock(dep_mutex_, msg_mutex_)` (`dispatchtx.cpp:103`)
- `GetDependentData()`: `scoped_lock(dep_mutex_, msg_mutex_)` (`dispatchtx.cpp:119`)

**评估**: 使用`std::scoped_lock`同时锁两个mutex, 避免死锁。线程安全。可信度高。

### 2.5 TimerProcessor (`dispatchtx.h:109-124`)

**设计**: 独立的timer线程

```cpp
void ProcessingFunc() {
    while (running_) {
        std::unique_lock<std::mutex> lock(timer_mutex_);
        timer_cv_.wait_for(lock, std::chrono::microseconds(kContractWaitingTime));
        // 处理...
    }
}
```

`kContractWaitingTime = 3 * 1000000ULL` (3秒)

**线程安全**: 使用condition_variable, 标准线程间通信模式。

### 2.6 ContractTransactionCache (已注释)

**状态**: 全部注释, 不参与运行

设计上使用`shared_mutex`保护`_cachedTransactions`, 1秒定时器检查。因全部注释无法评估实际线程安全性。

### 2.7 execute_by_evmone (`contract.cpp:72-132`)

**异步执行模型**:

```cpp
auto async_execute = [&vm](EvmHost& host, evmc_revision rev, 
    const evmc_message& msg, const uint8_t* code, size_t code_size) {
    return vm.execute(host, rev, msg, code, code_size);
};

std::future<evmc::Result> futureResult = std::async(
    std::launch::async, async_execute, std::ref(host), ...);

std::future_status status = futureResult.wait_for(std::chrono::seconds(10));
if (status == std::future_status::timeout) {
    ERRORLOG("Evmone execution failed timeout!");
    return -3;
}
```

**分析**:
- EVM执行在`std::async`创建的独立线程中运行
- 主线程等待最多10秒
- 超时后直接返回-3, **但EVM线程可能仍在运行**(std::future析构不强制终止)

**风险**:
1. **Critical**: 超时后若EVM线程仍在修改EvmHost, 而主线程已开始读取host.output等字段, 存在数据竞争
2. **Medium**: std::async线程无法被强制终止, 超时后持续占用CPU

**缓解**: 当前10秒超时足够长, 正常合约不会超时。但恶意合约(无限循环)会触发此问题。

---

## 3. MPT访问的并发控制

### 3.1 读写模式

| 操作 | 线程上下文 | 锁保护 |
|------|-----------|--------|
| `Trie::Get()` | 请求处理线程 | 无(Trie内部无锁) |
| `Trie::Update()` | 请求处理线程 | 无 |
| `Trie::Save()` | 请求处理线程 | 无 |
| `contractDataContainer::get()` | 请求处理线程 | shared_lock |
| `contractDataContainer::set()` | 请求处理线程 | unique_lock |
| `DBReader::getMptValueByMptKey()` | 请求处理线程 | RocksDB内部锁 |
| `DBReadWriter::setMptValueByMptKey()` | 请求处理线程 | RocksDB事务锁 |

### 3.2 并发安全总结

当前架构下MPT的并发安全依赖以下前提:
1. 每个合约交易创建独立的EvmHost和Trie
2. 每个请求在单个线程中处理
3. 对同一合约地址的并发请求通过UTXO模型的事务隔离保证(RocksDB TransactionDB)

**结论**: 在正确的使用模式下安全, 但缺乏显式的并发保护机制。如果未来引入对同一合约的并行处理, 需要为Trie添加锁机制。

---

## 4. 已知线程安全问题清单

### 问题1: execute_by_evmone超时后的数据竞争

- **位置**: `contract.cpp:89-103`
- **现象**: 超时返回后, std::async线程可能仍在运行, 与主线程竞争访问EvmHost成员
- **风险等级**: High
- **触发场景**: 恶意合约或计算密集型合约执行超过10秒
- **修复建议**: 使用可中断的执行机制, 或使用`std::jthread`+`stop_token`(C++20), 或使用进程隔离
- **验证方法**: 部署一个无限循环合约, 观察超时后host.output的行为

### 问题2: Trie无并发保护

- **位置**: `mpt/trie.h:152-155` (public成员无锁)
- **现象**: root/dirtyHash/contractDataStorage无任何锁保护
- **风险等级**: Medium
- **触发场景**: 多线程共享同一Trie实例
- **修复建议**: 为Trie添加mutex或使用不可变数据结构
- **验证方法**: ThreadSanitizer检测

### 问题3: const_cast修改EvmHost

- **位置**: `evm_host.cpp:118-119` (`const_cast<EvmHost*>(this)`)
- **现象**: get_storage/get_balance等const方法中修改usedInfo/dbSpendMap等mutable成员
- **风险等级**: Low
- **触发场景**: 多个const方法被并发调用
- **修复建议**: 将统计成员声明为mutable, 使用原子类型(std::atomic)保护
- **验证方法**: 代码审查确认, 当前为单线程使用

### 问题4: contractDataStorage指针无生命周期管理

- **位置**: `trie.h:155` `mutable contractDataContainer* contractDataStorage;`
- **现象**: 裸指针, 无shared_ptr/weak_ptr保护
- **风险等级**: Medium
- **触发场景**: contractDataContainer先于Trie析构
- **修复建议**: 使用`std::shared_ptr<contractDataContainer>`或`std::weak_ptr`
- **验证方法**: ASan(AddressSanitizer)检测use-after-free
