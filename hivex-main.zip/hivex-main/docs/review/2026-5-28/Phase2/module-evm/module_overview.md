# 模块5: EVM集成与合约执行 -- 模块概览

## 1. 架构概览

MeMeChain集成evmone作为EVM执行引擎，遵循EVMC (Ethereum Virtual Machine Connector) C接口。核心桥接组件是`EvmHost`(继承`evmc::Host`)，负责将UTXO模型的世界状态适配为EVM所需的账户模型。

```
RPC层 ──> ca/contract.cpp (DeployContract/CallContract)
              │
              v
         ca/evm/evmEnvironment.cpp (准备EVM上下文)
              │
              v
         ca/evm/evm_host.cpp (EvmHost: 适配UTXO→账户模型)
              │
              v
         evmone VM (EVM字节码执行)
              │
              v
         预编译合约 (precompiles.cpp / silkpre)
              │
              v
         mpt/trie.cpp (合约状态持久化, SHA256哈希)
```

**关键文件清单**:

| 层级 | 文件 | 大小 | 职责 |
|------|------|------|------|
| EVM核心 | `ca/evm/evm_host.cpp/h` | 22KB/5KB | evmc::Host接口实现 |
| EVM核心 | `ca/evm/evm_host_data.hpp` | 4KB | StateAccount/StorageValue定义 |
| EVM核心 | `ca/evm/evm_manager.cpp/h` | 5KB/2KB | evmone实例化与合约保存 |
| EVM核心 | `ca/evm/evmEnvironment.cpp/h` | 13KB/2KB | 交易消息和环境上下文构建 |
| 合约入口 | `ca/contract.cpp/h` | 56KB/9KB | DeployContract/CallContract主流程 |
| 合约入口 | `ca/eth_trans.cpp/h` | 13KB/1KB | ETH交易RLP解码和签名验证 |
| 预编译 | `contract/precompiles.cpp/hpp` | 9KB/1KB | 9个标准EVM预编译Gas计算 |
| 预编译 | `contract/precompiles_silkpre.cpp/hpp` | 3KB/1KB | 通过SilkPre库实际执行预编译 |
| 预编译 | `contract/precompiles_cache.cpp/hpp` | 3KB/1KB | 预编译结果Keccak256缓存 |
| 哈希 | `contract/hash_utils.cpp/hpp` | 1KB/1KB | Keccak256工具封装 |
| 错误 | `contract/contract_error.h` | 1KB | 合约错误码定义(大部分已注释) |
| MPT | `mpt/trie.cpp/h` | 15KB/4KB | Merkle Patricia Trie(合约状态) |
| MPT | `mpt/rlp.cpp/h` | 12KB/21KB | RLP编解码(Aleth移植) |
| MPT | `mpt/node.h` | 2KB | HashNode/ValueNode/ShortNode/FullNode |
| MPT | `mpt/common.cpp/h` | 3KB/11KB | MPT通用定义与SHA256哈希 |
| 分发 | `ca/dispatchtx.cpp/h` | 38KB/5KB | 合约交易依赖管理与分组分发 |
| 缓存 | `ca/contract_transaction_cache.cpp/h` | 7KB/3KB | 合约交易缓存(全部注释,未启用) |
| Gas | `ca/fee_calculator.h` | 6KB | EIP-1559动态基础费用计算 |
| 交易构造 | `ca/transaction/contract.cpp/h` | 30KB/3KB | 合约交易构造(contract.h全在#if 0) |
| RLP | `mpt/rlp.h` | 21KB | 包含`handleEthSendRawTransaction`声明 |

---

## 2. evmone与EvmHost的桥接关系

```
evmone (EVM执行引擎)
  │
  │ execute(host, revision, message, code, code_size)
  ▼
EvmHost : public evmc::Host
  │
  ├── account_exists()    → accounts map 查找
  ├── get_storage()       → accounts[addr].storage + MPT查询
  ├── set_storage()       → accounts[addr].storage赋值 + MPT.Update()
  ├── get_balance()       → UTXO余额查询(get_balance_by_utxo)
  ├── get_code_size()     → accounts[addr].code.size()
  ├── get_code_hash()     → accounts[addr].codehash (Keccak256)
  ├── copy_code()         → accounts[addr].code复制
  ├── selfdestruct()      → coinTransfersInProgress + recorded_selfdestructs
  ├── call()              → 预编译/合约代码加载/嵌套EVM执行
  ├── get_tx_context()    → tx_context (chainId/gasPrice/timestamp等)
  ├── get_block_hash()    → block_hash
  ├── emit_log()          → recorded_logs
  ├── access_account()    → EIP-2929 warm/cold访问追踪
  └── access_storage()    → EIP-2929 storage访问追踪
```

**核心桥接机制** (`evm_host.cpp:366-530`):

1. `call()`方法处理所有合约间调用(CALL/CALLCODE/DELEGATECALL/STATICCALL/CREATE/CREATE2)
2. 预编译优先(`evmone::state::call_precompile`)，命中后直接返回
3. 创建(CREATE/CREATE2)通过`createContract()`执行初始化代码
4. 调用(CALL)通过`fetchContractRootHash`加载MPT状态，再创建嵌套VM执行
5. 嵌套VM为每次`call()`创建新的`evmone` VM实例(`evm_host.cpp:507`)

---

## 3. 规范实现对照表

| 功能点 | 规范定义(spec_dev.md) | 当前实现 | 偏差原因 | 可信度 |
|--------|----------------------|---------|---------|--------|
| **合约地址生成** | 7.5.1节: EIP-161标准, Keccak256(RLP([sender,nonce]))取后20字节 | `evm_host.cpp:419-420` 调用`GenerateContractAddrEth`; `evm_manager.cpp:77` 同样调用 | 符合规范, 使用Keccak256+RLP标准流程 | 高 |
| **EIP-55校验和** | 2.4节: Keccak256哈希校验和 | `ToChecksumAddress()`实现存在 | 已实现校验和地址转换 | 高 |
| **EvmHost接口** | 7.4节: 8个方法 | `evm_host.h:33-137` 实现全部8个+ EIP-2929 access_account/storage + transient storage | 完整覆盖, 且增加了EIP-2929访问列表支持 | 高 |
| **预编译合约** | 7.7节: ecrecover(0x01)~blake2bf(0x09) | `precompiles.cpp:164-186` traits表9项; 实际执行由`precompiles_silkpre.cpp`通过SilkPre库提供 | 规范中的silkpre自定义预编译已集成; `identity`(0x04)有实际执行, 其余通过silkpre | 高 |
| **预编译Gas计算** | 7.7节: TODO未定义完整Gas表 | `precompiles.cpp` 各analyze函数定义了完整的Gas计算(如sha256=60+12*word) | 实现比规范更完整, 遵循以太坊EIP标准 | 高 |
| **MPT哈希函数** | 8.7.9节: SHA256(非Keccak256) | `trie.cpp:429` `Getsha256Hash(stringData)` | 使用SHA256, 与以太坊Keccak256不兼容 | 高 |
| **MPT终止符** | 8.7.6节: 使用'z'字符 | `trie.cpp:17-19` `wrapperKey`追加末尾字符+'z' | 与以太坊使用hex prefix(HP)编码不同 | 高 |
| **Gas计算** | 11.5.2节: UTXO基础Gas | `fee_calculator.h` EIP-1559动态调整; `contract.cpp:708` VerifyContractBaseFee | 基础Gas用UTXO计算, 动态基础费用用EIP-1559公式. 规范未描述EIP-1559部分 | 中 |
| **Gas限额** | 11.5.1节: MAX_GAS_LIMIT=120000 | `contract.cpp:710` `gasCost > KTargetGasPrice * 2` | 符合规范 | 高 |
| **INITIAL_BASE_FEE** | 11.5.1节: 10 | `contract.cpp:715` `old_baseFee = "10"` | 符合规范 | 高 |
| **依赖管理** | 7.6.5节: DependencyManager | `dispatchtx.cpp:87-176` DependencyManager通过并查集分组 | 实现符合规范, CanSendTransaction已注释 | 中 |
| **ContractTransactionCache** | 7.6.5节: 1秒定时器, 15秒强制发送 | `contract_transaction_cache.cpp/h` 全部代码被注释 | 功能未启用, 可能因存在bug或重构中【需人工验证】 | 高 |
| **ETH交易兼容** | 无明确规范 | `eth_trans.cpp` 支持Legacy和EIP-1559交易RLP解析 | 实现了eth_sendRawTransaction兼容层 | 高 |
| **CREATE2** | 7.6.3节: sender+salt+initCodeHash | `evm_host.cpp:623-652` 实现完整CREATE2地址计算 | 符合以太坊标准 | 高 |
| **block_prev_randao** | 7.3节: TODO需确认 | `evmEnvironment.cpp:297-316` 使用UTXO哈希拼接转数字 | 与以太坊RANDAO语义完全不同, 仅用于测试【需人工验证】 | 低 |
| **EVM执行超时** | 无规范定义 | `contract.cpp:96` `wait_for(10秒)` | 防御性超时保护, 合理但无规范依据 | 高 |
| **自毁(SELFDESTRUCT)** | 无明确规范 | `evm_host.cpp:336-363` 支持, 余额转移+记录 | 实现了EIP-6049之前的SELFDESTRUCT语义 | 中 |

---

## 4. 模块关键特征总结

### 4.1 已实现且活跃的功能
- evmone集成(通过EVMC, 支持MAX_REVISION)
- 9个预编译合约(silkpre实际执行, Gas计算完整)
- 预编译结果缓存(Keccak256输入哈希, 内存缓存)
- CREATE/CREATE2合约部署
- CALL/DELEGATECALL合约调用
- EIP-2929访问列表(cold/warm区分)
- 合约状态MPT持久化(但使用SHA256)
- ETH交易RLP解码与签名验证
- EIP-1559动态基础费用
- 合约依赖分组分发(并查集)
- EVM执行10秒超时保护
- 账户存在性检查(缓存预热机制)
- 自毁检测与调用拦截

### 4.2 已注释/未启用功能
- `ContractTransactionCache` -- 全部注释(`contract_transaction_cache.h:1-96`, `.cpp:1-177`)
- `transaction/contract.h` -- 全部在`#if 0`内
- `DependencyManager::CanSendTransaction` -- 已注释
- `contract_error.h` -- 大部分宏被注释

### 4.3 关键风险点
1. **MPT SHA256 vs Keccak256**: 状态根哈希与以太坊不兼容, 跨链验证不可行
2. **线程安全**: EvmHost通过`const_cast`访问mutable成员, `contractDataContainer`使用shared_mutex但Trie内部无锁
3. **确定性**: block_prev_randao使用UTXO哈希拼接, 可能非确定性【需人工验证】
4. **合约地址冲突**: nonceCache为本地增量, 依赖`GetNextNonce`从DB读取, 但过程中如果并发部署可能nonce重复【需人工验证】
