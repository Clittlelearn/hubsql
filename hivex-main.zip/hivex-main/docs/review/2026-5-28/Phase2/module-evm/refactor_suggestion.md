# 模块5: EVM集成与合约执行 -- 重构建议

## 1. ca/evm/ 模块拆分建议

### 1.1 当前问题

`ca/evm/`目录包含7个文件(3个cpp, 3个h, 1个hpp), 但职责混杂:

| 文件 | 当前职责 | 问题 |
|------|---------|------|
| `evm_host.cpp/h` | Host接口+合约创建+CREATE2+余额管理+存储+日志 | 单文件22KB, 职责过多 |
| `evm_manager.cpp/h` | VM实例化+合约保存/删除+地址验证 | 混合管理逻辑和持久化 |
| `evmEnvironment.cpp/h` | 环境构建+Nonce管理+Message创建+Host填充 | 多处静态函数, 逻辑耦合 |
| `evm_host_data.hpp` | 数据结构定义 | 合理, 但缺少EvmHost数据结构拆分 |

### 1.2 建议拆分

```
ca/evm/
├── host/
│   ├── evm_host.h              -- EvmHost类声明(保持evmc::Host接口)
│   ├── evm_host_account.cpp    -- account_exists/get_balance/get_code
│   ├── evm_host_storage.cpp    -- get_storage/set_storage (含MPT桥接)
│   ├── evm_host_call.cpp       -- call/createContract/calculateCreate2Address
│   ├── evm_host_access.cpp     -- access_account/access_storage/selfdestruct/log
│   └── evm_host_data.h         -- StateAccount/StorageValue/TransferInfo等
├── env/
│   ├── evm_environment.h       -- 环境上下文构建
│   ├── evm_environment_nonce.cpp -- Nonce管理
│   └── evm_environment_message.cpp -- Message/Host构造
├── manager/
│   ├── evm_manager.h           -- VM生命周期
│   ├── evm_manager_contract.cpp -- SaveContract/DeleteContract
│   └── evm_manager_address.cpp -- VerifyContractAddress/latestContractAddress
└── executor/
    └── evm_executor.h/cpp      -- execute_by_evmone + 超时控制(从contract.cpp移出)
```

### 1.3 预估工时

| 任务 | 工时 | 说明 |
|------|------|------|
| evm_host拆分 | 3人天 | 按职责拆分为4个cpp, 保持接口兼容 |
| evm_environment拆分 | 1人天 | 分离Nonce/Message/Host构建逻辑 |
| evm_manager拆分 | 1人天 | 分离持久化和地址管理 |
| execute_by_evmone迁移 | 0.5人天 | 从contract.cpp移到新executor |
| 单元测试 | 2人天 | 为拆分后的模块补充测试 |
| **小计** | **7.5人天** | |

---

## 2. MPT SHA256与Keccak256差异--不兼容风险

### 2.1 核心问题

MPT使用SHA256计算节点哈希(`trie.cpp:429`):

```cpp
nodePtr Trie::ToHash(nodePtr n) {
    dev::RLPStream rlp = Encode(n);
    std::string stringData = dev::toHex(rlp.out());
    strSha256 = Getsha256Hash(stringData);  // SHA256, 非Keccak256
    return HashNode{strSha256};
}
```

而以太坊使用Keccak256。这意味着:
1. **相同的合约状态在MeMeChain和以太坊产生不同的stateRoot**
2. **无法用以太坊工具验证MeMeChain的状态证明**
3. **跨链桥的状态验证不可行**

### 2.2 其他MPT差异

| 差异点 | MeMeChain | 以太坊 | 影响 |
|--------|-----------|--------|------|
| 哈希函数 | SHA256 | Keccak256 | 状态根不兼容 |
| Key终止符 | `'z'` 字符追加 | HP编码(16/17前缀) | 键编码不兼容 |
| 存储Key | `{contractAddr}_{hash}` | `keccak256(RLP(node))` | 节点索引不兼容 |
| 子节点空值 | 空字符串`""` | 空字节数组 | RLP编码略有差异 |
| Hex转换 | `HexToKeybytes`(自定义) | `hexToCompact`(HP) | 路径编码不兼容 |

### 2.3 影响评估

1. **Critical**: 跨链互操作不可行。与任何以太坊L2/侧链/sidecar的桥接都需要重新实现两套状态验证
2. **High**: 无法使用以太坊生态工具(如eth_getProof)验证MeMeChain状态
3. **Medium**: 若未来需要支持EIP-1186(eth_getProof), 需要完整重写MPT哈希层
4. **Low**: 在当前封闭生态内, 只要所有节点使用相同哈希算法, 共识不受影响

### 2.4 修复方案

**方案A: 替换为Keccak256 (推荐)**

```
修改位置: trie.cpp:429
原: strSha256 = Getsha256Hash(stringData);
改: strHash = keccak256_hex(stringData);  // 使用contract/hash_utils.hpp中的keccak256
```

影响范围:
- 所有现有MPT节点哈希改变
- 需要重新同步或迁移现有合约状态
- `Getsha256Hash`可能有其他调用者需要检查

**方案B: 同时支持两种哈希 (过渡方案)**

```cpp
enum class HashAlgorithm { SHA256, Keccak256 };

class Trie {
    HashAlgorithm hashAlgo_;
    // ...
    std::string computeHash(const std::string& data) {
        if (hashAlgo_ == HashAlgorithm::Keccak256)
            return keccak256_hex(data);
        return Getsha256Hash(data);
    }
};
```

影响范围:
- 新合约使用Keccak256
- 旧合约保持SHA256(向后兼容)
- 过渡期维护两套哈希逻辑

**预估工时**:
- 方案A: 3人天(修改+测试+状态迁移工具)
- 方案B: 5人天(双哈希+兼容逻辑+迁移策略)

---

## 3. 预编译合约扩展性改进

### 3.1 当前设计问题

1. **执行体** (`precompiles.cpp:164-186`): traits表硬编码9个预编译, 新增需要改表
2. **注册方式**: 先注册`dummy_execute`, 再通过silkpre覆盖(`precompiles.cpp:178-185`), 两步操作容易出错
3. **SilkPre强依赖**: 除identity外全部依赖silkpre, 新增预编译必须修改silkpre库
4. **无EIP-2537(BLS12-381)支持**: 9个预编译限制为Istanbul硬分叉级别

### 3.2 改进方案

**方案: 插件化预编译注册**

```cpp
// contract/precompiles_registry.hpp
class PrecompileRegistry {
public:
    struct Entry {
        PrecompileId id;
        std::function<PrecompileAnalysis(bytes_view, evmc_revision)> analyze;
        std::function<ExecutionResult(const uint8_t*, size_t, uint8_t*, size_t)> execute;
    };

    static PrecompileRegistry& instance();

    void registerPrecompile(PrecompileId id, Entry entry);
    const Entry* lookup(uint8_t id) const;

private:
    std::array<std::optional<Entry>, 256> registry_;  // 扩展到256个
};
```

使用方式:
```cpp
// silkpre注册(在初始化时)
PrecompileRegistry::instance().registerPrecompile(
    PrecompileId::ecrecover,
    {ecrecover_analyze, silkpre_ecrecover_execute}
);

// 动态注册自定义预编译
PrecompileRegistry::instance().registerPrecompile(
    PrecompileId{0x0a},  // 自定义ID
    {custom_analyze, custom_execute}
);
```

**优点**:
- 一步注册, 消除dummy_execute中间步骤
- 支持运行时注册(需考虑线程安全)
- 可扩展到256个预编译
- 内置和自定义预编译统一接口

**预估工时**: 2人天(重构traits为注册表+测试)

### 3.3 已注释功能恢复

**contract_error.h** (`contract/contract_error.h:1-18`):
- 当前全部注释
- 建议: 定义合约错误枚举, 统一错误码体系
- 工时: 0.5人天

---

## 4. 其他关键改进建议

### 4.1 execute_by_evmone超时处理

- **位置**: `contract.cpp:89-103`
- **问题**: std::future超时后EVM线程仍在运行, 无强制终止机制
- **建议**: 
  - 短期: 使用`std::jthread`(C++20) + `stop_token`
  - 长期: 使用进程级隔离(如wasm沙箱)
- **工时**: 1人天(jthread迁移)

### 4.2 ContractTransactionCache恢复

- **位置**: `contract_transaction_cache.cpp/h` (全部注释)
- **问题**: 依赖管理体系不完整(CanSendTransaction也注释)
- **建议**: 
  1. 先恢复DependencyManager的冲突检测
  2. 再恢复ContractTransactionCache的定时重试
  3. 添加死锁检测和超时保护
- **工时**: 3人天(依赖管理+缓存恢复+测试)

### 4.3 block_prev_randao标准化

- **位置**: `evmEnvironment.cpp:297-316`
- **问题**: 使用UTXO哈希拼接转整数, 与以太坊PREVRANDAO(BEACON_ROOTS)语义完全不同
- **建议**: 集成VRF种子作为PREVRANDAO来源
- **工时**: 1人天(修改+共识参数同步)

### 4.4 Gas计算的浮点精度问题

- **位置**: `fee_calculator.h:27-28`
- **问题**: EIP-1559计算使用`double`, 可能导致不同平台/编译器产生不同结果
- **建议**: 改用定点数计算
- **工时**: 0.5人天

### 4.5 EvmHost成员变量访问控制

- **位置**: `evm_host.h:19-138`
- **问题**: 所有成员public, 注释已承认是临时方案
- **建议**: 分阶段将成员改为private, 增加getter/setter, 将mutable成员用atomic保护
- **工时**: 2人天

### 4.6 合约创建nonce竞争

- **位置**: `evm_host.cpp:417` (`nonceCache++`), `evmEnvironment.cpp:196` (GetNonce)
- **问题**: nonceCache在当前EvmHost中递增, 若同一交易多次CREATE, nonce基于DB查询+本地计数, 可能与其他并发交易冲突
- **建议**: 在交易提交时验证nonce连续性
- **工时**: 1人天

---

## 5. 总工时估算

| 类别 | 任务 | 工时 | 优先级 |
|------|------|------|--------|
| 模块拆分 | ca/evm/目录重构 | 7.5人天 | P2 |
| 兼容性 | MPT SHA256→Keccak256 | 3人天 | P0 |
| 兼容性 | 状态迁移工具 | 2人天 | P0 |
| 扩展性 | 预编译插件化 | 2人天 | P1 |
| 稳定性 | execute_by_evmone超时处理 | 1人天 | P1 |
| 功能恢复 | ContractTransactionCache+依赖管理 | 3人天 | P2 |
| 标准化 | block_prev_randao标准化 | 1人天 | P2 |
| 精度 | Gas计算定点化 | 0.5人天 | P1 |
| 安全 | EvmHost访问控制 | 2人天 | P1 |
| 安全 | nonce竞争检查 | 1人天 | P1 |
| 基础设施 | contract_error.h错误码 | 0.5人天 | P3 |
| 测试 | 单元测试+集成测试 | 5人天 | P1 |
| **合计** | | **28.5人天** | |

**优先级说明**:
- **P0**: MPT Keccak256迁移 -- 影响跨链互操作, 必须在主网上线前完成
- **P1**: 预编译扩展/Gas精度/EVM超时/访问控制/nonce检查/测试 -- 影响安全性和可维护性
- **P2**: 模块拆分/缓存恢复/randao标准化 -- 改善代码质量, 可在P0/P1之后
- **P3**: 错误码 -- 锦上添花

**建议实施顺序**:
1. **Phase 1** (第1周): P0 MPT哈希迁移 + 状态迁移工具
2. **Phase 2** (第2周): P1安全修复(超时/精度/nonce) + 预编译插件化
3. **Phase 3** (第3-4周): P2重构 + 测试完善
