# 模块5: EVM集成与合约执行 -- 调用链分析

## 1. 合约部署完整流程

```mermaid
sequenceDiagram
    participant RPC as RPC/CreateDeploy
    participant Gas as VerifyContractBaseFee
    participant Env as evmEnvironment
    participant Host as EvmHost
    participant VM as evmone VM
    participant MPT as Trie(MPT)
    participant DB as RocksDB

    RPC->>RPC: 解析JSON: from/to/input/code
    RPC->>Gas: VerifyContractBaseFee(fromAddr, gasCost)
    Gas->>DB: 遍历区块链查找fromAddr最后一笔合约交易
    Gas->>Gas: EIP1559FeeCalculator::calculateNewFee(old_baseFee, gasCost, KTargetGasPrice)
    Gas-->>RPC: gasCost *= new_baseFee

    RPC->>Env: make_deploy_host(from, to, host, timestamp, prevRandao, blockNumber, 0)
    Env->>Env: createTxContext(chainId/gasPrice/coinbase/timestamp)
    Env->>DB: GetNonce(sender) -- 查询已部署合约数量
    Env->>Host: coinTransfersInProgress.push(sender, recipient, amount)
    Env->>Host: accounts[recipient].CreateTrie("", contractAddr)

    RPC->>Env: createDeploymentMessageRequest(sender, recipient, gasType, message)
    Env->>Env: MakeMessage(DEPLOY): message.kind=EVMC_CREATE; message.gas=balance

    RPC->>RPC: execute_by_evmone(message, host)
    RPC->>VM: evmc_create_evmone() → vm.execute(host, EVMC_MAX_REVISION, message, host.code, host.code.size())
    Note over VM,Host: VM执行初始化代码, 输出runtimeCode
    VM-->>RPC: output = host.output (runtimeCode hex)

    RPC->>Host: GetStorage(host) → jStorage (遍历accounts保存MPT)
    RPC->>Host: ContractInfoAdd(host, txHash, DEPLOY, ..., txInfoJson)
    Note over RPC,Host: 记录: storage/creation/preHash/log/selfdestruct
    RPC->>RPC: fillDeployOutTransaction() → fillOutputTransmissionRequest()
    RPC->>RPC: generateCallOutMessage() → transactionFillings()
    RPC->>DB: SaveContract(deployer, deployHash, contractAddr, contractCode)
    Note over DB: 6个Key写入: deployUtxo/code/latestUtxo/deployerAddr/deployerList
    RPC->>MPT: root->Save() → hash + Commit (SHA256)
    Note over MPT: 脏节点写入dirtyHash map
    RPC->>RPC: dropCallShippingRequest() → P2P广播
```

**关键代码路径**:
- `contract.h:110` `DeployContract()` → `contract.cpp:134`
- `contract.cpp:72` `execute_by_evmone()` (含10秒超时)
- `contract.cpp:680` `fillDeployOutTransaction()`
- `evm_manager.cpp:86` `SaveContract()`

---

## 2. 合约调用完整流程

```mermaid
sequenceDiagram
    participant RPC as RPC/CreateCall
    participant Gas as VerifyContractBaseFee
    participant Env as evmEnvironment
    participant Host as EvmHost
    participant VM as evmone VM
    participant MPT as Trie(MPT)
    participant DB as RocksDB

    RPC->>RPC: 解析JSON: from/to/input (ABI编码函数签名+参数)
    RPC->>Gas: VerifyContractBaseFee(fromAddr, gasCost) -- EIP-1559调整

    RPC->>DB: GetContractCode(to, code)
    DB-->>RPC: contractCode (运行时字节码)

    RPC->>Env: makeCallHostRequest(from, to, transferAmount, code, host, ...)
    Env->>Env: createTxContext() + GetNonce()
    Env->>Host: coinTransfersInProgress + accounts[recipient].set_code(code)
    Env->>DB: fetchContractRootHash(recipient, rootHash)
    Env->>Host: accounts[recipient].CreateTrie(rootHash, recipient, contractDataStorage)

    RPC->>Env: MakeCallMessage(sender, recipient, input, contractTransfer, ...)
    Env->>Env: MakeMessage(CALL): kind=EVMC_CALL; gas=balance; input

    RPC->>RPC: execute_by_evmone(message, host)
    RPC->>VM: evmc_create_evmone() → vm.execute(host, EVMC_MAX_REVISION, message, host.code, host.code.size())
    Note over VM,Host: vm.execute触发EvmHost::call()处理嵌套调用
    VM-->>RPC: output = host.output

    RPC->>Host: GetStorage(host) → 遍历accounts保存所有脏MPT状态
    RPC->>Host: ContractInfoAdd() → 记录preHash/log/creation/destruction
    RPC->>RPC: fillCallOutTransaction() → fillOutputTransmissionRequest()
    RPC->>RPC: generateCallOutMessage() → transactionFillings()
    RPC->>MPT: root->Save() → hash + Commit (SHA256)
    RPC->>RPC: dropCallShippingRequest() → P2P广播
```

**关键代码路径**:
- `contract.h:122` `CallContract()` → `contract.cpp:169`
- `contract.cpp:72` `execute_by_evmone()` (同部署)
- `contract.cpp:680` `fillCallOutTransaction()`

---

## 3. EvmHost::call() 内部调用链（嵌套合约调用）

```mermaid
flowchart TD
    A[EvmHost::call(msg)] --> B{msg.kind?}
    B -->|EVMC_CREATE| C[nonceCache++]
    C --> D[GenerateContractAddrEth]
    D --> E[createContract]
    E --> E1[getContractTransfer]
    E1 --> E2[CreateTrie empty root]
    E2 --> E3[executeSynchronouslyWithEvmone init code]
    E3 --> E4[createdContract cache runtimeCode]
    E4 --> E5[set_code / create_address]
    E5 --> Z[return EVMC_SUCCESS]

    B -->|EVMC_CREATE2| F[nonceCache++]
    F --> G[calculateCreate2Address]
    G --> E

    B -->|EVMC_CALL| H[recordAccountAccess recipient]
    H --> I{msg.code_address 已自毁?}
    I -->|是| J[return EVMC_FAILURE]
    I -->|否| K[解析msg.value → amount]
    K --> L[getContractTransfer check balance]
    L --> M{预编译地址?}
    M -->|是| N[evmone::state::call_precompile]
    N --> Z2[return 预编译结果]
    M -->|否| O[加载合约代码]
    O --> O1{createdContract缓存?}
    O1 -->|是| O2[从缓存取code]
    O1 -->|否| O3[GetContractCode from DB]
    O3 --> O4{code为空?}
    O4 -->|是| J
    O4 -->|否| P{已加载MPT?}
    P -->|否| Q[fetchContractRootHash]
    Q --> R[CreateTrie from rootHash]
    R --> S[loadContract.insert addr]
    P -->|是| S
    S --> T[evmc_create_evmone]
    T --> U[vm.execute nested EVM]
    U --> V{status_code?}
    V -->|EVMC_SUCCESS| Z
    V -->|其他| J
```

**关键代码**: `evm_host.cpp:366-530`

---

## 4. ETH交易兼容流程 (eth_sendRawTransaction)

```mermaid
sequenceDiagram
    participant RPC as eth_sendRawTransaction
    participant ER as EthRpc
    participant ET as ethVerify
    participant SP as SilkPre(ecrecover)
    participant TH as TxHelper
    participant NW as P2P Network

    RPC->>ER: 接收0x前缀的RLP编码交易
    ER->>ER: hex解码 → dev::bytes transaction_rlp

    ER->>ET: verifyRLP(transaction_rlp, errors, ethTx)
    ET->>ET: 检查首字节 txType (0=Legacy, 2=EIP-1559)
    ET->>ET: dev::RLP解析交易字段
    Note over ET: Legacy: [nonce,gasPrice,gasLimit,to,value,data,v,r,s]
    Note over ET: EIP-1559: [chainId,nonce,maxPriority,maxFee,gasLimit,to,value,data,accessList,v,r,s]

    ET->>ET: 重构签名消息:
    Note over ET: Legacy: RLP([nonce,gasPrice,gasLimit,to,value,data, (chainId,0,0)])
    Note over ET: EIP-1559: Keccak256(0x02 || RLP([chainId,nonce,maxPriority,maxFee,gasLimit,to,value,data,accessList]))
    ET->>ET: EthMessageHash(rlpToSign) → msgHash

    ET->>SP: silkpre_ecrecover_execute(hash(32B)+v(32B)+r(32B)+s(32B))
    SP-->>ET: 恢复的公钥地址(20字节)

    ET->>ET: DB验证: nonce匹配, 余额充足
    ET-->>ER: 返回 EthTransaction(from,nonce,gasPrice,gasLimit,to,value,data,chainId)

    ER->>TH: 根据to地址判断交易类型:
    Note over TH: to为空 → DEPLOY; to有值 → CALL; 普通转账 → TX
    ER->>TH: TxHelper构造Protobuf CTransaction
    ER->>TH: 填充UTXO (VOTE资产)
    ER->>NW: P2P广播交易
```

**关键代码**: `eth_trans.cpp:16-245`

---

## 5. 依赖验证流程 (ContractDispatcher → DependencyManager)

```mermaid
flowchart TD
    A[RPC contractTransactionRequest] --> B[ContractDispatcher::AddContractRequest]
    B --> C[DependencyManager::AddContractRequest]
    C --> C1[scoped_lock dep_mutex_ + msg_mutex_]
    C1 --> C2[contract_dep_cache_[txHash] = dependent_addresses]
    C2 --> C3[contract_msg_cache_[txHash] = txMsgReq]

    D[ContractDispatcher::Process] --> E[TimerProcessor::Start]
    E --> F[ProcessingFunc timer thread]
    F --> G[DependencyManager::GetDependentData]

    G --> G1[快照 dep_cache + msg_cache]
    G1 --> G2[并查集: 共享依赖地址 → 同一分组]
    G2 --> G3[按根节点分组输出 vector<vector<TxMsgReq>>]

    G3 --> H[DependencyManager::GroupData]
    H --> H1[分为8个均衡部分 PARTS=8]

    H1 --> I[MessageDispatcher::DistributionContractTransactionRequest]
    I --> I1[为每个分组选择打包节点]
    I1 --> I2[SendTransactionInfoRequest → P2P发送]
```

**关键代码**: `dispatchtx.cpp:87-200`

---

## 6. ContractTransactionCache 流程（已注释，仅记录原始设计）

```mermaid
flowchart TD
    A[交易发送失败] --> B[ContractTransactionCache::AddFailedTransaction]
    B --> B1[检查tx.hash是否已在缓存]
    B1 --> B2[创建CachedTransaction tx+msg+timestamp]
    B2 --> B3[存入_cachedTransactions]

    C[1秒定时器] --> D[_CheckCachedTransactions]
    D --> E{遍历缓存交易}
    E --> F{timeInCache >= FORCE_SEND_TIMEOUT 15秒?}
    F -->|是| G[发布TransactionConfirmed事件]
    G --> H[Force发送交易]
    F -->|否| I{CanSendTransaction? 依赖已解除?}
    I -->|是| J[发送交易]
    I -->|否| E
    H --> K[_SendCachedTransaction]
    J --> K
    K --> K1[更新tx.time为当前UTC]
    K1 --> K2[重新计算identity打包节点]
    K2 --> K3[清空旧hash/signature, 重新计算hash]
    K3 --> K4[dropCallShippingRequest 重新投递]
```

**状态**: 全部代码被注释(`contract_transaction_cache.h/cpp`), 功能未启用。

---

## 7. 跨合约调用递归深度

当前实现通过`recorded_calls`追踪(最大100次, `evm_host.h:105`), 但不限制嵌套深度。evmone内部有默认的调用深度限制(EIP-150规定的1024层), 但Host侧无额外限制。

**风险**: 若evmone深度限制不生效, 可能无限递归耗尽栈空间。
