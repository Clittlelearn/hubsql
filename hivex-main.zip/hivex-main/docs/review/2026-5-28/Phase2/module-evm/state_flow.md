# 模块5: EVM集成与合约执行 -- 状态流转

## 1. EVM执行状态机

```mermaid
stateDiagram-v2
    [*] --> IDLE: EvmHost创建
    IDLE --> LOADING: execute_by_evmone()
    LOADING --> EXECUTING: vm.execute(host, msg, code)
    EXECUTING --> REVERT: REVERT opcode
    EXECUTING --> DONE: EVMC_SUCCESS
    EXECUTING --> OUT_OF_GAS: EVMC_OUT_OF_GAS
    EXECUTING --> ERROR: 其他失败码
    EXECUTING --> TIMEOUT: 10秒超时
    REVERT --> ROLLBACK: 撤销状态变更
    ROLLBACK --> [*]
    OUT_OF_GAS --> ROLLBACK
    ERROR --> ROLLBACK
    TIMEOUT --> ROLLBACK
    DONE --> COMMITTING: GetStorage + Save
    COMMITTING --> PERSISTED: RocksDB写入
    PERSISTED --> [*]
```

### 1.1 状态说明

| 状态 | 描述 | 关键代码 |
|------|------|---------|
| **IDLE** | EvmHost创建, 账户/MPT状态已加载 | `content.cpp:136` `make_deploy_host` 或 `makeCallHostRequest` |
| **LOADING** | 准备执行: 获取nonce, 创建message, 填充tx_context | `contract.cpp:143-150` `createDeploymentMessageRequest` |
| **EXECUTING** | evmone VM正在执行字节码 | `contract.cpp:89-92` `vm.execute()` |
| **DONE** | 执行成功, output为返回值hex | `contract.cpp:105-131` |
| **REVERT** | 合约主动REVERT, output为回滚原因 | `contract.cpp:108` `EVMC_REVERT` |
| **OUT_OF_GAS** | Gas耗尽 | `evmc_status_code` |
| **ERROR** | 其它执行错误(非法指令/栈溢出等) | `contract.cpp:42-67` 错误描述表 |
| **TIMEOUT** | 10秒超时( `contract.cpp:96` ) | `contract.cpp:97-103` |
| **ROLLBACK** | Host内存状态自然丢弃(未持久化) | -- |
| **COMMITTING** | GetStorage提取脏状态, MPT Save | `contract.cpp:254-293`, `contract.cpp:320-403` |
| **PERSISTED** | 合约代码/MPT节点写入RocksDB | `evm_manager.cpp:86-133` |

### 1.2 执行状态码映射

```cpp
// contract.cpp:44-67
EVMC_SUCCESS         → "Execution successful."
EVMC_FAILURE         → "Generic execution failure."
EVMC_REVERT          → "Execution terminated with REVERT opcode."
EVMC_OUT_OF_GAS      → "Execution ran out of gas."
EVMC_INVALID_INSTRUCTION → "INVALID instruction hit."
EVMC_UNDEFINED_INSTRUCTION → "Undefined instruction encountered."
EVMC_STACK_OVERFLOW  → "Stack overflow."
EVMC_STACK_UNDERFLOW → "Stack underflow."
EVMC_BAD_JUMP_DESTINATION → "Bad jump destination."
EVMC_INVALID_MEMORY_ACCESS → "Read outside memory bounds."
EVMC_CALL_DEPTH_EXCEEDED → "Call depth exceeded."
EVMC_STATIC_MODE_VIOLATION → "Static mode violation."
EVMC_PRECOMPILE_FAILURE → "Precompile failure."
EVMC_CONTRACT_VALIDATION_FAILURE → "Contract validation failed."
EVMC_INSUFFICIENT_BALANCE → "Insufficient balance."
EVMC_INTERNAL_ERROR  → "Internal error."
EVMC_REJECTED        → "Execution rejected."
EVMC_OUT_OF_MEMORY   → "Out of memory."
```

---

## 2. 合约生命周期状态机

```mermaid
stateDiagram-v2
    [*] --> UNDEPLOYED: 链创世
    UNDEPLOYED --> DEPLOYING: CreateDeploy RPC
    DEPLOYING --> DEPLOYED: EIP-161地址生成 + 合约代码持久化
    DEPLOYING --> DEPLOY_FAILED: 执行失败/超时/回滚
    DEPLOY_FAILED --> UNDEPLOYED: 状态未持久化
    DEPLOYED --> CALLING: CreateCall RPC
    DEPLOYED --> DEPLOYED: 合约升级(重新部署, 新地址)
    CALLING --> DEPLOYED: 调用成功, MPT状态更新
    CALLING --> DEPLOYED: 调用失败(REVERT), MPT状态不更新
    DEPLOYED --> SELF_DESTRUCTED: SELFDESTRUCT opcode
    SELF_DESTRUCTED --> [*]: 后续调用被拦截(EVMC_FAILURE)
```

### 2.1 生命周期状态详解

| 状态 | 数据特征 | 验证方法 |
|------|---------|---------|
| **UNDEPLOYED** | `GetContractCode(addr)` 返回 DB_NOT_FOUND | `evm_manager.cpp:57` |
| **DEPLOYING** | EvmHost内存中存在, createdContract缓存中有runtimeCode | `evm_host.cpp:556` |
| **DEPLOY_FAILED** | EvmHost销毁, 内存状态释放 | -- |
| **DEPLOYED** | RocksDB中有合约代码; MPT根哈希存在 | `contract.cpp:324-340` |
| **CALLING** | EvmHost.accounts中存在; loadContract已标记; MPT已初始化 | `evm_host.cpp:485-501` |
| **SELF_DESTRUCTED** | recorded_selfdestructs中有记录; `call()`中检查`msg.code_address` | `evm_host.cpp:392-405` |

### 2.2 自毁状态检测

```cpp
// evm_host.cpp:392-405
auto found = std::find_if(recorded_selfdestructs.begin(), recorded_selfdestructs.end(),
    [msg](const selfDestructRecord &item) {
        return item.selfdestructed == msg.code_address;
    });
if (found != recorded_selfdestructs.end()) {
    return evmc::Result{evmc_failure_outcome};
}
```

**注意**: 自毁检测仅在当前EvmHost实例的recorded_selfdestructs中查找, 不跨交易。在EIP-6049之后(SHANGHAI硬分叉) SELFDESTRUCT语义已变更(不立即删除账户), 但当前实现仍保留旧语义。

---

## 3. MPT状态生命周期

```mermaid
stateDiagram-v2
    [*] --> EMPTY_TRIE: CreateTrie("", contractAddr)
    EMPTY_TRIE --> INSERTING: Update(key, value)
    INSERTING --> DIRTY: 节点标记dirty=true
    DIRTY --> INSERTING: 更多Update()
    DIRTY --> HASHING: Save() → hash(root)
    HASHING --> COMMITTED: Commit(root) → HashNode替换
    COMMITTED --> PERSISTED: GetBlockStorage → DB写入
    PERSISTED --> LOADED: Trie(rootHash, contractAddr) → ResolveHash → DescendKey
    LOADED --> INSERTING: Get() 反序列化节点树
```

### 3.1 MPT状态转换详解

| 转换 | 触发 | 代码 | 说明 |
|------|------|------|------|
| `EMPTY_TRIE → INSERTING` | `Update(key, value)` | `trie.cpp:238-249` | 封装key, 创建ValueNode, 调用Insert |
| `INSERTING → DIRTY` | Insert递归 | `trie.cpp:149-237` | ShortNode/FullNode split/merge; newFlag()标记dirty |
| `DIRTY → HASHING` | `Save()`第一步 | `trie.cpp:589-598` | `hash(root)`递归计算 |
| `HASHING → COMMITTED` | `Commit(root)` | `trie.cpp:515-561` | 遍历ShortNode/FullNode, Store→dirtyHash |
| `COMMITTED → PERSISTED` | `GetBlockStorage` | `trie.cpp:63-84` | dirtyHash暴露给外部, 由`contract.cpp:259-262`写入DB |
| `PERSISTED → LOADED` | 构造函数 | `trie.h:89-110` | root = ResolveHash(HashNode{roothash}) |
| `LOADED → INSERTING` | `Get(key)` | `trie.cpp:93-136` | 递归解析HashNode→DescendKey→DecodeNode |

### 3.2 哈希计算 (`trie.cpp:422-435`)

```
ToHash(n):
  1. RLPStream rlp = Encode(n)
  2. bytes data = rlp.out()
  3. string stringData = dev::toHex(data)  // → hex字符串
  4. strSha256 = Getsha256Hash(stringData) // SHA256
  5. 返回 HashNode{strSha256}
```

### 3.3 节点存储格式

RocksDB Key: `{contractAddr}_{hash}` (hash为SHA256 hex字符串)

RLP编码示例:
- **ShortNode**: `RLP([key, Encode(child).out()])` (2元素列表)
- **FullNode**: `RLP([c0, c1, ..., c15, ""])` (17元素列表, 空子节点编码为空字符串)
- **ValueNode**: RLP字符串
- **HashNode**: RLP字符串(hash值)

---

## 4. 合约部署时的MPT初始化

```
CreateTrie("", contractAddr):  -- 空根哈希
  root = NULL  // 新Trie, 无历史状态
  contractAddr = "0x..."
```

首次`Update(key, value)`触发:
```
Insert(NULL, "", wrapperKey, ValueNode)
→ ReturnVal{true, ShortNode{key, valueNode, dirty=true}, 0}
→ root = ShortNode
```

首次`Save()`:
```
hash(ShortNode) → HashShortNodeChildren → ToHash(ShortNode)
→ RLP编码 → SHA256
→ root变为HashNode{hash}
```

---

## 5. 合约调用时的MPT加载

```
1. fetchContractRootHash(contractAddr, rootHash, contractDataStorage)
   → 从交易JSON提取或DB读取

2. CreateTrie(rootHash, contractAddr, contractDataStorage):
   root = ResolveHash(HashNode{rootHash}, "")
   → DescendKey(rootHash)
   → DB key: "{contractAddr}_{rootHash}"
   → RLP解码 → DecodeNode → 递归构建节点树

3. 后续get_storage/set_storage操作:
   → 优先查contractDataStorage(内存缓存)
   → 缓存未命中查RocksDB (通过Trie::DescendKey)
   → 内存中维护storage map + storageRoot
```
