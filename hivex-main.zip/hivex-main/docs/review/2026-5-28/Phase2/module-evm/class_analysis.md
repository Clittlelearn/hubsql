# 模块5: EVM集成与合约执行 -- 类分析

## 1. EvmHost (继承 evmc::Host)

**文件**: `ca/evm/evm_host.h:33-139`, `ca/evm/evm_host.cpp:13-652`

### 1.1 类职责

EvmHost是MeMeChain与EVM之间的核心桥接层。它将UTXO模型的余额管理、合约代码存储、MPT状态树适配为EVM标准Host接口。

### 1.2 继承的Host接口实现

| 方法 | 行号 | 返回值 | 实现要点 |
|------|------|--------|---------|
| `account_exists()` | `evm_host.cpp:105-109` | `bool` | 查`accounts` map, 同时触发`recordAccountAccess`自动加载合约代码 |
| `get_storage()` | `evm_host.cpp:111-161` | `evmc::bytes32` | 先查`storageRoot`(MPT), 再查`storage` map(内存), 三级fallback |
| `set_storage()` | `evm_host.cpp:163-250` | `evmc_storage_status` | 更新MPT+内存; 返回ADDED/MODIFIED/DELETED/ASSIGNED状态 |
| `get_balance()` | `evm_host.cpp:252-284` | `evmc::uint256be` | UTXO余额查询+coinTransfersInProgress+dbSpendMap扣减 |
| `get_code_size()` | `evm_host.cpp:286-300` | `size_t` | accounts map查询 |
| `get_code_hash()` | `evm_host.cpp:302-314` | `evmc::bytes32` | 返回`StateAccount.codehash`(Keccak256计算) |
| `copy_code()` | `evm_host.cpp:316-334` | `size_t` | std::copy_n切片复制 |
| `selfdestruct()` | `evm_host.cpp:336-364` | `bool` | 记录到recorded_selfdestructs; 余额转移到受益者 |
| `call()` | `evm_host.cpp:366-530` | `evmc::Result` | 核心方法,处理所有跨合约调用(见下文) |
| `get_tx_context()` | `evm_host.cpp:569-572` | `evmc_tx_context` | 返回预设的tx_context |
| `get_block_hash()` | `evm_host.cpp:574-578` | `evmc::bytes32` | 返回预设的block_hash |
| `emit_log()` | `evm_host.cpp:580-584` | `void` | 记录到recorded_logs |
| `access_account()` | `evm_host.cpp:586-600` | `evmc_access_status` | EIP-2929实现; 预编译地址(1-9)返回WARM |
| `access_storage()` | `evm_host.cpp:602-608` | `evmc_access_status` | 返回上次access_status并更新为WARM |
| `get_transient_storage()` | `evm_host.cpp:611-614` | `evmc::bytes32` | 空实现,返回{} |
| `set_transient_storage()` | `evm_host.cpp:617-621` | `void` | 空实现(不支持EIP-1153 transient storage) |

### 1.3 公共成员变量（注释说明因EVM部署需求设为public）

```cpp
// evm_host.h:19-138
mutable Used usedInfo;              // gas_used/input_size/read_count/write_count统计
mutable unordered_map<address, StateAccount> accounts;  // 账户状态
evmc_tx_context tx_context;         // 交易上下文
evmc::bytes32 block_hash;           // 区块哈希
evmc_result call_result;            // 调用结果
mutable vector<int64_t> recorded_blockhashes;           // 已查询的区块号
mutable vector<evmc::address> recorded_account_accesses; // EIP-2929访问追踪
vector<evmc_message> recorded_calls;                   // 嵌套调用记录
vector<log_record> recorded_logs;                      // LOG记录
vector<selfDestructRecord> recorded_selfdestructs;     // 自毁记录
evmc::bytes code;                  // 当前执行代码
int64_t gas_cost;                  // 实际Gas消耗
string output;                     // 执行输出
string outputError;                // 错误输出
map<string, uint64_t> dbSpendMap;  // 转账扣除追踪
int64_t nonceCache;                // 当前nonce缓存
map<string, string> createdContract; // 本次交易创建的合约(addr→runtimeCode)
vector<TransferInfo> coinTransfersInProgress;  // 资产转移队列
contractDataContainer *contractDataStorage;    // MPT数据容器引用
set<string> loadContract;          // 已加载MPT的合约(防重复)
```

### 1.4 call()方法流程详解(`evm_host.cpp:366-530`)

```
步骤1: recordAccountAccess(msg.recipient) -- 自动加载合约代码
步骤2: 保存调用记录到recorded_calls
步骤3: 自毁状态检查 -- 若msg.code_address已被自毁, 返回EVMC_FAILURE
步骤4: 解析msg.value → amount; fromAddr/toAddr
步骤5: 分派消息类型:
  - EVMC_CREATE:  nonceCache++; GenerateContractAddrEth → createContract()
  - EVMC_CREATE2: nonceCache++; calculateCreate2Address() → createContract()
  - EVMC_CALL/DELEGATECALL: 
      a. getContractTransfer() -- 验证余额
      b. coinTransfersInProgress合并
      c. 预编译优先 (evmone::state::call_precompile)
      d. 加载合约代码 (createdContract缓存 → GetContractCode)
      e. 加载MPT状态 (fetchContractRootHash → CreateTrie)
      f. 创建嵌套evmone VM → vm.execute()
步骤6: 返回evmc::Result
```

### 1.5 createContract()方法 (`evm_host.cpp:532-566`)

专门处理CREATE/CREATE2的合约创建:
1. getContractTransfer验证转账
2. 新建CreateTrie(空根哈希)
3. 调用Evmone::executeSynchronouslyWithEvmone执行初始化代码
4. 将runtimeCode存入createdContract缓存
5. 设置create_address

### 1.6 calculateCreate2Address() (`evm_host.cpp:623-652`)

严格遵循以太坊CREATE2标准:
```
creationSeed = 0xff || sender(20B) || salt(32B) || keccak256(init_code)(32B)
address = keccak256(creationSeed)[12:32]
```
使用`ethash::keccak256`(与以太坊兼容)。

---

## 2. StateAccount (`evm_host_data.hpp:45-108`)

合约账户的内存表示:

| 字段 | 类型 | 说明 |
|------|------|------|
| `nonce` | `int` | 账户nonce(未使用) |
| `code` | `evmc::bytes` | 合约运行时字节码 |
| `codehash` | `evmc::bytes32` | Keccak256(code) |
| `balance` | `evmc::uint256be` | 余额(未使用) |
| `storage` | `unordered_map<bytes32, StorageValue>` | 存储映射(dirty标记) |
| `storageRoot` | `shared_ptr<Trie>` | MPT状态树 |

**CreateTrie()** 三个重载:
- `CreateTrie(rootHash, ContractAddr)` -- 从哈希加载
- `CreateTrie(rootHash, ContractAddr, contractDataStorage)` -- 带缓存加载

**set_code()**: 计算`keccak256_hex(code)`设置codehash (`evm_host_data.hpp:94-102`)

### 2.1 StorageValue (`evm_host_data.hpp:15-38`)

扩展的存储值:
- `value`: evmc::bytes32存储值
- `dirty`: 是否已被当前交易修改
- `access_status`: EVMC_ACCESS_COLD/WARM

### 2.2 辅助结构体

- `TransferInfo` (`evm_host_data.hpp:110-122`): from/to/amount
- `log_record` (`evm_host_data.hpp:125-141`): creator/data/topics
- `selfDestructRecord` (`evm_host_data.hpp:144-157`): selfdestructed/beneficiary
- `Used` (`evm_host.h:21-32`): gas_used/input_size/read_count/write_count统计

---

## 3. EvmManager (`evm_manager.h:8-51`, `evm_manager.cpp:12-172`)

### 3.1 命名空间 Evmone -- 静态工具函数

| 函数 | 行号 | 功能 |
|------|------|------|
| `GetEvmInstance()` | `evm_manager.cpp:12-27` | 创建并验证evmone VM实例 |
| `executeSynchronouslyWithEvmone()` | `evm_manager.cpp:29-55` | 执行EVM字节码并返回输出hex |
| `VerifyContractAddress()` | `evm_manager.cpp:57-65` | 校验合约地址(基于nonce) |
| `latestContractAddress()` | `evm_manager.cpp:67-84` | 预测下一合约地址(EIP-161) |
| `SaveContract()` | `evm_manager.cpp:86-133` | 保存合约到RocksDB(6个键) |
| `DeleteContract()` | `evm_manager.cpp:135-172` | 从RocksDB删除合约(6个键) |

### 3.2 SaveContract 保存的数据库键

```
1. setContractDeployUtxoByContractAddr(contractAddress, deployHash)
2. setContractCodeByContractAddr(contractAddress, contractCode)
3. setLatestUtxoByContractAddr(contractAddress, deployHash)
4. setContractAddrByDeployerAddr(deployerAddress, contractAddress)
5. getEvmDeployerAddr + setEvmDeployerAddr (deployerAddress)
```

---

## 4. evmEnvironment (`evmEnvironment.h:14-53`, `evmEnvironment.cpp:167-386`)

### 4.1 环境准备函数

| 函数 | 行号 | 功能 |
|------|------|------|
| `GetBlockNumber()` | `evmEnvironment.cpp:167-178` | 读取top高度+1 |
| `GetNonce()` | `evmEnvironment.cpp:196-214` | 按deployerAddr的合约数=nonce |
| `GetNextNonce()` | `evmEnvironment.cpp:216-225` | nonce+1 |
| `createTxContext()` | `evmEnvironment.cpp:275-295` | 填充evmc_tx_context(chainId/gasPrice/coinbase等) |
| `calculateBlockTimestamp()` | `evmEnvironment.cpp:180-194` | UTC时间戳+偏移, 转秒精度 |
| `blockPrevRandaoCalculator()` | `evmEnvironment.cpp:297-316` | UTXO哈希拼接转整数(非标准RANDAO) |
| `GetBlockTimestamp()` | `evmEnvironment.cpp:319-333` | 从交易JSON提取blockTimestamp |
| `get_block_prev_randao()` | `evmEnvironment.cpp:335-349` | 从交易JSON提取blockPrevRandao |

### 4.2 Message构造 (匿名命名空间内部)

- `MakeHost()` -- 填充EvmHost(txContext/nonce/transfer/MPT)
- `MakeMessage()` -- 填充evmc_message(kind/gas/input/value)
- `createRpcMessage()` -- RPC调用专用(固定gas=111657576591)

**关键发现**: RPC调用使用硬编码gas值`111657576591` (`evmEnvironment.cpp:99-103`, `139-145`), 当发送者为创始账户时也使用此值。此值无明确含义【需人工验证】。

---

## 5. ContractDispatcher / DependencyManager (`dispatchtx.h:21-96`, `dispatchtx.cpp:63-200`)

### 5.1 ContractDispatcher

轻量级分发器, 委托给DependencyManager:

```
AddContractInfo → DependencyManager::AddContractInfo
AddContractMessageRequest → DependencyManager::AddMessageRequest
AddContractRequest → DependencyManager::AddContractRequest
Process → TimerProcessor::Start
```

### 5.2 DependencyManager

**核心数据结构**:
```cpp
unordered_map<string, vector<string>> contract_dep_cache_;  // txHash → 依赖地址列表
unordered_map<string, TxMsgReq> contract_msg_cache_;        // txHash → 交易消息
```

**GetDependentData()** 流程 (`dispatchtx.cpp:113-177`):
1. 快照读取dep_cache和msg_cache
2. 并查集(Union-Find)构建: 共享依赖地址的交易归入同一分组
3. 按根节点分组输出`vector<vector<TxMsgReq>>`

**GroupData()** (`dispatchtx.cpp:179-200`):
- 将分组数据均衡分为8个部分(PARTS=8)

### 5.3 已注释功能

- `dependency_tx_hashes_`: 依赖地址→交易哈希列表
- `CanSendTransaction()`: 依赖冲突检查
- `ClearDependency()`: 依赖清理
- `BroadcastAddedDependency()`: 依赖广播
- `HandleContractDependencyBroadcastMsg()`: 依赖广播处理

所有这些功能已注释掉, 说明当前的依赖管理仅做分组, 不做阻塞检查。

---

## 6. ContractTransactionCache (`contract_transaction_cache.h`, `.cpp`)

**状态: 全部注释(未启用)**

设计上支持:
- 失败交易缓存
- 1秒定时器检查(CHECK_INTERVAL = 1000ms)
- 15秒强制发送(FORCE_SEND_TIMEOUT = 15)
- 依赖解除自动重试
- 发送前更新tx.time/identity/hash

未启用原因推测: 依赖管理的CanSendTransaction/ClearDependency等功能也被注释, 两者构成完整依赖-缓存体系, 可能因测试不充分或存在死锁风险而被整体移除【需人工验证】。

---

## 7. MPT Trie类 (`mpt/trie.h:75-157`, `mpt/trie.cpp:17-598`)

### 7.1 节点类型 (`mpt/node.h`)

| 节点 | 结构 | 说明 |
|------|------|------|
| `HashNode` | `data: string` | 哈希引用(32字节SHA256 hex) |
| `ValueNode` | `data: string` | 值节点(存储原始hex数据) |
| `ShortNode` | `nodeKey: string, nodeVal: nodePtr, nodeFlags: NodeFlag` | 短节点(压缩路径) |
| `FullNode` | `children: array[17], flags: NodeFlag` | 全节点(16子+1值) |

节点通过`packing<T>`模板使用RTTI(`typeid`)进行类型判别(`node.h:50-81`)。

### 7.2 核心操作

| 操作 | 行号 | 说明 |
|------|------|------|
| `Get(key)` | `trie.cpp:138-148` | 查找值: `wrapperKey(key) → Get递归 → ValueNode.data` |
| `Update(key, value)` | `trie.cpp:238-249` | 插入/更新: `Insert(root, "", wrapperKey(key), ValueNode)` |
| `Insert(n, prefix, key, value)` | `trie.cpp:149-237` | 递归插入, 处理ShortNode/FullNode/HashNode分支 |
| `Commit(n)` | `trie.cpp:515-561` | 计算脏节点哈希并替换为HashNode |
| `Save()` | `trie.cpp:589-598` | `hash(root) → Commit(root)` 完成整树哈希化 |
| `GetBlockStorage()` | `trie.cpp:63-84` | 提取rootHash和dirtyHash(用于序列化) |
| `Encode(n)` | `trie.cpp:436-479` | RLP编码节点(ShortNode→[key,value]; FullNode→[17]; ValueNode→data; HashNode→hash) |
| `ToHash(n)` | `trie.cpp:422-435` | RLP编码→hex字符串→SHA256哈希 |
| `DecodeNode(hash, rlp)` | `trie.cpp:331-342` | itemCount==2→DecodeShort; ==17→DecodeFull |
| `DescendKey(key)` | `trie.cpp:251-269` | 从DB/cache加载节点: `{contractAddr}_{hash}`→RLP→DecodeNode |

### 7.3 Key处理

- `wrapperKey(key)`: `key + key.back() + 'z'` (`trie.cpp:17-19`)
- `HasTerm(s)`: 检查末尾是否为'z' (`trie.cpp:21-24`)
- `HexToKeybytes(hex)`: 十六进制→字节数组 (`trie.cpp:25-41`)

**注意**: 此终止符方案与以太坊HP(Hex-Prefix)编码完全不同。以太坊使用nibble(4-bit)编码, nibble 0x10表示叶子节点。这里的'z'方案是自定义的简化方案。

### 7.4 contractDataContainer (`trie.h:45-73`)

内存缓存层:
- `set(jStorage)`: 批量写入(unique_lock)
- `get(key, value)`: 单个读取(shared_lock)
- 使用`shared_mutex`实现读写锁
- 存储格式: 直接JSON键值

---

## 8. RLP编解码 (`mpt/rlp.h:43-350`, `mpt/rlp.cpp`)

Aleth (Ethereum C++ client) 移植版, 支持:
- RLP数据解码: `isData()/isList()/isNull()/isEmpty()`
- 类型转换: `toInt<T>()/toString()/toBytes()/toHash<T>()`
- RLPStream序列化: `append()/appendList()/operator<<`
- 迭代器: `begin()/end()` for list items
- `handleEthSendRawTransaction()` 声明 (`rlp.h:479`)

---

## 9. EIP1559FeeCalculator (`fee_calculator.h:9-71`)

```cpp
static double calculateNewFee(old_fee, actual_gas, target_gas):
  adjustment = (actual_gas - target_gas) / (target_gas * 8.0)
  new_fee_exact = old_fee * (1.0 + adjustment)
  // 增长时ceil, 降低时floor
  return max(new_fee, 0.0)
```

使用`double`浮点计算, 存在精度问题(区块链应使用定点数)。`contract.cpp:815`调用。
