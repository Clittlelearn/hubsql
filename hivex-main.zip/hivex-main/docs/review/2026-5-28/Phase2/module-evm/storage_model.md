# 模块5: EVM集成与合约执行 -- 存储模型

## 1. RocksDB Key前缀规范

MeMeChain使用RocksDB TransactionDB模式存储所有数据。以下列出EVM合约相关的所有Key前缀。

### 1.1 合约代码与部署

| Key模式 | Value | 说明 | 读写位置 |
|---------|-------|------|---------|
| `EVM_CODE:{contractAddr}` | 合约运行时字节码(hex) | 合约代码存储 | `evm_manager.cpp:96` set; `utils/contract_utils.h` GetContractCode |
| `EVM_DEPLOY:{contractAddr}` | 部署交易的txHash | 合约部署UTXO映射 | `evm_manager.cpp:91` set; `evm_manager.cpp:138` remove |
| `EVM_UTXO:{contractAddr}` | 最新的UTXO hash | 合约最新UTXO追踪 | `evm_manager.cpp:101` set; `evm_manager.cpp:147` remove |
| `EVM_DEPLOYER:{deployerAddr}` | `vector<contractAddr>` (多值) | 部署者→合约地址映射 | `evm_manager.cpp:106` set; `evm_manager.cpp:153` remove |
| `{deployerAddr}` (setEvmDeployerAddr) | 部署者地址列表(追加) | EVM部署者注册 | `evm_manager.cpp:126` set; `evm_manager.cpp:164` remove |

**注意**: `EVM_DEPLOYER:`前缀对应`setContractAddrByDeployerAddr`, 但`setEvmDeployerAddr`似乎使用不同前缀(需要查`db_api.h`确认)【需人工验证】。

### 1.2 合约资产类型

| Key模式 | Value | 说明 |
|---------|-------|------|
| `EVM_ASSET:{assetType}` | 资产类型元数据 | EVM合约资产注册 |

**注意**: 此前缀在`spec_dev.md`提及但未在代码中直接搜索到, 可能通过其他机制实现【需人工验证】。

### 1.3 MPT节点存储

| Key模式 | Value | 说明 | 代码位置 |
|---------|-------|------|---------|
| `MPT:{contractAddr}_{hash}` | RLP编码节点(hex) | MPT状态树节点 | `trie.cpp:261` get; `trie.cpp:508` set(通过dirtyHash) |

**存储流程**:
1. `Trie::Save()` → `hash(root)` + `Commit(root)` → `dirtyHash[hash] = rlp_encoded_hex`
2. 外部调用`GetBlockStorage()`获取dirtyHash
3. `contract.cpp:259-262` 遍历dirtyHash, 构建`{contractAddr}_{hash}`键写入DB

### 1.4 合约交易信息

| Key模式 | Value | 说明 |
|---------|-------|------|
| `TX:{txHash}` | CTransaction序列化 | 交易数据 |
| `TXBH:{txHash}` | 区块哈希 | 交易所在区块 |

**ContractInfoAdd额外写入** (`contract.cpp:320-403`):
- `txInfo["storage"]` = jStorage (MPT脏数据 → DB)
- `txInfo["creation"]` = creationItems (新创建合约代码)
- `txInfo["preHash"]` = items (依赖合约的前一交易哈希)
- `txInfo["log"]` = EVM日志
- `txInfo["destruction"]` = 自毁合约代码

### 1.5 UTXO相关 (合约Gas支付)

| Key模式 | Value | 说明 |
|---------|-------|------|
| `UB:{addr}:{assetType}:{utxoHash}` | 余额 | UTXO余额 |
| `UAH:{addr}:{assetType}` | `vector<utxoHash>` | 地址UTXO列表 |
| `BAL:{addr}:{assetType}` | 余额 | 地址汇总余额 |

合约交易Gas通过VOTE资产UTXO支付(`contract.cpp:882-896`)。

---

## 2. MPT节点存储格式详解

### 2.1 Key格式

```
MPT_{contractAddr}_{nodeHash}
```

- `contractAddr`: 合约地址(40字符hex, 不带0x)
- `nodeHash`: 节点SHA256哈希(64字符hex)
- 完整Key示例: `MPT_1234567890abcdef1234567890abcdef12345678_a1b2c3d4...`

### 2.2 Value格式(RLP编码)

**ShortNode** (2元素RLP列表):
```
RLP([key_string, Encode(child).out()])
```

**FullNode** (17元素RLP列表):
```
RLP([c0, c1, ..., c15, c16])
```
- c0-c15: 16个子节点(索引0x0-0xf), 空子节点编码为空字符串
- c16: 值节点

**ValueNode** (RLP字符串/字节):
```
RLP(data_string)
```

**HashNode** (RLP字符串):
```
RLP(hash_string) -- SHA256 hash, 64字符hex
```

### 2.3 加载流程 (`trie.cpp:251-269`)

```cpp
nodePtr Trie::DescendKey(std::string key) const {
    // 1. 先查 contractDataStorage 内存缓存
    if (this->contractDataStorage != nullptr) {
        this->contractDataStorage->get(contractAddr + "_" + key, value);
    }
    // 2. 缓存未命中, 查RocksDB
    if (value.empty()) {
        dataReader.getMptValueByMptKey(contractAddr + "_" + key, value);
    }
    // 3. RLP解码
    dev::bytes bs = dev::fromHex(value);
    dev::RLP r = dev::RLP(bs);
    return DecodeNode(key, r);
}
```

### 2.4 存储流程 (`trie.cpp:482-513`)

```cpp
nodePtr Trie::Store(nodePtr n) {
    // 仅ShortNode和FullNode需要存储
    dev::RLPStream rlp = Encode(n);
    std::string stringData = dev::toHex(rlp.out());
    // 哈希→ RLP hex 存入dirtyHash
    dirtyHash[hash.data] = stringData;
    return HashNode{hash};
}
```

---

## 3. contractDataContainer 内存缓存

### 3.1 数据结构

```cpp
// trie.h:45-73
class contractDataContainer {
    std::unordered_map<std::string, std::string> contractDataMap;
    mutable std::shared_mutex contractDataMapMutex_;
};
```

### 3.2 使用场景

- **来源**: 从区块恢复时, 区块中的`jStorage`数据批量加载到内存
- **访问**: `Trie::DescendKey`优先查此缓存, 避免RocksDB I/O
- **生命周期**: 与区块验证过程绑定

### 3.3 缓存键

格式与RocksDB一致: `{contractAddr}_{hash}`

---

## 4. 合约代码存储

### 4.1 写入 (`evm_manager.cpp:86-133`)

部署合约后调用`Evmone::SaveContract`, 写入以下数据:

```
1. setContractDeployUtxoByContractAddr(contractAddress, deployHash)
   → Key: EVM_DEPLOY:{contractAddress} → deployHash

2. setContractCodeByContractAddr(contractAddress, contractCode)
   → Key: EVM_CODE:{contractAddress} → contractCode (hex)

3. setLatestUtxoByContractAddr(contractAddress, deployHash)
   → Key: EVM_UTXO:{contractAddress} → deployHash

4. setContractAddrByDeployerAddr(deployerAddress, contractAddress)
   → Key: EVM_DEPLOYER:{deployerAddress} → 追加contractAddress

5. setEvmDeployerAddr(deployerAddress) (EVM类型时)
   → 将deployerAddress加入全局EVM部署者列表
```

### 4.2 读取

```cpp
// evm_utils::GetContractCode (utils/contract_utils.h)
// Key: EVM_CODE:{contractAddress} → code bytes
int GetContractCode(const std::string& contractAddress, evmc::bytes& code);
```

### 4.3 删除 (`evm_manager.cpp:135-172`)

自毁合约时调用`Evmone::DeleteContract`, 删除上述所有键。
如果部署者全部合约已删除, 同时从EVM部署者列表中移除。

---

## 5. 合约创建代码存储 (createdContract缓存)

### 5.1 生命周期

仅在当前交易内有效:

```cpp
// evm_host.h:123
std::map<std::string, std::string> createdContract;
// key: contract address, value: runtime code (hex)
```

### 5.2 使用场景

1. CREATE/CREATE2执行后, runtimeCode存入`createdContract` (`evm_host.cpp:556`)
2. 后续CALL到新合约地址时, 从`createdContract`先查找 (`evm_host.cpp:457-462`)
3. 交易结束后, `ContractInfoAdd`将`createdContract`写入`txInfo["creation"]` (`contract.cpp:333-338`)
4. 区块确认后, `SaveContract`将代码持久化到RocksDB

### 5.3 注意

此缓存解决了"同一交易内创建后立即调用"的场景。以太坊中这是自然的(状态在同一交易内更新), 但在MeMeChain的UTXO+账户混合模型中, 数据库写入在交易结束后才发生, 因此需要内存缓存桥接。

---

## 6. 合约地址生成与部署者映射

### 6.1 Nonce管理

Nonce = 部署者已部署的合约数量 (`evmEnvironment.cpp:196-214`):

```cpp
int64_t evmEnvironment::GetNonce(const std::string& address) {
    vector<string> contractAddresses;
    dbReader.getContractAddrByDeployerAddr(address, contractAddresses);
    return contractAddresses.size();  // 合约数量 = nonce
}
```

**风险**: 如果部署交易失败但未回滚数据库, nonce可能不连续。当前设计依赖UTXO模型的事务性来保证原子性。

### 6.2 地址生成 (`evm_utils::GenerateContractAddrEth`)

```
1. nonce = GetNextNonce(from) = deployedCount + 1
2. sender_bytes = HexToBytes(from) // 20字节
3. rlp_data = RLP([sender_bytes, nonce])
4. contract_addr = Keccak256(rlp_data)[12:32]
```

这与以太坊EIP-161完全兼容。

### 6.3 部署者映射

| 查询方向 | Key | Value |
|---------|-----|-------|
| 部署者→合约 | `EVM_DEPLOYER:{deployerAddr}` | `[contractAddr1, contractAddr2, ...]` |
| 合约→部署hash | `EVM_DEPLOY:{contractAddr}` | `deployTxHash` |
| 合约→最新utxo | `EVM_UTXO:{contractAddr}` | `latestUtxoHash` |

---

## 7. Gas相关存储

### 7.1 动态基础费用

`baseFee`不存储在RocksDB中, 而是从链上历史交易推导:

```cpp
// contract.cpp:708-822 VerifyContractBaseFee
// 1. 从top高度向下遍历区块, 找到fromAddr最后一笔合约交易
// 2. 从txInfo["baseFee"]提取old_baseFee
// 3. 计算new_baseFee, 写入新交易的txInfo["baseFee"]
```

**风险**: 每次调用的O(block_count)遍历开销大。建议增加专门的baseFee缓存Key。

### 7.2 Gas销毁虚拟地址

| 虚拟地址 | 用途 |
|---------|------|
| `VirtualBurnGas` | 通用Gas销毁 |
| `VirtualDeployContractBurnGas` | 部署Gas销毁 |
| `VirtualCallContractBurnGas` | 调用Gas销毁 |
| `VirtualCallFlowOutBurnGas` | FlowOut调用Gas销毁 |

---

## 8. 预编译结果缓存

### 8.1 数据结构 (`precompiles_cache.cpp`)

```cpp
class Cache {
    // 每个预编译ID一个独立的unordered_map
    array<unordered_map<hash256, optional<bytes>>, NumPrecompiles> m_cache;
};
```

### 8.2 缓存键

- Key: `keccak256(input)` (以太坊兼容)
- Value: 执行结果bytes (成功) 或 nullopt (失败)
- 排除: `identity` (0x04) 不缓存

### 8.3 持久化

支持环境变量驱动的持久化(仅用于测试/调试):
- `EVMONE_PRECOMPILES_STUB`: 从JSON文件加载缓存
- `EVMONE_PRECOMPILES_DUMP`: 退出时导出缓存到JSON

### 8.4 缓存生命周期

全局静态变量, 进程生命周期内有效。不跨进程共享。
