# 模块10: RPC服务层 — 存储模型

> **可信度**: 高 — RPC层自身无独立存储，本文档说明其数据访问模式
> **分析日期**: 2026-05-26

---

## 一、RPC层的存储定位

RPC层本身**不持有任何持久化存储**。所有数据通过以下方式获取：

```
RPC处理函数
    │
    ├── 查询类: 直接调用 DBReader (只读RocksDB)
    │   - GetBalance → DBReader::getBalanceByAddr
    │   - GetBlockByHash → DBReader::getBlockByBlockHash
    │   - GetTransactionByHash → DBReader::getTransactionByHash
    │
    ├── 构造类: 调用TxHelper → CA层 → DB
    │   - CreateTransaction → TxHelper → 构造CTransaction对象
    │   - 不直接写DB，返回交易JSON给调用方
    │
    └── 提交类: 调用net/Send → TransactionCache → DB
        - SendMessage → 交易入池 → 打包 → 写入DB
        - SendContractMessage → 合约交易入池 → 打包 → 写入DB
```

---

## 二、各接口的数据访问模式

### 2.1 POST查询接口 (只读)

| 接口 | DB Key前缀 | 操作类型 |
|------|-----------|---------|
| GetBalance | `BAL:{addr}:{asset}` | Get |
| GetBlockHeight | `TOP` | Get |
| GetBlockByHash | `B:{hash}` | Get |
| GetBlockByHeight | `BH:{height}` → `B:{hash}` | Get + 遍历 |
| GetTransactionByHash | `TX:{txHash}` | Get |
| GetStakingUtxo | `STAKE:{addr}:{asset}` | Get + 遍历 |
| GetDelegatingUtxo | `DELEG:{bonus}:{from}:{asset}` | Get + 遍历 |
| GetLockUtxo | `LOCK_UTXO:{addr}:{asset}` | Get + 遍历 |
| GetVoteAddrs | `APPROVE:{asset}`, `AGAINST:{asset}` | Get + 遍历 |
| GetBonusInfo | `SIGN:{period}:{addr}` | Get + 遍历 |
| GetNodeList | PeerNode (内存) | 内存查找 |
| IsContract | `EVM_CODE:{addr}` | Exists检查 |

### 2.2 POST创建接口 (构造交易，不直接写DB)

| 接口 | 读取的DB数据 | 返回 |
|------|-------------|------|
| CreateTransaction | UTXO集合 (UAH:) | 已签名交易JSON |
| CreateStakingTransaction | UTXO + STAKE_ADDR | 已签名交易JSON |
| CreateDelegatingTransaction | UTXO + DELEG_ADDR | 已签名交易JSON |
| CreateCallContractTransaction | UTXO + EVM_CODE: | 已签名交易JSON + 合约消息 |
| CreateDeployContractTransaction | UTXO | 已签名交易JSON + 合约消息 |
| CreateVoteTransaction | UTXO + VOTE_TX: + LOCK_UTXO: | 已签名交易JSON |
| CreateLockTransaction | UTXO | 已签名交易JSON |

### 2.3 POST提交接口 (将交易入池)

| 接口 | 操作 | 后续 |
|------|------|------|
| SendMessage | → TransactionCache::addTx | CA线程打包→写入DB |
| SendContractMessage | → ContractDispatcher | 依赖检查→打包→写入DB |

---

## 三、GET调试接口的访问模式

| 接口 | 数据来源 | 说明 |
|------|---------|------|
| /block | DBReader + HTML渲染 | 返回格式化HTML |
| /get_block | DBReader + JSON序列化 | 返回JSON区块数据 |
| /account | DBReader + 遍历 | 遍历所有UTXO计算余额 |
| /Node | PeerNode (内存) | 节点信息 |
| /pub | Benchmark (内存) + PeerNode | 线程统计 + 请求统计 |
| /ShowVRFInfo | VRF (内存) | VRF验证信息 |
| /SystemInfo | 系统调用 (/proc, sysinfo) | CPU/内存/磁盘/网络 |
| /printVoteInfo | DBReader (VOTE_TX:, PROPOSAL:) | 投票统计 |
| /printLockAddrs | DBReader (LOCK_ADDR, LOCK_UTXO:) | 锁定地址和UTXO |
| /GetRollbackBlocks | DBReader | 回滚区块信息 |

---

## 四、无持久化存储的组件

以下RPC层使用的数据完全在内存中，不持久化：

| 组件 | 存储位置 | 说明 |
|------|---------|------|
| HTTP路由表 | `http_api.cpp` 静态注册 | 编译时固定 |
| 请求统计 | Benchmark 全局单例 | 运行时统计，重启丢失 |
| 节点列表 | PeerNode 全局单例 | 通过P2P网络动态维护 |
| VRF验证信息 | VRF/VRFConsensusNode 单例 | 每个周期更新 |
| 参数缓存 | ParamHandle (请求级别) | 请求结束后释放 |

---

## 五、ETH兼容接口的精度转换存储

ETH兼容接口面临的主要存储问题是精度转换：

| 操作 | 内部(10^8) | ETH(10^18) | 转换 |
|------|-----------|-----------|------|
| eth_getBalance 输入 | 地址 | 地址 | 无转换 |
| eth_getBalance 输出 | balance (÷10^8) | balance × 10^10 | 乘10^10 |
| eth_sendRawTransaction value | value ÷ 10^10 | value | 除10^10 |
| eth_call value | value ÷ 10^10 | value | 除10^10 |

精度转换位于 `rpc/eth/eth_impl.cpp` 中，注意溢出风险（uint64_t × 10^10 可能超过 64 位范围）。
