# 模块10: RPC服务层 — 重构建议与优先级

> **可信度**: 高 — 基于完整源码和规范文档
> **分析日期**: 2026-05-26

---

## 一、重构优先级矩阵

| 优先级 | 问题 | 工时 | 影响范围 |
|--------|------|------|---------|
| P0 | 修复参数校验安全漏洞 | 3人日 | 所有POST接口 |
| P1 | 拆分 http_api.cpp (223KB) | 5人日 | api/interface/ |
| P1 | ETH接口补全与规范化 | 3人日 | rpc/eth/ |
| P2 | 统一GET/POST命名规范 | 2人日 | rpc/api/ |
| P2 | RPC接口与CA层解耦 | 3人日 | rpc/ ↔ ca/ |
| P2 | RPC错误码体系完善 | 2人日 | rpc/error/ |
| P3 | 添加RPC限流机制 | 2人日 | api/interface/ |
| P3 | GET接口统一返回格式 | 1人日 | rpc/api/get/ |
| **合计** | | **21人日** | |

---

## 二、详细重构方案

### 2.1 P0: 参数校验安全漏洞

**现状**: POST接口的参数校验分散在各 `rpc_api_*.cpp` 的 `checkParams()` 方法中。但根据UTXO模块分析，多数 `checkParams()` 方法为空函数体或返回true。

**风险**:
- 注入攻击: 地址、hash等字符串参数未做长度和格式校验
- 整数溢出: amount参数未做范围检查
- 空指针: 未检查必要参数是否存在

**重构方案**:
1. 在 `ParamHandle` 中添加统一的白名单校验:
   - 地址: 40字符, 十六进制, 可选EIP-55校验
   - Hash: 64字符, 十六进制
   - Amount: 正整数, ≤ uint64_max
   - AssetType: 已知的资产类型列表
2. 为每种交易类型实现 `checkParams()` (当前多数为空)
3. 在 `http_api.cpp` 入口处添加请求大小限制

**预估工时**: 3人日

---

### 2.2 P1: 拆分 http_api.cpp (223KB)

**现状**: `api/interface/http_api.cpp` (~223KB) 集中了所有HTTP路由注册和RPC请求分发。

**拆分方案**:

```
api/interface/
├── http_api.cpp           (~30KB) 主入口 + 公共处理
├── routes_block.cpp       (~20KB) 区块相关路由
├── routes_tx.cpp          (~30KB) 交易创建路由
├── routes_query.cpp       (~30KB) 查询路由(余额/交易/UTXO)
├── routes_vote.cpp        (~25KB) 投票/提案/锁定路由
├── routes_contract.cpp    (~30KB) 合约部署/调用路由
├── routes_eth.cpp         (~30KB) ETH兼容路由分发
└── routes_debug.cpp       (~28KB) GET调试接口路由
```

**拆分原则**:
- 保持不变: `HttpServer::RegisterCallback()` 调用分散到各文件
- 每个文件提供 `void register_xxx_routes(HttpServer&)` 函数
- `http_api.cpp` 中按顺序调用各注册函数

**预估工时**: 5人日

---

### 2.3 P1: ETH接口补全与规范化

**现状**: 当前实现16个ETH方法，但部分实现不完整。

**缺失的标准ETH方法**:
- `eth_getLogs` — 日志查询（支持Bloom过滤器）
- `eth_getTransactionByBlockHashAndIndex`
- `eth_getTransactionByBlockNumberAndIndex`
- `eth_getStorageAt` — 合约存储读取
- `eth_getProof` — (EIP-1186)

**精度问题**:
- `eth_gasPrice` 固定返回 `0x1`，未实现动态Gas价格
- `eth_estimateGas` 实现可能不准确
- 精度转换（10^8↔10^18）使用uint64_t可能溢出

**重构方案**:
1. 优先实现 `eth_getLogs` 和 `eth_getStorageAt`（MetaMask常用）
2. eth_gasPrice 返回实际动态Gas价格
3. 精度转换使用 uint256 或 boost::multiprecision 避免溢出

**预估工时**: 3人日

---

### 2.4 P2: 统一命名规范

**现状**: 接口命名不一致:
- POST用驼峰: `GetBalance`, `CreateStakingTransaction`
- GET用小写: `/block`, `/pub`, `/account`
- 部分拼写错误: `printAsseTypeByContractAddr` (应为Asset)
- `printAvailableAssetType` vs `GetAllAssetType` 功能重叠

**重构方案**:
1. 统一POST方法名为 `namespace.method` 格式: `chain.getBalance`, `tx.createStake`
2. 统一GET路径为 `/api/v1/xxx` 格式
3. 添加旧路径到新路径的301重定向（向后兼容）
4. 修正拼写错误，废弃重复接口

**预估工时**: 2人日

---

### 2.5 P2: RPC层与CA层解耦

**现状**: RPC处理函数直接调用CA层的具体实现类（TxHelper, BlockHelper, etc），耦合紧密。

**重构方案**:
1. 定义 `IServiceLayer` 接口，提供所有RPC需要的操作
2. CA层实现该接口
3. RPC层通过接口调用，而非直接包含CA头文件
4. 便于未来替换实现或mock测试

**预估工时**: 3人日

---

### 2.6 P2: 错误码体系完善

**现状**: 错误码分散在 `rpc/rpc_error.h`、`rpc/error/error.h`、`api/rpc_error.h` 中，缺乏统一管理。

**重构方案**:
1. 统一错误码定义到一个文件 `rpc/error_codes.h`
2. 按功能域分类错误码: 1xxx=通用, 2xxx=交易, 3xxx=合约, 4xxx=投票, 5xxx=质押
3. 每个接口的错误返回值标准化

**预估工时**: 2人日

---

### 2.7 P3: 添加RPC限流

**现状**: HTTP服务器无请求限流机制。

**重构方案**:
1. 在 httplib 层面添加中间件
2. 按IP限流: 每秒最多N个请求
3. 按方法限流: 交易创建接口更严格限制
4. IP白名单: 本地/内部IP不限流

**预估工时**: 2人日

---

### 2.8 P3: GET接口统一返回格式

**现状**: GET接口返回格式不统一:
- `/block` → HTML
- `/get_block` → JSON
- `/account` → HTML
- `/pub` → HTML
- `/SystemInfo` → Plain text

**重构方案**:
1. 所有GET接口支持 `?format=json|html|text` 参数
2. 默认格式保持不变（向后兼容）
3. JSON格式返回结构化的机器可读数据

**预估工时**: 1人日

---

## 三、实施路线图

```
第1周: P0参数校验修复 + P1 http_api.cpp拆分开始
第2周: P1 http_api.cpp拆分完成 + P2命名规范统一
第3周: P1 ETH接口补全 + P2 解耦 + P2 错误码
第4周: P3 限流 + P3 GET格式统一
```

---

## 四、当前质量评估

| 维度 | 评分 | 说明 |
|------|------|------|
| 接口完整性 | 7/10 | 基本功能覆盖，ETH部分方法缺失 |
| 参数校验 | 3/10 | 多数checkParams()为空，存在安全风险 |
| 代码结构 | 4/10 | http_api.cpp 223KB单文件是最大问题 |
| 命名一致性 | 5/10 | GET/POST命名风格不统一，有拼写错误 |
| 错误处理 | 5/10 | 错误码分散，GET接口错误格式不统一 |
| 文档 | 8/10 | 有完整的GET/POST API文档，与代码基本一致 |
| 并发安全 | 7/10 | httplib提供多线程模型，但需关注DB竞争 |
