# 模块10：RPC 服务层 -- 核心类分析

**可信度**: 高

---

## 1. 类层次总览

```
RpcDataBase (rpc/rpc_data_base.h:45-49)
├── ReqDataBase (rpc/rpc_data_base.h:51-54)
│   └── GetBalanceParam, TransactionParam, StakeParam, ... (rpc/param_handle.h)
└── AckDataBase (rpc/rpc_data_base.h:56-59)
    └── GetBalanceResult, TransactionResult, ... (rpc/result_handle.h)

Header_req  (rpc/rpc.h:23-31)  -- 请求头 {id, jsonrpc, method}
Header_res  (rpc/rpc.h:33-39)  -- 响应头 {id, jsonrpc}

Req  (rpc/rpc.h:42-126)  -- 完整请求 {header, params}
Ack  (rpc/rpc.h:128-203) -- 完整响应 {header, result, status}

HttpServer (net/http_server.h:35-91) -- HTTP服务器 + 路由注册

eth_req_header (rpc/eth/eth.h:10-35) -- ETH请求头
eth_res_header (rpc/eth/eth.h:78-91)  -- ETH响应头
eth_errors (rpc/eth/eth.h:39-51)      -- ETH错误结构
```

---

## 2. RpcDataBase 及子类 (rpc/rpc_data_base.h)

### 2.1 设计意图

提供多态基类，使 `Req` 和 `Ack` 可以通过 `dynamic_cast` 进行类型安全的下行转换。

```cpp
// rpc/rpc_data_base.h:45-59
class RpcDataBase { public: virtual ~RpcDataBase(){} };

class ReqDataBase : public RpcDataBase { public: virtual ~ReqDataBase(){} };

class AckDataBase : public RpcDataBase { public: virtual ~AckDataBase(){} };
```

### 2.2 DEFAULT_VALUE_TYPE 宏

```cpp
// rpc/rpc_data_base.h:33-35
#define DEFAULT_VALUE_TYPE(T) \
    using defualt_type=bool;  \
    T get_defualt_value()
```

注意：宏名有拼写错误 (`defualt`)，但不影响功能。此宏使类提供默认值方法，用于API文档生成时的示例值。`TransactionParam` (param_handle.h:278-283) 等类使用了此宏。

### 2.3 设计评价

- **优点**: 简单的多态设计，清晰的请求/响应/数据三层分离
- **缺点**: 使用 `dynamic_cast` 存在运行时类型安全风险（性能开销+无效转换导致异常）
- **可信度**: 高

---

## 3. Req 与 Ack -- 请求/响应容器 (rpc/rpc.h)

### 3.1 Req 类 (rpc/rpc.h:42-126)

核心职责：JSON解析 + 参数类型检查

```cpp
class Req {
public:
    Header_req header;
    ReqDataBase *params = nullptr;  // 原始指针，需要手动管理

    ~Req() { if(params != nullptr) { delete params; } }  // 析构函数释放

    template <typename T>
    T* GetParams() {
        // 通过dynamic_cast转换参数类型
        T* obj = dynamic_cast<T*>(params);
        if(obj == nullptr) throw std::runtime_error("wrong params type");
        return obj;
    }

    // 方法1: 解析JSON字符串
    expected<int> parse(const std::string &v);

    // 方法2: 解析httplib请求 + 方法名校验 + 参数解析
    template <typename T>
    expected<int> parse(const httplib::Request &request);
};
```

**关键流程** (rpc/rpc.h:83-125):
1. 解析 `request.body` 为 nlohmann::json
2. 使用 `reflect::Deserialize` 反序列化 header
3. 检查 `header.method` 是否与 `T::method_name` 一致
4. 检查 `params` 字段是否存在
5. 创建 `T` 实例，调用 `T::parse(json["params"])`
6. 返回解析结果

**设计评价**:
- `GetParams` (rpc/rpc.h:54-65): 使用`throw`抛出异常，调用方需要try-catch，但现有代码(如rpc_api_getBalance.cpp:31)未捕获，若转换失败会导致进程终止
- **风险**: dynamic_cast失败时抛出`std::runtime_error`，如果未捕获会崩溃
- 可信度：高

### 3.2 Ack 类 (rpc/rpc.h:128-203)

```cpp
class Ack {
public:
    Header_res header;
    AckDataBase *result = nullptr;

    ~Ack() { if(result != nullptr) { delete result; } }

    template <typename T> T* GetResult();  // dynamic_cast转换

    template <typename T> expected<int> respond();  // 创建result实例

    const char *RESULT = "result";
    std::string code = "0";
    std::vector<std::string> errorCallstack{"success"};

    // 从expected类型提取完整错误链
    template <typename T> void getAllErrors(const expected<T> &e);

    // 将响应转为JSON字符串
    template <typename T>
    std::string toJsonString(const std::string &id);
};
```

**toJsonString序列化逻辑** (rpc/rpc.h:182-202):
1. 设置 `header.id = id`
2. 序列化header和status
3. 调用 `result->toJson()` 获取结果数据
4. 组装为 `{header..., "result": result_json, "status": status_json}`
5. 返回 `header_json.dump()`

**设计评价**:
- 错误码硬编码为 "0"/"success" 初始化值，与实际错误设置存在不一致风险
- 序列化方案因将status和header信息混合于同一JSON对象，与标准JSON-RPC 2.0冲突
- 可信度：高

### 3.3 Header_req 与 Header_res (rpc/rpc.h:23-39)

```cpp
class Header_req {
    std::string id = "1";
    std::string jsonrpc = "2.0";
    std::string method;
    REFLECT(id, jsonrpc, method);
};

class Header_res {
    std::string id = "1";
    std::string jsonrpc = "2.0";
    REFLECT(id, jsonrpc);
};
```

简洁的头信息载体。

---

## 4. ParamHandle -- 参数处理 (rpc/param_handle.h + rpc/param_handle.cpp)

### 4.1 架构

每个POST方法对应一个Param类，继承自 `ReqDataBase`，包含：
- `static constexpr char *method_name` -- 方法名标识
- RPC参数成员变量
- `REFLECT(...)` 宏 -- 自动序列化
- `parse(const nlohmann::json&)` -- 自定义校验逻辑
- `toJson()` -- 序列化为JSON（用于文档/调试）

### 4.2 典型实现分析 -- GetBalanceParam

```cpp
// param_handle.h:31-46
class GetBalanceParam : public ReqDataBase {
    static constexpr char *method_name = "GetBalance";
    std::string addr;
    std::string asset_type;
    REFLECT(addr, asset_type);

    expected<int> parse(const nlohmann::json &json);
};

// param_handle.cpp:18-50
expected<int> GetBalanceParam::parse(const nlohmann::json &json) {
    auto re = reflect::Deserialize(json, *this);   // 自动反序列化
    if (!re.ok) return PERROR(MEM::PARSE_JSON_FAIL, re.error.value());

    // 地址校验: 40字符十六进制
    std::string addr_without_prefix = (addr);
    if (addr_without_prefix.size() != 40) return PERROR(MEM::INVALID_ADDR);
    if (!isValidAddress(addr_without_prefix)) return PERROR(MEM::INVALID_ADDR);

    // AssetType校验
    if (!Util::isValidAssetType(asset_type)) return PERROR(MEM::INVALID_ASSET_TYPE);
    return 0;
}
```

### 4.3 典型实现分析 -- TransactionParam

```cpp
// param_handle.h:268-291
class TransactionParam : public ReqDataBase {
    std::vector<txTable> tx_table;       // 多资产转账表
    mmc::UtxoCore::OtherToPayGas gas_asset;  // Gas支付信息
    std::string encoded_info;            // 附加信息
    bool is_find_utxo = false;          // 是否查找UTXO
    bool sponsor_gas;                    // 是否代付Gas
    static constexpr char *method_name = "CreateTransaction";
};
```

其中 `txTable` 结构:
```cpp
struct txTable {
    std::string asset_type;
    std::string from_addr;
    std::vector<ToAddr> to_addrs;  // ToAddr = {addr, amount}
};
```

**校验逻辑** (param_handle.cpp:224-277): 遍历所有交易表，校验addr和asset_type格式。

### 4.4 校验覆盖度分析

| 接口 | 地址校验 | AssetType校验 | 金额校验 | Gas参数校验 |
|------|---------|--------------|---------|-------------|
| GetBalance | 有(size+format) | 有 | N/A | N/A |
| Transaction | 有 | 有 | 无(延迟到CA层) | 条件(仅sponsor_gas时) |
| Stake | 有 | 有 | 有(stringToDecimal) | 条件 |
| DeployContract | 有 | 有条件 | 无 | 条件 |
| Vote | **无** | **无** | **无** | **无** |
| PostMessage | **无** | **无** | **无** | N/A |
| UnLock | **无** | **无** | **无** | **无** |

**校验漏洞最严重的是 VoteParam** (param_handle.cpp:775-784):
```cpp
expected<int> VoteParam::parse(const nlohmann::json &json) {
    auto re = reflect::Deserialize(json, *this);
    if (!re.ok) return PERROR(MEM::PARSE_JSON_FAIL, re.error.value());
    return 0;  // 无任何业务字段校验
}
```

### 4.5 设计评价

- **优点**: 类型安全(模板+dynamic_cast)，每个方法独立校验逻辑，可读性好
- **缺点**: 
  - 校验覆盖不均（约20%的接口未做完整校验）
  - `isValidAssetType` 被用于校验hash字段，语义不匹配 (param_handle.cpp:114,132,149等)
  - 无统一校验框架，各接口重复编写相同的校验代码

---

## 5. ResultHandle -- 结果处理 (rpc/result_handle.h + rpc/result_handle.cpp)

### 5.1 架构

每个方法对应一个Result类，继承自 `AckDataBase`，包含：
- 响应数据成员变量
- `REFLECT(...)` 宏
- `toJson()` 方法
- 可选的 `DEFAULT_VALUE_TYPE` 示例值

### 5.2 典型实现

```cpp
// result_handle.h:30-38
class GetBalanceResult : public AckDataBase {
    std::string addr;
    std::string asset_type;
    std::string balance;
    REFLECT(addr, asset_type, balance);
    nlohmann::json toJson();
};
```

```cpp
// result_handle.cpp:28-35
nlohmann::json GetBalanceResult::toJson() {
    nlohmann::json json;
    auto res = reflect::Serialize(*this, json);
    return json;
}
```

所有Result的`toJson()`实现几乎相同（仅调用`reflect::Serialize`），建议可以模板化统一。

### 5.3 交易创建统一使用 TransactionResult

大部分交易创建接口（Stake/UnStake/Delegate/Vote等）统一使用 `TransactionResult`，其result字段为protobuf序列化的交易JSON字符串。少数接口（如`ContractTransResult`）有特殊返回结构。

---

## 6. HttpServer -- 路由注册机制 (net/http_server.h + net/http_server.cpp)

### 6.1 核心设计

```cpp
class HttpServer {
public:
    // 回调存储
    static std::map<const std::string, HttpCallBack> _cbs;              // HTTP路由
    static std::map<const std::string, JsonRpcCallBack> rpcCbs;         // JSON-RPC
    static std::map<std::string, ETH_RPC_FUNCTION> eth_rpc_callbacks;   // ETH RPC

    // 注册HTTP回调
    static void RegisterCallback(std::string pattern, HttpCallBack handler);

    // 注册ETH回调
    static void RegisterEthCallback(const std::pair<std::string, ETH_RPC_FUNCTION> &cb);

    // 启动HTTP服务器
    static void Start();

private:
    static void Work();  // 服务器主循环
    static std::thread _listenThread;
};
```

### 6.2 路由注册流程

所有路由在 `subscribeToHttpCallbacks()` (http_api.cpp:195-317) 中统一注册：

```
subscribeToHttpCallbacks()
├── ETH_LAMDA(eth_chainId)      -- 16个ETH回调(行199-240)
├── RegisterCallback(...)       -- ~44个POST回调(行243-292)
├── RegisterCallback(...)       -- ~18个GET回调(行295-314)
└── HttpServer::Start()         -- 启动服务器(行316)
```

### 6.3 HTTP服务器启动 (net/http_server.cpp:35-146)

```cpp
void HttpServer::Work() {
    Server svr;  // httplib::Server
    svr.set_read_timeout(30, 0);   // 30秒读超时
    svr.set_write_timeout(30, 0);  // 30秒写超时

    // HTTPS可选
    if (enableHttps) {
        SSLServer ssl_svr(...);
        // 同样注册所有回调
        ssl_svr.listen("0.0.0.0", https_port);
    }

    // 为每个callback注册GET, POST, OPTIONS
    for(auto item: _cbs) {
        auto cors_handler = cors_wrapper(item.second);
        svr.Get(item.first.c_str(), cors_handler);
        svr.Post(item.first.c_str(), cors_handler);
        svr.Options(item.first.c_str(), [](...){ /* CORS preflight */ });
    }

    svr.listen("0.0.0.0", port);  // configurable, default 8080
}
```

**关键设计点**:
- 每个URL path同时注册GET和POST处理器（同一handler处理两种HTTP方法）
- 全局CORS支持，允许所有来源
- 支持HTTPS + mTLS（需OpenSSL支持）
- 线程detach模式运行

### 6.4 ETH请求分发 (net/http_server.cpp:177-306)

```cpp
void eth_dispatch(const Request &req, Response &res) {
    // 1. 解析JSON
    req_json = nlohmann::json::parse(req.body);

    // 2. 支持批量请求（数组格式）
    if (req_json.is_array()) {
        for (auto &p : req_json) { /* 逐个处理 */ }
    }

    // 3. 单个请求处理 lambda:
    //    - 解析header
    //    - 验证params字段存在且为数组
    //    - 查找eth_rpc_callbacks
    //    - 调用回调函数
    //    - 返回结果
}
```

---

## 7. ETH RPC 处理 (rpc/eth/eth_rpc.h + eth_rpc.cpp)

### 7.1 宏定义系统

ETH RPC使用宏简化参数/返回结构定义 (rpc/eth/eth.h):

```cpp
// 有参数的方法
#define ETH_PARAM(struct_name, ...) \
struct struct_name { \
    nlohmann::json req;              // 原始请求JSON
    constexpr static const char *method = #struct_name;  // 自动方法名
    __VA_ARGS__                      // 自定义成员和parse方法
}

// 无参数的方法
#define ETH_NO_PARAM(struct_name, ...) \
struct struct_name { \
    constexpr static const char *method = #struct_name;
    nlohmann::json req;
    reflect::reflect_status parse(const nlohmann::json &j) { return {"",true}; }
}; \
struct struct_name##_ret { ... }  // 返回结构

// 返回结构
#define ETH_RET(struct_name, ...) \
struct struct_name##_ret { ... }

// Lambda回调注册
#define ETH_LAMDA(STRUCT_NAME) \
{ #STRUCT_NAME, [](const nlohmann::json& req) -> nlohmann::json { ... } }
```

### 7.2 eth_rpc.cpp 中的实现函数

每个函数签名：`nlohmann::json fun_ETH_METHOD(const ETH_METHOD &req, eth_errors &e)`

```
fun_eth_chainId       -- 返回硬编码chainId 0x3027
fun_eth_blockNumber   -- 查询DB最新高度，to__Hex转换
fun_eth_gasPrice      -- 查询近100块平均gas
fun_eth_getBalance    -- 查询余额 + scale_up_10_8_to_18
fun_eth_getTransactionCount -- 查询nonce
fun_eth_sendRawTransaction  -- RLP解码 + 签名验证 + TxHelper创建 + 广播
fun_eth_getTransactionReceipt -- 查询交易收据
fun_eth_call          -- EVM只读执行
fun_eth_getBlockByNumber -- 按区块号查询 + fullTx支持
fun_eth_getBlockByHash   -- 按区块哈希查询
fun_eth_getCode       -- 查询合约字节码
fun_eth_getTransactionByHash -- 按哈希查交易
fun_eth_estimateGas   -- 固定返回1（未实现）
fun_eth_accounts      -- 返回本地账户
fun_eth_feeHistory    -- 已定义结构但实现不完整
fun_net_version       -- 返回网络版本
fun_web3_clientVersion -- 返回客户端版本
```

### 7.3 eth_sendRawTransaction 完整流程 (eth_rpc.cpp:236-390+)

1. **RLP解码**: `verifyRLP(_responseStr, e, &ethTx)` 解析交易数据
2. **签名验证**: 从RLP中提取v/r/s，恢复from地址
3. **精度转换**: `scale_down_10_18_to_8(ethTx.value)`
4. **类型判断**:
   - `to`为空 -> 部署合约(DEPLOY) -> `TxHelper::createEvmDeployContractTransactionRequest()`
   - `to`为合约地址 -> 调用合约(CALL) -> `TxHelper::createEvmCallContractTransactionRequest()`
   - `to`为普通地址 -> 普通转账(TX) -> `TxHelper::createEvmTransactionRequest()`
5. **签名与哈希**: `SigTx(outTx, "")` 签名交易
6. **广播**: `dropCallShippingRequest()` 广播到网络
7. **缓存**: 如果依赖未满足，通过 `ContractTransactionCache` 缓存待后续重发

---

## 8. rpc_create_transaction -- 交易创建请求处理

`api/interface/rpc_create_transaction.h` 整个文件被注释掉，所有函数体被注释。该模块的功能已迁移到各 `rpc/api/post/rpc_api_*.cpp` 文件中的具体实现（如 `rpc_api_Transaction.cpp`, `rpc_api_stake.cpp` 等）。

当前交易创建流程 (以createTransaction为例，rpc/api/post/rpc_api_Transaction.cpp:15-98):
1. 创建Req/Ack容器
2. 调用 `rpc_handle_requese<TransactionParam, TransactionResult>` 解析请求
3. 参数校验 (UTXO选择、金额合法性)
4. 构造 `TransforerTransParam` 对象
5. 调用 `TransforerTrans::trans()` 执行交易构造
6. 将protobuf交易对象序列化为JSON返回

### 8.1 通用模板函数 rpc_handle_requese (rpc/api/post/rpc_handle_requese.h)

```cpp
template <typename REQ_TYPE, typename ACK_TYPE>
expected<int> rpc_handle_requese(const httplib::Request &request,
                                  mmc::rpc::Req &req, mmc::rpc::Ack &ack) {
    expected<int> ackRet = ack.respond<ACK_TYPE>();  // 创建result实例
    expected<int> reqRet = req.parse<REQ_TYPE>(request);  // 解析请求
    if(!reqRet.isOk()) return reqRet;
    return reqRet;
}
```

这是所有POST接口的统一入口。先创建响应对象，再解析请求，确保即使解析失败也能返回格式正确的错误响应。

---

## 9. 错误处理体系

### 9.1 分层错误码

| 层次 | 定义文件 | 错误范围 | 示例 |
|------|---------|---------|------|
| RPC解析 | errorn/rpc/error.def.h | 解析/序列化/字段 | PARSE_JSON_FAIL, MISSING_JSON_FIELD |
| 全局通用 | errorn/global/error.def.h | 地址/资产/Hash | INVALID_ADDR, INVALID_ASSET_TYPE, INVALID_HASH |
| CA/UTXO | errorn/ca/error.def.h | 业务逻辑 | (在ca/transaction/error.h或类似文件中) |
| RPC业务 | rpc/error/error.h | RPC特定 | 委托自errorn模块 |

### 9.2 MEM错误系统

使用 `MEM` 命名空间的 `PERROR` 宏创建错误链 (rpc/error/error.h + utils/uerror/expected.h):
```cpp
ret.push(PERROR(MEM::INVALID_ADDR));
ret << PERROR(MEM::PARSE_JSON_FAIL);
```

错误支持链式传播，`getAllErrors` 提取完整调用栈到 `errorCallstack` 向量。

### 9.3 线程局部错误 (api/rpc_error.cpp)

```cpp
static thread_local std::pair<std::string, std::string> error = {"0", ""};
static thread_local bool isGet = true;

void SetRpcError(const std::string &errorCode, const std::string &errorMessage);
std::pair<std::string, std::string> GetRpcError();
```

使用 `thread_local` 存储错误状态，`isGet` 标志检测错误是否被正确处理（未Get就直接覆盖会打印ERRORLOG警告）。这是一个独立的错误通道，与MEM错误系统并存。

### 9.4 ETH错误 (rpc/eth/eth.h:39-51)

```cpp
struct eth_errors {
    int code;
    std::string message;
    std::string data;
    bool ok = true;
};
```

ETH错误直接通过函数参数 `eth_errors &e` 传递，与自定义RPC的expected错误链机制隔离。

---

## 10. 问题清单

| 位置 | 现象 | 风险等级 | 修复建议 |
|------|------|---------|---------|
| rpc/rpc.h:54-65 | GetParams/GetResult dynamic_cast失败时throw未捕获 | 高 | 改用返回nullptr或expected模式 |
| rpc/param_handle.cpp:775-784 | VoteParam::parse()零校验 | 高 | 添加addr和vote_hash格式校验 |
| rpc/param_handle.cpp:114 | isValidAssetType校验hash字段(语义错误) | 中 | 添加专用isValidHash函数 |
| rpc/result_handle.cpp | 所有toJson()实现完全相同(repeat) | 低 | 使用模板或基类默认实现 |
| api/interface/rpc_create_transaction.h | 整个文件被注释(L183行) | 低 | 清理死代码或归档 |
| api/rpc_error.cpp:4-5 | thread_local错误状态与MEM错误系统并存 | 中 | 统一为一种错误处理机制 |
| rpc/rpc.h:199-201 | toJsonString输出格式非标准JSON-RPC 2.0 | 中 | 提供标准格式选项 |
