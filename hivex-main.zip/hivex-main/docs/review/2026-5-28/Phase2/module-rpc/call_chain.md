# 模块10：RPC 服务层 -- 调用链分析

**可信度**: 高

---

## 1. POST 请求完整调用链

### 1.1 流程图

```mermaid
sequenceDiagram
    participant Client as 外部客户端
    participant HTTP as httplib Server<br/>(net/http_server.cpp)
    participant Route as HttpServer路由
    participant Handler as RPC Handler<br/>(rpc/api/post/*.cpp)
    participant ReqAck as Req/Ack容器<br/>(rpc/rpc.h)
    participant Param as ParamHandle<br/>(rpc/param_handle.cpp)
    participant CA as CA层<br/>(TxHelper/DBReader)
    participant Result as ResultHandle<br/>(rpc/result_handle.cpp)

    Client->>HTTP: POST /GetBalance<br/>{"header":{...},"params":{...}}
    HTTP->>Route: 路由匹配: _cbs["/GetBalance"]
    Note over Route: http_api.cpp:244<br/>RegisterCallback("/GetBalance", getBalance)

    Route->>Handler: getBalance(req, res)<br/>(rpc/api/post/rpc_api_getBalance.cpp:12)

    Handler->>ReqAck: Req req; Ack ack;<br/>ON_SCOPE_EXIT{...}

    Handler->>ReqAck: rpc_handle_requese<br/><GetBalanceParam, GetBalanceResult>(request, req, ack)
    Note over ReqAck: rpc_handle_requese.h:10

    ReqAck->>ReqAck: ack.respond<GetBalanceResult>()<br/>创建result实例

    ReqAck->>ReqAck: req.parse<GetBalanceParam>(request)<br/>rpc/rpc.h:83-125

    Note over ReqAck: 1. JSON.parse(request.body)
    Note over ReqAck: 2. Deserialize header
    Note over ReqAck: 3. 检查 method == "GetBalance"
    Note over ReqAck: 4. 检查 "params" 字段存在
    Note over ReqAck: 5. params = new GetBalanceParam()

    ReqAck->>Param: params->parse(json["params"])<br/>param_handle.cpp:18-50
    Note over Param: 1. reflect::Deserialize(json, *this)
    Note over Param: 2. 地址长度=40校验
    Note over Param: 3. isValidAddress()校验
    Note over Param: 4. isValidAssetType()校验

    Param-->>ReqAck: return 0 (成功)

    ReqAck-->>Handler: return reqRet (解析完成)

    Handler->>ReqAck: param = req.GetParams<GetBalanceParam>()
    Handler->>ReqAck: result = ack.GetResult<GetBalanceResult>()

    Handler->>CA: DBReader.getBalanceByAddr(addr, asset_type, balance)
    Note over CA: 查询RocksDB<br/>Key: BALANCE_PREFIX + addr + asset_type

    CA-->>Handler: balance int64_t

    Handler->>Result: result->addr = param->addr<br/>result->asset_type = param->asset_type<br/>result->balance = std::to_string(balance)

    Handler->>ReqAck: ack.getAllErrors(ret)
    Note over ReqAck: 提取错误链到 errorCallstack

    Handler->>ReqAck: ack.toJsonString<GetBalanceResult>(req.header.id)
    Note over ReqAck: 1. 序列化header
    Note over ReqAck: 2. 序列化status(callstack)
    Note over ReqAck: 3. result->toJson()
    Note over ReqAck: 4. 组装: {header, result, status}

    ReqAck-->>Handler: JSON字符串

    Handler->>HTTP: response.set_content(json, "application/json")

    HTTP-->>Client: HTTP 200 OK<br/>{"id":"1","jsonrpc":"2.0",<br/>"result":{"addr":"...","balance":"1000"},<br/>"status":{"code":"0","errorCallstack":["success"]}}
```

### 1.2 代码位置映射

| 步骤 | 文件:行号 | 关键函数 |
|------|----------|---------|
| HTTP接收 | net/http_server.cpp:110-115 | httplib Server::listen |
| 路由分发 | net/http_server.h:65-68 | RegisterCallback |
| Handler入口 | rpc/api/post/rpc_api_getBalance.cpp:12 | getBalance |
| 请求解析 | rpc/api/post/rpc_handle_requese.h:10-21 | rpc_handle_requese |
| JSON解析 | rpc/rpc.h:83-125 | Req::parse<T> |
| 参数校验 | rpc/param_handle.cpp:18-50 | GetBalanceParam::parse |
| 业务调用 | rpc/api/post/rpc_api_getBalance.cpp:59 | DBReader::getBalanceByAddr |
| 结果序列化 | rpc/rpc.h:182-202 | Ack::toJsonString |
| HTTP响应 | rpc/api/post/rpc_api_getBalance.cpp:21 | response.set_content |

---

## 2. GET 请求完整调用链

### 2.1 流程图

```mermaid
sequenceDiagram
    participant Client as 浏览器/curl
    participant HTTP as httplib Server
    participant Handler as GET Handler<br/>(rpc/api/get/*.cpp)
    participant DB as DBReader
    participant AuxFunc as 辅助函数<br/>(print_blocks_hash等)

    Client->>HTTP: GET /block?html=true&num=50&height=1000

    HTTP->>Handler: getBlock(req, res)<br/>(rpc/api/get/rpc_api_getBlock.cpp:7)

    Note over Handler: 解析URL参数:<br/>num=50, height=1000, html=true
    Handler->>Handler: request.has_param("num")<br/>request.get_param_value("num")

    alt html_format == true
        Note over Handler: 构造HTML响应<br/>内联CSS样式<br/>迭代区块数据

        Handler->>DB: dbReader.getBlockTop(top)
        DB-->>Handler: top height

        loop i = height to height-num
            Handler->>DB: getBlockHashsByBlockHeight(i, blockHashs)
            DB-->>Handler: hash list

            loop each blockHash
                Handler->>DB: getBlockByBlockHash(hash, strHeader)
                DB-->>Handler: block protobuf data

                Handler->>Handler: block.ParseFromString(strHeader)
                Note over Handler: 检查是否为合约区块<br/>(DEPLOY/CALL类型交易)
            end
        end

        Handler->>HTTP: response.set_content(html_str, "text/html")

    else hash mode
        Handler->>AuxFunc: print_blocks_hash(num, pre_hash_flag)
        AuxFunc-->>Handler: plain text
        Handler->>HTTP: response.set_content(str, "text/plain")

    else range mode
        Handler->>AuxFunc: print_range_contract_blocks(startNum, num, pre_hash_flag)
        AuxFunc-->>Handler: plain text
        Handler->>HTTP: response.set_content(str, "text/plain")
    end

    HTTP-->>Client: HTTP 200 OK<br/>HTML/Plain/JSON 内容
```

### 2.2 关键特征

- **无统一框架**: GET接口无Req/Ack抽象，直接操作httplib的Request/Response对象
- **URL参数解析**: 通过 `request.has_param()` 和 `request.get_param_value()` 获取参数，参数名在HTML和plain模式间可能不一致
- **多格式响应**: `/block` 端点支持三种输出格式：HTML(调试浏览器)、Plain(哈希列表)、Range(范围区块)
- **直连DB层**: GET接口绕过CA层事务管理，直接使用DBReader查询RocksDB

### 2.3 代码位置映射

| 步骤 | 文件:行号 | 关键函数 |
|------|----------|---------|
| HTTP接收 | net/http_server.cpp:113 | svr.Get(pattern, cors_handler) |
| GET Handler | rpc/api/get/rpc_api_getBlock.cpp:7 | getBlock |
| URL参数解析 | rpc/api/get/rpc_api_getBlock.cpp:10-24 | has_param / get_param_value |
| HTML渲染 | rpc/api/get/rpc_api_getBlock.cpp:28-120 | 内联HTML构造 |
| 区块查询 | rpc/api/get/rpc_api_getBlock.cpp:57-113 | DBReader调用链 |
| 辅助函数1 | rpc/api/get/rpc_api_moonMeshChain.cpp | print_blocks_hash |
| 辅助函数2 | rpc/api/get/rpc_api_moonMeshChain.cpp | DisplayContractSections |
| 辅助函数3 | rpc/api/get/rpc_api_moonMeshChain.cpp | print_range_contract_blocks |

---

## 3. ETH 请求完整调用链

### 3.1 流程图

```mermaid
sequenceDiagram
    participant Client as MetaMask/Web3.js/Hardhat
    participant HTTP as httplib Server
    participant Dispatch as eth_dispatch<br/>(net/http_server.cpp:177)
    participant Parse as eth_req_header<br/>(eth.h:10-35)
    participant Route as eth_rpc_callbacks map
    participant Impl as fun_eth_* 实现<br/>(eth_rpc.cpp)
    participant ETHImpl as eth_impl<br/>(eth_impl.cpp)
    participant CA as CA/DB/EVM层

    Client->>HTTP: POST /<br/>{"jsonrpc":"2.0","method":"eth_getBalance",<br/>"params":["0xaddr...","latest"],"id":1}

    HTTP->>Dispatch: eth_dispatch(req, res)

    Dispatch->>Dispatch: req_json = nlohmann::json::parse(req.body)

    Dispatch->>Parse: req_header.parse(json_p)
    Note over Parse: 1. 处理id(数字/字符串)
    Note over Parse: 2. Deserialize jsonrpc, method
    Parse-->>Dispatch: parse status

    Dispatch->>Dispatch: 检查 params 字段是否存在
    Dispatch->>Dispatch: 检查 params 是否为数组格式

    Dispatch->>Route: HttpServer::eth_rpc_callbacks.find("eth_getBalance")
    Note over Route: 在http_api.cpp:203注册

    Route->>Impl: callback(req_json)
    Note over Impl: ETH_LAMDA宏展开的lambda

    Impl->>Impl: req_obj.parse(req["params"])
    Note over Impl: eth_getBalance: parse数组前两个元素

    Impl->>Impl: fun_eth_getBalance(req_obj, er)

    Impl->>ETHImpl: eth_getBalance_impl(address, e, balance)
    Note over ETHImpl: 查询DB: getBalanceByAddr

    ETHImpl->>CA: DBReader.getBalanceByAddr(addr, asset_type, balance)
    CA-->>ETHImpl: balance (int64_t, 10^8精度)

    ETHImpl->>ETHImpl: scale_up_10_8_to_18(balance)
    Note over ETHImpl: amount * 10^10 = 10^18精度<br/>转换为十六进制字符串<br/>带0x前缀
    
    ETHImpl-->>Impl: "0x..." (hex string)

    Impl->>Impl: ret.ret_header.make(ret)
    Note over Impl: 组装JSON: {jsonrpc, result, id}

    Impl-->>Dispatch: nlohmann::json response

    Dispatch->>Dispatch: 支持批量: 数组请求逐个处理并拼接

    Dispatch->>HTTP: res.set_content(r, "application/json")

    HTTP-->>Client: {"jsonrpc":"2.0","result":"0xde0b6b3a7640000","id":1}
```

### 3.2 精度转换详解

```
                         sendRawTransaction (ETH→MM)
                         ┌──────────────────────────────────┐
Client (10^18 hex)       │  scale_down_10_18_to_8(bytes)     │  MM内部 (10^8 uint64)
"0xde0b6b3a7640000"      │  bytes→uint128→÷10^10→uint64      │  1000000000
(1 ETH in wei)           └──────────────────────────────────┘

                         eth_getBalance (MM→ETH)
                         ┌──────────────────────────────────┐
MM内部 (10^8 int64)      │  scale_up_10_8_to_18(amount)       │  Client (10^18 hex)
100000000                 │  int64→uint128→×10^10→hex         │  "0xde0b6b3a7640000"
=========================│===================================│==========================
```

### 3.3 eth_sendRawTransaction 特殊处理 (eth_rpc.cpp:236-390+)

```mermaid
sequenceDiagram
    participant Client as 客户端
    participant Impl as fun_eth_sendRawTransaction
    participant RLP as verifyRLP
    participant Scale as scale_down
    participant TxH as TxHelper
    participant Sig as SigTx
    participant Net as 网络广播
    participant Cache as ContractTransactionCache

    Client->>Impl: signed raw tx (RLP encoded hex)

    Impl->>Impl: dev::fromHex(raw_data) → bytes
    Impl->>RLP: verifyRLP(bytes, e, &ethTx)
    Note over RLP: 1. RLP解码交易
    Note over RLP: 2. 提取 v/r/s 签名
    Note over RLP: 3. 恢复 from 地址
    RLP-->>Impl: ethTx {from, to, value, data, gas, ...}

    Impl->>Scale: scale_down_10_18_to_8(ethTx.value)
    Scale-->>Impl: uint64_t value (10^8精度)

    alt to为空 (部署合约)
        Impl->>TxH: createEvmDeployContractTransactionRequest(...)
    else to为合约地址
        Impl->>TxH: createEvmCallContractTransactionRequest(...)
    else to为普通地址
        Impl->>TxH: createEvmTransactionRequest(...)
    end
    TxH-->>Impl: CTransaction outTx

    Impl->>Sig: SigTx(outTx, "")
    Sig-->>Impl: 签名结果

    alt 依赖检查
        Impl->>Cache: ContractTransactionCache 缓存
    else 直接广播
        Impl->>Net: dropCallShippingRequest(txHash, txRaw)
    end

    Impl-->>Client: {"result": "0xtxhash..."}
```

### 3.4 代码位置映射

| 步骤 | 文件:行号 | 关键函数 |
|------|----------|---------|
| HTTP接收路由 | net/http_server.cpp:311 | RegisterCallback("/", eth_dispatch) |
| ETH分发 | net/http_server.cpp:177-306 | eth_dispatch |
| Header解析 | eth.h:16-34 | eth_req_header::parse |
| 回调查找 | net/http_server.h:70-72 | RegisterEthCallback |
| eth_chainId | eth_rpc.cpp:~110 | fun_eth_chainId |
| eth_getBalance | eth_rpc.cpp:~210-227 | fun_eth_getBalance |
| eth_sendRawTransaction | eth_rpc.cpp:236-390+ | fun_eth_sendRawTransaction |
| 精度上转换 | eth_impl.cpp:444-458 | scale_up_10_8_to_18 |
| 精度下转换 | eth_impl.cpp:461-472 | scale_down_10_18_to_8 |
| Gas查询 | eth_impl.cpp:41-101 | eth_gasPrice_impl |
| 交易类型判断 | eth_rpc.cpp:297-320 | DEPLOY/CALL/TX分支 |

---

## 4. 交易创建完整调用链 (CreateTransaction)

### 4.1 流程图

```mermaid
sequenceDiagram
    participant Client as 外部客户端
    participant Handler as createTransaction<br/>(rpc/api/post/rpc_api_Transaction.cpp:15)
    participant ReqAck as Req/Ack解析
    participant Param as TransactionParam::parse
    participant Validate as 参数验证
    participant Converter as TransforerTrans<br/>(CA层)
    participant Proto as Protobuf序列化

    Client->>Handler: POST /CreateTransaction<br/>{"header":{...},"params":{tx_table:[...],...}}

    Handler->>ReqAck: rpc_handle_requese<br/><TransactionParam, TransactionResult>

    ReqAck->>Param: TransactionParam::parse(json["params"])
    Note over Param: param_handle.cpp:224-277

    Param->>Param: reflect::Deserialize(json, *this)

    loop 遍历 tx_table
        Param->>Param: isValidAddress(from_addr)
        Param->>Param: isValidAssetType(asset_type)
        loop 遍历 to_addrs
            Param->>Param: isValidAddress(to_addr)
        end
    end

    alt sponsor_gas == true
        Param->>Param: isValidAddress(gas_asset.addr)
        Param->>Param: isValidAssetType(gas_asset.asset_type)
    end

    Param-->>Handler: parse完成

    Handler->>Validate: transactionDiscoveryHeight(top)
    Handler->>Validate: Util::stringToDecimal(amount) 金额校验

    Handler->>Handler: 构造 TransforerTransParam
    Note over Handler: 1. tx_table → tx_asset
    Note over Handler: 2. gas_asset → gas_tray
    Note over Handler: 3. encoded_info / is_find_utxo

    Handler->>Converter: TransforerTrans(param_t).trans()
    Note over Converter: CA层UTXO选择+交易构造+签名

    Converter-->>Handler: CTransaction tx

    Handler->>Proto: MessageToJsonString(*tx, &json_string)
    Note over Proto: google::protobuf::util

    Handler->>ReqAck: result->tx = json_string
    Handler->>ReqAck: ack.getAllErrors(ret)
    Handler->>ReqAck: ack.toJsonString<TransactionResult>(id)

    Handler->>Client: {"id":"1","jsonrpc":"2.0",<br/>"result":{"tx":"{proto_json}"},<br/>"status":{"code":"0"...}}
```

### 4.2 各交易创建类型的差异对比

| 交易类型 | Handler函数 | Param类 | Trans类 | 特有参数 |
|---------|------------|---------|---------|---------|
| 普通转账 | createTransaction | TransactionParam | TransforerTrans | tx_table(多资产) |
| 质押 | createStake | StakeParam | StakeTrans | amount, reward_rank_string |
| 解押 | createUnStake | UnStakeTransParam | UnStakeTrans | stake_utxo_hash |
| 委托 | createDelegating | DelegatingParam | DelegatingTrans | to_addr, delegate_type |
| 取消委托 | createUndelegating | UndelegatingParam | UndelegatingTrans | utxo_hash |
| 部署合约 | createDeploy | DeployParam | (TxHelper直接调用) | contract_type, data, pubstr |
| 调用合约 | createCall | CallParam | (TxHelper直接调用) | deployer, deployutxo, args, money |
| 锁定 | createLock | LockTransParam | LockTrans | lock_amount, lock_type |
| 解锁 | createUnlock | UnLockParam | UnLockTrans | utxo_hash |
| 投票 | createVote | VoteParam | VoteTrans | vote_hash, vote_type |
| 奖励 | createBonus | BonusParam | BonusTrans | first_choose |
| 国库 | createFund | FundParam | FundTrans | 无额外参数 |
| 发送消息 | createPostMessage | PostMessageParam | SendMessage | tx, sleep_time |
| 合约消息 | createContractMsg | PostContractMessageParam | SendContractMessage | contract_msg |

### 4.3 代码位置映射

| 步骤 | 文件:行号 | 关键函数 |
|------|----------|---------|
| Handler入口 | rpc/api/post/rpc_api_Transaction.cpp:15 | createTransaction |
| 请求解析 | rpc/api/post/rpc_handle_requese.h:10-21 | rpc_handle_requese |
| 参数校验 | rpc/param_handle.cpp:224-277 | TransactionParam::parse |
| 高度获取 | rpc/api/post/rpc_api_Transaction.cpp:42-47 | transactionDiscoveryHeight |
| 金额转换 | rpc/api/post/rpc_api_Transaction.cpp:58-64 | Util::stringToDecimal |
| 交易构造 | rpc/api/post/rpc_api_Transaction.cpp:76-78 | TransforerTrans::trans |
| Proto序列化 | rpc/api/post/rpc_api_Transaction.cpp:88-93 | MessageToJsonString |
| 错误处理 | rpc/rpc.h:159-175 | Ack::getAllErrors |
| JSON响应 | rpc/rpc.h:182-202 | Ack::toJsonString |

---

## 5. 路由注册总览

```
subscribeToHttpCallbacks() -- http_api.cpp:195-317
│
├── ETH回调 (16个, 行199-240)
│   ├── ETH_LAMDA(eth_chainId)
│   ├── ETH_LAMDA(net_version)
│   ├── ETH_LAMDA(eth_blockNumber)
│   ├── ETH_LAMDA(eth_gasPrice)
│   ├── ETH_LAMDA(eth_getBalance)
│   ├── ETH_LAMDA(eth_feeHistory)
│   ├── ETH_LAMDA(eth_getTransactionCount)
│   ├── ETH_LAMDA(eth_sendRawTransaction)
│   ├── 手动 lambda: eth_call (行208-219)
│   ├── 手动 lambda: eth_getBlockByNumber (行221-233)
│   ├── ETH_LAMDA(web3_clientVersion)
│   ├── ETH_LAMDA(eth_getCode)
│   ├── ETH_LAMDA(eth_getTransactionReceipt)
│   ├── ETH_LAMDA(eth_getBlockByHash)
│   ├── ETH_LAMDA(eth_estimateGas)
│   ├── ETH_LAMDA(eth_getTransactionByHash)
│   └── ETH_LAMDA(eth_accounts)
│
├── POST回调 (44个, 行243-292)
│   ├── 基础查询: GetVersion, GetBalance, ..., IsContract (行243-271)
│   ├── 区块交易: GetTransactionByHash, ..., GetBlockNumberByHash (行261-273)
│   ├── 交易创建: CreateTransaction, ..., CreateFundTransaction (行276-292)
│   └── 特殊: SendMessage, SendContractMessage (行284-285)
│
├── GET回调 (18个, 行295-314)
│   ├── 网页: /api, /block, /get_block, /pub, /account, /Node (行295-300)
│   ├── VRF: /ShowVRFInfo (行301)
│   ├── 调试: /printCalcHash, /printhundredhash, /printblock, /SystemInfo (行302-305)
│   ├── 投票: /printVoteInfo, /printLockAddrs, /printProposalInfoByHash (行307-309)
│   ├── 资产: /printAvailableAssetType, /printAsseTypeByContractAddr (行310-311)
│   └── 其他: /GetPublicIp, /GetRollbackBlocks, /Get30daylockdatas (行312-314)
│
└── HttpServer::Start() (行316)
    └── RegisterAllCallback() → 注册 /hello 和 / (eth_dispatch)
    └── 启动线程 HttpServer::Work()
        └── 所有_cbs注册GET+POST+OPTIONS
        └── svr.listen("0.0.0.0", port)
```
