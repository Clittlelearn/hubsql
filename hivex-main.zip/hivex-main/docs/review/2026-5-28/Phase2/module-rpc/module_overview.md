# 模块10：RPC 服务层 -- 架构概览

**分析版本**: 0.1.0-draft  
**分析日期**: 2026-05-26  
**可信度**: 高（基于完整源码、规范文档和已有API文档交叉验证）

---

## 1. RPC 层三层架构

MeMeChain 的 RPC 层采用三层架构设计，服务于不同的客户端和场景：

### 1.1 三层总览

```
                          ┌──────────────────────────────┐
                          │        HTTP Server           │
                          │   (httplib, 0.0.0.0:port)   │
                          │   support: HTTP + HTTPS(mTLS)│
                          └──────────┬───────────────────┘
                                     │
                ┌────────────────────┼────────────────────┐
                │                    │                    │
         ┌──────▼──────┐    ┌───────▼───────┐    ┌───────▼──────┐
         │ POST路由     │    │ GET路由        │    │ ETH路由      │
         │ (JSON-RPC    │    │ (HTTP GET      │    │ (eth_dispatch │
         │  2.0风格)    │    │  debug查询)    │    │  JSON-RPC 2.0)│
         └──────┬──────┘    └───────┬───────┘    └───────┬──────┘
                │                    │                    │
         ┌──────▼──────┐    ┌───────▼───────┐    ┌───────▼──────┐
         │ Req/Ack      │    │ 直接调用       │    │ eth_req_header│
         │ 解析引擎     │    │ DBReader       │    │ ETH_PARAM宏   │
         │ ParamHandle  │    │ HTML/Plain     │    │ 参数解析      │
         │ ResultHandle │    │ 格式化响应     │    │ eth_ret格式   │
         └──────┬──────┘    └───────┬───────┘    └───────┬──────┘
                │                    │                    │
                └────────────────────┼────────────────────┘
                                     │
                            ┌────────▼────────┐
                            │    CA 层/DB 层    │
                            │  (TxHelper,       │
                            │   DBReader, etc.) │
                            └─────────────────┘
```

### 1.2 三层对比

| 维度 | POST (JSON-RPC 2.0) | GET (调试接口) | ETH 兼容 |
|------|---------------------|----------------|----------|
| **协议** | 自定义JSON-RPC 2.0 (非标准header结构) | HTTP GET参数 | 标准 JSON-RPC 2.0 |
| **路由方式** | httplib POST每个路径单独注册 | httplib GET每个路径单独注册 | 根路径"/"统一分发 |
| **请求格式** | `{"header":{id,jsonrpc,method},"params":{...}}` | URL参数 `?key=val` | `{"jsonrpc":"2.0","method":"...","params":[...],"id":...}` |
| **响应格式** | `{"id":"...","jsonrpc":"2.0","result":{...},"status":{code,errorCallstack}}` | `text/html` / `text/plain` / `application/json` | `{"jsonrpc":"2.0","result":{...},"id":...}` |
| **主要用途** | 业务操作（查询/创建交易） | 浏览器调试、监控 | MetaMask/Hardhat/Web3.js |
| **参数校验** | ParamHandle::parse() 逐字段验证 | 无统一框架 | ETH_PARAM宏 + parse()方法 |
| **文件规模** | ~93个cpp文件 | ~38个cpp文件 | 1个cpp文件(~43KB) + 辅助 |

---

## 2. 完整接口分类表

### 2.1 POST 接口 (JSON-RPC 2.0风格)

#### 基础查询 (12个)
| 方法名 | 路由 | 功能 | 源文件 |
|--------|------|------|--------|
| GetVersion | /GetVersion | 获取节点版本 | rpc_api_getVersion.cpp |
| GetBalance | /GetBalance | 获取地址余额 | rpc_api_getBalance.cpp |
| GetBlockHeight | /GetBlockHeight | 获取当前区块高度 | rpc_api_getBlockHeight.cpp |
| GetChainId | /GetChainId | 获取链ID | rpc_api_getChainId.cpp |
| GetAccounts | /GetAccounts | 获取本地账户列表 | rpc_api_getAccounts.cpp |
| GetNodeList | /GetNodeList | 获取已知节点列表 | rpc_api_getNodeList.cpp |
| GetAllStakeNodeList | /GetAllStakeNodeList | 获取所有质押节点 | rpc_api_getAllStakeNodeList.cpp |
| GetAddrType | /GetAddrType | 获取地址类型 | rpc_api_getAddrType.cpp |
| GetYieldInfo | /GetYieldInfo | 获取收益信息 | rpc_api_getYieldInfo.cpp |
| GetBonusInfo | /GetBonusInfo | 获取奖励信息 | rpc_api_getBonusInfo.cpp |
| GetAssetTypeByContractAddr | /GetAssetTypeByContractAddr | 按合约地址查资产类型 | rpc_api_getAssetTypeByContractAddr.cpp |
| IsContract | /IsContract | 检查是否为合约地址 | rpc_api_isContract.cpp |

#### 区块/交易查询 (13个)
| 方法名 | 路由 | 功能 |
|--------|------|------|
| GetTransactionByHash | /GetTransactionByHash | 根据哈希查询交易 |
| GetBlockByHash | /GetBlockByHash | 根据哈希查询区块 |
| GetBlockByHeight | /GetBlockByHeight | 根据高度查询区块 |
| GetBlockByTransactionHash | /GetBlockByTransactionHash | 根据交易哈希查询区块 |
| GetDelegatingUtxo | /GetDelegatingUtxo | 获取委托UTXO |
| GetStakingUtxo | /GetStakingUtxo | 获取质押UTXO |
| GetLockUtxo | /GetLockUtxo | 获取锁定UTXO |
| GetBlockTransactionCountByHash | /GetBlockTransactionCountByHash | 获取区块交易计数 |
| GetDelegatingAddrsByBonusAddr | /GetDelegatingAddrsByBonusAddr | 获取委托地址 |
| GetUtxoDeployerByConAddr | /GetUtxoDeployerByConAddr | 获取部署者UTXO |
| GetTxByHash | /GetTxByHash | 获取交易详情 |
| GetBlockNumberByHash | /GetBlockNumberByHash | 获取区块编号 |
| GetTransactions | (注册与GetTransactionByHash共用method) | 获取交易列表 |

#### 投票/资产查询 (5个)
| 方法名 | 路由 | 功能 |
|--------|------|------|
| GetVoteAddrs | /GetVoteAddrs | 获取投票地址 |
| GetVoteTxHash | /GetVoteTxHash | 获取投票交易哈希 |
| GetAllAssetType | /GetAllAssetType | 获取所有资产类型 |
| GetAssetTypeInfo | /GetAssetTypeInfo | 获取资产类型详情 |
| GetAllRollBackBlocks | /GetRollbackBlocks | 获取回滚区块列表 |

#### 交易创建 (14个)
| 方法名 | 路由 | 功能 |
|--------|------|------|
| CreateTransaction | /CreateTransaction | 创建普通转账交易 |
| CreateStakingTransaction | /CreateStakingTransaction | 创建质押交易 |
| CreateUnstakingTransaction | /CreateUnstakingTransaction | 创建解押交易 |
| CreateDelegatingTransaction | /CreateDelegatingTransaction | 创建委托交易 |
| CreateUndelegatingTransaction | /CreateUndelegatingTransaction | 创建取消委托交易 |
| CreateBonusTransaction | /CreateBonusTransaction | 创建领取奖励交易 |
| CreateCallContractTransaction | /CreateCallContractTransaction | 创建调用合约交易 |
| CreateDeployContractTransaction | /CreateDeployContractTransaction | 创建部署合约交易 |
| SendMessage | /SendMessage | 发送网络消息 |
| SendContractMessage | /SendContractMessage | 发送合约消息 |
| CreateLockTransaction | /CreateLockTransaction | 创建锁定交易 |
| CreateUnLockTransaction | /CreateUnLockTransaction | 创建解锁交易 |
| CreateVoteTransaction | /CreateVoteTransaction | 创建投票交易 |
| CreateFundTransaction | /CreateFundTransaction | 创建国库交易 |

### 2.2 GET 接口 (调试)

| 端点 | 路由 | 功能 | 响应类型 |
|------|------|------|----------|
| /block | /block | 区块列表(支持HTML视觉化) | text/html, text/plain |
| /get_block | /get_block | 区块数据(JSON) | application/json |
| /pub | /pub | 线程和请求统计 | text/plain |
| /account | /account | 账户列表 | text/plain |
| /Node | /Node | 节点列表 | text/plain |
| /ShowVRFInfo | /ShowVRFInfo | VRF验证信息 | text/plain |
| /printCalcHash | /printCalcHash | 千块汇总hash | text/plain |
| /printhundredhash | /printhundredhash | 百块汇总hash | text/plain |
| /printblock | /printblock | 打印区块hash到文件 | text/plain |
| /SystemInfo | /SystemInfo | 系统信息 | text/plain |
| /printVoteInfo | /printVoteInfo | 投票信息 | text/plain |
| /printLockAddrs | /printLockAddrs | 锁定地址列表 | text/plain |
| /printProposalInfoByHash | /printProposalInfoByHash | 提案详细信息 | text/plain |
| /printAvailableAssetType | /printAvailableAssetType | 可用资产类型 | text/plain |
| /printAsseTypeByContractAddr | /printAsseTypeByContractAddr | 根据合约地址查资产类型 | text/plain |
| /GetPublicIp | /GetPublicIp | 公网IP | text/plain |
| /GetRollbackBlocks | /GetRollbackBlocks | 回滚区块信息 | application/json |
| /api | /api | API模板(通用JSON-RPC) | application/json |

注：GET接口还有 `GetNewVrfInfo` (新VRF信息) 和 `PrintProposalInfo` 等端点已定义在 rpc_api.h 头部但未在 subscribeToHttpCallbacks() 中全部注册。【需人工验证】

### 2.3 ETH 兼容接口 (16个)

| 方法 | 规范章节 | 实现状态 | 备注 |
|------|---------|---------|------|
| eth_chainId | 10.5.1 | 已实现 | 返回0x3027 (12315) |
| eth_blockNumber | 10.5.1 | 已实现 | 返回十六进制当前高度 |
| eth_gasPrice | 10.5.1 | 已实现 | 近100区块平均gas |
| eth_getBalance | 10.5.1/10.5.2 | 已实现 | 精度转换10^8→10^18 |
| eth_getTransactionCount | 10.5.1 | 已实现 | 返回nonce计数 |
| eth_sendRawTransaction | 10.5.1/10.5.3 | 已实现 | 支持部署/调用/转账三种类型 |
| eth_getTransactionReceipt | 10.5.1 | 已实现 | 完整收据字段 |
| eth_call | 10.5.1 | 已实现 | 只读合约调用 |
| eth_getBlockByNumber | 10.5.1 | 已实现 | 支持fullTx参数 |
| eth_getBlockByHash | 10.5.1 | 已实现 | 完整区块字段 |
| eth_getCode | 10.5.1 | 已实现 | 返回合约字节码 |
| eth_getTransactionByHash | 10.5.1 | 已实现 | 完整交易字段 |
| eth_estimateGas | 10.5.1 | 已实现 | 当前固定返回gas=1（未实现实际估算） |
| eth_accounts | 10.5.1 | 已实现 | 返回本地账户列表 |
| net_version | 10.5.1 | 已实现 | 返回网络ID |
| web3_clientVersion | 10.5.1 | 已实现 | 返回客户端版本 |

**缺失的关键ETH方法** (以太坊标准RPC中常见但未实现):
- eth_getLogs / eth_newFilter (事件日志过滤)
- eth_getStorageAt (存储读取)
- eth_getBalance 的 blockTag 参数实质未生效
- eth_subscribe / eth_unsubscribe (WebSocket订阅)
- eth_sign / personal_sign (签名)
- eth_getBlockReceipts
- eth_feeHistory (已定义结构体但实现不完整)

---

## 3. 规范 vs 实现 对比分析

| 功能点 | 规范定义 (spec_dev.md 第10章) | 当前实现 | 偏差原因 |
|--------|-------------------------------|----------|----------|
| **请求格式** | `{"header":{...},"params":{...}}` (内嵌header) | 标准的JSON-RPC 2.0要求header字段在顶层 | 自定义设计，与标准JSON-RPC 2.0不兼容 |
| **响应格式** | 包含额外`status`字段 `{code,errorCallstack}` | 实现与规范一致 | 非标准字段，开发者需要额外适配 |
| **POST注册策略** | 未明确规定 | 每个path同时注册GET和POST处理器 | 允许GET方式调用POST接口（CORS友好），但可能引起混淆 |
| **精度转换(10^8→10^18)** | `amount × 10^10` 返回hex | `scale_up_10_8_to_18(int64_t amount)` 实现正确 (rpc/eth/eth_impl.cpp:444-458) | 使用 `unsigned __int128` 防溢出，正确 |
| **精度转换(10^18→10^8)** | `value / 10^10` 取整 | `scale_down_10_18_to_8(bytes)` 用位移解析字节再除 (rpc/eth/eth_impl.cpp:461-472) | 接收raw bytes而非十六进制字符串，与其他ETH实现不同 |
| **eth_estimateGas** | 估算执行所需Gas | 固定返回`"1"`(string)非hex (rpc/eth/eth_impl.cpp:429-435) | 未实现真实的Gas估算逻辑 |
| **eth_gasPrice精度** | 理论上应返回10^18精度 | `gas_averages = std::to_string(gas_average)` 返回10^8精度字符串 (rpc/eth/eth_impl.cpp:98) | 注释掉了scale_up转换，与ETH工具链期望不符 |
| **Gas价格计算** | KTargetGasPrice=60000 | 遍历最近100个区块累加gas burnt除以交易数 (eth_impl.cpp:54-100) | 算法正确但数据量小(仅100块)，且gas_average初始化未置零 |
| **参数校验** | 未详细规定 | 使用`reflect::Deserialize`反序列化 + 自定义校验 (param_handle.cpp) | 校验覆盖率不均衡：部分接口校验严格(地址长度/格式/assetType)，部分完全跳过(GetVersion等无参接口) |
| **错误码体系** | 10.6节标记为"TODO需要补充" | 使用MEM错误枚举(rpc/global/utxo三层) (errorn/) | 错误码体系存在但未在规范中完整记录 |
| **批量JSON-RPC请求** | 未提及 | eth_dispatch支持数组形式的批量请求 (net/http_server.cpp:278-293) | 代码支持了但规范未说明 |
| **RPC鉴权** | 附录E TODO: 需要确认 | 无任何鉴权机制 | 规范标记为TODO，实现为空 |
| **CORS支持** | 未提及 | 全局启用CORS (允许所有来源) (net/http_server.cpp:12-28,113-129) | 开发期便利做法，生产环境需限制 |
| **速率限制** | 未提及 | 无 | 无任何请求速率限制机制 |
| **SSL/TLS** | 未提及 | 支持HTTPS + mTLS (net/http_server.cpp:45-108) | 实现超前于规范 |

---

## 4. JSON-RPC 2.0 格式一致性评估

### 4.1 POST接口请求格式问题

标准 JSON-RPC 2.0 请求格式：
```json
{"jsonrpc":"2.0","method":"GetBalance","params":{"addr":"...","asset_type":"..."},"id":1}
```

当前实现格式 (rpc/rpc.h:86-125):
```json
{"header":{"id":"1","jsonrpc":"2.0","method":"GetBalance"},"params":{"addr":"...","asset_type":"..."}}
```

**偏差**: 方法名嵌套在`header`子对象中，而非顶层。这导致标准JSON-RPC客户端库无法直接使用。

### 4.2 ETH接口 -- 符合标准

ETH兼容接口严格遵循标准JSON-RPC 2.0：
- 方法名在顶层 `"method": "eth_getBalance"`
- 正确支持 `"params": [...]` 数组格式
- 错误返回 `{"error": {"code":..., "message":...}}` 格式
- 支持批量请求的数组格式

### 4.3 GET接口 -- 非标准

GET接口使用URL查询参数，返回HTML/Plain/JSON，不属于JSON-RPC规范，属于调试便利接口。

---

## 5. 参数校验安全性评估

### 5.1 地址校验

- `isValidAddress()` 检查地址格式（长度、hex字符） (param_handle.cpp:28-37等)
- 校验覆盖度：大多数接口有地址校验，但部分接口（如`VoteParam::parse()` at param_handle.cpp:775-784）无任何校验
- 风险等级：低。地址校验统一使用`isValidAddress`函数

### 5.2 AssetType/Hash 校验

- `Util::isValidAssetType()` 检查hash格式 (param_handle.cpp:34-47等)
- **风险发现**: 多个地方用`isValidAssetType`校验hash字段，但函数名暗示它用于asset_type，存在语义不匹配。GetVoteAddrsParam::parse() (param_handle.cpp:114) 对hash字段调用`isValidAssetType`
- 风险等级：中。不正确的校验函数可能导致非法hash通过验证

### 5.3 金额校验

- `Util::stringToDecimal(amount)` 转换金额为10进制uint64数组 (Transaction.cpp:59-64, stake.cpp:49-52)
- 校验了转换结果有效性
- 风险等级：中。溢出可能发生在精度转换环节(10^18→10^8时uint64截断)

### 5.4 注入风险

- JSON解析使用nlohmann的安全解析器，自动转义
- URL参数通过httplib处理
- 风险等级：低。JSON和HTTP库具有基础的注入防护

### 5.5 信息泄露

- 错误消息在`errorCallstack`中返回详细的调试信息 (rpc/rpc.h:159-175)
- `/pub`接口暴露线程信息和请求统计 (rpc/api/get/rpc_api_getPub.cpp)
- `/SystemInfo`接口暴露系统配置信息
- 风险等级：中。生产环境应限制详细错误信息的暴露

---

## 6. 问题清单

| 位置 | 现象 | 风险等级 | 触发场景 | 修复建议 | 验证方法 |
|------|------|---------|---------|---------|---------|
| rpc/rpc.h:177-202 | 自定义请求格式非标准JSON-RPC 2.0 | 中 | 标准JSON-RPC客户端无法对接 | 同时注册标准格式路由，渐进式迁移 | 用curl发送标准JSON-RPC 2.0请求测试 |
| rpc/eth/eth_impl.cpp:97-98 | gasPrice返回10^8精度字符串而非10^18 hex | 高 | MetaMask等工具显示的gas price错误 | 恢复被注释的`scale_up_10_8_to_18`转换 | 对比eth_gasPrice返回值与其他链格式 |
| rpc/eth/eth_impl.cpp:429-435 | eth_estimateGas固定返回"1" | 高 | Hardhat/Truffle部署合约时gas估算为1导致交易失败 | 实现真实的Gas估算(模拟执行) | 用Hardhat部署合约并验证gas消耗 |
| rpc/eth/eth_impl.cpp:56 | gas_average变量未初始化为0 | 中 | gasPrice计算结果包含垃圾值（首次调用） | 添加初始化`uint64_t gas_average = 0;` | 检查首次调用eth_gasPrice的结果 |
| rpc/param_handle.cpp:114 | `isValidAssetType`用于校验hash参数 | 中 | hash校验不充分（asset_type校验规则可能不匹配hash规则） | 添加专用的hash校验函数或用更通用的校验 | 使用非法hash格式尝试通过校验 |
| rpc/param_handle.cpp:775-784 | VoteParam::parse()无任何校验 | 高 | 无效地址/hash可成功创建投票交易 | 添加addr和vote_hash的格式校验 | 发送包含无效地址的投票请求 |
| net/http_server.cpp:13 | CORS允许所有来源(`*`) | 高(生产环境) | 任意网页可向节点发起请求 | 生产环境配置白名单域名 | 从任意域发起跨域请求 |
| net/http_server.cpp:299-304 | http日志写入`/root/mm/build/bin/http_log.txt` | 低 | 磁盘占用增长（无日志轮转） | 添加日志轮转或移除调试日志 | 检查日志文件大小增长 |
| rpc/param_handle.cpp:52-70等 | 多个无参接口的parse()直接返回0 | 低 | 无参数校验但未引入安全风险 | 可保持不变 | N/A |
| rpc/eth/eth_rpc_json_def.h:251-253 | eth_getBlockByHash parse()的try-catch可能静默失败 | 中 | 参数格式错误时静默使用默认值 | 添加日志记录解析失败原因 | 发送格式错误的参数测试 |
| rpc/eth/eth_impl.cpp:461-472 | scale_down接受raw bytes而非hex字符串 | 中 | 前端发送hex字符串时转换失败 | 代码注释说明bytes来源，或支持hex输入 | 测试hex格式和bytes格式输入 |
