# 模块10: RPC服务层 — 状态机流转图

> **可信度**: 高 — 基于 http_api.cpp 和 rpc 框架源码分析
> **分析日期**: 2026-05-26

---

## 一、RPC 请求生命周期状态机

```mermaid
stateDiagram-v2
    [*] --> HTTP_RECEIVED: HTTP请求到达
    HTTP_RECEIVED --> PARSING: 开始解析
    
    PARSING --> PARSE_FAILED: JSON解析失败
    PARSING --> ROUTED: 解析成功+路由匹配
    PARSING --> METHOD_NOT_FOUND: 路由未匹配
    
    PARSE_FAILED --> ERROR_RESPONSE: 返回400错误
    METHOD_NOT_FOUND --> ERROR_RESPONSE: 返回404错误
    
    ROUTED --> PARAM_VALIDATING: 进入参数校验
    PARAM_VALIDATING --> PARAM_INVALID: 参数不合法
    PARAM_VALIDATING --> PROCESSING: 参数合法
    
    PARAM_INVALID --> ERROR_RESPONSE: 返回参数错误
    
    PROCESSING --> CA_CALL: 调用CA层
    CA_CALL --> PROCESSING_RESULT: CA返回结果
    
    PROCESSING_RESULT --> FORMATTING: 结果格式化
    FORMATTING --> JSON_RESPONSE: JSON-RPC格式
    FORMATTING --> HTML_RESPONSE: HTML格式(GET)
    FORMATTING --> PLAIN_RESPONSE: 纯文本格式
    FORMATTING --> ETH_JSON_RESPONSE: ETH JSON格式
    
    JSON_RESPONSE --> HTTP_RESPONSE: 200 OK
    HTML_RESPONSE --> HTTP_RESPONSE: 200 OK
    PLAIN_RESPONSE --> HTTP_RESPONSE: 200 OK
    ETH_JSON_RESPONSE --> HTTP_RESPONSE: 200 OK
    
    ERROR_RESPONSE --> HTTP_RESPONSE: 错误状态码
    HTTP_RESPONSE --> [*]: 请求完成
```

---

## 二、交易创建状态机

```mermaid
stateDiagram-v2
    [*] --> RECEIVE_PARAMS: 接收JSON参数
    
    RECEIVE_PARAMS --> VALIDATE_ADDR: 验证地址格式
    VALIDATE_ADDR --> ADDR_INVALID: 地址无效
    VALIDATE_ADDR --> VALIDATE_AMOUNT: 地址有效
    
    ADDR_INVALID --> ERROR_PRE_CHECK: 返回地址错误
    
    VALIDATE_AMOUNT --> AMOUNT_INVALID: 金额无效(为0或负数)
    VALIDATE_AMOUNT --> CHECK_UTXO: 金额有效
    
    AMOUNT_INVALID --> ERROR_PRE_CHECK: 返回金额错误
    
    CHECK_UTXO --> UTXO_INSUFFICIENT: UTXO不足
    CHECK_UTXO --> BUILD_TX: UTXO充足
    
    UTXO_INSUFFICIENT --> ERROR_PRE_CHECK: 返回余额不足
    
    BUILD_TX --> SIGN_TX: TxHelper构造交易
    SIGN_TX --> SIGN_FAILED: 签名失败
    SIGN_TX --> RETURN_TX_JSON: 签名成功
    
    SIGN_FAILED --> ERROR_PRE_CHECK: 返回签名失败
    
    RETURN_TX_JSON --> [*]: 返回交易JSON给调用方
    ERROR_PRE_CHECK --> [*]: 返回错误信息
```

**说明**: 交易创建阶段不广播交易，仅返回构造好、已签名的交易JSON。实际广播由 `SendMessage`/`SendContractMessage` 接口完成。

---

## 三、ETH兼容请求状态机

```mermaid
stateDiagram-v2
    [*] --> ETH_RECEIVED: POST /eth
    
    ETH_RECEIVED --> PARSE_JSONRPC: 解析JSON-RPC 2.0
    PARSE_JSONRPC --> INVALID_JSONRPC: 格式错误
    PARSE_JSONRPC --> EXTRACT_METHOD: 格式正确
    
    INVALID_JSONRPC --> ETH_ERROR: 返回-32600 Invalid Request
    
    EXTRACT_METHOD --> METHOD_DISPATCH: 路由到具体方法
    METHOD_DISPATCH --> UNSUPPORTED_METHOD: 未知方法
    METHOD_DISPATCH --> PRECISION_CONVERT: 已知方法
    
    UNSUPPORTED_METHOD --> ETH_ERROR: 返回-32601 Method not found
    
    PRECISION_CONVERT --> CA_CALL: 精度转换(10^8↔10^18)
    CA_CALL --> ETH_FORMAT: 格式化ETH响应
    ETH_FORMAT --> ETH_SUCCESS: 返回结果
```

**精度转换规则**:
- `eth_getBalance`: 余额 × 10^10 (8位精度→18位精度)
- `eth_sendRawTransaction`: value ÷ 10^10 (18位精度→8位精度)
- `eth_gasPrice`: 当前固定返回 `0x1`

---

## 四、HTTP服务器生命周期

```mermaid
stateDiagram-v2
    [*] --> CREATED: 构造HttpServer
    
    CREATED --> CONFIGURING: 设置IP/端口
    CONFIGURING --> TLS_CONFIG: 配置SSL(可选)
    TLS_CONFIG --> LISTENING: listen()
    
    LISTENING --> ACCEPTING: 接受连接
    ACCEPTING --> PROCESSING: 处理请求
    PROCESSING --> ACCEPTING: 继续接受
    PROCESSING --> RESPONDING: 返回响应
    
    LISTENING --> STOPPING: stop()
    STOPPING --> [*]: 服务器关闭
```

---

## 五、错误处理状态流转

```mermaid
stateDiagram-v2
    [*] --> NO_ERROR: 正常处理
    
    NO_ERROR --> PARSE_ERROR: JSON解析失败(-32700)
    NO_ERROR --> INVALID_REQUEST: 无效请求(-32600)
    NO_ERROR --> METHOD_NOT_FOUND: 方法未找到(-32601)
    NO_ERROR --> INVALID_PARAMS: 参数无效(-32602)
    NO_ERROR --> INTERNAL_ERROR: 内部错误(-32603)
    NO_ERROR --> TIMEOUT_ERROR: 超时
    NO_ERROR --> AUTH_ERROR: 鉴权失败
    
    PARSE_ERROR --> ERROR_LOG: 记录错误日志
    INVALID_REQUEST --> ERROR_LOG
    METHOD_NOT_FOUND --> ERROR_LOG
    INVALID_PARAMS --> ERROR_LOG
    INTERNAL_ERROR --> ERROR_LOG
    TIMEOUT_ERROR --> ERROR_LOG
    AUTH_ERROR --> ERROR_LOG
    
    ERROR_LOG --> FORMAT_ERROR_RESPONSE: 格式化错误响应
    FORMAT_ERROR_RESPONSE --> [*]: 返回给客户端
```

**说明**: RPC错误码定义在 `rpc/rpc_error.h` 和 `rpc/error/error.h` 中。GET接口的错误处理更简单（直接返回错误字符串），POST接口使用JSON-RPC标准错误格式。
