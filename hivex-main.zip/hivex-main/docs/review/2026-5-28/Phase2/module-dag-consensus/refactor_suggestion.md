# Module 4: Refactoring Suggestions

## 1. Problem Summary

The module's code suffers from several structural issues:

1. **Monolithic files**: 382KB algorithm.cpp and 132KB sync_block.cpp
2. **Mixed concerns**: Consensus logic, block storage, transaction validation, economic model, EVM integration all in one file
3. **Distributed rollback logic**: Rollback scattered across 3 files
4. **Static variable state machines**: Heavily reliant on file-scope statics for sync state
5. **Two parallel VRF implementations**: Legacy ECDSA-based VRF (vrf_consensus) + new ECVRF RFC 9381 (vrf_selection)

---

## 2. ca/algorithm.cpp (382KB) Split Plan

### Current State

File `ca/algorithm.cpp` contains ~7600+ lines mixing:
- Transaction verification (~1000 lines)
- Block verification and saving (~800 lines)
- Block rollback/deletion (~300 lines)
- SumHash computation (~200 lines)
- Abnormal sign address detection (~50 lines)
- Bonus/inflation rate calculation (~400 lines)
- Asset type management (~500 lines)
- Proposal/vote management (~400 lines)
- Contract-related functions (~600 lines)
- EVM integration utilities (~300 lines)
- Various helper functions (~1500 lines)

### Split Target Architecture

```
ca/
  algorithm/
    block_hash.cpp/h          -- CalcBlockHash, calculateTransactionHash, calculateBlockMerkle
    block_verify.cpp/h         -- memVerifyBlock, VerifyBlock, verifyPreSaveBlock_
    block_save.cpp/h            -- SaveBlock, DeleteBlock
    block_rollback.cpp/h        -- RollBackToHeight, rollback_by_hash
    block_sumhash.cpp/h         -- calculateHeightsSumHash, calculateSumHashOf1000Heights, recalculate_heights_sum_hash
    tx_verify.cpp/h             -- memoryVerificationTransactionRequest, verifyTransactionRequest, doubleSpendCheck
    consensus_stats.cpp/h       -- fetchAbnormalSignAddrListByPeriod, getAllAddrSignCountByPeriod
    bonus_calc.cpp/h            -- CalcBonusValue, GetPledgeTimeByAddr, GetCommissionPercentage
    inflation.cpp/h             -- GetAnnualizedRate, GetNewAnnualizedRate, mapStakingRateToK, calculateInflationRates
    asset_manager.cpp/h         -- fetchAvailableAssetType, GetAssetTypeIsValid, GetVoteAssetType, etc.
    proposal_vote.cpp/h         -- CheckProposaInfo, GetVoteNum, CheckForDuplicateVotes, etc.
    contract_utils.cpp/h        -- verifyDirtyContract, verify_contract_storage, verifyContractBlock, verifyContractDepsTx, etc.
    evm_helpers.cpp/h           -- get_call_contract_from_addr, GetFlowTxType, etc.
```

### Split Strategy

| Module | Lines (est.) | Dependencies | Priority |
|--------|-------------|--------------|----------|
| `block_hash` | ~50 | proto, sha256 | P0 (immediate) |
| `block_verify` | ~300 | proto, db, block_hash, tx_verify | P0 |
| `block_save` | ~600 | proto, db, block_hash, block_verify | P0 |
| `block_rollback` | ~150 | proto, db, block_save | P0 |
| `block_sumhash` | ~200 | proto, db, sync_block | P0 |
| `tx_verify` | ~800 | proto, db, block_hash | P1 |
| `consensus_stats` | ~100 | proto, db | P1 |
| `bonus_calc` | ~300 | proto, db, consensus_stats | P2 |
| `inflation` | ~200 | proto, math | P2 |
| `asset_manager` | ~400 | proto, db | P2 |
| `proposal_vote` | ~300 | proto, db, asset_manager | P3 |
| `contract_utils` | ~500 | proto, db, evm | P3 |
| `evm_helpers` | ~200 | proto, evm | P3 |

**Priorities**: P0=Critical for module clarity, P1=Important, P2=Nice to have, P3=Low priority

### Migration Steps

1. **Phase 1** (P0 modules, 2 person-weeks):
   - Create `ca/algorithm/` directory
   - Extract `block_hash.cpp` (no dependencies on other module internals)
   - Extract `block_verify.cpp` (depends on tx_verify minimally)
   - Extract `block_save.cpp` (largest P0 module)
   - Extract `block_rollback.cpp` (depends on block_save)
   - Extract `block_sumhash.cpp` (depends on sync concepts)
   - Keep `ca/algorithm.h` as a forwarding header for backward compatibility

2. **Phase 2** (P1 modules, 1 person-week):
   - Extract `tx_verify.cpp`
   - Extract `consensus_stats.cpp`

3. **Phase 3** (P2-P3 modules, 2 person-weeks):
   - Extract bonus, inflation, asset, proposal, contract, evm modules
   - Update all callers to use new include paths

**Total estimated: 5 person-weeks**

---

## 3. ca/sync_block.cpp (132KB) Split Plan

### Current State

File `ca/sync_block.cpp` contains:

| Section | Lines (est.) | Description |
|---------|-------------|-------------|
| Static state variables | ~50 | Global sync state flags |
| SumHash computation helpers | ~100 | calculateSumHeightHash, sumHeightsHash |
| getHeightBlockHash (3 overloads) | ~150 | Block hash fetching |
| Sync thread main loop (ThreadStart) | ~220 | Main orchestrator |
| Fast sync | ~150 | runFastSyncOnce, get_fast_sync_sum_hash_node, get_fast_sync_block_data |
| New sync | ~200 | runNewSyncOnce, get_sync_sum_hash_node, get_sync_block_hash_node |
| From zero sync | ~200 | runFromZeroSyncOnce, get_from_zero_sync_sum_hash_node, getSyncBlockDataFromZero |
| Block data retrieval | ~300 | getSyncBlockData, getSyncBlockHashVerification, getSyncBlockDataFromZero |
| Node selection | ~400 | getSyncNode, getSyncNodeSimplified, get_sync_node_basic, needByzantineAdjustment, checkRequirementAndFilterQualifyingNodes, get_sync_node_hash_info, _GetSelectedAddr |
| Message handler functions | ~200 | All network message send/process/handle functions |
| Fork resolution helpers | ~50 | addBlockToMap, checkByzantineFault |
| Misc/static helpers | ~100 | get_save_sync_type, kStabilityTime logic |

### Split Target Architecture

```
ca/
  sync/
    sync_state.cpp/h             -- SyncState class wrapping all static variables
    sync_sumhash.cpp/h            -- SumHash computation and verification (sumHeightsHash, calculateSumHeightHash)
    sync_block_hash.cpp/h         -- getHeightBlockHash overloads
    sync_thread.cpp/h             -- ThreadStart main loop (SyncState owner)
    sync_fast.cpp/h               -- Fast sync protocol
    sync_new.cpp/h                -- New sync protocol
    sync_zero.cpp/h               -- From-zero sync protocol
    sync_node_selector.cpp/h      -- getSyncNode variants, Byzantine adjustment, requirement filtering
    sync_block_retrieval.cpp/h    -- getSyncBlockData, getSyncBlockHashVerification, etc.
    sync_messages.cpp/h           -- All network message handlers and send functions
    sync_fork.cpp/h               -- addBlockToMap, checkByzantineFault, fork resolution logic
```

### Key Decoupling Actions

1. **Extract SyncState class** (encapsulate all file-scope static variables):
```cpp
class SyncState {
    uint64_t sync_fail_height_ = 0;
    bool run_fast_sync_ = false;
    bool is_fast_sync_failed_ = false;
    bool execute_new_sync_ = false;
    uint64_t initial_sync_start_height_ = 0;
    uint32_t sync_height_count_ = 100;
    uint64_t sync_send_new_sync_number_ = UINT32_MAX;
    // ... thread-safe accessors
    std::mutex mutex_;
};
```
This eliminates the data race concern on static variables.

2. **Decouple fork resolution from sync**:
   - Move `addBlockToMap`, `checkByzantineFault`, `fetchRollbackBlock` into `sync_fork.cpp/h`
   - The sync thread should call fork resolution as a separate phase

3. **Separate network message handlers**:
   - Move all `send*Request` / `handle*Request` / `process*Request` functions to `sync_messages.cpp`
   - Keep them as free functions (already are)

### Estimated Effort

| Phase | Modules | Person-Weeks |
|-------|---------|-------------|
| 1 | sync_state, sync_sumhash, sync_block_hash | 1 |
| 2 | sync_thread, sync_fast, sync_new, sync_zero | 2 |
| 3 | sync_node_selector, sync_block_retrieval | 2 |
| 4 | sync_messages, sync_fork | 1 |
| **Total** | | **6 person-weeks** |

---

## 4. Fork Logic and Sync Logic Decoupling

### Current Coupling Issue

The fork detection and resolution logic is deeply embedded inside the sync thread's main loop (`SyncBlock::ThreadStart()`):

1. **Fork detection**: `nodeSelfHeight == chainHeight` for `SYNC_STUCK_OVERTIME_COUNT=6` cycles triggers `needByzantineAdjustment()` [sync_block.cpp:551-586]
2. **Node selection for fork**: `getSyncNode()` switches to `get_sync_node_basic()` with `forceFindBaseChainVar` [sync_block.cpp:588-594]
3. **Rollback triggering**: Rollback happens during `runNewSyncOnce()` -> `getSyncBlockHashVerification()` -> hash comparison

### Proposed Architecture

```cpp
// New class: ForkDetector (runs in its own timer)
class ForkDetector {
    void Start();  // Periodic timer (15s)
    bool DetectFork(std::vector<std::string>& alternativeNodes);
    ForkResult Resolve();
};

// New class: SyncOrchestrator (coordinates sync strategies)
class SyncOrchestrator {
    SyncState state_;
    std::unique_ptr<FastSyncer> fast_syncer_;
    std::unique_ptr<NewSyncer> new_syncer_;
    std::unique_ptr<ZeroSyncer> zero_syncer_;
    std::unique_ptr<ForkDetector> fork_detector_;
    
    void Run();  // Main loop
    SyncDecision Decide();  // Which strategy to use
};
```

### Key Benefits

1. Fork detection is a **separate, configurable timer** -- not embedded in sync loop
2. Rollback is triggered by **ForkDetector**, which publishes events for SyncOrchestrator to handle
3. Each sync strategy (fast/new/zero) is **independently testable**
4. SyncState is **explicitly owned** by SyncOrchestrator, not global statics

### Estimated Effort: 3 person-weeks

---

## 5. Critical Bug Fixes (During Refactoring)

### 5.1 Rollback Atomicity (Critical)

**Problem**: `RollBackToHeight()` (algorithm.cpp:7511) and `RollbackBlock()` (block_helper.cpp:1155) use different mechanisms. The former traverses from top, the latter queries remote nodes. Neither guarantees atomic UTXO recovery -- they rely on chain re-sync.

**Fix**: Implement `AtomicRollback` that:
1. Begins RocksDB transaction
2. For each block to rollback: delete block, delete txs, restore UTXO outputs to unspent
3. Commit or rollback atomically
4. If any step fails, abort entire rollback

### 5.2 Block Signature Verification (High)

**Problem**: `verifyPreSaveBlock_()` (algorithm.cpp:3923) only checks signature count == kConsensus, does not verify signers are VRF-selected packagers.

**Fix**: After `extractPackagerVRFData()` selects nodes, cache the selected nodes. During `verifyPreSaveBlock_()`, verify each signer is in the selected packager set for that block's height.

### 5.3 Consensus Threshold Mismatch (Medium)

**Problem**: Spec defines 51% (`floor((N+1) * 0.51)`) but `getChainHeight()` uses 75% (`nodeHeights.size() * 0.75`).

**Fix**: Either update spec to match implementation (75%), or change implementation to use spec-defined 51%. Recommend: keep 75% (more conservative) but document decision in both spec and code.

---

## 6. VRF Implementation Migration

### Current State

Two VRF implementations exist:
1. **Legacy** (`vrf_consensus.cpp/h`, `utils/vrf.hpp`): ECDSA-based VRF, in production use
2. **New** (`utils/vrf_selection.cpp/h`, `utils/ecvrf_p256_sha256_tai.cpp/h`, `utils/vrf_trace.cpp/h`): RFC 9381 ECVRF-P256-SHA256-TAI, with domain separation and proper proof format

The new ECVRF implementation has cleaner interfaces:
- Domain-separated roles (`tx_packager_v1`, `contract_dispatcher_v1`, `contract_packager_v1`, `block_validator_v1`)
- RFC 9381 compliant proof structure
- Proper verification with candidate digest binding

### Migration Plan

1. Add ECVRF to `VRFConsensusNode::generateVRFStructure()` as an **additional** proof alongside existing signature
2. Over N cycles, increase ECVRF acceptance while allowing legacy fallback
3. Phase out legacy VRF once ECVRF is fully validated
4. Remove `utils/vrf.hpp` legacy cache
5. Integrate `mm::vrf::trace` for observability

### Estimated Effort: 3 person-weeks

---

## 7. Total Refactoring Timeline

| Work Package | Person-Weeks | Risk |
|-------------|-------------|------|
| algorithm.cpp split (P0) | 2 | Low |
| algorithm.cpp split (P1-P3) | 3 | Low |
| sync_block.cpp split | 6 | Medium |
| Fork/Sync decoupling | 3 | Medium |
| Critical bug fixes | 2 | High (requires careful testing) |
| VRF migration | 3 | Medium |
| Integration testing | 3 | High |
| **Total** | **22 person-weeks (~5.5 months)** | |

### Recommended Phased Approach

1. **Month 1**: algorithm.cpp P0 split + critical bug fixes
2. **Month 2**: sync_block.cpp split Phase 1-2
3. **Month 3**: Fork/Sync decoupling + sync_block.cpp Phase 3-4
4. **Month 4**: algorithm.cpp P1-P3 split + VRF migration
5. **Month 5**: Integration testing + regression testing
6. **Month 6 (partial)**: Documentation + cleanup

---

## 8. Quick Wins (Low Effort, High Impact)

| Item | Effort | Impact |
|------|--------|--------|
| Move `RollBackTime` constant to `global.h` (deduplicate) | 15 min | Code quality |
| Add `static_assert` for `kConsensus=3` minimum | 5 min | Safety |
| Add `BlockStatus` verification node qualification check | 2 hours | Security |
| Extract `SyncState` class (encapsulate statics) | 4 hours | Thread safety |
| Add unit test for `computeMaxHeightWithMinFrequency` | 1 day | Test coverage |
| Add unit test for `RollBackToHeight` atomicity | 2 days | Test coverage |
| Document `checkByzantineFault` threshold | 1 hour | Documentation |
