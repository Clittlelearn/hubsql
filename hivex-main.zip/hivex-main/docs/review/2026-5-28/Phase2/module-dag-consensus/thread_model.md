# Module 4: Thread Model

## 1. Thread Inventory

| Thread | Owner | Period | Type | Status |
|--------|-------|--------|------|--------|
| VRF Consensus Thread | VRFConsensusNode::run() | 10 seconds | Detached, infinite loop | Active |
| Block Sync Thread | SyncBlock::ThreadStart() | 10 seconds (variable) | Detached, infinite loop | Active |
| Block Pool Timer | BlockHelper::Process() | Called by timer (external) | Episodic | Active |
| Seek Block Timer | BlockHelper::SeekBlockThreadObject() | Called by timer (external) | Episodic | Active |
| Block Storage Timer | BlockStorage::_StartTimer() | 100 milliseconds | AsyncLoop callback | Active |
| Check Blocks Timer | CheckBlocks::StartTimer() | 30 seconds | AsyncLoop callback | Active |
| Database Timer | DB maintenance | Configurable | AsyncLoop callback | Active |
| VRF Cache Cleanup | VRF::ClearTimer | 3 seconds | AsyncLoop callback | Active |
| epoll Network Thread | net/ | Event-driven | Persistent | Active |
| TaskPool Workers | TaskPool | On-demand | Thread pool | Active |
| sendBlockByUtxoRequest Thread | BlockHelper | On-demand (async) | Detached, one-shot | Episodic |

## 2. Thread Interaction Diagram

```mermaid
graph TD
    subgraph "Network Layer"
        EPOLL[epoll Network Thread<br/>net/dispatcher]
    end
    
    subgraph "Consensus"
        VRF[VRFConsensusNode::run<br/>10s cycle, detached]
        BLOCKFLOW[BlockStorage::_BlockCheck<br/>100ms timer callback]
    end
    
    subgraph "Block Management"
        BLOCKPOOL[BlockPool/Process Timer<br/>calls BlockHelper::Process]
        SEEKTIMER[SeekBlock Timer<br/>calls SeekBlockThreadObject]
    end
    
    subgraph "Synchronization"
        SYNC[SyncBlock::ThreadStart<br/>10s cycle, detached]
    end
    
    subgraph "Verification"
        CHECK[CheckBlocks::_ToCheck<br/>30s timer callback]
    end
    
    subgraph "Task Execution"
        TASKPOOL[TaskPool Workers<br/>thread pool]
    end
    
    subgraph "Database"
        DB_MAINT[Database Timer<br/>periodic maintenance]
    end
    
    EPOLL -->|HandleVRFConsensusInfoReq| VRF
    EPOLL -->|Process sync messages| SYNC
    
    VRF -->|vrfBroadcastMessage| TASKPOOL
    VRF -->|extractPackagerVRFData| BLOCKFLOW
    
    BLOCKFLOW -->|sendBroadcastAddBlockRequest| EPOLL
    BLOCKFLOW -->|composeEndBlockMessage| EPOLL
    
    SYNC -->|Network requests via TaskPool| EPOLL
    SYNC -->|AddSyncBlock/AddFastSyncBlock| BLOCKPOOL
    SYNC -->|SetFastSync| BLOCKPOOL
    
    BLOCKPOOL -->|SaveBlock| DB_MAINT
    BLOCKPOOL -->|RollbackBlocks| DB_MAINT
    BLOCKPOOL -->|PostSaveProcess| DB_MAINT
    
    SEEKTIMER -->|sendBlockByHashRequest| EPOLL
    SEEKTIMER -->|sendBlockByUtxoRequest (async thread)| EPOLL
    
    CHECK -->|get_sync_node_hash_info| SYNC
    CHECK -->|performNewSynchronization| SYNC
    
    EPOLL -->|Block verification tasks| TASKPOOL
    BLOCKPOOL -->|Transaction verification tasks| TASKPOOL
```

## 3. Thread Details

### 3.1 VRF Consensus Thread

**Owner**: `VRFConsensusNode::run()` [vrf_consensus.cpp:284-336]
**Type**: `std::thread` detached
**Period**: Synchronized to 10-second cycle boundaries
**Lifecycle**:
```
Process() called at startup
  -> Creates VRFConsensusThread thread
  -> Thread detached
  -> Infinite loop:
       sleep_until(nextCycleStart)
       generate seed
       generate VRF structure
       add to own validatedVRfs (if qualified)
       broadcast VRF message
       computeMaxHeightWithMinFrequency()
       repeat
```
**Synchronization**: `mutable std::shared_mutex mutex_` protecting `validatedVRfs` and `newValidatedVRfs`

### 3.2 Block Sync Thread

**Owner**: `SyncBlock::ThreadStart()` [sync_block.cpp:175-395]
**Type**: `std::thread` detached
**Period**: `SYNC_HEIGHT_TIME = 10` seconds (variable)
**Lifecycle**:
```
ThreadStart() called at startup
  -> Creates _syncThread
  -> Thread detached
  -> Infinite loop:
       wait for condition_variable (sleepTime or notification)
       get chain heights
       get pledge addresses
       decide sync strategy:
         - SyncFromZero: runFromZeroSyncOnce()
         - SyncNormal: runNewSyncOnce()
         - SyncFast: runFastSyncOnce()
       handle failures and mode switching
       repeat
```
**Synchronization**:
- `syncThreadRunning`: atomic<bool>
- `syncThreadRunningMutex`: mutex + condition_variable
- `cacheSyncMutex`: protects syncFromZeroCache
- Static variables: `sync_fail_height`, `runFastSync`, `isFastSyncFailed`, `execute_new_sync` (no mutex protection!) -- 【需人工验证】Potential data race

### 3.3 Block Pool Timer (Process)

**Owner**: External timer calls `BlockHelper::Process()` [block_helper.cpp:1311]
**Type**: Called periodically via timer callback
**Period**: Configured via `CTimer` (`BLOCK_POOL_TIMER_INTERVAL`)
**Lifecycle**:
```
Process() called by timer
  -> Lock helperMutex
  -> Execute rollbackBlocks (with timeout check)
  -> Execute RollbackBlocks()
  -> Process fastSyncBlocks (with usleep(100000) between each)
  -> Process utxoMissingBlocks
  -> Process _syncBlocks
  -> Process broadcastBlocks
  -> Process hashPendingBlocks
  -> Cleanup expired blocks
  -> Release helperMutex
```
**Synchronization**: `helperMutex` (non-recursive mutex)

### 3.4 Seek Block Timer

**Owner**: External timer calls `BlockHelper::SeekBlockThreadObject()` [block_helper.cpp:1549]
**Type**: Called periodically via timer callback
**Period**: Configured via `CTimer` (`SEEK_BLOCK_TIMER`)
**Lifecycle**:
```
SeekBlockThreadObject() called by timer
  -> Lock seekMutex
  -> Iterate _missingBlocks:
       Check timeouts (30s) and retry counts (3)
       Collect expired hashes into missingHashs
       Delete expired entries
  -> Release seekMutex
  -> If missingHashs not empty: sendBlockByHashRequest()
```
**Synchronization**: `seekMutex`

### 3.5 Block Storage Timer

**Owner**: `BlockStorage::_StartTimer()` [block_stroage.cpp:18-23]
**Type**: AsyncLoop callback
**Period**: 100 milliseconds
**Lifecycle**:
```
_BlockCheck() called every 100ms
  -> Lock _blockMutex (shared)
  -> Iterate _blockCnt:
       Check signatures >= kConsensus AND lagTime <= 10s
       If satisfied: composeEndBlockMessage() then sendBroadcastAddBlockRequest()
       If timeout: mark for removal
  -> Remove processed entries
  -> checkExpiredDelete() called separately
```
**Synchronization**: `std::shared_mutex _blockMutex`

### 3.6 Check Blocks Timer

**Owner**: `CheckBlocks::StartTimer()` [check_blocks.cpp:36-45]
**Type**: AsyncLoop callback
**Period**: 30,000 milliseconds (30s)
**Lifecycle**:
```
_ToCheck() called every 30s
  -> Guard with isRunning atomic to prevent re-entrancy
  -> Get current block top
  -> If ready for next thousand-sum-hash checkpoint:
       Calculate local sumHash
       Query pledge nodes for their sumHash
       Wait for >= 90% responses (90s timeout)
       Compare with local
       If mismatch: calculateByzantineSumHash()
       If needed: performNewSynchronization()
```

### 3.7 epoll Network Thread

**Owner**: `net/` module
**Type**: epoll event loop
**Role**: Receives all network messages, dispatches to handlers
**Key dispatch points**:
- `HandleVRFConsensusInfoReq` -> VRFConsensusNode::receiveVRRequest [vrf_consensus.cpp:692-704]
- `handleFastSyncHashAcknowledge` -> SyncBlock [sync_block.h:358]
- `handleBlockByUtxoRequest` -> BlockHelper [sync_block.h:396]
- `processSyncSumHashRequest` -> SyncBlock [sync_block.h:371]
- Various others -> SyncBlock, BlockStorage, BlockHelper

### 3.8 TaskPool Workers

**Owner**: `MagicSingleton<TaskPool>`
**Type**: Thread pool (size configurable)
**Usage**:
- Transaction verification: `commitWorkTask` for `memoryVerificationTransactionRequest` / `verifyTransactionRequest`
- VRF broadcast: `commitBroadcastRequest` for `net_com::SendVRFConsensusInfoTask`
- Various high-volume async work

---

## 4. Critical Race Conditions and Safety Analysis

### 4.1 Static Variable Races (sync_block.cpp)

**Location**: `sync_block.cpp:29-43`
**Issue**: Static variables used across threads without explicit synchronization:
```cpp
static uint64_t sync_fail_height = 0;
static bool runFastSync = false;
static bool isFastSyncFailed = false;
static bool execute_new_sync = false;
static uint64_t initialSyncStartHeight = 0;
static uint32_t syncHeightCount = 100;
static uint64_t syncSendNewSyncNumber = UINT32_MAX;
static uint64_t syncSendFastSyncCount = global::ca::MIN_SYNC_QUAL_NODES;
static uint64_t sync_send_zero_sync_num = global::ca::MIN_SYNC_QUAL_NODES;
static uint32_t runFastSyncCount = 0;
static uint32_t runZeroSyncCount = 0;
```
**Risk**: Medium. All accesses are within the detached sync thread (single-writer), but `runFastSync` is set by `SetFastSync()` which may be called from other threads (e.g. sendBlockByUtxoRequest async thread).
**Verification**: Check if compiler barriers / atomic operations are sufficient.
【需人工验证】

### 4.2 BlockHelper::Process() Re-entrancy

**Location**: `block_helper.cpp:1311-1320`
```cpp
static bool processing_ = false;
if(processing_) { return; }
processing_ = true;
```
**Issue**: Protected by non-atomic static variable.
**Risk**: Low. Process is called from a single timer callback, but explicit atomic would be safer.

### 4.3 BlockStorage double check

**Location**: `block_stroage.cpp:69-121`
**Issue**: `_BlockCheck()` locks `_blockMutex`, iterates `_blockCnt`, calls `composeEndBlockMessage()` which may trigger callbacks.
**Risk**: Low. The lock scope is the entire function body.

### 4.4 VRF data map concurrent access

**Location**: `vrf_consensus.cpp`
**Issue**: `validatedVRfs` and `newValidatedVRfs` are protected by `shared_mutex`, but:
- `run()` loop: takes exclusive lock in `computeMaxHeightWithMinFrequency` [line 329]
- `extractPackagerVRFData`: takes exclusive lock [line 554]
- `receiveVRRequest`: takes lock via `addVRFStructure` -> `unique_lock` [line 243]
- `checkVRFExists`: takes shared lock [line 267]
**Assessment**: Correct locking protocol observed.

---

## 5. Timer Configuration Summary

| Timer | Registry Key | Period | Purpose |
|-------|-------------|--------|---------|
| BLOCK_POOL_TIMER_INTERVAL | "blockpool" | Configurable | Trigger BlockHelper::Process() |
| SEEK_BLOCK_TIMER | "SeekBlock" | Configurable | Trigger SeekBlockThreadObject() |
| DATABASE_TIMER | "database" | Configurable | DB maintenance operations |
| BlockStorage::_blockTimer | Internal | 100ms | Block flow check |
| CheckBlocks::_timer | Internal | 30s (hardcoded) | Thousand-sum-hash verification |
| VRF::ClearTimer | Internal | 3s | VRF cache cleanup |
| VRFConsensusNode::VRFConsensusThread | Internal | 10s (cycle-aligned) | VRF consensus cycle |
| SyncBlock::_syncThread | Internal | 10s (condition variable) | Block sync worker |
