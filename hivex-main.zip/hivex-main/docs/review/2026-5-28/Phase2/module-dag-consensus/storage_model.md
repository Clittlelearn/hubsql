# Module 4: Storage Model

## 1. Storage Architecture Overview

```
Application Layer
    |
DBReader / DBReadWriter (TransactionDB wrapper)
    |
RocksDB (TransactionDB mode)
    |
Key-Value store with prefixed keys
```

MeMeChain uses RocksDB TransactionDB for atomic multi-key operations. All data is stored as key-value pairs, organized by key prefixes.

## 2. Key Prefix Specification

### 2.1 Block Storage (Module 4 Core)

| Key Pattern | Value Type | Description | Source |
|-------------|-----------|-------------|--------|
| `BH:{height}` | `vector<blockHash>` | Height -> All block hashes at that height (DAG support) | spec 8.3.1 |
| `B:{blockHash}` | `CBlock (serialized)` | Full block data by hash | spec 8.3.1 |
| `SH:{height}` | `string (SumHash)` | Height-level SumHash for fast sync verification | spec 8.3.1 |
| `TH:{thousandNum}` | `string (SumHash)` | Thousand-block-level SumHash for integrity verification | spec 8.3.1 |
| `TOP` | `uint64_t (height)` | Current highest block height | spec 8.3.1 |
| `BLOCK_NUM:{period}` | `uint64_t` | Number of blocks in a VRF period | spec 8.3.6 |
| `SIGN:{period}:{address}` | `uint64_t` | Signature count per node per period | spec 8.3.6 |
| `SIGN_ADDR:{period}` | `vector<address>` | All signing addresses in a period | spec 8.3.6 |
| `PACKAGER` | `packagerCount` | Packager selection statistics | spec 8.3.6 |

### 2.2 Code References for Block Keys

| Key | Read/Written Where |
|-----|-------------------|
| `BH:{height}` | `dbReader.getBlockHashsByBlockHeight(height, hashes)` [vrf_consensus.cpp:85, sync_block.cpp:112, block_helper.cpp:209] |
| | Written in `ca_algorithm::SaveBlock()` [algorithm.cpp:3986+] |
| `B:{blockHash}` | `dbReader.getBlockByBlockHash(hash, raw)` [block_helper.cpp:629] |
| | Written in `ca_algorithm::SaveBlock()` |
| `TOP` | `dbReader.getBlockTop(top)` [block_helper.cpp:613, vrf_consensus.cpp:76, sync_block.cpp:102] |
| | Updated after successful block save |
| `SIGN:{period}:{addr}` | `dbReader.getSignCountByPeriod(period, addr, count)` [algorithm.cpp:82] |
| | Period = `TimeUtil::GetPeriod(timestamp)` |
| `SIGN_ADDR:{period}` | `dbReader.getSignAddrByPeriod(period, addresses)` [algorithm.cpp:71] |

## 3. SumHash Storage Schema

### 3.1 Per-Height SumHash

**Key**: `SH:{height}`
**Value**: SHA256 hash computed from all block hashes at that height
**Computation**: `calculateHeightsSumHash()` [algorithm.cpp:289]

```
sumHash(height) = SHA256(concat(sorted(all_hash_at_height)))
```

### 3.2 Thousand-Block SumHash

**Key**: `TH:{thousandNum}`
**Value**: SHA256 hash summarizing 1000 block heights
**Computation**: `calculateSumHashOf1000Heights()` [algorithm.cpp:309]

```
thousandSumHash(n) = SHA256(concat(SH_{n*1000-999}, SH_{n*1000-998}, ..., SH_{n*1000}))
```

**Verification**: `CheckBlocks::_ToCheck()` [check_blocks.cpp:78-165]
- Period: Every 30 seconds
- Trigger condition: `nodeSelfHeight >= topBlockHeight + 1100`
- Process: Calculate local thousand-sum-hash -> Query pledge nodes -> Compare -> Byzantine if mismatch

### 3.3 Sync Hash Verification

**Fast Sync** (`SyncGetSumHashReq`/`SyncGetSumHashAck`):
- Request per-height hashes from nodes
- Compare with local hashes
- Download mismatched blocks

**New Sync** (`SyncGetHeightHashReq`/`SyncGetHeightHashAck`):
- Use `sumHeightsHash()` [sync_block.cpp:74-86]
- Sort hashes at each height -> SHA256 -> concat all -> SHA256
- Compare aggregate hash across nodes

**From Zero Sync** (`SyncFromZeroGetSumHashReq`/`SyncFromZeroGetSumHashAck`):
- Query thousand-block SumHash values
- Compare with local
- Download blocks for mismatched ranges

## 4. BlockStatus Storage

### 4.1 In-Memory Structure

**Location**: `BlockStorage::blockStatusMap` [block_stroage.h:236]
**Type**: `std::map<std::string, BlockStatusWrapper>`
**Protected by**: `std::mutex _statusMutex`

```cpp
struct BlockStatusWrapper {
    std::string blockHash;
    CBlock block;
    BroadcastType broadcastType;  // verifyBroadcast / level1BroadcastMessage
    uint32_t nodeVerificationCount;
    uint32_t level1_node_count;
    std::vector<BlockStatus> blockStatusList;
    std::set<std::string> verifyNodes;     // Nodes that verified this block
    std::set<std::string> level1Nodes;     // Level-1 nodes
};
```

### 4.2 BlockStatus Message Format

```protobuf
message BlockStatus {
    string blockHash = 1;
    int32 status = 2;           // Error code (0 = success)
    repeated TxStatus txStatus = 3;  // Failed transactions
    string id = 4;              // Verifier node ID
}
```

### 4.3 BlockStatus Lifecycle

1. **Created**: When `BlockStorage::_BlockCheck()` detects signatures >= kConsensus [block_stroage.cpp:94-96]
2. **Updated**: When nodes send `BlockStatus` messages via `AddBlockStatus()` [block_stroage.h:120-139]
3. **Checked**: `BlockStorage::CheckData(blockStatus)` [block_stroage.h:153]
4. **Expired**: `checkExpiredDelete()` called by 100ms timer [block_stroage.cpp:145 class decl]
5. **Used**: For building broadcast messages with verified nodes

### 4.4 Consensus Weight via BlockStatus

`BlockStatusWrapper.verifyNodes` accumulates verified node IDs:
- Each node sends a `BlockStatus` after receiving `BlockMsg`
- `AddBlockStatus` inserts the node ID
- The count of `verifyNodes` per block represents consensus weight
- This feeds into the `_BlockCheck` that triggers block saving when consensus threshold is met

## 5. DB Access Patterns

### 5.1 Read Patterns

| Read Operation | Key Pattern | Frequency | Caller |
|---------------|-------------|-----------|--------|
| Get block top | `TOP` | Multiple per cycle | BlockHelper, SyncBlock, VRFConsensusNode |
| Get blocks by height range | `BH:{*}` | Per sync cycle | SyncBlock |
| Get block by hash | `B:{hash}` | Per block save/verify | BlockHelper, ca_algorithm |
| Get sum hash by height | `SH:{height}` | Per sync check | CheckBlocks |
| Get thousand sum hash | `TH:{n}` | Every 30s | CheckBlocks |
| Get sign count by period | `SIGN:{period}:{addr}` | Per reward calc | ca_algorithm |
| Get sign addr by period | `SIGN_ADDR:{period}` | Per reward calc | ca_algorithm |
| Get block top | `TOP` | Multiple per cycle | Various |

### 5.2 Write Patterns

| Write Operation | Key Pattern | Transaction | Caller |
|----------------|-------------|-------------|--------|
| Save block + index | `B:{hash}`, `BH:{height}`, `TOP` | Single transaction | ca_algorithm::SaveBlock |
| Save transactions | `TX:{txHash}`, `TXBH:{txHash}` | Same transaction | ca_algorithm::SaveBlock |
| Update UTXO states | `UB:...`, `UAH:...`, `BAL:...` | Same transaction | ca_algorithm::SaveBlock |
| Update sign stats | `SIGN:...`, `SIGN_ADDR:...`, `BLOCK_NUM:...` | Post-save | PostSaveProcess |
| Delete block | `B:{hash}`, `BH:{height}`, `TX:*`, UTXOs | Single transaction | ca_algorithm::DeleteBlock |
| Save SumHash | `SH:{height}`, `TH:{n}` | Post-save batch | calculateHeightsSumHash |

### 5.3 Transaction Scope

- `BlockHelper::SaveBlock()` calls `ca_algorithm::SaveBlock(dbWriter, ...)` then `dbWriter.transactionCommit()` [block_helper.cpp:646,669]
- `ca_algorithm::SaveBlock()` implements the full block write in a single RocksDB transaction [algorithm.cpp:3986+]
- `ca_algorithm::DeleteBlock()` uses its own transaction for rollback [algorithm.cpp: DeleteBlock body]
- `ca_algorithm::RollBackToHeight()` creates its own DBReadWriter transaction [algorithm.cpp:7511+]

## 6. Data Integrity Mechanisms

### 6.1 SumHash Chain

```
height=0: SH[0] = SHA256(concat(all hash at height 0))
height=1: SH[1] = SHA256(concat(all hash at height 1))
...
height=999: SH[999] = SHA256(concat(all hash at height 999))
TH[0] = SHA256(concat(SH[0..999]))
TH[1] = SHA256(concat(SH[1000..1999]))
```

### 6.2 Verification Flow

1. `ca_algorithm::calculateHeightsSumHash()` [algorithm.cpp:289] -- Builds per-height sum hash
2. `ca_algorithm::calculateSumHashOf1000Heights()` [algorithm.cpp:309] -- Builds thousand-block sum hash
3. `CheckBlocks::_ToCheck()` [check_blocks.cpp:78] -- Periodically verifies thousand-block hashes
4. `SyncBlock::sumHeightsHash()` [sync_block.cpp:74] -- Used for sync hash comparison
5. Byzantine check: If local sum hash differs from majority of network nodes, trigger resync

### 6.3 Rollback Integrity

| Aspect | Implementation | Issues |
|--------|---------------|--------|
| Block deletion atomicity | `DeleteBlock(dbWriter, blockHash)` in single RocksDB transaction | OK |
| UTXO restoration | Commented out in `rollbackPreviousBlocks` logic; actual UTXO recovery via `SetFastSync` re-sync | **Problematic: re-syncs entire chain from height, not selective UTXO recovery** |
| Transaction rollback | Transactions deleted as part of DeleteBlock | OK for removed blocks |
| Contract state rollback | `rollbackContractBlock()` called before block rollback [block_helper.cpp:1240] | OK |

## 7. Compacted Key Index (Quick Reference)

```
Key: BH:0, BH:1, ..., BH:{top}
Key: B:{64-char-hex-hash}
Key: SH:0, SH:1, ..., SH:{top}
Key: TH:0, TH:1, TH:2, ...
Key: TOP (single key)
Key: BLOCK_NUM:{period_number}
Key: SIGN:{period_number}:{40-char-address}
Key: SIGN_ADDR:{period_number}
Key: PACKAGER (single key)
Key: TX:{64-char-tx-hash}
Key: TXBH:{64-char-tx-hash}
Key: UB:{addr}:{assetType}:{64-char-utxo-hash}
Key: UAH:{addr}:{assetType}
Key: BAL:{addr}:{assetType}
Key: STAKE:{addr}:{assetType}
Key: DELEG:{bonusAddr}:{delegAddr}:{assetType}
Key: EVM_CODE:{contractAddr}
Key: MPT:{mptKey}
```

## 8. Pending Verification Items

| Item | Question | Priority |
|------|----------|----------|
| SV-1 | Are `UB:`, `UAH:`, `BAL:` keys correctly computed and unique? Check UTXO hash generation algorithm | High |
| SV-2 | Is the `calculateSumHashOf1000Heights` computation deterministic across nodes with the same blocks? | Medium |
| SV-3 | What happens to `SH:{height}` when a block at that height is rolled back? Need to verify SumHash recalculation logic | High |
| SV-4 | Are `SIGN:{period}:{addr}` statistics correct after a rollback? | Medium |
| SV-5 | Is the period computation `TimeUtil::GetPeriod()` consistent across all nodes? | Medium |
