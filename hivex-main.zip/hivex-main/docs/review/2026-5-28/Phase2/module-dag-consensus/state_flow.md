# Module 4: State Flow Diagrams

## 1. Block State Machine

```mermaid
stateDiagram-v2
    [*] --> Receive: BlockMsg from network
    Receive --> VerifyPreHash: VerifyBlock()
    VerifyPreHash --> MissingPreHash: prevhash not in DB
    MissingPreHash --> Pending: AddPendingBlock()
    Pending --> VerifyPreHash: prevhash arrives
    
    VerifyPreHash --> MemVerify: memVerifyBlock()
    MemVerify --> MemVerifyFail: Version/Hash/Merkle/Tx error
    MemVerifyFail --> [*]: Discard
    
    MemVerify --> FullVerify: VerifyBlock() continues
    FullVerify --> TxVerify: Verify each transaction
    TxVerify --> ContractVerify: verifyContractBlock()
    
    FullVerify --> TimeFail: Block time out of range
    HeightAhead --> [*]: discard (SaveBlock height check)
    
    FullVerify --> PreSaveVerify: verifyPreSaveBlock_()
    PreSaveVerify --> SignInvalid: signature count != kConsensus
    SignInvalid --> [*]: Discard
    
    PreSaveVerify --> SaveDB: ca_algorithm::SaveBlock()
    SaveDB --> Commit: transactionCommit()
    Commit --> CommitFail: DB error
    CommitFail --> [*]: Return error
    
    Commit --> MainChain: Success, top updated
    MainChain --> ForkCandidate: Alternative chain with more consensus
    
    state ForkCandidate {
        [*] --> Monitor: Block exists at same height
        Monitor --> ConsensusCheck: Periodically check (15s)
        ConsensusCheck --> Stay: Local hash >= 51%
        ConsensusCheck --> Rollback: Remote hash >= 51%
        ConsensusCheck --> Isolate: No hash >= 51%
        Stay --> [*]: Keep as main chain
        Isolate --> [*]: Mark as isolated, wait
    }
    
    Rollback --> DeleteBlock: ca_algorithm::DeleteBlock()
    DeleteBlock --> RestoreUTXO: UTXO state recovery
    RestoreUTXO --> ApplyNewBlock: Sync & save new block
    ApplyNewBlock --> MainChain: New top
```

## 2. Block Status Tracking (BlockStatus)

```mermaid
stateDiagram-v2
    [*] --> Received: BlockMsg arrives
    Received --> Flowing: BlockStorage::AddBlock()
    Flowing --> CollectingSignatures: _BlockCheck() activated
    CollectingSignatures --> SignaturesComplete: signature count >= kConsensus
    SignaturesComplete --> BroadcastBuilt: composeEndBlockMessage()
    BroadcastBuilt --> Verified: BlockHelper::SaveBlock() succeeds
    Verified --> Persisted: DB commit succeeds
    Persisted --> Confirmed: 15s pass without rollback
    
    CollectingSignatures --> Timeout: lagTime > 10 seconds
    Timeout --> [*]: Removed from _blockCnt
    
    Verified --> SaveFailed: DB error or biz logic error
    SaveFailed --> MissingPreHash: prevhash not found
    SaveFailed --> MissingBlock: UTXO not found -> getMissingBlock()
    
    Confirmed --> RolledBack: Fork resolution triggers rollback
    RolledBack --> [*]: Block deleted from DB
```

## 3. Consensus State (VRF)

```mermaid
stateDiagram-v2
    [*] --> WaitForCycle: VRFConsensusNode::run() starts
    WaitForCycle --> SeedGeneration: sleep_until(nextCycleStart)
    SeedGeneration --> Signing: generateVRSeed() + generateVRFStructure()
    Signing --> Broadcasting: vrfBroadcastMessage() to all nodes
    Broadcasting --> Receiving: receiveVRRequest() from peers
    
    state Receiving {
        [*] --> TimeCheck: received
        TimeCheck --> BadTime: |timeDiff| > 10s
        TimeCheck --> QualCheck: time OK
        QualCheck --> Unqualified: blockinfo != 10 or not staking
        QualCheck --> SigCheck: qualified
        SigCheck --> BadSig: signature verify fail
        SigCheck --> StoreVRF: signature OK
        BadTime --> [*]: Discard
        Unqualified --> [*]: Discard
        BadSig --> [*]: Discard
        StoreVRF --> Relayed: vrfBroadcastMessage() relay
        StoreVRF --> Added: validatedVRfs updated
    }
    
    Added --> FrequencyCompute: computeMaxHeightWithMinFrequency()
    FrequencyCompute --> InsufficientData: validatedVRfs.size() < 3
    FrequencyCompute --> FrequencyDone: newValidatedVRfs populated
    
    FrequencyDone --> PackagerSelect: extractPackagerVRFData() called by packager
    PackagerSelect --> Selected: Randomly selected kConsensus=3 nodes
    Selected --> BlockPackaging: Packager creates block
    
    InsufficientData --> WaitForCycle
    FrequencyDone --> WaitForCycle
    Relayed --> WaitForCycle
```

## 4. Sync State Machine

```mermaid
stateDiagram-v2
    [*] --> SyncNormal: Local height close to network height
    
    state SyncNormal {
        [*] --> CheckDiff: Compare local vs network height
        CheckDiff --> Stuck: nodeSelfHeight == chainHeight for 6 cycles
        Stuck --> ByzCheck: needByzantineAdjustment()
        ByzCheck --> NewSync: Run runNewSyncOnce()
        CheckDiff --> NewSync: nodeSelfHeight < chainHeight
        NewSync --> SumHashRequest: getSyncBlockHashVerification()
        SumHashRequest --> CompareHashes: Compare local vs remote
        CompareHashes --> NoDiff: All hashes match
        CompareHashes --> HasDiff: Some heights differ
        HasDiff --> DownloadBlock: getSyncBlockData()
        DownloadBlock --> SaveBlockMap: Blocks saved via AddSyncBlock
        SaveBlockMap --> CheckDiff
        NoDiff --> CheckDiff
    }

    SyncNormal --> SyncFast: runFastSync = true (triggered by SetFastSync)
    
    state SyncFast {
        [*] --> FastHashReq: get_fast_sync_sum_hash_node()
        FastHashReq --> FastBlockDownload: get_fast_sync_block_data()
        FastBlockDownload --> FastApply: AddFastSyncBlock() to fastSyncBlocks
        FastApply --> FastDone: Applied successfully
        FastApply --> FastFailed: Failed
        FastFailed --> RetryCheck: runFastSyncCount++
        RetryCheck --> FastRetry: runFastSyncCount < 5
        FastRetry --> FastHashReq
        RetryCheck --> SyncFromZero: runFastSyncCount >= 5
    }
    
    SyncNormal --> SyncFromZero: chainHeight - localHeight > hashRangeSum
    
    state SyncFromZero {
        [*] --> calculateHeights: Determine sync heights (multiples of hashRangeSum)
        calculateHeights --> SumHashFromZero: get_from_zero_sync_sum_hash_node()
        SumHashFromZero --> Compare1000Hash: Compare thousand-block sum hashes
        Compare1000Hash --> DownloadFromZero: getSyncBlockDataFromZero()
        DownloadFromZero --> VerifySumHash: Verify downloaded blocks' sum hash
        VerifySumHash --> FromZeroDone: All verified
        VerifySumHash --> FromZeroFailed: Mismatch -> retry
        FromZeroFailed --> calculateHeights: Retry with adjusted params
    }
    
    FromZeroDone --> SyncNormal
    FastDone --> SyncNormal
```

## 5. Fork Resolution State Detail

```mermaid
stateDiagram-v2
    [*] --> Idle: Normal operation
    Idle --> Triggered: 15s timer fires
    
    Triggered --> QueryNodes: Send height range query to pledge nodes
    QueryNodes --> WaitResponses: Wait for responses
    WaitResponses --> InsufficientResponse: < 80% received
    InsufficientResponse --> Idle: Wait next cycle
    
    WaitResponses --> BuildConsensusMap: >= 80% received
    BuildConsensusMap --> HeightIteration: For each height in range
    
    state HeightIteration {
        [*] --> CheckHash: For each hash at this height
        CheckHash --> LocalMatch: Local hash >= 51% support
        CheckHash --> ForkFound: Remote hash >= 51%, local != remote
        CheckHash --> Ambiguous: No hash >= 51%
        
        LocalMatch --> [*]: Keep, no action
        Ambiguous --> [*]: Mark isolated
        ForkFound --> RollbackDecision: Evaluate rollback conditions
    }
    
    RollbackDecision --> TimeProtected: Block age > 15s
    RollbackDecision --> TimeFresh: Block age <= 15s (protected)
    TimeFresh --> Idle: Skip, too recent
    
    TimeProtected --> DepthCheck: Rollback depth
    DepthCheck --> DepthOK: Depth <= limit
    DepthCheck --> DepthExceeded: Fast sync failed 5 times
    DepthExceeded --> SyncFromZero: Switch to full resync
    
    DepthOK --> ExecuteRollback: rollback_block_()
    ExecuteRollback --> RollbackBlocks: RollbackBlocks() called
    
    state RollbackBlocks {
        [*] --> ContractRollback: rollbackContractBlock()
        ContractRollback --> IterateRollback: For each block (reverse height order)
        IterateRollback --> SingleRollback: RollbackBlock(hash, height)
        SingleRollback --> FetchCorrect: fetchRollbackBlock() from consensus nodes
        FetchCorrect --> ApplyCorrect: DeleteBlock(old) + save new
        ApplyCorrect --> IterateRollback
    }
    
    RollbackBlocks --> DownloadMissing: Sync missing blocks
    DownloadMissing --> ApplyNewChain: AddSyncBlock() -> SaveBlock() chain
    ApplyNewChain --> Idle: Resolution complete
```

## 6. Block Verification Detail

```mermaid
flowchart TD
    A[Block arrives] --> B{Block already in DB?}
    B -->|Yes| A1[Return 0 - skip]
    B -->|No| C{prevhash exists in DB?}
    C -->|No| C1[set_missing_prehash - return -2]
    C -->|Yes| D{height == preBlock.height + 1?}
    D -->|No| D1[return -4]
    D -->|Yes| E[memVerifyBlock]
    
    subgraph memVerifyBlock
        E1[Check version == kCurrentBlockVersion]
        E2[Check serialized size < 4MB]
        E3[Check hash matches CalcBlockHash]
        E4[Check merkleroot matches calculateBlockMerkle]
        E5[Check tx count validity]
        E6[Group txs by hash, reject duplicates]
        E7[memoryVerificationTransactionRequest for each tx]
        E1 --> E2 --> E3 --> E4 --> E5 --> E6 --> E7
    end
    
    E --> F{memVerify OK?}
    F -->|No| F1[return error code - 10000]
    F -->|Yes| G{Time check: block.time in [startTime - 10s, now + 10min]?}
    G -->|No| G1[return -8]
    G -->|Yes| H[Transaction verification]
    
    subgraph TxVerification
        H1[For each tx: verifyTransactionRequest in TaskPool]
        H2[verifyContractBlock for contract txs]
        H3[Wait all futures, check results]
        H1 --> H2 --> H3
    end
    
    H --> I{All txs valid?}
    I -->|No| I1[return -12, failed txs in blockStatus]
    I -->|Yes| J[Return 0 - verified]
    
    J --> K[PreSaveProcess continues]
    K --> L[verifyPreSaveBlock_: check signature count == kConsensus]
    L --> M{count matches?}
    M -->|No| M1[return -1]
    M -->|Yes| N[ca_algorithm::SaveBlock]
```
