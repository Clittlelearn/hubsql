# Module 4: Class Analysis

## 1. Core Data Structures

### 1.1 CBlock (Protobuf Message)

- **File**: `proto/block.proto:17-32`
- **Fields**: version(version), time(microsecond timestamp), hash(SHA256), prevhash, height, merkleroot, txs(repeated CTransaction), data, info, signature(repeated CSign), reserve0, reserve1
- **Lifecycle**: Create (打包节点构造) -> Sign (签名附加) -> Broadcast -> Verify -> Save -> Store (RocksDB)
- **Identity**: 区块哈希 = `SHA256(Serialize(CBlock without hash and signature))`
- **DB Key**: `B:{blockHash}` -> `blockRaw`
- **Notes**: DAG 结构允许同一高度有多个区块，通过 `BH:{height}` -> `vector<blockHash>` 索引

### 1.2 BlockStatus (Protobuf Message)

- **File**: `proto/block.proto:73-79`
- **Fields**: blockHash, status(error code), txStatus(repeated TxStatus for failed txs), id(self node ID)
- **Purpose**: 追踪每个区块的验证状态，用于共识统计和节点间通信
- **TxStatus** (proto/block.proto:66-70): txHash + status

### 1.3 BlockMsg (Protobuf Message)

- **File**: `proto/block.proto:35-48`
- **Fields**: nonce, version, code, message, time, block(bytes), verifyAddrs(repeated), dispatcher_vrf(ECVRF proof), validator_vrf(ECVRF proof)
- **Purpose**: 区块流转消息，携带区块数据和 VRF 证明
- **Notes**: `reserved 8` 标记了废弃字段；`dispatcher_vrf` 和 `validator_vrf` 是 RFC 9381 ECVRF 证明

### 1.4 BlockStatusWrapper (C++ Struct)

- **File**: `ca/block_stroage.h:28-38`
- **Fields**:
  - `blockHash`: 区块哈希
  - `block`: CBlock 完整区块
  - `broadcastType`: verifyBroadcast / level1BroadcastMessage
  - `nodeVerificationCount`: 验证节点总数
  - `level1_node_count`: 一级节点数
  - `blockStatusList`: vector<BlockStatus>
  - `verifyNodes`: set<string> 验证节点 ID
  - `level1Nodes`: set<string> 一级节点 ID
- **Lifecycle**: Created in `BlockStorage::_BlockCheck()` -> stored in `blockStatusMap` -> used for building broadcast messages
- **Notes**: 用于在区块流转中追踪验证节点集合，`nodeVerificationCount` 可能是共识权重的代理变量

### 1.5 VRFStructure (C++ Class)

- **File**: `ca/vrf_consensus.h:18-40`
- **Fields**: seed, signature, nodeId, signatureHash(SHA256(signature)), frequency(0.0 initially), height_hashes(map<height, vector<hash>>)
- **Constructor**: `VRFStructure(seed, signature, nodeId)` (vrf_consensus.cpp:27-28)
- **Key Methods**:
  - `getAddress()` -> nodeId
  - `getSignatureHash()` -> SHA256 of signature
  - `getFrequency()` -> frequency (set via `addFrequency()`)
  - `calculateHeightHashes()` -> full height_hashes map
  - `addHashForHeight(height, hash)` -> append to height_hashes
  - `addFrequency(f)` -> sets frequency

### 1.6 VRFConsensusInfo (Protobuf Message)

- **File**: (imported from `pb/ca_protomsg.proto`)
- **Fields**: vrfSeed, blockinfo(repeated, each: blockhash + height), vrfsign(CSign)
- **Purpose**: 节点广播的 VRF 共识信息，包含种子、区块信息和签名

---

## 2. Core Classes

### 2.1 VRFConsensusNode

- **File**: `ca/vrf_consensus.h:42-71`, `ca/vrf_consensus.cpp`
- **Responsibility**: VRF 共识主控，管理 VRF 数据结构、执行周期运行、节点选择和资格判定
- **Lifecycle**: Singleton (via MagicSingleton) -> Process() starts thread -> run() infinite loop
- **Key Methods**:

| Method | Line | Description |
|--------|------|-------------|
| `Process()` | h:281-282 / cpp:278-282 | 启动 VRF consensus thread (detached) |
| `run()` | h:48 / cpp:284-336 | 主循环: 等待周期开始 -> 生成种子 -> 签名 -> 广播 -> computeMaxHeightWithMinFrequency |
| `generateVRFStructure(seed, vrf)` | h:46 / cpp:70-124 | 从 top 向下查 10 个高度，取 hash 前 8 字符，签名整个结构 |
| `vrfBroadcastMessage(vrf)` | h:47 / cpp:126-137 | 向全网 peer 广播 VRFConsensusInfo |
| `receiveVRRequest(vrf)` | h:48 / cpp:166-226 | 接收 VRF 请求: 时间验证 -> 质押检查 -> blockinfo 验证 -> 签名验证 -> addVRFStructure -> 二次广播 |
| `validate_block_info(vrf, nodeId)` | h:65 / cpp:139-163 | 验证质押资格 + blockinfo=10 + 哈希去重 |
| `addVRFStructure(vrfInfo, nodeId)` | h:53 / cpp:242-263 | 添加到 validatedVRfs，调用 pruneOldData |
| `computeMaxHeightWithMinFrequency(seed)` | h:55 / cpp:339-481 | 核心: 取倒数第 3 周期数据 -> 统计高度哈希频率 -> 计算 optimalFrequency -> 按 0.55 阈值筛选 -> 填充 newValidatedVRfs |
| `extractPackagerVRFData(nodes, timestamp)` | h:51 / cpp:544-625 | 打包节点选择: 按频率升序 -> maxValue 递减筛选 -> selectRandomNodes |
| `extractVRFData(dataSource, timestamp)` | h:50 / cpp:485-519 | 底层: 获取前一周期种子对应的 VRF 数据 |
| `selectRandomNodes(dataSource, nodes, count)` | cpp:521-542 (free function) | 随机选择: SHA256(sum of all signatureHash) as seed -> shuffle |
| `generateVRSeed(time)` | h:62 / cpp:628-633 | VRF 种子 = floor(epoch_seconds / 10) * 10 |
| `cycleStartTimestamp(current_time)` | h:63 / cpp:635-640 | 下一周期起始 = 对齐到 10 秒边界 + 10 秒 |
| `getPreviousCycleTime(timestamp)` | h:64 / cpp:642-648 | 前一周期 = 当前周期 - 2 * 10 秒 |
| `pruneOldData()` | h:61 / cpp:228-240 | 当 size > MAX_VRFS_SIZE(10) 时删除最旧数据 |

- **Thread Safety**: `mutable std::shared_mutex mutex_` 保护 validatedVRfs 和 newValidatedVRfs
- **State**:
  - `validatedVRfs`: map<seed, map<nodeId, VRFStructure>> (已确认数据)
  - `newValidatedVRfs`: map<seed, map<nodeId, VRFStructure>> (computeMaxHeightWithMinFrequency 输出)

### 2.2 BlockHelper

- **File**: `ca/block_helper.h:117-422`, `ca/block_helper.cpp`
- **Responsibility**: 区块保存统筹、回滚管理、缺失区块协议、双花处理、区块广播接收
- **Lifecycle**: Singleton -> Process() 在定时器中周期性调用
- **Key Methods**:

| Method | Line | Description |
|--------|------|-------------|
| `SaveBlock(block, saveType, computeMeanValue)` | h:139 / cpp:597-700 | 主保存入口: 去重检查 -> PreSaveProcess -> ca_algorithm::SaveBlock -> transactionCommit -> PostSaveProcess |
| `verifyFlowedBlockStatus(block, blockStatus, msg)` | h:129 | 区块流转状态验证 |
| `Process()` | h:175 / cpp:1311-1547 | 区块保存主循环: rollbackBlocks -> fastSyncBlocks -> utxoMissingBlocks -> _syncBlocks -> broadcastBlocks -> hashPendingBlocks |
| `AddBroadcastBlock(block, status)` | h:188 | 添加广播收到的区块到 broadcastBlocks |
| `AddSyncBlock(syncBlockData, type)` | h:196 | 添加同步区块到 _syncBlocks |
| `AddFastSyncBlock(syncBlockData, type)` | h:204 | 添加快速同步区块到 fastSyncBlocks |
| `rollback_block_(rollbackBlockInfo)` | h:211 / cpp:2100-2104 | 设置回滚区块映射到 rollbackBlocks |
| `RollbackBlock(blockHash, height)` | cpp:1155-1231 | 单个区块回滚: 从远程获取新区块 -> DeleteBlock |
| `RollbackBlocks()` | cpp:1233-1262 | 遍历 rollbackBlocks 执行批量回滚 |
| `rollbackPreviousBlocks(utxo, shelfHeight, blockHash)` | cpp:189-254 | UTXO 查找触发的回滚: 从 shelfHeight 向下查找包含该 UTXO 的区块并触发 SetFastSync |
| `getChainHeight(chainHeight)` | h:170 / cpp:2113-2177 | 获取全网高度: 从质押节点高度取第 75 百分位 |
| `SeekBlockThreadObject()` | h:181 / cpp:1549-1622 | 缺失区块定时搜索: 超时 30s/重试 3 次 -> sendBlockByHashRequest |
| `dealDoubleSpend(block, tx, missingUtxo)` | h:260 | 双花检测和处理 |
| `getMissingBlock()` | cpp:1284-1300 | 启动 sendBlockByUtxoRequest 线程查找缺失区块 |

- **Internal Queues**:
  - `broadcastBlocks`: set<CBlock, blockTimeAscending> -- 广播接收的区块
  - `_syncBlocks`: set<CBlock, blockTimeAscending> -- 同步的区块
  - `fastSyncBlocks`: set<CBlock, blockTimeAscending> -- 快速同步区块
  - `rollbackBlocks`: map<height, set<CBlock, BlockComparator>> -- 待回滚区块
  - `_pendingBlocks`: map<height, multimap<hash, CBlock>> -- 因缺少 prevhash 等待的区块
  - `hashPendingBlocks`: map<hash, pair<time, CBlock>> -- 通过查找协议找到的区块
  - `utxoMissingBlocks`: vector<CBlock> -- 通过 UTXO 查找找到的区块
  - `_missingBlocks`: set<MissingBlock> -- 等待触发查找协议的缺失哈希
  - `doubleSpendBlocks`: map<hash, CBlock> -- 双花区块
  - `contractBlocks`: map<hash, pair<prevHash, CBlock>> -- 合约区块缓存

### 2.3 BlockStorage

- **File**: `ca/block_stroage.h:39-239`, `ca/block_stroage.cpp`
- **Responsibility**: 区块流转状态管理、BlockStatus 追踪、PreHash 查询
- **Lifecycle**: Singleton -> `_StartTimer()` 启动 100ms 定时器
- **Key Methods**:

| Method | Line | Description |
|--------|------|-------------|
| `AddBlock(msg)` | h:62 / cpp:27-41 | 添加区块消息到 `_blockCnt` |
| `UpdateBlock(msg)` | h:70 / cpp:43-66 | 追加签名到已存在区块的消息列表 |
| `_BlockCheck()` | h:176 / cpp:69-121 | 定时检查: 当签名数 >= kConsensus 且时延 <= 10s -> composeEndBlockMessage -> sendBroadcastAddBlockRequest |
| `composeEndBlockMessage(msgVec, outMsg, isVrf)` | cpp:124-173 | 从多个签名中随机选 kConsensus-1 个，组装最终区块 |
| `AddBlockStatus(blockHash, Block, verifyNodes)` | h:129-139 | 三种重载: (BlockStatus) / (hash+Block+level1Nodes) / (hash+Block+verifyNodes) |
| `checkExpiredDelete()` | h:145 | 过期区块状态清理 |
| `GetPrehash(height)` | h:77 / cpp:191-199 | 从 preHashMap 共享 future 获取 PreHash |
| `commitLookupTask(seekHeight)` | h:84 | 提交 PreHash 查找任务 |
| `BlockFlowSignVerifier(blockMsg)` | h:208 | 区块流签名验证 |

- **Internal State**:
  - `_blockCnt`: map<hash, vector<BlockMsg>> -- 区块消息缓冲
  - `preHashMap`: map<height, shared_future<RetType>> -- PreHash 异步查询
  - `blockStatusMap`: map<blockHash, BlockStatusWrapper> -- 区块状态映射
  - `_failureRate`: double = 0.75

### 2.4 BlockMonitor

- **File**: `ca/block_monitor.h:37-77`, `ca/block_monitor.cpp`
- **Responsibility**: 区块广播发送、交易成功率统计
- **Lifecycle**: Singleton
- **Key Methods**:

| Method | Line | Description |
|--------|------|-------------|
| `sendBroadcastAddBlockRequest(blockMsg, blockHeight)` | h:54 / cpp:74-100+ | 构建 BuildBlockBroadcastMsg 并广播给高度匹配节点 |
| `dropshippingTxVec(txHash)` | cpp:62-66 | 记录已发出交易哈希 |
| `addDoHandleTransactionVector(txHash)` | cpp:67-71 | 记录已处理交易哈希 |
| `transactionSuccessRateChecker()` | cpp:10-60 | 统计交易成功率 |

### 2.5 SyncBlock

- **File**: `ca/sync_block.h:34-351`, `ca/sync_block.cpp`
- **Responsibility**: 区块同步、分叉解决、拜占庭容错检查
- **Lifecycle**: Singleton -> ThreadStart() starts detached thread
- **Key Methods**:

| Method | Line | Description |
|--------|------|-------------|
| `ThreadStart()` | h:48 / cpp:175-395 | 启动同步线程: 循环决策 syncType -> 选择 runFastSyncOnce/runNewSyncOnce/runFromZeroSyncOnce |
| `ThreadStop()` | cpp:165-168 | 停止同步线程 |
| `runFastSyncOnce(pledgeAddr, chainHeight, syncInitHeight, endSyncHeight_, syncNodeCount)` | cpp:400-432 | 快速同步: get_fast_sync_sum_hash_node -> get_fast_sync_block_data |
| `runNewSyncOnce(pledgeAddr, chainHeight, ...)` | cpp:434-473 | 普通同步: getSyncBlockHashVerification -> getSyncBlockData |
| `runFromZeroSyncOnce(pledgeAddr, chainHeight, nodeSelfHeight, syncNodeCount)` | cpp:475-536 | 从零同步: get_from_zero_sync_sum_hash_node -> getSyncBlockDataFromZero |
| `getSyncNode(num, chainHeight, pledgeAddr, node_ids_to_send)` | cpp:538-599+ | 选择同步节点: 卡住超时 -> ByzantineAdjustment |
| `getSyncNodeSimplified(num, chainHeight, pledgeAddr, node_ids_to_send)` | h:72 | 简化节点选择 |
| `checkByzantineFault(receiveCount, hitCount)` | h:96 | 拜占庭检查 |
| `sumHeightsHash(heightBlocks, hash)` | cpp:74-86 | 汇总哈希: sort(hashes) -> SHA256(concat) per height, then SHA256(concat all) |
| `get_sync_node_hash_info(nodes, stakeQualifyingNodes, sumHash)` | h:324 | 获取同步节点的哈希信息 |
| `fetchRollbackBlock(node_ids_to_send, syncInitHeight, endSyncHeight_, nodeSelfHeight, retBlocks)` | h:122 | 获取回滚区块列表 |

- **Internal State**:
  - `_syncThread`: thread (detached)
  - `syncThreadRunning`: atomic<bool>
  - `syncFromZeroCache`: map<height, map<height, set<CBlock>>>
  - `syncFromZeroReserveHeights`: vector<height>
  - `fastSyncHeightCount`: 快速同步高度数量
  - `kSynchronizationBoundary`: const = 200

- **Static State**:
  - `sync_fail_height`: 同步失败高度标记
  - `runFastSync`: 是否执行快速同步
  - `isFastSyncFailed`: 快速同步失败标记
  - `execute_new_sync`: 触发新同步
  - `syncHeightCount`: 同步范围 = 100
  - `RollBackTime`: 15 * 1000000 (微秒)
  - `kStabilityTime`: 60 * 1000000 (区块稳定时间)
  - `SYNC_HEIGHT_TIME`: 10 (sleep time)
  - `SYNC_STUCK_OVERTIME_COUNT`: 6 (卡住超时次数)

### 2.6 CheckBlocks

- **File**: `ca/check_blocks.h:25-108`, `ca/check_blocks.cpp`
- **Responsibility**: 千区块 SumHash 完整性校验
- **Lifecycle**: Singleton -> StartTimer() 启动 30s 定时器
- **Key Methods**:

| Method | Line | Description |
|--------|------|-------------|
| `_Init()` | cpp:23-34 | 从 DB 读取 thousandSumHashTop |
| `StartTimer()` | h:38 / cpp:36-45 | 30s period AsyncLoop _ToCheck |
| `_ToCheck()` | cpp:78-165 | 核心检查: nodeSelfHeight >= topBlockHeight+1100 时计算千区块 SumHash -> 向质押节点查询验证 |
| `calculateByzantineSumHash(node_ids_to_send, heightsForSending, shouldSyncHeights)` | h:62 | 通过拜占庭共识确定错误高度范围 |
| `performNewSynchronization(node_ids_to_send, pledgeAddr, nodeSelfHeight)` | h:72 | 基于 CheckBlocks 结果触发新同步 |
| `fetchPledgeAddress(dbReader, pledgeAddr)` | cpp:48-63 | 获取质押地址列表（VerifyBonusAddr 过滤） |

### 2.7 BlockManager

- **File**: `ca/block_helper.h:81-112`
- **Responsibility**: 区块去重管理（内存级，thread-safe）
- **Key Methods**:
  - `addBlock(blockHash)` -> bool: 添加 hash，返回是否成功（去重）
  - `hasBlock(blockHash)` -> bool: 检查是否已存在
  - `remove_expired_blocks_(timeout)`: 过期清理
- **Notes**: 在 BlockHelper::Process() 结尾调用 `remove_expired_blocks_(60s)`

### 2.8 packDispatch

- **File**: `ca/packager_dispatch.h:20-40`
- **Responsibility**: 打包依赖分发（合约交易依赖管理）
- **Key Methods**:
  - `Add(contractHash, dependentContracts, tx)`: 添加合约依赖和交易
  - `GetDependentData(dependentContractTxMap, nonContractTxMap)`: 获取依赖分组

---

## 3. Supporting Libraries

### 3.1 mm::crypto::EcvrfP256Sha256Tai

- **File**: `utils/ecvrf_p256_sha256_tai.h:7-33`
- **Purpose**: RFC 9381 compliant ECVRF-P256-SHA256-TAI implementation
- **Key Methods**:
  - `GenerateKeyPair(sk, pk)`: Generate ECDSA P-256 key pair
  - `DerivePublicKey(sk, pk)`: Derive public from secret
  - `Prove(sk, alpha, pk, proof, beta)`: Generate VRF proof
  - `Verify(pk, alpha, proof, beta)`: Verify VRF proof
  - `RunSelfTest()`: Self-test

### 3.2 mm::vrf (Selection Proof)

- **File**: `utils/vrf_selection.h:8-80`
- **Purpose**: RFC 9381 selection proof builder/verifier with domain separation
- **Roles**: `tx_packager_v1`, `contract_dispatcher_v1`, `contract_packager_v1`, `block_validator_v1`
- **Key Functions**:
  - `BuildSelectionProof(role, selector_addr, candidates, public_input, select_count, selected, selection_json)`
  - `VerifySelectionProof(role, selection_json, candidates, public_input, select_count, selected)`
  - `BuildAlphaHex(role, public_input, candidates, select_count)`
- **Status**: Interface defined but **not yet integrated into existing VRF consensus flow** (old code in vrf_consensus.cpp uses its own ECDSA-based approach)
- 【需人工验证】Migration status: New ECVRF vs Legacy VRF

### 3.3 mm::vrf::trace

- **File**: `utils/vrf_trace.h:3-46`
- **Purpose**: VRF selection event logging/tracing
- **Functions**: LogCreate, LogCreateFailure, LogVerifySuccess, LogVerifyFailure
- **Status**: Support library for the new ECVRF selection proof

### 3.4 VRF (Legacy)

- **File**: `utils/vrf.hpp:13-80`
- **Purpose**: Legacy VRF cache management
- **Features**: Timer-based cleanup of VRF cache data (300s expiry), tx VRF cache, verification node request cache, block signature data cache
- **Status**: Still in use by existing consensus flow

### 3.5 ca_algorithm Namespace

- **File**: `ca/algorithm.h`, `ca/algorithm.cpp` (382KB)
- **Responsibility**: 核心算法集合: 哈希计算、交易验证、区块验证、保存/删除、回滚、年化率、SumHash、异常节点检测
- **Key Functions** (consensus/block related):
  - `CalcBlockHash(block)`, `calculateTransactionHash(tx)`, `calculateBlockMerkle(cblock)`
  - `memVerifyBlock(block, ...)`, `VerifyBlock(block, ...)`, `verifyPreSaveBlock_(block)`
  - `SaveBlock(dbWriter, block, saveType, computeMeanValue)`, `DeleteBlock(dbWriter, blockHash)`
  - `RollBackToHeight(height)`, `rollback_by_hash(blockHash)`
  - `calculateHeightsSumHash(blockHeight, dbWriter)`, `calculateSumHashOf1000Heights(blockHeight, dbWriter, backHash)`
  - `fetchAbnormalSignAddrListByPeriod(curTime, addr_percent, addrSignCount)`
  - `GetPledgeTimeByAddr(addr, stakeType)`, `CalcBonusValue(curTime, bonusAddr, values)`
  - `GetAnnualizedRate(curTime, annualizedRate)`, `GetNewAnnualizedRate(curTime, stakingRate, annualizedRate)`

---

## 4. Relationship and Identity

### 4.1 Class Dependency Graph

```
VRFConsensusNode (VRF cycle + selection)
    |
    v
SyncBlock (sync + fork resolution)
    |
    v
BlockStorage / BlockMonitor (block flow + status)
    |
    v
BlockHelper (save + rollback orchestration)
    |
    v
ca_algorithm (core algorithms: verify, save, delete, rollback, hash)
    |
    v
DBReader/DBReadWriter (RocksDB access)
```

All classes interact through `MagicSingleton<T>::GetInstance()` (singleton pattern).

### 4.2 Singleton Access Pattern

```
MagicSingleton<VRFConsensusNode>
MagicSingleton<BlockHelper>
MagicSingleton<BlockStorage>
MagicSingleton<BlockMonitor>
MagicSingleton<SyncBlock>
MagicSingleton<CheckBlocks>
MagicSingleton<BlockManager>
MagicSingleton<PeerNode>
MagicSingleton<AccountManager>
MagicSingleton<TimeUtil>
MagicSingleton<TaskPool>
MagicSingleton<Benchmark>
```
