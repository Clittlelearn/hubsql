# Module 4: Call Chain Analysis (Mermaid Diagrams)

## 1. VRF Cycle: Seed Generation -> Packager Selection

```mermaid
sequenceDiagram
    participant VM as VRFConsensusNode::run()
    participant GEN as generateVRFStructure
    participant BC as vrfBroadcastMessage
    participant RCV as receiveVRRequest
    participant ADD as addVRFStructure
    participant FREQ as computeMaxHeightWithMinFrequency
    participant SEL as extractPackagerVRFData

    VM->>VM: sleep_until(nextCycleStart) [vrf_consensus.cpp:294]
    VM->>GEN: generateVRSeed(nextCycleStart) [cpp:296]
    Note over GEN: seed = floor(epoch_seconds/10)*10 [cpp:628-633]
    VM->>GEN: generateVRFStructure(seed, vrf) [cpp:299]
    Note over GEN: Read top height from DB [cpp:75-79]
    alt top >= MIN_UNSTAKE_HEIGHT
        Note over GEN: For i=top downto top-10 [cpp:82-105]
        GEN->>GEN: DB: getBlockHashsByBlockHeight(i) [cpp:85]
        GEN->>GEN: vrf.add_blockinfo(hash[0:8], height) [cpp:93-94]
        Note over GEN: Stop when blockinfo_size >= 10
    end
    GEN->>GEN: sign(vrfData, signature, pub) [cpp:113]
    Note over GEN: ECDSA sign on vrf.SerializeAsString() [cpp:108-122]
    
    VM->>BC: vrfBroadcastMessage(vrf) [cpp:327]
    Note over BC: Send to ALL nodes via TaskPool [cpp:126-137]
    
    RCV->>RCV: Receive VRFConsensusInfo from peer [cpp:166]
    RCV->>RCV: Check timeDiff <= 10s [cpp:181]
    alt timeDiff > 10s
        RCV-->>RCV: TRACELOG, discard
    end
    RCV->>RCV: validate_block_info(vrf, nodeId) [cpp:192]
    Note over RCV: VerifyBonusAddr + blockinfo=10 + dedup [cpp:139-163]
    RCV->>RCV: Reconstruct vrfForVerify (without sign) [cpp:200-207]
    RCV->>RCV: ca_algorithm::VerifySign(sign, vrfDataHash) [cpp:214]
    RCV->>ADD: addVRFStructure(vrf, nodeId) [cpp:219]
    Note over ADD: Insert into validatedVRfs[seed][nodeId] [cpp:248]
    ADD->>ADD: pruneOldData() [cpp:256]
    RCV->>BC: vrfBroadcastMessage(vrf) (relay) [cpp:225]

    VM->>FREQ: computeMaxHeightWithMinFrequency() [cpp:330]
    Note over FREQ: Skip if validatedVRfs.size() < 3 [cpp:344]
    Note over FREQ: Take 3rd-last period: prev(validatedVRfs.end(),3) [cpp:351]
    FREQ->>FREQ: Count hash frequency per height [cpp:364-378]
    FREQ->>FREQ: Calculate optimalFrequency [cpp:410-417]
    Note over FREQ: weighted avg = sum(avgRatio*h)/sum(h)
    FREQ->>FREQ: Identify optimalHashes [cpp:422-432]
    FREQ->>FREQ: Match node hashes against optimalHashes [cpp:442-451]
    FREQ->>FREQ: Lower freqThreshold until >= size*0.55 [cpp:453-479]
    Note over FREQ: Populate newValidatedVRfs[seed][node] [cpp:469]

    SEL->>SEL: getPreviousCycleTime(timestamp) [vrf_consensus.cpp:545]
    Note over SEL: seed = prev_cycle_epoch [cpp:547]
    SEL->>SEL: Lookup newValidatedVRfs[seed] or validatedVRfs[seed] [cpp:556-581]
    SEL->>SEL: Sort by frequency ASC [cpp:584-587]
    SEL->>SEL: Filter >= maxValue, dec by 0.1 [cpp:589-607]
    SEL->>SEL: selectRandomNodes(dataSource, nodes, kConsensus=3) [cpp:618]
    Note over SEL: seed = SHA256(sum of all signatureHash) [cpp:528]
    Note over SEL: shuffleMap(dataSource, seed) -> pick first kConsensus [cpp:531-542]
```

## 2. Block Packaging and Saving

```mermaid
sequenceDiagram
    participant PKG as Packager (selected by VRF)
    participant BH as BlockHelper
    participant ALG as ca_algorithm
    participant DBW as DBReadWriter (RocksDB)

    Note over PKG: Collect transactions from mempool
    PKG->>PKG: Prepare CBlock {version,time,prevhash,height,txs}
    PKG->>ALG: CalcBlockHash(block) [algorithm.cpp:234]
    Note over ALG: clear_hash, clear_signature -> SHA256(Serialize) [cpp:236-238]
    PKG->>ALG: calculateBlockMerkle(block) [algorithm.cpp:241]
    Note over ALG: Double-SHA256 iterative Merkle [cpp:250-276]
    PKG->>PKG: Sign block with ECDSA key
    PKG->>PKG: Broadcast BlockMsg via network

    BH->>BH: AddBroadcastBlock(block) [block_helper.h:188]
    Note over BH: Insert into broadcastBlocks set
    
    BH->>BH: Process() called by timer [cpp:1311]
    
    loop For each block in broadcastBlocks
        BH->>DBW: getBlockByBlockHash(block.hash) [cpp:1507]
        alt already saved
            BH-->>BH: Skip
        end
        BH->>BH: SaveBlock(block, Broadcast, Normal) [cpp:1513]
    end

    BH->>BH: SaveBlock(block, saveType, computeMeanValue) [cpp:597]
    BH->>DBW: getBlockTop(nodeHeight) [cpp:614]
    alt block.height >= nodeHeight + 2
        BH-->>BH: Return -4 (height ahead too much)
    end
    BH->>DBW: getBlockByBlockHash(block.hash) [cpp:629]
    alt already in DB
        BH-->>BH: Return 0 (skip)
    end
    BH->>BH: PreSaveProcess(block, saveType, computeMeanValue) [cpp:636]
    Note over BH: Includes VerifyBlock + tx checks [cpp: PreSaveProcess body]
    
    BH->>ALG: SaveBlock(dbWriter, block, saveType, computeMeanValue) [cpp:646]
    Note over ALG: [algorithm.cpp:3986-4500+]
    ALG->>DBW: getBlockByBlockHash for prevhash [cpp:4005]
    alt prevhash not found
        ALG->>BH: set_missing_prehash() [cpp:4007]
    end
    Note over ALG: Write block data to DB
    Note over ALG: Write BH:{height} index
    Note over ALG: Write TX:{txHash} for each tx
    Note over ALG: Update UTXO states
    Note over ALG: Update block top
    Note over ALG: Calculate SumHash for heights
    Note over ALG: Update SIGN:{period} stats
    Note over ALG: Update PACKAGER stats

    BH->>DBW: transactionCommit() [cpp:669]
    alt commit failed
        BH-->>BH: Return -9
    end
    BH->>BH: PostSaveProcess(block) [cpp:694]
    Note over BH: processPostTransaction + processPostMembershipCancellation
```

## 3. Block Synchronization (New Sync / SumHash)

```mermaid
sequenceDiagram
    participant SYNC as SyncBlock::ThreadStart
    participant SN as getSyncNode
    participant SH as getSyncBlockHashVerification
    participant VER as SumHash Verification
    participant DATA as getSyncBlockData
    participant BH as BlockHelper::AddSyncBlock

    SYNC->>SYNC: Wake every SYNC_HEIGHT_TIME=10s [cpp:199]
    SYNC->>SYNC: getChainHeight(chainHeight) [cpp:212]
    Note over SYNC: Polls pledge nodes, takes 75th percentile
    SYNC->>SYNC: getBlockTop(nodeSelfHeight) [cpp:221]
    
    alt nodeSelfHeight == chainHeight for SYNC_STUCK_OVERTIME_COUNT
        Note over SYNC: Possible fork problem detected
        SYNC->>SN: needByzantineAdjustment(chainHeight, pledgeAddr, selectedAddr) [cpp:562]
        Note over SN: Find nodes with different chain perspective
    end

    SYNC->>SYNC: Decides sync type [cpp:314-389]
    Note over SYNC: SaveType based on height diff with hash range sum

    Note over SYNC: Compute sync range [cpp:349-360]
    Note over SYNC: syncInitHeight = max(nodeSelfHeight - 100, 1)
    Note over SYNC: endSyncHeight_ = nodeSelfHeight + 100

    SYNC->>SN: getSyncNode(syncNodeCount, chainHeight, pledgeAddr, node_ids_to_send) [cpp:443]
    Note over SN: Filter nodes by height baseline [sync_block.cpp:538-600+]
    
    SYNC->>SH: getSyncBlockHashVerification(node_ids_to_send, syncInitHeight, endSyncHeight_, nodeSelfHeight, chainHeight, ...) [cpp:451]
    Note over SH: Send SyncGetBlockHeightAndHashReq to nodes
    Note over SH: Await responses (timeout=30s, 80% response required)
    Note over SH: Deduplicate hashes from responses
    
    SH->>VER: Compare received hashes with local hashes per height
    alt hash mismatch detected
        Note over VER: Add different hashes to reqHashes list
        Note over VER: For local hashes not in consensus: mark for rollback
    end

    SYNC->>DATA: getSyncBlockData(node_ids_returned, reqHashes, chainHeight) [cpp:462]
    Note over DATA: Send SyncGetBlockReq to consensus nodes
    Note over DATA: Download block bytes, verify them
    Note over DATA: Check Byzantine fault: checkByzantineFault(receiveCount, hitCount)
    
    DATA->>BH: AddSyncBlock(syncBlockData, SaveType) [cpp: ?]
    Note over BH: Insert into _syncBlocks set (ordered by time)
    
    BH->>BH: Process() picks up _syncBlocks and saves each [cpp:1488-1502]
```

## 4. Fork Detection and Resolution

```mermaid
sequenceDiagram
    participant SYNC as SyncBlock main loop
    participant SN as getSyncNode
    participant RP as Rollback protocol
    participant BH as BlockHelper
    participant ALG as ca_algorithm

    Note over SYNC: Fork detection embedded in sync thread
    Note over SYNC: 15-second timeout for rollback blocks

    SYNC->>SYNC: nodeSelfHeight == chainHeight for 6+ cycles [cpp:559]
    Note over SYNC: SYNC_STUCK_OVERTIME_COUNT = 6

    SYNC->>SN: needByzantineAdjustment(chainHeight, pledgeAddr, selectedAddr) [cpp:562]
    Note over SN: [sync_block.cpp: needByzantineAdjustment body]
    SN->>SN: get_sync_node_hash_info(nodes, stakeQualifyingNodes, sumHash)
    Note over SN: Each node reports its sumHash
    SN->>SN: _GetSelectedAddr(sumHash, selectedAddr)
    Note over SN: Select addresses with majority sumHash
    
    SN-->>SYNC: selectedAddr = nodes on different chain
    SYNC->>SYNC: get_sync_node_basic() with selectedAddr [cpp:566]
    Note over SYNC: Query selected nodes for blocks at our heights
    
    Note over SYNC: Build consensus map: map<height, map<hash, set<nodeId>>>
    Note over SYNC: 51% threshold: verifyNum = floor((N+1) * 0.51)

    loop For each height where local hash != consensus
        alt Remote hash >= 51% support and local hash < 51%
            Note over RP: Trigger rollback
            RP->>BH: rollback_block_(rollbackBlockInfo) [cpp:2100]
            BH->>BH: RollbackBlocks() [cpp:1233-1262]
            
            loop For each block to rollback
                BH->>BH: RollbackBlock(blockHash, height) [cpp:1155]
                BH->>SN: fetchRollbackBlock(node_ids, height, height, ...) [cpp:1192]
                Note over SN: Get the correct block from consensus nodes
                alt Found correct block with >= 51% support
                    BH->>ALG: DeleteBlock(dbWriter, blockHash) [cpp:1216]
                    Note over ALG: [algorithm.cpp: DeleteBlock body]
                    Note over ALG: Remove block, txs, UTXO states
                    BH->>DBW: transactionCommit() [cpp:1217]
                end
            end
        end
        
        alt Remote hash >= 51% but local doesn't have it
            Note over SYNC: Download and apply new block
            SYNC->>BH: AddSyncBlock(...)
        end
    end

    Note over SYNC: Rollback protection:
    Note over SYNC: - Time window: blocks older than 15s from current time
    Note over SYNC: - Depth limit: fast sync fails 5 times -> FromZero
    Note over SYNC: - Node qualification: VerifyBonusAddr only
    Note over SYNC: - Failure recovery: isFastSyncFailed -> switch to FromZero
```

## 5. Missing Block Protocol

```mermaid
sequenceDiagram
    participant BH as BlockHelper::SaveBlock
    participant UQ as sendBlockByUtxoRequest
    participant PEER as Peer nodes
    participant ALG as ca_algorithm

    Note over BH: During PreSaveProcess, UTXO referenced by tx is not found
    
    BH->>BH: pushMissUtxo(utxo) [cpp:1275]
    BH->>BH: getMissingBlock() [cpp:1284]
    BH->>BH: Start async thread: sendBlockByUtxoRequest [cpp:1297]

    UQ->>PEER: GetBlockByUtxoReq {self_node_id, utxo, msg_id} [cpp:104-116]
    Note over UQ: Send to pledge nodes (VerifyBonusAddr filter)
    UQ->>PEER: Wait for 80% responses (30s timeout) [cpp:98]
    
    alt Received responses
        PEER-->>UQ: GetBlockByUtxoAck {block_raw}
        UQ->>UQ: Verify all responses have same block_raw [cpp:143-149]
        
        alt All match
            UQ->>BH: rollbackPreviousBlocks(utxo, nodeSelfHeight, blockHash) [cpp:172]
            Note over BH: [block_helper.cpp:189-254]
            Note over BH: Search local blocks from top down for the UTXO
            Note over BH: When found: SyncBlock::SetFastSync(height_of_UTXO_block) [cpp:243]
            Note over BH: This triggers re-sync from the UTXO-containing block's height
            UQ->>BH: AddMissingBlock(block) [cpp:183]
        else Mismatch
            UQ-->>UQ: ERRORLOG "get different block", return -8
        end
    else Timeout or insufficient responses
        UQ-->>UQ: checkByzantineFault check, return -7
    end
```

## 6. Byzantine Fault Tolerance Check

```mermaid
flowchart TD
    A[SyncBlock or BlockHelper<br/>wait for responses] --> B{Responses received <br/>vs sent}
    B -->|hitCount/receiveCount<br/>>= threshold| C[Pass: proceed with data]
    B -->|hitCount/receiveCount<br/>< threshold| D[Byzantine check failed]
    D --> E[Mark as sync failure]
    E --> F[Increase sync timeout/count]
    F --> G[Retry with different nodes<br/>in next cycle]
    G --> A
    
    D --> H[SyncBlock::needByzantineAdjustment<br/>triggered after SYNC_STUCK_OVERTIME_COUNT=6]
    H --> I[get_sync_node_hash_info<br/>collect sumHash from all nodes]
    I --> J[_GetSelectedAddr<br/>select nodes on majority chain]
    J --> K[get_sync_node_basic<br/>query selected nodes for sync]
```

Note: `checkByzantineFault()` specific threshold value is in `sync_block.cpp` function body. Declaration only in header (sync_block.h:96). 【需人工验证】
