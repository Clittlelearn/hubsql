# Module 4: DAG Block Structure & Consensus (VRF) -- Module Overview

## 1. Module Responsibility

本模块负责 MeMeChain 区块链的核心数据结构维护和共识达成，涵盖四大子领域：

1. **DAG 结构维护**: 同一高度允许多个区块共存（分叉），通过 `vector<blockHash>` 存储，通过共识权重选择主链
2. **VRF 共识**: 每 10 秒周期的打包节点随机选择机制，基于可验证随机函数 (VRF) 保证公平性
3. **区块验证**: 多阶段区块验证流程（内存验证 -> 完整验证 -> 预保存验证 -> 保存）
4. **区块同步**: 支持三种同步模式（FastSync / NewSync / FromZero），通过拜占庭容错检查保证数据一致性

## 2. Core Function List

| No. | Function | Description |
|-----|----------|-------------|
| F1 | VRF seed generation + broadcast | 每 10 秒生成种子、签名、广播 VRFConsensusInfo |
| F2 | VRF packager selection | 从 validatedVRfs 中按频率筛选 + 随机选择 kConsensus=3 个打包节点 |
| F3 | Block saving | 多级缓存处理（broadcast -> sync -> fastSync -> utxoMissing -> hashPending）|
| F4 | Block verification | memVerifyBlock -> VerifyBlock -> verifyPreSaveBlock_ -> SaveBlock |
| F5 | DAG fork detection | 15 秒周期向质押节点查询高度范围，51% 判定 |
| F6 | Block rollback | RollBackToHeight / rollback_by_hash / RollbackBlock (single) |
| F7 | Fast sync | 获取哈希列表 -> 下载区块 -> 快速应用 |
| F8 | New sync (SumHash) | SumHash 验证 -> 获取差异哈希 -> 下载区块 |
| F9 | FromZero sync | 千区块 SumHash 验证 -> 逐高度请求区块 |
| F10 | Missing block protocol | UTXO 缺失 -> 向质押节点请求区块 -> 回滚 |
| F11 | Byzantine fault tolerance | checkByzantineFault (hitCount/receiveCount < threshold) |
| F12 | BlockStatus tracking | 每个区块验证状态追踪，共识权重统计 |

## 3. Specification vs Implementation Comparison

| Feature | Spec Definition | Current Implementation | Deviation Reason |
|---------|----------------|----------------------|-----------------|
| **DAG multi-block storage (5.5.1)** | Key: `BH:{height}` -> `vector<blockHash>` | `dbReader.getBlockHashsByBlockHeight(height, block_hashes)` (block_helper.cpp:209, sync_block.cpp:112); 数据库层通过 `getBlockHashesByBlockHeight` 实现 【可信度:高】 | Conforms |
| **Main chain selection (5.5.3)** | Max consensus weight -> Longest chain -> Earliest timestamp | `getChainHeight()` (block_helper.cpp:2113-2177): 取节点高度第 75 百分位作为全网高度，用 `VerifyBonusAddr` 过滤有质押资格节点，但**没有按共识权重排序**，仅简单取 `sampleRate=0.75` 分位 【可信度:高】 | 规范定义了三级优先级（累计共识权重>最长链>时间戳），但实现仅采用简单高度分位统计，**缺少 DAG 级别权重比较** |
| **Rollback mechanism (5.5.4)** | "从 top 向下回滚到分叉点，删除分叉区块的状态数据，恢复 UTXO" | `RollBackToHeight` (algorithm.cpp:7511-7569): 遍历高度收集所有区块 -> `RollBackBlock(hashs)` 批量删除 -> HTTP 回调通知。`RollbackBlock` (block_helper.cpp:1155-1231): 从远程获取新区块，调用 `ca_algorithm::DeleteBlock` 单个删除 【可信度:高】 | `RollBackToHeight` 有从 top 向下遍历收集区块的逻辑，但 **缺少显式的分叉点查找和 UTXO 恢复原子性保证**。`RollbackBlock` 和 `RollBackToHeight` 是两个独立路径，前者依赖远程查询，后者从本地遍历 |
| **Rollback timeout (5.5.4)** | `RollBackTime = 15s` | `RollbackTimeout = 15 * 1000000` (block_helper.cpp:1405) 用于过滤超时区块；`const static uint32_t RollBackTime = 15 * 1000000` (sync_block.cpp:46) 定义一致 【可信度:高】 | Conforms |
| **VRF cycle (6.3.1)** | seed = floor(time / 10) * 10 | `generateVRSeed()` (vrf_consensus.cpp:628-633): `seconds -= seconds % CYCLE_DURATION_SECONDS` 【可信度:高】 | Conforms |
| **VRF blockinfo count (6.3.2)** | Recent 10 blocks, hash first 8 chars | `generateVRFStructure()` (vrf_consensus.cpp:82-105): 从 top 倒查 10 个高度，每个高度取 hash 前 8 字符 (`hash.substr(0,8)`) 【可信度:高】 | Conforms |
| **VRF signature scope (6.3.2)** | seed + blockinfo | `generateVRFStructure()` (vrf_consensus.cpp:108-122): 序列化**整个 VRFConsensusInfo**（含 seed 和 blockinfo，但不含签名）后用 ECDSA 签名。**但规范说的是对 VRF 结构体签名而非对特定数据**，实现一致 【可信度:高】 | Conforms |
| **VRF verification (6.3.3)** | Time window <=10s, verify sign, stake qualification, blockinfo=10 | `receiveVRRequest()` (vrf_consensus.cpp:166-226): 时间差校验(181行)、签名验证(214行)、质押资格(143行)、blockinfo 数量=10(147行) + 重复哈希检查(152-159行) 【可信度:高】 | **额外增加了 blockinfo 中哈希去重检查**，规范未提及但属安全性增强 |
| **Packager selection (6.4.1)** | Frequency computation: take 3rd-last period, optimal frequency = weighted avg | `computeMaxHeightWithMinFrequency()` (vrf_consensus.cpp:339-481): 取 `std::prev(validatedVRfs.end(), 3)` 即倒数第 3 个周期；optimalFrequency = sum(avgRatio * h) / sum(h)；validateNodeThreshold = size * 0.55 【可信度:高】 | 实现与规范吻合。额外的 `validateNodeThreshold = 0.55` 和 `frequencyThreshold` 递减循环 (0.1 步长) 是合理的工程实现 |
| **Packager random selection (6.4.2)** | SHA256(sum of all signatureHash) as seed, shuffle and select | `extractPackagerVRFData()` (vrf_consensus.cpp:544-625): 按频率升序排序 -> `maxValue = 1.0` 递减筛选 -> `selectRandomNodes()` (521-541) 用 SHA256(sumSeed) 做种子 shuffle 【可信度:高】 | Conforms |
| **Abnormal node penalty (6.4.3)** | `fetchAbnormalSignAddrListByPeriod`, nodes below average get reduced rewards | `fetchAbnormalSignAddrListByPeriod()` (algorithm.cpp:66-106): 获取 period-1 签名地址 -> 计算平均签名数 -> 低于平均的节点 dividendRate = own/average 【可信度:高】 | Conforms |
| **Byzantine fault tolerance (6.7)** | `checkByzantineFault(receiveCount, hitCount)` | Function exists at `SyncBlock::checkByzantineFault` declaration in sync_block.h:96. **具体实现需验证 sync_block.cpp 中的函数体** 【可信度:中】 | 需检查 sync_block.cpp 中的具体实现以确认阈值 |
| **Block signature verification (6.5)** | Signatures >= kConsensus, signers must be packagers | `verifyPreSaveBlock_()` (algorithm.cpp:3923-3938): 仅检查签名去重后数量 == kConsensus，**未验证签名节点是否为合法打包节点**。`composeEndBlockMessage()` (block_stroage.cpp:124-173): 从 BlockMsg 中随机选 kConsensus-1 个签名组装 【可信度:高】 | **VerifyBlock 签名字段不完整**：verifyPreSaveBlock_ 只做数量检查，未做节点资格检查；BlockMsg 流中签名组装时 `getRandomElements` 随机选择而非严格验证 |
| **Fork detection period (5.6.1)** | 15 seconds, query pledge nodes, height +/-50, require 80% response | `ThreadStart()` main loop (sync_block.cpp:191-393): `sleepTime=SYNC_HEIGHT_TIME=10` 秒间隔；`syncHeightCount=100` 高度范围；response threshold = `sendNum * 0.8`; 但**统一使用 `VerifyBonusAddr` 过滤而非完整质押检查** 【可信度:高】 | Sync cycle is 10 seconds (not 15 as in spec). Spec deviation or spec was updated. |
| **51% consensus (5.6.2)** | verifyNum = floor((N+1) * 0.51) | `getChainHeight()` (block_helper.cpp:2168): `verifyNum = nodeHeights.size() * 0.75` (不是 51% 而是 75%) 【可信度:高】 | **规范是 51% 但实现用 75%**。更保守的阈值增加了安全性但偏离规范 |
| **Rollback protection (5.6.5)** | Time window, depth limit (<10), node qualification | Time window: 15s (block_helper.cpp:1405); Fast sync depth limit: `runFastSyncCount >= 5` (sync_block.cpp:258) 5 次失败后彻底放弃；Node qualification: `VerifyBonusAddr` 【可信度:高】 | 回滚深度限制在快速同步模式下通过 `runFastSyncCount` 计数器实现，非显式区块深度计算 |
| **Block verification chain (5.4)** | Version, height continuity, timestamp, prevhash, merkle, txs, signature, packager | `VerifyBlock()` (algorithm.cpp:3759-3921): 检查 prevhash 存在性 (3778行)、高度连续性 (3791行)、时间窗口(3839行)、memVerifyBlock 内容验证 (3798行)、交易验证 (3849行)、合约验证 (3882行); `verifyPreSaveBlock_` 签名数量检查 (3923行) 【可信度:高】 | 签名节点资格验证缺失（见上），prevhash 检查通过 DB 查询而非内存比较 |
| **Block hash calculation (5.2)** | SHA256(Serialize(Block without hash)) | `CalcBlockHash()` (algorithm.cpp:234-239): `block.clear_hash(); block.clear_signature(); return Getsha256Hash(block.SerializeAsString())` 【可信度:高】 | 实现额外清除了 signature 字段，比规范更严格 |
| **Merkle root (5.3)** | Merkle tree of all tx hashes | `calculateBlockMerkle()` (algorithm.cpp:241-277): 迭代归并 Merkle 树，每轮 hash = SHA256(SHA256(tx1) + SHA256(tx2)) 【可信度:高】 | 实现为**双 SHA256 归并 Merkle**，非标准 Merkle 树（标准 Merkle 直接 hash 连接值），需确认是否与规范一致 |

## 4. Key Findings Summary

### Confirmed Deviations

| ID | Deviation | Severity | Location |
|----|-----------|----------|----------|
| DEV-1 | 主链选择缺少按共识权重的 DAG 级别比较 | High | block_helper.cpp:2113 |
| DEV-2 | 51% consensus threshold 实现为 75% (not 51%) | Medium | block_helper.cpp:2168 |
| DEV-3 | 区块签名验证未检查签名节点是否为合法 VRF 打包节点 | High | algorithm.cpp:3923 |
| DEV-4 | sync cycle is 10s, not 15s as in spec | Low | sync_block.cpp:37 |
| DEV-5 | 回滚缺少 UTXO 恢复原子性保证 | Critical | algorithm.cpp:7511-7569 |

### Architecture Issues

| ID | Issue | Risk |
|----|-------|------|
| AI-1 | `ca/algorithm.cpp` 382KB 巨型文件，混合了共识、交易验证、存储、经济模型等完全不相关的功能 | High |
| AI-2 | `ca/sync_block.cpp` 132KB，同步逻辑、分叉解决、拜占庭检查耦合在一起 | High |
| AI-3 | BlockHelper::Process() 处理所有区块类型的保存，逻辑复杂且无清晰分层 | Medium |
| AI-4 | VRF 数据结构全内存存储（`validatedVRfs`/`newValidatedVRfs`），重启丢失 | Low |
| AI-5 | 回滚逻辑分散在 `algorithm.cpp`(DeleteBlock/RollBackToHeight)、`block_helper.cpp`(RollbackBlock/rollback_block_)、`sync_block.cpp`(fast sync 回退) 三个文件 | High |

### Question Items

| Q-ID | Question | Location |
|------|----------|----------|
| Q-1 | checkByzantineFault 的具体阈值是多少？ | sync_block.cpp: 需查找函数体 |
| Q-2 | `shuffleMap` 函数实现是否保证均匀随机？ | vrf_consensus.cpp:531 |
| Q-3 | 是否有对最新 ECVRF (RFC 9381) 实现的迁移计划？vrf_selection.h 中有新接口但 vrf_consensus 中仍是旧实现 | vrf_selection.h vs vrf_consensus.h |
| Q-4 | `send_node_threshold = 5` 在代码何处使用？ | global.h:18 |
| Q-5 | `RollBackTime = 15 * 1000000` (15 秒) 冗余定义在 sync_block.cpp:46 和 block_helper.cpp:1405，是否应统一到 global.h? | sync_block.cpp:46, block_helper.cpp:1405 |
