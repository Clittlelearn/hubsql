# 模块3: UTXO 模型实现 - 模块概览

## 1. 模块职责与定位

UTXO 模块是 MeMeChain 的**交易基础层**，负责管理所有未花费交易输出（UTXO）的完整生命周期。该模块采用 **UTXO + 账户混合模型**：基础层（转账/质押/委托/投票）使用 UTXO 模型，合约层（DEPLOY/CALL）使用账户模型（EVM-compatible）。

### 架构定位

```
RPC/API 层
    |
[TxHelper + UtxoCore]  <-- 交易构造 (ca/transaction/)
    |
[transaction.{cpp,h}]  <-- 交易处理 / 验证 / 路由
    |
[区块打包 / VRF 共识]
    |
[RocksDB 存储层]       <-- UTXO 持久化
```

### 源文件清单

| 文件 | 大小 | 定位 |
|------|------|------|
| `ca/global.h` | ~170 行 | 全局常量、枚举、交易类型定义 |
| `ca/transaction.h` | ~477 行 | 交易处理函数声明 |
| `ca/transaction.cpp` | ~4000+ 行 (128KB) | 交易处理主逻辑 |
| `ca/txhelper.h` | ~486 行 | 交易构造帮助类声明 |
| `ca/txhelper.cpp` | ~4900+ 行 (138KB) | 交易构造帮助类实现 |
| `ca/transaction/utxo_core.cpp/h` | ~587 行 | UTXO 核心操作基类 |
| `ca/transaction/trans.cpp/h` | ~303 行 | 普通转账交易 |
| `proto/transaction.proto` | ~69 行 | 交易 Protobuf 定义 |
| `ca/transaction/stake.cpp/h` | ~255 行 | 质押交易 |
| `ca/transaction/unstake.cpp/h` | ~274 行 | 解质押交易 |
| `ca/transaction/delegating.cpp/h` | ~321 行 | 委托交易 |
| `ca/transaction/undelegating.cpp/h` | ~315 行 | 取消委托交易 |
| `ca/transaction/bonus.cpp/h` | ~456 行 | 领取奖励交易 |
| `ca/transaction/fund.cpp/h` | ~356 行 | 国库资金交易 |
| `ca/transaction/lock.cpp/h` | ~281 行 | 锁定(投票权)交易 |
| `ca/transaction/unlock.cpp/h` | ~271 行 | 解锁交易 |
| `ca/transaction/vote.cpp/h` | ~246 行 | 投票交易 |
| `ca/transaction/contract.cpp` | ~896 行(全 `#if 0`) | 合约交易(已废弃) |
| `ca/double_spend_cache.h` | ~68 行 | 双花缓存 |

---

## 2. 16种交易类型枚举完整列表

定义位置: `ca/global.h:88-107`

| 枚举值 | 整数值 | 类型名 | 说明 | 状态 |
|--------|--------|--------|------|------|
| `UNKNOWN` | -1 | 未知 | 保留/错误 | 当前有效 |
| `GENESIS` | 0 | 创世交易 | 创世区块专用 | 当前有效 |
| `TX` | 1 | 普通转账 | 基础 UTXO 转账 | 当前有效 |
| `STAKE` | 2 | 质押 | 节点质押 | 当前有效 |
| `UNSTAKE` | 3 | 解质押 | 赎回质押 | 当前有效 |
| `DELEGATE` | 4 | 委托 | 委托代币 | 当前有效 |
| `UNDELEGATE` | 5 | 取消委托 | 赎回委托 | 当前有效 |
| `DECLARATION` | 6 | 声明 | 节点声明 | 当前有效(较少使用) |
| `DEPLOY` | 7 | 部署合约 | EVM 合约部署 | 当前有效 |
| `CALL` | 8 | 调用合约 | EVM 合约调用 | 当前有效 |
| `LOCK` | 9 | 锁定 | 锁定以获得投票权 | 当前有效 |
| `UNLOCK` | 10 | 解锁 | 释放锁定 | 当前有效 |
| `PROPOSAL` | 11 | 提案 | 治理提案 | 当前有效 |
| `REVOKEPROPOSAL` | 12 | 撤销提案 | 撤销治理提案 | 当前有效 |
| `VOTE` | 13 | 投票 | 治理投票 | 当前有效 |
| `FUND` | 98 | 国库奖励 | 领取国库奖励 | 当前有效 |
| `BONUS` | 99 | 节点奖励 | 领取节点出块奖励 | 当前有效 |

**注意**: FUND(98) 和 BONUS(99) 的枚举值跳跃式编号，暗示这些交易类型是后期加入的。

---

## 3. UTXO 生命周期概述

```
创建（作为 vout）
  |
  v
未确认（交易在 mempool）
  |
  v (区块确认)
已确认 / 可用（可被花费）
  |
  v (作为 vin 被新交易引用)
已花费（不可再用）
  |
  v (链重组/回滚)
恢复可用
```

### 生命周期各阶段

1. **创建**: 交易在 `vout` 中创建新的 CTxOutput（指定接收地址和金额），被写入 RocksDB
2. **可用**: 区块确认后，UTXO 变为可花费状态，通过 `UB:` / `UAH:` 前缀索引
3. **选择**: `FindUtxo()` 遍历可用 UTXO，按值降序排序，随机起点选择
4. **花费**: 被新交易的 `vin.prevout` 引用后，标记为已花费（从可用索引中移除）
5. **回滚**: 链重组时，已花费的 UTXO 恢复为可用状态

---

## 4. 规范定义 vs 当前实现对比

| 功能点 | 规范定义 | 当前实现 | 偏差原因 | 可信度 |
|--------|---------|---------|---------|--------|
| **UTXO 结构字段** | `CTxUtxos{owner, vin, vout, multisign, assettype, gas}` (spec 5.8) | 完全一致 (`proto/transaction.proto:36-43`) | 无偏差 | 高 |
| **交易哈希计算** | `SHA256(Serialize(Tx without hash))` (spec 5.9) | `Getsha256Hash(tx.SerializeAsString())` 先 `clear_hash()` (`utxo_core.cpp:215-218`) | 一致。`signature` 也在 clear 之后计算 | 高 |
| **双花检查** | `doubleSpendCheck(Tx)` (spec 5.9.1) | `doubleSpendCache` 类 (`double_spend_cache.h`)。但主流程 `handleTransaction` 中未显式调用，而是通过 `TransactionCache::AddCache` 间接处理 | `AddCache` 内部可能做了双花检测；外层缺少显式 doubleSpendCheck | 中 |
| **签名验证** | 所有签名 MUST 有效 (spec 5.9.1) | `signTx()` 对每个 CTxUtxos 添加 multisign，对每个 vin 添加 vinsign (`utxo_core.cpp:142-220`)。验证在 `verifyTransactionMessageRequest` 中 | 验证实现在非分析文件范围内，需进一步查看 | 中 |
| **交易超时** | 不超过 `KtxTimeout = 10秒` (spec 5.9.1) | `verifyTransactionTimeoutRequest()` (`transaction.cpp:3905-3924`): 普通交易超时 = `KtxTimeout` (10,000,000 us = 10s)，合约交易 = `3 * KtxTimeout` (30s)。检查 `tx.time() + expireTime <= nowTime` 或 `tx.time() >= nowTime + expireTime` | 一致，合约交易额外给了 3 倍超时 | 高 |
| **精度转换** | `kDecimalNum = 100,000,000` (spec 2.3.4) | `global.h:35` 定义 `kDecimalNum = 100000000`。`LOCK_AMOUNT = 1` 使用时乘以 kDecimalNum (`lock.cpp:37`)。`MIN_STAKE_AMOUNT = 3500 * kDecimalNum` | 一致 | 高 |
| **UTXO 选择算法** | 规范未详述 | 两种实现: (1) `FindUtxo` v1 (`txhelper.cpp:248`): 按值降序，贪心选择前 N 个; (2) `FindUtxo` v2 (`txhelper.cpp:339`): 按值降序，随机起点环形遍历 | v1 简单但可能导致大 UTXO 总是被选中 | 高 |
| **资产类型检查** | 资产类型 MUST 有效且已批准 (spec 5.9.1) | `TxHelper::Check()` (`txhelper.cpp:174`) 检查地址有效性 + 高度 + 资产类型 | 一致 | 高 |
| **Gas计算** | 规范未详述具体公式 | `CalculateGas()` (`transaction.cpp:3926`): `gas = owner_size*34 + utxoSize + vout_size*34 + gasSize`。`GenerateGas()` 在此基础上增加 `voutSize` 参数化 | Gas 乘以 1（注释暗示曾有配置倍数） | 高 |
| **UTXO 高度验证** | `verifyTxUtxoHeight(Tx, txUtxoHeight)` (spec 5.9.1) | `transaction.cpp:1244-1260`: 比较发送方声明的高度与本地计算的高度是否一致 | 一致 | 高 |
| **质押最小金额** | 规范未明确 | `MIN_STAKE_AMOUNT = 3500 * kDecimalNum = 3500 MM` (`global.h:39`) | 业务规则 | 高 |
| **委托最小金额** | 规范未明确 | `kMinDelegatingAmt = 500 * kDecimalNum = 500 MM` (`global.h:41`) | 业务规则 | 高 |

---

## 5. 架构特征总结

### 优点
1. **类继承体系清晰**: `UtxoCore` 作为抽象基类，定义了 `trans()/signTx()/createUtxoTransferFrom()/createUtxoTransferTo()` 等接口，各交易类型子类继承实现
2. **交易类型与处理分离**: 每种交易类型(TX/STAKE/UNSTAKE/...)有独立文件处理
3. **Protobuf 序列化**: 跨平台、schema 演进友好

### 主要问题
1. **超大文件**: `transaction.cpp` (128KB) 和 `txhelper.cpp` (138KB) 严重超大
2. **重复代码**: 各交易类型子模块中大量重复的 `goMessage()` 和 `makeTxInfor()` 逻辑
3. **两种 UTXO 选择算法并存**: 简单贪心被新交易子模块使用，随机环形被合约/Bonus 等使用，缺乏统一
4. **合约模块已废弃**: `contract.cpp` 全量 `#if 0`，合约逻辑实际分散在 `txhelper.cpp` 和 `transaction.cpp` 中
5. **双花检测不透明**: `doubleSpendCache` 实现未在分析路径内，`handleTransaction` 中无显式双花检查调用

---

## 6. 问题清单

### 问题 1: 双花检测位置不明确
- **位置**: `ca/transaction.cpp:1374-1559` (handleTransaction)
- **现象**: 主交易处理流程中未见显式 `doubleSpendCheck()` 调用
- **风险等级**: Critical
- **触发场景**: 恶意节点构造引用相同 UTXO 的两个交易
- **修复建议**: 在 `handleTransaction` 入口处显式调用双花检测，或在 `TransactionCache::AddCache` 中文档化双花检测逻辑
- **验证方法**: 构造双花交易对，验证系统是否正确拒绝

### 问题 2: UTXO 选择算法不一致导致公平性问题
- **位置**: `ca/txhelper.cpp:248-337` (v1) vs `ca/txhelper.cpp:339-463` (v2)
- **现象**: v1 贪心算法总是选择值最大的 UTXO，导致大额 UTXO 被频繁使用（碎片化低但隐私差）；v2 使用随机起点，但 `tempGas` 参数使用硬编码 `* 100` 系数
- **风险等级**: Medium
- **触发场景**: v1 用于新交易模块(trans.cpp/delegating.cpp等)，v2 用于 txhelper 的旧 CreateTransaction 接口
- **修复建议**: 统一使用 v2 算法，将 Gas 系数提取为常量
- **验证方法**: 对同一地址多次发起交易，观察选中的 UTXO 分布

### 问题 3: Gas 计算缺少动态定价
- **位置**: `ca/transaction.cpp:3926-3955` (CalculateGas), `3926` 行 `gas *= 1`
- **现象**: Gas 按固定公式(bytes * 1)计算，无市场竞价机制
- **风险等级**: Low
- **触发场景**: 高负载时无竞价机制可能导致交易优先级不明
- **修复建议**: 引入 gasPrice 参数，支持动态定价
- **验证方法**: 【需人工验证】压力测试下的交易排序

### 问题 4: 创世账户 Gas 豁免
- **位置**: `trans.cpp:297-300`, `stake.cpp:196-199`, `lock.cpp:275-278` 等多处
- **现象**: `if(GetInitAccountAddr() == addr) { gas = 0; }` —— 创世账户免 Gas
- **风险等级**: Medium
- **触发场景**: 若创世账户私钥泄露，可发起零成本交易攻击
- **修复建议**: 仅创世交易(GENESIS)免 Gas，普通交易应正常收费
- **验证方法**: 创世账户发起普通转账，检查 Gas 是否为 0

### 问题 5: 未使用 nonce 防重放
- **位置**: `ca/transaction/trans.cpp:256-263` 等多处
- **现象**: `getNonceByAddr()` 读取 nonce 并设置到交易，但 `handleTransaction` 中未见 nonce 递增验证
- **风险等级**: High
- **触发场景**: 同一交易被重放攻击
- **修复建议**: 在交易验证时检查 nonce 严格递增
- **验证方法**: 【需人工验证】重放已确认交易
