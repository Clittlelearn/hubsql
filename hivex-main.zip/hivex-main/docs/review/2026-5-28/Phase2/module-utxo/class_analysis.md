# 模块3: UTXO 模型实现 - 类与结构分析

## 1. 核心数据结构 (Protobuf 定义)

所有交易数据结构定义在 `proto/transaction.proto`。

### 1.1 CTxPrevOutput -- 前向 UTXO 引用

```protobuf
// proto/transaction.proto:17-20
message CTxPrevOutput{
  string hash = 1;   // 被引用的 UTXO 的 tx_hash
  uint32 n    = 2;   // 该 UTXO 在交易中的输出索引
}
```

**分析**:
- `hash` 是原始交易的 tx_hash（即产生此 UTXO 的交易的哈希值）
- `n` 是该 UTXO 在原始交易的 vout 数组中的索引
- **注意**: 当前实现中 `n` 在大多数代码路径中固定为 0 (`txhelper.cpp:274`: `utxo.n = 0; // At present, the n of utxo is all 0`)

### 1.2 CTxInput -- 交易输入

```protobuf
// proto/transaction.proto:22-28
message CTxInput{
  repeated CTxPrevOutput prevOut = 1;  // 前向引用列表
  CSign  vinSign      = 2;            // 输入签名
  uint32 sequence     = 3;            // 序列号
  string contractAddr = 4;            // 合约地址
}
```

**分析**:
- 一个 `CTxInput` 可包含多个 `CTxPrevOutput`，表示花多个 UTXO
- `vinSign` 对 vin 序列化内容进行 SHA256+签名
- `contractAddr` 字段用于合约交易，非合约交易为空。签名时如果 `contractAddr` 非空则跳过 VIN 签名 (`utxo_core.cpp:155-158`)
- `sequence` 由 setTxOwners 的遍历顺序递增赋值

### 1.3 CTxOutput -- 交易输出

```protobuf
// proto/transaction.proto:30-33
message CTxOutput{
  int64 value = 1;   // 输出金额（最小精度）
  string addr = 2;   // 接收地址
}
```

**分析**:
- `value` 使用 `int64_t`（有符号），但在正常流程中不应为负
- 金额使用**最小精度**（1 MM = 10^8 单位），见 `global.h:35` `kDecimalNum = 100000000`
- 虚拟地址（如 `VirtualBurnGas`, `VirtualStake`, `VirtualDelegating`）用于特殊输出

### 1.4 CTxUtxos -- 交易 UTXO 集合

```protobuf
// proto/transaction.proto:36-43
message CTxUtxos{
  repeated string owner    = 1;    // UTXO 所有者地址列表
  repeated CTxInput vin    = 2;    // 输入列表
  repeated CTxOutput vout  = 3;    // 输出列表
  repeated CSign multisign = 4;    // 多签（UTXO 级签名）
  string assettype         = 5;    // 资产类型
  int64 gas                = 6;    // Gas 标识/消耗
}
```

**分析**:
- `owner` 可以有多个（多签场景），当前实现通常只有一个 owner
- `multisign` 是对整个 CTxUtxos（不含 multisign 字段）的 SHA256+签名
- `assettype` 当前支持 "MM"（原生资产）和 "Vote"（投票权资产）
- `gas` 字段用作标识: `UTXO_GAS_TYPE_TRUE(1)` 表示此 UTXO 是支付 Gas 的资产 UTXO

### 1.5 CTransaction -- 交易主体

```protobuf
// proto/transaction.proto:47-68
message CTransaction{
  uint32 version            = 1;    // 交易版本
  uint64 time               = 2;    // 时间戳(微秒)
  uint32 n                  = 3;    // 交易序号
  string identity           = 4;    // 打包节点身份
  string hash               = 5;    // 交易哈希
  uint32 consensus          = 6;    // 共识数量
  uint32 type               = 7;    // 交易类型 (TxType)
  string data               = 8;    // 交易数据(JSON)
  string note               = 9;    // 交易备注
  repeated CSign signature  = 10;   // 交易级签名
  string reserve0           = 11;   // 预留字段
  string reserve1           = 12;   // 预留字段
  repeated CTxUtxos utxos   = 13;   // UTXO 列表
  uint32 independence       = 14;   // 交易独立性标志
  uint64 nonce              = 15;   // EVM 兼容 nonce
  string rlp                = 16;   // EVM 交易 RLP 编码
  string selection_vrf      = 17;   // VRF 选择证明
}
```

**分析**:
- `independence` 字段 (`global.h:76-79`): `TX_INDEPENDENCE_FALSE(0)` 表示依赖其他交易; `TX_INDEPENDENCE_TRUE(1)` 表示可独立执行（有独立 Gas UTXO）
- `nonce` 用于 EVM 兼容，从 `DBReader::getNonceByAddr()` 读取，但**未见递增/验证**
- `selection_vrf` 是 RFC 9381 VRF 选择证明，用于验证打包节点的合法性

---

## 2. 核心类层次结构

### 2.1 UtxoCore -- 抽象基类

**文件**: `ca/transaction/utxo_core.h` (行 20-117)

```
UtxoCore (抽象基类)
├── virtual trans() = 0                                -- 交易构造主逻辑
├── virtual makeTxInfor() = 0                          -- 设置交易元信息
├── virtual checkParams() = 0                          -- 参数校验
├── virtual getGasValue() = 0                          -- 计算 Gas
├── virtual goMessage() = 0                            -- 发送/广播交易
├── signTx(addr, isRLP)                                -- 交易签名
├── createUtxoTransferTo(utxo, param)                  -- 创建 vout
├── createUtxoTransferFrom(utxo, param, sq)            -- 创建 vin (查 UTXO)
├── createUtxoGas(tx, param)                           -- 创建 Gas 支付 UTXO
├── createUtxoGasBylameda(tx, param, lambda)           -- Lambda 方式创建 Gas UTXO
├── getStakeAmount(addr, assetType)                    -- 查询质押金额
├── findUtxoByAddrAndCheckBalance(param)               -- 按地址查找 UTXO
├── transactionDiscoveryHeight()                       -- 网络高度发现
├── sign(addr, data) -> SingRe                         -- 签名基元
├── calculate_all_hash(tx) -> string                   -- 计算所有 UTXO hash 串联
├── checkGasAssetsQualification(gasAssets, height)     -- Gas 资产资格检查
└── GetChainId() -> int64_t                            -- 创世区块生成 chainId
```

**关键成员变量**:
- `CTransaction tx` (行 97): 当前正在构造的交易对象
- `CTransaction *tx_` (行 115): 未使用的指针（疑似遗留字段）

**内部结构**:
- `TransferToParam`: `{to: CowString, amount: int64_t}` -- vout 创建参数
- `TransferFromParam`: `{from: CowString, asset_type: CowString, amount: int64_t, is_find_utxo: bool}` -- vin 创建参数
- `UtxoGasParam`: `{from: CowString, asset_type: CowString, gas: int64_t}` -- Gas 支付参数
- `FindUtxoParam`: `{addr, asset_type, need_amount, need_wid_utxo}` -- UTXO 查找参数
- `SingRe`: `{signature: CowString, pubkey: CowString}` -- 签名返回值
- `OtherToPayGas`: `{addr: CowString, asset_type: CowString}` -- 第三方支付 Gas 配置

### 2.2 交易类型子类继承关系

```
                    UtxoCore (抽象基类)
                         |
        +----------------+----------------+----------------+
        |                |                |                |
   TransforerTrans   StakeTrans      UnStake          LockTrans
   (普通转账TX)      (质押STAKE)    (解质押UNSTAKE)   (锁定LOCK)
        |                |                |                |
        +----------------+----------------+----------------+
        |
   DelegatingTrans   UndelegatingTrans   BonusTrans   UnlockTrans
   (委托DELEGATE)    (取消委托UNDELEGATE)(领奖BONUS)  (解锁UNLOCK)
        |
   FundTrans         VoteTrans
   (国库FUND)        (投票VOTE)
```

每个子类结构:

```
class XxxTrans : public mmc::UtxoCore {
public:
    XxxTransParam s_xxx_param;     // 交易特定参数
    XxxTrans(const XxxTransParam&); // 构造函数

    expected<bool> trans() override;        // 核心交易构造
    expected<bool> goMessage() override;    // 广播/路由
protected:
    expected<bool> makeTxInfor(CTransaction*) override; // 元信息设置
    expected<bool> checkParams() override;             // 参数校验
    expected<int64_t> getGasValue(CTxUtxos*, int) override; // Gas计算
};
```

**分析**: 继承设计合理，但每个子类的 `goMessage()` 和 `makeTxInfor()` 存在大量重复代码（见问题清单）。

### 2.3 TX 交易特殊设计 (TransforerTrans)

**文件**: `ca/transaction/trans.h` (行 11-37), `ca/transaction/trans.cpp`

`TransforerTrans` 是唯一支持**多资产批量转账**的交易子类:

```cpp
struct TransforerTransParam {
    std::vector<TxHelper::TransTable> tx_asset;   // 多资产转账列表
    mmc::UtxoCore::OtherToPayGas gas_tray;         // 第三方Gas支付
    mmc::CowString encoded_info;
    bool is_find_utxo;
    bool is_gas_tray;
};
```

每个 `TransTable` 包含:
```cpp
struct TransTable {
    std::string asset_type;                          // 资产类型
    std::vector<std::string> fromAddr;               // 发送方地址
    std::map<std::string, int64_t> toAddrAmount;     // 目标地址->金额
};
```

---

## 3. TxHelper 类详解

**文件**: `ca/txhelper.h` (~486行), `ca/txhelper.cpp` (~4900行, 138KB)

### 3.1 核心数据结构

| 结构 | 位置 | 说明 |
|------|------|------|
| `Utxo` | `txhelper.h:87-93` | `{value: uint64_t, addr: string, hash: string, n: uint32_t}` -- 内存 UTXO 表示 |
| `TransTable` | `txhelper.h:95-101` | 多资产转账表 |
| `UnspentTxOutputComparator` | `txhelper.h:103-109` | UTXO 比较器（按 value 升序，用于 `multiset`） |
| `ProposalInfo` | `txhelper.h:37-69` | 提案信息 |
| `VoteInfo` | `txhelper.h:71-84` | 投票信息 |

### 3.2 关键方法分析

#### `get_tx_utxo_height()`
- **位置**: `txhelper.cpp:40-77`
- **功能**: 遍历交易所有 UTXO 的 prevout，查找每个 UTXO 所在区块的高度，取最大值
- **调用**: `DBReader::getBlockHashByTransactionHash()` -> `getBlockHeightByBlockHash()`
- **注意**: 如果所有 prevout hash 都不在数据库中，返回 -3

#### `GetUtxos()`
- **位置**: `txhelper.cpp:100-170`
- **功能**: 按地址获取所有资产的 UTXO
- **遍历**: 所有资产类型 -> 该地址的 UTXO hash -> 获取 value
- **特殊**: 支持 `_` 分隔的多值格式（可能会被质押 UTXO 使用）

#### `Check()`
- **位置**: `txhelper.cpp:174-246`
- **功能**: 地址 + 资产类型 + 高度的基础验证
- **检查项**: 地址非空、无重复、ValidAddress、高度合法性、资产类型注册状态

#### `FindUtxo()` (两个重载)

**重载 1 -- 简单贪心** (`txhelper.cpp:248-337`):
```
1. 遍历所有地址->资产类型对
2. 从数据库获取 utxoHashes
3. 过滤: 跳过 lock 数据中未满 1 天的 UTXO (24小时锁定期)
4. 按 value 降序排序
5. 贪心选择前 requiredUtxoAmount 个 UTXO
6. (可选) 发送 confirmUtxoHashRequest 验证
```

**重载 2 -- 随机环形** (`txhelper.cpp:339-463`):
```
1. 从数据库获取 utxoHashes（单地址单资产类型）
2. 按 value 降序排序
3. 放入 circular_buffer
4. 使用 sender/addr 的 hash 作为随机种子
5. 在 circular_buffer 中随机选择起始位置
6. 环形遍历，累加直到 sum >= expend + Gas
7. Gas = (tempGas + i*64 + 34) * 100  (注意: 硬编码 * 100 系数)
```

**关键问题**:
- 重载 2 的 Gas 计算中 `* 100` 系数硬编码，是合约模块 `contract.cpp`(已废弃)中的用法 `gas *= 100` (`contract.cpp:31`) 的遗留
- 重载 1 用于新交易模块(UtxoCore::createUtxoTransferFrom 调用)，重载 2 用于旧 TxHelper 接口
- 两种算法行为差异大: 重载 1 总是选最大的 UTXO（确定性强但隐私差），重载 2 随机化

#### `calculate_utxo_value()`
- **位置**: `txhelper.cpp` (行号约 600+)
- **功能**: 将 balance 字符串转换为 uint64_t 值
- **处理**: `_` 分隔的多值格式求和（质押 UTXO 可能包含多个值）

#### `createTransactionRequest()` (过时接口)
- **位置**: `txhelper.cpp:595`
- **状态**: 此函数标记为过时，新代码使用 UtxoCore 子类的 `trans()` 方法

---

## 4. UTXO 选择/花费算法深度分析

### 4.1 算法流程（以 TransforerTrans 为例）

```
trans()
  │
  ├── transactionDiscoveryHeight()      -- 获取网络高度
  ├── TxHelper::Check()                 -- 地址/资产/高度校验
  ├── createUtxoTransferFrom()          -- UTXO 选择 + Vin 填充
  │     ├── TxHelper::FindUtxo()        -- 查询可用 UTXO (重载1)
  │     ├── 按值排序 (UnspentTxOutputComparator)
  │     ├── 贪心选择 (前 MAX_VIN_SIZE 个)
  │     ├── 检查 setTxOwners 唯一性
  │     └── 填充 vin.prevout
  ├── getGasValue()                     -- Gas 计算
  ├── 余额充足性检查
  ├── createUtxoTransferTo() x N       -- 填充 vout (to + self + burn)
  ├── (is_gas_tray) createUtxoGas()    -- 第三方 Gas 支付
  └── makeTxInfor()                     -- 设置时间/版本/类型/identity/nonce
```

### 4.2 UTXO 选择公平性分析

| 特性 | 重载 1 (简单贪心) | 重载 2 (随机环形) |
|------|-----------------|-----------------|
| 选择策略 | 按值降序，取前 N 个 | 按值降序，随机起始，环形遍历 |
| 确定性 | 完全确定 | 依赖发送者地址哈希（可预测但非完全确定） |
| 碎片化 | 大额 UTXO 优先，碎片化低 | 随机选择，可能导致更多碎片 |
| 隐私性 | 低（总是选大额） | 中等 |
| 使用场景 | UtxoCore 子类 (stake/delegate/lock等) | 旧 TxHelper 接口 (CreateStake等) |
| Gas 处理 | 不预扣 Gas（Gas 在 vout 中扣除） | 预扣 `(tempGas + i*64 + 34) * 100` |

### 4.3 UTXO 花费标记

UTXO 花费不是在交易构造时标记，而是在**区块确认时**由存储层处理:
- 已花费的 UTXO 从其地址的索引 (`UAH:`) 中移除
- UTXO value 从余额 (`BAL:`) 中扣除
- 新创建的 UTXO 添加到对应地址的索引

---

## 5. 交易验证函数族

### 5.1 验证调用链

```
handleTransaction()                              -- transaction.cpp:1374
  │
  ├── Util::IsVersionCompatible()                -- 版本兼容检查
  ├── verifyTransactionTimeoutRequest(tx)         -- 超时检查 (行 1423)
  ├── verifyTxUtxoHeight(tx, txUtxoHeight)       -- UTXO高度验证 (行 1427) [非合约/FUND]
  ├── checkTop(nodeHeight)                        -- 节点高度合理性 (行 1472)
  ├── verifyTransactionMessageRequest(*msg)       -- 交易消息验证 (行 1498)
  ├── AttachTxSelectionProof(tx, selectionVrf)    -- VRF 选择证明附加 (行 1505)
  ├── TxHelper::addVerifySign(defaultAddr, tx)    -- 验证签名 (行 1510)
  ├── VerifyBlockPackager(tx) / ContractVerifier(tx) -- 打包节点验证 (行 1533/1541)
  └── TransactionCache::AddCache(tx, msg)         -- 加入交易缓存 (行 1551)
```

### 5.2 各验证函数详解

#### `verifyTransactionTimeoutRequest()`
- **位置**: `transaction.cpp:3905-3924`
- **逻辑**:
  ```
  普通交易: expireTime = KtxTimeout = 10,000,000 us (10s)
  合约交易: expireTime = 3 * KtxTimeout = 30,000,000 us (30s)
  
  失败条件:
    tx.time() + expireTime <= nowTime    // 交易已过期
    tx.time() >= nowTime + expireTime    // 交易时间戳在未来太远
  ```
- **风险**: `nowTime` 使用本机UTC时间，节点间时钟偏差可能导致误判

#### `verifyTxUtxoHeight()`
- **位置**: `transaction.cpp:1244-1260`
- **逻辑**: 对比发送方 `msg->txutxoheight` 与本地计算的 UTXO 高度
- **失败场景**: UTXO 不存在于本地数据库、高度不一致

#### `verifyTransactionMessageRequest()`
- **位置**: 声明在 `transaction.h:304`，实现在 `transaction.cpp`
- **功能**: 验证交易消息的签名和格式完整性（实现不在分析范围内，约在行 1700+）

---

## 6. 问题清单

### 问题 6: UtxoCore 中未使用的成员变量 tx_
- **位置**: `ca/transaction/utxo_core.h:115`
- **现象**: 定义了 `CTransaction *tx_` 指针，但所有代码使用 `CTransaction tx` (栈变量)
- **风险等级**: Low
- **触发场景**: 代码维护者误用 `tx_`
- **修复建议**: 删除未使用的 `tx_` 成员

### 问题 7: 两种 FindUtxo 算法并存导致维护困难
- **位置**: `ca/txhelper.cpp:248-337` vs `ca/txhelper.cpp:339-463`
- **现象**: 两个重载行为不一致，Gas 计算方式不同
- **风险等级**: Medium
- **触发场景**: 同一交易通过不同路径构造，可能选中完全不同的 UTXO
- **修复建议**: 统一为随机环形算法，Gas 系数提取为配置常量

### 问题 8: 重载2 Gas 预定系数硬编码
- **位置**: `ca/txhelper.cpp:422-431`
- **现象**: `Gas = (tempGas + (i * 64) + 34) * 100`，`* 100` 硬编码
- **风险等级**: Medium
- **触发场景**: Gas 计算不一致可能导致 UTXO 选择不足或过度
- **修复建议**: 将系数 `100` 提取为命名常量或配置参数

### 问题 9: checkParams() 多数未实现
- **位置**: `trans.cpp:283-285`, `delegating.cpp:299`, `bonus.cpp:363`, `undelegating.cpp:295`
- **现象**: 多数子类的 `checkParams()` 返回 `return true` 而不做任何检查
- **风险等级**: Medium
- **触发场景**: 无效参数提前未被捕获，导致交易构造到后期才失败
- **修复建议**: 在各子类中实现实际参数校验

### 问题 10: UnStake::checkParams() 空函数体
- **位置**: `ca/transaction/unstake.cpp:270-273`
- **现象**: 函数体为空，不返回任何值（编译器可能警告）
- **风险等级**: High
- **触发场景**: 未定义行为 (UB)，函数无返回值的控制路径
- **修复建议**: 至少添加 `return true;`

### 问题 11: n (UTXO索引) 始终为 0
- **位置**: `ca/txhelper.cpp:274,339` 注释 "At present, the n of utxo is all 0"
- **现象**: 一个交易中如果有多个 vout 输出给同一地址，它们无法通过 `n` 区分
- **风险等级**: Medium
- **触发场景**: 需要引用特定 vout 的场景（理论上需要 n > 0）
- **修复建议**: 正确设置 vout 索引 `n`
