# 模块3: UTXO 模型实现 - 状态流转

## 1. UTXO 状态机

```mermaid
stateDiagram-v2
    [*] --> 未创建: (无)

    未创建 --> 未确认: 交易构造完成<br/>(vout 生成)

    未确认 --> 已确认_可用: 区块确认<br/>(写入 RocksDB)

    未确认 --> 作废: 交易超时/验证失败<br/>(从mempool移除)

    已确认_可用 --> 已花费: 被新交易 vin 引用<br/>(从 UAH: 索引移除)

    已确认_可用 --> 已锁定: LOCK 交易<br/>(用于投票权)

    已锁定 --> 已确认_可用: UNLOCK 交易<br/>(释放锁定)

    已确认_可用 --> 已质押: STAKE 交易<br/>(vout -> VirtualStake)

    已质押 --> 已确认_可用: UNSTAKE 交易<br/>(解除质押)

    已确认_可用 --> 已委托: DELEGATE 交易<br/>(vout -> VirtualDelegating)

    已委托 --> 已确认_可用: UNDELEGATE 交易<br/>(解除委托)

    已花费 --> 已确认_可用: 区块回滚<br/>(链重组恢复)

    note right of 已质押
        必须等待 MIN_UNSTAKE_HEIGHT<br/>(500 个区块) 才能解除
    end note

    note right of 已锁定
        锁定资产类型必须为 VOTE<br/>最小锁定金额 = LOCK_AMOUNT * kDecimalNum
    end note
```

### 1.1 UTXO 状态说明

| 状态 | 含义 | 进入条件 | 退出条件 | 是否可花费 |
|------|------|---------|---------|-----------|
| **未创建** | UTXO 不存在 | 初始状态 | 交易构造 | 否 |
| **未确认** | 交易在 mempool/未打包 | 交易签名并广播 | 区块确认或超时 | 否 |
| **已确认(可用)** | 已上链可花费 | 区块确认，UTXO 写入 RocksDB | 被花费/锁定/质押/委托 | 是 |
| **已花费** | 已被新交易引用 | 新交易的 vin.prevout 指向此 UTXO | 链重组回滚 | 否 |
| **已锁定** | 用于投票权 | LOCK 交易成功 | UNLOCK 交易 | 否 |
| **已质押** | 节点质押中 | STAKE 交易 (vout->VirtualStake) | UNSTAKE 交易 (需等 500 区块) | 否 |
| **已委托** | 委托给节点 | DELEGATE 交易 (vout->VirtualDelegating) | UNDELEGATE 交易 (需等 1 天) | 否 |
| **作废** | 永久失败 | 交易超时/验证失败 | 不可恢复 | 否 |

---

## 2. 交易状态机

```mermaid
stateDiagram-v2
    [*] --> 创建: RPC 调用

    创建 --> 参数校验: XxxTrans 构造

    参数校验 --> 参数校验失败: checkParams() 失败

    参数校验 --> UTXO选择: checkParams() 通过

    UTXO选择 --> UTXO不足: FindUtxo 返回空/不足

    UTXO选择 --> Vin填充: FindUtxo 成功

    Vin填充 --> Vout填充: createUtxoTransferTo

    Vout填充 --> 元信息设置: makeTxInfor
    note right of 元信息设置: 设置 time, version,<br/>type, identity, nonce, data

    元信息设置 --> Gas计算: getGasValue

    Gas计算 --> 余额检查: total >= expend ?

    余额检查 --> 余额不足: total < expend

    余额检查 --> 已构造: total >= expend

    已构造 --> 已签名: signTx()
    note right of 已签名: VIN 级签名 + UTXO 级签名<br/>SHA256 hash 计算

    已签名 --> 已广播: goMessage()
    note right of 已广播: identity == defaultAddr?<br/>-> handleTransaction<br/>-> DropShippingTransaction

    已广播 --> 验证中: handleTransaction()

    验证中 --> 验证失败: 超时/高度/签名失败
    note right of 验证失败: 返回错误码<br/>进入 failedTransactionCache

    验证中 --> 已加入缓存: TransactionCache::AddCache

    已加入缓存 --> 已打包: 区块打包节点处理

    已打包 --> 已确认: 区块确认

    已打包 --> 打包失败: 区块回滚

    已确认 --> 已确认: (永久存储)

    参数校验失败 --> [*]
    UTXO不足 --> [*]
    余额不足 --> [*]
    验证失败 --> [*]
    打包失败 --> [*]
    作废 --> [*]
```

### 2.1 交易状态说明

| 状态 | 含义 | 持久化? | 可回滚? |
|------|------|---------|---------|
| 创建 | 用户发起请求 | 否 | N/A |
| 参数校验 | 验证输入参数 | 否 | N/A |
| UTXO选择 | 从数据库选取可用 UTXO | 否 | N/A |
| Vin填充 | 设置交易输入 | 否 | N/A |
| Vout填充 | 设置交易输出 | 否 | N/A |
| 元信息设置 | 设置 time/type/identity/nonce | 否 | N/A |
| 已构造 | 交易对象完整 | 仅在内存 | N/A |
| 已签名 | 两层签名完成 | 仅在内存 | N/A |
| 已广播 | 已发送到打包节点 | 否（网络） | N/A |
| 验证中 | handleTransaction 处理中 | 否 | N/A |
| 已加入缓存 | TransactionCache 管理 | 内存缓存 | 是（移除） |
| 已打包 | 进入区块 | 区块数据 | 是（回滚） |
| 已确认 | 区块被共识确认 | RocksDB 永久 | 理论可回滚 |

---

## 3. 特殊 UTXO 状态转移

### 3.1 质押 (STAKE) 状态跃迁

```mermaid
stateDiagram-v2
    direction LR

    state "可用 UTXO" as AVAIL
    state "质押中" as STAKED
    state "质押解锁中" as UNSTAKING
    state "委托给节点" as DELEGATED
    state "委托解锁中" as UNDELEGATING

    AVAIL --> STAKED: STAKE 交易<br/>(vout -> VirtualStake)
    AVAIL --> DELEGATED: DELEGATE 交易<br/>(vout -> VirtualDelegating)

    STAKED --> UNSTAKING: UNSTAKE 交易<br/>(需要质押时长达标)

    DELEGATED --> UNDELEGATING: UNDELEGATE 交易<br/>(需要委托时长达标)

    note right of STAKED
        约束:
        - 最小质押金额: 3500 MM
        - 佣金率: 5% ~ 35%
        - 不能重复质押
    end note

    note right of DELEGATED
        约束:
        - 最小委托金额: 500 MM
        - 最大投资金额: 3,500,000 MM
        - 最大投资笔数: 1000
    end note
```

### 3.2 投票权锁定 (LOCK) 状态跃迁

```mermaid
stateDiagram-v2
    state "可用 Vote UTXO" as VOTE_AVAIL
    state "已锁定(有投票权)" as LOCKED

    VOTE_AVAIL --> LOCKED: LOCK 交易<br/>(vout -> LockVirtualStake)
    LOCKED --> VOTE_AVAIL: UNLOCK 交易<br/>(释放锁定的 Vote)

    note right of LOCKED
        约束:
        - 资产类型必须为 VOTE
        - 最小锁定金额: LOCK_AMOUNT * kDecimalNum
          = 1 * 100000000 = 1 MM
        - 不能重复锁定
        - 锁定后才能投票
    end note
```

---

## 4. 区块回滚时的 UTXO 状态恢复

```mermaid
flowchart TD
    ROLLBACK[触发回滚] --> FIND[找到分叉点高度]
    FIND --> DESCEND[从 top 逐区块回滚]
    DESCEND --> REVERT_TX{遍历区块内每笔交易}
    REVERT_TX --> MARK_UNSPENT[将 vin 引用的 UTXO 标记为未花费]
    MARK_UNSPENT --> RESTORE_UB[恢复 UB: 前缀索引]
    RESTORE_UB --> RESTORE_UAH[恢复 UAH: 前缀索引]
    RESTORE_UAH --> RESTORE_BAL[恢复 BAL: 余额]
    RESTORE_BAL --> REMOVE_NEW[移除新创建的 UTXO (vout)]
    REMOVE_NEW --> REVERT_TX
    REVERT_TX -->|区块处理完毕| NEXT_BLOCK{还有区块?}
    NEXT_BLOCK -->|是| DESCEND
    NEXT_BLOCK -->|否| APPLY_NEW[应用新分叉区块]
```

**关键设计点**:
- UTXO 回滚涉及三个 RocksDB Key 前缀: `UB:`, `UAH:`, `BAL:`（详见 storage_model.md）
- 回滚超时保护: `RollBackTime = 15 秒` —— 仅回滚 15 秒前的区块（spec 5.5.4）
- 回滚深度限制: 快速同步模式下超过 10 个区块会触发从零同步（spec 5.6.5）

---

## 5. 问题清单

### 问题 14: UTXO 回滚可能引发余额不一致
- **位置**: 存储层 (block_helper / block_stroage)，非本模块直接范围
- **现象**: 区块回滚时，如果新 UTXO 已被后续交易花费，恢复逻辑可能复杂
- **风险等级**: High
- **触发场景**: 深度重组时，已花费 UTXO 的级联回滚
- **修复建议**: 实现二级回滚机制，跟踪 UTXO 消费链
- **验证方法**: 【需人工验证】模拟 3+ 层级的 UTXO 消费链回滚

### 问题 15: failedTransactionCache 中的交易高度超前处理不完整
- **位置**: `transaction.cpp:1433-1438` 和 `transaction.cpp:1449-1454`
- **现象**: 当 `txUtxoHeight > top` 时，交易被加入 `failedTransactionCache`，但未定义重试机制
- **风险等级**: Medium
- **触发场景**: 发送方高度领先接收方，交易被缓存后可能永远不被重试
- **修复建议**: 添加定时重试或事件驱动的重试机制
- **验证方法**: 发送方人为设置超前高度，观察交易最终是否被处理

### 问题 16: 合约交易高度不一致仅警告不阻止
- **位置**: `transaction.cpp:1407-1411`, `transaction.cpp:1416-1420`
- **现象**: 合约交易和 FUND 交易在 `nodeHeight != top` 时只输出 DEBUGLOG 警告，不返回错误
- **风险等级**: Medium
- **触发场景**: 节点高度不一致时执行合约，可能导致 EVM 状态分歧
- **修复建议**: 考虑在高度差超过阈值时拒绝处理
- **验证方法**: 【需人工验证】两个不同步的节点执行同一合约
