# 模块3: UTXO 模型实现 - 重构建议

## 1. 当前架构问题总览

| 问题类别 | 严重程度 | 影响文件 | 根本原因 |
|---------|---------|---------|---------|
| 文件过大 | Critical | `transaction.cpp` (128KB), `txhelper.cpp` (138KB) | 缺乏模块化拆分 |
| 代码重复 | High | 所有交易子模块 (`stake.cpp`/`delegating.cpp` 等) | 基类抽象不足 |
| 两种 FindUtxo 算法 | Medium | `txhelper.cpp` | 接口演进未清理旧代码 |
| 死代码 | Critical | `txhelper.cpp:287-292`, `contract.cpp`(全 `#if 0`) | 缺乏代码审查 |
| 全局锁问题 | Critical | `global.h:29-32` | C++ static 误用 |
| Nonce 非原子 | High | 多处 | 缺乏并发设计 |
| 一致性缺失 | Medium | 全局 | UTXO/EVM 两套状态系统 |
| 测试覆盖不足 | High | 全局 | 无单元测试 |

---

## 2. ca/transaction.cpp (128KB) 拆分建议

### 2.1 当前问题

`transaction.cpp` 包含了交易处理、验证、VRF、区块处理、Gas 计算、合约根哈希、打包节点选择等功能，严重违背单一职责原则。

### 2.2 拆分方案

```
ca/
├── transaction/
│   ├── tx_handle.cpp         -- HandleTx, handleTransaction (原 1262-1559行)
│   ├── tx_verify.cpp         -- verifyTransactionTimeoutRequest,
│   │                             verifyTxUtxoHeight,
│   │                             verifyTransactionMessageRequest (原 1244-1260, 3905-3924)
│   ├── tx_gas.cpp            -- CalculateGas, GenerateGas, precalculatedGas (原 3926-3999)
│   ├── tx_block.cpp          -- HandleBlock, handleBlock, handleBuildBlockBroadcastMessage
│   ├── tx_sign.cpp           -- AddBlockSign, VerifyBlockSign, addVerifySign
│   ├── tx_contract.cpp       -- contractTransactionRequest, ContractVerifier
│   │                             fetchContractRootHash (原 1308-1370, 1561-1579, 4001+)
│   ├── tx_packager.cpp       -- find_sign_node, calculatePackerByTime,
│   │                             get_contract_distribution_manager (原 141+)
│   ├── tx_stake_query.cpp    -- SearchStake, getStake, GetStakeAmountByTime,
│   │                             GetdelegateAmountByTime, GetStakedelegateAmountByTime
│   ├── tx_qualification.cpp  -- IsQualifiedToUnstake, IsQualifiedToUnLock,
│   │                             CheckDelegatingQualification, evaluateBonusEligibility,
│   │                             CheckFundQualificationAndGetRewardAmount
│   └── tx_routing.cpp        -- DropShippingTransaction, dropCallShippingRequest
├── vrf/
│   ├── vrf_packager.cpp      -- 打包节点 VRF 选择逻辑
│   └── vrf_selection.cpp     -- VRF 种子生成、随机选择
└── block/
    └── block_verify.cpp      -- 区块验证逻辑
```

**预估工时**: 5-7 人天
**风险**: 中等 -- 拆分后需重新验证跨文件引用不丢失

---

## 3. ca/txhelper.cpp (138KB) 拆分建议

### 3.1 当前问题

`TxHelper` 类包含了所有交易类型的 Create 函数、UTXO 查找、签名、VRF 代理选择、合约部署/调用等，是单体类的反模式。

### 3.2 拆分方案

```
ca/
├── txhelper/
│   ├── tx_helper_core.cpp       -- Check, GetUtxos, getTransactionOwner,
│   │                                get_tx_utxo_height (基础工具)
│   ├── tx_helper_utxo.cpp       -- FindUtxo (两个重载统一),
│   │                                calculate_utxo_value, sendConfirmUtxoHashRequest
│   ├── tx_helper_sign.cpp       -- Sign, addMultipleSigns, addVerifySign
│   ├── tx_helper_vrf.cpp        -- get_vrf_agent_type, fetchIdentityNodes,
│   │                                getTransactionStartIdentity, GetEligibleNodes
│   ├── tx_helper_transfer.cpp   -- createTransactionRequest (普通转账)
│   ├── tx_helper_stake.cpp      -- CreateStakingTransaction, CreateUnstakeTransaction
│   ├── tx_helper_delegate.cpp   -- CreateDelegatingTransaction,
│   │                                CreateUndelegatingTransaction
│   ├── tx_helper_bonus.cpp      -- CreateBonusTransaction
│   ├── tx_helper_fund.cpp       -- CreateFundTransaction
│   ├── tx_helper_lock.cpp       -- createLockTransaction, createUnlockTransactionRequest
│   ├── tx_helper_vote.cpp       -- CreateProposalTransaction,
│   │                                CreateRevokeProposalTransaction, CreateVoteTransaction
│   └── tx_helper_contract.cpp   -- make_evm_deploy_contract_transaction,
│                                    makeEvmCallContractTransaction,
│                                    createEvmDeployContractTransactionRequest,
│                                    createEvmCallContractTransactionRequest
```

**预估工时**: 7-10 人天
**风险**: 中等偏高 -- `TxHelper` 各函数间共享大量代码（如 vin/vout 填充逻辑），拆分后需要提取公共函数

---

## 4. 交易类型子模块重构方案

### 4.1 当前问题

所有 10 个交易类型子类 (`StakeTrans`, `UnStake`, `DelegatingTrans`, `UndelegatingTrans`, `BonusTrans`, `FundTrans`, `LockTrans`, `UnlockTrans`, `VoteTrans`, `TransforerTrans`) 存在严重的代码重复。

### 4.2 重复代码分析

每个子类的以下函数几乎完全相同：

```cpp
// 完全相同的模式 (所有子类):
expected<bool> goMessage() {
    // 1. transactionDiscoveryHeight()
    // 2. 构造 TxMsgReq
    // 3. TxHelper::get_tx_utxo_height()
    // 4. 判断 identity == defaultAddr -> handleTransaction / DropShippingTransaction
    // 5. DEBUGLOG "Transaction result, ret:{}, txHash:{}"
    return true;
}

// 相似度 > 80% 的模式:
expected<bool> makeTxInfor(CTransaction* tx) {
    // 1. 构造 JSON txInfo
    // 2. tx->set_data(data.dump())
    // 3. tx->set_note(encoded_info)
    // 4. 检查 utxos_size > 0, owner_size > 0
    // 5. getNonceByAddr -> set_nonce
}

// 相似度 > 60% 的模式 (各子类略有差异):
expected<int64_t> getGasValue(CTxUtxos* u, int index) {
    // 1. gasSize = data+note+reserve0+reserve1 大小
    // 2. 构造 toAddr map
    // 3. GenerateGas()
    // 4. GetInitAccountAddr() == addr -> gas = 0
    return gas;
}
```

### 4.3 重构方案: 模板方法模式

将 `goMessage()` 和 `makeTxInfor()` 提升到 `UtxoCore` 基类中，子类仅需提供差异化的参数：

```cpp
// 基类提供默认实现
namespace mmc {

struct TxMetaInfo {
    nlohmann::json txInfo;
    global::ca::TxType txType;
};

class UtxoCore {
protected:
    // 默认实现，子类可选择覆盖
    virtual TxMetaInfo buildTxMetaInfo() = 0;  // 纯虚，子类必须实现

    expected<bool> goMessage() {
        // 所有子类共享的默认实现
        uint64_t top;
        auto retNum = transactionDiscoveryHeight();
        if (!retNum.isOk()) {
            return retNum << PERROR(MEM::FAILED_TO_GET_HEIGHT);
        }
        top = retNum.Value();

        TxMsgReq txMsg;
        txMsg.set_version(mm::GetVersion());
        TxMsgInfo* txMsgInfo = txMsg.mutable_txmsginfo();
        txMsgInfo->set_type(0);
        txMsgInfo->set_tx(tx.SerializeAsString());
        txMsgInfo->set_nodeheight(top);

        uint64_t txUtxoLocalHeight;
        auto ret = TxHelper::get_tx_utxo_height(tx, txUtxoLocalHeight);
        if (ret != 0) {
            return PERROR(MEM::FAILED_TO_GET_UTXO_HEIGHT, "ret:{}", ret);
        }
        txMsgInfo->set_txutxoheight(txUtxoLocalHeight);

        auto msg = std::make_shared<TxMsgReq>(txMsg);
        std::string defaultAddr =
            MagicSingleton<AccountManager>::GetInstance()->GetDefaultAddr();

        if (tx.identity() == defaultAddr) {
            ret = handleTransaction(msg, tx);
        } else {
            ret = DropShippingTransaction(msg, tx, tx.identity());
        }

        DEBUGLOG("Transaction result, ret:{}  txHash:{}", ret, tx.hash());
        return true;
    }

    // 公共的 makeTxInfor 逻辑
    void applyTxMetaInfo(const TxMetaInfo& meta) {
        nlohmann::json data;
        data["txinfo"] = meta.txInfo;
        tx.set_data(data.dump());

        tx.set_version(global::ca::CURRENT_TRANSACTION_VERSION);
        tx.set_consensus(global::ca::kConsensus);
        tx.set_type((uint32_t)meta.txType);

        if (tx.utxos_size() <= 0) {
            throw std::runtime_error("tx has no utxos!");
        }
        if (tx.utxos(0).owner_size() <= 0) {
            throw std::runtime_error("utxos(0) has no owner!");
        }

        uint64_t nonce = 0;
        DBReader db_reader;
        if (db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce)
                != DBStatus::DB_SUCCESS &&
            db_reader.getNonceByAddr(tx.utxos(0).owner(0), nonce)
                != DBStatus::DB_NOT_FOUND) {
            throw std::runtime_error("get NonceByAddr error");
        }
        tx.set_nonce(nonce);
    }
};

} // namespace mmc
```

**预估工时**: 3-5 人天
**风险**: 低 -- 主要是消除重复，不改变行为
**收益**: 减少约 500+ 行重复代码；降低新交易类型添加的复杂度

---

## 5. UTXO/EVM 一致性问题

### 5.1 问题描述

UTXO 模型和 EVM 账户模型存在两套独立的状态系统：

```
UTXO 状态 (RocksDB):
  - UB:/UAH:/BAL: 前缀
  - 通过 prevout 引用
  - 花费时移除索引

EVM 状态 (MPT):
  - Merkle Patricia Trie
  - 通过 rootHash 验证
  - 通过 EvmHost::accounts 访问
```

当一笔合约交易 (CALL/DEPLOY) 同时涉及 UTXO 花费（支付 Gas）和 EVM 状态变更时，这两个操作需要在区块确认时保持**原子性**。

### 5.2 当前实现分析

合约交易的 Gas 支付：
1. UTXO 侧的 Gas 支付 UTXO 被创建（`createUtxoGas()`）
2. EVM 执行通过 `EvmHost` 完成状态变更
3. 区块确认时，两步操作应在同一个 RocksDB WriteBatch 中原子提交

**但**: `contract.cpp` 已全部 `#if 0`，合约交易的实际构造逻辑分散在 `txhelper.cpp` 的 `make_evm_deploy_contract_transaction()` 等函数中，难以确认原子性保证。

### 5.3 建议

```
1. 使用 RocksDB WriteBatch 将以下操作打包为一个原子写入:
   - UTXO 花费标记 (UB:/UAH:/BAL: 更新)
   - EVM MPT rootHash 更新
   - Nonce 递增

2. 区块级别的写操作也应使用 WriteBatch

3. 添加一致性检查工具:
   - 启动时校验: 遍历所有 UTXO, 验证 BAL 一致性
   - 运行时检查: 区块确认后验证 rootHash
```

---

## 6. 统一 FindUtxo 算法

### 6.1 建议方案

将两个 FindUtxo 重载统一为单一实现：

```cpp
struct FindUtxoConfig {
    uint64_t maxVinSize = 1000;
    bool randomize = true;        // 是否随机化选择
    uint64_t gasCoefficient = 1;  // Gas 预扣系数（替换硬编码的 * 100）
    bool filterLocked = true;     // 是否过滤锁定 UTXO
};

int FindUtxo(const std::vector<std::pair<std::string, std::string>>& addressAssetPairs,
             const FindUtxoConfig& config,
             uint64_t& total,
             std::multiset<Utxo, UnspentTxOutputComparator>& outputUtxosSet,
             bool isFindUtxo = false,
             const std::string& sender = "")
```

**预估工时**: 1-2 人天
**风险**: 中等 -- 需要回归测试所有交易类型

---

## 7. 死代码清理

### 7.1 确认的死代码

| 位置 | 内容 | 处理建议 |
|------|------|---------|
| `ca/transaction/contract.cpp` | 全量 `#if 0` (896行) | 删除文件，或移动到 `legacy/` |
| `ca/txhelper.cpp:287-292` | `continue` 后的死代码 | 修复逻辑（见问题 21） |
| `ca/transaction.cpp:3947,3978` | `gas *= 1` 无操作代码 | 删除或替换为可配置参数 |
| `ca/transaction/utxo_core.h:115` | `CTransaction *tx_` 未使用成员 | 删除 |
| `ca/transaction.cpp:1440` | 重复的 `verifyTxUtxoHeight` 调用 | 删除 |

### 7.2 已注释的代码模式

大量被注释掉的旧代码（标记为 `//` 的错误码返回），例如：
- `trans.cpp:48-50`: `// ret -= 100; // return ret;`
- `delegating.cpp:41-42`: `// ret -= 100; // return ret;`
- 多处 `// std::string txHash = Getsha256Hash(tx.SerializeAsString()); // tx.set_hash(txHash);`

**建议**: 系统性地清理这些注释代码，保留有意义的注释说明原因。

**预估工时**: 0.5 人天

---

## 8. 测试建议

### 8.1 单元测试

| 测试模块 | 测试内容 | 预估用例数 |
|---------|---------|-----------|
| `UtxoCore` | createUtxoTransferFrom/To, signTx, createUtxoGas | 15+ |
| `FindUtxo` | 贪心选择, 随机选择, 锁定过滤, 余额不足 | 20+ |
| `CalculateGas/GenerateGas` | 不同输入大小, 边界条件 | 10+ |
| `handleTransaction` | 超时, 高度, 签名失败, 正常流程 | 15+ |
| 各交易子类 | 正常构造, 参数校验失败, 余额不足, Gas不足 | 30+ |

### 8.2 集成测试

- UTXO 选择 + 消费 + 回滚: 模拟完整生命周期
- 多地址并发交易: 双花检测验证
- 跨区块 UTXO 消费链: 5+ 层级
- 合约交易 + UTXO Gas 支付原子性: 故障注入

### 8.3 压力测试

- 1000 笔/秒交易构造
- 10000+ UTXO 地址的 FindUtxo 性能
- 区块回滚 100+ 区块的恢复时间

**预估测试工时**: 10-15 人天

---

## 9. 总工时预估

| 任务 | 工时 | 优先级 |
|------|------|--------|
| 拆分 transaction.cpp (128KB) | 5-7 人天 | P1 |
| 拆分 txhelper.cpp (138KB) | 7-10 人天 | P1 |
| 交易子模块重构 (模板方法) | 3-5 人天 | P2 |
| 统一 FindUtxo 算法 | 1-2 人天 | P2 |
| 修复死代码/全局锁/Nonce 问题 | 2-3 人天 | P0 (Critical) |
| UTXO/EVM 原子性保证 | 3-5 人天 | P1 |
| 死代码和注释清理 | 0.5 人天 | P3 |
| 单元测试 | 5-7 人天 | P1 |
| 集成测试 | 3-5 人天 | P1 |
| 压力测试 | 2-3 人天 | P2 |
| **总计** | **31.5-47.5 人天** | |

---

## 10. 重构优先级路线图

### Phase 1: 修复 (P0, 1周)
1. 修复全局锁跨编译单元问题 (问题 17)
2. 修复 FindUtxo 死代码 bug (问题 21)
3. 修复 UnStake::checkParams() 空函数体 (问题 10)
4. 添加 Nonce 原子递增 (问题 18)

### Phase 2: 重构核心 (P1, 3-4周)
1. 拆分 transaction.cpp 和 txhelper.cpp
2. 实现 UTXO/EVM WriteBatch 原子写入
3. 编写核心模块单元测试

### Phase 3: 优化 (P2, 2-3周)
1. 交易子模块模板方法重构
2. 统一 FindUtxo 算法
3. 集成测试和压力测试

### Phase 4: 清理 (P3, 1周)
1. 删除 contract.cpp 等废弃代码
2. 清理注释代码
3. 文档更新
