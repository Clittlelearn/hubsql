# 模块3: UTXO 模型实现 - 核心调用链

## 1. 交易创建完整调用链

### 1.1 新架构 (UtxoCore 子类) 调用链

```mermaid
sequenceDiagram
    participant RPC as RPC/API 层
    participant XX as XxxTrans (子类)
    participant UC as UtxoCore (基类)
    participant TH as TxHelper
    participant DB as RocksDB (DBReader)
    participant ACC as AccountManager
    participant NET as 网络层

    RPC->>XX: 创建 XxxTrans(param)
    XX->>XX: trans()
    XX->>UC: transactionDiscoveryHeight()
    UC->>NET: sendSyncGetHeightHashRequest()
    UC->>NET: 等待 80% 节点回复
    NET-->>UC: 共识高度
    UC-->>XX: top (uint64_t)

    XX->>TH: Check(fromAddr, assetType, top+1)
    TH->>DB: getAssetType() / getBlockTop()
    TH-->>XX: 0 (验证通过)

    XX->>XX: checkParams()
    Note over XX: 大多数子类返回 true<br/>(Stake 检查 isStaked/minStakeAmount)

    XX->>UC: createUtxoTransferFrom(u, param, sq)
    UC->>TH: FindUtxo(fromAddr_assetType, MAX_VIN_SIZE, ...)
    TH->>DB: getUtxoHashsByAddress()
    TH->>DB: getUtxoValueByUtxoHashes()
    TH->>DB: get30DayLockData() (过滤锁定期)
    TH->>TH: 按值降序排序
    TH->>TH: 贪心选择前 N 个 (v1)<br/>或 随机环形选择 (v2)
    TH-->>UC: outputUtxosSet
    UC->>UC: 检查 setTxOwners 唯一性
    UC->>UC: 填充 vin.prevout + owner
    UC-->>XX: balance (int64_t)

    XX->>XX: makeTxInfor(&tx)
    Note over XX: 设置:<br/>- time (UTC微秒)<br/>- version (CURRENT_TRANSACTION_VERSION)<br/>- consensus (kConsensus=3)<br/>- type (TxType枚举)<br/>- data (JSON txinfo)<br/>- nonce (从DB读取)

    XX->>XX: getGasValue(u, index)
    XX->>TH: GenerateGas(utxo, voutSize, gasSize, gas)
    TH->>TH: gas = owner_size*34 + utxoSize + vout_size*34 + gasSize
    TH-->>XX: gas (uint64_t)

    XX->>XX: 余额充足性检查 (total >= expend)

    XX->>UC: createUtxoTransferTo(u, to_param) x N
    Note over UC: 创建 vout:<br/>1. to_addr = amount<br/>2. self = total-expend-gas<br/>3. VIRTUAL_BURN_GAS_ADDR = gas

    alt is_gas_tray (第三方支付Gas)
        XX->>UC: createUtxoGas(&tx, gas_param)
        UC->>UC: createUtxoTransferFrom() + to_self + to_burn
        UC->>UC: set_gas(UTXO_GAS_TYPE_TRUE)
        UC->>UC: set_independence(TX_INDEPENDENCE_TRUE)
    end

    XX->>UC: calculate_all_hash(&tx)
    UC->>UC: 串联所有 prevout.hash + tx.time()
    UC-->>XX: all_hash

    XX->>TH: fetchIdentityNodes(type, all_hash, time, identity, selector)
    TH-->>XX: identity (打包节点地址)

    XX->>XX: tx.set_identity(identity)

    XX->>XX: goMessage()

    XX->>ACC: GetDefaultAddr()
    ACC-->>XX: defaultAddr

    alt tx.identity == defaultAddr (本节点是打包者)
        XX->>TH: handleTransaction(msg, tx)
    else 其他节点是打包者
        XX->>TH: DropShippingTransaction(msg, tx, identity)
    end
```

### 1.2 旧架构 (TxHelper::CreateXxxTransaction) 调用链

```mermaid
flowchart TD
    RPC[RPC 调用] --> TX[TxHelper::CreateXxxTransaction]
    TX --> CHK[TxHelper::Check]
    TX --> FIND[TxHelper::FindUtxo (重载2)]
    FIND --> SORT[按值降序 -> circular_buffer]
    FIND --> RANDOM[随机种子选择起始位置]
    FIND --> CIRCLE[环形遍历累加 UTXO]
    TX --> FILL[手动填充 vin/vout]
    TX --> ID[fetchIdentityNodes]
    ID --> NET[VRF 选择打包节点]
    TX --> SIGN[addMultipleSigns]
    TX --> HASH[Getsha256Hash -> set_hash]
```

---

## 2. UTXO 选择算法详细流程

### 2.1 重载 1 (简单贪心) -- 用于 UtxoCore::createUtxoTransferFrom

```mermaid
flowchart TD
    START([createUtxoTransferFrom]) --> BUILD[构建 fromAddr -> assetType map]
    BUILD --> QUERY[DB: getUtxoHashsByAddress]
    QUERY --> DEDUP[去重 utxoHashes]
    DEDUP --> LOOP{遍历每个 hash}
    LOOP --> GETVAL[DB: getUtxoValueByUtxoHashes]
    GETVAL --> LOCK{检查 30 天锁定?}
    LOCK -->|是| SKIP[跳过此 UTXO]
    LOCK -->|否| CALC[calculate_utxo_value]
    CALC --> PUSH[加入 Utxos 向量]
    PUSH --> LOOP
    LOOP -->|结束| SORT[按 value 降序排序]
    SORT --> GREEDY{outputUtxosSet.size < MAX_VIN_SIZE?}
    GREEDY -->|是| TAKE[取下一个最大 UTXO]
    TAKE --> ACCUM[累加 total]
    ACCUM --> GREEDY
    GREEDY -->|否| RETURN[返回 balance]
```

**关键代码位置**: `txhelper.cpp:248-337`, `utxo_core.cpp:74-140`

### 2.2 重载 2 (随机环形) -- 用于旧 TxHelper 接口

```mermaid
flowchart TD
    START([FindUtxo v2]) --> QUERY[DB: getUtxoHashsByAddress<br/>单地址单资产]
    QUERY --> DEDUP[去重 utxoHashes]
    DEDUP --> GETVAL[遍历: getUtxoValueByUtxoHashes]
    GETVAL --> SORT[按 value 降序排序]
    SORT --> CIRCLE[放入 circular_buffer]
    CIRCLE --> SEED[hash(sender or addr) 作为随机种子]
    SEED --> RANDOM[uniform_int_distribution<br/>选择随机起始位置]
    RANDOM --> LOOP[环形遍历]
    LOOP --> ACCUM[累加 amountSum += it->value]
    ACCUM --> CHECK{amountSum >= expend + Gas?}
    CHECK -->|是| RETURN[返回 outputUtxosSet]
    CHECK -->|否| NEXT[++it, 环形折返]
    NEXT --> LOOP
    LOOP -->|遍历完整圈| FAIL[outputUtxosSet 为空 -> 失败]
```

**关键代码位置**: `txhelper.cpp:339-463`
**Gas 公式**: `Gas = (tempGas + (i * 64) + 34) * 100`

---

## 3. 交易验证调用链 (handleTransaction)

```mermaid
flowchart TD
    START([handleTransaction]) --> VER[Util::IsVersionCompatible]
    VER --> PARSE[ParseFromString 反序列化]
    PARSE --> TOP[DB: getBlockTop]
    TOP --> TYPE{判断交易类型}
    TYPE -->|CALL/DEPLOY| CTX[isContractTx = true]
    TYPE -->|FUND| FUND[isFund = true]
    TYPE -->|其他| NORMAL[普通交易]

    CTX --> CHK1{nodeHeight != top?}
    CHK1 -->|是| WARN1[WARNING: 高度不一致]

    FUND --> CHK2{nodeHeight != top?}
    CHK2 -->|是| WARN2[WARNING: 高度不一致]

    NORMAL --> TIMEOUT[verifyTransactionTimeoutRequest]
    CTX --> TIMEOUT
    FUND --> TIMEOUT

    TIMEOUT -->|失败| ERR1[返回 -7: 超时]

    NORMAL --> UTHEIGHT[verifyTxUtxoHeight]
    UTHEIGHT -->|失败| ERR2[返回 -6]

    UTHEIGHT --> CHKTOP{txUtxoHeight > top?}
    CHKTOP -->|是| CACHE1[failedTransactionCache::Add]

    NORMAL --> MSGVERIFY[verifyTransactionMessageRequest]
    CTX --> MSGVERIFY
    FUND --> MSGVERIFY
    MSGVERIFY -->|失败| ERR3[返回 -10000+ret]

    NORMAL --> ATTACH[AttachTxSelectionProof]
    ATTACH --> ADDSIGN[TxHelper::addVerifySign]
    ADDSIGN -->|失败| ERR4[返回 -10]

    ADDSIGN --> VRF{VRF Agent Type?}
    VRF -->|vrfAgentType_vrf| PKGVERIFY[VerifyBlockPackager<br/>或 ContractVerifier]
    PKGVERIFY -->|失败| ERR5[返回 -12/-13]

    VRF -->|其他| CACHE2[TransactionCache::AddCache]
    PKGVERIFY --> CACHE2
    CACHE2 -->|失败| ERR6[返回 -14]
    CACHE2 -->|成功| DONE[返回 0]

    style ERR1 fill:#f66
    style ERR2 fill:#f66
    style ERR3 fill:#f66
    style ERR4 fill:#f66
    style ERR5 fill:#f66
    style ERR6 fill:#f66
    style DONE fill:#6f6
```

**关键代码位置**: `transaction.cpp:1374-1559`

### 3.1 超时验证详解

**位置**: `transaction.cpp:3905-3924`

```
verifyTransactionTimeoutRequest(tx):
  expireTime = isContractTx ? (3 * KtxTimeout) : KtxTimeout
               30秒              10秒
  if tx.time + expireTime <= nowTime:     FAIL (已过期)
  if tx.time >= nowTime + expireTime:     FAIL (未来时间戳)
  return 0                                PASS
```

### 3.2 UTXO 高度验证详解

**位置**: `transaction.cpp:1244-1260`

```
verifyTxUtxoHeight(tx, txUtxoHeight):
  localHeight = get_tx_utxo_height(tx)
    ├── 遍历所有 utxo.vin.prevout
    ├── getBlockHashByTransactionHash() 查找 UTXO 所在区块
    └── getBlockHeightByBlockHash() 获取区块高度
  if txUtxoHeight != localHeight: FAIL
  return 0                           PASS
```

---

## 4. 交易写入 / UTXO 花费链

```mermaid
flowchart TD
    subgraph 区块确认时
        BLOCK[区块确认] --> SAVE[SaveTx / 写入区块]
        SAVE --> MARK[标记 vin.prevout 为已花费]
        MARK --> REMOVE1[从 UAH:addr:assetType 移除 UTXO hash]
        REMOVE1 --> DEDUCT[从 BAL:addr:assetType 扣除余额]
        DEDUCT --> CREATE[创建新 UTXO (vout)]
        CREATE --> ADD1[添加到 UAH:addr:assetType]
        ADD1 --> ADD2[增加到 BAL:addr:assetType]
    end

    subgraph 回滚时
        ROLLBACK[链重组/回滚] --> RESTORE[恢复已花费 UTXO]
        RESTORE --> READD1[重新添加到 UAH:]
        READD1 --> READD2[恢复 BAL: 余额]
        READD2 --> REMOVE_NEW[移除已确认的新 UTXO]
    end
```

**注意**: 写入逻辑在区块处理流程中（`block_helper`, `block_stroage`），不在本模块分析范围内。UTXO 花费标记由存储层通过 `DBReadWriter` 操作 RocksDB 完成。

---

## 5. 签名调用链

```mermaid
flowchart TD
    START([signTx]) --> LOOP{遍历 tx.utxos}
    LOOP --> VIN_LOOP{遍历 utxo.owner}
    VIN_LOOP --> VIN_SIGN{contractAddr 为空?}
    VIN_SIGN -->|是| VIN_HASH[Getsha256Hash vin_t.SerializeAsString]
    VIN_HASH --> VIN_SIGN2[sign(owner, vinHash)]
    VIN_SIGN2 --> VIN_SET[vinSign.set_sign / set_pub]
    VIN_SIGN -->|否, 跳过| SKIP[跳过 VIN 签名]

    VIN_LOOP -->|结束| UTXO_SIGN[UTXO 级签名]
    UTXO_SIGN --> COPY[复制 utxo, 清除 multisign]
    COPY --> UTXO_HASH[Getsha256Hash copyUtxo.SerializeAsString]
    UTXO_HASH --> UTXO_SIGN2[sign(owner, utxoHash)]
    UTXO_SIGN2 --> MULTI[add_multisign: set_sign / set_pub]

    LOOP -->|结束| TX_HASH[clear_hash / clear_signature]
    TX_HASH --> TX_HASH2[tx.set_hash Getsha256Hash tx.SerializeAsString]
    TX_HASH2 --> DONE[return true]
```

**两层签名设计**:
1. **VIN 级签名**: 对每个 `CTxInput` 的内容签名，证明对输入 UTXO 的所有权
2. **UTXO 级签名**: 对整个 `CTxUtxos`（不含 multisign）签名，防止 UTXO 级篡改

**RLP 交易特殊逻辑** (`utxo_core.cpp:166-170`):
- 如果 `isRLPTransaction == true`，使用 `addr`（交易发起者）签名而不是 `owner`
- 这是 EVM 兼容需求：RLP 编码的合约交易使用单一签名者

**关键代码位置**: `utxo_core.cpp:142-220`

---

## 6. Gas 计算调用链

```mermaid
flowchart TD
    subgraph Gas 公式
        F1[utxo.owner_size * 34] --> SUM
        F2[vin.prevout.size * 64] --> SUM2[utxoSize]
        SUM2 --> SUM
        F3[voutSize * 34] --> SUM
        F4[gasSize<br/>data+note+reserve0+reserve1] --> SUM
        SUM --> RESULT[gas *= 1<br/>gas *= 1]
    end

    subgraph 两种变体
        CG[CalculateGas<br/>transaction.cpp:3926] --> CGV[voutSize 从实际 utxo.vout_size 获取]
        GG[GenerateGas<br/>transaction.cpp:3958] --> GGV[voutSize 从外部参数传入]
        GG --> GG2[含 owner_size*34 计算]
    end
```

**Gas 公式中的因子**:
- `34` = 每笔 output 的 Protobuf 序列化大小估算值
- `64` = 每个 prevout hash 的长度（SHA256 hex = 64 字符）
- `* 1` = 当前 Gas price 为 1（注释暗示历史上有过 `* 100` 的配置）

**关键代码位置**: `transaction.cpp:3926-3999`

---

## 7. 问题清单

### 问题 12: handleTransaction 中重复调用 verifyTxUtxoHeight
- **位置**: `transaction.cpp:1427` 和 `transaction.cpp:1440`
- **现象**: 同一函数中 `verifyTxUtxoHeight` 被调用了两次（行 1427 和行 1440），第二次对同一参数调用
- **风险等级**: Low
- **触发场景**: 性能浪费
- **修复建议**: 删除第二次重复调用

### 问题 13: Gas 计算中乘以 1 无实际效果
- **位置**: `transaction.cpp:3947` `gas *= 1;`, `transaction.cpp:3978` `gas *= 1;`
- **现象**: `gas *= 1` 是无操作，但保留了历史代码痕迹
- **风险等级**: Low
- **触发场景**: 维护者误以为这是可配置的
- **修复建议**: 删除或替换为可配置的 gasPrice 参数
