# 模块3: UTXO 模型实现 - 线程与并发模型

## 1. 全局互斥锁分析

### 1.1 已声明的全局锁

定义位置: `ca/global.h:29-32`

| 锁名称 | 类型 | 用途 | 保护对象 |
|--------|------|------|---------|
| `bonusMutex` | `std::mutex` | 奖励计算 | 奖励分配计算过程 |
| `kDelegatingMutex` | `std::mutex` | 委托操作 | 委托/取消委托并发安全 |
| `BURN_MUTEX` | `std::mutex` | Gas 燃烧 | Gas 燃烧/销毁操作 |
| `LOCK_MUTEX` | `std::mutex` | 锁定/投票 | 锁定和投票操作 |

**问题**: 这四个锁是**全局静态变量**，声明在头文件 `ca/global.h` 中（非 inline, non-const），每个包含此头文件的编译单元都会产生独立的锁实例。这可能导致**不同编译单元的线程使用不同的锁对象，无法起到互斥保护作用**。

### 1.2 静态变量跨编译单元问题

```cpp
// ca/global.h:29-32
static std::mutex bonusMutex;
static std::mutex kDelegatingMutex;
static std::mutex BURN_MUTEX;
static std::mutex LOCK_MUTEX;
```

**风险**: 在 C++ 中，头文件中的 `static` 变量在每个包含该头文件的 `.cpp` 翻译单元中会产生独立实例。如果 `bonusMutex` 在 `ca/bonus.cpp` 和 `ca/transaction.cpp` 中都需要使用，它们实际上锁定的是**不同的 mutex 对象**，无法提供跨文件的互斥保护。

**现状**: 这些锁的实际使用位置需要在各 `.cpp` 文件中确认。如果所有 lock/unlock 调用都在同一个翻译单元内（例如只在 `transaction.cpp` 中），则此问题不触发。但如果分散在多个文件中，则存在安全隐患。

---

## 2. Double Spend Cache 的并发模型

### 2.1 类结构

**文件**: `ca/double_spend_cache.h` (行 17-67)

```cpp
class doubleSpendCache {
private:
    CTimer _timer;                                           // 定时器(1秒)
    std::mutex doubleSpendMutex;                             // 双花检测互斥锁
    std::map<std::string, doubleSpendSuccess> _pending;       // 待处理双花记录
};
```

### 2.2 并发访问分析

```mermaid
flowchart TD
    subgraph 主线程
        ADD[AddFromAddr<br/>添加待检测交易]
        DETECT[Detection<br/>检测区块中的双花]
        REMOVE[Remove<br/>移除超时记录]
    end

    subgraph 定时器线程 (1秒间隔)
        CHECK[CheckLoop<br/>清理超时记录]
    end

    ADD -->|lock| MUTEX1[doubleSpendMutex]
    DETECT -->|lock| MUTEX2[doubleSpendMutex]
    REMOVE -->|lock| MUTEX3[doubleSpendMutex]
    CHECK -->|lock| MUTEX4[doubleSpendMutex]
```

**分析**:
- `doubleSpendMutex` 是实例成员变量（非全局），不会出现跨编译单元问题
- 定时器线程 `CheckLoop()` 每 1 秒执行一次，与主线程的 `AddFromAddr` / `Detection` / `Remove` 正确互斥
- `_pending` map 的访问均在锁保护下，线程安全

### 2.3 双花检测机制

```
AddFromAddr(using_pair):
  记录待检测的 (addr + assetType) -> utxoVector 映射

Detection(block):
  遍历区块内所有交易的 prevout
  与 _pending 中记录对比
  如果匹配 -> 标记为双花

CheckLoop() (1秒定时):
  遍历 _pending
  移除超时记录
```

---

## 3. 交易构造的并发安全

### 3.1 内存操作

所有 `UtxoCore` 子类的 `trans()` 方法操作的是**局部变量** `CTransaction tx`:
- 每个交易构造调用创建新的 `XxxTrans` 实例
- `tx` 是栈上的成员变量，天然线程安全
- 不同交易的构造可并行执行

```cpp
// 每个 RPC 调用创建独立的 TransforerTrans 对象
// ca/transaction/trans.h:21
class TransforerTrans : public mmc::UtxoCore {
    CTransaction tx;  // 每个实例独立的栈变量
};
```

### 3.2 数据库操作

交易构造过程中的数据库读取:

| 操作 | 并发安全 |
|------|---------|
| `DBReader::getUtxoHashsByAddress()` | RocksDB 自身 MVCC 保证读一致性 |
| `DBReader::getUtxoValueByUtxoHashes()` | RocksDB 快照读 |
| `DBReader::getBlockTop()` | RocksDB 快照读 |
| `DBReader::getNonceByAddr()` | RocksDB 读，但 nonce 没有原子递增保护 |

**关键问题**: `nonce` 字段虽然从数据库读取并设置到交易中，但在多个交易并行构造时，**没有原子递增机制**来防止 nonce 重用。

---

## 4. 交易池 (TransactionCache) 并发模型

### 4.1 TransactionCache

```
MagicSingleton<TransactionCache>::GetInstance()->AddCache(tx, msg)
```

- 使用 `MagicSingleton` 模板，推测内部有线程安全保证
- 交易缓存是一个共享数据结构，多个线程可同时添加/读取
- 具体线程安全机制需查看 `TransactionCache` 实现

### 4.2 failedTransactionCache

```
MagicSingleton<failedTransactionCache>::GetInstance()->Add(txUtxoHeight, *msg)
```

- 缓存超前高度的交易
- 同样通过 `MagicSingleton` 访问

---

## 5. 特殊并发场景分析

### 5.1 同一地址的多笔交易并发构造

```mermaid
sequenceDiagram
    participant T1 as Thread 1
    participant DB as RocksDB
    participant T2 as Thread 2

    T1->>DB: getUtxoHashsByAddress(addr, "MM")
    DB-->>T1: [utxo_A, utxo_B, utxo_C]
    T2->>DB: getUtxoHashsByAddress(addr, "MM")
    DB-->>T2: [utxo_A, utxo_B, utxo_C]

    T1->>T1: 选择 utxo_A + utxo_B
    T2->>T2: 选择 utxo_A + utxo_C

    Note over T1,T2: 两个交易都引用了 utxo_A<br/>但此时都未写入区块

    T1->>DB: 交易广播(引用 utxo_A, utxo_B)
    T2->>DB: 交易广播(引用 utxo_A, utxo_C)

    Note over DB: 区块确认时<br/>只有第一个交易成功<br/>第二个交易 double-spend 失败
```

**分析**:
- 交易构造时不检查双花（这是正常的比特币/UTXO 模型设计）
- 双花检测在**区块打包/确认时**进行
- 两个并发构造的交易可能引用相同的 UTXO，只有先确认的生效

### 5.2 区块打包期间的 UTXO 选择

区块打包器在构造区块时，需要确保选中的交易之间没有 UTXO 冲突。此逻辑在 `BlockHelper` / `block_stroage` 中实现，不在本模块范围内。

---

## 6. 并发安全总结

| 组件 | 线程安全性 | 评估 | 依据 |
|------|-----------|------|------|
| UtxoCore 子类 trans() | 安全 (栈变量隔离) | 高 | 每个调用独立实例 |
| doubleSpendCache | 安全 (mutex 保护) | 高 | `double_spend_cache.h:64` |
| RocksDB 读取 | 安全 (MVCC) | 高 | RocksDB 自身保证 |
| Nonce 管理 | **不安全** (无原子递增) | 高 | nonce 只是读取+设置，无原子 CAS |
| 全局锁 (bonusMutex等) | **可能不安全** (static 在头文件) | 高 | `global.h:29-32` |
| TransactionCache | 未知 (需查看实现) | 中 | 通过 MagicSingleton 访问 |

---

## 7. 问题清单

### 问题 17: 全局锁定义在头文件中导致跨编译单元问题
- **位置**: `ca/global.h:29-32`
- **现象**: `static std::mutex bonusMutex` 等在头文件中声明为 static，每个包含此头文件的 .cpp 文件都会生成独立实例
- **风险等级**: Critical
- **触发场景**: 如果 `bonusMutex` 在 `transaction.cpp` 和 `ca/bonus.cpp` 中都被使用（不在分析范围内），两个文件的线程将锁定不同的 mutex，无法互斥
- **修复建议**: 将 static mutex 改为 inline（C++17）或使用 Meyer's Singleton 模式: `inline std::mutex& bonusMutex() { static std::mutex m; return m; }`
- **验证方法**: 在不同 .cpp 文件中打印 `&bonusMutex` 的地址，确认它们相同

### 问题 18: Nonce 无并发保护
- **位置**: 多处 `getNonceByAddr()` + `set_nonce()` (如 `trans.cpp:256-263`)
- **现象**: Nonce 从 DB 读取 -> 设置到交易 -> 广播，之间无原子性保证
- **风险等级**: High
- **触发场景**: 同一地址并发发送多笔交易，可能获得相同的 nonce
- **修复建议**: 使用 RocksDB Merge 操作或原子 CAS 递增 nonce
- **验证方法**: 并发发送 10 笔交易，检查 nonce 唯一性

### 问题 19: 交易构造中的 TOCTOU 问题
- **位置**: `FindUtxo()` 读取 UTXO 列表到 `trans()` 构造交易之间
- **现象**: 在 `FindUtxo()` 读取可用 UTXO 列表后、交易广播前，可能有其他交易花费相同的 UTXO
- **风险等级**: Medium
- **触发场景**: 高并发环境下，同一地址的 UTXO 被竞争消费
- **修复建议**: 添加可选的 `sendConfirmUtxoHashRequest()` 确认（当前仅当 `isFindUtxo=true` 时执行）
- **验证方法**: 压力测试下检查 UTXO 双花拒绝率

### 问题 20: CheckLoop 定时器线程在构造时启动，生命周期不明
- **位置**: `double_spend_cache.h:20-23`
- **现象**: `_timer.AsyncLoop(1000, ...)` 在构造函数中启动，如果 `doubleSpendCache` 对象在程序启动时创建，定时器立即运行
- **风险等级**: Low
- **触发场景**: 程序启动早期，数据库可能未就绪
- **修复建议**: 延迟启动或在数据库就绪后才实例化 `doubleSpendCache`
- **验证方法**: 【需人工验证】启动时序检查
