# 模块3: UTXO 模型实现 - 存储模型

## 1. RocksDB 概述

MeMeChain 使用 **RocksDB** 作为底层 KV 存储引擎。所有 UTXO 相关的数据通过 `DBReader` / `DBReadWriter` 封装访问。

**精度约定**: 所有存储在 RocksDB 中的金额值使用**最小精度**（即乘以 `kDecimalNum = 10^8` 后的 uint64_t 值）。

---

## 2. Key 前缀规范

### 2.1 主要 Key 前缀

| Key 前缀 | 格式 | Value | 说明 | 可信度 |
|---------|------|-------|------|--------|
| `UB:` | `UB:{txHash}:{n}` or similar | UTXO value (string) | UTXO 余额存储 | 中 (从代码推断) |
| `UAH:` | `UAH:{address}:{assetType}` | UTXO hash 列表 | 地址-资产类型的 UTXO 索引 | 中 |
| `BAL:` | `BAL:{address}:{assetType}` | uint64_t string | 地址-资产类型余额 | 中 |

**注意**: 具体的 Key 格式需要查看 `db/db_api.h` 和相关实现。以上前缀从代码中的函数名称推断：
- `getUtxoHashsByAddress()` -- 查询某地址某资产的 UTXO hash 列表
- `getUtxoValueByUtxoHashes()` -- 查询某 UTXO hash 对应的 value
- `getBalanceByUtxo()` / `getBalance()` -- 查询余额

### 2.2 从函数签名推断的 Key-Value 映射

```cpp
// db/db_api.h (推断)
class DBReader {
public:
    // Key: 推测 UAH:{address}:{assetType} -> Value: vector<string> utxoHashes
    DBStatus getUtxoHashsByAddress(const std::string& address,
                                    const std::string& assetType,
                                    std::vector<std::string>& utxoHashes);

    // Key: 推测 UB:{utxoHash}:{address}:{assetType} -> Value: string (uint64 value)
    int getUtxoValueByUtxoHashes(const std::string& hash,
                                  const std::string& address,
                                  const std::string& assetType,
                                  std::string& balance);

    // Key: 推测 TX:{txHash} -> Value: bytes (CTransaction serialized)
    DBStatus getTransactionByHash(const std::string& txHash,
                                   std::string& txRawData);

    // Key: 推测 BH:{blockHash} -> Value: uint32 height
    DBStatus getBlockHeightByBlockHash(const std::string& blockHash,
                                        uint32_t& blockHeight);

    // Key: 推测 BHH:{txHash} -> Value: string blockHash
    DBStatus getBlockHashByTransactionHash(const std::string& txHash,
                                            std::string& blockHash);

    // Nonce 存储
    DBStatus getNonceByAddr(const std::string& addr, uint64_t& nonce);

    // 资产类型列表
    DBStatus getAssetType(std::vector<std::string>& assetTypes);

    // 质押 UTXO 按地址查询
    DBStatus getStakeUtxoByAddr(const std::string& address,
                                 const std::string& assetType,
                                 std::vector<std::string>& utxos);

    // 锁定 UTXO 按地址查询
    DBStatus getLockAddrUtxo(const std::string& address,
                              const std::string& assetType,
                              std::vector<std::string>& utxos);

    // 30天锁定数据
    DBStatus get30DayLockData(const std::string& addr,
                               const std::string& utxoHash,
                               const std::string& assetType,
                               uint64_t& time);
};
```

**可信度说明**: 以上 Key 格式为**推断**（从函数命名和调用模式推导），需要查看 `db/db_api.h` 和 `db/db_api.cpp` 实际实现确认。

---

## 3. UTXO 索引结构

### 3.1 双索引设计

```mermaid
flowchart LR
    subgraph 地址维度索引
        UAH[UAH: 地址:资产类型] --> LIST1["[utxo_hash_1, utxo_hash_2, ...]"]
    end

    subgraph UTXO 维度
        UB[UB: utxo_hash:地址:资产类型] --> VAL["uint64 value"]
    end

    subgraph 交易维度
        TX[交易 hash] --> RAW["CTransaction 序列化 bytes"]
    end

    LIST1 --> UB
    UB --> RAW
```

### 3.2 查询路径

```
查询"地址 A 的 MM 资产可用余额":
  1. getUtxoHashsByAddress(A, "MM") -> [hash1, hash2, ...]
  2. 对每个 hash: getUtxoValueByUtxoHashes(hash, A, "MM") -> value
  3. apply: 过滤锁定期 (get30DayLockData)
  4. sum(values) = 可用余额

构造交易时选择 UTXO:
  1. 同上获取 utxoHashes
  2. 按 value 降序排序
  3. 贪心/随机环形选择
  4. 将选中的 hash 填入 vin.prevout

区块确认后更新 UTXO:
  1. 对于 vin 中的每个 prevout hash:
     - 从 UAH: 中移除对应 hash
     - 从 UB: 中删除对应 value
     - 从 BAL: 中扣除 value
  2. 对于 vout 中的每个输出:
     - 创建新的 UB: Key
     - 添加到 UAH: 索引
     - 增加到 BAL: 累计余额
```

---

## 4. 余额存储设计

### 4.1 余额计算方式

余额不是直接存储的单一值，而是通过**遍历地址的所有可用 UTXO 求和**计算得出:

```cpp
// ca/transaction.h:43
int get_balance_by_utxo(const std::string & address,
                         const std::string & assetType,
                         uint64_t &balance);
```

**优点**: 余额计算完全可审计（追溯到每个 UTXO）
**缺点**: 当 UTXO 数量大时，查询性能下降

### 4.2 余额分解表示

`getUtxoValueByUtxoHashes()` 返回的 balance 字符串可能存在 `_` 分隔的多值格式:

```cpp
// ca/txhelper.cpp:147-154
if(balance.find(underline) != std::string::npos)
{
    StringUtil::SplitString(balance, "_", utxoValues);
    for(int i = 0; i < utxoValues.size(); ++i)
    {
        utxo.value += std::stol(utxoValues[i]);
    }
}
else
{
    utxo.value = std::stol(balance);
}
```

**分析**: `_` 分隔格式用于质押 UTXO，一个 UTXO 可能关联多个值（如本金 + 多个奖励分配）

### 4.3 Gas 消耗存储

Gas 消耗按周期统计存储:
```cpp
DBReader::getGasAmountByPeriod(period, assetType, gas_amount);
```

---

## 5. 特殊 UTXO 存储

### 5.1 质押 UTXO

- **索引**: `getStakeUtxoByAddr(address, assetType, utxos)` 返回质押相关 UTXO hash 列表
- **识别**: 质押交易在 `data.txinfo.StakeType == "Net"` 中标识
- **目标地址**: vout 输出到 `kTargetAddress = "VirtualStake"`
- **查询**: `getStakeAmount()` 遍历质押 UTXO，累加 vout 到 VirtualStake 的金额

### 5.2 委托 UTXO

- **目标地址**: vout 输出到 `kVirtualDelegatingAddr = "VirtualDelegating"`
- **查询**: 通过 `BonusAddrCache` 和 `GetDelegatingAmountAndDuration()` 查询

### 5.3 锁定 UTXO

- **资产类型**: 必须为 `ASSET_TYPE_VOTE = "Vote"`
- **索引**: `getLockAddrUtxo(address, "Vote", utxos)`
- **目标地址**: vout 输出到 `VIRTUAL_LOCK_ADDRESS = "LockVirtualStake"`

### 5.4 Gas 燃烧 UTXO

- **目标地址**: `VIRTUAL_BURN_GAS_ADDR = "VirtualBurnGas"`
- **合约部署燃烧**: `kVirtualDeploymentContractAddress = "VirtualDeployContractBurnGas"`
- **合约调用燃烧**: `VIRTUAL_CALL_CONTRACT_ADDR = "VirtualCallContractBurnGas"`

---

## 6. Nonce 存储

```
Key: NONCE:{address} -> Value: uint64_t
```

在每笔交易构造时:
1. `DBReader::getNonceByAddr(owner, nonce)` 读取当前 nonce
2. `tx.set_nonce(nonce)` 设置到交易
3. 区块确认后 nonce 应该递增（但此逻辑在存储层，未在本模块内）

**问题**: nonce 读取和设置之间无原子性保证（见 thread_model.md 问题 18）。

---

## 7. UTXO 锁定/过滤机制

### 7.1 30 天锁 (委托解除锁定期)

```cpp
// ca/txhelper.cpp:283-293
DBReadWriter writer;
uint64_t time = 0;
if(DBStatus::DB_SUCCESS == writer.get30DayLockData(addr, utxo.hash, assetType, time)){
    INFOLOG("is not locked utxo");
    continue;
    uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
    if ((curTime - time) < 24 * 60 * 60 * 1000000 * 1) {
        INFOLOG("locked utxo less 1day");
        continue;
    }
}
```

**逻辑分析**:
- 此代码在 `FindUtxo()` 重载 1 中，用于过滤委托解除锁定期的 UTXO
- 代码路径有**明显的死代码 bug**: `continue` 后无条件跳转，后面的检查永远不会执行
  - `continue` 之后的两行代码（288-292）**永远不会被执行**
  - 这意味着所有有 30 天锁记录的 UTXO 都会被跳过，**不论是否已过锁定期**

**注意**: 此 bug 已在分析中确认，但需要验证这是否是预期的行为（也许 30DayLockData 的设计就是如果存在记录则永久锁定？）

### 7.2 锁定期检查 (已确认的死代码)

```cpp
// 行 287: continue;  <- 直接跳回循环开头
// 行 288: uint64_t curTime = ...  <- 永远不会执行
// 行 289-292: if ((curTime - time) < ...)  <- 永远不会执行
```

---

## 8. 数据一致性

### 8.1 UTXO 与余额的一致性

系统需要通过以下规则维护一致性:
```
对于任意地址 A 和资产类型 T:
  BAL(A, T) = SUM(UB(hash, A, T) for all hash in UAH(A, T))
```

**一致性检查**: 当前代码中未见显式的余额-UTXO一致性验证函数。

### 8.2 区块回滚时的数据恢复

回滚时需要:
1. 恢复 `UB:` 中被标记为花费的 UTXO
2. 恢复 `UAH:` 中的索引
3. 恢复 `BAL:` 中的余额
4. 删除新区块创建的 UTXO

---

## 9. 问题清单

### 问题 21: FindUtxo 重载1中死代码导致锁定期逻辑失效
- **位置**: `ca/txhelper.cpp:287-292`
- **现象**: `continue` 后还有访问 `curTime` 和判断锁定期的代码，永远无法执行
- **风险等级**: Critical
- **触发场景**: 所有有 30DayLockData 记录的 UTXO 都会被无条件跳过（即使已超过锁定期），导致用户无法使用已解锁的 UTXO
- **修复建议**: 
  ```cpp
  if(DBStatus::DB_SUCCESS == writer.get30DayLockData(addr, utxo.hash, assetType, time)){
      uint64_t curTime = MagicSingleton<TimeUtil>::GetInstance()->GetUTCTimestamp();
      if ((curTime - time) < 24 * 60 * 60 * 1000000 * 1) {
          INFOLOG("locked utxo less 1day");
          continue;
      }
  }
  ```
- **验证方法**: 构造一个有 30DayLockData 但已过期的 UTXO，验证是否可被选择

### 问题 22: getUtxoValueByUtxoHashes 返回值类型不一致
- **位置**: 多个调用点 (`txhelper.cpp:138`, `txhelper.cpp:277`, `txhelper.cpp:371`)
- **现象**: 同一个函数调用在不同位置的返回值类型不一致 —— 有时作为 `int` 返回值检查，有时检查 `!= 0`
- **风险等级**: Low
- **触发场景**: 代码维护困难
- **修复建议**: 统一返回值类型和检查方式

### 问题 23: 余额存储无显式一致性验证
- **位置**: 全局
- **现象**: BAL: 值可能与 UAH: 中 UTXO value 之和不一致（如部分更新失败）
- **风险等级**: Medium
- **触发场景**: 写操作中途崩溃
- **修复建议**: 添加定期余额校验工具或使用 RocksDB WriteBatch 原子写入
- **验证方法**: 【需人工验证】断电/崩溃测试后余额验证
