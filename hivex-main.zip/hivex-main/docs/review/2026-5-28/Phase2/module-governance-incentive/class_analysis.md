# 模块8+9: 治理与激励 -- 类与结构体分析

## 1. 核心数据结构

### 1.1 ProposalInfo

**文件**: `ca/txhelper.h` L37-69, 规范 `spec_dev.md` 11.3.1 / 12.1.1

```cpp
struct ProposalInfo {
    int version;                              // 提案版本 KProposalInfoVersion=0
    uint64_t BeginTime;                       // 投票开始时间(微秒)
    uint64_t EndTime;                         // 投票结束时间(微秒)
    std::string Name;                         // 资产名称(如"nETH")
    std::string ExchangeRate;                 // 汇率 Token->Native Token
    uint32_t CrossChainTxType;                // 跨链交易类型
    std::string ContractAddr;                 // 跃入合约地址
    std::string CrossChainInvestmentContractAddr; // 跨链投资合约地址
    uint64_t canBeStake;                      // 是否可质押(0/1)
    uint64_t MIN_VOTE_NUM;                    // 最小投票数
    std::string Title;                        // 提案标题
    std::string Identifier;                   // 提案标识符
    std::string PeerChainTokenAddr;           // 对等链代币地址
};
```

**存储方式**: 序列化为JSON(Base64编码), 以 `PROPOSAL:{assetType}` 为Key存入RocksDB。

**初始化**: 所有字段默认为空/0值 (`ProposalInfo()` 构造函数 L39-54)。

**解析入口**: `ca_algorithm::GetProposalInfo` (algorithm.cpp L9513) 从DB读取Base64解码 -> JSON解析 -> 填充结构体。

### 1.2 RevokeProposalInfo

**规范定义**: `spec_dev.md` 11.3.4

```cpp
RevokeProposalInfo {
    version: U8                      // KRevokeProposalInfoVersion = 0
    proposalHash: string             // 原提案交易哈希
    beginTime: U64                   // 投票开始时间
    endTime: U64                     // 投票结束时间
    minVote: U64                     // 最小投票数
}
```

**实现状态**: 撤销提案信息在代码中通过 `getRevokeProposalInfoByAssetType` 直接读取JSON, 未定义独立结构体, 字段从JSON中动态解析 (`CheckVoteTxInfo` L9450-9471)。

### 1.3 VoteInfo

**文件**: `ca/txhelper.h` L71-84

```cpp
struct VoteInfo {
    uint32_t TxType;                // PROPOSAL或REVOKEPROPOSAL
    uint64_t BeginTime;             // 投票开始时间
    uint64_t EndTime;               // 投票结束时间
    std::string AssetName;          // 资产名称
    std::string ExchangeRate;       // 汇率
    uint32_t CrossChainTxType;      // 跨链交易类型
    std::string ContractAddr;       // 合约地址
    std::string CrossChainInvestmentContractAddr; // 跨链投资合约
    std::string ProposalHash;       // 原始提案哈希
    std::string PeerChainTokenAddr; // 对等链代币地址
    uint64_t MIN_VOTE_NUM;          // 最小投票数
};
```

**用途**: 前端查询可投票资产列表时使用, 由 `GetVoteAssetType` 填充。

## 2. 治理类分析

### 2.1 LockTrans

**文件**: `ca/transaction/lock.h`, `ca/transaction/lock.cpp`

**继承**: `mmc::UtxoCore`

**参数结构** (`LockTransParam`):
| 字段 | 类型 | 说明 |
|------|------|------|
| lock_addr | CowString | 锁定地址 |
| lock_amount | uint64_t | 锁定金额(最小精度) |
| lock_type | TxHelper::LockType | 锁定类型(仅kLock_Node=0有效) |
| gas | OtherToPayGas | Gas支付信息 |
| is_gas_tray | bool | 是否使用Gas托盘 |
| is_find_utxo | bool | 是否查找UTXO |

**核心处理逻辑** (lock.cpp trans()):

```
1. 获取当前高度 top (L14-19)
2. 参数校验:
   - 地址有效性: isValidAddress (L32)
   - 锁定金额: >= LOCK_AMOUNT * kDecimalNum = 100,000,000 (L37)
   - 锁定类型: 仅kLock_Node有效 (L44-48)
   - 重复锁定检查: getLockAddrUtxo 已存在则拒绝 (L56-61)
3. UTXO构造:
   - 从用户地址创建TransferFrom, asset_type=Vote (L63-73)
   - vout[0]: VIRTUAL_LOCK_ADDRESS ("LockVirtualStake") 接收锁定金额 (L112-113)
   - vout[1]: 找零回原地址 (L116-118)
   - vout[2]: VIRTUAL_BURN_GAS_ADDR Gas燃烧 (L122-130)
4. 交易签名与身份获取 (L149-159)
```

**关键检查**: 重复锁定检查 (`lock.cpp` L56-61):
```cpp
auto dbret = dbReader.getLockAddrUtxo(s_lock_param.lock_addr.str(),
                                        global::ca::ASSET_TYPE_VOTE,
                                        stake_unspent_outputs);
if(dbret != DBStatus::DB_NOT_FOUND) { // 已有锁定记录 -> 拒绝
    return PERROR(MEM::UNKNOWN_LOCK_TYPE, "There has been a lock transaction before");
}
```
【需人工验证】此检查仅判断是否存在锁定UTXO记录, 未考虑解锁后再锁定的场景(解锁后UTXO应被清理, 但需确认UTXO清理是否同步清理LOCK_ADDR索引)。

### 2.2 UnlockTrans

**文件**: `ca/transaction/unlock.h`, `ca/transaction/unlock.cpp`

**核心处理逻辑** (unlock.cpp trans()):

```
1. 获取当前高度 (L13-19)
2. 参数校验:
   - 地址有效性 (L32)
   - 解锁资格: IsQualifiedToUnLock(addr, utxo_hash, lock_amount, Vote) (L40)
3. UTXO构造:
   - vin: 引用锁定UTXO (L51-61)
   - TransferFrom: 获取可用Vote余额 (L63-73)
   - vout[0]: 释放锁定金额回原地址 (L111-113)
   - vout[1]: 找零 (L115-117)
   - vout[2]: Gas燃烧 (L127-130)
4. 交易签名 (L143-163)
```

**解锁资格校验** (`IsQualifiedToUnLock`): 需检查该地址是否有未解锁的锁定UTXO, 且传入的utxo_hash属于该地址。函数定义在UTXO核心逻辑中【需人工验证具体位置】。

### 2.3 VoteTrans

**文件**: `ca/transaction/vote.h`, `ca/transaction/vote.cpp`

**参数结构** (`VoteTransParam`):
| 字段 | 类型 | 说明 |
|------|------|------|
| addr | CowString | 投票地址 |
| gas | UtxoGasParam | Gas参数 |
| is_gas_tray | bool | Gas托盘模式 |
| vote_hash | CowString | 投票目标(提案hash或撤销提案hash) |
| is_find_utxo | bool | 是否查找UTXO |
| vote_type | int | 0=反对(Against), 1=赞成(Approve) |
| tx_type | TxType | PROPOSAL或REVOKEPROPOSAL |

**核心处理逻辑** (vote.cpp trans()):

```
1. 获取高度 (L15-20)
2. 地址有效性检查 (L22-25)
3. Gas地址检查 (L27-33)
4. 获取锁定量(投票权重):
   - 若仅有一种资产且为创始账号: lockValue=1 (L45-48)
   - 否则: GetLockValue(addr, lockValue) (L51)
5. 投票信息校验:
   - CheckVoteTxInfo(voteHash, txType, voteType, currentTime) (L60)
     - 检查vote_type是否合法 (0或1)
     - 检查投票时间窗口 (currentTime在[beginTime, endTime)内)
     - 检查资产类型是否有效
6. Gas UTXO创建 (L81-98)
7. 交易签名 (L103-131)
```

**投票数据** (makeTxData L233-245):
```json
{
  "VoteHash": "提案哈希",
  "VoteTxType": 11或12,
  "VoteType": 0或1,
  "VoteNumber": "锁定量(投票权重)"
}
```

## 3. 激励类分析

### 3.1 BonusTrans

**文件**: `ca/transaction/bonus.h`, `ca/transaction/bonus.cpp`

**核心处理逻辑** (bonus.cpp trans()):

```
1. Gas资格检查 (L27-36)
2. 参数校验 (L43-63)
3. 领取资格检查: evaluateBonusEligibility(addr, currentTime) (L70)
4. 奖励计算: CalcBonusValue(currentTime, addr, delegator_reward_allocations) (L76)
   - 获取年化率 (GetNewAnnualizedRate)
   - 获取异常节点列表 (fetchAbnormalSignAddrListByPeriod)
   - 按dividendRate调节奖励
5. 佣金计算 (L119-124):
   - GetCommissionPercentage(addr, temp_commission_rate)
6. 委托者奖励分配 (L142-163):
   - operator_commission = delegator.second * temp_commission_rate + 0.5
   - award = delegator.second - operator_commission
   - 为每个委托者创建vout输出
7. 节点佣金输出 (L169-179):
   - first_choose模式: 仅输出operator_commission
   - 否则: total - expend + total_operator_commission
8. 交易签名 (L239-261)
```

**佣金截断风险** (bonus.cpp L144, L152):
```cpp
operator_commission = delegator.second * temp_commission_rate + 0.5; // 四舍五入?
```
`+0.5`意图实现四舍五入, 但由于`uint64_t`强制转换行为是截断, 实际上`3.6 + 0.5 = 4.1 -> 4`正确, `3.4 + 0.5 = 3.9 -> 3`正确。但`temp_commission_rate`为double, `delegator.second`为uint64_t, 乘法结果在double->uint64_t转换时可能出现精度问题。建议使用`std::round()`显式处理。

### 3.2 FundTrans

**文件**: `ca/transaction/fund.h`, `ca/transaction/fund.cpp`

**核心处理逻辑** (fund.cpp trans()):

```
1. 参数校验 (L27-31)
2. 获取可用资产类型 (L33): fetchAvailableAssetType(asset_map)
3. 获取各资产Gas收入 (L49-61):
   - getGasAmountByPeriod(period-1, assetType, gas_amount)
4. 国库领取资格 (L75): CheckFundQualificationAndGetRewardAmount
5. 锁定奖励计算 (L88-98):
   - is_locked = (return_value > 0 && total_locked_amount > 0)
6. 打包奖励计算 (L108-123):
   - 检查节点是否有质押资格 (VerifyBonusAddr)
   - getPackagerCountByPeriod / getBlockNumberByPeriod
   - is_packaged = (times > 0 && count > 0)
7. 奖励分配 (L278-304) createUtxoFundTransfer:
   - 锁定部分: rate = return_value / total_locked_amount, value = rate * amount * 0.5
   - 打包部分: rate = times / count, value = rate * amount * 0.5
8. 交易签名 (L176-199)
```

**关键风险点** (fund.cpp L105-106, L286, L297):

```cpp
// L105: 除零风险
double rate = double(return_value) / double(total_locked_amount);
// L286: 同上
double rate = double(return_value) / double(total_locked_amount);
// L297: 同上
double rate = double(times) / double(count);
```
当`total_locked_amount == 0`或`count == 0`时发生除零。虽然后续有`if (return_value != 0 && total_locked_amount != 0)`保护(L96), 但`createUtxoFundTransfer`中(L286,L297)没有再做保护, 依赖`is_locked`和`is_packaged`标志。如果标志在两次调用间被篡改, 存在竞态风险。

### 3.3 EIP1559FeeCalculator

**文件**: `ca/fee_calculator.h`

**算法** (calculateNewFee L12):

```
adjustment_factor = (actual_gas - target_gas) / (target_gas * 8.0)
new_fee_exact = old_fee * (1.0 + adjustment_factor)

if actual_gas > target_gas: new_fee = ceil(new_fee_exact)   // 拥堵时向上取整
if actual_gas < target_gas: new_fee = floor(new_fee_exact)  // 空闲时向下取整
if actual_gas == target_gas: new_fee = new_fee_exact        // 平衡时不变

new_fee = max(new_fee, 0.0)  // 确保非负
```

**参数** (global.h L65):
- `KTargetGasPrice = 60000` (目标Gas价格)
- 初始 baseFee = 10
- 最大Gas限制 = KTargetGasPrice * 2 = 120,000

**边界条件处理** (spec_dev.md 11.5.3):
- old_fee < 0: 抛出异常
- actual_gas < 0: 抛出异常
- target_gas <= 0: 抛出异常
- 最终结果: max(new_fee, 0.0) 确保非负

### 3.4 BonusAddrCache

**文件**: `ca/bonus_addr_cache.h`, `ca/bonus_addr_cache.cpp`

**数据结构**:
```cpp
struct BonusAddrInfo {
    bool dirty{true};              // 脏标记, 需重新加载
    uint64_t amount;               // 委托金额
    std::set<std::string> utxos;   // 委托UTXO集合
    uint64_t time;                 // 首次达标时间
};

class BonusAddrCache {
    mutable std::shared_mutex bonus_addr_mutex_;  // 读写锁
    std::map<std::string, BonusAddrInfo> bonus_addr_map_;
};
```

**缓存逻辑** (bonus_addr_cache.cpp):

1. `getAmount(addr, amount)`:
   - 获取unique_lock写锁 (L14)
   - 若not dirty, 直接返回缓存值 (L15-21)
   - 若dirty或amount < kMinDelegatingAmt, 重新从DB加载:
     - 查询委托者列表 (L35)
     - 遍历委托者, 查询UTXO和交易 (L49-92)
     - 累加委托金额 (L81)
     - 首次达到kMinDelegatingAmt时记录时间 (L86-89)
     - 设置dirty=false (L93)
   - 返回amount

2. `getTime(addr)`: 获取shared_lock读锁, 返回缓存时间。

3. `isDirty(addr, dirty=true)`: 获取unique_lock写锁, 设置脏标记。

**线程安全**: 使用`std::shared_mutex`, 读操作用`shared_lock`, 写操作用`unique_lock`, 设计合理。

## 4. 年化率计算器

### 4.1 GetNewAnnualizedRate

**文件**: `ca/algorithm.cpp` L7985-8060

**流程图**:
```
输入: curTime(微秒), stakingRate(百分比)
  |
  v
1. 计算项目运行周数
   projectStartTime = 创世时间(微秒)
   若 < 10^12 则 *10^6 (秒转微秒兼容)  [临时兼容]
   timeDiff = curTime - projectStartTime
   weekInMicroseconds = 7*24*3600*10^6
   weeksSinceStart = timeDiff / weekInMicroseconds
   若 >= 520 则 = 519
  |
  v
2. mapStakingRateToK(stakingRate)
   k = 1.0 + (stakingRate - 10.0) * 19.0 / 90.0
  |
  v
3. calculateInflationRates(k, 520, 5.0, 0.5)
   每周: x=(w-1)/519, rate=0.5+(5.0-0.5)*exp(-k*x)
  |
  v
4. calculateAnnualizedRates(inflationRates, stakingRate)
   每周: annualizedRate = inflationRate / (stakingRate/100)
  |
  v
5. annualizedRate = annualizedRates[weeksSinceStart]
   返回百分比形式的年化率
```

### 4.2 mapStakingRateToK

**文件**: `ca/algorithm.cpp` L7903-7921

线性映射: 质押率10%-100% -> k值1.0-20.0

```cpp
k = 1.0 + (stakingRate - 10.0) * (20.0 - 1.0) / (100.0 - 10.0);
```

- 质押率越低 -> k越小 -> 通胀衰减越慢 -> 年化率越高 (激励质押)
- 质押率越高 -> k越大 -> 通胀衰减越快 -> 年化率越低 (抑制过度通胀)

### 4.3 calculateInflationRates

**文件**: `ca/algorithm.cpp` L7923-7945

指数衰减模型: `rate = endRate + (startRate - endRate) * exp(-k * x)`

- x = (w-1)/(totalWeeks-1), 归一化到[0,1]
- w=1时: x=0, rate = 0.5 + 4.5*1 = 5.0%
- w=520时: x=1, rate = 0.5 + 4.5*exp(-k) -> 趋近0.5%

### 4.4 calculateAnnualizedRates

**文件**: `ca/algorithm.cpp` L7947-7983

```cpp
stakingRatio = stakingRate / 100.0;
annualizedRate = inflationRate / stakingRatio;
```

质押率反比关系: 质押越少, 年化率越高。

### 4.5 浮点精度分析

| 风险点 | 位置 | 详情 | 可信度 |
|--------|------|------|--------|
| double截断 | L7970 | `inflationRate[i] / stakingRatio` 结果为double, 精度约15位有效数字 | 低风险 |
| uint64乘法 | L7849 | `annualizedRate * it.second.first / 365` - double*uint64可能溢出double表示范围 | 中风险 |
| exp(-k*x) | L7933 | k范围[1,20], x范围[0,1], exp(-20)=2.06e-9, 在double范围内 | 低风险 |
| 精度常量 | global.h L135 | `boost::multiprecision::cpp_bin_float_100 KLowestExchangeRate("1e-8")` 仅用于汇率比较 | 低风险 |
| 佣金截断 | bonus.cpp L144 | double*uint64->uint64 截断 | 中风险 |

## 5. 可信度评估

| 分析模块 | 可信度 | 依据 |
|---------|--------|------|
| Lock/Unlock/Vote处理逻辑 | 高 | 完整源码分析 |
| Bonus/Fund处理逻辑 | 高 | 完整源码分析 |
| 年化率计算 | 高 | 完整源码分析 + spec对照 |
| EIP1559FeeCalculator | 高 | 完整源码分析 + spec对照 |
| PROPOSAL创建逻辑 | 低 | contract.cpp被#if 0包裹, 无法分析实际执行路径 |
| 国库分配细节 | 中 | 部分逻辑委托给UTXO核心函数, 未追踪到底层 |
| Gas计算(GenerateGas) | 中 | 函数签名可见, 实现在transaction.h/cpp中, 未完全追踪 |
