# 模块8+9: 治理与激励 -- 重构建议

## 1. 治理与激励逻辑从algorithm.cpp中分离

### 1.1 现状

`ca/algorithm.cpp` 是一个超大文件（约382KB），包含了从区块验证、交易验证、VRF共识、质押、委托到治理投票、年化率计算的所有算法逻辑。治理和激励相关函数散布在文件中：

| 函数 | 行号范围 | 类别 |
|------|---------|------|
| `fetchAbnormalSignAddrListByPeriod` | L66-106 | 激励 |
| `CalcBonusValue` | L7743-7901 | 激励 |
| `mapStakingRateToK` | L7903-7921 | 激励 |
| `calculateInflationRates` | L7923-7945 | 激励 |
| `calculateAnnualizedRates` | L7947-7983 | 激励 |
| `GetNewAnnualizedRate` | L7985-8060 | 激励 |
| `GetNetworkStakingRate` | L8062-8111 | 激励 |
| `GetVoteNum` | L9162-9176 | 治理 |
| `CheckForDuplicateVotes` | L9179-9224 | 治理 |
| `addVoteCount` | L9228-9310 | 治理 |
| `subVoteNum` | L9313-9361+ | 治理 |
| `CheckVoteTxInfo` | L9422-9486 | 治理 |
| `GetProposalInfo` | L9513-9546 | 治理 |
| `AssetTypeListIsEmpty` | L9548-9569 | 治理 |
| `GetLockValue` | L9572-9624 | 治理 |
| `GetCanBeRevokeAssetType` | L9627-9653 | 治理 |
| `GetAnnualizedRate` (旧) | L9728-9748 | 激励(已废弃) |

### 1.2 建议方案

**分离为三个文件**:

```
ca/
├── algorithm.cpp          (保留: 区块/交易验证, VRF共识, 通用工具)
├── governance.cpp/.h      (新建: 投票, 提案, 锁定)
└── incentive.cpp/.h       (新建: 年化率, 奖励, Gas费用)
```

**governance.cpp** 应包含:
- `GetVoteNum`, `CheckForDuplicateVotes`, `addVoteCount`, `subVoteNum`
- `CheckVoteTxInfo`, `GetProposalInfo`, `GetVoteAssetType`
- `GetLockValue`, `AssetTypeListIsEmpty`, `GetCanBeRevokeAssetType`
- `CheckProposaInfo`, `GetAssetTypeIsValid`, `canBeRevoked`

**incentive.cpp** 应包含:
- `CalcBonusValue`, `fetchAbnormalSignAddrListByPeriod`
- `GetNewAnnualizedRate`, `GetNetworkStakingRate`
- `mapStakingRateToK`, `calculateInflationRates`, `calculateAnnualizedRates`
- `GetCommissionPercentage`, `fetchBonusAddressInfo`

**预估工时**: 3-4人天（含迁移、编译验证、回归测试）

## 2. 年化率计算的可测试性改进

### 2.1 现状问题

1. **计算与DB耦合**: `GetNewAnnualizedRate` 虽不直接操作DB, 但上游 `GetNetworkStakingRate` 和 `CalcBonusValue` 深耦合RocksDB。
2. **时间依赖**: `GetNewAnnualizedRate` 依赖 `MagicSingleton<Genesis>::GetInstance()->GetGenesisTime()`, 无法在单元测试中注入时间。
3. **520周数据每次全量计算**: 即使只需要当前周的数据, 也计算全部520周。

### 2.2 建议方案

**1) 分离纯计算函数与数据获取函数**

```cpp
// 纯计算, 可单元测试
namespace incentive {
    double computeInflationRate(double k, double normalizedTime, 
                                 double startRate, double endRate);
    
    double computeAnnualizedRate(double inflationRate, double stakingRatio);
    
    double computeKFromStakingRate(double stakingRate);
    
    uint64_t computeWeeksSinceStart(uint64_t currentTime, uint64_t genesisTime);
}

// 数据获取, 依赖DB
namespace incentive {
    double getNetworkStakingRate(DBReader& db, uint64_t currentTime);
    
    double getCurrentAnnualizedRate(DBReader& db, uint64_t currentTime);
}
```

**2) 缓存通货膨胀率序列**

```cpp
class InflationRateCache {
    struct CacheKey {
        double k;
        double startRate;
        double endRate;
        int totalWeeks;
    };
    std::map<CacheKey, std::vector<double>> cache_;
    std::shared_mutex mutex_;
    
    const std::vector<double>& getOrCompute(CacheKey key);
};
```

由于k值随质押率变化, 可缓存多个k值对应的通胀率序列。质押率按区间分组(如每5%一个桶), 预计算并缓存。

**3) 时间注入**

```cpp
class TimeProvider {
public:
    virtual uint64_t getCurrentTime() = 0;
    virtual uint64_t getGenesisTime() = 0;
};

// 生产环境
class SystemTimeProvider : public TimeProvider { ... };

// 测试环境
class MockTimeProvider : public TimeProvider { ... };
```

**预估工时**: 2-3人天（含单元测试编写）

## 3. 浮点精度风险处理

### 3.1 风险点

| # | 位置 | 问题 |
|---|------|------|
| 1 | `bonus.cpp` L144 | `operator_commission = delegator.second * temp_commission_rate + 0.5` -- double*uint64_t -> uint64_t 截断 |
| 2 | `bonus.cpp` L152 | 同上 |
| 3 | `bonus.cpp` L321 | 同上, makeTxInfor中重复计算 |
| 4 | `fund.cpp` L289 | `uint64_t value = uint64_t(rate * asset_type.second * 0.5)` |
| 5 | `fund.cpp` L299 | 同上 |
| 6 | `algorithm.cpp` L7849 | `annualizedRate * it.second.first / 365` -- double*uint64_t/double |
| 7 | `algorithm.cpp` L7886 | 同上, 含dividendRate系数 |
| 8 | `algorithm.cpp` L9615 | `lockValue = std::trunc(lockValue / kDecimalNum)` -- 截断 |

### 3.2 建议方案

**1) 统一使用高精度乘法和明确取整**

```cpp
// 替代: operator_commission = delegator.second * temp_commission_rate + 0.5;
// 使用:
uint64_t operator_commission = static_cast<uint64_t>(
    std::round(static_cast<double>(delegator.second) * temp_commission_rate)
);
```

**2) 使用定点数代替浮点数(长期方案)**

对于佣金计算等高频金融操作, 考虑使用整数定点数:

```cpp
// 佣金率以基点表示: 5% = 500, 35% = 3500
uint32_t commission_rate_bps; // basis points

// 佣金计算: (amount * rate_bps) / 10000
uint64_t operator_commission = (delegator.second * commission_rate_bps) / 10000;
```

**3) 年化率使用scaled整数**

年化率从百分比转换为scaled整数:
```cpp
// annualizedRate = 7.5% -> 750 (scaled by 100)
uint64_t annual_rate_scaled = static_cast<uint64_t>(
    std::round(annualizedRate * 100.0)
);

// 日奖励: amount * rate_scaled / (365 * 100)
uint64_t daily_reward = (delegated_amount * annual_rate_scaled) / 36500;
```

**预估工时**: 2-3人天（含回归测试, 精度验证）

## 4. Gas计算的边界条件处理

### 4.1 当前状态

`EIP1559FeeCalculator::calculateNewFee` (fee_calculator.h L12) 处理了大部分边界:

```cpp
if (old_fee < 0) throw std::invalid_argument(...);
if (actual_gas < 0) throw std::invalid_argument(...);
if (target_gas <= 0) throw std::invalid_argument(...);
return std::max(new_fee, 0.0);
```

### 4.2 待处理边界

| 边界条件 | 当前处理 | 建议 |
|---------|---------|------|
| `new_fee_exact` 为NaN | 未处理 | `adjustment_factor`中除零或 old_fee为NaN时产生, 添加`std::isnan`检查 |
| `new_fee_exact` 极大值 | 未限制 | 添加upper bound (如 KTargetGasPrice * 2 = 120000) |
| `old_fee * (1 + adjustment)` 下溢 | `std::max(new_fee, 0.0)`已处理 | 已充分 |
| round参数 | rounds=0时立即返回 | 当前for循环i=0时推入initial_fee, 合理 |

**建议**:

```cpp
static double calculateNewFee(double old_fee, double actual_gas, double target_gas) {
    if (old_fee < 0 || std::isnan(old_fee)) throw ...;
    if (actual_gas < 0 || std::isnan(actual_gas)) throw ...;
    if (target_gas <= 0 || std::isnan(target_gas)) throw ...;
    
    double adjustment = (actual_gas - target_gas) / (target_gas * 8.0);
    double new_fee_exact = old_fee * (1.0 + adjustment);
    
    if (std::isnan(new_fee_exact)) {
        return old_fee; // 保守: 保持不变
    }
    
    double new_fee;
    if (actual_gas > target_gas) new_fee = std::ceil(new_fee_exact);
    else if (actual_gas < target_gas) new_fee = std::floor(new_fee_exact);
    else new_fee = new_fee_exact;
    
    // 限制在[0, KTargetGasPrice * 2]
    return std::clamp(new_fee, 0.0, static_cast<double>(KTargetGasPrice * 2));
}
```

**预估工时**: 0.5人天

## 5. 投票去重的正确性改进

### 5.1 问题

如 `call_chain.md` 分析, `CheckVoteTxInfo`(时间窗口)在 `trans()` 阶段, `addVoteCount`(去重)在合约执行阶段, 存在TOCTOU窗口。

### 5.2 建议

在 `addVoteCount` 内部增加时间窗口二次校验:

```cpp
int ca_algorithm::addVoteCount(DBReadWriter& db, const std::string &assetType, 
                                const int voteType, const std::string& addr, 
                                const uint64_t& voteNumber, uint64_t currentTime)
{
    // 现有去重检查...
    
    // 新增: 时间窗口二次校验
    uint64_t beginTime, endTime;
    // 获取提案或撤销提案的时间窗口
    // 若 currentTime >= endTime, 拒绝: 投票已结束
    
    // 现有计数逻辑...
}
```

**预估工时**: 1人天

## 6. 建议的代码清理

### 6.1 移除已废弃代码

| 代码 | 文件:行号 | 原因 |
|------|----------|------|
| `GetAnnualizedRate` (旧版) | algorithm.cpp L9728-9748 | 被`GetNewAnnualizedRate`替代 |
| contract.cpp 全文件 | transaction/contract.cpp | 被`#if 0`包裹 |
| contract.h 全文件 | transaction/contract.h | 被`#if 0`包裹 |
| fund.cpp L151-169 注释块 | transaction/fund.cpp | 旧逻辑, 已迁移到createUtxoFundTransfer |

### 6.2 移除调试代码

| 代码 | 文件:行号 | 原因 |
|------|----------|------|
| `std::cout << ...` 多处 | lock.cpp L39, L59, L158 | 生产环境不应有cout输出 |
| `usleep(1)` 多处 | algorithm.cpp L7759, L7769, etc | 调试用sleep |
| `std::ofstream outFile("example.txt")` | algorithm.cpp L7749 | 调试文件写入 |
| 循环内DEBUGLOG | algorithm.cpp L7975-7978 | 520周×每次日志 = 大量输出 |

## 7. 错误码规范化

当前治理/激励函数使用"裸整数"返回错误, 难以追踪:

```cpp
return -1;  // GetNewAnnualizedRate 中catch异常
return -2;  // GetNetworkStakingRate 中异常
return -3;  // vote.cpp 中GetLockValue失败
return -4;  // algorithm.cpp 中质押率失败
return -5;  // algorithm.cpp 中节点无资格
```

建议使用统一的错误枚举:

```cpp
enum class IncentiveError {
    SUCCESS = 0,
    NO_SIGNATURES_FOUND = -1,
    STAKING_RATE_FAILED = -2,
    ANNUALIZED_RATE_FAILED = -3,
    NODE_NOT_QUALIFIED = -4,
    NO_DELEGATORS = -5,
    // ...
};
```

**预估工时**: 1人天

## 8. 工时汇总

| 重构项 | 预估工时 | 优先级 | 风险 |
|--------|---------|--------|------|
| algorithm.cpp分离 (governance/incentive) | 3-4人天 | 中 | 低 |
| 年化率可测试性改进 | 2-3人天 | 高 | 中 |
| 浮点精度修复 | 2-3人天 | 高 | 中 |
| Gas边界条件处理 | 0.5人天 | 中 | 低 |
| 投票去重TOCTOU修复 | 1人天 | 高 | 低 |
| 代码清理(废弃+调试) | 0.5人天 | 低 | 低 |
| 错误码规范化 | 1人天 | 低 | 低 |
| **总计** | **10-13人天** | - | - |

## 9. 推荐实施顺序

```
第一阶段 (高优先级, 4-5人天):
  1. 浮点精度修复 (bonus.cpp, fund.cpp, algorithm.cpp)
  2. 投票去重TOCTOU修复
  3. 年化率可测试性改进

第二阶段 (中优先级, 3.5-4.5人天):
  4. Gas边界条件处理
  5. algorithm.cpp分离

第三阶段 (低优先级, 1.5-2人天):
  6. 代码清理
  7. 错误码规范化
```

## 10. 风险评估

| 风险 | 影响 | 缓解措施 |
|------|------|---------|
| 精度修复引入计算分歧 | 已产出的区块数据与新节点计算结果不一致 | 在TestNet上充分验证, 保留旧计算路径为fallback |
| algorithm.cpp分离引入编译错误 | 大范围头文件依赖变更 | 渐进式分离, 先提取纯函数, 再处理依赖DB的函数 |
| 年化率缓存与实际质押率偏差 | 缓存过期导致年化率不准 | 设置合理的缓存失效策略(质押率变化>1%时刷新) |
| 投票去重TOCTOU修复影响性能 | 增加DB查询可能影响投票吞吐 | 仅在投票期结束前N秒启用二次校验 |
