# 模块8+9: 治理与激励 -- 调用链分析

## 1. 提案流程

```mermaid
sequenceDiagram
    participant Creator as 创始账号
    participant RPC as RPC层
    participant Contract as contract.cpp(#if 0)
    participant DB as RocksDB
    participant Voter as 投票者
    participant Timer as 定时器

    Note over Creator,Timer: === 提案创建阶段 ===
    Creator->>RPC: CreateProposalTransaction
    RPC->>Contract: ContractBase::trans()
    Note over Contract: 【PROPOSAL交易创建逻辑被#if 0包裹】
    Note over Contract: 需人工验证实际执行路径

    Contract->>DB: setProposalInfoByAssetType(assetType, ProposalInfo)
    Contract->>DB: 存储提案信息 BeginTime/EndTime/MIN_VOTE_NUM等

    Note over Creator,Timer: === 投票期 (10分钟 KVoteCycle) ===
    Timer-->>Timer: KVoteCycle = 10*60*1000000 μs

    Voter->>RPC: CreateVoteTransaction (先锁定LOCK)
    Note over Voter: 锁定Vote获得投票权
```

```mermaid
flowchart TD
    A[锁定LOCK] --> B[获得投票权]
    B --> C[CreateVoteTransaction]
    C --> D{CheckVoteTxInfo}
    D -->|时间窗口无效| E[拒绝: vote finished]
    D -->|时间窗口有效| F{CheckForDuplicateVotes}
    F -->|已投过| G[拒绝: Duplicate Votes]
    F -->|未投过| H[addVoteCount]
    H --> I[赞成票+N 或 反对票+N]
    I --> J[等待投票期结束 EndTime]
    J --> K{赞成 > 反对?}
    K -->|是| L[提案通过: Token可跃入]
    K -->|否| M[提案否决: Token仅合约层流转]
```

### 提案流程关键步骤 (代码追踪)

**步骤1: 提案发起** (规范定义但实现被 #if 0 包裹)
- 规范: `spec_dev.md` 11.3.1, 仅创始账号可发起
- 代码: `ca/transaction/contract.cpp/h` 全文件被 `#if 0` 包裹
- 存储: 提案信息以Base64编码JSON存入 `PROPOSAL:{assetType}` 前缀
- **【需人工验证】实际提案创建路径**

**步骤2: 投票资格获取** (Lock)
- `lock.cpp` trans() L11-163
- 锁定 `LOCK_AMOUNT * kDecimalNum = 100,000,000` 最小精度的Vote
- Vote转入 `VIRTUAL_LOCK_ADDRESS` ("LockVirtualStake")

**步骤3: 投票** (Vote)
- `vote.cpp` trans() L13-132
- `GetLockValue(addr, lockValue)` (algorithm.cpp L9572): 遍历锁定UTXO, 累加vout到VIRTUAL_LOCK_ADDRESS的金额, 除以kDecimalNum得到票数
- `CheckVoteTxInfo` (algorithm.cpp L9422): 验证投票时间窗口和资产有效性
- `addVoteCount` (algorithm.cpp L9228): 去重 + 累加票数 + 写入DB

**步骤4: 投票到期判定** (定时器触发)
- `KVoteCycle = 10*60*1000000 μs` (10分钟) (global.h L132)
- 投票到期时系统统计赞成/反对票数, 判定提案结果

## 2. 投票流程 (详细)

```mermaid
flowchart TD
    subgraph 投票前置
        A1[用户持有Vote币] --> A2[CreateLock]
        A2 --> A3{锁定金额 >= 100,000,000?}
        A3 -->|否| A4[拒绝: LESS_THAN_MIN_LOCK_AMOUNT]
        A3 -->|是| A5{已有锁定记录?}
        A5 -->|是| A6[拒绝: 重复锁定]
        A5 -->|否| A7[Vote转入LockVirtualStake]
        A7 --> A8[锁定成功: 获得投票权]
    end

    subgraph 投票执行
        B1[CreateVote] --> B2{地址有效?}
        B2 -->|否| B3[拒绝]
        B2 -->|是| B4[获取锁定量 GetLockValue]
        B4 --> B5{创始账号?}
        B5 -->|是| B6[lockValue=1]
        B5 -->|否| B7[lockValue=锁定Vote量/kDecimalNum]
        B6 --> B8[CheckVoteTxInfo]
        B7 --> B8
        B8 --> B9{投票类型合法? 0或1}
        B9 -->|否| B10[拒绝]
        B9 -->|是| B11{提案/撤销提案存在?}
        B11 -->|否| B12[拒绝]
        B11 -->|是| B13{currentTime在[beginTime, endTime)?}
        B13 -->|否| B14[拒绝: vote finished]
        B13 -->|是| B15[addVoteCount]
        B15 --> B16{CheckForDuplicateVotes}
        B16 -->|重复| B17[拒绝]
        B16 -->|通过| B18[赞成+=lockValue 或 反对+=lockValue]
        B18 --> B19[setVoteCountByAddr: 记录投票数]
        B19 --> B20[投票成功]
    end
```

### 投票去重分析

**`CheckForDuplicateVotes`** (algorithm.cpp L9179-9224):

```cpp
// 先查询赞成地址集合
db.getApproveAddrsByAssetType(assetType, addrs);
if (addrs.find(addr) != addrs.end()) -> 已投赞成, 拒绝

// 再查询反对地址集合
db.getAgainstAddrsByAssetType(assetType, addrs);
if (addrs.find(addr) != addrs.end()) -> 已投反对, 拒绝
```

**原子性分析**:
- `addVoteCount` 内部调用 `CheckForDuplicateVotes` (L9239), 若通过则在同一DB事务中写入赞成/反对集合。
- 但 `CheckVoteTxInfo` 在交易的 `trans()` 阶段执行 (vote.cpp L60), 而 `addVoteCount` 在合约执行阶段调用。
- 两个阶段之间存在时间窗口, 理论上存在TOCTOU竞态:
  - T1: 用户A的Vote交易通过CheckVoteTxInfo (时间窗口有效)
  - T2: 投票时间窗口过期
  - T3: 用户A的Vote交易执行addVoteCount (此时时间已过期, 但去重检查通过)
- **风险**: 取决于 addVoteCount 是否重复校验时间窗口。
- **【需人工验证】addVoteCount 是否包含时间窗口二次校验** -- 从代码看仅做了去重检查, 未重复校验时间窗口。

## 3. 锁定/解锁流程

```mermaid
flowchart LR
    subgraph 锁定LOCK
        L1[用户持有Vote] --> L2[CreateLock]
        L2 --> L3{验证: 金额>=100M, 地址有效, 锁定类型=Node, 未重复锁定}
        L3 -->|失败| L4[拒绝]
        L3 -->|通过| L5[UTXO构造: Vote->LockVirtualStake]
        L5 --> L6[Gas燃烧到VirtualBurnGas]
        L6 --> L7[交易签名 & 广播]
        L7 --> L8[获得投票权: 票数=锁定金额/kDecimalNum]
    end

    subgraph 解锁UNLOCK
        U1[CreateUnlock] --> U2{IsQualifiedToUnLock?}
        U2 -->|否| U3[拒绝: NOT_QUALIFIED_TO_UNLOCK]
        U2 -->|是| U4[引用锁定UTXO hash]
        U4 --> U5[UTXO构造: LockVirtualStake->用户地址]
        U5 --> U6[Gas燃烧]
        U6 --> U7[交易签名 & 广播]
        U7 --> U8[释放投票权]
    end

    L8 -.->|状态转换| U1
```

### 锁定与投票权的原子性

**GetLockValue** (algorithm.cpp L9572-9624):
```cpp
1. dbReader.getLockAddrUtxo(addr, "Vote", utxos) // 获取所有锁定UTXO
2. 遍历utxos:
   - getTransactionByHash(utxo, txRaw) // 读取交易
   - 遍历vout, 找VIRTUAL_LOCK_ADDRESS的金额
3. lockValue = trunc(sum / kDecimalNum) // 截断转标准精度
4. 若lockValue < LOCK_AMOUNT(1), 返回错误
```

**原子性问题**:
- `GetLockValue` 读取的是"已确认"的锁定UTXO状态 -- 只有当LOCK交易被打包入块后, UTXO才生效。
- 如果在LOCK交易已提交但尚未入块期间, 用户提交VOTE交易:
  - 此时 `getLockAddrUtxo` 可能找不到锁定记录 -> 投票失败
  - 或找到但锁定量不足 -> 投票权重偏低
- 这确保了只有"已确认锁定"的用户才能投票, 符合UTXO模型的一致性保证。

## 4. 年化率计算流程

```mermaid
flowchart TD
    subgraph 触发时机
        T1[每个VRF周期?]
        T2[CalcBonusValue被调用时]
    end

    T2 --> S1

    subgraph 主流程
        S1[GetNetworkStakingRate] --> S1a[获取总流通量 totalSupply]
        S1 --> S1b[获取锁定总量 totalLockedAmount]
        S1 --> S2[stakingRate = totalLocked/totalSupply * 100]
        S1 --> S1c[Clamp到[10, 100]%]

        S2 --> S3[mapStakingRateToK]
        S3 --> S3a[k = 1.0 + (rate-10) * 19/90]

        S3a --> S4[calculateInflationRates]
        S4 --> S4a["520周: rate=0.5+(5.0-0.5)*exp(-k*x)"]
        S4a --> S4b["x = (w-1)/519 归一化时间"]

        S4b --> S5[calculateAnnualizedRates]
        S5 --> S5a["annualRate = inflRate / (stakingRate/100)"]

        S5a --> S6[GetNewAnnualizedRate]
        S6 --> S6a[计算周数: weeksSinceStart]
        S6a --> S6b["若>=520 -> 取最后一周期"]
        S6b --> S7["返回: annualizedRate = rates[weeksSinceStart]"]
    end

    S7 --> R1[CalcBonusValue]
```

### 年化率触发时机

**调用链追踪**:
```
CalcBonusValue (bonus.cpp L76调用, algorithm.cpp L7743)
  -> GetNetworkStakingRate (L7818)
  -> GetNewAnnualizedRate (L7826)
    -> mapStakingRateToK (L8022)
    -> calculateInflationRates (L8026)
    -> calculateAnnualizedRates (L8033)
```

**触发频率**: 每次用户调用 `CreateBonus` RPC时触发 (按需计算, 非定时批量计算)。

**性能考量**:
- `calculateInflationRates` 每次计算520周数据, 但参数固定时结果相同 -> 可缓存优化。
- DEBUGLOG在520次循环中每次都记录 (L7975-7978), 性能影响需要评估。

## 5. 奖励领取流程

```mermaid
flowchart TD
    subgraph 前置检查
        P1[CreateBonus RPC] --> P2[BonusTrans::trans]
        P2 --> P3{evaluateBonusEligibility}
        P3 -->|不合格| P4[拒绝: NOT_QUALIFIED_FOR_BONUS]
        P3 -->|合格| P5[CalcBonusValue]
    end

    subgraph CalcBonusValue
        C1[fetchAbnormalSignAddrListByPeriod] --> C1a[获取上周期签名地址]
        C1a --> C1b[计算平均签名量]
        C1b --> C1c{节点签名量 >= 平均?}
        C1c -->|是| C1d[dividendRate=1.0, 全额奖励]
        C1c -->|否| C1e["dividendRate = 实际/平均 < 1.0, 扣减奖励"]

        C1d --> C2
        C1e --> C2

        C2[GetNetworkStakingRate] --> C3[GetNewAnnualizedRate]

        C3 --> C4[获取委托者列表]
        C4 --> C5[遍历委托者]
        C5 --> C6{基础奖励 = annualRate * amount / 365}
        C6 --> C7{实际奖励 = dividendRate * 基础奖励}
        C7 --> C8[values[delegator] = 实际奖励]
    end

    subgraph 佣金与输出
        O1[GetCommissionPercentage] --> O2[佣金 = 总奖励 * 佣金率 + 0.5]
        O2 --> O3[为每个委托者创建vout: 奖励-佣金]
        O3 --> O4[为节点创建vout: 找零+总佣金]
        O4 --> O5[交易签名 & 广播]
    end

    C8 --> O1
```

## 6. Gas调整流程

```mermaid
flowchart TD
    G1[合约交易提交 DEPLOY/CALL] --> G2[VerifyContractBaseFee]
    G2 --> G3{gasCost > KTargetGasPrice*2 = 120,000?}
    G3 -->|是| G4[拒绝交易]
    G3 -->|否| G5[获取旧baseFee: 遍历发送者最后一笔合约交易]
    G5 --> G6{找到历史baseFee?}
    G6 -->|否/top==0| G7[old_baseFee = 10 初始值]
    G6 -->|是| G8[old_baseFee = 历史值]
    G7 --> G9
    G8 --> G9

    G9[EIP1559FeeCalculator::calculateNewFee]
    G9 --> G10["adjustment = (gasCost - 60000) / (60000 * 8)"]
    G10 --> G11["new_fee = old * (1 + adjustment)"]
    G11 --> G12{gasCost > 60000?}
    G12 -->|是 拥堵| G13["new_baseFee = ceil(new_fee) 上涨"]
    G12 -->|< 空闲| G14["new_baseFee = floor(new_fee) 下降"]
    G12 -->|= 平衡| G15["new_baseFee = new_fee 不变"]

    G13 --> G16["new_baseFee = max(new_baseFee, 0)"]
    G14 --> G16
    G15 --> G16

    G16 --> G17["最终Gas费用 = gasCost * new_baseFee"]
    G17 --> G18["记录new_baseFee到交易txInfo[baseFee]"]
```

### EIP-1559调整分析

**调整系数设计**:
```
adjustment_factor = (actual - target) / (target * 8)
```
- actual=target时: adjustment=0, new_fee=old_fee (不变)
- actual=2*target=120,000时: adjustment = 60000/480000 = 0.125, new_fee = 1.125*old (上涨12.5%)
- actual=0时: adjustment = -60000/480000 = -0.125, new_fee = 0.875*old (下降12.5%)

**收敛速度**: 8倍除数使得调整幅度较小, 每次最多±12.5%, 避免剧烈波动。

**边界条件**:
- old_fee < 0: throw (不应发生)
- actual_gas < 0: throw (不应发生)
- target_gas <= 0: throw (配置错误)
- 结果非负: max(new_fee, 0.0)

## 7. 关键调用链汇总

| 起始点 | 调用链 | 文件:行号 |
|--------|--------|----------|
| RPC CreateLock | LockTrans::trans() -> getLockAddrUtxo -> createUtxoTransferFrom -> GenerateGas -> fetchIdentityNodes | lock.cpp L11-163 |
| RPC CreateUnlock | UnlockTrans::trans() -> IsQualifiedToUnLock -> createUtxoTransferFrom -> GenerateGas -> fetchIdentityNodes | unlock.cpp L10-164 |
| RPC CreateVote | VoteTrans::trans() -> GetLockValue -> CheckVoteTxInfo -> makeTxData -> getGasValue -> fetchIdentityNodes | vote.cpp L13-132 |
| RPC CreateBonus | BonusTrans::trans() -> evaluateBonusEligibility -> CalcBonusValue -> GetNewAnnualizedRate -> GetCommissionPercentage -> createUtxoTransferTo | bonus.cpp L18-264 |
| RPC CreateFund | FundTrans::trans() -> fetchAvailableAssetType -> getGasAmountByPeriod -> CheckFundQualificationAndGetRewardAmount -> createUtxoFundTransfer | fund.cpp L17-200 |
| 合约交易验证 | VerifyContractBaseFee -> EIP1559FeeCalculator::calculateNewFee | fee_calculator.h L12 |
| 奖励地址缓存 | BonusAddrCache::getAmount -> getDelegatingAddrAndAssetTypeByBonusAddr -> getTransactionByHash | bonus_addr_cache.cpp L11-97 |
