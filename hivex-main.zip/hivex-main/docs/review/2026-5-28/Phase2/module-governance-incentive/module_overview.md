# 模块8+9: 治理与激励 -- 模块总览

## 1. 治理模块职责

治理模块负责链上提案管理与投票机制，包含四大子功能：

| 子模块 | 文件 | 职责 |
|--------|------|------|
| 提案(PROPOSAL) | `ca/transaction/contract.cpp/h` | 仅创始账号可发起，定义新资产类型的跃入参数 |
| 投票(VOTE) | `ca/transaction/vote.cpp/h` | 已锁定用户对提案/撤销提案进行赞成/反对投票 |
| 撤销提案(REVOKEPROPOSAL) | 同上 PROPOSAL 流程 | 创始账号发起撤销投票，通过后资产只能跃出不能跃入 |
| 锁定/解锁(LOCK/UNLOCK) | `ca/transaction/lock.cpp/h`, `ca/transaction/unlock.cpp/h` | 锁定Vote获得投票权，解锁释放Vote |

**核心算法函数** (位于 `ca/algorithm.cpp`):
- `CheckVoteTxInfo`: 验证投票时间窗口与资产类型有效性 (L9422)
- `CheckForDuplicateVotes`: 去重检查，确保每个地址对一个提案仅投票一次 (L9179)
- `addVoteCount` / `subVoteNum`: 投票计数增减 (L9228, L9313)
- `GetVoteNum`: 获取赞成/反对票数 (L9162)
- `GetLockValue`: 获取地址锁定金额即投票权重 (L9572)
- `GetProposalInfo`: 解析提案信息 (L9513)

## 2. 激励模块职责

激励模块负责质押奖励分配与Gas费用管理：

| 子模块 | 文件 | 职责 |
|--------|------|------|
| 年化率计算 | `ca/algorithm.cpp` | 指数衰减通胀率 (5%->0.5%) + 质押率反比调节 |
| 奖励领取(BONUS) | `ca/transaction/bonus.cpp/h` | 节点领取其委托者的分红奖励 |
| 国库领取(FUND) | `ca/transaction/fund.cpp/h` | 节点领取按锁定/打包占比分配的Gas国库奖励 |
| Gas费用 | `ca/fee_calculator.h` | EIP-1559动态调整，目标阈值60000 |
| 奖励缓存 | `ca/bonus_addr_cache.cpp/h` | 缓存节点委托金额与时间 |

**核心算法函数**:
- `GetNewAnnualizedRate`: 新版年化率计算，基于指数衰减 (L7985)
- `mapStakingRateToK`: 质押率线性映射到衰减系数 (L7903)
- `calculateInflationRates`: 指数衰减通胀率序列 (L7923)
- `calculateAnnualizedRates`: 通胀率/质押率得年化率 (L7947)
- `GetNetworkStakingRate`: 网络质押率计算 (L8062)
- `CalcBonusValue`: 奖励金额计算入口，含VRE工作量惩罚 (L7743)
- `fetchAbnormalSignAddrListByPeriod`: 异常签名节点列表 (L66)
- `GetAnnualizedRate`(旧): 旧版线性衰减 (L9728, **已废弃**)

## 3. 三层资产分类

来源: `spec_dev.md` 11.1.1节, `ca/global.h` L67-68

| 资产层 | AssetType | 所在层 | 可否支付Gas | 可否质押 | 可否跃入/跃出 |
|--------|-----------|--------|-------------|----------|---------------|
| **Token** | 合约地址 | EVM合约层 | 否 | 否 | 否(仅合约内流转) |
| **Native Token** | 提案交易哈希 | UTXO层 | 是 | 是 | 可通过FlowIn/FlowOut |
| **Native(Vote)** | `"Vote"` | UTXO层 | 是 | 是(锁定) | 否(底层原生币) |

关键常量:
- `ASSET_TYPE_VOTE = "Vote"` (`global.h` L67)
- `assetType_MM = "MM"` (`global.h` L68) -- MM是原生Native Token，由提案动态规定发行量

## 4. 跃入/跃出协议

来源: `spec_dev.md` 11.2节

- **FlowIn**: 提案通过(赞成票>反对票) -> 用户调用跨链合约 -> 合约层Token锁定 -> UTXO层按汇率铸造Native Token -> AssetType=提案交易哈希
- **FlowOut**: 用户创建FlowOut交易 -> UTXO层Native Token销毁 -> 合约层释放Token
- **撤销后**: Native Token只能跃出不能跃入

## 5. 三列对比表: 规范定义 vs 当前实现 vs 偏差原因

| 功能点 | 规范定义(spec_dev.md) | 当前实现(代码) | 偏差原因 | 可信度 |
|--------|----------------------|---------------|----------|--------|
| **提案发起资格** | 仅限创始账号 (11.3.1, L2055) | 代码中`CheckProposaInfo`未做发起者校验, 依赖交易类型标记 | 可能是业务层在RPC侧校验【需人工验证】 | 中 |
| **投票资格** | 所有锁定Vote币的用户 (11.3.2, L2077) | `vote.cpp` L51调用`GetLockValue`获取锁定量, 创始账号特殊处理lockValue=1 | 增加创始账号豁免 | 高 |
| **投票规则:去重** | 一个地址对一提案仅投一次 (11.3.2, L2082) | `CheckForDuplicateVotes` (algorithm.cpp L9179) 同时检查赞成和反对地址集合 | 完全符合规范 | 高 |
| **投票规则:二选一** | 赞成或反对 (11.3.2, L2080) | `addVoteCount` (L9255-9277) 分别处理Approve/Against; `CheckForDuplicateVotes`确保不在对方列表中 | 完全符合规范 | 高 |
| **投票时间窗口** | beginTime ~ endTime (11.3.2, L2083) | `CheckVoteTxInfo` L9479: `currentTime < beginTime || currentTime >= endTime` 拒绝 | 完全符合规范 | 高 |
| **提案结果判定** | 赞成票 > 反对票 = 通过 (11.3.3) | 规范定义简单多数; 代码中判定逻辑分散在合约交互层【需人工验证】 | 判定逻辑可能内嵌在EVM合约中 | 中 |
| **年化率:指数衰减** | 5.0% -> 0.5%, 指数衰减 exp(-k*x) (11.7.1) | `calculateInflationRates` (L7923): `endRate + (startRate - endRate) * exp(-k*x)`, startRate=5.0, endRate=0.5 | startRate与规范一致, endRate=0.5%与规范一致 | 高 |
| **年化率:质押率反比** | 年化率 = 通胀率 / 质押率 (11.7.1) | `calculateAnnualizedRates` L7970: `rate / stakingRatio` | 完全符合规范 | 高 |
| **年化率:旧版** | 未定义 | `GetAnnualizedRate` (L9728) 使用线性衰减 startRate=0.23, endRate=0.15, attenuationValue=0.0001 | **已废弃**, 被GetNewAnnualizedRate替代 | 高 |
| **质押率下限** | 若<10%按10%计算 (11.7.1) | `calculateAnnualizedRates` L7953: `if(stakingRate < 10) stakingRate = 10.0` | 完全符合规范 | 高 |
| **异常节点惩罚** | 签名量低于平均值按比例扣减 (6.4.3, 11.7.3) | `fetchAbnormalSignAddrListByPeriod` (L66) 计算平均签名量; `CalcBonusValue` L7882: `dividendRate * 基础奖励` | 完全符合规范 | 高 |
| **Gas动态调整** | EIP-1559, target=60000 (11.5.3) | `EIP1559FeeCalculator` (`fee_calculator.h`): `adjustment = (actual-target)/(target*8)`, 拥堵ceil/空闲floor | 完全符合规范 | 高 |
| **锁定金额** | LOCK_AMOUNT=1标准精度 (11.4.2) | `global.h` L37: `LOCK_AMOUNT = 1`, lock.cpp L37使用 `LOCK_AMOUNT * kDecimalNum` | 完全符合规范 | 高 |
| **投票周期** | 10分钟 KVoteCycle (12.1.2) | `global.h` L132: `KVoteCycle = 10 * 60 * 1000000` (600秒微秒) | 完全符合规范 | 高 |
| **年化率计算:时间单位** | 微秒 (11.7.1) | `GetNewAnnualizedRate` L7997 检查若 `projectStartTime < 10^12` 则转换为微秒 | 增加容错处理 | 高 |
| **Gas初始baseFee** | 10 (11.5.3) | `spec_dev.md` L2181: 创世或无历史时默认old_baseFee=10 | 在`VerifyContractBaseFee`中实现【需人工验证】 | 中 |
| **最低汇率** | 1e-8 (`KLowestExchangeRate`) | `global.h` L135: `boost::multiprecision::cpp_bin_float_100 KLowestExchangeRate("1e-8")` | 完全符合规范 | 高 |

## 6. 问题清单

### 6.1 高优先级

| # | 位置 | 现象 | 风险等级 | 触发场景 | 修复建议 | 验证方法 |
|---|------|------|---------|---------|---------|---------|
| Q1 | `bonus.cpp` L144, L152 | `operator_commission = delegator.second * temp_commission_rate + 0.5` 使用整数截断而非四舍五入 | 高 | 佣金率>0时, 每次截断积累误差, 委托量大时累积显著 | 使用`std::round()`明确四舍五入 | 单元测试验证佣金精度 |
| Q2 | `algorithm.cpp` L8070 | `getTotalCirculationAsOfTodayStart` 计算总流通量, 若为零则默认质押率10% | 高 | 创世初期totalSupply=0时, stakingRate被硬设为10%, 可能误导年化率 | 区分"当前为零"与"计算失败" | 检查创世后首个VRF周期数据 |
| Q3 | `algorithm.cpp` L9615 | `lockValue = std::trunc(lockValue / kDecimalNum)` 截断而非四舍五入 | 中 | 锁定金额刚好在小数边界时损失精度 | 使用`std::round()` | 单元测试 |
| Q4 | `fund.cpp` L289 | `uint64_t value = uint64_t(rate * asset_type.second * 0.5)` 浮点乘法截断 | 高 | rate为double, 乘法结果可能因浮点精度于边界值差1 | 使用高精度计算后round | 边界值测试 |

### 6.2 中优先级

| # | 位置 | 现象 | 风险等级 | 触发场景 | 修复建议 | 验证方法 |
|---|------|------|---------|---------|---------|---------|
| Q5 | `algorithm.cpp` L8003-8009 | weekInMicroseconds 使用 `7*24*60*60*1000000ULL = 604800000000` 但需确认无溢出 | 中 | 64位足够(约5800亿周), 但万一curTime异常大 | 添加溢出检查 | 检查curTime合法性 |
| Q6 | `algorithm.cpp` L8093 | stakingRate被clamp到[10,100], 但质押率>100%在数学上不应出现 | 中 | 若totalLockedAmount > totalSupply则质押率>100%被截断 | 应记录WARNING而非静默截断 | 监控日志 |
| Q7 | `vote.cpp` L45-57 | 创始账号lockValue硬编码为1, 其他走数据库查询 | 低 | 创始账号投票权恒为1, 不受实际锁定影响 | 确认是否符合设计意图 | 查阅设计文档 |
| Q8 | `algorithm.cpp` L7971-7978 | `calculateAnnualizedRates` 中每次迭代都输出DEBUGLOG | 低 | 520周日志量极大, 影响性能 | 移除循环内日志或改为TRACE级别 | 性能分析 |
| Q9 | `lock.cpp` L57-61 | 重复锁定检查仅通过getLockAddrUtxo判断 | 中 | 若用户锁定后解锁再锁定, 旧UTXO可能被清理但索引未清理 | 增加锁定状态标志位 | 测试锁定->解锁->锁定循环 |
| Q10 | `fund.cpp` L105-106 | `double(return_value) / double(total_locked_amount)` 除数为零 | 高 | total_locked_amount=0时除零崩溃 | 添加除零保护 | 空网络启动测试 |

### 6.3 低优先级

| # | 位置 | 现象 | 风险等级 | 触发场景 | 修复建议 | 验证方法 |
|---|------|------|---------|---------|---------|---------|
| Q11 | `bonus_addr_cache.cpp` L86-89 | 首次达到kMinDelegatingAmt时记录时间, 但后续委托增加不更新时间 | 低 | 委托时间记录为首次达标时间, 可能影响权益计算 | 确认设计意图 | 查阅设计文档 |
| Q12 | `algorithm.cpp` L9728-9748 | 旧版`GetAnnualizedRate`函数仍存在但未被调用 | 低 | 代码混淆, 新人可能误用 | 标记deprecated或移除 | 全局搜索调用点 |

## 7. 有效/废弃/未完成/临时兼容 分类

| 状态 | 代码位置 | 说明 |
|------|---------|------|
| **有效** | `GetNewAnnualizedRate` (L7985) | 当前使用的年化率计算 |
| **已废弃** | `GetAnnualizedRate` (L9728) | 旧版线性衰减, 已被新版替代 |
| **临时兼容** | `GetNewAnnualizedRate` L7997-8000 | 时间戳秒/微秒兼容检查 |
| **未完成(注释掉)** | `contract.cpp/h` 全文件 | 被 `#if 0` 包裹, PROPOSAL相关逻辑未启用 |
| **未完成(注释掉)** | `fund.cpp` L151-169 | 锁定/打包奖励分配逻辑被注释, 改用 `createUtxoFundTransfer` |
