# 模块8+9: 治理与激励 -- 线程模型分析

## 1. 全局锁概览

| 锁名称 | 类型 | 声明位置 | 保护范围 |
|--------|------|---------|---------|
| `bonusMutex` | `std::mutex` | `ca/global.h` L29 | 奖励计算全局锁 |
| `kDelegatingMutex` | `std::mutex` | `ca/global.h` L30 | 委托操作全局锁 |
| `BURN_MUTEX` | `std::mutex` | `ca/global.h` L31 | Gas销毁全局锁 |
| `LOCK_MUTEX` | `std::mutex` | `ca/global.h` L32 | 锁定/解锁全局锁 |
| `bonus_addr_mutex_` | `std::shared_mutex` | `bonus_addr_cache.h` L47 | BonusAddrCache读写锁 |

## 2. 定时器分析

### 2.1 投票周期定时器

**常量**: `KVoteCycle = 10 * 60 * 1000000` (10分钟, 单位微秒) -- `ca/global.h` L132

**用途**: 控制提案投票周期长度。每个提案的投票期为从 `beginTime` 到 `endTime`, 时长通常为 `KVoteCycle`。

**代码引用**: `CheckVoteTxInfo` (algorithm.cpp L9422) 检查 `currentTime` 是否在 `[beginTime, endTime)` 区间。

**线程**: 由 `CTimer` 类管理, `global.h` L25-27 声明了三个静态定时器:
```cpp
static CTimer BLOCK_POOL_TIMER_INTERVAL("blockpool");
static CTimer SEEK_BLOCK_TIMER("SeekBlock");
static CTimer DATABASE_TIMER("database");
```
投票到期检查可能由区块打包或同步定时器触发【需人工验证触发机制】。

### 2.2 VRF投票开始定时器

**常量**: `KVrfVoteBeginTime = 10 * 1000000` (10秒, 单位微秒) -- `ca/global.h` L133

**用途**: VRF共识中打包节点开始处理投票交易的时间窗口。

**设计逻辑**: VRF周期为10秒, 每个VRF周期内有一个投票处理窗口, 确保投票交易能在规定时间内被处理。

## 3. 锁定的线程安全

### 3.1 LOCK_MUTEX

**位置**: `ca/global.h` L32
**类型**: `static std::mutex`

**保护内容**: 锁定(Lock)和解锁(Unlock)交易的全局互斥, 防止同一地址的并发锁定/解锁操作。

**持有时机**:
- Lock交易执行时 (`lock.cpp trans()` 或上游调用)
- Unlock交易执行时 (`unlock.cpp trans()` 或上游调用)

**死锁风险评估**: 低。LOCK_MUTEX是独立的全局锁, 不与其他锁交叉获取。

### 3.2 重复锁定检查

`lock.cpp` L56-61:
```cpp
DBReader dbReader;
std::vector<std::string> stake_unspent_outputs;
auto dbret = dbReader.getLockAddrUtxo(s_lock_param.lock_addr.str(),
                                        global::ca::ASSET_TYPE_VOTE,
                                        stake_unspent_outputs);
if(dbret != DBStatus::DB_NOT_FOUND) {
    return PERROR(MEM::UNKNOWN_LOCK_TYPE, "There has been a lock transaction before");
}
```

**竞态分析**:
- LOCK_MUTEX确保同一时刻没有其他线程对同一地址进行锁定
- 但DB读取与写入之间的时间窗口:
  - T1: 线程A读getLockAddrUtxo -> DB_NOT_FOUND (无锁定记录)
  - T2: 线程B读getLockAddrUtxo -> DB_NOT_FOUND (无锁定记录)
  - T3: 线程A写入锁定UTXO
  - T4: 线程B写入锁定UTXO (重复锁定)
- **风险缓解**: LOCK_MUTEX在trans()入口处获取, 覆盖整个读-写过程, 使上述场景不可能发生。

## 4. 奖励计算的线程安全

### 4.1 bonusMutex

**位置**: `ca/global.h` L29
**类型**: `static std::mutex`

**保护内容**: `CalcBonusValue` 中的奖励计算过程, 特别是 `fetchAbnormalSignAddrListByPeriod` 和 `GetDelegatingAmountAndDuration` 等涉及DB读取的操作。

**持有时机**: BONUS交易创建 (bonus.cpp trans())

**需要全局锁的原因**: 奖励计算涉及读取前一周期的全局签名统计数据, 多个节点的并发奖励计算可能导致数据竞争(虽然DB本身可能提供事务隔离)。

### 4.2 BonusAddrCache读写锁

**位置**: `bonus_addr_cache.h` L47
**类型**: `mutable std::shared_mutex bonus_addr_mutex_`

**保护内容**: `bonus_addr_map_` (委托地址->委托信息映射)

**锁策略**:
- `getAmount()`: 使用 `unique_lock` 写锁 (L14) -- 因为可能修改缓存
- `getTime()`: 使用 `shared_lock` 读锁 (L101) -- 纯读取
- `isDirty()`: 使用 `unique_lock` 写锁 (L115) -- 修改脏标记

**并发读优化**: `getTime()` 使用共享锁, 允许多个线程并发读取缓存时间, 提高吞吐量。

**潜在问题**: `getAmount()` 始终获取写锁, 即使在缓存命中(只读)场景。优化建议: 缓存命中时降级为读锁。

## 5. 其他全局锁的治理/激励影响

### 5.1 kDelegatingMutex

**位置**: `ca/global.h` L30
**类型**: `static std::mutex`

**保护内容**: 委托(Delegating)和取消委托(UnDelegating)操作。

**治理/激励关联**: 委托金额影响节点的 `CalcBonusValue` 计算。委托锁确保在奖励计算期间, 委托结构不被并发修改。

### 5.2 BURN_MUTEX

**位置**: `ca/global.h` L31
**类型**: `static std::mutex`

**保护内容**: Gas销毁统计数据的并发写入。

**治理/激励关联**: Gas销毁量影响国库(Fund)奖励分配(按周期统计Gas收入)。BURN_MUTEX确保Gas统计不被并发修改。

## 6. 线程交互模型

```mermaid
sequenceDiagram
    participant RPC as RPC线程
    participant VRF as VRF打包线程
    participant Timer as 定时器线程
    participant DB as RocksDB

    Note over RPC,Timer: === 锁定流程 ===
    RPC->>RPC: 获取 LOCK_MUTEX
    RPC->>DB: getLockAddrUtxo (检查重复)
    RPC->>DB: 写入锁定UTXO
    RPC->>RPC: 释放 LOCK_MUTEX

    Note over RPC,Timer: === 投票流程 ===
    RPC->>DB: GetLockValue (读锁定UTXO)
    RPC->>DB: CheckVoteTxInfo (读提案信息)
    RPC->>DB: addVoteCount (写投票记录)

    Note over RPC,Timer: === 奖励流程 ===
    RPC->>RPC: 获取 bonusMutex
    RPC->>DB: fetchAbnormalSignAddrListByPeriod (读签名统计)
    RPC->>DB: GetNetworkStakingRate (读质押率)
    RPC->>DB: GetNewAnnualizedRate (计算年化率)
    RPC->>RPC: 释放 bonusMutex

    Note over Timer: === 定时器 ===
    Timer->>Timer: KVoteCycle 10分钟周期
    Timer->>DB: 检查投票到期
    Timer-->>DB: 统计投票结果

    Timer->>Timer: KVrfVoteBeginTime 10秒
    Timer-->>VRF: 触发投票处理窗口
```

## 7. 线程安全评估

| 场景 | 安全性 | 说明 |
|------|--------|------|
| 并发锁定 | 安全 | LOCK_MUTEX+重复检查 |
| 并发解锁 | 安全 | LOCK_MUTEX保护 |
| 并发投票 | 部分安全 | addVoteCount有去重检查, 但无全局投票锁 |
| 并发奖励计算 | 安全 | bonusMutex保护 |
| 并发委托+奖励 | 依赖kDelegatingMutex | 需确认获取顺序一致 |
| BonusAddrCache并发读 | 安全 | shared_mutex |
| BonusAddrCache读写混合 | 安全 | getAmount()持写锁, getTime()持读锁 |

### 潜在死锁风险

**bonusMutex + kDelegatingMutex** 交叉获取可能:

路径A: Bonus交易 -> bonusMutex (CalcBonusValue) -> kDelegatingMutex (获取委托数据)
路径B: Delegating交易 -> kDelegatingMutex -> bonusMutex (可能更新缓存脏标记)

如果两条路径的锁获取顺序不一致, 存在死锁风险。

**【需人工验证】** 实际代码中两条路径的锁获取顺序。

## 8. 年化率计算时机

年化率计算**非定时触发**, 而是在以下场景**按需计算**:

1. **奖励领取时** (bonus.cpp trans() -> CalcBonusValue):
   - 最频繁的触发场景
   - 每次计算520周通胀率 + 年化率序列 (即使只需当前周的值)
   - 性能可优化: 缓存每周的年化率, 仅在质押率变化时重新计算

2. **可能的其他触发点**:
   - RPC查询收益信息 (`GetYieldInfo`)
   - 前端展示年化率

**优化建议**: 将 `calculateInflationRates` 和 `calculateAnnualizedRates` 的结果按k值缓存, 因为k值仅取决于质押率, 而质押率在每个VRF周期内相对稳定。
