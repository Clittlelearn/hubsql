# 模块8+9: 治理与激励 -- 状态流转分析

## 1. 提案状态机

```mermaid
stateDiagram-v2
    [*] --> 未创建
    未创建 --> 已创建 : 创始账号发起PROPOSAL\n存储提案信息到RocksDB

    已创建 --> 投票中 : 投票时间窗口开启\n[beginTime, endTime)

    投票中 --> 已通过 : 投票到期 + 赞成票 > 反对票
    投票中 --> 已否决 : 投票到期 + 反对票 >= 赞成票

    已通过 --> 已撤销 : 创始账号发起REVOKEPROPOSAL\n撤销投票通过

    note right of 已通过
        Token可跃入UTXO层
        成为Native Token
    end note

    note right of 已撤销
        Native Token只能跃出
        不能跃入,不能质押
        已质押资产不再有效
    end note

    note right of 投票中
        周期: KVoteCycle=10分钟
        资格: 已锁定Vote的用户
        去重: 每个地址每提案仅投一次
        类型: 赞成(Approve=1)或反对(Against=0)
    end note
```

### 提案状态枚举

代码中未有显式枚举, 状态由以下条件隐式推导:

| 状态 | 判定条件 | 数据库标志 |
|------|---------|-----------|
| 已创建 | `PROPOSAL:{assetType}` Key存在 | DB中有提案信息 |
| 投票中 | `beginTime <= currentTime < endTime` | CheckVoteTxInfo L9479 |
| 已通过 | 赞成票 > 反对票 (投票期结束后判定) | 资产可跃入 |
| 已否决 | 反对票 >= 赞成票 (投票期结束后判定) | 资产不可跃入 |
| 已撤销 | `REVOKE:{assetType}` Key存在 + 撤销投票通过 | Token仅可跃出 |

### 关键状态转换条件

**创建 -> 投票中**: 提案交易被打包入块后, `beginTime` 到达时开始。`CheckVoteTxInfo` (algorithm.cpp L9422-9486) 负责校验时间窗口。

**投票中 -> 通过/否决**: 依赖定时器触发判定 (`KVoteCycle = 10*60*1000000 μs`, global.h L132)。判定逻辑在合约交互层。

**通过 -> 撤销**: 创始账号发起 `REVOKEPROPOSAL` -> 投票 -> 赞成 > 反对 -> 撤销生效。

## 2. 锁定状态机

```mermaid
stateDiagram-v2
    [*] --> 未锁定 : 初始状态

    未锁定 --> 已锁定 : CreateLock交易入块\nVote转入LockVirtualStake

    已锁定 --> 已解锁 : CreateUnlock交易入块\nVote释放回用户地址

    note right of 已锁定
        获得投票权
        票数 = 锁定Vote量 / kDecimalNum
        min锁定: 100,000,000 (最小精度)
    end note

    note right of 已解锁
        失去投票权
        Vote回到用户可用余额
    end note
```

### 锁定状态存储

| 状态 | 数据库记录 | 文件:行号 |
|------|-----------|----------|
| 未锁定 | `LOCK_UTXO:{addr}:Vote` 无记录 | - |
| 已锁定 | `LOCK_UTXO:{addr}:Vote` 有UTXO记录 | lock.cpp L56 |
| 锁定检查 | `getLockAddrUtxo(addr, "Vote", utxos)` != DB_NOT_FOUND | lock.cpp L56-61 |

### 状态转换校验

**未锁定 -> 已锁定**:
1. `lock_amount >= LOCK_AMOUNT * kDecimalNum` (100,000,000) [lock.cpp L37]
2. 锁定类型必须为 `kLock_Node` [lock.cpp L44]
3. 不存在已有锁定记录 [lock.cpp L56-61]

**已锁定 -> 已解锁**:
1. `IsQualifiedToUnLock(addr, utxo_hash, lock_amount, "Vote")` == 0 [unlock.cpp L40]
2. utxo_hash必须匹配锁定UTXO
3. 锁定金额必须匹配

## 3. 投票状态机

```mermaid
stateDiagram-v2
    [*] --> 未投票 : 初始状态

    未投票 --> 已投赞成 : CreateVote vote_type=1
    未投票 --> 已投反对 : CreateVote vote_type=0

    已投赞成 --> [*] : 投票不可撤销
    已投反对 --> [*] : 投票不可撤销

    note right of 未投票
        条件: 已锁定Vote + 在投票时间窗口内
    end note

    note right of 已投赞成
        赞成票数 + lockValue
        DB: setApproveAddrsByAssetType
    end note

    note right of 已投反对
        反对票数 + lockValue
        DB: setAgainstAddrsByAssetType
    end note
```

### 投票状态存储

| 地址投票状态 | 数据库记录 | Key格式 |
|-------------|-----------|---------|
| 未投票 | 不在任何地址集合中 | - |
| 已投赞成 | 在赞成地址集合中 | `APPROVE:{assetType}` -> set of addrs |
| 已投反对 | 在反对地址集合中 | `AGAINST:{assetType}` -> set of addrs |
| 投票数 | 地址投票权重 | `VOTE_ADDR:{addr}:{assetType}` -> voteNumber |

### 投票不可逆性

投票后不可更改或撤销:
- `addVoteCount` 仅新增, 无修改或删除已投记录的操作
- `subVoteNum` 存在但用于撤销提案场景的批量回退 (非用户撤销投票)
- `CheckForDuplicateVotes` 阻止同一地址对同一提案重复投票

## 4. 奖励状态机

```mermaid
stateDiagram-v2
    [*] --> 未领取 : 初始状态

    未领取 --> 计算中 : CalcBonusValue被调用
    计算中 --> 可领取 : 计算完成, rewards > 0
    计算中 --> 不可领取 : 计算失败 或 rewards = 0

    可领取 --> 已领取 : CreateBonus交易入块

    已领取 --> 未领取 : 下一奖励周期开始

    note right of 计算中
        1. fetchAbnormalSignAddrListByPeriod
        2. GetNetworkStakingRate
        3. GetNewAnnualizedRate
        4. 遍历委托者计算分配
        5. 工作量惩罚系数
    end note

    note right of 不可领取
        原因:
        - 无签名记录(前一天无人工作)
        - 节点不在签名列表中
        - 年化率计算失败
    end note
```

### 奖励状态判定条件

| 状态 | 判定条件 | 代码位置 |
|------|---------|---------|
| 可领取 | `evaluateBonusEligibility(addr,time) == 0` + `CalcBonusValue >= 0` | bonus.cpp L70-84 |
| 不可领取(无人工作) | `addrSignCount.empty()` -> 返回-1 | algorithm.cpp L7751-7755 |
| 不可领取(无资格) | addr不在addr_percent且不在addrSignCount | algorithm.cpp L7787-7790 |
| 不可领取(年化率失败) | GetNewAnnualizedRate返回值!=0 | algorithm.cpp L7827-7831 |
| 已领取 | BONUS交易被打包入块 | - |

### 国库领取状态

`FundTrans` 有独立的无法复用BONUS的状态:

```mermaid
stateDiagram-v2
    [*] --> 未领取国库

    未领取国库 --> 合格检查 : CreateFund

    合格检查 --> 可领取国库 : is_locked或is_packaged = true
    合格检查 --> 不可领取 : 无锁定且无打包

    可领取国库 --> 已领取 : FUND交易入块

    note right of 合格检查
        is_locked = return_value>0 && total_locked_amount>0
        is_packaged = 节点质押资格 && times>0 && count>0
    end note
```

## 5. 年化率状态

年化率是瞬时计算值, 无持久化状态。每次调用 `GetNewAnnualizedRate` 重新计算:

| 输入因素 | 随时变化 | 稳定性 |
|---------|---------|--------|
| 项目运行周数 | 随时间单调递增 | 高度可预测 |
| 质押率 | 随锁定/解锁/质押变化 | 可能波动 |
| 通胀率序列 | 由k值和周数决定 | 确定性 |

**关键**: 年化率在同一周内因质押率变化而波动, 但通胀率序列在同一k值下确定。由于k值也依赖质押率, 所以年化率本质上随质押率动态变化。

## 6. 状态转换的安全性分析

### 6.1 锁定->投票的原子性

- 锁定和投票是两次独立交易, 非原子操作
- UTXO模型天然保证: 只有锁定交易入块后, 投票时才能查到锁定UTXO
- `GetLockValue` 读取已确认UTXO, 避免了未确认锁定的投票

### 6.2 投票去重的正确性

- `addVoteCount` 调用 `CheckForDuplicateVotes` 与DB写入在同一函数内
- 但`CheckVoteTxInfo`(时间窗口校验)在交易`trans()`阶段, `addVoteCount`在合约执行阶段
- 存在时间窗口: trans()通过验证后, 到实际执行addVoteCount之间, 投票期可能结束
- **风险评估**: 中风险, 但实际影响有限 (10分钟投票期内, trans()到执行通常秒级)

### 6.3 奖励领取的幂等性

- `evaluateBonusEligibility` 检查是否已领取 (bonus.cpp L70)
- 检查机制是查询该地址在该周期的已领取记录
- 需确认基金领取是否有防重入保护【需人工验证】
