# 模块8+9: 治理与激励 -- 存储模型分析

## 1. RocksDB Key前缀规范

来源: `spec_dev.md` 附录C (L2561-2599)

### 1.1 治理相关Key前缀

| 前缀 | Key格式 | Value | 读写操作 | 代码引用 |
|------|---------|-------|---------|---------|
| `APPROVE:` | `APPROVE:{assetType}` | set of addresses | `setApproveAddrsByAssetType` / `getApproveAddrsByAssetType` / `removeApproveAddrsByAssetType` | algorithm.cpp L9192, L9258, L9354 |
| `AGAINST:` | `AGAINST:{assetType}` | set of addresses | `setAgainstAddrsByAssetType` / `getAgainstAddrsByAssetType` / `removeAgainstAddrsByAssetType` | algorithm.cpp L9208, L9267 |
| `VOTE_TX:` | `VOTE_TX:{assetType}` | 投票交易哈希 | `setVoteTxHashByAssetType` / `getVoteTxHashByAssetType` | 投票交易与资产关联 |
| `PROPOSAL:` | `PROPOSAL:{assetType}` | Base64编码的JSON提案信息 | `setProposalInfoByAssetType` / `getProposalInfoByAssetType` | algorithm.cpp L9436, L9492, L9518 |
| `REVOKE:` | `REVOKE:{assetType}` | Base64编码的JSON撤销提案信息 | `setRevokeProposalInfoByAssetType` / `getRevokeProposalInfoByAssetType` | algorithm.cpp L9451 |
| `VOTE_CNT:` | `VOTE_CNT:{assetType}` | 赞成票数+反对票数 | `setVoteCountByAssetType` / `getVoteCountByAssetType` | algorithm.cpp L9169, L9279 |
| `VOTE_ADDR:` | `VOTE_ADDR:{addr}:{assetType}` | 该地址的投票权重 | `setVoteCountByAddr` / `getVoteCountByAddr` | algorithm.cpp L9285, L9334 |
| `VOTE_TOTAL:` | `VOTE_TOTAL:{assetType}` | 总投票者数 | `setTotalCountByAssetType` / `getTotalCountByAssetType` | algorithm.cpp L9292, L9303 |
| `LOCK_ADDR` | `LOCK_ADDR` | 所有锁定地址列表 | `setLockAddr` / `getLockAddr` | 锁定地址注册 |
| `LOCK_UTXO:` | `LOCK_UTXO:{addr}:{assetType}` | 该地址的锁定UTXO列表 | `setLockAddrUtxo` / `getLockAddrUtxo` | lock.cpp L56, algorithm.cpp L9576 |

### 1.2 激励相关Key前缀

| 前缀 | Key格式 | Value | 读写操作 | 代码引用 |
|------|---------|-------|---------|---------|
| `SIGN:` | `SIGN:{period}:{addr}` | 该周期该地址签名数 | `setSignCountByPeriod` / `getSignCountByPeriod` | algorithm.cpp L82 |
| `BLOCK_NUM:` | `BLOCK_NUM:{period}` | 该周期区块总数 | `setBlockNumberByPeriod` / `getBlockNumberByPeriod` | fund.cpp L114 |
| `SIGN_ADDR:` | `SIGN_ADDR:{period}` | 该周期所有签名地址列表 | `setSignAddrByPeriod` / `getSignAddrByPeriod` | algorithm.cpp L71 |
| `BURN:` | `BURN:{period}` | Gas销毁量(按周期) | `setGasAmountByPeriod` / `getGasAmountByPeriod` | fund.cpp L51 |
| `PACKAGER` | `PACKAGER` | 打包次数统计 | `getPackagerCountByPeriod` | fund.cpp L112 |

### 1.3 经济/质押相关Key前缀

| 前缀 | Key格式 | Value | 代码引用 |
|------|---------|-------|---------|
| `ASSET` | `ASSET` | 所有资产类型列表 | vote.cpp L37, algorithm.cpp L9552 |
| `STAKE_ADDR` | `STAKE_ADDR` | 所有质押地址 | - |
| `STAKE:` | `STAKE:{addr}:{assetType}` | 质押UTXO列表 | - |
| `DELEG:` | `DELEG:{bonusAddr}:{delegator}:{assetType}` | 委托UTXO | bonus_addr_cache.cpp L52 |
| `DELEG_ADDR` | `DELEG_ADDR` | 所有委托地址 | bonus_addr_cache.cpp L35 |
| `UAH:` | `UAH:{addr}:{assetType}` | 地址的UTXO列表 | 查询余额 |
| `BAL:` | `BAL:{addr}:{assetType}` | 地址余额 | - |
| `UB:` | `UB:{addr}:{assetType}:{utxo}` | UTXO余额 | - |

## 2. 提案信息存储

### 2.1 存储结构

提案信息以JSON格式(Base64编码)存储:

```json
{
  "Version": 0,
  "BeginTime": 1769000000000000,
  "EndTime": 1769000600000000,
  "Name": "base64(资产名称)",
  "ExchangeRate": "1000000000000000000",
  "CrossChainTxType": 0,
  "EnteringMoreContractAddr": "0x...",
  "CrossChainInvestmentContractAddr": "0x...",
  "canBeStake": 1,
  "MIN_VOTE_NUM": 100,
  "Title": "base64(标题)",
  "Identifier": "base64(标识符)",
  "PeerChainTokenAddr": "0x..."
}
```

**Key**: `PROPOSAL:{assetType}` (assetType即提案交易哈希)
**编码**: Base64(JSON字符串)
**解析**: `GetProposalInfo` (algorithm.cpp L9513-9546)

### 2.2 撤销提案存储

```json
{
  "version": 0,
  "ProposalHash": "原始提案哈希",
  "BeginTime": 1769000000000000,
  "EndTime": 1769000600000000,
  "MIN_VOTE_NUM": 100
}
```

**Key**: `REVOKE:{assetType}`
**解析**: `CheckVoteTxInfo` (algorithm.cpp L9448-9471) 通过 `getRevokeProposalInfoByAssetType`

## 3. 投票计数存储

### 3.1 赞成/反对票计数

**Key**: `VOTE_CNT:{assetType}`
**Value**: 复数 (赞成票数, 反对票数)  -- 以某种序列化格式存储

**读取**: `GetVoteNum` (algorithm.cpp L9162-9176):
```cpp
db.getVoteCountByAssetType(assetType, approveNum, againstNum);
```

**写入**: `addVoteCount` (algorithm.cpp L9279):
```cpp
db.setVoteCountByAssetType(assetType, approveNum, againstNum);
```

### 3.2 投票地址集合

**赞成地址** `APPROVE:{assetType}` -> Set of addresses
**反对地址** `AGAINST:{assetType}` -> Set of addresses

用于去重检查, `CheckForDuplicateVotes` 查询两个集合确认地址未投过票。

### 3.3 地址投票权重

**Key**: `VOTE_ADDR:{addr}:{assetType}`
**Value**: 该地址的投票权重 (lockValue, 即锁定Vote量/kDecimalNum)

**用途**: 记录每个地址对每个提案投了多少票, 用于 `subVoteNum` 中验证投票数匹配 (algorithm.cpp L9340-9344):
```cpp
if(voteNum != voteNumber) {
    ERRORLOG("subVoteNum voteNum:{} voteNumber:{}", voteNum, voteNumber);
    return -5;
}
```

### 3.4 总投票者数

**Key**: `VOTE_TOTAL:{assetType}`
**Value**: uint64_t 投票者总数

用于统计参与度, 在 `addVoteCount` 中递增 (L9303):
```cpp
db.setTotalCountByAssetType(assetType, ++totalNumberOfVoters);
```

## 4. 锁定UTXO存储

### 4.1 锁定地址注册

**Key**: `LOCK_ADDR`
**Value**: 所有已锁定地址的列表

用于全局查询哪些地址有锁定状态。

### 4.2 锁定UTXO记录

**Key**: `LOCK_UTXO:{addr}:{assetType}` (assetType通常为"Vote")
**Value**: 该地址锁定UTXO的哈希列表

**查询**: `getLockAddrUtxo` (lock.cpp L56, algorithm.cpp L9576):
- Lock交易前检查是否已锁定: 若存在则拒绝 (重复锁)
- GetLockValue时遍历所有锁定UTXO计算投票权重

### 4.3 锁定UTXO生命周期

```
CreateLock:
  -> setLockAddr (添加地址到LOCK_ADDR)
  -> setLockAddrUtxo (添加UTXO到LOCK_UTXO:{addr}:Vote)

CreateUnlock:
  -> removeLockAddrUtxo (从LOCK_UTXO:{addr}:Vote移除指定UTXO)
  -> 若该地址无更多锁定UTXO: removeLockAddr (从LOCK_ADDR移除)
```

## 5. 签名与周期存储

### 5.1 签名统计

**Key**: `SIGN:{period}:{addr}`
**Value**: uint64_t 该地址在该周期内的签名次数

用于 `fetchAbnormalSignAddrListByPeriod` 计算平均签名量:
```cpp
dbReader.getSignCountByPeriod(period - 1, addr, signNumber);
```

### 5.2 签名地址列表

**Key**: `SIGN_ADDR:{period}`
**Value**: 该周期所有有签名记录的地址列表

```cpp
dbReader.getSignAddrByPeriod(period - 1, signatureAddresses);
```

### 5.3 区块数统计

**Key**: `BLOCK_NUM:{period}`
**Value**: 该周期内产生的区块总数

用于 `FundTrans` 中计算打包占比 (fund.cpp L114):
```cpp
dbReader.getBlockNumberByPeriod(period - 1, count);
```

### 5.4 Gas销毁统计

**Key**: `BURN:{period}`
**Value**: 该周期内累计的Gas费用总量

用于 `FundTrans` 中计算国库奖励 (fund.cpp L51):
```cpp
dbReader.getGasAmountByPeriod(period - 1, per_asset_type.first, gas_amount);
```

## 6. 存储操作汇总

### 6.1 治理交易写操作

| 交易类型 | DB写操作 | Key |
|---------|---------|-----|
| LOCK | setLockAddr, setLockAddrUtxo | LOCK_ADDR, LOCK_UTXO:{addr}:Vote |
| UNLOCK | removeLockAddrUtxo, (removeLockAddr) | LOCK_UTXO:{addr}:Vote, LOCK_ADDR |
| PROPOSAL | setProposalInfoByAssetType, setAssetType | PROPOSAL:{hash}, ASSET |
| VOTE | setApproveAddrsByAssetType / setAgainstAddrsByAssetType, setVoteCountByAssetType, setVoteCountByAddr, setTotalCountByAssetType | APPROVE:/AGAINST:, VOTE_CNT:, VOTE_ADDR:, VOTE_TOTAL: |
| REVOKEPROPOSAL | setRevokeProposalInfoByAssetType | REVOKE:{type} |

### 6.2 激励交易写操作

| 交易类型 | DB写操作 | Key |
|---------|---------|-----|
| BONUS | (UTXO变更, 标记已领取) | BAL:, UAH:, etc |
| FUND | (UTXO变更, 标记已领取) | BAL:, UAH:, etc. |

## 7. 存储一致性保证

### 7.1 投票计数一致性

`addVoteCount` 在一次调用中执行多个写入:
1. `setApproveAddrsByAssetType` / `setAgainstAddrsByAssetType` (投票类型)
2. `setVoteCountByAssetType` (累计票数)
3. `setVoteCountByAddr` (个人票数)
4. `setTotalCountByAssetType` (投票者总数)

这些操作在 `DBReadWriter` 上执行, 利用RocksDB的WriteBatch机制保证原子性。

### 7.2 锁定状态一致性

锁定和解锁操作分别修改:
- UTXO余额 (BAL:/UAH:/UB:)
- 锁定UTXO记录 (LOCK_UTXO:)
- 锁定地址列表 (LOCK_ADDR)

需要确认这些操作是否在一个事务中完成【需人工验证】。

### 7.3 奖励领取防重入

`evaluateBonusEligibility` 检查地址是否已领取当前周期奖励:
- 通过查询该地址在当前周期的已领取标记/记录
- 具体实现需查看UTXO核心验证逻辑【需人工验证】
