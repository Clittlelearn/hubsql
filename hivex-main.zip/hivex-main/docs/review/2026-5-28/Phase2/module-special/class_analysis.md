# Module 11 -- 类与结构体分析 (class_analysis.md)

**分析日期**: 2026-05-26
**置信度标注**: [高]=代码确认 [中]=合理推断 [低]=猜测/需验证

---

## 1. Config 类 (config.json 管理)

### 1.1 基本信息
- **文件**: `common/config.cpp/h` (~22KB 实现代码)
- **设计模式**: Singleton (通过 MagicSingleton 访问, `config.h:28`)
- **职责**: 运行时配置文件的解析/验证/过滤/热加载/持久化

### 1.2 内部数据结构

```cpp
// config.h:36-43
struct Info     { std::string logo; std::string name; };
struct Log      { bool console; std::string level; std::string path; };
struct HttpCallback { std::string ip; std::string path; uint32_t port; };
```

### 1.3 生命周期与状态机

```
构造 -> InitFile() -> _Parse(json) -> _Filter() -> _Verify() -> _Check()后台线程
                                                                      |
                                                            每3600s收集节点列表
```

**依据**: `config.h:84-95`, `config.cpp:45-101`, `config.cpp:647-659`

### 1.4 方法分析

#### 构造 (2个重载)
- `Config()` (config.h:84-88) -- 默认构造, InitFile返回void, 不报错误
- `Config(bool& flag)` (config.h:90-95) -- 带标志构造, 通过引用返回初始化结果
- **问题**: InitFile的返回值被忽略(默认构造), 且双构造存在重复代码【可信度:高】

#### InitFile (config.cpp:45-101)
- 流程: 读取现有config.json -> 不存在则用默认JSON创建 -> _Parse -> _Filter -> _Verify
- _Verify/_Filter 失败时删除文件并用默认JSON重建, 返回0(成功) -- 这会掩盖配置错误【可信度:高】
- Line 118有重复代码: `_httpCallback.path = json[...].get<std::string>()` 写了两次

#### _Parse (config.cpp:104-250)
- 逐个字段从JSON提取, 部分字段有 contains 检查兜底(如 enable_https, enable_mtls)
- SSL证书自动发现: 在 config_dir/certs/ 和 config_dir/build/bin/certs/ 搜索 fullchain.pem/cert.pem/privkey.pem (config.cpp:177-211)
- **SentinelNode IP探测**: 如果 kPublicIpAddress 为空, 遍历 sentinelNode 逐个探测 (config.cpp:224-231)

#### _Verify (config.cpp:275-303)
- 使用宏 `Dverify` 验证参数, 包含正则表达式校验
- 正则 `^[\u4E00-\u9FA5\x20-\x7E]+$` 对 name 只允许中文+ASCII可见字符, 对 logo 要求完整的URL格式
- **问题**: logo 正则 ~180字符, 可读性极差, 维护困难【可信度:高】

#### _Filter (config.cpp:305-346)
- 依次验证: IP格式 -> server_port -> http_port -> https_port(若启用) -> server IPs -> log -> http_callback
- port验证用正则 `^([1-9][0-9]{1,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])$` 即1-65535

#### FilterLog (config.cpp:561-586)
- log.level 必须匹配 `(debug|info|warn|error|trace|critical|off)` 之一 (大小写不敏感)
- **log.path 强制精确匹配 `./logs`** -- 这是强限制, 不允许其他路径【可信度:高】【需人工验证是否为设计意图】
- FilterBool 用 `std::is_same<bool, T>::value` 编译期检查, 但 log.console 运行时从JSON解析必然是bool类型, 该检查恒为true

#### _Check 后台线程 (config.cpp:647-659)
- 循环: sleep(2s) * 1800 次 = 3600秒(1小时)
- 每次循环内检查 `_exitThread` 原子变量
- 唤醒后调用 GetAllServerAddress() 刷新节点列表并覆写config.json
- **问题**: 整个循环期间无法被快速打断(只能每2秒检查一次退出标志)【可信度:高】

#### SetIP/SetPort/SetRPC (config.cpp:408-466)
- 每个方法都是: 读文件 -> 修改tmpJson -> 覆写文件 -> 更新内存成员
- **原子性问题**: 无文件备份, 无临时文件+rename, 写入中途崩溃会损坏配置文件【可信度:高】
- **线程安全问题**: tmpJson 成员变量无锁保护, 与 _Check 线程存在竞争【可信度:中】

### 1.5 问题清单

| # | 位置 | 现象 | 风险 | 触发场景 | 修复建议 | 验证方法 |
|---|------|------|------|---------|---------|---------|
| 1 | config.cpp:91-98 | _Verify/_Filter失败后删除文件用默认JSON重建并返回0 | 中 | 用户修改config格式错误时静默恢复默认 | _Verify失败应返回错误码, 向用户报告具体问题 | 手动写入非法IP到config.json后启动 |
| 2 | config.cpp:118 | `_httpCallback.path` 赋值重复 | 低 | 始终存在, 无害但浪费 | 删除重复行 | 代码审查 |
| 3 | config.cpp:648-653 | _Check 循环1800*2s才检查一次退出, 最大延迟2s | 低 | 程序退出时延迟, 不导致数据错误 | 使用 condition_variable 可快速唤醒 | 代码审查 |
| 4 | config.h:80 | tmpJson 成员变量无锁保护 | 中 | 多线程同时读写 SetIP/SetPort 与 _Check | 加 mutex 保护, 或去掉 tmpJson 成员变量 | 并发测试脚本 |
| 5 | config.cpp:408-465 | SetIP/SetPort 覆写文件无原子写入 | 中 | 写文件中途崩溃导致文件损坏 | 先写 .tmp 再 rename | 进程kill测试 + 文件完整性校验 |
| 6 | config.cpp:571-577 | log.path 强制精确匹配 `./logs` | 低 | 用户想自定义日志路径时被拒绝 | 改为路径格式校验而非值匹配 | 测试不同路径 |

---

## 2. Genesis 类 (genesis.json 管理)

### 2.1 基本信息
- **文件**: `common/genesis.cpp/h`
- **职责**: 创世配置文件加载/保存/编辑, 网络类型与名称一致性维护

### 2.2 核心设计

```cpp
// genesis.h:16-19
enum class NetworkType { Dev, Test, Primary };
```

**网络名称同步逻辑** (genesis.cpp 中的 SyncNetworkNameAndType):
- Dev <-> "devnet", Test <-> "testnet", Primary <-> "primarynet"
- SetNetworkType 自动更新 name 字段
- SetNetworkName 强制反向同步 type 字段 (不推荐直接调用)

### 2.3 构造逻辑 (genesis.cpp:6-35)
- 默认构造: 尝试从 "genesis.json" 加载, 失败则用默认值并保存
- 指定路径构造: 同上逻辑, 使用指定路径
- **问题**: 构造失败静默用默认值覆盖文件, 原有配置丢失【可信度:高】

### 2.4 与规范一致性
- 完全匹配 spec_dev.md:336-361 定义的 genesis.json 结构
- 额外增加了 NetworkType 枚举和 Getter/Setter 便利方法, 属于合理扩展

### 2.5 问题清单

| # | 位置 | 现象 | 风险 | 触发场景 | 修复建议 | 验证方法 |
|---|------|------|------|---------|---------|---------|
| 1 | genesis.cpp:7-18 | 默认构造加载失败静默用默认值覆盖原文件 | 高 | 文件格式错误或损坏时, 原有数据被覆盖 | 加载失败只使用内存默认值, 不覆写文件; 提示用户检查 | 手动损坏 genesis.json 后启动 |

---

## 3. TaskPool 类 (线程池)

### 3.1 基本信息
- **文件**: `common/task_pool.cpp/h`
- **底层库**: boost::threadpool::pool
- **设计**: Singleton, 8个子池, 总计255个线程

### 3.2 线程池配置 (task_pool.h:23-30)

| 池名 | 线程数 | 用途 |
|------|--------|------|
| caTaskPool_ | 15 | CA核心业务处理 |
| netTaskPool | 15 | 网络消息处理 |
| broadcastTaskPool | 10 | 广播消息 |
| txTaskPool | 50 | 交易处理 |
| syncTaskPool | 25 | 区块同步 |
| saveBlockTaskPool | 50 | 区块保存 |
| blockTaskPool | 50 | 区块处理 |
| workTaskPool | 50 | 通用工作 |
| **合计** | **255** | |

### 3.3 提交接口
- 每个子池提供两个重载: `ProtoCallBack` 三参数版本和 `std::function<void()>` 泛型版本
- 例如: `commitCaTask(ProtoCallBack, MessagePtr, MsgData)` 和 `commitCaTask<T>(T func)` (task_pool.h:71-84)

### 3.4 问题清单

| # | 位置 | 现象 | 风险 | 触发场景 | 修复建议 | 验证方法 |
|---|------|------|------|---------|---------|---------|
| 1 | task_pool.h:23-30 | 线程数硬编码为编译期常量 | 中 | 不同硬件环境下无法调优 | 部分关键池从config.json读取线程数 | 配置测试 |
| 2 | task_pool.h:23-30 | 无工作队列上限 | 中 | 任务提交速度超过处理速度时内存无限增长 | boost::threadpool 内部队列无界, 需评估是否需要背压机制 | 压力测试 |

---

## 4. advanced_menu (CLI交互)

### 4.1 基本信息
- **文件**: `ca/advanced_menu.cpp/h` (~141KB 实现, 估算3000+行)
- **职责**: 提供节点运维CLI交互界面

### 4.2 菜单层次结构 (advanced_menu.h:24-100)

```
MenuAdvanced [根菜单]
  ├── MenuCa           [CA操作] - 交易/合约/质押等
  │   ├── menuBlockInfo     [区块信息]
  │   ├── MenuTest          [测试]
  │   └── exportAndTestContract [合约导出测试]
  ├── MenuNet          [网络操作] - 节点管理/K桶/回显测试
  ├── RollBack         [回滚操作]
  ├── GetStakeList     [质押列表]
  ├── fetchExchequer   [国库查询]
  └── ...
```

### 4.3 关键问题
- **141KB 单体文件**: 菜单输入循环、参数解析、CA业务调用、结果显示全部混在一个文件中, 违反单一职责原则
- **无MVC分离**: 没有独立的 视图/控制器/模型 分层
- **全局变量 (advanced_menu.cpp:52-66)**: `jobs`, `jobs_index`, `errNodeIndex`, `test_pool` 等全局变量, 不支持多实例并发

### 4.4 问题清单

| # | 位置 | 现象 | 风险 | 触发场景 | 修复建议 | 验证方法 |
|---|------|------|------|---------|---------|---------|
| 1 | advanced_menu.cpp | 141KB 单体文件, 菜单+业务逻辑混合 | 高 | 维护困难, 单次改动影响面难以评估 | 拆分为 menu_controller / menu_view / ca_commands 三层 | 代码审查 |
| 2 | advanced_menu.cpp:52-66 | 模块级全局变量 | 中 | 并发调用时数据竞争 | 封装为类成员或使用局部变量 | 并发测试 |

---

## 5. Benchmark 类 (性能监控)

### 5.1 基本信息
- **文件**: `utils/bench_mark.cpp/h` (~30KB)
- **职责**: 全链路交易/区块处理性能统计

### 5.2 功能矩阵

| 功能 | 方法 | 数据结构 |
|------|------|---------|
| 交易发起批次 | transactionInitiateBatchSize | transactionInitiateMap |
| 交易发起速率统计 | addTransactionInitiateMap / calculateTransactionInitiateAmountPerSecond | transactionInitCache |
| 内存验证统计 | transactionMemVerifyMap | verifyTimeRecord.memVerifyTimestamp |
| DB验证统计 | transactionDbVerifyMap | verifyTimeRecord.dbVerifyTime |
| 签名接收统计 | addTransactionSignReceiveMap | transactionSignReceiveMap_ |
| 区块交易数量 | blockTransactionAmountMap | blockHasTransactionAmountMap |
| 区块验证时间 | addBlockVerifyMap | blockVerificationMap |
| 区块池保存 | addBlockPoolSaveMapStart / add_block_pool_save_map_end | blockPoolStorageMap |
| 内存监控 | Benchmark() 构造函数 | sysinfo (每60秒) |

### 5.3 开关机制
- `OpenBenchmark()` -- 开启并清空文件 benchmark.json
- `OpenBenchmarkAlt()` -- 开启第二套统计 benchmark2.json  
- `Clear()` -- 停止统计线程, 清零所有数据, sleep(5), 重新开始
- `PrintBenchmarkSummary(bool)` -- 打印汇总, 可选导出到文件

### 5.4 内存监控线程 (bench_mark.cpp:19-35)
- 构造时创建detached线程, 每60秒用 sysinfo 检查 freeram
- **问题**: detached线程无法优雅停止 (Clear()只设 _threadFlag=false, 最坏等60秒)【可信度:高】

### 5.5 问题清单

| # | 位置 | 现象 | 风险 | 触发场景 | 修复建议 | 验证方法 |
|---|------|------|------|---------|---------|---------|
| 1 | bench_mark.cpp:34 | memoryMonitorThread.detach() + sleep(60) | 低 | 进程退出时detach线程可能被强制终止, 但不影响数据 | 改用 joinable 线程 + 条件变量快速唤醒 | 压力测试 |
| 2 | bench_mark.cpp:77 | Clear()中 sleep(5) 后重置_benchmarkSwitch | 低 | 这5秒内 benchmarkSwitch=false, 丢弃统计请求 | 使用原子变量保证切换原子性 | 代码审查 |

---

## 6. TimeUtil / CTimer (时间/定时器)

### 6.1 TimeUtil 类
- **文件**: `utils/time_util.cpp/h`
- **依赖**: `utils/vxntp_helper.h` (底层NTP C库)

#### 接口分析

| 方法 | 返回类型 | 实现要点 | 可信度 |
|------|---------|---------|--------|
| GetNtpTimestamp(bool) | x_uint64_t (us) | 硬编码12个NTP服务器, 随机选取重试3次 | 高 |
| getNtpTimestampConfig() | x_uint64_t (us) | 从 ntp_server.conf 读取NTP服务器列表 | 高 |
| GetUTCTimestamp() | x_uint64_t (us) | gettimeofday 本地系统调用 | 高 |
| GetTimestamp() | x_uint64_t (us) | NTP优先, 失败回退UTC | 高 |
| SetLocalTime(uint64_t) | bool | settimeofday 系统调用 (需root) | 高 |

#### NTP信任依赖链 (time_util.cpp:90-123)
```
GetTimestamp()
  -> GetNtpTimestamp()   // 硬编码阿里云/腾讯云NTP
    -> ntp_get_time()    // vxntp_helper C库
      -> UDP socket to port 123
    -> 3次随机选择 + 重试
  -> fallback: GetUTCTimestamp()  // 本地时间
```

**安全问题**: 
- 硬编码NTP服务器不可配置, 私有化部署时需修改代码
- NTP协议无加密/认证, 可能受中间人攻击
- 失败回退本地时间, 可能导致不同节点时间偏差【可信度:高】

### 6.2 CTimer 类
- **文件**: `utils/timer.cpp/hpp`

#### 生命周期
```
构造 -> Start(msTime, task, bLoop, async)
  ├── async=true: 创建 std::thread, 循环 msTime 间隔执行 task
  │   └── Cancel -> notify_all -> join/detach -> m_bExpired=true
  └── async=false: 当前线程 sleep(msTime) 后同步执行一次
```

#### 关键状态变量 (timer.hpp:100-111)
- `m_bExpired` -- 任务是否已过期 (true=可启动新任务)
- `isTryExpired` -- 是否正在尝试过期 (用于取消)
- `m_bLoop` -- 是否循环执行
- `m_nCount` -- 已执行次数

#### Cancel 的可能bug (timer.cpp:65-81)
```cpp
void CTimer::Cancel() {
    if (m_bExpired || isTryExpired || !m_Thread) return;  // 已过期或无线程, 直接返回
    isTryExpired = true;
    m_ThreadCon.notify_all();
    if (m_Thread->joinable())
        m_Thread->join();
    else
        m_Thread->detach();  // 注意: detach 之后 m_Thread 仍然持有已 detach 的 thread 对象
}
```
**分析**: `m_Thread->detach()` 后 `m_Thread` 仍指向前一个已 detach 的 thread, 这是安全的行为(unique_ptr仍有效), 但语义上 joinable() 返回 false 说明线程在执行 Start 前就退出了, 此时 detach 也是安全的。

### 6.3 问题清单

| # | 位置 | 现象 | 风险 | 触发场景 | 修复建议 | 验证方法 |
|---|------|------|------|---------|---------|---------|
| 1 | time_util.cpp:93-101 | NTP服务器硬编码 | 中 | 私有化部署无法使用阿里云/腾讯云NTP | 改为从配置文件读取NTP服务器列表 | 配置测试 |
| 2 | time_util.cpp:126-137 | SetLocalTime 需要 root 权限但未检查返回值语义 | 低 | 非root运行时 settimeofday 静默失败 | 打印明确错误日志提示权限需求 | 非root启动 |

---

## 7. ContractDispatcher / DependencyManager / MessageDispatcher / TimerProcessor

### 7.1 四者关系图

```
ContractDispatcher (入口门面)
  ├── DependencyManager (依赖缓存与分组)
  │   ├── AddContractInfo(contract_hash, dependent_addresses)
  │   ├── AddMessageRequest(contract_hash, txmsg)
  │   ├── AddContractRequest(contract_hash, deps, txmsg)  // 原子添加
  │   ├── GetDependentData() -> grouped tx vectors [并查集分组]
  │   └── GroupData(vectors) -> 合并为8个组
  ├── MessageDispatcher (消息分发到打包节点)
  │   ├── DistributionContractTransactionRequest() -> VRF选择打包节点
  │   └── SendTransactionInfoRequest() -> 网络发送
  ├── TimerProcessor (定时触发处理)
  │   └── ProcessingFunc() -> 周期调用 Process() 收集/分发
  └── EventManager (事件通知)
      └── Subscribe/Publish (block_hash) -- 用于依赖清除通知
```

### 7.2 DependencyManager 核心算法 (dispatchtx.cpp:113-177)
```
GetDependentData():
  1. 加锁拷贝 dep_cache + msg_cache
  2. 构建并查集 (Union-Find), 共享依赖地址的交易合并为一组
  3. 按 root 分组输出 vector<vector<TxMsgReq>>
```

**并查集逻辑** (dispatchtx.cpp:31-59):
- `FindDependencyRoot` 递归查找根节点 (路径压缩)
- `UnionDependencyTx` 合并两个集合
- 目的: 确保共享依赖地址的合约交易被发往同一打包节点, 按其排序顺序执行

### 7.3 TimerProcessor 周期 (dispatchtx.h:109-124)
- `kContractWaitingTime = 3 * 1000000ULL` (3百万微秒 = 3秒)
- Start() 启动定时线程, ProcessingFunc() 周期唤醒

### 7.4 问题清单

| # | 位置 | 现象 | 风险 | 触发场景 | 修复建议 | 验证方法 |
|---|------|------|------|---------|---------|---------|
| 1 | dispatchtx.h:66-95 | DependencyManager中大量方法被注释 | 低 | 注释代码使文件膨胀, 混淆维护者 | 清理注释代码, 用git历史追溯 | 代码审查 |
| 2 | contract_transaction_cache.h:1-96 | 整个头文件被注释 | 高 | 规范文档(spec_dev.md:1120-1161)仍描述此机制, 与实现不一致 | 更新规范文档, 或恢复该机制 | 功能测试 |

---

## 8. NTP 时间同步系统 (vxntp_helper)

### 8.1 基本信息
- **文件**: `utils/vxntp_helper.cpp/h` (~30KB C代码)
- **语言**: C (extern "C" 接口)
- **协议**: 标准NTP v3, UDP port 123

### 8.2 核心数据结构 (vxntp_helper.h:27-57)
- `x_ntp_timestamp_t` -- NTP时间戳 (秒+分数, 1900年起)
- `x_ntp_timeval_t` -- 类timeval结构 (秒+微秒, 1970年起)
- `x_ntp_time_context_t` -- 人类可读时间 (年月日时分秒毫秒, 位域)

### 8.3 精度
- NTP时间戳精度: 100纳秒 (100ns)
- 但实际NTP网络精度约 1-10ms
- `GetNtpTimestamp()` 返回微秒级 (`timev/10`)

### 8.4 问题清单

| # | 位置 | 现象 | 风险 | 触发场景 | 修复建议 | 验证方法 |
|---|------|------|------|---------|---------|---------|
| 1 | vxntp_helper.h:17-19 | NTP_OUTPUT 宏控制调试输出, 默认开启 | 低 | 生产环境打印过多调试信息 | 生产构建时设为0 | 编译检查 |
| 2 | time_util.cpp:75 | getNtpTimestampConfig 中 ntp_server.conf 打开失败只打印cout, 无错误日志 | 低 | 配置文件不存在时静默返回0 | 加入ERRORLOG | 删除ntp_server.conf测试 |

---

## 9. 工具类摘要

### 9.1 压缩 (Compress)
- **文件**: `utils/compress.cpp/h`
- 构造即压缩/解压: `Compress(rawData)` 调用 compressFunc(), `Compress(data, len)` 调用 uncompressFunc()
- **问题**: 构造即处理, 无法延迟或复用, 不使用何压缩算法需查看实现【可信度:低】

### 9.2 字符串 (StringUtil)
- **文件**: `utils/string_util.cpp/h`
- Trim / SplitString / SplitStringToSet / StringToNumber
- concat 拼接 + pop_back 移除尾部多余分隔符

### 9.3 守护进程 (daemon.h)
- **文件**: `utils/daemon.h`
- double-fork + setsid + umask(0) + 标准输入输出重定向到 /dev/null
- Crash-loop保护: 60秒内超过5次快速重启则放弃 (MAX_CRASHES_IN_60S = 5)
- **问题**: 硬编码 MOONMESH_WORKDIR = "/var/lib/moonmesh", 不同部署环境需修改【可信度:高】

### 9.4 进程控制 (init.cpp/h)
- **文件**: `utils/init.cpp/h`
- PID文件: 创建 /tmp/moonmesh.pid, 检测已有进程, 僵尸进程自动清理
- 信号处理: init_signal_handlers() 设置 SIGINT/SIGTERM 等
- 文件锁: flock 防止多实例

### 9.5 控制台 (console)
- **文件**: `utils/console.cpp/h`
- ANSI颜色码: RED, GREEN, YELLOW, RESET 等宏
- 用于 config.cpp, advanced_menu.cpp 中的彩色错误提示

### 9.6 命令行解析 (cmdline)
- **文件**: `utils/cmdline.cpp/h`
- `parse_cmdline_args(argc, argv)` 单一接口
- 具体参数需查看实现【可信度:低】

### 9.7 临时日志 (tmp_log)
- **文件**: `utils/tmp_log.cpp/h`
- `errorL/debugL/infoL` 三个自定义宏, 使用 printf 风格 %s 占位符
- `Sutil::Format` 模板实现可变参数格式化
- 与 logging.h 体系并存, 用于快速调试输出
