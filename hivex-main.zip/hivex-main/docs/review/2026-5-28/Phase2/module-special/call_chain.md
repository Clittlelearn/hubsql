# Module 11 -- 调用链分析 (call_chain.md)

**分析日期**: 2026-05-26
**依据**: 代码调用关系静态分析 [可信度: 高]

---

## 1. 配置加载调用链

### 1.1 InitConfig -> Config 构造 -> InitFile -> _Parse -> _Verify -> _Check 线程

```mermaid
sequenceDiagram
    participant Main as main()
    participant Config as Config(bool&)
    participant IF as InitFile()
    participant Parse as _Parse(json)
    participant Filter as _Filter()
    participant Verify as _Verify()
    participant Check as _Check() 线程

    Main->>Config: Config(bool& flag) [config.h:90]
    Config->>IF: InitFile() [config.h:92]
    
    IF->>IF: filesystem::absolute("config.json") [config.cpp:50]
    Note over IF: 计算绝对路径 _configPath
    
    IF->>IF: ifstream f("config.json") [config.cpp:60]
    alt 文件存在
        IF->>IF: read string + json::parse [config.cpp:64-65]
        IF->>Parse: _Parse(tmpJson) [config.cpp:66]
        Parse->>Parse: 提取 _ip, _httpCallback, _httpPort... [config.cpp:114-241]
        Parse->>Parse: SSL证书自动发现 [config.cpp:163-211]
        Parse->>Parse: SetIP(_ip) [config.cpp:248]
    else 文件不存在
        IF->>IF: 用默认 kConfigJson 创建文件 [config.cpp:76-87]
        IF->>Parse: _Parse(tmpJson) [config.cpp:80]
    end
    
    IF->>Filter: _Filter() [config.cpp:90]
    Filter->>Filter: FilterIp(_ip) [config.cpp:307]
    Filter->>Filter: FILTER_SERVER_PORT(_serverPort) [config.cpp:312]
    Filter->>Filter: filter_http_port(_httpPort) [config.cpp:317]
    Filter->>Filter: filter_server_ip(各server) [config.cpp:328-333]
    Filter->>Filter: FilterLog(_log) [config.cpp:336]
    Filter->>Filter: handleFilterHttpCallback [config.cpp:341]
    
    IF->>Verify: _Verify() [config.cpp:90]
    Verify->>Verify: Dverify(_info, name, ...) [config.h:254宏]
    Verify->>Verify: Dverify(_info, logo, ...) [config.h:254宏]
    
    alt _Filter或_Verify失败
        IF->>IF: 删除config.json, 写入默认JSON [config.cpp:92-97]
        Note over IF: 返回0 (成功), 掩盖错误
    end
    
    IF-->>Config: return 0 (或 -1/-2)
    Config-->>Main: flag = (ret == 0)
    
    Config->>Check: 启动 _Check() 线程 [config.h:94]
    activate Check
    loop 每3600秒
        Check->>Check: sleep(2s) * 1800 [config.cpp:651]
        Check->>Check: GetAllServerAddress() [config.cpp:656]
        Note over Check: 收集节点列表, 覆写config.json server字段
    end
    deactivate Check
```

**关键代码位置**:
- Config构造: `config.h:84-95`
- InitFile: `config.cpp:45-101`
- _Parse: `config.cpp:104-250`
- _Filter: `config.cpp:305-346`
- _Verify: `config.cpp:290-303`
- _Check: `config.cpp:647-659`

---

## 2. CLI交互调用链

### 2.1 菜单选择 -> 命令分发 -> CA函数调用 -> 结果显示

```mermaid
flowchart TB
    subgraph Entry["入口层"]
        A[main()] --> B["MenuAdvanced()<br/>advanced_menu.cpp"]
        B --> C{用户输入选择}
    end
    
    subgraph MenuLayer["菜单层"]
        C -->|1| D["MenuCa()<br/>CA操作菜单"]
        C -->|2| E["MenuNet()<br/>网络操作菜单"]
        C -->|3| F["RollBack()<br/>回滚操作"]
        C -->|4| G["GetStakeList()<br/>质押列表"]
        C -->|5| H["fetchExchequer()<br/>国库查询"]
        
        D -->|子菜单| D1["menuBlockInfo()"]
        D -->|子菜单| D2["exportAndTestContract()"]
        D -->|子菜单| D3["MenuTest()"]
    end
    
    subgraph ActionLayer["业务操作层"]
        D1 --> AA["printRocksdbInfo()<br/>pretty_print.cpp"]
        D2 --> AB["readContractJson()<br/>解析合约JSON"]
        D3 --> AC["批量交易创建"]
        F --> AD["回滚算法调用"]
        G --> AE["查询质押UTXO"]
        H --> AF["查询奖励信息"]
    end
    
    subgraph OutputLayer["输出层"]
        AA --> BA["PrintBlock() / PrintTx()<br/>pretty_print.cpp"]
        AB --> BB["contract_transaction_request()<br/>ca/contract.cpp"]
        AC --> BC["交易发送确认<br/>网络层"]
        AD --> BD["std::cout 输出结果"]
        AE --> BE["std::cout 输出结果"]
        AF --> BF["std::cout 输出结果"]
    end
    
    style Entry fill:#4a90d9,color:#fff
    style MenuLayer fill:#67b168,color:#fff
    style ActionLayer fill:#e8a838,color:#fff
    style OutputLayer fill:#d94a4a,color:#fff
```

**关键代码位置**:
- 入口: `advanced_menu.cpp` -> `MenuAdvanced()` 
- 引用头文件: `advanced_menu.cpp:1-50` (大量include)
- 输出: `utils/pretty_print.cpp/h`

---

## 3. 合约依赖检查调用链

### 3.1 ContractDispatcher -> DependencyManager -> CanSendTransaction -> ClearDependency

```mermaid
sequenceDiagram
    participant Client as 合约调用方
    participant CD as ContractDispatcher
    participant DM as DependencyManager
    participant TP as TimerProcessor
    participant MD as MessageDispatcher
    participant Net as 网络层(P2P)
    participant EM as EventManager

    Client->>CD: AddContractRequest(hash, deps, msg) [dispatchtx.cpp:75]
    CD->>DM: AddContractRequest(hash, deps, msg) [dispatchtx.cpp:76]
    DM->>DM: scoped_lock(dep_mutex_, msg_mutex_) [dispatchtx.cpp:104]
    DM->>DM: contract_dep_cache_[hash] = deps [dispatchtx.cpp:105]
    DM->>DM: contract_msg_cache_[hash] = msg.txmsgreq() [dispatchtx.cpp:106]
    Note over DM: 原子存储依赖+消息
    
    CD->>TP: Start() [dispatchtx.cpp:80]
    activate TP
    TP->>TP: 启动 timer_thread_ [dispatchtx.cpp:113]
    loop 每 kContractWaitingTime (3s)
        TP->>CD: Process() [dispatchtx.cpp:79]
        CD->>DM: GetDependentData() [dispatchtx.cpp:113]
        
        DM->>DM: scoped_lock 拷贝 dep_cache + msg_cache [dispatchtx.cpp:119-122]
        Note over DM: 构建并查集 (Union-Find)
        
        alt 有依赖冲突
            DM->>DM: FindDependencyRoot() 递归查找 [dispatchtx.cpp:31-47]
            DM->>DM: UnionDependencyTx() 合并集合 [dispatchtx.cpp:49-59]
            Note over DM: 共享依赖的交易归入同一 root
        end
        
        DM->>DM: 按 root 分组输出 [dispatchtx.cpp:154-176]
        DM-->>CD: vector<vector<TxMsgReq>>
        
        CD->>MD: GroupData(tx_vectors) [dispatchtx.cpp:179-208]
        Note over MD: 合并为8个组 (PARTS=8)
        
        CD->>MD: DistributionContractTransactionRequest() [dispatchtx.cpp:220]
        MD->>MD: FindContractPackNode() VRF选择打包节点 [dispatchtx.cpp:243]
        MD->>MD: 构建 ContractPackagerMsg [dispatchtx.cpp:263]
        
        alt 本地即打包节点
            MD->>MD: handleContractPackagerMessage() [dispatchtx.cpp:347]
        else 远程打包节点
            MD->>Net: SendTransactionInfoRequest() [dispatchtx.cpp:260]
            Net->>Net: 网络发送 ContractPackagerMsg
        end
    end
    
    Note over EM: 交易确认后发布事件
    EM->>DM: Publish("TransactionConfirmed", block_hash)
    Note over DM: 清除该交易的依赖缓存
    deactivate TP
```

**关键代码位置**:
- ContractDispatcher: `dispatchtx.cpp:63-85`
- DependencyManager::GetDependentData: `dispatchtx.cpp:113-177`
- 并查集算法: `dispatchtx.cpp:31-59`
- MessageDispatcher::DistributionContractTransactionRequest: `dispatchtx.cpp:220-258`
- MessageDispatcher::SendTransactionInfoRequest: `dispatchtx.cpp:260-349`
- TimerProcessor: `dispatchtx.h:109-124`

---

## 4. NTP时间同步调用链

### 4.1 CheckNtpTime -> vxntp_helper -> 时间校正

```mermaid
flowchart TB
    subgraph EntryPoint["入口"]
        A["系统启动/定时检查"]
    end
    
    subgraph TimeUtil["TimeUtil 层"]
        B["GetTimestamp()<br/>time_util.cpp:46"]
        B --> C{"GetNtpTimestamp()<br/>time_util.cpp:90"}
        C -->|成功| D["返回NTP时间 (us)"]
        C -->|失败| E["return time"]
        C -->|失败| F["GetUTCTimestamp()<br/>time_util.cpp:32<br/>gettimeofday 本地系统调用"]
    end
    
    subgraph NTPLayer["NTP协议层"]
        C --> C1["遍历12个硬编码NTP服务器<br/>time_util.cpp:93-101"]
        C1 --> C2["rand() 随机选择<br/>time_util.cpp:111"]
        C2 --> C3["ntp_get_time(host, 123, 1000, &timev)<br/>vxntp_helper C库"]
        C3 -->|成功| C4["timev / 10 微秒转换<br/>time_util.cpp:123"]
        C3 -->|失败| C5{重试次数 < 3}
        C5 -->|是| C1
        C5 -->|否| F
    end
    
    subgraph SyncLocal["本地时钟同步"]
        C4 -->|is_sync=true| G["SetLocalTime(timev/10)<br/>time_util.cpp:126"]
        G --> G1["settimeofday(&tv, NULL)<br/>需要 root 权限<br/>time_util.cpp:133"]
    end
    
    subgraph NTPConfig["配置文件NTP"]
        H["getNtpTimestampConfig()<br/>time_util.cpp:56"]
        H --> H1["ifstream ntp_server.conf<br/>time_util.cpp:60"]
        H1 --> H2["遍历NTP服务器<br/>time_util.cpp:75"]
        H2 --> H3["ntp_get_time()<br/>3次重试<br/>time_util.cpp:75-85"]
    end
    
    style EntryPoint fill:#4a90d9,color:#fff
    style TimeUtil fill:#67b168,color:#fff
    style NTPLayer fill:#e8a838,color:#fff
    style SyncLocal fill:#d94a4a,color:#fff
    style NTPConfig fill:#8a6dba,color:#fff
```

**关键代码位置**:
- GetTimestamp: `time_util.cpp:46-53`
- GetNtpTimestamp: `time_util.cpp:90-123`
- getNtpTimestampConfig: `time_util.cpp:56-87`
- SetLocalTime: `time_util.cpp:126-137`
- ntp_get_time: `vxntp_helper.cpp/h` (底层C函数)

---

## 5. 定时器机制调用链

### 5.1 CTimer -> Start -> 线程创建 -> 回调执行

```mermaid
sequenceDiagram
    participant Caller as 调用方
    participant Timer as CTimer
    participant Thread as std::thread
    participant Task as 用户回调

    Caller->>Timer: Start(msTime, task, bLoop, async) [timer.cpp:16]
    
    alt m_bExpired == false 或 isTryExpired == true
        Timer-->>Caller: return false (任务仍在运行) [timer.cpp:18]
    end
    
    Timer->>Timer: m_bExpired = false [timer.cpp:19]
    Timer->>Timer: m_bLoop = bLoop [timer.cpp:20]
    Timer->>Timer: m_nCount = 0 [timer.cpp:21]
    
    alt async == true
        Timer->>Timer: DeleteThread() [timer.cpp:24]
        Note over Timer: join旧线程 + reset
        
        Timer->>Thread: m_Thread.reset(new std::thread([=]{...})) [timer.cpp:25]
        activate Thread
        
        loop 循环条件: !isTryExpired
            Thread->>Thread: m_ThreadCon.wait_for(msTime) [timer.cpp:35]
            Note over Thread: 等待 msTime 毫秒
            
            alt isTryExpired == false
                Thread->>Task: task() [timer.cpp:37]
                Task-->>Thread: 回调完成
                Thread->>Thread: m_nCount++ [timer.cpp:39]
                
                alt bLoop == false (单次)
                    Thread->>Thread: break [timer.cpp:41]
                end
            end
        end
        
        Thread->>Thread: m_bExpired = true [timer.cpp:46]
        Thread->>Thread: isTryExpired = false [timer.cpp:47]
        deactivate Thread
        
    else async == false (同步)
        Timer->>Timer: sleep_for(msTime) [timer.cpp:54]
        
        alt isTryExpired == false
            Timer->>Task: task() [timer.cpp:56]
            Task-->>Timer: 回调完成
        end
        
        Timer->>Timer: m_bExpired = true [timer.cpp:58]
        Timer->>Timer: isTryExpired = false [timer.cpp:59]
    end
    
    Timer-->>Caller: return true [timer.cpp:62]
```

**Cancel流程**:
```mermaid
sequenceDiagram
    participant Caller as 调用方
    participant Timer as CTimer
    participant Thread as std::thread
    
    Caller->>Timer: Cancel() [timer.cpp:65]
    
    alt m_bExpired == true 或 isTryExpired == true 或 !m_Thread
        Timer-->>Caller: return (无需取消) [timer.cpp:67-68]
    end
    
    Timer->>Timer: isTryExpired = true [timer.cpp:71]
    Timer->>Timer: m_ThreadCon.notify_all() [timer.cpp:72]
    Note over Timer: 唤醒 wait_for
    
    alt m_Thread->joinable()
        Timer->>Thread: m_Thread->join() [timer.cpp:74]
        Note over Timer: 等待线程退出
    else
        Timer->>Thread: m_Thread->detach() [timer.cpp:78]
        Note over Timer: 分离线程
    end
```

**关键代码位置**:
- Start: `timer.cpp:16-63`
- Cancel: `timer.cpp:65-81`
- DeleteThread: `timer.cpp:83-90`
- 头文件定义: `timer.hpp:1-116`

---

## 6. 合约交易缓存(已废弃) vs 新依赖分发对比

```mermaid
flowchart LR
    subgraph Old["旧机制 (废弃 - contract_transaction_cache.h)"]
        O1["AddFailedTransaction(tx, msg)"] --> O2["存入 _cachedTransactions map"]
        O2 --> O3["每1秒 _CheckCachedTransactions()"]
        O3 --> O4{timeInCache >= 15s?}
        O4 -->|是| O5["强制发送"]
        O4 -->|否| O6{CanSendTransaction?}
        O6 -->|是| O7["清除依赖, 发送"]
        O6 -->|否| O8["继续等待"]
    end
    
    subgraph New["新机制 (dispatchtx.cpp)"]
        N1["AddContractRequest(hash, deps, msg)"] --> N2["原子存储 dep_cache + msg_cache"]
        N2 --> N3["每3秒 TimerProcessor::ProcessingFunc()"]
        N3 --> N4["GetDependentData() 并查集分组"]
        N4 --> N5["GroupData() 8组"]
        N5 --> N6["VRF选择打包节点"]
        N6 --> N7["网络发送 ContractPackagerMsg"]
    end
    
    style Old fill:#ccc,stroke-dasharray:5 5
    style New fill:#67b168,color:#fff
```

**旧机制文件**: `ca/contract_transaction_cache.h` (全部注释, 行1-96)
**新机制文件**: `ca/dispatchtx.cpp/h` (行1-349)
**规范文档**: spec_dev.md:1120-1161 仍描述旧机制, **需更新规范**。

---

## 7. 性能基准收集调用链

```mermaid
flowchart TB
    subgraph Entry["Benchmark开关"]
        A["OpenBenchmark()<br/>bench_mark.cpp:38"]
        A --> A1["benchmarkSwitch = true"]
        A1 --> A2["创建/清空 benchmark.json"]
    end
    
    subgraph Collect["数据收集点"]
        B1["transactionInitiateBatchSize"] --> C1["_batchSize"]
        B2["addTransactionInitiateMap<br/>记录交易发起时间"] --> C2["transactionInitiateMap"]
        B3["transactionMemVerifyMap<br/>记录内存验证时间"] --> C3["transactionVerificationMap"]
        B4["transactionDbVerifyMap<br/>记录DB验证时间"] --> C4["transactionVerificationMap"]
        B5["add_agent_transaction_receive_map"] --> C5["agentTransactionReceiveMap_"]
        B6["addTransactionSignReceiveMap"] --> C6["transactionSignReceiveMap_"]
        B7["blockTransactionAmountMap"] --> C7["blockHasTransactionAmountMap"]
        B8["addBlockVerifyMap"] --> C8["blockVerificationMap"]
        B9["addBlockPoolSaveMapStart/End"] --> C9["blockPoolStorageMap"]
    end
    
    subgraph Calculate["计算与输出"]
        C1 & C2 --> D1["calculateTransactionInitiateAmountPerSecond<br/>计算TPS"]
        C3 & C4 --> D2["聚合验证时间"]
        D1 & D2 --> E["PrintBenchmarkSummary(exportToFile)<br/>bench_mark.cpp:153"]
        E --> E1["输出到控制台"]
        E --> E2["追加到 benchmark.json"]
    end
    
    subgraph Cleanup["清理"]
        F["Clear()<br/>bench_mark.cpp:68"]
        F --> F1["_threadFlag=false"]
        F --> F2["sleep(5)"]
        F --> F3["清空所有map和atomic"]
        F --> F4["benchmarkSwitch=true 重新开始"]
    end
    
    style Entry fill:#4a90d9,color:#fff
    style Collect fill:#e8a838,color:#fff
    style Calculate fill:#67b168,color:#fff
    style Cleanup fill:#d94a4a,color:#fff
```

**关键代码位置**: 
- Benchmark构造: `bench_mark.cpp:18-36`
- OpenBenchmark: `bench_mark.cpp:38-51`
- Clear: `bench_mark.cpp:68-91`
- 数据结构定义: `bench_mark.h:199-293`
