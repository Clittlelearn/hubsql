# Module 11 -- 状态流转分析 (state_flow.md)

**分析日期**: 2026-05-26
**依据**: 代码状态变量 + 生命周期分析 [可信度: 高]

---

## 1. 配置状态流转

### 1.1 Config 生命周期状态

```mermaid
stateDiagram-v2
    [*] --> 未加载: 进程启动
    
    未加载 --> 读取中: Config() 构造 / InitFile()
    
    读取中 --> 文件不存在: f.good() == false
    读取中 --> 解析中: 文件存在, 读取成功
    
    文件不存在 --> 生成默认: 用 kConfigJson 创建文件
    生成默认 --> 解析中: _Parse(tmpJson)
    
    解析中 --> 验证中: _Parse 成功返回0
    解析中 --> 验证中: _Parse 失败但继续 (_Parse返回非0不阻止)
    
    验证中 --> 已加载: _Filter()==0 && _Verify()==0
    验证中 --> 回退默认: _Filter或_Verify失败
    
    回退默认 --> 已加载: 删除文件 -> 写入默认JSON -> 返回0
    Note right of 回退默认: config.cpp:91-98<br/>错误被静默吞掉
    
    已加载 --> 监控中: _Check() 线程启动
    Note right of 监控中: config.h:94<br/>每3600s检查一次
    
    监控中 --> 节点收集: GetAllServerAddress()
    节点收集 --> 配置覆写: 读取PeerNode列表 + sentinelNode
    配置覆写 --> 监控中: 覆写 config.json server字段
    
    监控中 --> 已终止: _exitThread = true (析构)
    已终止 --> [*]: _thread.join()
```

**关键代码依据**:
- 构造启动监控: `config.h:84-95` -- `_thread = std::thread(std::bind(&Config::_Check, this))`
- _Check循环: `config.cpp:647-659`
- 回退默认: `config.cpp:91-98`
- 析构终止: `config.h:97-104`

### 1.2 tmpJson 并发访问状态

```mermaid
stateDiagram-v2
    [*] --> 初始化: Config构造, InitFile填入JSON
    
    初始化 --> 读: _Check() 读取server列表
    初始化 --> 写: SetIP/SetPort/SetRPC 修改字段
    
    读 --> 读: 循环中
    写 --> 写文件: 覆写 config.json + 更新内存成员
    
    写文件 --> 读: 释放后_Check可再次读取
    
    note right of 读: 无锁保护<br/>与写线程存在竞争
    note right of 写: config.cpp:408-466<br/>无原子写入保护
```

**风险**: `tmpJson` 成员变量 (config.h:80) 在 `_Check` 线程的 `GetAllServerAddress` 中读写, 同时在主线程的 `SetIP/SetPort/SetRPC` 中读写, **无任何 mutex 保护**。【可信度:中, 需验证实际并发调用是否会发生】

---

## 2. CLI菜单状态流转

### 2.1 菜单层次状态

```mermaid
stateDiagram-v2
    [*] --> 主菜单: 启动CLI / MenuAdvanced()
    
    主菜单 --> CA菜单: 选择"1" / MenuCa()
    主菜单 --> 网络菜单: 选择"2" / MenuNet()
    主菜单 --> 回滚: 选择"3" / RollBack()
    主菜单 --> 质押列表: 选择"4" / GetStakeList()
    主菜单 --> 国库: 选择"5" / fetchExchequer()
    主菜单 --> 退出: 选择"0" / return
    
    CA菜单 --> 区块信息: 子选择 / menuBlockInfo()
    CA菜单 --> 合约测试: 子选择 / exportAndTestContract()
    CA菜单 --> 测试菜单: 子选择 / MenuTest()
    CA菜单 --> 主菜单: 返回上级 / return
    
    区块信息 --> 数据查询: 输入参数(起止高度等)
    数据查询 --> 结果显示: printRocksdbInfo / PrintBlock
    结果显示 --> 区块信息: 等待下一次输入
    
    合约测试 --> 读合约JSON: readContractJson()
    读合约JSON --> 批量执行: 遍历jobs数组
    批量执行 --> 结果显示: std::cout
    结果显示 --> 合约测试: 等待下一次输入
    
    网络菜单 --> 操作选择: 等待输入
    操作选择 --> 显示K桶: displayKBuckets()
    操作选择 --> 踢出节点: kickOutNode()
    操作选择 --> 回显测试: TestEcho()
    操作选择 --> 网络菜单: return
    
    退出 --> [*]
```

**关键代码位置**:
- 主菜单入口: `advanced_menu.cpp` -> `MenuAdvanced()`
- 各子菜单: `advanced_menu.h:24-100` 中定义的函数签名

### 2.2 合约测试并发状态 (advanced_menu.cpp:52-66)

```mermaid
stateDiagram-v2
    [*] --> 空闲: 全局变量初始化
    
    空闲 --> 加载中: readContractJson(file)
    加载中 --> 就绪: JSON解析成功, jobs已填充
    
    就绪 --> 执行中: 循环遍历jobs
    执行中 --> 线程池提交: test_pool.schedule(task)
    线程池提交 --> 执行中: jobs_index++
    
    执行中 --> 完成: jobs_index >= jobs.size()
    完成 --> 空闲: 等待下一指令
    
    执行中 --> 出错: 合约调用失败
    出错 --> 执行中: errNodeIndex++, 继续下一任务
    
    note right of 执行中: 全局变量 jobs_index/errNodeIndex<br/>无锁自增, 存在数据竞争
```

**风险**: `jobs_index` 和 `errNodeIndex` 是 `std::atomic<int>` 类型, 线程安全。但 `jobs` 是普通 `std::vector`, 在线程池并发读取时需确保写入已完成。【可信度:中】

---

## 3. 合约依赖状态流转

### 3.1 依赖管理状态

```mermaid
stateDiagram-v2
    [*] --> 空闲: DependencyManager初始化
    
    空闲 --> 接收合约请求: AddContractRequest(hash, deps, msg)
    接收合约请求 --> 缓存中: 加锁写入 dep_cache + msg_cache
    
    缓存中 --> 定时收集: TimerProcessor 3秒触发
    定时收集 --> 依赖分析: GetDependentData()
    
    依赖分析 --> 无冲突: 各交易依赖地址不重叠
    依赖分析 --> 有冲突: 两个交易共享依赖地址
    
    无冲突 --> 分组: 独立交易各自成组
    有冲突 --> 并查集合并: UnionDependencyTx()
    并查集合并 --> 分组: 合并为一组
    
    分组 --> 合并分组: GroupData (8组)
    合并分组 --> VRF选择节点: FindContractPackNode
    
    VRF选择节点 --> 本地处理: 打包节点=本地
    VRF选择节点 --> 远程发送: 打包节点=远程
    
    本地处理 --> handleContractPackagerMessage
    远程发送 --> 网络发送 ContractPackagerMsg
    
    本地处理 --> 已分发: 消息处理完成
    远程发送 --> 已分发: 发送完成
    
    已分发 --> 等待确认: 交易上链
    等待确认 --> 清除依赖: EventManager::Publish("TransactionConfirmed")
    清除依赖 --> 空闲: 依赖缓存清除
    
    空闲 --> 接收合约请求: 新的合约调用
```

**关键代码位置**:
- AddContractRequest: `dispatchtx.cpp:102-111`
- GetDependentData: `dispatchtx.cpp:113-177`
- GroupData: `dispatchtx.cpp:179-208`
- DistributionContractTransactionRequest: `dispatchtx.cpp:220-258`
- SendTransactionInfoRequest: `dispatchtx.cpp:260-349`

### 3.2 依赖缓存并存状态

```mermaid
stateDiagram-v2
    state "contract_dep_cache_" as dep
    state "contract_msg_cache_" as msg
    
    [*] --> dep: AddContractInfo
    [*] --> msg: AddMessageRequest
    
    dep --> 双缓存就绪: AddContractRequest 同时写入两个缓存
    msg --> 双缓存就绪: AddContractRequest 同时写入两个缓存
    
    Note right of 双缓存就绪: scoped_lock 保证原子性<br/>dispatchtx.cpp:104
    
    双缓存就绪 --> 数据快照: GetDependentData() scoped_lock拷贝
    数据快照 --> 分组处理: 并查集分组
    分组处理 --> 分发发送: MessageDispatcher
```

---

## 4. 定时器状态流转

### 4.1 CTimer 生命周期

```mermaid
stateDiagram-v2
    [*] --> 就绪: CTimer构造<br/>m_bExpired=true, isTryExpired=false
    
    就绪 --> 运行中: Start(msTime, task, loop, async)
    Note right of 就绪: m_bExpired=true 表示可接受新任务
    
    运行中 --> 等待中: wait_for(msTime) 阻塞
    等待中 --> 执行中: 超时唤醒, !isTryExpired
    执行中 --> 执行回调: task()
    执行回调 --> 计数: m_nCount++
    
    计数 --> 等待中: m_bLoop==true, !isTryExpired
    计数 --> 已过期: m_bLoop==false
    
    已过期 --> 就绪: m_bExpired=true, isTryExpired=false
    
    运行中 --> 取消中: Cancel() 被调用
    取消中 --> 唤醒: notify_all()
    唤醒 --> 已过期: join() 等待线程退出
    
    运行中 --> 析构: ~CTimer() 自动Cancel
    析构 --> 已过期
    析构 --> [*]
```

**关键代码位置**:
- 构造: `timer.cpp:6-9` (m_bExpired=true)
- Start: `timer.cpp:16-63`
- Cancel: `timer.cpp:65-81`
- ~CTimer: `timer.cpp:11-14` (调用Cancel)

### 4.2 Start 同步 vs 异步

```mermaid
stateDiagram-v2
    [*] --> 选择模式: Start(msTime, task, bLoop, async)
    
    选择模式 --> 异步线程: async == true
    选择模式 --> 同步阻塞: async == false
    
    异步线程 --> 创建线程: DeleteThread() + reset(new thread)
    创建线程 --> 等待循环: wait_for(msTime)
    
    同步阻塞 --> 当前线程sleep: sleep_for(msTime)
    当前线程sleep --> 执行: !isTryExpired
    执行 --> 完成: task() 完成
    完成 --> [*]
    
    Note right of 异步线程: 可被 Cancel() 中断
    Note right of 同步阻塞: Cancel() 无效<br/>(任务代码已开始执行)
```

**依据**: `timer.hpp:45` 注释 -- "Cancel the timer, the synchronization timer cannot be canceled"

---

## 5. Benchmark 监控状态

```mermaid
stateDiagram-v2
    [*] --> 未开启: Benchmark构造<br/>benchmarkSwitch=false
    
    未开启 --> 内存监控: 构造中启动detached线程
    Note right of 内存监控: 每60s sysinfo<br/>与benchmarkSwitch无关
    
    未开启 --> 已开启: OpenBenchmark()
    Note right of 已开启: benchmarkSwitch=true<br/>清空 benchmark.json
    
    已开启 --> 收集数据: 各 add* 方法被调用
    收集数据 --> 收集数据: 持续收集
    
    已开启 --> 清理中: Clear()
    清理中 --> 暂停: _threadFlag=false
    暂停 --> sleep5s: sleep(5)
    sleep5s --> 清零: 所有map/atomic清零
    清零 --> 已开启: benchmarkSwitch=true
    
    已开启 --> 打印汇总: PrintBenchmarkSummary(exportToFile)
    打印汇总 --> 已开启: 继续收集
    
    已开启 --> 未开启: Clear() 后 benchmarkSwitch保持false
    未开启 --> [*]: 析构 (_threadFlag=false)
```

**关键代码位置**:
- Benchmark构造: `bench_mark.cpp:18-36`
- OpenBenchmark: `bench_mark.cpp:38-51`
- Clear: `bench_mark.cpp:68-91`
- PrintBenchmarkSummary: `bench_mark.cpp:153`

---

## 6. NTP时间获取状态

```mermaid
stateDiagram-v2
    [*] --> 请求NTP: GetNtpTimestamp() / getNtpTimestampConfig()
    
    请求NTP --> 随机选服务器: rand() % ntpHost.size()
    随机选服务器 --> UDP发送: ntp_get_time(host, 123, 1000ms)
    
    UDP发送 --> 获取成功: err == 0
    UDP发送 --> 获取失败: err != 0
    
    获取失败 --> 重试: 重试次数 < 3
    重试 --> 随机选服务器: 重新随机选择
    
    获取失败 --> 回退本地: 重试次数 >= 3
    回退本地 --> GetUTCTimestamp: gettimeofday()
    
    获取成功 --> 微秒转换: timev / 10
    
    微秒转换 --> 仅返回: is_sync == false
    微秒转换 --> 同步本地时钟: is_sync == true
    
    同步本地时钟 --> SetLocalTime: settimeofday()
    Note right of 同步本地时钟: 需要root权限<br/>失败时静默返回
    
    仅返回 --> [*]: return timestamp (us)
    同步本地时钟 --> [*]: return timestamp (us)
    GetUTCTimestamp --> [*]: return timestamp (us)
```

**关键代码位置**:
- GetNtpTimestamp: `time_util.cpp:90-123`
- getNtpTimestampConfig: `time_util.cpp:56-87`
- SetLocalTime: `time_util.cpp:126-137`
- ntp_get_time: `vxntp_helper.cpp/h`
