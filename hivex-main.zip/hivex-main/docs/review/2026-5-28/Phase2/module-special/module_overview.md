# Module 11 -- 其他特殊功能模块总览 (module_overview.md)

**分析日期**: 2026-05-26
**分析范围**: 错误处理 / 配置管理 / CLI / 合约依赖管理 / 监控与调试 / 时间与NTP / 其他工具
**置信度**: 高 (核心模块) / 中 (辅助工具) / 低 (废弃/注释代码)

---

## 1. 模块职责汇总

### 1.1 错误处理系统 (errorn/)

| 子模块 | 文件 | 职责 | 状态 |
|--------|------|------|------|
| 入口模块 | `errorn/error_module.h` | 统一引用所有错误定义，生成错误消息和枚举 | 有效 |
| CA层错误 | `errorn/ca/error.def.h` | 72个CA层业务错误码 (质押/合约/Gas/UTXO等) | 有效 |
| 合约层错误 | `errorn/contract/error.def.h` | 13个EVM合约执行错误码 | 有效 |
| 全局错误 | `errorn/global/error.def.h` | 6个通用错误码 (地址/资产/哈希/时间等) | 有效 |
| RPC层错误 | `errorn/rpc/error.def.h` | 11个RPC解析/序列化错误码 | 有效 |

**依据**: `errorn/error_module.h:1-25` -- 通过宏展开 `MEM` (memorize) 生成带内存驻留的错误枚举和消息映射。

### 1.2 配置管理系统 (common/)

| 子模块 | 文件 | 职责 | 状态 |
|--------|------|------|------|
| 运行时配置 | `common/config.cpp/h` | config.json 热加载/验证/后台监控 (~22KB) | 有效 |
| 创世配置 | `common/genesis.cpp/h` | genesis.json 加载/保存/网络类型管理 | 有效 |
| 全局数据 | `common/global_data.cpp/h` | 跨线程消息等待与数据同步 | 有效 |
| 线程池 | `common/task_pool.cpp/h` | 8个子池共255个线程的多任务调度 | 有效 |
| 耗时统计 | `common/time_report.cpp/h` | 代码段计时与报告 | 有效 |
| CPU绑定 | `common/bind_thread.cpp/h` | 线程绑核优化 | 有效 |
| 进程控制 | `utils/init.cpp/h` | 信号处理/PID文件/进程守护 | 有效 |

### 1.3 CLI交互系统

| 子模块 | 文件 | 职责 | 状态 |
|--------|------|------|------|
| 高级菜单 | `ca/advanced_menu.cpp/h` | 完整的CLI交互菜单 (~141KB, 大量业务逻辑混入) | 有效但需重构 |
| 基础菜单 | `main/menu.cpp/h` | 简单菜单入口 | 有效 |

### 1.4 合约依赖管理系统

| 子模块 | 文件 | 职责 | 状态 |
|--------|------|------|------|
| 依赖管理器 | `ca/dispatchtx.cpp/h` (~DependencyManager) | 合约地址依赖分组/冲突解决 | 有效 |
| 消息分发器 | `ca/dispatchtx.cpp/h` (~MessageDispatcher) | 合约交易分组发送至打包节点 | 有效 |
| 定时处理 | `ca/dispatchtx.cpp/h` (~TimerProcessor) | 周期触发依赖数据收集与分发 | 有效 |
| 事件管理 | `ca/dispatchtx.cpp/h` (~EventManager) | 事件订阅与发布 | 有效 |
| 交易缓存 | `ca/contract_transaction_cache.cpp/h` | 失败交易缓存与重试 (整个文件已注释掉) | **废弃** |
| 合约入口 | `ca/contract.cpp/h` | 合约调用入口 | 有效 |

### 1.5 监控与调试系统

| 子模块 | 文件 | 职责 | 状态 |
|--------|------|------|------|
| 性能基准 | `utils/bench_mark.cpp/h` | 交易/区块/验证全链路计时 (~30KB) | 有效 |
| 格式化打印 | `utils/pretty_print.cpp/h` | 区块/交易/RocksDB信息打印 (~44KB) | 有效 |
| JSON输出 | `utils/json_output.cpp/h` | 区块/交易对象转JSON | 有效 |
| 临时日志 | `utils/tmp_log.cpp/h` | 简易printf风格日志宏 | 有效(调试用) |

### 1.6 时间与NTP系统

| 子模块 | 文件 | 职责 | 状态 |
|--------|------|------|------|
| 时间工具 | `utils/time_util.cpp/h` | 获取NTP/UTC时间戳，时间格式化 | 有效 |
| 定时器 | `utils/timer.cpp/hpp` | 单次/循环异步/同步定时器 | 有效 |
| NTP辅助库 | `utils/vxntp_helper.cpp/h` | 底层NTP协议C库 (~30KB) | 有效 |
| 时间守护 | `utils/timd.cpp/h` | 时间守护进程相关 | 有效 |

### 1.7 其他工具系统

| 子模块 | 文件 | 职责 | 状态 |
|--------|------|------|------|
| 压缩 | `utils/compress.cpp/h` | 数据压缩/解压 | 有效 |
| 字符串工具 | `utils/string_util.cpp/h` | 字符串修剪/分割/拼接 | 有效 |
| 命令行解析 | `utils/cmdline.cpp/h` | 命令行参数解析 | 有效 |
| 控制台输出 | `utils/console.cpp/h` | 终端彩色输出 | 有效 |
| 守护进程 | `utils/daemon.h` | 进程守护 (double-fork + crash-loop保护) | 有效 |

---

## 2. 三列对比表: 规范定义 vs 当前实现 vs 偏差原因

| 功能点 | 规范定义 (spec_dev.md) | 当前实现 | 偏差原因 |
|--------|----------------------|---------|---------|
| **config.json 结构** | 定义 server_port/http_port/https_port/rpc/ip/log/server/version 等字段 (10.1节) | 实现完整支持所有字段, 额外支持 enable_https/enable_mtls/ssl证书路径 (config.h:57-78) | 规范未完整列出SSL字段, 实现超前 |
| **genesis.json 结构** | 定义 genesis/network/version 三层结构 (4.3节) | 完全按规范实现, 额外增加 NetworkType 枚举和名称/类型同步逻辑 (genesis.h:16-19) | 实现增加了便利性方法 |
| **错误码体系** | spec_dev.md:1961 "TODO: [需要补充] 完整 RPC 错误码定义" | 已有完整4层102个错误码: CA(72)+Contract(13)+Global(6)+RPC(11) | 规范文档未及时同步代码 |
| **合约依赖缓存** | spec_dev.md:1120-1161 详细定义 ContractTransactionCache 机制 (1秒检查, 15秒强制发送) | contract_transaction_cache.h 整个文件已被注释为废弃 (行1-96均为注释) | **重大偏差** -- 依赖检查逻辑已迁移至 Dispatcher/TimerProcessor 在线处理, 旧缓存机制废弃 |
| **合约依赖分发** | 未在规范中定义分发逻辑细节 | 实现完整: Dispatcher->DependencyManager(并查集分组)->MessageDispatcher(VRF选择打包节点)->网络发送 (dispatchtx.cpp) | 实现细节超出规范 |
| **NTP时间同步** | 规范未提及NTP实现 | 硬编码12个阿里云/腾讯云NTP服务器, 3次重试, 可选同步本地时钟 (time_util.cpp:92-123) | 实现细节未入规范 |
| **CLI交互菜单** | 未在规范中定义 | advanced_menu.cpp 141KB 实现完整的CLI交互, 但菜单逻辑与CA业务逻辑高度耦合 | 未入规范但属于运维必需功能 |
| **线程池** | spec_dev.md:248 提及 "Task Pool/Timer" | 8个子池: CA(15)/Net(15)/Broadcast(10)/Tx(50)/SyncBlock(25)/SaveBlock(50)/Block(50)/Work(50) = 255线程 (task_pool.h:23-30) | 规范只提及但未定义具体线程数 |
| **性能基准** | 规范未提及 | benchmark完全实现, 覆盖: 交易发起/签名/验证/区块构建/保存全链路 (bench_mark.h:25-293) | 实现细节未入规范 |
| **config热加载** | 规范仅提及配置读取, 未定义热加载行为 | Config::_Check 后台线程每3600秒(2s*1800)收集节点列表并覆盖server字段 (config.cpp:647-659) | 实际是"周期性刷新节点列表", 非完整热加载 |
| **错误处理统一性** | 规范未涉及 | 3种错误体系并存: (1)EXP_ERROR宏生成枚举 (2)protobuf status字段 (3)cerr/cout直接控制台输出 | 历史演进造成的多渠道并存 |
| **日志路径验证** | 未在规范定义 | FilterLog强制要求 log.path == "./logs" 精确匹配 (config.cpp:571-577) | 限制过于严格, 不灵活 |

---

## 3. 关键发现

### 3.1 废弃/未完成的代码

1. **ContractTransactionCache** (`ca/contract_transaction_cache.h`) -- 整个类被注释掉, 其职责已迁移至 `DependencyManager` + `TimerProcessor` + `MessageDispatcher` 的在线依赖分组/分发机制。根据 spec_dev.md:1120-1161 仍描述此机制, 规范待更新。
2. **DependencyManager 中的大量注释方法** (`dispatchtx.h:66-82`) -- `GetAllDependenciesWithTxHashes`, `CanSendTransaction`, `ClearDependency`, `BroadcastAddedDependency`, `RememberClearedDependencyHash` 等均被注释, 表明依赖管理经历了重大重构。

### 3.2 临时兼容逻辑

1. **Config::InitFile 的双重try-catch** (`config.cpp:48-58`) -- filesystem::absolute 可能抛异常, 用try-catch吞掉后用裸文件名兜底, 是防御性但掩盖真实错误的设计。
2. **NTP fallback** (`time_util.cpp:47-53`) -- `GetTimestamp()` 先尝试NTP, 失败后回退到本地UTC, 在NTP不可用时保证基本功能, 但可能导致节点间时间不一致。

### 3.3 安全隐患

1. **Config热加载无原子性保护** (`config.cpp:612-646`) -- `GetAllServerAddress` 直接修改成员变量和文件, 无锁保护, 与读取线程并发时可能出现数据竞争。**风险等级: 中**
2. **NTP SetLocalTime 无权限检查** (`time_util.cpp:126-137`) -- settimeofday 需root权限, 普通用户运行时静默失败, 不返回明确错误。**风险等级: 低**
3. **SetIP/SetPort 直接写文件无备份** (`config.cpp:408-465`) -- 配置更新直接覆写, 无原子写入(先写临时文件再rename)。若写入中途崩溃, 可能出现损坏的config。**风险等级: 中**
4. **tmpJson 成员变量跨线程非保护访问** (`config.h:80`) -- tmpJson 在SetIP/SetPort中读写, 在_Check线程中读写, 均无锁。**风险等级: 中**
