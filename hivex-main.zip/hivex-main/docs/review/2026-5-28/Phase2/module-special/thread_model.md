# Module 11 -- 线程模型分析 (thread_model.md)

**分析日期**: 2026-05-26
**依据**: 代码中 thread 创建点 + 线程池定义 [可信度: 高]

---

## 1. 线程全景图

```mermaid
graph TB
    subgraph MainProcess["主进程"]
        MainThread["main() 主线程<br/>CLI交互 / 生命周期管理"]
    end
    
    subgraph ConfigThreads["配置管理线程"]
        C1["Config::_Check() 线程<br/>config.h:94<br/>每3600s周期检查<br/>收集节点列表"]
    end
    
    subgraph TaskPool["TaskPool 线程池 (255线程)"]
        T1["caTaskPool_ (15线程)<br/>task_pool.h:48<br/>CA核心业务"]
        T2["netTaskPool (15线程)<br/>task_pool.h:49<br/>网络消息"]
        T3["broadcastTaskPool (10线程)<br/>task_pool.h:50<br/>广播消息"]
        T4["txTaskPool (50线程)<br/>task_pool.h:51<br/>交易处理"]
        T5["syncTaskPool (25线程)<br/>task_pool.h:52<br/>区块同步"]
        T6["saveBlockTaskPool (50线程)<br/>task_pool.h:53<br/>区块保存"]
        T7["blockTaskPool (50线程)<br/>task_pool.h:54<br/>区块处理"]
        T8["workTaskPool (50线程)<br/>task_pool.h:55<br/>通用工作"]
    end
    
    subgraph TimerThreads["定时器线程 (动态)"]
        TM1["CTimer 线程1<br/>timer.cpp:25<br/>用户任务定时"]
        TM2["CTimer 线程2<br/>按需创建<br/>单次/循环"]
        TM3["CTimer 线程N<br/>按需创建<br/>每个Start创建新线程"]
    end
    
    subgraph ContractThreads["合约依赖处理线程"]
        CD1["TimerProcessor 线程<br/>dispatchtx.h:118<br/>每3s触发依赖收集"]
        CD2["ContractPackager 线程<br/>(网络层)<br/>处理合约打包消息"]
    end
    
    subgraph BenchmarkThreads["性能监控线程"]
        BM1["内存监控线程(detached)<br/>bench_mark.cpp:20<br/>每60s检查 sysinfo"]
    end
    
    subgraph DaemonThreads["守护进程线程"]
        D1["startDaemon() 监控进程<br/>daemon.h:97<br/>fork子进程 + 崩溃重启"]
    end
    
    style MainThread fill:#4a90d9,color:#fff
    style TaskPool fill:#e8a838,color:#fff
    style TimerThreads fill:#67b168,color:#fff
    style ContractThreads fill:#8a6dba,color:#fff
    style BenchmarkThreads fill:#d94a4a,color:#fff
```

---

## 2. Config::_Check 后台监控线程

### 2.1 基本信息
- **创建位置**: `config.h:94` -- `_thread = std::thread(std::bind(&Config::_Check, this))`
- **生命周期**: Config 构造时创建, 析构时 join
- **运行周期**: ~3600秒 (1小时)

### 2.2 线程函数分析

```cpp
// config.cpp:647-659
void Config::_Check() {
    while(!_exitThread) {            // 原子变量检查
        for(int i=0; i <= 1800 && !_exitThread ; i++){
            std::this_thread::sleep_for(std::chrono::seconds(2));  // 2s * 1800 = 3600s
        }
        if(!_exitThread){
            GetAllServerAddress();   // 收集节点并覆写 config.json
        }
    }
}
```

### 2.3 线程安全分析

| 共享资源 | 访问点 | 保护机制 | 风险 |
|---------|--------|---------|------|
| `_exitThread` | _Check读, 析构写 | std::atomic<bool> | 安全 |
| `tmpJson` | _Check写的GetAllServerAddress(), SetIP/SetPort/SetRPC读写 | **无** | **有竞争** |
| `_server` | GetAllServerAddress()写, GetServer()读 | **无** | **有竞争** |
| config.json文件 | GetAllServerAddress覆写 | 无文件锁 | 基本安全(单进程) |
| `sentinelNode` | GetAllServerAddress读 | 初始化时写入 | 安全(immutable after init) |

### 2.4 问题清单

| # | 位置 | 现象 | 风险 | 修复建议 |
|---|------|------|------|---------|
| 1 | config.cpp:648-653 | sleep(2)*1800 循环, 无法快速退出 | 低 | 用 condition_variable::wait_for 替代, 析构时 notify |
| 2 | config.cpp:656 | GetAllServerAddress 无锁写共享数据 | 中 | 加 mutex 保护 tmpJson 和相关成员 |
| 3 | config.cpp:612-646 | 节点列表收集逻辑: 遍历PeerNode + sentinelNode, 合并去重 | 低 | 线性复杂度O(n), 节点数多时可能有性能影响 |

---

## 3. TaskPool 工作线程池

### 3.1 架构概览

```
TaskPool (Singleton)
├── caTaskPool_        : boost::threadpool::pool(15)    -- CA业务消息
├── netTaskPool        : boost::threadpool::pool(15)    -- 网络消息
├── broadcastTaskPool  : boost::threadpool::pool(10)    -- 广播消息
├── txTaskPool         : boost::threadpool::pool(50)    -- 交易处理
├── syncTaskPool       : boost::threadpool::pool(25)    -- 区块同步
├── saveBlockTaskPool  : boost::threadpool::pool(50)    -- 区块保存
├── blockTaskPool      : boost::threadpool::pool(50)    -- 区块处理
└── workTaskPool       : boost::threadpool::pool(50)    -- 通用工作
                         合计: 255 线程
```

### 3.2 线程池特性 (基于 boost::threadpool)
- **线程数**: 编译期固定 (task_pool.h:23-30)
- **任务队列**: 无界队列 (boost::threadpool 默认)
- **调度策略**: FIFO 先进先出
- **生命周期**: TaskPool 单例, 整个进程生命周期

### 3.3 提交接口模式

每个子池提供两种提交模式:

**模式A: Protobuf回调 (三参数)**
```cpp
commitCaTask(ProtoCallBack func, MessagePtr subMsg, const MsgData &data)
// -> caTaskPool_.schedule(boost::bind(func, subMsg, data))
```

**模式B: 泛型可调用对象**
```cpp
template<class T>
commitCaTask(T func)
// -> caTaskPool_.schedule(func)
```

### 3.4 监控接口
每个子池提供 `Active()` 和 `Pending()` 查询:
- `Active()`: 当前正在执行的任务数
- `Pending()`: 队列中等待的任务数

### 3.5 问题清单

| # | 位置 | 现象 | 风险 | 修复建议 |
|---|------|------|------|---------|
| 1 | task_pool.h:23-30 | 线程数硬编码 | 中 | 部分关键池支持配置文件调优 |
| 2 | boost::threadpool | 无界任务队列 | 中 | 高峰期可能堆积大量任务, 内存增长 |
| 3 | task_pool.h:71-84 | 每个池提交接口命名不统一 (commitCaTask / CommitNetworkTask / commitBroadcastRequest) | 低 | 统一命名规范为 `commitXxxTask` 或 `CommitXxxTask` |

---

## 4. Timer 定时器线程

### 4.1 线程模型

```
CTimer 实例 (每次 Start 可能创建新线程)
  ├── async=true: 创建 std::unique_ptr<std::thread>, 独立运行
  │   ├── 循环: wait_for(msTime) -> task() -> m_nCount++ -> 检查 bLoop
  │   └── 退出: m_bExpired=true, isTryExpired=false
  └── async=false: 当前线程同步执行
      └── sleep_for(msTime) -> task() -> 直接返回
```

### 4.2 生命周期管理

| 操作 | 方法 | 行为 |
|------|------|------|
| 创建 | Start(async=true) | DeleteThread(join旧线程) + reset(new thread) |
| 取消 | Cancel() | isTryExpired=true -> notify_all -> join or detach |
| 销毁 | ~CTimer() | 自动调用 Cancel() |
| 重新Start | Start(async=true) | 如果 m_bExpired=false 返回false, 否则先 DeleteThread 再创建 |

### 4.3 资源管理分析

```
正确路径:
  1. Start() -> 创建线程 -> task执行 -> m_bExpired=true -> 线程自然退出
  2. ~CTimer() -> Cancel() -> join() 等待线程退出

潜在问题路径:
  1. Start()后, 线程还在wait_for中, Cancel() -> notify_all唤醒 -> join等待
     - join等待时间取决于task()执行时间, 如果task()执行很久, 退出会阻塞
  2. detach路径: Cancel()中如果!joinable(), 执行detach
     - 这种情况发生在线程已自然退出但未join, detach是安全的
```

### 4.4 问题清单

| # | 位置 | 现象 | 风险 | 修复建议 |
|---|------|------|------|---------|
| 1 | timer.cpp:25 | 每个Start创建新线程 | 低 | 大量定时器可能创建过多线程, 考虑线程池复用 |
| 2 | timer.cpp:72-80 | Cancel中 join/detach 分支 | 低 | 逻辑正确但需要代码注释说明!joinable()何时发生 |
| 3 | timer.hpp:45 | 注释说"同步定时器无法取消" | 低 | 语义正确, sync模式下调用了sleep_for后执行task, Cancel检查在sleep之前 |

---

## 5. Benchmark 统计线程

### 5.1 线程模型

```
Benchmark 构造
  └── memoryMonitorThread (detached) [bench_mark.cpp:20-34]
      └── while(_threadFlag): sleep(60) -> sysinfo -> DEBUGLOG(memFreeTotal)

Clear() 操作
  └── _threadFlag = false (通知内存线程退出)
  └── sleep(5) (等待内存线程退出)
  └── 清零所有数据
  └── benchmarkSwitch = true
```

### 5.2 特性
- **detached线程**: 构造时创建, 进程结束时被OS回收
- **退出信号**: `_threadFlag` 原子变量 (bench_mark.h:213)
- **退出延迟**: 最多60秒 (sleep间隔)
- **无优雅退出**: 没有 join 或 condition_variable, 依赖sleep循环检查标志

### 5.3 问题清单

| # | 位置 | 现象 | 风险 | 修复建议 |
|---|------|------|------|---------|
| 1 | bench_mark.cpp:34 | detach() + sleep(60) | 低 | 进程退出时detach线程可能不完整执行最后一次检查 | 改用 condition_variable+join |
| 2 | bench_mark.cpp:77 | Clear()中 sleep(5) 粗粒度等待 | 低 | 不够精确, 可能多等或少等 | 改用 wait_for 或 join |

---

## 6. ContractDispatcher 处理线程

### 6.1 TimerProcessor 定时器线程

```
TimerProcessor::Start() [dispatchtx.h:113]
  ├── running_ = true
  ├── timer_thread_ = std::thread(&TimerProcessor::ProcessingFunc, this)
  │   └── while(running_):
  │       ├── unique_lock + timer_cv_.wait_for(kContractWaitingTime)
  │       │   kContractWaitingTime = 3 * 1000000 (3秒)
  │       ├── if(!running_) break
  │       ├── ContractDispatcher::Process()
  │       │   └── DependencyManager::GetDependentData()
  │       │       └── 并查集分组 -> MessageDispatcher分发
  │       └── loop
  └── Stop():
      ├── running_ = false
      ├── timer_cv_.notify_all()
      └── if(joinable()) join()
```

### 6.2 线程同步

| 共享资源 | 保护机制 |
|---------|---------|
| contract_dep_cache_ | std::mutex dep_mutex_ |
| contract_msg_cache_ | std::mutex msg_mutex_ |
| running_ | 普通bool + timer_mutex_ (Stop写, ProcessingFunc读) |
| time_value_ | timer_mutex_ (SetTimeValue写, ProcessingFunc读) |

### 6.3 问题清单

| # | 位置 | 现象 | 风险 | 修复建议 |
|---|------|------|------|---------|
| 1 | dispatchtx.h:118-121 | running_ 非原子变量, 虽有关联mutex但Stop和ProcessingFunc中的读写可能不经过同一个锁路径 | 低 | 改为 std::atomic<bool> |

---

## 7. ContractTransactionCache (已废弃)

### 7.1 原始设计
```
ContractTransactionCache 构造
  └── _StartTimer()
      └── CTimer _timer
          └── AsyncLoop(CHECK_INTERVAL=1000ms, _CheckCachedTransactions)
              └── 遍历缓存 -> 检查超时 -> 发送或重试

旧规范定义: spec_dev.md:1130
  _CheckCachedTransactions(): 每1秒检查一次
```

### 7.2 当前状态
- `contract_transaction_cache.h` 全部被注释 (行1-96)
- `contract_transaction_cache.cpp` 可能也被注释或删除
- 该线程**不再运行**

---

## 8. 守护进程线程

### 8.1 daemon.h 监督进程
```
startDaemon() [daemon.h:32]
  ├── Phase 1: double-fork + setsid + umask + /dev/null重定向
  └── Phase 2: 监督循环
      └── while(1):
          ├── fork() 子进程
          │   └── execl("/usr/local/bin/moonmesh-worker", "-m")
          ├── waitpid(子进程)
          ├── 判断退出原因 (exit code / signal)
          ├── crash-loop防护: 60秒内 >5次崩溃则放弃
          └── sleep(5) 后重启
```

### 8.2 特点
- **double-fork**: 标准守护进程化, 脱离控制终端
- **crash-loop防护**: MAX_CRASHES_IN_60S = 5
- **硬编码路径**: `/usr/local/bin/moonmesh-worker`, `/var/lib/moonmesh`

---

## 9. 线程总结

| 线程/线程池 | 线程数 | 创建时机 | 生命周期 | 退出方式 |
|-----------|--------|---------|---------|---------|
| main() | 1 | 进程启动 | 进程结束 | return/exit |
| Config::_Check | 1 | Config构造 | Config析构 | _exitThread原子变量 |
| caTaskPool_ | 15 | 首次使用 | 进程结束 | pool析构 |
| netTaskPool | 15 | 首次使用 | 进程结束 | pool析构 |
| broadcastTaskPool | 10 | 首次使用 | 进程结束 | pool析构 |
| txTaskPool | 50 | 首次使用 | 进程结束 | pool析构 |
| syncTaskPool | 25 | 首次使用 | 进程结束 | pool析构 |
| saveBlockTaskPool | 50 | 首次使用 | 进程结束 | pool析构 |
| blockTaskPool | 50 | 首次使用 | 进程结束 | pool析构 |
| workTaskPool | 50 | 首次使用 | 进程结束 | pool析构 |
| CTimer线程 | N (动态) | 每次Start(async) | Cancel或自然结束 | join/detach |
| TimerProcessor | 1 | ContractDispatcher::Process() | Stop()调用 | join |
| Benchmark内存监控 | 1 | Benchmark构造 | 进程结束 | detach(无显式join) |
| Daemon (startDaemon) | 1+子进程 | 显式调用 | 永不退出(守护进程) | _exit |
| **(不含网络/RPC/共识线程)** | **269+** | | | |

**注**: 此处不含网络层、RPC HTTP服务、共识算法、EVM执行等其他模块的线程。
