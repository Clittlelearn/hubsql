# Module 11 -- 存储模型分析 (storage_model.md)

**分析日期**: 2026-05-26
**依据**: 代码文件格式定义 + 读写逻辑分析 [可信度: 高]

---

## 1. config.json -- 运行时配置文件

### 1.1 文件位置
- **默认路径**: 进程当前工作目录下的 `config.json`
- **读取方式**: `config.h:56` -- `const std::string kConfigFilename = "config.json"`
- **绝对路径**: `config.cpp:50` -- `std::filesystem::absolute(kConfigFilename)` 转为绝对路径

### 1.2 文件格式

```json
{
  "http_callback": {
    "ip": "",
    "path": "",
    "port": 0
  },
  "rpc": true,
  "http_port": 13134,
  "enable_https": false,
  "https_port": 443,
  "ssl_cert_path": "",
  "ssl_key_path": "",
  "ssl_ca_bundle": "",
  "enable_mtls": false,
  "info": {
    "logo": "",
    "name": ""
  },
  "ip": "",
  "log": {
    "console": false,
    "level": "OFF",
    "path": "./logs"
  },
  "server": [
    "52.8.162.216",
    "50.18.55.167"
  ],
  "server_port": 13133,
  "version": "1.0.0"
}
```

**依据**: `config.cpp:43` -- `kConfigJson` 默认JSON模板字符串

### 1.3 字段说明

| JSON Key | C++类型 | 默认值 | 验证规则 | 代码位置 |
|----------|---------|--------|---------|---------|
| `http_callback.ip` | string | "" | IPv4正则 | config.cpp:115 |
| `http_callback.path` | string | "" | 无验证 | config.cpp:117 |
| `http_callback.port` | uint32 | 0 | 1-65535 | config.cpp:593 |
| `rpc` | bool | true | 无 | config.cpp:120 |
| `http_port` | uint32 | 13134 | 1-65535正则 | config.cpp:119 |
| `enable_https` | bool | false | contains检查 | config.cpp:121-125 |
| `https_port` | uint32 | 443 | 1-65535正则 | config.cpp:126-130 |
| `ssl_cert_path` | string | "" | 路径解析+自动发现 | config.cpp:131-136 |
| `ssl_key_path` | string | "" | 路径解析+自动发现 | config.cpp:137-139 |
| `ssl_ca_bundle` | string | "" | 路径解析 | config.cpp:140-141 |
| `enable_mtls` | bool | false | contains检查 | config.cpp:142-145 |
| `info.logo` | string | "" | URL正则 | config.cpp:214 |
| `info.name` | string | "" | 中文+ASCII, 0-45字符 | config.cpp:215 |
| `ip` | string | "" | IPv4正则 或 空 | config.cpp:114 |
| `log.console` | bool | false | bool类型 | config.cpp:216 |
| `log.level` | string | "OFF" | debug/info/warn/error/trace/critical/off | config.cpp:217 |
| `log.path` | string | "./logs" | **精确匹配 "./logs"** | config.cpp:218 |
| `server` | string[] | 2个AWS IP | IPv4正则 | config.cpp:219-222 |
| `server_port` | uint32 | 13133 | 1-65535或0 | config.cpp:238 |
| `version` | string | "1.0.0" | 无验证 | config.cpp:240 |

### 1.4 读写模式

```
读取 (InitFile):
  1. 尝试打开 config.json
  2. 存在 -> json::parse -> _Parse -> _Filter -> _Verify
  3. 不存在 -> 写入默认JSON -> _Parse
  4. _Filter/_Verify失败 -> 删除 -> 写入默认JSON
  
写入:
  SetIP/SetPort/SetRPC:
    读取文件 -> 修改 tmpJson -> 覆写文件 (ofstream + dump(4))
  GetAllServerAddress:
    收集节点 -> 修改 tmpJson -> 覆写文件
```

### 1.5 并发访问问题

```
tmpJson (config.h:80) 被以下操作共享访问, 无锁保护:
  - _Check()线程: GetAllServerAddress() 读写 tmpJson
  - 主线程: SetIP() / SetPort() / SetRPC() 读写 tmpJson
```

### 1.6 写入安全性
- **覆写模式**: 直接 `ofstream << dump(4)` 覆写, **无临时文件+rename**
- **风险**: 写入中途崩溃导致文件不完整/损坏
- **建议**: 写入 `.tmp` 文件完成后再 rename

---

## 2. genesis.json -- 创世配置文件

### 2.1 文件位置
- **默认路径**: `genesis.h:84` -- `static constexpr const char* DEFAULT_PATH = "genesis.json"`

### 2.2 文件格式

```json
{
  "genesis": {
    "blockData": {
      "Name": "DevChain",
      "Type": "Genesis"
    },
    "genesisTime": 1769736708175000,
    "initAccountAddr": "755Ccf704E17570b64E247f0794314e4C8E542CA",
    "initialBalance": {
      "MM": 0,
      "Vote": 0
    }
  },
  "network": {
    "name": "devnet",
    "type": "dev"
  },
  "version": "1.0.0"
}
```

**依据**: `genesis.cpp` + spec_dev.md:340-361

### 2.3 字段说明

| JSON Key | 类型 | NetworkType影响 | 说明 |
|----------|------|----------------|------|
| `genesis.blockData.Name` | string | 否 | 链名称, e.g. "DevChain" |
| `genesis.blockData.Type` | string | 否 | 固定 "Genesis" |
| `genesis.genesisTime` | uint64 | 否 | 创世时间戳(微秒) |
| `genesis.initAccountAddr` | string | 否 | 初始账户EIP-55地址 |
| `genesis.initialBalance.MM` | uint64 | 否 | 初始MM余额(最小精度), 当前强制0 |
| `genesis.initialBalance.Vote` | uint64 | 否 | 初始Vote余额(最小精度), 当前强制0 |
| `network.name` | string | **是** | "devnet"/"testnet"/"primarynet" |
| `network.type` | string | **是** | "dev"/"test"/"primary" |
| `version` | string | 否 | 配置文件版本 |

### 2.4 网络类型映射

```
NetworkType::Dev     -> name="devnet",     type="dev"
NetworkType::Test    -> name="testnet",    type="test"
NetworkType::Primary -> name="primarynet", type="primary"
```

**依据**: `genesis.h:16-19` + `SyncNetworkNameAndType()` (genesis.cpp 私有方法)

### 2.5 读写模式

```
读取:
  构造 -> TryLoadFromFile(path) -> json::parse
  失败 -> CreateDefaultData() -> Save() 静默覆盖

写入:
  Save(path) -> ofstream << data_.dump(4) -> flush
```

**风险**: 构造失败时静默用默认值覆盖原文件 (`genesis.cpp:15-18`)
**建议**: 加载失败时只在内存中使用默认值, 不覆写文件, 提示用户检查

---

## 3. 密钥库文件 (keystore)

### 3.1 文件位置
【需人工验证】密钥文件路径需查看 `utils/account_manager.cpp/h` 确认。根据 `ca/global.h` 和相关常量推测:
- 可能在 `./keystore/` 或 `./data/keystore/` 目录下
- 使用 `AccountManager` 类管理

### 3.2 相关API推测
- `AccountManager::GetDefaultAddr()` -- 获取默认账户地址 (dispatchtx.cpp:243中使用)
- `AccountManager::GetInstance()` -- 单例访问 (dispatchtx.cpp:292中使用)

---

## 4. PID文件

### 4.1 文件位置
- **默认路径**: `utils/init.cpp:19` -- `#define MOONMESH_PID_FILE "/tmp/moonmesh.pid"`
- **可自定义**: `SetPidFilePath(const char* path)` 接口 (init.cpp:30)

### 4.2 文件格式
```
<进程PID数字>\n
```
示例: `12345\n`

**依据**: `init.cpp:54` -- `snprintf(buf, sizeof(buf), "%d\n", (int)pid)`

### 4.3 生命周期

```mermaid
sequenceDiagram
    participant Main as main()
    participant Init as init.cpp
    participant FS as 文件系统
    
    Main->>Init: InitPidFile() [init.cpp:13]
    Init->>FS: open(/tmp/moonmesh.pid, O_CREAT|O_EXCL)
    alt 创建成功
        FS-->>Init: fd
        Init->>FS: pwrite(fd, "12345\n", 6)
        Init->>FS: fsync(fd) [已注释]
    else EEXIST (文件已存在)
        Init->>FS: fopen + fscanf 读取旧PID
        Init->>Init: kill(old_pid, 0) 检查进程是否存在
        alt 旧进程已死 (ESRCH)
            Init->>FS: unlink(旧文件)
            Init->>FS: open(O_CREAT|O_EXCL) 重试
        else 旧进程仍在运行
            Init-->>Main: return -1 (多实例防护)
        end
    end
    
    Note over Main,FS: 进程运行中...
    
    Main->>Init: RemovePidFile() [init.cpp:14]
    Init->>FS: unlink(/tmp/moonmesh.pid)
```

### 4.4 关键实现细节

```cpp
// init.cpp:49-70
static int WritePidIntoFd(int fd, pid_t pid) {
    char buf[PID_BUF_SIZE];  // PID_BUF_SIZE = 32
    int len = snprintf(buf, sizeof(buf), "%d\n", (int)pid);
    ftruncate(fd, 0);         // 清空文件
    pwrite(fd, buf, len, 0); // 从偏移0写入
    // fsync(fd);             // 已注释 (init.cpp:67)
    return 0;
}
```

**注意**: `fsync` 被注释掉 (init.cpp:67), 意味着PID写入不保证持久化到磁盘。如果系统在此之后立即崩溃, PID文件可能为空或损坏。

### 4.5 多实例防护
- 使用 `O_CREAT | O_EXCL` 标志确保原子创建
- 如果文件已存在: 检查旧PID对应的进程是否存活
  - 存活: 返回错误 (防止多实例)
  - 已死: 删除旧文件, 重新创建

---

## 5. 日志文件

### 5.1 文件位置
- **配置项**: `config.json` -> `log.path` -> 默认 `"./logs"`
- **强制路径**: config.cpp:571-577, `FilterLog` 强制精确匹配 `./logs`
- **日志库**: `include/logging.h` (独立日志框架, 非本模块分析范围)

### 5.2 日志级别
- debug, info, warn, error, trace, critical, off
- config.cpp:563-568 大小写不敏感验证

### 5.3 临时日志 (tmp_log)
- **文件**: `utils/tmp_log.cpp/h`
- **用途**: 开发调试, 直接输出到控制台 (ANSI颜色)
- **宏**: `errorL`, `debugL`, `infoL`
- `logWriter(content, OUTTYPE, log_name)` -- 支持写入文件 (`new_tmp.log`)

---

## 6. Benchmark统计数据存储

### 6.1 文件位置
- `bench_mark.cpp:15-16`
- 主文件: `benchmark.json`
- 备用文件: `benchmark2.json`
- 位置: 进程工作目录

### 6.2 文件格式

```json
[
  {
    "timestamp": 1769736708,
    "tx_initiate_amount": 1000,
    "tx_initiate_per_second": 50.5,
    "mem_verify_time": 1200,
    "db_verify_time": 3500,
    "block_height": 100,
    "block_tx_count": 50,
    "block_verify_time": 5000,
    "block_pool_save_time": 200,
    "pending_time": 15000
  }
  // ... 更多数据点
]
```

### 6.3 写入模式
- `OpenBenchmark()`: 创建/清空文件, 写入 `[]` 初始化
- `PrintBenchmarkSummary(exportToFile=true)`: 追加数据到JSON数组
- 格式: `nlohmann::json` 序列化, `filestream << json.dump()`

### 6.4 数据结构映射

| BenchMark字段 | JSON Key | 说明 |
|---------------|----------|------|
| transactionInitiateMap | tx_initiate_* | 交易发起时间记录 |
| transactionVerificationMap | *_verify_time | 内存/DB验证时间 |
| agentTransactionReceiveMap_ | agent_receive_* | Agent接收时间 |
| transactionSignReceiveMap_ | sign_receive_* | 签名接收时间 |
| blockHasTransactionAmountMap | block_tx_count | 区块交易数 |
| blockVerificationMap | block_verify_time | 区块验证时间 |
| blockPoolStorageMap | block_pool_save_time | 区块池保存时间 |

---

## 7. NTP配置文件

### 7.1 文件位置
- `time_util.cpp:61` -- `ifstream infile("./ntp_server.conf")`

### 7.2 文件格式
```
ntp1.aliyun.com
ntp2.aliyun.com
time1.cloud.tencent.com
...
```
每行一个NTP服务器地址。

### 7.3 使用方式
- `getNtpTimestampConfig()` (time_util.cpp:56-87) 读取该文件
- 每次调用读取文件 (无缓存)
- 随机选择服务器, 3次重试

### 7.4 硬编码后备
- 当 `ntp_server.conf` 不存在时, `GetNtpTimestamp()` 使用硬编码的12个NTP服务器 (time_util.cpp:93-101)

---

## 8. SSL证书文件

### 8.1 文件位置
- 配置指定: `ssl_cert_path`, `ssl_key_path`, `ssl_ca_bundle`
- 自动发现路径 (config.cpp:177-211):
  - `<config_dir>/certs/fullchain.pem` 或 `cert.pem`
  - `<config_dir>/certs/privkey.pem`
  - `<config_dir>/build/bin/certs/` (备用)

### 8.2 路径解析逻辑 (config.cpp:146-161)
```cpp
auto resolve_path = [this](const std::string& p) -> std::string {
    if (p.empty()) return std::string();
    std::filesystem::path pp(p);
    if (pp.is_absolute()) return pp.lexically_normal().string();
    if (_configDir.empty()) return pp.lexically_normal().string();
    return (std::filesystem::path(_configDir) / pp).lexically_normal().string();
};
```
- 空路径返回空
- 绝对路径保持原样
- 相对路径相对于 config.json 所在目录解析

---

## 9. 文件存储全景总结

| 文件 | 默认路径 | 格式 | 写入方式 | 并发保护 | 风险等级 |
|------|---------|------|---------|---------|---------|
| config.json | ./config.json | JSON (4空格缩进) | ofstream覆写 | 无 | 中 (无原子写入, 无锁) |
| genesis.json | ./genesis.json | JSON (4空格缩进) | ofstream覆写 | 无 | 高 (失败时静默覆盖) |
| keystore/* | ./keystore/ (推测) | 加密JSON | 未知 | 未知 | 待确认 |
| moonmesh.pid | /tmp/moonmesh.pid | 文本(数字+换行) | pwrite+ftruncate | flock(O_EXCL) | 低 |
| 日志文件 | ./logs/ | 文本(日志库格式) | 日志库 | 日志库内部 | 低 |
| benchmark.json | ./benchmark.json | JSON数组 | ofstream追加/覆写 | 无 | 低 |
| ntp_server.conf | ./ntp_server.conf | 文本(每行一个地址) | 只读 | N/A | 低 |
| SSL证书 | ./certs/*.pem | PEM | 只读 | N/A | 低 |
