# Module 11 -- 重构建议 (refactor_suggestion.md)

**分析日期**: 2026-05-26
**分析范围**: 所有特殊功能模块的重构建议
**优先级定义**: P0=立即修复(安全/数据风险) P1=短期(1-2迭代) P2=中期 P3=长期

---

## 1. ca/advanced_menu.cpp (141KB) 菜单与业务逻辑分离

### 1.1 当前问题
- **文件**: `ca/advanced_menu.cpp/h` (~141KB, 估计3000+行)
- **核心缺陷**: CLI菜单交互逻辑与CA业务操作代码高度耦合在单一文件中
- **具体表现**:
  - 菜单输入循环中使用 `cin >>`, `getline` 等交互代码
  - 同一作用域内直接调用 `ca/ca.h`, `ca/contract.h`, `ca/txhelper.h` 等业务接口
  - 参数验证、错误处理、结果格式化输出全部混合
  - 全局变量 `jobs`, `jobs_index`, `errNodeIndex`, `test_pool` 模块级存在 (advanced_menu.cpp:52-66)

### 1.2 目标架构

```
重构后:
├── cli/
│   ├── menu_controller.h/cpp     -- 菜单树管理 + 输入循环 (不依赖CA业务)
│   ├── menu_view.h/cpp           -- 输出格式化 (ANSI颜色, 排版)
│   └── command_dispatcher.h/cpp  -- 命令路由到业务层
├── cli/commands/
│   ├── ca_commands.h/cpp         -- CA业务命令实现
│   ├── net_commands.h/cpp        -- 网络命令实现
│   ├── contract_commands.h/cpp   -- 合约命令实现
│   └── test_commands.h/cpp       -- 测试命令实现
├── cli/shell/
│   ├── readline_adapter.h/cpp    -- 可选 readline/linenoise 适配
│   └── command_history.h/cpp     -- 命令历史管理
└── ca/advanced_menu.h/cpp        -- 保留向后兼容包装 (废弃标记)
```

### 1.3 具体改造步骤

| 步骤 | 内容 | 工时(人日) |
|------|------|-----------|
| 1 | 提取 `MenuView` 类: 封装所有 `std::cout` 输出 + ANSI颜色 | 2 |
| 2 | 提取 `MenuController` 类: 菜单树定义(数据结构) + 输入解析 | 3 |
| 3 | 提取 `CommandDispatcher` 接口: 命令字符串 -> 回调函数注册 | 2 |
| 4 | 按功能域拆分命令实现文件: ca_commands / net_commands / contract_commands / test_commands | 5 |
| 5 | 消除全局变量: `jobs`, `jobs_index` 等封装为局部上下文 | 1 |
| 6 | 集成 readline/linenoise 库 (可选, 获得命令历史和Tab补全) | 1.5 |
| 7 | 保留 `MenuAdvanced()` 作为向后兼容的入口函数, `[[deprecated]]` 标记 | 0.5 |
| **合计** | | **15 人日** |

### 1.4 收益
- 每个命令实现在独立的小文件中, 降低维护门槛
- 菜单结构变更(增加/删除/重排)不需要修改业务代码
- 支持单元测试: 可以 mock 输出, 验证菜单逻辑

---

## 2. Config 类改进 (类型安全的配置访问)

### 2.1 当前问题

| 问题 | 位置 | 详情 |
|------|------|------|
| 字符串key拼写错误 | config.h:57-78 | 每次访问 `json["server_port"]` 等, 拼写错误编译器无法检测 |
| 类型不安全 | config.cpp:114-241 | `json[key].get<T>()` 运行时抛异常, 编译期无检查 |
| Getter/Setter 模板 | config.h:213-233 | `FilterIp<T>(T&)` 等模板仅用于类型擦除, 没有真正类型安全 |
| 无原子写入 | config.cpp:408-465 | SetIP/SetPort覆写文件无 backup+rename |
| 线程不安全 | config.h:80 | tmpJson 成员变量无锁保护 |
| 配置热加载语义不清 | config.cpp:612-659 | `_Check` 实际只更新 server 字段, 不应叫配置热加载 |

### 2.2 目标设计

```cpp
// 配置Schema定义 (编译期类型安全)
struct ConfigSchema {
    // 使用宏或模板定义每个字段的key/类型/默认值/验证器
    DEFINE_CONFIG_FIELD(server_port,    uint32_t,   13133,  PortValidator{1, 65535});
    DEFINE_CONFIG_FIELD(http_port,      uint32_t,   13134,  PortValidator{1, 65535});
    DEFINE_CONFIG_FIELD(rpc,            bool,       true,   NoopValidator{});
    DEFINE_CONFIG_FIELD(ip,             std::string, "",    Ipv4Validator{});
    DEFINE_CONFIG_FIELD(log.level,      std::string, "OFF", LogLevelValidator{});
    DEFINE_CONFIG_FIELD(log.path,       std::string, "./logs", PathValidator{});
    // ...
};

// 类型安全的配置访问
class TypedConfig {
public:
    template<typename T>
    T get(const ConfigKey<T>& key) const;  // 编译期保证类型匹配
    
    template<typename T>
    void set(const ConfigKey<T>& key, const T& value);  // 原子更新
    
    void reload();    // 重新加载配置文件 (真正的热加载)
    void watch();     // 文件变化监控 (inotify/FSEvents)
};
```

### 2.3 改造步骤

| 步骤 | 内容 | 工时(人日) |
|------|------|-----------|
| 1 | 定义 `ConfigFieldDescriptor` 结构体模板, 描述每个字段的 key/类型/默认值/验证器 | 2 |
| 2 | 实现编译期类型安全的 get<T>(field) 和 set<T>(field, value) | 2 |
| 3 | 实现原子文件写入: write .tmp -> fsync -> rename | 1 |
| 4 | 添加 mutex 保护所有共享状态 (tmpJson + 各成员变量) | 1 |
| 5 | 重新设计热加载: 使用文件系统事件(inotify)替代定时轮询 | 2 |
| 6 | 提取 `_Parse` 中的字段提取逻辑为独立函数 (每字段一个lambda) | 1 |
| 7 | 日志路径去除严格匹配, 改为路径格式校验 | 0.5 |
| **合计** | | **9.5 人日** |

### 2.4 修复关键Bug

| Bug | 位置 | 修复 | 用时(人日) |
|-----|------|------|-----------|
| _Parse 118行重复赋值 | config.cpp:118 | 删除重复行 | 0.1 |
| _Verify失败返回0 | config.cpp:91-98 | 返回错误码, 不覆写文件 | 0.3 |
| _Check 退出延迟2s | config.cpp:651 | condition_variable替代sleep | 0.2 |
| SetIP无原子写入 | config.cpp:408-425 | .tmp + rename | 0.5 |
| FilterLog路径强制匹配 | config.cpp:571-577 | 改为格式校验 | 0.2 |
| **合计** | | | **1.3 人日** |

---

## 3. 错误处理模块的统一化 (errorn/)

### 3.1 当前问题

```
error_module.h 通过宏展开:
  1. EXP_ERROR(CODE, "msg") -> 错误消息字符串
  2. EXP_ERROR(CODE, "msg") -> 错误枚举值
  3. ERROR_SERIALIZER_MACRO_DF(MEM) -> 带内存驻留的序列化

问题:
  1. 三层宏嵌套: 宏中有宏 ERROR_MESSAGE_MACRO_DF / ERROR_ENUM_MACRO_DF
  2. 错误码和消息定义在 .def.h 文件中, 与具体错误位置分离
  3. 与 protobuf status 字段共存, 形成两套错误体系
  4. 部分代码直接 cerr/cout 输出错误, 不走统一错误通道
```

### 3.2 三种错误输出渠道并存

```
渠道1: EXP_ERROR宏 -> 生成枚举 + 消息Map -> 通过 ERROR_SERIALIZER_MACRO 序列化
渠道2: protobuf status {code, errorCallstack} -> JSON-RPC 响应中返回
渠道3: std::cerr/std::cout + ANSI颜色 -> 直接终端输出 (config.cpp, time_util.cpp)
```

### 3.3 目标统一

```cpp
// 统一错误类型
class Error {
public:
    enum class Domain { CA, Contract, Global, RPC, Network };
    
    Domain domain;
    int code;
    std::string message;
    std::string detail;     // 可选的详细信息
    std::string callstack;  // 可选的调用栈
};

// 统一错误报告接口
class ErrorReporter {
public:
    // 三个通道统一到一个入口
    static void report(const Error& err, 
                       ReportChannel channel = ReportChannel::LOG);
};

enum class ReportChannel {
    LOG,       // 写入日志文件
    RPC,       // 通过JSON-RPC返回
    CONSOLE,   // 终端输出
    ALL        // 所有通道
};
```

### 3.4 改造步骤

| 步骤 | 内容 | 工时(人日) |
|------|------|-----------|
| 1 | 分析所有 EXP_ERROR 宏调用点, 建立错误码->用途映射 | 1 |
| 2 | 定义统一的 Error 类和 ErrorReporter 接口 | 1.5 |
| 3 | 迁移 CA层 72个错误码到新体系 (可批量脚本) | 1 |
| 4 | 迁移 Contract/Global/RPC 层错误码 | 1 |
| 5 | 替换 config.cpp 中的 cerr 输出为 ErrorReporter::report() | 1 |
| 6 | 替换 time_util.cpp 中的 cout 输出 | 0.5 |
| 7 | 兼容层: 保留旧宏接口, 内部转发到新 ErrorReporter | 1.5 |
| 8 | 集成到 RPC 响应生成: Error -> protobuf status 自动序列化 | 2 |
| **合计** | | **9.5 人日** |

---

## 4. CLI系统的重构 (MVC分离)

### 4.1 当前问题 (与第1节related但侧重不同)

第1节关注将141KB文件拆分为小文件, 本节关注 MVC 架构层面:

```
当前 advanced_menu.cpp:
  1. 直接获取用户输入 (cin >> / getline) -- View层
  2. 解析输入, 路由到子菜单 -- Controller层
  3. 调用CA/Net/Contract API -- Model/Service层
  4. 格式化输出 -- View层
  5. 全部混合在一个文件中
```

### 4.2 目标 MVC 架构

```mermaid
graph TB
    subgraph View["View层 - cli/views/"]
        V1["ConsoleView: 终端输出 + ANSI颜色"]
        V2["TableView: 表格格式化输出 (区块列表等)"]
        V3["JsonView: JSON格式化输出"]
        V4["ProgressView: 进度条 (批量操作)"]
    end
    
    subgraph Controller["Controller层 - cli/controllers/"]
        C1["MenuController: 命令解析 + 路由"]
        C2["InputParser: 参数解析 + 验证"]
        C3["CommandHandler: 命令注册/分发"]
    end
    
    subgraph Service["Service层 - cli/services/"]
        S1["TransactionService: 交易构造/签名/发送"]
        S2["BlockService: 区块查询/回滚"]
        S3["ContractService: 合约部署/调用"]
        S4["NetworkService: 节点管理"]
        S5["StakingService: 质押/委托/奖励"]
    end
    
    subgraph API["API层 - 现有CA/NET模块"]
        A1["ca/ 模块API"]
        A2["net/ 模块API"]
        A3["db/ 模块API"]
    end
    
    Controller --> View: 渲染结果
    Controller --> Service: 业务操作
    Service --> API: 调用底层API
```

### 4.3 改造步骤

| 步骤 | 内容 | 工时(人日) |
|------|------|-----------|
| 1 | 定义 Command 接口: `struct Command { string name; string desc; function<Result(Args)> handler; }` | 1 |
| 2 | 实现 CommandRegistry: 命令注册表 + 自动帮助生成 | 1.5 |
| 3 | 实现各 Service 接口 (提取现有 menu 中的业务调用) | 3 |
| 4 | 实现各 View 渲染器 (提取现有 printf/cout 逻辑) | 2 |
| 5 | 实现 MenuController: 将现有菜单结构转换为Command注册 | 2 |
| 6 | 实现 InputParser: 提取参数解析逻辑, 统一错误提示 | 1.5 |
| 7 | 编写单元测试 (Command注册, 路由, View渲染) | 3 |
| 8 | 向后兼容: 保留 MenuAdvanced() 入口, 内部转发新架构 | 0.5 |
| **合计** | | **14.5 人日** |

---

## 5. 其他关键改进

### 5.1 线程池可配置化

| 改进 | 当前 | 目标 | 工时(人日) |
|------|------|------|-----------|
| 线程数可配置 | 硬编码常量 (task_pool.h:23-30) | 从config.json读取, 运行时动态调整 | 1.5 |
| 任务队列上限 | 无界队列 | 可选有界队列 + 背压策略 | 1 |
| 线程池监控 | Active/Pending查询 | 添加Metrics: 执行时间分布/拒绝计数/队列深度 | 2 |
| **合计** | | | **4.5 人日** |

### 5.2 NTP时间安全加固

| 改进 | 当前 | 目标 | 工时(人日) |
|------|------|------|-----------|
| NTP服务器可配置 | 硬编码12个阿里云/腾讯云服务器 | 从配置文件读取, 支持私有NTP | 1 |
| 多NTP源共识 | 只取第一个成功结果 | 取多个NTP源的中位数, 拒绝异常值 | 2 |
| 本地时钟漂移监控 | 无 | 记录NTP偏差, 偏差过大时告警 | 1 |
| **合计** | | | **4 人日** |

### 5.3 配置热加载的完整实现

| 改进 | 当前 | 目标 | 工时(人日) |
|------|------|------|-----------|
| 实时文件监控 | 定时轮询 (3600s) | inotify/FSEvents 文件变化回调 | 2 |
| 全字段热加载 | 只更新 server 列表 | 所有字段支持热加载 (IP/Port/RPC等) | 2 |
| 热加载回调通知 | 无 | ConfigChangeListener 接口, 订阅字段变更 | 1.5 |
| **合计** | | | **5.5 人日** |

### 5.4 合约依赖管理的规范同步

| 改进 | 当前 | 目标 | 工时(人日) |
|------|------|------|-----------|
| 更新规范文档 | spec_dev.md:1120-1161 描述废弃的ContractTransactionCache | 描述新的 Dispatcher + DependencyManager 机制 | 1 |
| 清理注释代码 | dispatchtx.h:66-95 大量注释方法 | 移除注释的方法声明 | 0.5 |
| 清理废弃文件 | contract_transaction_cache.h 全注释 | 若确认废弃, 删除或用 git history 追溯 | 0.5 |
| **合计** | | | **2 人日** |

### 5.5 单元测试补充

| 模块 | 当前测试覆盖 | 建议补充 | 工时(人日) |
|------|-------------|---------|-----------|
| Config | 未知(可能无) | _Parse/_Verify/_Filter 边界测试 | 2 |
| Genesis | 未知 | 网络类型转换测试, 构造失败测试 | 1.5 |
| CTimer | 未知 | Start/Cancel并发测试, 循环/单次测试 | 1.5 |
| DependencyManager | 未知 | 并查集分组正确性测试, 并发Add测试 | 2 |
| TimeUtil | 未知 | NTP mock测试, fallback路径测试 | 1 |
| **合计** | | | **8 人日** |

---

## 6. 总工时估算

| 重构项 | 优先级 | 工时(人日) | 风险 |
|--------|--------|-----------|------|
| 1. advanced_menu 文件拆分 | P2 | 15.0 | 低 (纯代码重构) |
| 2. Config 类改进 | P1 | 9.5 | 中 (涉及运行时行为变更) |
| 2a. Config Bug修复 | P0 | 1.3 | 低 |
| 3. 错误处理统一化 | P2 | 9.5 | 中 (影响面广) |
| 4. CLI MVC重构 | P3 | 14.5 | 中 (大改动) |
| 5.1 线程池可配置化 | P2 | 4.5 | 低 |
| 5.2 NTP时间安全加固 | P1 | 4.0 | 低 |
| 5.3 配置热加载完整实现 | P2 | 5.5 | 中 |
| 5.4 合约依赖规范同步 | P1 | 2.0 | 低 |
| 5.5 单元测试补充 | P1 | 8.0 | 低 |
| **总计** | | **73.8 人日** | |

### 6.1 建议实施顺序 (按优先级)

```
迭代1 (P0紧急修复): Config Bug修复 (1.3人日) 
  - 修复 _Verify 失败静默覆写
  - 修复 tmpJson 无锁访问
  - 修复 SetIP 无原子写入

迭代2 (P1高优先级): 安全加固 + 规范同步 (14人日)
  - NTP安全加固
  - 合约依赖规范同步
  - 单元测试补充

迭代3 (P2中优先级): 架构优化 (34.5人日)
  - Config 类型安全改进
  - 错误处理统一化
  - 线程池可配置化
  - 配置热加载完整实现
  - advanced_menu 文件拆分

迭代4 (P3长期优化): CLI MVC重构 (14.5人日)
  - 完整的 MVC 分层
```

### 6.2 重点标注

| 风险点 | 说明 |
|--------|------|
| **Config重构** | Config 被大量模块通过 `MagicSingleton<Config>::GetInstance()` 访问, 任何接口变更都可能影响数十个文件, 建议逐步改造, 保留旧接口做兼容层 |
| **错误处理统一** | 错误码在CA/Contract/RPC层广泛使用, 统一化需要各模块负责人配合, 建议新增 Error 类不走替换路线, 新代码用新接口, 旧代码逐步迁移 |
| **CLI重建** | 141KB 文件包含大量运维调试功能, 需确保所有功能点都被迁移, 建议用功能列表 checklist 方式逐项迁移验证 |
