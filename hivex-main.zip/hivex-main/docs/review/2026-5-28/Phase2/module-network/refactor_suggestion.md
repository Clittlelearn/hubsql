# 模块6: 网络层 — 重构建议与优先级

> **可信度**: 高 — 基于源码结构和规范文档交叉验证
> **分析日期**: 2026-05-26

---

## 一、重构优先级总览

| 优先级 | 问题 | 工时 | 风险 |
|--------|------|------|------|
| P0 | 消息队列并发安全审查 | 2人日 | Critical |
| P1 | epoll事件处理异常恢复 | 2人日 | High |
| P1 | httplib.h 第三方库内嵌升级 | 1人日 | High |
| P2 | net/api.h 头文件依赖瘦身 | 2人日 | Medium |
| P2 | ProtobufDispatcher 模板化重构 | 3人日 | Medium |
| P2 | 广播策略可配置化 | 1人日 | Low |
| P3 | Node 结构规范化 | 1人日 | Low |
| P3 | 网络层日志标准化 | 1人日 | Low |
| **合计** | | **13人日** | |

---

## 二、详细重构方案

### 2.1 P0: 消息队列并发安全审查

**现状**: `net/msg_queue.h` 定义了读写队列分离的消息队列机制，但锁粒度和队列满/空的处理策略不明确。epoll事件循环、工作线程、定时器线程同时操作队列。

**问题位置**:
- `net/msg_queue.h` — MsgQueue 模板类
- `net/handle_event.cpp` — 多线程读写队列

**重构方案**:
1. 审计所有 `MsgQueue::push/pop` 的调用点，确认锁持有时间
2. 为读写队列分别添加容量上限（防止OOM）
3. 添加背压机制：队列满时阻塞或丢弃低优先级消息
4. 添加 `try_push` / `try_pop` 非阻塞接口

**验证方法**: 编写多线程压力测试，100线程并发读写队列

---

### 2.2 P1: epoll事件处理异常恢复

**现状**: `net/handle_event.cpp` (~29KB) 处理epoll的各种事件（EPOLLIN/EPOLLOUT/EPOLLERR/EPOLLHUP），但异常处理分散且不完整。

**问题**:
- EAGAIN 处理: 非阻塞 socket 在边缘触发模式下 EAGAIN 属正常，但当前实现可能将其视为错误
- 连接断开: EPOLLHUP/EPOLLRDHUP 处理后是否有完整的资源清理
- ECDH解密失败: 解密失败时是否安全关闭连接并清理密钥

**重构方案**:
1. 抽取错误处理为独立函数 `handleEpollError(fd, events)`
2. 添加每个连接的异常计数器，超过阈值自动断开
3. EAGAIN 与真正的收发错误明确区分
4. 添加连接状态日志（DEBUG级别）

**预估工时**: 2人日

---

### 2.3 P1: httplib.h 第三方库管理

**现状**: `net/httplib.h` (~195KB) 是 cpp-httplib 库的单头文件版本，直接内嵌在源码中。

**问题**:
- 版本不明（内嵌无版本标识）
- 无法通过包管理器升级
- 修改困难（195KB单文件）
- 与项目编译选项可能冲突

**重构方案**:
1. 将 httplib 移至 deps/ 作为标准第三方依赖
2. 在 CMakeLists.txt 中明确声明版本
3. 使用 FetchContent 或 git submodule 管理

**预估工时**: 1人日

---

### 2.4 P2: net/api.h 头文件依赖瘦身

**现状**: `net/api.h` (~11KB .h 文件) 包含了几乎所有网络子模块的头文件（peer_node, ip_port, pack, socket_buf, global, handle_event, config, genesis, logging, protobuf消息等）。

**影响**: 任何依赖 net/api.h 的编译单元都需要重新编译所有网络子模块。

**重构方案**:
1. 使用前向声明替代不必要的 #include
2. 模板函数移到独立的 .hpp 或 _impl.h 文件
3. 只暴露真正公共的接口在 api.h 中

**预估工时**: 2人日

---

### 2.5 P2: ProtobufDispatcher 模板化重构

**现状**: `net/dispatcher.cpp/h` 使用大量显式注册函数（~20个 `NetRegisterCallback<T>()` 调用），每种消息类型需要单独的注册和分发逻辑。

**重构方案**:
1. 使用 `std::unordered_map<uint32_t, std::function<...>>` 替代模板特化
2. 消息类型通过 Protobuf 的 `GetTypeName()` 自动注册
3. 支持运行时动态注册/注销回调

**预估工时**: 3人日

---

### 2.6 P2: 广播策略可配置化

**现状**: 广播策略硬编码（`broadcastMessage` 中 `broadcast_threshold` 固定值）。

**重构方案**:
1. 将广播参数（阈值、选择策略）移至 config.json
2. 支持按消息类型配置不同的广播策略
3. 添加广播统计（成功/失败计数）

**预估工时**: 1人日

---

### 2.7 P3: Node 结构规范化

**现状**: `net/node.hpp` 中 `Node` 结构的字段命名不统一（`address`/`name` vs `listenIp`/`publicPort`），枚举命名不规范（`NOTYET`/`dataRateToOutput`/`PASSIV`）。

**重构方案**:
1. 使用 Protobuf `NodeInfo` 消息替代自定义 Node 结构
2. 统一命名风格（snake_case）
3. 规范枚举值命名（ConnKind::kNotYet/kOutgoing/kIncoming）

**预估工时**: 1人日

---

### 2.8 P3: 网络层日志标准化

**现状**: 网络层日志使用 `INFOLOG`/`ERRORLOG`/`DEBUGLOG` 宏，但日志级别使用不一致（部分关键路径缺少日志，部分调试日志使用了INFO级别）。

**重构方案**:
1. 统一日志规范：连接建立/断开用INFO，消息收发用DEBUG，错误用ERROR
2. 添加每条日志的上下文（fd, peer_addr, msg_type）
3. 关键安全事件（密钥交换失败、解密失败）使用WARN级别

**预估工时**: 1人日

---

## 三、实施路线图

```
第1周: P0消息队列审查 + P1异常恢复 + P1 httplib迁移
第2周: P2 api.h瘦身 + P2 广播可配置化
第3周: P2 Dispatcher重构 + P3 规范化 + P3 日志标准化
```
