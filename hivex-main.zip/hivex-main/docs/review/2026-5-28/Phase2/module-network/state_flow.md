# 模块6: 状态流转分析 (state_flow.md)

> **可信度标记**: 全文依据源文件状态枚举和状态转换代码交叉验证, 高可信度。

---

## 1. 连接状态流转

### 1.1 ConnKind 状态定义 (net/node.hpp:10-15)

| 状态 | 枚举值 | 说明 | 触发方式 |
|------|--------|------|---------|
| NOTYET | 0 | 未连接(初始状态) | Node构造默认值 |
| dataRateToOutput | 1 | 主动连接(外部直连) | 本节点发起TCP连接后设置 |
| PASSIV | 2 | 被动连接 | 收到远程节点注册请求后设置 |

### 1.2 状态流转 (Mermaid)

```mermaid
stateDiagram-v2
    [*] --> NOTYET: 构造Node(默认)

    NOTYET --> dataRateToOutput: 主动连接<br/>1. ConnectNode发起TCP<br/>2. ANALYSIS_CONNECTION_KIND设置
    NOTYET --> PASSIV: 被动连接<br/>1. accept接受连接<br/>2. 收到RegisterNodeReq<br/>3. handleRegisterNodeRequest设置

    dataRateToOutput --> 已加密: ECDH密钥交换完成<br/>KeyExchangeManager::addKey(fd)
    dataRateToOutput --> NOTYET: 密钥交换失败<br/>ConnectNode失败或超时

    PASSIV --> 已加密: ECDH密钥交换完成<br/>(响应方handleKeyExchangeRequest)

    已加密 --> 已注册: Add/AddOrUpdate进入_nodeMap
    
    已注册 --> 活跃: pulse=3(初始)<br/>收到Ping/Pong时ResetHeart
    
    active: 活跃
    note right of active
      pulse > 0
      定期发送PingReq
      收到PingReq→发送PongReq→ResetHeart
      收到PongReq→ResetHeart
    end note

    已注册 --> active

    active --> active: DealHeart: pulse--; Update(node)<br/>发送PingReq
    active --> 活跃: 收到PingReq/PongReq<br/>pulse = 3 (ResetHeart)

    active --> 断开: pulse <= 0<br/>连续3次心跳无响应(180秒)
    已注册 --> 断开: fd <= 0<br/>对端关闭连接<br/>handle_net_read: nread==0

    断开 --> [*]: DeleteNode →<br/>epoll删除 → close(fd) →<br/>buffer删除 → nodeMap删除
```

### 1.3 状态转换代码位置

| 转换 | 触发条件 | 代码位置 |
|------|---------|---------|
| NOTYET → dataRateToOutput | ConnectNode→InitConnection成功 | peer_node.cpp:373, api.cpp:400 |
| NOTYET → PASSIV | handleRegisterNodeRequest中设置 | handle_event.cpp:190 |
| 已加密 → 已注册 | Add/AddOrUpdate | peer_node.cpp:43 (Add), :74 (AddOrUpdate) |
| 活跃 → pulse递减 | DealHeart 每60秒 | api.cpp:739 |
| pulse重置 | 收到PingReq/PongReq | handle_event.cpp:431 (Ping), :454 (Pong) |
| 活跃 → 断开 | pulse <= 0 | api.cpp:740-745 |
| 断开 → 清理 | DeleteNode/delete_by_fd | peer_node.cpp:79-107, :126-165 |

---

## 2. 密钥交换状态流转

### 2.1 状态定义 (隐式, 非显式枚举)

密钥交换没有显式的状态枚举, 通过 KeyExchangeMap 中是否存在fd对应的EcdhKey来判断:

| 逻辑状态 | 判定方式 | 说明 |
|---------|---------|------|
| 未交换 | !hasKey(fd) | keyExchangeMap中无此fd的条目 |
| 交换进行中 | 发起方: 在keyExchangeRequest中WaitData阻塞 | 等待对方KeyExchangeResponse |
| 已交换 | hasKey(fd) | keyExchangeMap存在, AES密钥已派生 |

### 2.2 密钥交换状态机 (Mermaid)

```mermaid
stateDiagram-v2
    [*] --> 未交换: TCP连接建立<br/>(fd有效但无密钥)

    未交换 --> 请求已发送: 发起方<br/>1. ConnectNode<br/>2. generate_ecdh_keys<br/>3. sendEcdhMessageRequest<br/>4. WaitData阻塞

    未交换 --> 请求已收到: 响应方<br/>1. 收到KeyExchangeRequest<br/>2. handleKeyExchangeRequest

    state 请求已发送 {
        [*] --> 等待响应: 阻塞在WaitData(msg_id, 5s)
        等待响应 --> 超时失败: 5秒超时<br/>ret = -6
        等待响应 --> 响应验证中: 收到KeyExchangeResponse
    }

    state 请求已收到 {
        [*] --> 验证公钥和Salt
        验证公钥和Salt --> 生成密钥: EC_PUBLIC_KEY_LENGTH=65<br/>CRYPTO_SALT_LEN=32
        生成密钥 --> derive_key: generate_ecdh_keys<br/>rand_salt<br/>key_calculate
    }

    响应验证中 --> derive_key: memcpy peer_key; key_calculate

    derive_key --> 已交换: addKey(fd)<br/>AES密钥存入keyExchangeMap

    已交换 --> 加密通道就绪: SendMessage会使用getKey获取AES密钥<br/>进行AES-256-GCM加密通信

    超时失败 --> 未交换: 关闭连接, 重试

    note right of 加密通道就绪
      每条消息:
      1. encrypt_plaintext (AES-256-GCM)
      2. generate_token (HMAC-SHA256)
      3. serialize → 压缩 → 打包 → 发送
    end note
```

### 2.3 密钥计算详解 (key_exchange.cpp:98-123)

```
key_calculate(ownkey, peerkey):
Step 1: bytes_xor(ownkey.salt, peerkey.salt) → saltXorValue (32字节)
  双方salt异或, 确保双方得到相同的XOR结果
  因为: own_salt XOR peer_salt == peer_salt XOR own_salt

Step 2: calculate_ecdh_shared_key(own_pub, own_priv, peer_pub) → shared_key (32字节)
  NIST P-256 ECDH: shared_key = own_priv * peer_pub

Step 3: createHkdfBytes(shared_key, saltXorValue, "ENCRYPTION", 32) → aes_key (32字节)
  HKDF-SHA256: aes_key = HKDF(ikm=shared_key, salt=saltXor, info="ENCRYPTION", L=32)
```

### 2.4 Token生成与验证 (key_exchange.cpp:73-95, 51-71)

每条加密消息附带Token, 用于防止重放和消息篡改:

```
generate_token(ecdh_pub_key):
├── rand_salt(random_digit, 3)                   → 3字节随机数
├── hmac_sha256(hmac, random_digit, 3, ecdh_pub_key)  → 32字节HMAC
├── token.salt_3bytes = random_digit (前3字节)
└── token.hmac_3bytes = hmac (前3字节)

verify_token(ecdh_pub_key, token):
├── hmac_sha256(hmac, token.salt_3bytes, 3, ecdh_pub_key)
└── memcmp(token.hmac_3bytes, hmac, 3) == 0 ?
```

---

## 3. TCP连接生命周期状态

### 3.1 完整生命周期

```mermaid
stateDiagram-v2
    [*] --> socket: Socket(AF_INET, SOCK_STREAM)

    socket --> connect: 主动连接<br/>InitConnection + 非阻塞connect
    socket --> listen: 被动监听<br/>initialize_listen_server

    listen --> accept: epoll_wait EPOLLIN on fdServerMain
    accept --> buffer_ready: AddBuffer + epoll注册

    connect --> epoll_poll: epoll_create(1) + epoll_ctl + epoll_wait(3s)
    epoll_poll --> connected: getsockopt SO_ERROR == 0
    epoll_poll --> failed: 超时或错误 → close
    connected --> buffer_ready: AddBuffer + EpollLoop注册

    buffer_ready --> ecdh_exchange: KeyExchangeManager::keyExchangeRequest
    ecdh_exchange --> encrypted: AES密钥派生完成

    encrypted --> registered: RegisterNodeReq/Ack
    registered --> active_heartbeat: DealHeart定时器

    active_heartbeat --> active_heartbeat: Ping/Pong交换, ResetHeart

    active_heartbeat --> closed: pulse <= 0 (3次心跳超时)
    registered --> closed: read返回0 (对端关闭)
    active_heartbeat --> closed: handle_net_read错误
    buffer_ready --> closed: EPOLLERR → getsockopt错误

    closed --> [*]: DeleteNode:<br/>epoll_ctl DEL → close(fd)<br/>bufferControl::DeleteBuffer<br/>KeyExchangeManager::removeKey
```

### 3.2 各阶段代码位置

| 阶段 | 操作 | 文件:行号 |
|------|------|----------|
| socket | Socket() | api.cpp:48-55 |
| listen | initialize_listen_server | api.cpp:169-195 |
| accept | Accept() | api.cpp:57-74 |
| connect | InitConnection | api.cpp:207-308 |
| epoll注册 | EpollLoop(fd, flags) | epoll_mode.cpp:163-177 |
| buffer创建 | AddBuffer(ip, port, fd) | socket_buf.cpp:220-241 |
| ECDH交换 | keyExchangeRequest | key_exchange.cpp:149-235 |
| 节点注册 | registerNodeRequest | api.cpp:626-701 |
| 心跳 | DealHeart | api.cpp:721-752 |
| Ping/Pong | HandlePingReq/handle_pong_request | handle_event.cpp:417-457 |
| 连接关闭 | DeleteNode/delete_by_fd | peer_node.cpp:79-107, :126-165 |
| epoll删除 | DeleteEpollEvent | epoll_mode.cpp:179-187 |
| 密钥删除 | removeKey | key_exchange.cpp:131-134 |

---

## 4. 写缓冲区状态

### 4.1 发送状态 (隐式)

SocketBuf 的 `_sendCache` 和 `_isSending` (未使用) 构成发送状态:

| 逻辑状态 | 条件 | 行为 |
|---------|------|------|
| 空闲 | _sendCache.empty() | epoll EPOLLOUT跳过 |
| 待发送 | !_sendCache.empty() | epoll EPOLLOUT触发, queue_write_counter.Push |
| 发送中 | send() 部分写入 | popAndSendMessageRequest(已发送字节) |
| 发送完成 | send() == buff.size() | popAndSendMessageRequest(全部) |

### 4.2 fd级互斥 (socket_buf.cpp:8-23)

每个fd关联一个独立的 `std::mutex`, 防止多线程同时写同一个socket:

```cpp
std::unordered_map<int, std::unique_ptr<std::mutex>> fileDescriptorSetMutex;

std::mutex& fdMutex(int fd) {
    // 如果fd不存在, 创建新的mutex
    auto search = fileDescriptorSetMutex.find(fd);
    if (search != fileDescriptorSetMutex.end())
        return *(search->second);
    // ... 创建并插入
}
```

---

## 5. 问题清单

### Q5: pulse本地修改不在nodeMap中原子更新
- **位置**: api.cpp:739
- **现象**: DealHeart中 `node.pulse -= 1` 修改的是GetNodelist返回的vector拷贝, 然后用Update写回nodeMap。两个操作间非原子。
- **风险等级**: 中
- **触发场景**: 高频心跳并发时, 可能有读旧值覆盖写的问题
- **修复建议**: 在DealHeart中直接对nodeMap加写锁后原地修改pulse值
- **验证方法**: 多线程并发测试, 检查pulse值异常

### Q6: 无连接超时与密钥超时清理
- **位置**: key_exchange.h:28 (EcdhKey.timeout未使用)
- **现象**: 定义了timeout字段但无超时清理逻辑。keyExchangeMap只增不减(只在fd关闭时removeKey)
- **风险等级**: 中
- **触发场景**: ECDH交换完成但后续未注册的fd, 密钥永久驻留内存
- **修复建议**: 实现定期扫描keyExchangeMap, 清理超时key(如300秒未使用)
- **验证方法**: 内存泄漏检测, 长时间运行监控keyExchangeMap大小

### Q7: ECDH交换同步阻塞在连接建立线程
- **位置**: key_exchange.cpp:198-206
- **现象**: keyExchangeRequest 中使用 WaitData 同步阻塞等待对方响应, 超时5秒。在refreshNodeListThread中调用, 若对方无响应则整个注册过程阻塞。
- **风险等级**: 中
- **触发场景**: 配置多个服务器, 某服务器不响应时阻塞整个节点发现流程
- **修复建议**: 改为异步回调模式, 或并行发起所有服务器的交换请求
- **验证方法**: 模拟无响应服务器场景, 观察注册延迟
