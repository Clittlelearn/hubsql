# 模块6: 调用链分析 (call_chain.md)

> **可信度标记**: 全文依据源文件调用关系交叉验证, 高可信度。

---

## 1. 连接建立流程

### 1.1 整体调用链 (Mermaid)

```mermaid
sequenceDiagram
    participant Init as InitializeNetwork
    participant Ep as EpollMode
    participant PN as PeerNode
    participant KM as KeyExchangeManager
    participant Buf as bufferControl
    participant QT as CTimer(心跳)

    Init->>Init: SIGPIPE处理
    Init->>Init: 获取本地IP
    Init->>Init: 设置SelfId/SelfIdentity/SelfHeight
    Init->>Init: 设置监听IP/Port
    Init->>Init: 启动WorkThreads::Start()
    Init->>Ep: EPOL_MODE_START()
    Init->>PN: initNodeListRefreshThread()
    Init->>PN: nodelistSwitchThread()
    Init->>QT: AsyncLoop(60s, DealHeart)

    Note over Ep: EpollWork线程
    Ep->>Ep: InitListen(): epoll_create + bind + listen
    Ep->>Ep: epoll_ctl ADD fdServerMain
    Ep->>Ep: EpollLoop(): epoll_wait循环
    activate Ep
    Ep-->>Ep: accept新连接
    Ep->>Ep: setFdNonBlocking(connFd)
    Ep->>Buf: AddBuffer(ip, port, connFd)
    Ep->>Ep: epoll_ctl ADD connFd (EPOLLIN|EPOLLOUT|EPOLLET)
    deactivate Ep

    Note over PN: refreshNodeListThread
    PN->>PN: 等待listen_thread_inited
    PN->>PN: 获取配置服务器列表
    loop 对每个配置服务器
        PN->>KM: keyExchangeRequest(dest)
        KM->>KM: ConnectNode: InitConnection + AddBuffer + epoll注册
        KM->>KM: 生成ECDH密钥对 + rand salt
        KM->>KM: sendEcdhMessageRequest(dest)
        KM->>KM: WaitData(5s) 同步等待响应
        KM->>KM: key_calculate: XOR salt + ECDH + HKDF → AES密钥
        KM->>KM: addKey(fd, key)
    end
    PN->>PN: Register(nodeMap) 注册到节点列表
```

### 1.2 详细步骤 (文件逐行)

**步骤1**: 网络初始化 `net_com::InitializeNetwork()` (api.cpp:404-489)
```
InitializeNetwork():
├── 注册SIGPIPE信号处理器                            :407-420
├── 获取配置IP, 如为空则GetLocalHostIp               :422-433
├── IP验证(非空, 非内网)                             :436-447
├── 加载默认账户, 设置自身节点信息                     :450-471
│   ├── SetSelfId(acc.GetAddr())                     :456
│   ├── SetSelfIdentity(acc.GetPubStr())             :457
│   ├── SetSelfHeight()                               :458
│   ├── set_self_ip_listen/set_self_ip_public        :460-461
│   ├── configureSelfPortForListening(kServerMainPort) :461
│   ├── setPublicSelfPort(kServerMainPort)            :463
│   ├── SetSelfName/SetSelfLogo/SetSelfVer            :465-471
├── WorkThreads::Start() 启动工作线程池               :474
├── EpollMode::EPOL_MODE_START() 启动epoll监听        :477
├── PeerNode::initNodeListRefreshThread() 启动节点发现 :480
├── PeerNode::nodelistSwitchThread() 启动节点同步      :483
└── CTimer::AsyncLoop(60s, DealHeart) 启动心跳定时器  :486
```

**步骤2**: epoll监听启动 (epoll_mode.cpp:19-44)
```
EPOL_MODE_START():
└── new thread(EpollMode::EpollWork, this)
    ├── InitListen():
    │   ├── epoll_create(MAXEPOLLSIZE=100000)
    │   ├── initialize_listen_server(kServerMainPort, 1000)
    │   │   └── Socket → Bind → Listen (SOCK_NONBLOCK)
    │   └── epoll_ctl ADD fdServerMain
    ├── listen_thread_inited = true; conditionListenThread.notify_all()
    └── EpollLoop() 主事件循环
```

**步骤3**: 连接接受 (epoll_mode.cpp:93-119)
```
epoll_wait → events[n].data.fd == fdServerMain:
├── while(Accept(listener) > 0):
│   ├── setFdNonBlocking(connFd)
│   ├── 获取对端IP/Port
│   ├── bufferControl::AddBuffer(ip, port, connFd) → 创建SocketBuf
│   └── EpollLoop(connFd, EPOLLIN|EPOLLOUT|EPOLLET)
```

**步骤4**: ECDH密钥交换 (key_exchange.cpp:149-235)
```
keyExchangeRequest(dest):
├── ConnectNode(dest)                                 :154 (peer_node.cpp:366)
│   ├── InitConnection(ip, port) → socket+connect
│   ├── AddBuffer(ip, connPort, cfd)
│   └── EpollLoop(cfd, EPOLLIN|EPOLLET|EPOLLOUT)
├── generate_ecdh_keys(key.own_key)                   :161
├── rand_salt(key.own_key.salt, 32)                    :166
├── 构造KeyExchangeRequest{msg_id, key_info}           :172-194
├── sendEcdhMessageRequest(dest, request)              :196 (api.cpp:355-363)
│   └── CommonMsg(无加密无压缩) → SendOneMessage(dest, pack)
├── WaitData(msg_id, ret_datas) 同步5秒等待            :198-206
├── 验证响应key_info长度                               :219-222
├── key_calculate(own_key, peer_key)                   :228
│   ├── bytes_xor(ownkey.salt, peerkey.salt)          :102-106
│   ├── calculate_ecdh_shared_key                     :110-113
│   └── createHkdfBytes(shared, saltXor, "ENCRYPTION") :117-121
└── addKey(fd, key)                                   :233
```

---

## 2. 消息处理流程

### 2.1 接收处理链 (Mermaid)

```mermaid
sequenceDiagram
    participant Ep as EpollMode
    participant QR as queueReader
    participant WR as WorkThread(读线程)
    participant Buf as SocketBuf
    participant QW as queue_work
    participant WW as WorkThread(工作线程)
    participant Disp as ProtobufDispatcher
    participant TP as TaskPool

    Ep->>Ep: epoll_wait 发现 EPOLLIN
    Ep->>Ep: DeleteEpollEvent(fd) (临时移除)
    Ep->>QR: queueReader.Push(E_READ, fd, ip, port)

    QR->>WR: tryWaitTop → handle_net_read
    WR->>WR: read(fd, buf, MAXLINE) 循环读取
    WR->>Buf: addReadBufferToQueue(buf, nread)
    Buf->>Buf: _cache += data (粘包缓冲)
    Buf->>Buf: 解析长度前缀 → 校验Adler32 → 提取完整消息
    Buf->>QW: sendPacketToMessageQueue → queue_work.Push(E_WORK)
    WR->>Ep: EpollLoop(fd, EPOLLIN|EPOLLOUT) (重新注册)

    QW->>WW: tryWaitTop → networkReadHandler
    WW->>WW: Pack::apartPackData → NetPack
    WW->>Disp: ProtobufDispatcher::Handle(data)

    Note over Disp: 消息处理
    Disp->>Disp: CommonMsg.ParseFromString
    Disp->>Disp: 版本检查 + 类型检查
    Disp->>Disp: DescriptorPool 动态查找消息类型
    Disp->>Disp: if compress: 解压
    Disp->>Disp: if !KeyExchange: ParseFromString→Ciphertext
    Disp->>Disp: getKey(fd) → verify_token → decrypt_ciphertext
    Disp->>Disp: subMsg->ParseFromString(plaintext)
    Disp->>Disp: 查找回调映射表
    Disp->>TP: commitXxxTask(callback, subMsg, from)
```

### 2.2 详细步骤 (文件逐行)

**读数据阶段** (work_thread.cpp:143-179)
```
handle_net_read(MsgData):
├── do { read(fd, buf, MAXLINE) } while(nread >= MAXLINE)   :147-176
├── 如果 nread > 0:
│   └── bufferControl::addReadBufferToQueue(ip, port, buf, nread) :154
│       └── SocketBuf::add_data_to_read_buffer(data, len)          (socket_buf.cpp:71-123)
│           ├── _cache += data                                     :81
│           ├── while(_cache >= 4 + messageLength):                :89
│           ├── Adler32校验                                        :99-105
│           └── sendPacketToMessageQueue → queue_work.Push         :109,136
├── 如果 nread == 0 (对端关闭):
│   ├── delete_by_fd(fd)                                          :159
│   └── removeKey(fd)                                             :160
├── 如果 nread < 0 && EAGAIN/EWOULDBLOCK:
│   └── EpollLoop(fd, EPOLLIN|EPOLLOUT|EPOLLET) 重新注册         :167
└── 如果 nread < 0 (错误):
    ├── delete_by_fd(fd)                                          :172
    └── removeKey(fd)                                             :173
```

**消息分发阶段** (dispatcher.cpp:16-166, work_thread.cpp:136-140)
```
networkReadHandler → ProtobufDispatcher::Handle(data):
├── CommonMsg.ParseFromString(data.pack.data)              :18
├── 统计 requestCountMap                                   :28-31
├── 版本检查(mm::GetNetVersion())                          :33-38
├── type非空检查                                           :39-42
├── DescriptorPool动态查找消息类型                          :45-49
├── MessageFactory创建消息实例                              :52-56
├── 解压处理(compress)                                      :60-68
├── 解密处理                                                :69-103
│   ├── KeyExchangeRequest/Response → 直接使用              :70,104-107
│   └── 其他消息 → Ciphertext解析 → getKey → verify_token → decrypt :72-102
├── subMsg->ParseFromString(str_plaintext)                  :109-113
├── 按7类回调映射表顺序匹配:                               :119-163
│   ├── blockProtocolCallbacks    → commit_block_task
│   ├── saveBlockProtocolCallbacks → CommitSaveBlockJob
│   ├── broadcastProtocol         → commitBroadcastRequest
│   ├── chainProtocolCallbacks    → commitCaTask
│   ├── netProtocolCallbacks      → CommitNetworkTask
│   ├── txProtocolCallbacks       → CommitTransactionTask
│   └── syncBlockProtocolCallbacks → CommitSyncBlockJob
└── 无匹配 → return -12                                   :165
```

---

## 3. 消息发送流程

### 3.1 发送调用链 (Mermaid)

```mermaid
sequenceDiagram
    participant App as 应用层
    participant SM as SendMessage<T>
    participant Pack as Pack
    participant Buf as bufferControl
    participant QW as queue_write_counter
    participant WR as WorkThread(写线程)
    participant TCP as TCP Socket

    App->>SM: SendMessage(dest, msg, compress, priority)
    SM->>SM: FindNode 或 locateNodeByFd 获取Node

    alt 有密钥(默认加密)
        SM->>KM: getKey(fd)
        SM->>Pack: initializeCommonMessageRequest(msg, key, ENCRYPT_TRUE, compress)
        Pack->>Pack: msg.SerializeAsString()
        Pack->>Pack: encrypt_plaintext(peer_key, plaintext, ciphertext)
        Pack->>Pack: generate_token + ciphertext.SerializeToString()
        Pack->>Pack: if compress: Compress
        Pack->>Pack: msg.set_type/version/encrypt/compress/data
    else 无密钥
        SM->>Pack: initializeCommonMessageRequest(msg, ENCRYPT_FALSE, compress)
    end

    SM->>Pack: packedCommonMessage(CommonMsg, priority, NetPack)
    Pack->>Pack: pack.data = msg.SerializeAsString()
    Pack->>Pack: pack.len + checkSum(Adler32) + flag(priority)
    SM->>Pack: packageToString(NetPack) → 在线字节流
    SM->>Buf: addWritePack_(ip, port, msg)
    SM->>QW: queue_write_counter.Push(E_WRITE, fd, ip, port)

    QW->>WR: tryWaitTop → handle_net_write
    WR->>Buf: writeBufferQueue(portAndIp) 获取缓冲区
    WR->>TCP: send(fd, buff, size) 循环发送
    WR->>Buf: popAndSendMessageRequest(n) 清除已发送数据
```

### 3.2 详细步骤 (文件逐行)

**步骤1**: SendMessage模板 (api.h:448-462)
```cpp
SendMessage(dest, msg, compress, priority):
├── 获取KeyExchangeManager::getKey(dest.fd)              :451-456
├── initializeCommonMessageRequest(commMsg, msg, key, ENCRYPT_TRUE, compress) :457
└── packedCommonMessage(commMsg, priority, pack)          :459
```

**步骤2**: 消息打包 (pack.cpp:55-63, pack.h:119-165)
```
initializeCommonMessageRequest(带密钥):
├── msg.set_type/submsg.descriptor()->name()             :122
├── msg.set_version(GetNetVersion())                     :123
├── msg.set_encrypt(ENCRYPT_TRUE)                        :124
├── submsg.SerializeAsString() → str_plaintext            :125
├── encrypt_plaintext(key.peer_key, plaintext, ciphertext) :129-133
│   ├── rand_iv (12字节)                                (key_exchange.cpp:31-34)
│   ├── aes_encrypt(plaintext, key, iv, out, tag)        (key_exchange.cpp:36-41)
│   └── ciphertext.set_{version,iv,tag,ciphertext}       (key_exchange.cpp:43-47)
├── generate_token(own_pub_key, token)                   :136-140
├── ciphertext.SerializeToString(&str_request)            :142
├── 可选: Compress(str_request)                          :144-158
├── if cpr._compressData > str_request.size(): 不压缩      :148-152
├── else: msg.set_compress(compress); msg.set_data(cpr)   :155-157
└── msg.set_data(str_request)                            :161

packedCommonMessage:
├── pack.data = msg.SerializeAsString()                  :57
├── pack.len = data.size() + 12                           :58
├── pack.checkSum = Adler32(data)                         :59
└── pack.flag = priority & 0xF                            :60
```

**步骤3**: 发送到写队列 (api.cpp:327-339)
```
SendOneMessage(to, msg, priority):
├── MsgData{type=E_WRITE, fd=to.fd, ip=to.publicIp, port=to.publicPort}
├── bufferControl::addWritePack_(ip, port, msg) → PushSendMsg :335
└── queue_write_counter.Push(sendData) → 阻塞push到优先级队列 :336
```

**步骤4**: TCP写入 (work_thread.cpp:182-242)
```
handle_net_write(MsgData):
├── 检查BufferMap是否存在这个连接                       :186-190
├── 检查fd有效                                           :191-195
├── fdMutex(fd) 获取每fd独立锁                            :196-197
├── 获取写缓冲区内容                                       :198
├── net_tcp::Send(fd, buff, size)                         :205
│   └── while循环 write(fd) 直到全部发送或EAGAIN         (api.cpp:129-154)
├── 部分发送: PopAndWriteBufferQueue(fd, ret)            :212-216
├── 全部发送: PopAndWriteBufferQueue + 检查Phone_List关闭  :218-238
```

---

## 4. 节点发现流程

### 4.1 主动注册 (refreshNodeListThread → startRegistrationNode)

```mermaid
sequenceDiagram
    participant PN as PeerNode
    participant UR as UnregisterNode
    participant KM as KeyExchangeManager
    participant Net as 远程节点

    PN->>PN: refreshNodeListThread 启动
    PN->>PN: 等待listen_thread_inited
    PN->>PN: 获取config server列表

    loop 对每个配置服务器
        PN->>KM: keyExchangeRequest(node)
        KM->>KM: ConnectNode + ECDH交换
        KM-->>KM: AES密钥就绪
        PN->>Net: RegisterNodeReq{mynode, is_get_nodelist=true, msg_id}
        Net-->>PN: RegisterNodeAck{nodes[自身+已知节点列表]}
    end

    PN->>PN: 解析RegisterNodeAck
    PN->>PN: RegistrationVerifier(验证各节点)
    PN->>PN: PeerNode::Add(合格节点)
    PN->>UR: Register({未连接节点}) 再发起注册
```

**注册请求构造** (api.cpp:626-701):
```
registerNodeRequest(dest, msgId, isNodeListFetched):
├── 构造 RegisterNodeReq                                   :630-633
├── 检查dest是否已在节点列表中(去重)                       :636-642
├── 设置mynode字段(addr,name,ip,port,timestamp,height,ver) :650-658
├── 签名: acc.Sign(SHA256(addr))                           :660-684
├── keyExchangeRequest(dest) ECDH密钥交换                  :686-691
├── dataMgrPtr.AddResNode(msgId, ipPort) 注册响应等待      :693-697
└── SendMessage(dest, getNodes, COMPRESS_TRUE, HIGH_PRIORITY) :698
```

---

## 5. 广播流程

### 5.1 新区块广播 (Mermaid)

```mermaid
sequenceDiagram
    participant API as broadcastMessage
    participant PN as PeerNode
    participant TP as TaskPool

    API->>PN: GetNodelist()
    Note over API: 计算未连接节点比例
    alt 未连接 > 25%
        API-->>API: 拒绝广播 (return false)
    end

    alt block.height < MIN_UNSTAKE_HEIGHT
        alt nodeList <= broadcast_threshold
            Note over API: 全部广播(type=1)
        else nodeList > broadcast_threshold
            Note over API: 随机选broadcast_threshold个(type=1)
        end
    else block.height >= MIN_UNSTAKE_HEIGHT
        Note over API: 查询质押余额 → 过滤eligibleAddress
        alt nodeList >= threshold^2
            Note over API: sqrt(N) 策略
        else
            Note over API: 随机选threshold个质押节点(type=1)
        end
    end

    loop 对每个目标地址
        API->>TP: commitBroadcastRequest(SendMessageTask, addr, msg)
    end

    Note over TP: 各目标节点收到后:
    TP->>TP: HandleBroadcastMsg → initializeCyclicTargetAddresses
    TP->>TP: 找到自身在环形列表位置 → 找上下邻居
    TP->>TP: 向邻居区间转发(type=2, 二轮传播)
```

### 5.2 详细步骤 (api.cpp:830-977)

**随机选择算法** (api.cpp:854-882)
```
fetchTargetIndexes(num, limit, source):
├── if limit < num: 返回空集
├── if limit == num: 返回全部地址
└── while(addrs.size() < num):
    └── index = random(0, limit-1); addrs.insert(source[index].address)
```

**平方根策略** (api.cpp:884-889)
```
getRootOfEquation(listSize):
└── 解方程 x(x+1) = listSize 的正根 → 广播节点数
```

---

## 6. 心跳处理流程 (api.cpp:721-752)

```
DealHeart():
├── 获取自身节点 + 所有节点列表                          :723-724
├── 从列表中排除自身                                     :727-734
├── 对每个节点:                                          :737-752
│   ├── node.pulse -= 1                                 :739
│   ├── if pulse <= 0:                                   :740-746
│   │   └── DeleteNode(address) (从nodeMap + epoll + buffer移除)
│   ├── else:                                            :747-751
│   │   ├── Update(node) (更新nodeMap中的pulse值)
│   │   └── SendPingReq(node) (发送Ping消息, HIGH_PRIORITY)
```

---

## 7. 关键数据管理器 dataMgrPtr

`dataMgrPtr` 是 `GlobalDataManager::get_global_data_manager()` 的宏别名 (common/global_data.h:91):
- `CreateWait(timeout, expectedCount, msgId)`: 创建等待上下文
- `AddResNode(msgId, nodeId)`: 添加预期响应节点
- `WaitData(msgId, results)`: 阻塞等待, 超时5秒
- `waitDataToAdd(msgId, nodeId, data)`: 接收方提交响应数据
