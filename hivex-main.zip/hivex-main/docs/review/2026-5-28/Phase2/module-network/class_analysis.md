# 模块6: 类与结构分析 (class_analysis.md)

> **可信度标记**: 全文依据源文件交叉验证, 高可信度。

---

## 1. Node 结构详解 (net/node.hpp:17-90)

### 1.1 字段说明

| 字段 | 类型 | 说明 | 初始化值 | 行号 |
|------|------|------|---------|------|
| address | string | 节点地址(由公钥Keccak256生成40字符hex) | "" | :20 |
| pub | string | 公钥(hex编码) | "" | :21 |
| sign | string | 签名数据 | "" | :22 |
| identity | string | 身份标识(公钥) | "" | :23 |
| name | string | 节点名称 | "" | :24 |
| logo | string | 节点logo URL | "" | :25 |
| ver | string | 版本号 | "" | :26 |
| listenIp | uint32_t | 监听IP(网络字节序) | 0 | :27 |
| listenPort | uint32_t | 监听端口(主机字节序) | 0 | :28 |
| publicIp | uint32_t | 公网IP | 0 | :29 |
| publicPort | uint32_t | 公网端口 | 0 | :30 |
| height | uint32_t | 链高度 | 0 | :31 |
| connKind | ConnKind | 连接类型(NOTYET/dataRateToOutput/PASSIV) | NOTYET | :32 |
| fd | int32_t | socket文件描述符(-1=未连接, -2=特殊状态) | -1 | :33 |
| pulse | int32_t | 心跳计数器 | HEARTBEAT_CHECKS(3) | :34 |

### 1.2 关键方法

| 方法 | 说明 | 行号 |
|------|------|------|
| operator== | 通过address比较节点 | :42-45 |
| ResetHeart() | 重置pulse = HEARTBEAT_CHECKS(3) | :52-55 |
| IsConnected() | 检查fd > 0 或 fd == -2 | :81-84 |
| SetHeight(uint32_t) | 设置链高度 | :85-88 |
| InfoStr() | 格式化输出节点信息 | :61-78 |

### 1.3 ConnKind 枚举 (node.hpp:10-15)

```
NOTYET          = 0  // 未连接
dataRateToOutput= 1  // 主动连接(外部直连)
PASSIV          = 2  // 被动接受连接
```

> **注意**: 枚举命名 `dataRateToOutput` 和 `PASSIV` 不符合C++命名惯例(用了混合命名风格且PASSIV有拼写错误)。节点连接类型命名含义对应 spec 9.6.1 表。

### 1.4 与规范(spec 9.3.1)的差异

规范Node定义包含 `time: U64` (最后通信时间戳)字段, 但实现中该字段不存在。实现通过 `pulse` 心跳计数器替代时间戳机制。

---

## 2. PeerNode 管理器 (net/peer_node.h:37-374; net/peer_node.cpp:1-577)

### 2.1 数据结构

```cpp
// 节点存储 (peer_node.h:363-364)
std::shared_mutex mutexForNodes;           // 读写锁
std::map<std::string, Node> _nodeMap;      // key=address → Node

// 自身节点 (peer_node.h:366-367)
std::mutex mutexForCurrent;
Node _currNode;                            // 本节点信息
```

### 2.2 核心方法

| 方法 | 返回 | 线程安全 | 说明 | 位置 |
|------|------|---------|------|------|
| FindNode(addr, node) | bool | shared_lock | 通过地址查找节点 | peer_node.cpp:244-255 |
| locateNodeByFd(fd, node) | bool | shared_lock | 通过fd查找节点 (O(n)遍历) | peer_node.cpp:213-224 |
| GetNodelist(type, mustAlive) | vector<Node> | shared_lock | 获取节点列表拷贝 | peer_node.cpp:258-279 |
| GetNodelistSize() | uint64_t | shared_lock | 获取节点数量 | peer_node.cpp:302-305 |
| Add(node) | bool | unique_lock | 添加节点 | peer_node.cpp:20-46 |
| Update(node) | bool | unique_lock | 更新节点 | peer_node.cpp:48-69 |
| AddOrUpdate(node) | bool | unique_lock | 添加或覆盖节点 | peer_node.cpp:71-77 |
| DeleteNode(addr) | void | unique_lock | 删除节点(含epoll/buffer清理) | peer_node.cpp:79-107 |
| delete_by_fd(fd) | void | unique_lock | 通过fd删除节点 | peer_node.cpp:126-165 |
| CloseFd(fd) | void | - | 关闭fd并清理 | peer_node.cpp:109-124 |
| ConnectNode(node) | int | - | 发起TCP连接 | peer_node.cpp:366-393 |
| DisconnectNode(node) | int | - | 断开TCP连接 | peer_node.cpp:395-409 |
| GetSelfId() | string | lock_guard | 获取自身地址 | peer_node.cpp:429-433 |
| GetSelfNode() | Node | lock_guard | 获取自身节点拷贝 | peer_node.cpp:538-542 |

### 2.3 线程模型

- **_nodeMap**: 使用 `std::shared_mutex`, 读操作用shared_lock, 写操作用unique_lock
- **_currNode**: 使用 `std::mutex`, 所有访问用lock_guard
- **_refreshThread**: detach线程, 等待listen_thread_inited后调用 startRegistrationNode (peer_node.cpp:343-364)
- **nodeSwitchThread**: detach线程, 按 node_list_refresh_time(100秒) 周期调用 syncStartNode (peer_node.cpp:325-339)

### 2.4 配置验证

Add 和 Update 方法中有配置验证调用 `MagicSingleton<Config>::GetInstance()->_Verify(node)` (peer_node.cpp:33-36), 该验证函数的具体逻辑在Config类中。

---

## 3. ProtobufDispatcher 消息分发器 (net/dispatcher.h:20-285; net/dispatcher.cpp:1-197)

### 3.1 回调映射表

| 映射表 | 类型 | 用途 | dispatcher.h行号 |
|--------|------|------|-----------------|
| chainProtocolCallbacks | map<string, ProtoCallBack> | 链协议回调 | :172 |
| netProtocolCallbacks | map<string, ProtoCallBack> | 网络协议回调 | :173 |
| broadcastProtocol | map<string, ProtoCallBack> | 广播协议回调 | :174 |
| txProtocolCallbacks | map<string, ProtoCallBack> | 交易协议回调 | :175 |
| syncBlockProtocolCallbacks | map<string, ProtoCallBack> | 同步区块回调 | :176 |
| saveBlockProtocolCallbacks | map<string, ProtoCallBack> | 保存区块回调 | :177 |
| blockProtocolCallbacks | map<string, ProtoCallBack> | 区块回调 | :178 |

### 3.2 回调注册模板方法

所有注册方法使用同一模板模式: 通过 Protobuf `T::descriptor()->name()` 获取消息类型名, 包装 callback 为接受 `MessagePtr` 的 lambda:

```cpp
// dispatcher.h:184-188
template <typename T>
void ProtobufDispatcher::registerCallback(...)
{
    chainProtocolCallbacks[T::descriptor()->name()] = [cb](const MessagePtr &msg, ...) {
        return cb(std::static_pointer_cast<T>(msg), from);
    };
}
```

### 3.3 Handle 消息处理流程 (dispatcher.cpp:16-166)

```
Handle(MsgData)
├── CommonMsg.ParseFromString(data.pack.data)      // :18-24
├── 记录请求统计 (global::requestCountMap)          // :28-31
├── 版本检查 (commonMsg.version() != kNetVersion)   // :33-38
├── type 非空检查                                    // :39-42
├── DescriptorPool 动态查找消息类型                  // :45-49
├── MessageFactory 创建消息实例                      // :52-56
├── 解压处理 (Compress)                             // :60-68
├── KeyExchange消息特殊处理(不解密)                  // :69-102
│   ├── 其他消息: ParseFromString→Ciphertext         // :72-77
│   │   ├── AES IV/TAG长度校验 (12/16)              // :78-83
│   │   ├── getKey(fd) 获取密钥                     // :85-90
│   │   ├── verify_token 验证令牌                  // :92-96
│   │   └── decrypt_ciphertext AES-GCM解密          // :98-102
│   └── KeyExchange消息: 直接使用subSerializedMessage // :104-107
├── subMsg->ParseFromString(str_plaintext)          // :109-113
└── 按优先级匹配回调映射表并提交到TaskPool:          // :116-163
    ├── blockProtocolCallbacks → commit_block_task
    ├── saveBlockProtocolCallbacks → CommitSaveBlockJob
    ├── broadcastProtocol → commitBroadcastRequest
    ├── chainProtocolCallbacks → commitCaTask
    ├── netProtocolCallbacks → CommitNetworkTask
    ├── txProtocolCallbacks → CommitTransactionTask
    └── syncBlockProtocolCallbacks → CommitSyncBlockJob
```

### 3.4 消息统计 (dispatcher.cpp:28-31)

每次Handle调用记录请求计数和字节数到 `global::requestCountMap`, 可用于网络监控。

> **注意**: 该统计未持久化, 仅内存; 且requestCountMap未设置大小上限, 长时间运行可能内存增长。【可信度: 高】

---

## 4. KeyExchangeManager 密钥交换管理器 (net/key_exchange.h:31-61; net/key_exchange.cpp:1-287)

### 4.1 数据结构

```cpp
// key_exchange.h:13-29
struct ownkey_s {
    uint8_t ec_pub_key[65];    // 己方ECDH公钥
    uint8_t ec_priv_key[32];   // 己方ECDH私钥
    uint8_t salt[32];          // 己方随机Salt
};

struct peerkey_s {
    uint8_t ec_pub_key[65];    // 对方ECDH公钥
    uint8_t aes_key[32];       // 派生AES-256密钥
    uint8_t salt[32];          // 对方Salt
};

struct EcdhKey {
    ownkey_s own_key;
    peerkey_s peer_key;
    uint64_t timeout;          // 超时时间(未在代码中使用)【需人工验证】
};

// key_exchange.h:49
std::map<int, KeyPtr> keyExchangeMap;  // key=fd → shared_ptr<EcdhKey>
mutable std::shared_mutex mtx;
```

### 4.2 核心方法

| 方法 | 说明 | 位置 |
|------|------|------|
| keyExchangeRequest(Node) | 发起方: 连接→生成密钥→发送请求→等待响应→计算AES密钥→存入map | key_exchange.cpp:149-235 |
| handleKeyExchangeRequest(msg, from) | 响应方: 验证→生成密钥→XOR Salt→计算AES→回发响应 | key_exchange.cpp:236-274 |
| key_calculate(ownkey, peerkey) | XOR Salt→ECDH共享密钥→HKDF派生AES密钥 | key_exchange.cpp:98-123 |
| addKey(fd, key) | 写入keyExchangeMap | key_exchange.cpp:125-129 |
| removeKey(fd) | 从keyExchangeMap删除 | key_exchange.cpp:131-134 |
| getKey(fd) | 读取keyExchangeMap | key_exchange.cpp:136-142 |
| hasKey(fd) | 检查是否存在 | key_exchange.cpp:144-147 |

### 4.3 密钥交换流程 (key_exchange.cpp:149-235)

```
发起方 keyExchangeRequest:
1. ConnectNode(dest) 建立TCP连接                      :154
2. generate_ecdh_keys(pub, priv) 生成ECDH密钥对      :161
3. rand_salt(salt) 生成32字节随机Salt                 :166
4. 构造KeyExchangeRequest{msg_id, key_info}           :172-194
5. sendEcdhMessageRequest 发送(不加密)                 :196
6. WaitData 同步等待KeyExchangeResponse               :198-206
7. 验证响应公钥(65字节)和Salt(32字节)长度              :219-222
8. memcpy 存入peer_key                                :225-226
9. key_calculate(own_key, peer_key) 计算共享密钥       :228-231
10. addKey(fd, key) 存入KeyExchangeMap                :233

响应方 handleKeyExchangeRequest:
1. 验证请求公钥(65)/Salt(32)                          :238-241
2. memcpy 存入peer_key                                :246-251
3. generate_ecdh_keys(pub, priv) 生成ECDH密钥对      :255
4. rand_salt(salt) 生成32字节随机Salt                 :257
5. key_calculate(own_key, peer_key) 计算共享密钥       :259-262
6. addKey(fd, key) 存入KeyExchangeMap                 :264
7. 构造KeyExchangeResponse{msg_id, key_info}          :266-271
8. SendMessage 回发(不加密, COMPRESS_TRUE)             :272
```

### 4.4 安全分析

**优势**:
1. 使用 NIST P-256 曲线 + AES-256-GCM 认证加密
2. 每次连接独立生成随机Salt, 经XOR后作为HKDF salt
3. Token机制(HMAC-SHA256)提供额外消息认证
4. 密钥交换消息本身不加密传输(正常设计)

**风险点**:
1. **内存密钥**: ECDH私钥和AES密钥存储在进程内存的keyExchangeMap中, 无内存保护(如mlock/mprotect)
2. **同步阻塞**: keyExchangeRequest使用同步WaitData等待, 阻塞调用线程最多5秒
3. **无前向安全性**: 使用静态ECDH(非临时), 私钥泄露可解密所有历史会话
4. **Token仅3字节**: HMAC-SHA256取前3字节(key_exchange.cpp:92), 碰撞概率约 2^-24

> 问题: Token长度仅3字节, 安全性较弱。建议增加到至少8字节 (HMAC-SHA256前8字节)。

### 4.5 encrypt_plaintext / decrypt_ciphertext (key_exchange.cpp:24-49, 9-22)

两函数作为自由函数实现(非KeyExchangeManager成员), 封装AES-256-GCM加密/解密:

- encrypt: 生成随机IV(12字节) → AES-GCM加密 → 设置Ciphertext{version=1, iv, tag, ciphertext}
- decrypt: 从Ciphertext提取参数 → AES-GCM解密 → 返回明文

---

## 5. EpollMode 事件循环 (net/epoll_mode.h:25-93; net/epoll_mode.cpp:1-188)

### 5.1 结构

```cpp
class EpollMode {
    int epollFd;                     // epoll文件描述符
    std::thread* _listenThread;     // 监听线程(detach)
    int fdServerMain;               // 主监听socket fd
    std::atomic<bool> haltListening = true;  // 循环控制标志
};
```

### 5.2 事件循环 (epoll_mode.cpp:47-161)

```
EpollLoop() 主循环:
├── setrlimit(RLIMIT_NOFILE, MAXEPOLLSIZE) 设置最大文件描述符 :60-64
├── while(haltListening)                                    :66
│   ├── epoll_wait(epollFd, events, MAXEPOLLSIZE, 1000ms)  :70
│   ├── for each event                                      :76
│   │   ├── EPOLLERR → getsockopt SO_ERROR → delete_by_fd   :78-91
│   │   ├── fd == fdServerMain → Accept循环 → AddBuffer → EpollLoop注册 :93-119
│   │   ├── EPOLLIN → DeleteEpollEvent → queueReader.Push(E_READ)    :120-136
│   │   └── EPOLLOUT → IsCacheEmpty检查 → queue_write_counter.Push(E_WRITE) :137-157
```

### 5.3 关键设计点

1. **epoll_wait超时1秒**: 非精确但安全的轮询间隔
2. **ET边缘触发**: EPOLLIN | EPOLLOUT | EPOLLET, 避免重复通知
3. **EPOLLIN时先DeleteEvent**: epoll_mode.cpp:123, 读取完成后在handle_net_read中重新注册 (work_thread.cpp:167,178)
4. **Accept循环**: 使用while循环确保ET模式下accept所有等待连接

---

## 6. SocketBuf 读写缓冲区 (net/socket_buf.h:47-142; net/socket_buf.cpp:34-178)

### 6.1 结构

```cpp
class SocketBuf {
    int fd;                     // 关联的socket fd
    uint64_t portAndIp;         // 打包的IP+Port标识
    std::string _cache;         // 读缓冲区
    std::mutex mutexForRead;    // 读缓冲互斥锁
    std::string _sendCache;     // 发送缓冲区
    std::mutex sendMutex;       // 发送缓冲互斥锁
    std::atomic<bool> _isSending;  // 发送状态标志(未使用) 【需人工验证】
};
```

### 6.2 粘包处理 (socket_buf.cpp:71-123)

```
add_data_to_read_buffer(data, len):
├── _cache += data                                    :81
├── if _cache.size() >= 4:                           :83
│   ├── 读取前4字节作为消息长度                        :85
│   ├── VerifyCache(超大消息修正)                     :87
│   ├── while _cache >= 4 + current_message_length:   :89
│   │   ├── 跳过长度前缀                              :91
│   │   ├── 提取消息体                                 :92
│   │   ├── 校验 Adler32 checksum                     :99-105
│   │   ├── 从_cache移除已处理数据                    :107
│   │   ├── sendPacketToMessageQueue → queue_work.Push :109
│   │   └── 继续读取下一条消息长度                     :111-115
│   └── shrink_to_fit (容量远大于使用量时)            :117-120
└── CorrectCache: 查找END_FLAG修复损坏缓冲区           :44-69
```

### 6.3 bufferControl (net/socket_buf.h:145-324; net/socket_buf.cpp:180-407)

单例管理器, 持有 `map<uint64_t, shared_ptr<SocketBuf>> _BufferMap`:

| 方法 | 功能 |
|------|------|
| AddBuffer(portAndIp, fd) | 为新连接创建SocketBuf |
| DeleteBuffer(portAndIp/fd) | 删除连接的SocketBuf |
| addReadBufferToQueue | 路由读数据到对应SocketBuf |
| addWritePack_ | 追加写数据到对应SocketBuf |
| IsCacheEmpty | 检查发送缓冲区是否为空 |
| GetSocketBuf | 获取SocketBuf指针 |

---

## 7. Pack 消息打包 (net/pack.h:23-166; net/pack.cpp:1-64)

### 7.1 在线格式 (pack.cpp:12-19)

```
[4B len][N B data][4B checkSum][4B flag][4B endFlag(7777777)]
```

- len: 消息体长度 = data.size() + 12 (3x4B尾部字段)
- data: CommonMsg Protobuf序列化数据
- checkSum: Adler32校验和
- flag: 优先级 (低4位)
- endFlag: 固定魔数 7777777

### 7.2 packageToString (pack.cpp:21-29)

将NetPack转换为在线字节流, 分配堆内存后拷贝为string。

### 7.3 apartPackData (pack.cpp:31-52)

从在线字节流解析NetPack, 要求最小长度12字节。

### 7.4 initializeCommonMessageRequest (模板, pack.h:87-165)

两个重载:
1. **无密钥版本** (pack.h:87-116): 序列化→(可选)压缩→设置CommonMsg
2. **有密钥版本** (pack.h:119-165): 序列化→AES加密→generate_token→(可选)压缩→设置CommonMsg

---

## 8. MsgQueue 优先级消息队列 (net/msg_queue.h:52-146)

### 8.1 结构

```cpp
class MsgQueue {
    std::priority_queue<MsgData, vector<MsgData>, compareMessageDataRequest> msgQueue;
    std::mutex listMutex;
    std::condition_variable_any notEmpty, notFull;
    size_t maxSize = 50000;  // 默认值
};
```

### 8.2 优先级比较 (msg_queue.h:43-49)

基于 `pack.flag & 0xF` 提取优先级, 高优先级先出队。

### 8.3 阻塞Push/Pop

- Push: 队列满则阻塞等待notFull信号
- tryWaitTop: 队列空则阻塞等待notEmpty信号, 取出最高优先级元素

---

## 9. NetPack 消息结构 (net/define.h:34-41)

```cpp
typedef struct NetPack {
    uint32_t    len       = 0;   // 消息总长度(data + 3x4字节)
    std::string data      = "";  // 序列化CommonMsg
    uint32_t    checkSum  = 0;   // Adler32校验和
    uint32_t    flag      = 0;   // 标志位(含优先级)
    uint32_t    endFlag   = END_FLAG;  // 魔法数字 7777777
} NetPack;
```

> **与规范差异**: 规范(spec 9.4.1)定义 NetPack 包含 type/data/flag/priority 字段, 但实际实现无独立的 type/priority 字段, 而是通过 CommonMsg.type 传递消息类型, priority 编码到 flag 低4位。

---

## 10. 全局状态 (net/global.h:22-42; net/global.cpp:1-24)

| 变量 | 类型 | 说明 |
|------|------|------|
| queueReader | MsgQueue | 读事件队列 |
| queue_work | MsgQueue | 工作处理队列 |
| queue_write_counter | MsgQueue | 写事件队列 |
| g_localIp | string | 本地IP |
| cpu_count | int | CPU核心数 |
| node_list_refresh_time | atomic<int> | 节点列表刷新间隔(100秒) |
| Phone_List | list<int> | 手机连接fd列表 |
| g_heartTimer | CTimer | 心跳定时器 |
| mutex_listen_thread | mutex | 监听线程同步互斥锁 |
| conditionListenThread | condition_variable_any | 监听线程同步条件变量 |
| listen_thread_inited | bool | 监听线程是否初始化完成 |
| mutexRequestCountMap | mutex | 请求计数map互斥锁 |
| requestCountMap | map<string, pair<uint32_t,uint64_t>> | 请求类型→(次数, 总字节数) |
| broadcast_threshold | int | 广播阈值(15) |

---

## 11. 问题清单

### Q1: EcdhKey.timeout 未使用
- **位置**: key_exchange.h:28
- **现象**: timeout字段定义但全代码中无任何赋值和引用
- **风险等级**: 低
- **触发场景**: 无
- **修复建议**: 移除或实现会话超时清理逻辑
- **验证方法**: grep timeout key_exchange.*

### Q2: SocketBuf._isSending 未使用
- **位置**: socket_buf.h:59
- **现象**: _isSending 定义为 atomic<bool> 但无赋值或读取
- **风险等级**: 低
- **触发场景**: 无
- **修复建议**: 移除或实现发送状态跟踪
- **验证方法**: grep _isSending socket_buf.*

### Q3: locateNodeByFd O(n)遍历
- **位置**: peer_node.cpp:213-224
- **现象**: 通过fd查找节点需遍历整个_nodeMap
- **风险等级**: 低~中
- **触发场景**: 大量节点连接时高频消息处理
- **修复建议**: 增加 fd→Node 反向索引map
- **验证方法**: 性能测试, 1000节点连接时测消息延迟

### Q4: 文件描述符-2的特殊含义
- **位置**: node.hpp:83
- **现象**: IsConnected() 中 fd > 0 || fd == -2 被认为是已连接, 但代码中从未设置fd=-2
- **风险等级**: 低
- **触发场景**: 无(未使用)
- **修复建议**: 清理或文档化fd=-2的含义
- **验证方法**: grep "fd = -2" 全项目, 结果应为空
