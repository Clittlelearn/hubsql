# 模块6: 网络层架构概览 (module_overview.md)

> **可信度标记**: 全文依据 .cpp/.h/.proto 源文件及 spec_dev.md 第9章交叉验证, 高可信度。

---

## 1. 整体架构: epoll + Protobuf + ECDH 三层结构

MeMeChain 网络层采用自研 C++20 P2P 协议栈, 架构分三层:

```
上层:  PeerNode Manager (节点发现/连接管理/心跳)
       ProtobufDispatcher (消息路由/回调注册)
       UnregisterNode (节点注销管理)

中层:  WorkThreads (读写工作线程池)
       MsgQueue x3 (读写队列分离)
       Pack/Compress (消息打包/压缩)

底层:  EpollMode (epoll事件循环)
       SocketBuf (每连接读写缓冲区)
       KeyExchangeManager (ECDH密钥交换)
       net_tcp (TCP封装:Socket/Accept/Connect/Send)
```

**数据流向**:
- **收**: epoll EPOLLIN → queueReader → handle_net_read (读取socket) → SocketBuf 粘包处理 → queue_work → ProtobufDispatcher::Handle (解密/解压/反序列化/分发)
- **发**: SendMessage模板 (加密/压缩/序列化) → queue_write_counter → handle_net_write → TCP发送

---

## 2. 核心组件与文件映射

| 组件 | 头文件 | 实现文件 | 大小 |
|------|--------|---------|------|
| TCP API | net/api.h | net/api.cpp | 11KB / 26KB |
| epoll事件循环 | net/epoll_mode.h | net/epoll_mode.cpp | 1.6KB / 5.5KB |
| 事件处理 | net/handle_event.h | net/handle_event.cpp | 4.6KB / 29.9KB |
| Peer节点管理 | net/peer_node.h | net/peer_node.cpp | 6.3KB / 13.5KB |
| 消息分发器 | net/dispatcher.h | net/dispatcher.cpp | 7.0KB / 6.4KB |
| Socket缓冲区 | net/socket_buf.h | net/socket_buf.cpp | 6.2KB / 10.2KB |
| 消息打包 | net/pack.h | net/pack.cpp | 3.5KB / 1.6KB |
| ECDH密钥交换 | net/key_exchange.h | net/key_exchange.cpp | 2.1KB / 8.8KB |
| HTTP服务器 | net/http_server.h | net/http_server.cpp | 2.1KB / 9.9KB |
| 工作线程 | net/work_thread.h | net/work_thread.cpp | 1.5KB / 5.5KB |
| 消息队列 | net/msg_queue.h | - | 2.5KB |
| Node结构 | net/node.hpp | - | 1.8KB |
| NetPack定义 | net/define.h | - | 1.0KB |
| 全局变量 | net/global.h | net/global.cpp | 1.1KB / 0.8KB |
| IP/端口工具 | net/ip_port.h | net/ip_port.cpp | 3.2KB / 4.5KB |
| 节点注销 | net/unregister_node.h | net/unregister_node.cpp | 4.0KB / 16.6KB |
| 网络版本 | net/net_version.h | net/net_version.cpp | 0.15KB / 0.17KB |
| 消息协议 | proto/net.proto | - | 3.0KB |
| 密钥交换协议 | proto/key_exchange.proto | - | 1.3KB |
| 公共消息协议 | proto/common.proto | - | 0.7KB |

---

## 3. 消息类型分类

依据 `net/handle_event.h:1-198` 和 `net/interface.h:12-44` 中注册的回调函数, 消息类型分为以下类别:

### 3.1 网络管理消息 (NetRegisterCallback)
| 消息类型 | 处理函数 | 用途 | 注册位置 (interface.h) |
|---------|---------|------|---------------------|
| RegisterNodeReq | handleRegisterNodeRequest | 节点注册请求 | :16 |
| RegisterNodeAck | handleRegisterNodeAcknowledgment | 节点注册响应 | :17 |
| SyncNodeReq | handleSyncNodeRequest | 同步节点列表请求 | :18 |
| SyncNodeAck | handleSyncNodeAcknowledgment | 同步节点列表响应 | :19 |
| PingReq | HandlePingReq | 心跳Ping | :30 |
| PongReq | handle_pong_request | 心跳Pong | :31 |
| NodeHeightChangedReq | processNodeHeightChangeRequest | 节点高度变更通知 | :36 |
| NodeAddrChangedReq | handleNodeAddressChangeRequest | 节点地址变更通知 | :37 |

### 3.2 密钥交换消息
| 消息类型 | 处理函数 | 用途 | 注册位置 |
|---------|---------|------|---------|
| KeyExchangeRequest | handleKeyExchangeRequest | ECDH密钥交换请求 | interface.h:39 |
| KeyExchangeResponse | handleKeyExchangeAcknowledgment | ECDH密钥交换响应 | interface.h:40 |

### 3.3 交易相关消息
| 消息类型 | 处理函数 | 用途 | 注册位置 |
|---------|---------|------|---------|
| CheckTxReq | handleCheckTransactionRequest | 检查交易请求 | interface.h:23 |
| CheckTxAck | handleCheckTransactionAck | 检查交易响应 | interface.h:24 |
| GetUtxoHashReq | handleGetTxUtxoHashRequest | 获取UTXO哈希请求 | interface.h:26 |
| GetUtxoHashAck | handleGetTxUtxoHashAcknowledgment | 获取UTXO哈希响应 | interface.h:27 |

### 3.4 广播消息
| 消息类型 | 处理函数 | 用途 | 注册位置 |
|---------|---------|------|---------|
| BuildBlockBroadcastMsg | HandleBroadcastMsg | 区块广播 | interface.h:42 |

### 3.5 测试/调试消息
| 消息类型 | 处理函数 | 用途 | 注册位置 |
|---------|---------|------|---------|
| PrintMsgReq | processPrintMessageRequest | 打印消息测试 | interface.h:29 |
| EchoReq | HandleEchoReq | Echo测试 | interface.h:32 |
| EchoAck | handleEchoAcknowledge | Echo响应测试 | interface.h:33 |
| TestNetReq | networkTestRequest | 网络测试请求 | interface.h:35 |
| TestNetAck | networkTestAcknowledge | 网络测试响应 | interface.h:34 |

---

## 4. 规范与实现对比表

### 4.1 节点发现 (spec 9.3.2)

| 功能点 | 规范定义 | 当前实现 | 偏差原因 |
|--------|---------|---------|---------|
| 节点注册流程 | RegisterNodeReq→RegisterNodeAck, 包含自身节点信息和可选节点列表请求 | 实现完全一致 (net/api.cpp:626-701, net/handle_event.cpp:58-286) | 无偏差 |
| 多IP重复注册检测 | 规范未明确 | handleRegisterNodeRequest 检查 from.ip 是否已有同IP节点注册 (handle_event.cpp:97-102) | 实现增强: 增加安全防护 |
| 内网节点过滤 | 规范未明确 | IsLan 检查, Dev/TestNet 跳过内网过滤, Primary 拒绝内网 (ip_port.cpp:183-206) | 按网络类型差异化处理 |
| 地址身份验证 | 规范未明确 | GenerateAddr(identity) 推导地址, ECDSA签名验证 (handle_event.cpp:134-183) | 实现增强: 安全验证 |
| 版本兼容检查 | 规范未明确 | Util::IsVersionCompatible 检查 (handle_event.cpp:112-116) | 实现增强 |

### 4.2 心跳机制 (spec 9.3.3 / HEARTBEAT_INTERVAL=60s)

| 功能点 | 规范定义 | 当前实现 | 偏差原因 |
|--------|---------|---------|---------|
| 心跳间隔 | HEARTBEAT_INTERVAL = 60秒 | 定义一致 (net/define.h:13) | 无偏差 |
| 心跳检查次数 | HEARTBEAT_CHECKS = 3 (共180秒超时) | 定义一致 (net/define.h:14) | 无偏差 |
| 心跳定时器启动 | 规范未明确具体API | AsyncLoop(HEARTBEAT_INTERVAL*1000, DealHeart) (net/api.cpp:486) | 使用CTimer异步定时器 |
| DealHeart逻辑 | pulse--; pulse<=0则删除; 否则发Ping并Update | 实现与规范一致 (net/api.cpp:721-752) | 无偏差 |
| Pulse重置 | 规范未明确 | 收到PingReq/PongReq时调用 node.ResetHeart() (handle_event.cpp:431,454) | 实现增强 |
| 排除自身 | 规范明确排除自身 | 遍历中排除 (api.cpp:728-734) | 无偏差 |
| 节点初始pulse | 规范未明确 | Node构造时初始化为 HEARTBEAT_CHECKS=3 (node.hpp:34) | 实现选择 |

### 4.3 消息格式 (spec 9.4.1)

| 功能点 | 规范定义 | 当前实现 | 偏差原因 |
|--------|---------|---------|---------|
| 消息结构 | NetPack {type:U32, data:Bytes, flag:U8, priority:U8} | NetPack {len:U32, data:string, checkSum:U32, flag:U32, endFlag:U32} (define.h:34-41) | 重大偏差: 实现比规范多了len/checkSum/endFlag字段; 规范中的type字段在实现中以CommonMsg.type替代 |
| 序列化格式 | Protobuf | Protobuf (CommonMsg包装) | 一致 |
| 消息头部 | 规范未明确 | 4字节长度前缀 + data + 4字节checkSum + 4字节flag + 4字节endFlag (pack.cpp:12-19) | 自定义二进制头部在规范中未描述 |
| 优先级编码 | 0-15 | flag & 0xF 提取 (pack.cpp:60) | 一致 |
| 消息包装 | 规范简化 | CommonMsg{version, type, encrypt, compress, data} (proto/common.proto:16-26) | 实现增加版本/加密/压缩标志 |

> **偏差说明**: NetPack的在线格式为 `[4B len][data][4B checkSum][4B flag][4B endFlag(7777777)]`, 与规范中的简化定义不一致。建议更新规范文档以反映实际在线格式。【需人工验证】

### 4.4 同步模式 (spec 9.5)

| 功能点 | 规范定义 | 当前实现 | 偏差原因 |
|--------|---------|---------|---------|
| SyncNormal | 从最近已知高度快速同步 | 实现与规范一致 (ca/sync_block.cpp, 不在本模块) | - |
| SyncFromZero | 从创世区块完整同步 | 存在对应回调注册 syncBlockProtocolCallbacks (dispatcher.h:176) | 回调注册存在, 具体同步逻辑在ca模块 |
| Broadcast | 接收广播新区块 | HandleBroadcastMsg (handle_event.cpp:777-999) | 广播转发采用Cycliclist环形邻居传播算法 |

### 4.5 ECDH密钥交换 (spec 9.7)

| 功能点 | 规范定义 | 当前实现 | 偏差原因 |
|--------|---------|---------|---------|
| 椭圆曲线 | NIST P-256 (NID_X9_62_prime256v1) | 一致 (utils/crypto.h:10) | 无偏差 |
| 公钥长度 | 65字节未压缩 | 65字节 EC_PUBLIC_KEY_LENGTH=65 (utils/crypto.h:13) | 无偏差 |
| 私钥长度 | 32字节 | 32字节 EC_PRIVATE_KEY_LENGTH=32 (utils/crypto.h:14) | 无偏差 |
| Salt长度 | 32字节 | 32字节 CRYPTO_SALT_LEN=32 (utils/crypto.h:15) | 无偏差 |
| HKDF参数 | HKDF-SHA256, info="ENCRYPTION" | 一致 (utils/crypto.h:27) | 无偏差 |
| AES算法 | AES-256-GCM | 一致 (key_exchange.cpp:12-17 解密, 24-49 加密) | 无偏差 |
| IV长度 | 12字节 | 12字节 CRYPTO_AES_IV_LEN=12 (utils/crypto.h:19) | 无偏差 |
| Auth Tag长度 | 16字节 | 16字节 AES_TAG_LENGTH=16 (utils/crypto.h:20) | 无偏差 |
| Token机制 | 规范未明确 | HMAC-SHA256(salt_3bytes, ecdh_pub_key) 取前3字节 (key_exchange.cpp:73-95) | 实现增强: 额外消息认证 |
| Ciphertext结构 | 规范定义 | cipher_version + aes_iv_12bytes + ciphertext_nbytes + aes_tag_16bytes + Token (proto/key_exchange.proto:37-43) | 比规范多了cipher_version和Token字段, 规范中也有cipher_version |

### 4.6 广播策略 (spec 9.6.2)

| 功能点 | 规范定义 | 当前实现 | 偏差原因 |
|--------|---------|---------|---------|
| 未连接节点阈值 | >25%拒绝广播 | 0.25 (api.cpp:839-846) | 一致 |
| MIN_UNSTAKE_HEIGHT分期 | 低于阈值: 随机选broadcast_threshold个节点; 否则: 只给质押节点 | 实现一致 (api.cpp:894-974) | 无偏差 |
| 区块高度低于MIN_UNSTAKE_HEIGHT | 随机选择broadcast_threshold=15个节点 | 实现一致 (global.cpp:23; api.cpp:894-918) | 无偏差 |
| 区块高度高于MIN_UNSTAKE_HEIGHT | 只广播给质押合格节点 | dbReader.getStakeUtxoByAddr 验证 (api.cpp:922-973) | 无偏差 |
| 大网络平方根策略 | 当nodeList >= broadcast_threshold^2时使用 sqrt 数量 | getRootOfEquation 实现 (api.cpp:884-889) | 规范未提及此优化 |
| 广播类型标记 | 规范未明确 | type=1表示一轮转发, type=2表示二轮转发 (api.cpp:898,909,948,960) | 实现细节在规范中未说明 |

---

## 5. 关键配置常量

| 常量 | 值 | 定义位置 |
|------|-----|---------|
| HEARTBEAT_INTERVAL | 60秒 | define.h:13 |
| HEARTBEAT_CHECKS | 3 | define.h:14 |
| MAXEPOLLSIZE | 100000 | define.h:10 |
| MAXLINE | 10240 | define.h:11 |
| END_FLAG | 7777777 | define.h:7 |
| broadcast_threshold | 15 | global.cpp:23 |
| node_list_refresh_time | 100 (秒) | global.cpp:7 |
| 工作线程数 | 128 (固定) | work_thread.cpp:32 |
| 读线程数 | 8 | work_thread.cpp:43 |
| 写线程数 | 8 | work_thread.cpp:49 |
| 消息队列最大容量 | 50000 | msg_queue.h:140-141 |
| 网络版本 | "0.0" | net_version.cpp:8 |

---

## 6. 设计特点总结

1. **三队列分离**: E_READ → queueReader, E_WORK → queue_work, E_WRITE → queue_write_counter, 读写解耦
2. **每连接双缓冲**: SocketBuf 提供独立的读缓冲区(_cache)和写缓冲区(_sendCache), 用不同mutex保护
3. **epoll边缘触发(ET)**: EpollLoop 注册 EPOLLIN|EPOLLOUT|EPOLLET, 小睡眠1秒轮询避免忙等
4. **连接时ECDH**: 每次注册节点时先做ECDH密钥交换, keyExchangeRequest内部包含ConnectNode
5. **心跳同步**: pulse计数器在DealHeart中递减, 在收到Ping/Pong时重置
6. **节点发现两种模式**: 主动连接(从配置serverList)和被动发现(从其他节点同步节点列表)
7. **广播梯度**: sqrt(N)次传播实现二级转发振荡扩散
