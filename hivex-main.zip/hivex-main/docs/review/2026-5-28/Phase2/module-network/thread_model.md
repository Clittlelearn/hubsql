# 模块6: 线程模型分析 (thread_model.md)

> **可信度标记**: 全文依据源文件线程创建和同步代码交叉验证, 高可信度。

---

## 1. 总体线程架构

```
┌─────────────────────────────────────────────────────────────┐
│                    MeMeChain 网络层线程模型                    │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────────┐                    ┌─────────────┐ │
│  │  EpollMode主线程×1   │                    │ HTTP线程×1  │ │
│  │  (detach)            │                    │ (detach)    │ │
│  │  EpollWork→EpollLoop│                    │ HttpServer:: │ │
│  │  epoll_wait(1s)     │                    │ Work()       │ │
│  └──────┬───────────────┘                    └─────────────┘ │
│         │ EPOLLIN push → queueReader                          │
│         │ EPOLLOUT push → queue_write_counter                  │
│         ▼                                                     │
│  ┌──────────────────────────────────────────────────────┐    │
│  │  读线程 pool ×8 (detach)   写线程 pool ×8 (detach)    │    │
│  │  WorkRead(0..7)            WorkWrite(0..7)            │    │
│  │  queueReader.tryWaitTop    queue_write_counter        │    │
│  │  handle_net_read           handle_net_write           │    │
│  └──────┬──────────────────────┬─────────────────────────┘    │
│         │ push → queue_work    │                              │
│         ▼                      │                              │
│  ┌──────────────────────────────────────────────────────┐    │
│  │  工作线程 pool ×128 (detach)                          │    │
│  │  Work(0..127)                                        │    │
│  │  queue_work.tryWaitTop                               │    │
│  │  networkReadHandler → ProtobufDispatcher::Handle     │    │
│  │  → TaskPool (提交CA/交易/广播/同步任务)               │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐    │
│  │  心跳定时器 CTimer (异步)                              │    │
│  │  AsyncLoop(60s, DealHeart)                           │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐    │
│  │  节点管理线程 ×2 (detach)                              │    │
│  │  refreshNodeListThread + nodeSwitchThread             │    │
│  │  节点发现注册 + 100秒周期节点同步                       │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

**总线程数**: 1(epoll) + 1(HTTP) + 8(读) + 8(写) + 128(工作) + 1(心跳) + 2(节点管理) = **149 线程**

> 如果开启HTTPS: +1(SSL监听线程) = 150线程

---

## 2. epoll 主事件循环线程

### 2.1 创建 (epoll_mode.cpp:40-45)

```cpp
bool EpollMode::EPOL_MODE_START() {
    this->_listenThread = new std::thread(EpollMode::EpollWork, this);
    this->_listenThread->detach();
    return true;
}
```

- **线程类型**: detach (不可join)
- **职责**: 单一事件循环, 处理所有连接的 I/O 事件
- **生命周期**: 程序整个运行期间

### 2.2 事件循环操作 (epoll_mode.cpp:47-161)

```
EpollLoop():
├── while(haltListening):                                  // 主循环
│   ├── epoll_wait(epollFd, events, MAXEPOLLSIZE, 1000ms)  // 1秒超时
│   ├── 处理每个就绪事件:
│   │   ├── EPOLLERR → delete_by_fd                        // 连接错误
│   │   ├── 监听fd → accept循环 → AddBuffer → 注册到epoll  // 新连接
│   │   ├── EPOLLIN → DeleteEpollEvent → queueReader.Push  // 读就绪
│   │   └── EPOLLOUT → IsCacheEmpty?Skip : queue_write_counter.Push // 写就绪
```

### 2.3 线程安全考量

- **epoll_wait本身线程安全**: epoll实例为单线程使用
- **EPOLLIN时先DeleteEpollEvent**: 防止同一连接被多次触发读事件
- **重注册在worker线程**: handle_net_read完成后重新注册 EPOLLIN|EPOLLOUT|EPOLLET
- **EPOLLOUT不删除事件**: 写事件允许持续触发

---

## 3. 工作线程池

### 3.1 线程配置 (work_thread.cpp:28-59)

```cpp
void WorkThreads::Start() {
    int workNum = 128;               // 硬编码128
    // 如果workNum==0则使用cpu_count*2, 但已被hardcode覆盖

    for (i = 0; i < 8; i++)          // 8个读线程
        threadsReadList.push_back(thread(WorkRead, i));
    for (i = 0; i < 8; i++)          // 8个写线程
        threadsTransList.push_back(thread(WorkWrite, i));
    for (i = 0; i < workNum; i++)    // 128个工作线程
        threadsWorkList.push_back(thread(Work, i));
}
```

> **注意**: workNum=128 硬编码覆盖了 `cpu_count*2` 的自动计算逻辑 (work_thread.cpp:34-37)。这意味着在4核CPU上也会有128个工作线程, 可能造成大量线程竞争。【可信度: 高】

### 3.2 读线程 (WorkRead, work_thread.cpp:85-108)

```
WorkRead(id):
├── BindCpu() 绑定CPU                              :90
├── while(1):                                      :92
│   ├── queueReader.tryWaitTop(data) 阻塞等待      :95
│   └── switch(data.type):
│       └── E_READ → handle_net_read(data)         :101
│           ├── read(fd, buf, MAXLINE) 循环读取    :151
│           ├── addReadBufferToQueue → SocketBuf粘包处理 :154
│           └── EpollLoop重新注册fd                :167,178
```

### 3.3 写线程 (WorkWrite, work_thread.cpp:62-84)

```
WorkWrite(id):
├── BindCpu() 绑定CPU                              :67
├── while(1):                                      :68
│   ├── queue_write_counter.tryWaitTop(data) 阻塞等待 :71
│   └── switch(data.type):
│       └── E_WRITE → handle_net_write(data)       :77
│           ├── fdMutex(fd) 获取fd级锁             :196-197
│           ├── writeBufferQueue→send→PopAndWrite   :198-238
│           └── Phone_List管理                      :222-237
```

### 3.4 工作线程 (Work, work_thread.cpp:110-134)

```
Work(id):
├── BindCpu() 绑定CPU                              :115
├── while(1):                                      :117
│   ├── queue_work.tryWaitTop(data) 阻塞等待        :120
│   └── switch(data.type):
│       └── E_WORK → networkReadHandler(data)      :127
│           └── ProtobufDispatcher::Handle(data)   :138
│               └── 解密→解压→反序列化→任务投递
```

### 3.5 CPU绑定 (work_thread.cpp:19-26)

```
BindCpu():
├── if cpu_count >= 4:
│   ├── index = GetCpuIndex() (递增或轮询)
│   └── setThreadCpu(index) → pthread_setaffinity_np
```

---

## 4. 消息队列的并发模型

### 4.1 三队列架构

| 队列 | 类型 | 生产者 | 消费者 | 容量 |
|------|------|--------|--------|------|
| queueReader | MsgQueue | EpollMode (1线程) | 读线程池 (8线程) | 50000 |
| queue_work | MsgQueue | 读线程 (8线程) | 工作线程池 (128线程) | 50000 |
| queue_write_counter | MsgQueue | 读线程+epoll (多线程) | 写线程池 (8线程) | 50000 |

### 4.2 优先级队列机制 (msg_queue.h:43-74)

```cpp
struct compareMessageDataRequest {
    bool operator()(MsgData &a, MsgData &b) {
        return (a.pack.flag & 0xF) < (b.pack.flag & 0xF);
        // 高优先级值 → 先出队 (priority_queue是最大堆)
    }
};
```

### 4.3 阻塞-通知模式

```cpp
Push(MsgData &data):
├── lock_guard(listMutex)
├── while(IsFull())  →  notFull.wait(listMutex)  // 满则阻塞
├── msgQueue.push(move(data))
└── notEmpty.notify_one()

tryWaitTop(MsgData &out):
├── lock_guard(listMutex)
├── while(IsEmpty())  →  notEmpty.wait(listMutex)  // 空则阻塞
├── out = move(msgQueue.top()); msgQueue.pop()
└── notFull.notify_one()
```

> **安全分析**: 使用 `std::lock_guard` + `std::condition_variable_any`, 生产者-消费者模型正确实现。Wait操作可能导致写线程完全停止(如果队列长期为满)。

---

## 5. 发送缓冲区的线程安全

### 5.1 写缓冲锁机制

SocketBuf的发送缓冲区使用两层锁:

```
Layer 1 (bufferControl::_mutex): 保护 _BufferMap 的增删
Layer 2 (SocketBuf::sendMutex): 保护 _sendCache 的读写

Layer 2b (fdMutex): 每fd独立的锁, 保护socket写操作互斥
```

### 5.2 fd级别互斥 (socket_buf.cpp:8-23)

```cpp
// 全局map: fd → unique_ptr<mutex>
std::unordered_map<int, std::unique_ptr<std::mutex>> fileDescriptorSetMutex;
std::mutex mu;  // 保护fileDescriptorSetMutex自身的插入

std::mutex& fdMutex(int fd) {
    lock_guard<mutex> lck(mu);  // 只在创建mutex时短暂锁定
    auto search = fileDescriptorSetMutex.find(fd);
    if (search != fileDescriptorSetMutex.end())
        return *(search->second);
    else {
        // 插入新的mutex并返回
        fileDescriptorSetMutex.insert({fd, make_unique<mutex>()});
        return *(fileDescriptorSetMutex[fd]);
    }
}
```

> **使用**: handle_net_write 中 `lock_guard<mutex> lck(fdMutex(data.fd))` 确保同一fd不会被多线程同时写。但由于有8个写线程, 不同的fd可以并发写入。

### 5.3 SocketBuf 读写缓冲隔离

```
SocketBuf:
├── mutexForRead → 保护 _cache (读缓冲)
└── sendMutex    → 保护 _sendCache (写缓冲)
```

读写缓冲使用**不同的mutex**, 读线程和写线程不会互相阻塞。这是良好设计。

---

## 6. PeerNode 的线程安全

### 6.1 _nodeMap 保护 (peer_node.h:363)

```cpp
std::shared_mutex mutexForNodes;
std::map<std::string, Node> _nodeMap;
```

| 操作 | 锁类型 | 方法 |
|------|--------|------|
| FindNode | shared_lock | peer_node.cpp:244-255 |
| locateNodeByFd | shared_lock | peer_node.cpp:213-224 |
| GetNodelist | shared_lock | peer_node.cpp:258-279 |
| Add | unique_lock | peer_node.cpp:20-46 |
| Update | unique_lock | peer_node.cpp:48-69 |
| AddOrUpdate | unique_lock | peer_node.cpp:71-77 |
| DeleteNode | unique_lock | peer_node.cpp:79-107 |
| delete_by_fd | unique_lock | peer_node.cpp:126-165 |

读多写少的场景使用了 shared_mutex, 设计合理。

### 6.2 _currNode 保护 (peer_node.h:366-367)

```cpp
std::mutex mutexForCurrent;
Node _currNode;
```

所有自身节点访问使用 `lock_guard<mutex>`, 单一互斥锁。

---

## 7. KeyExchangeManager 的线程安全

### 7.1 keyExchangeMap 保护 (key_exchange.h:49-50)

```cpp
std::map<int, KeyPtr> keyExchangeMap;
mutable std::shared_mutex mtx;
```

| 操作 | 锁类型 |
|------|--------|
| getKey(fd) | shared_lock |
| hasKey(fd) | shared_lock |
| addKey(fd, key) | unique_lock |
| removeKey(fd) | unique_lock |

---

## 8. 心跳定时器

### 8.1 启动 (api.cpp:486)

```cpp
global::g_heartTimer.AsyncLoop(HEARTBEAT_INTERVAL * 1000, net_com::DealHeart);
// AsyncLoop(60000ms, DealHeart)
```

- **实现**: CTimer 异步定时器, 每60秒触发 DealHeart 回调
- **CTimer内部**: 可能在独立线程中执行回调, 或使用定时器线程池

### 8.2 DealHeart 线程安全性 (api.cpp:721-752)

DealHeart 执行以下线程敏感操作:
1. `GetNodelist()` - shared_lock (读安全)
2. `DeleteNode()` - unique_lock (写安全)
3. `Update(node)` - unique_lock (写安全)
4. `SendPingReq(node)` - 内部有 getKey → SendMessage → queue_write_counter.Push

> **分析**: DealHeart 中先GetNodelist获取拷贝, 然后对拷贝遍历并修改。本地修改node.pulse后通过Update原子写入。关键点是 GetNodelist返回后_nodeMap可能被其他线程修改, 但Update/DeleteNode内部会访问最新_map并加唯一锁。

### 8.3 心跳与注册的竞态

**场景**: DealHeart正在遍历节点时, 新节点通过handleRegisterNodeRequest被Add到_nodeMap。由于DealHeart在GetNodelist时获取的是快照, 新节点不会被本轮心跳处理, 首次心跳将在下一轮(60秒后)触发。这可能导致新节点在注册后最多60秒后才开始心跳。

---

## 9. 线程间通信汇总

| 通信路径 | 机制 | 方向 |
|---------|------|------|
| EpollMode → 读线程 | queueReader (MsgQueue) | 1→N |
| EpollMode → 写线程 | queue_write_counter (MsgQueue) | 1→N |
| 应用层 → 写线程 | queue_write_counter (MsgQueue) | N→N |
| 读线程 → 工作线程 | queue_work (MsgQueue) | N→N |
| CTimer → DealHeart | 直接函数调用 | 1→1 |
| Worker → TaskPool | commitXxxTask | N→N |
| listen_thread → refreshNodeListThread | conditionListenThread | 1→1 |

---

## 10. 问题清单

### Q8: 128个工作线程硬编码
- **位置**: work_thread.cpp:32
- **现象**: `int workNum = 128;` 硬编码, 覆盖了 cpu_count*2 的自动计算
- **风险等级**: 中
- **触发场景**: 在低配机器(2核4G)上创建128个线程, 大量上下文切换
- **修复建议**: 移除硬编码, 使用 `cpu_count * 2` 或通过配置项控制
- **验证方法**: 在低配机器启动, 检查线程数

### Q9: 读线程删除epoll事件与重注册的时序
- **位置**: epoll_mode.cpp:123; work_thread.cpp:167,178
- **现象**: EpollLoop中EPOLLIN处理时先 DeleteEpollEvent(fd), 然后在handle_net_read完成后重注册。期间该fd不在epoll监视中, 可能丢失事件。
- **风险等级**: 低
- **触发场景**: 高频写入场景下, 删除事件期间的数据可能不会触发新的EPOLLIN
- **修复建议**: 使用 EPOLLONESHOT 标志, 由内核保证单次触发后自动移除
- **验证方法**: 高频短消息压力测试, 检查是否有消息丢失

### Q10: DealHeart中排除自身的erase-in-loop
- **位置**: api.cpp:728-734
- **现象**: 在迭代中 `it = pubNodeList_.erase(it)`, 这是正确的erase-iterator用法。但GetNodelist返回的是拷贝, 不会影响_nodeMap。
- **风险等级**: 低 (实现正确, 仅提示)
- **触发场景**: 无
- **修复建议**: 可改为 `std::remove_if` + `erase` 惯用法
- **验证方法**: 代码审查

### Q11: fileDescriptorSetMutex 未清理
- **位置**: socket_buf.cpp:8-23
- **现象**: fdMutex() 创建 per-fd mutex 后, 在连接关闭(close_fd/delete_by_fd)时未从 fileDescriptorSetMutex 中删除对应条目
- **风险等级**: 低
- **触发场景**: 长期运行且大量连接建立/关闭后, fileDescriptorSetMutex 持续增长导致内存泄漏
- **修复建议**: 在close(fd)时同步删除 fileDescriptorSetMutex.erase(fd)
- **验证方法**: 连接压测后检查 fileDescriptorSetMutex.size() 是否持续增长
