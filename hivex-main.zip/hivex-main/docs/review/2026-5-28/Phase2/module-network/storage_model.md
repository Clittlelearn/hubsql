# 模块6: 存储模型分析 (storage_model.md)

> **可信度标记**: 全文依据源文件数据结构定义和操作代码交叉验证, 高可信度。

---

## 1. 概述

MeMeChain 网络层的存储模型是**纯内存模型**, 不依赖任何持久化存储(如 RocksDB/LevelDB)来保存网络状态。网络层状态在节点重启后完全丢失, 通过主动发现和注册重建。

---

## 2. 节点列表存储

### 2.1 数据结构 (peer_node.h:363-364)

```cpp
class PeerNode {
    std::shared_mutex mutexForNodes;
    std::map<std::string, Node> _nodeMap;  // key = address (40-char hex)
};
```

### 2.2 存储特征

| 特征 | 说明 |
|------|------|
| 存储介质 | 进程内存 |
| 键 | 节点地址 (string, 40字符hex) |
| 值 | Node 完整结构 |
| 持久化 | 无 |
| 最大容量 | 无硬限制 (受 std::map 和内存限制) |
| 线程安全 | shared_mutex |

### 2.3 数据生命周期

```
节点数据生命周期:
┌─────────────────────────────────────────────────────────┐
│  加入: Add/AddOrUpdate (收到RegisterNodeAck或注册请求)    │
│    ↓                                                     │
│  使用: FindNode/GetNodelist/locateNodeByFd               │
│    ↓                                                     │
│  更新: Update (心跳重置pulse, 高度变更等)                  │
│    ↓                                                     │
│  过期: DealHeart中 pulse--; pulse<=0 时自动删除            │
│    ↓                                                     │
│  手动删除: DeleteNode/delete_by_fd (fd错误或连接关闭)     │
└─────────────────────────────────────────────────────────┘
```

### 2.4 节点发现与填充

节点列表的初始来源:
1. **配置文件**: `MagicSingleton<Config>::GetInstance()->GetServer()` → `refreshNodeListThread` 中遍历配置服务器列表
2. **主动注册**: `startRegistrationNode` → 向配置服务器发送 `RegisterNodeReq(is_get_nodelist=true)` → 服务器返回已知节点列表
3. **被动发现**: 收到 `RegisterNodeAck` 中携带的节点列表 → `RegistrationVerifier` 验证 → `Add` 到 nodeMap
4. **同步扩展**: `syncStartNode` (每100秒) → 向所有已知节点请求 `SyncNodeReq` → 收集并交叉验证节点列表

---

## 3. 密钥交换映射存储

### 3.1 数据结构 (key_exchange.h:31-51)

```cpp
class KeyExchangeManager {
    using KeyPtr = std::shared_ptr<EcdhKey>;
    std::map<int, KeyPtr> keyExchangeMap;  // key = fd (int)
    mutable std::shared_mutex mtx;
};
```

### 3.2 EcdhKey 结构

```
EcdhKey {
    ownkey_s own_key: {
        uint8_t ec_pub_key[65];    // 己方NIST P-256公钥
        uint8_t ec_priv_key[32];   // 己方ECDH私钥
        uint8_t salt[32];          // 己方随机Salt
    }
    peerkey_s peer_key: {
        uint8_t ec_pub_key[65];    // 对方NIST P-256公钥
        uint8_t aes_key[32];       // 派生AES-256密钥
        uint8_t salt[32];          // 对方Salt
    }
    uint64_t timeout;             // 超时字段(未使用)
}
```

### 3.3 存储特征

| 特征 | 说明 |
|------|------|
| 存储介质 | 进程内存 |
| 键 | fd (int, socket文件描述符) |
| 值 | shared_ptr<EcdhKey> (堆上分配) |
| 持久化 | 无 |
| 每条目大小 | 约 290 字节 |
| 最大容量 | 无硬限制, 随连接数增长 |
| 线程安全 | shared_mutex |
| 清理机制 | removeKey(fd) 在关闭连接时调用 |

### 3.4 敏感数据存储

> **安全警告**: ECDH 私钥 (ec_priv_key, 32字节) 和 AES 密钥 (aes_key, 32字节) 明文存储在进程堆内存中。无加密保护(mprotect/mlock/secure_clear), 可从内存dump中直接提取。

**敏感数据路径**:
```
ec_priv_key: 内存 → crypto::generate_ecdh_keys → keyExchangeMap[fd].own_key.ec_priv_key
aes_key:     内存 → crypto::createHkdfBytes → keyExchangeMap[fd].peer_key.aes_key
```

### 3.5 密钥清理

| 事件 | 清理操作 | 位置 |
|------|---------|------|
| handle_net_read: nread==0 (对端关闭) | removeKey(fd) | work_thread.cpp:160 |
| handle_net_read: nread<0 且非EAGAIN | removeKey(fd) | work_thread.cpp:173 |
| delete_by_fd | 调用close/DeleteBuffer/DeleteEpollEvent | peer_node.cpp:126-165 |
| DeleteNode | 调用close/DeleteBuffer/DeleteEpollEvent | peer_node.cpp:79-107 |

> **注意**: delete_by_fd 和 DeleteNode 中**没有**调用 KeyExchangeManager::removeKey(fd)。密钥仅在 handle_net_read 中两处显式删除。这可能在某些关闭路径(如EPOLLERR导致delete_by_fd)中留下孤立的keyExchangeMap条目。【可信度: 高, 需人工验证】

---

## 4. SocketBuffer 映射存储

### 4.1 数据结构 (socket_buf.h:145-158)

```cpp
class bufferControl {
    std::mutex _mutex;
    std::map<uint64_t, shared_ptr<SocketBuf>> _BufferMap;  // key = portAndIp(uint64)
};
```

### 4.2 portAndIp 编码 (api.cpp:366-371)

```cpp
uint64_t dataPackPortAndIp(uint16_t port, uint32_t ip) {
    uint64_t ret = port;
    ret = ret << 32 | ip;
    return ret;
}
// 格式: [port(16bit)][ip(32bit)] = 高32位=port, 低32位=ip
```

### 4.3 存储特征

| 特征 | 说明 |
|------|------|
| 存储介质 | 进程内存 |
| 键 | portAndIp (uint64, ip+port打包) |
| 值 | shared_ptr<SocketBuf> |
| 持久化 | 无 |
| 线程安全 | std::mutex (_mutex) |
| 清理 | DeleteBuffer(portAndIp/fd) |

---

## 5. UnregisterNode 存储

### 5.1 数据结构 (unregister_node.h:143-154)

```cpp
class UnregisterNode {
    std::shared_mutex mutexForNodes;
    std::map<std::string, Node> _nodes;  // key = ip+port字符串

    std::mutex mutexStackList;
    std::map<uint64_t, map<string, int>> stake_node_list;     // timestamp → {addr→count}
    std::map<uint64_t, map<string, int>> unstakeNodeList;     // timestamp → {addr→count}
};
```

### 5.2 存储特征

| 特征 | 说明 |
|------|------|
| 存储介质 | 进程内存 |
| stake_node_list | 按时间戳索引的质押节点统计表 (保留最近2轮) |
| unstakeNodeList | 按时间戳索引的非质押节点统计表 (保留最近2轮) |
| 持久化 | 无 |
| 容量 | stake/unstake各保留2个条目, oldest在超过2个时清理 (unregister_node.cpp:377-380) |

### 5.3 共识节点列表 (unregister_node.h:150)

```cpp
std::map<uint64_t, std::map<Node, int, NodeCompare>> _consensusNodeList;
```

通过 `data_to_split_and_insert` 方法将同步来的节点按质押状态分拆为 stake/unstake, 供共识层使用。

---

## 6. 请求统计存储

### 6.1 数据结构 (global.h:39)

```cpp
std::mutex mutexRequestCountMap;
std::map<std::string, std::pair<uint32_t, uint64_t>> requestCountMap;
// key = 消息类型名 (protobuf descriptor name)
// value = (请求次数, 累计字节数)
```

### 6.2 存储特征

| 特征 | 说明 |
|------|------|
| 存储介质 | 进程内存 |
| 持久化 | 无 |
| 更新频率 | 每条消息处理时更新 (dispatcher.cpp:28-31) |
| 容量限制 | 无硬限制 (受Protobuf消息类型数量限制, 约20-30种) |
| 用途 | 监控/诊断 |

---

## 7. 全局配置与参数

| 变量 | 类型 | 默认值 | 定义位置 |
|------|------|--------|---------|
| broadcast_threshold | int | 15 | global.cpp:23 |
| node_list_refresh_time | atomic<int> | 100 秒 | global.cpp:7 |
| g_localIp | string | 自动检测 | global.cpp:5 |
| HEARTBEAT_INTERVAL | constexpr int | 60 秒 | define.h:13 |
| HEARTBEAT_CHECKS | constexpr int | 3 | define.h:14 |
| MAXEPOLLSIZE | constexpr int | 100000 | define.h:10 |
| MAXLINE | constexpr int | 10240 | define.h:11 |
| IP_LEN | constexpr int | 16 | define.h:8 |

---

## 8. 数据恢复与重启

### 8.1 重启后状态

节点重启后, 所有网络层内存状态丢失:
- _nodeMap: 空 → 从配置服务器重新注册发现
- keyExchangeMap: 空 → 所有连接重新ECDH交换
- _BufferMap: 空 → 新连接重新创建
- stake_node_list/unstakeNodeList: 空 → 重新同步
- requestCountMap: 空 → 从0开始统计

### 8.2 恢复时间估算

```
节点恢复流程:
1. epoll监听就绪                           < 1秒
2. 连接到配置服务器 + ECDH交换              < 5秒/服务器
3. 发送RegisterNodeReq + 获取节点列表       < 5秒
4. 向所有已知节点发送SyncNodeReq            < 5秒 (超时5秒)
5. 从已知节点获取区块同步                   (取决于链高度)
```

---

## 9. 问题清单

### Q12: ECDH私钥无安全擦除
- **位置**: key_exchange.h:16, key_exchange.cpp: 全文件
- **现象**: ECDH私钥(ec_priv_key)和AES密钥(aes_key)存储在堆内存(shared_ptr<EcdhKey>)中。removeKey使shared_ptr析构, 但未显式安全擦除(memset_s/OPENSSL_cleanse)密钥缓冲区。
- **风险等级**: 高 (安全性)
- **触发场景**: 攻击者通过内存dump提取密钥, 可解密所有会话
- **修复建议**: 在EcdhKey析构时显式清零密钥字段; 考虑使用mlock锁定敏感内存页
- **验证方法**: 内存dump分析, 检查密钥是否可恢复

### Q13: delete_by_fd遗漏keyExchangeMap清理
- **位置**: peer_node.cpp:126-165
- **现象**: delete_by_fd 关闭连接时未调用 KeyExchangeManager::removeKey(fd)。而 handle_net_read 在两处调用 removeKey。如果通过 EPOLLERR 路径触发 delete_by_fd, 则密钥遗留。
- **风险等级**: 中
- **触发场景**: 连接异常断开(EPOLLERR触发), EcdhKey对象保留在内存中直到程序退出
- **修复建议**: 在 delete_by_fd 和 DeleteNode 中增加 KeyExchangeManager::removeKey(fd) 调用
- **验证方法**: grep "removeKey" 确认所有关闭路径都调用了此方法

### Q14: requestCountMap无限增长风险
- **位置**: dispatcher.cpp:28-31
- **现象**: requestCountMap 使用 `operator[]` 插入, pair<次数,字节> 持续累加。虽然key数量受限于消息类型数量(约20-30), 但字节计数(uint64_t)理论上可能溢出。
- **风险等级**: 低
- **触发场景**: 长期运行(数月)且大量消息, uint64_t字节计数器溢出(需要 2^64 / (假设100MB/s) ≈ 5850年)
- **修复建议**: 不需要修复, 溢出风险极低
- **验证方法**: 不需要

### Q15: output_port仅通过getsockname获取, 可能与listenPort不一致
- **位置**: api.cpp:238-240 (InitConnection)
- **现象**: `getsockname(confd, ...)` 获取的是系统分配的本地端口, 可能与配置文件中的listenPort不同(当端口被占用发生重分配时或NAT场景)
- **风险等级**: 中
- **触发场景**: Docker/VM NAT环境, 对外广播错误的端口号
- **修复建议**: 对外通信使用配置中的listenPort而非系统实际分配的端口
- **验证方法**: 在Docker环境中启动, 检查RegisterNodeReq中携带的端口号
