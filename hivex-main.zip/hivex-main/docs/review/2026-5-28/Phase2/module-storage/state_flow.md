# 模块2: 存储层 (RocksDB) 状态流转

## 1. RocksDB 事务状态流转

### 1.1 事务生命周期状态机

```mermaid
stateDiagram-v2
    [*] --> Created: DBReadWriter构造
    
    Created --> Idle: reInitTransaction()
    Idle --> Active: transactionInit()
    note right of Active: txn_ = BeginTransaction()
    
    Active --> Writing: Put/Delete操作
    Writing --> Writing: 连续Put/Delete
    Writing --> Committing: transactionCommit()
    Writing --> RollingBack: transactionRollBack()
    Writing --> RollingBack: ~DBReadWriter()析构未提交
    
    Committing --> Committed: Commit成功
    Committed --> [*]: delete txn_
    Committing --> Error: Commit失败
    
    RollingBack --> RolledBack: Rollback完成
    RolledBack --> [*]: delete txn_
    RollingBack --> Error: Rollback失败
    
    Active --> Idle: txn_为null(内部保持)
    Idle --> Active: reInitTransaction()
```

**状态说明**:

| 状态 | 触发条件 | txn_状态 | autoOperationTrans | 位置 |
|------|---------|---------|--------------------|------|
| Created | `DBReadWriter(txn_name)` | nullptr (尚未初始化) | false | db_api.cpp:802-806 |
| Active | `transactionInit()` 成功 | 有效Transaction指针 | true | rocksdb_read_write.cpp:17-25 |
| Writing | Put/Delete/Merge操作 | 有效Transaction指针 | true | 各写操作方法 |
| Committed | `transactionCommit()` 成功 | nullptr (已delete) | false | rocksdb_read_write.cpp:27-51 |
| RolledBack | `transactionRollBack()` 成功 | nullptr (已delete) | false | rocksdb_read_write.cpp:53-77 |
| Error | Commit/Rollback失败 | 可能悬空 | 未知 | - |

### 1.2 详细事务操作流程

```mermaid
flowchart TD
    A[DBReadWriter构造函数] --> B[autoOperationTrans = false]
    B --> C[reInitTransaction]
    C --> D[transactionRollBack 当前事务]
    D --> E{autoOperationTrans?}
    E -->|true| F[调用RocksDBReadWriter::transactionRollBack]
    F --> G[txn_->Rollback + delete txn_]
    G --> H[autoOperationTrans = true]
    H --> I[transactionInit]
    I --> J[txn_ = db_->BeginTransaction]
    J --> K{nullptr?}
    K -->|是| L[ERRORLOG, 返回DB_ERROR]
    K -->|否| M[return DB_SUCCESS]
    
    N[业务操作 Put/Delete/Merge] --> O{txn_有效?}
    O -->|否| P[返回错误]
    O -->|是| Q[执行rocksdb操作]
    
    R[transactionCommit] --> S{autoOperationTrans?}
    S -->|false| T[返回DB_SUCCESS 已提交]
    S -->|true| U[调用RocksDBReadWriter::transactionCommit]
    U --> V[txn_->Commit]
    V --> W{成功?}
    W -->|是| X[autoOperationTrans = false]
    X --> Y[delete txn_]
    Y --> Z[return DB_SUCCESS]
    W -->|否| AA[ERRORLOG, return DB_ERROR]
    
    AB[~DBReadWriter析构] --> AC[transactionRollBack]
    AC --> AD{autoOperationTrans?}
    AD -->|false| AE[no-op, 已提交]
    AD -->|true| AF[txn_->Rollback]
    AF --> AG[delete txn_]
    AG --> AH[return DB_SUCCESS]
```

**autoOperationTrans 关键作用** (db_api.cpp:812-826, db_api.h:2691):
- 在 `reInitTransaction()` 中设置为 `true` (db_api.cpp:819)
- 在 `transactionCommit()` 成功后设置为 `false` (db_api.cpp:833)
- 在 `~DBReadWriter()` 析构时, 如果 `autoOperationTrans == true`, 自动 Rollback
- **实现了一种RAII风格的事务管理**: 如果事务生命周期中抛出异常或提前返回, 析构函数保证事务被回滚

### 1.3 mergeValue 操作内部状态流转

```mermaid
flowchart TD
    A[mergeValue key=K value=V] --> B[readForUpdate K]
    B --> C{读取结果?}
    C -->|Success| D[SplitString 旧值]
    D --> E{V在列表中?}
    E -->|否| F{firstOrLast?}
    F -->|true| G[V插入列表开头]
    F -->|false| H[V追加到列表末尾]
    G --> I[拼接所有非空元素]
    H --> I
    I --> J[writeData K 新值]
    E -->|是| K[跳过, 返回true]
    C -->|NotFound| L[writeData K V]
    J --> M{写入成功?}
    L --> M
    M -->|是| N[返回true]
    M -->|否| O[返回false]
```

**mergeValue 原子性保证**:
1. 整个过程在同一个 Transaction 内
2. `GetForUpdate` 对Key加排他锁, 防止其他事务并发修改
3. Read-Modify-Write 三步在事务内原子完成
4. 如果写操作失败, 整个事务可以回滚

---

## 2. 数据库生命周期状态

### 2.1 RocksDB 实例状态

```mermaid
stateDiagram-v2
    [*] --> Uninitialized: RocksDB构造
    
    Uninitialized --> PathSet: setDBPath(path)
    PathSet --> Opening: initDB(retStatus)
    PathSet --> Destroyed: sestoryDB()
    
    Opening --> Ready: TransactionDB::Open成功
    Opening --> Error: Open失败
    
    Ready --> Destroying: sestoryDB() / ~RocksDB()
    Destroying --> Destroyed: db_->Close() + delete db_
    
    Destroyed --> [*]
    Error --> [*]
```

**状态详细说明**:

| 状态 | isInitialized | db_ | 可执行操作 | 进入条件 |
|------|---------------|-----|-----------|---------|
| Uninitialized | false | nullptr | 无 | `RocksDB()` 构造函数 |
| PathSet | false | nullptr | setDBPath | `setDBPath(path)` |
| Opening | false→true | nullptr→有效指针 | 无 | `initDB()` 执行中 |
| Ready | true | 有效指针 | 读/写/事务 | `TransactionDB::Open` 成功 |
| Destroying | true→false | 有效→nullptr | 无 | `sestoryDB()` 执行中 |
| Destroyed | false | nullptr | 无 | `Close()` 和 `delete` 完成 |
| Error | false | nullptr | 无 | `Open` 失败 |

### 2.2 RocksDBDataReader / RocksDBReadWriter 生命周期

```mermaid
stateDiagram-v2
    [*] --> Constructed: 构造(传入shared_ptr)
    
    Constructed --> Ready: RocksDB.isInitSuccess()==true
    Constructed --> Error: RocksDB.isInitSuccess()==false
    
    Ready --> Operating: readData/multiReadData
    Operating --> Operating: 连续操作
    
    Operating --> Error: kIOError → exit(-1)
    Operating --> [*]: 析构(shared_ptr释放)
```

**RocksDBReadWriter 额外状态**:

```mermaid
stateDiagram-v2
    [*] --> Constructed: 构造(传入shared_ptr + txn_name)
    
    Constructed --> Ready: RocksDB.isInitSuccess()==true
    Ready --> NoTx: txn_==nullptr
    NoTx --> HasTx: transactionInit()
    HasTx --> NoTx: transactionCommit/Rollback
    HasTx --> Operating: 读写操作
    Operating --> Operating: 连续操作
    HasTx --> [*]: 析构(未回滚?)
```

**注意**: `RocksDBReadWriter::~RocksDBReadWriter()` 析构函数是**空的** (rocksdb_read_write.cpp:13-16):
```cpp
RocksDBReadWriter::~RocksDBReadWriter()
{

}
```
这意味着如果在 Commit/Rollback 之前就销毁 `RocksDBReadWriter`, `txn_` 指针会**泄漏**, 且事务不会自动回滚。但上层 `DBReadWriter::~DBReadWriter()` 会调用 `transactionRollBack()` (db_api.cpp:808-811), 所以只要正确使用 DBReadWriter 封装, 就能保证事务清理。

---

## 3. Key-Value 数据的状态

### 3.1 区块高度映射的数据状态

由于支持 DAG/分叉, 同一个高度可以对应多个区块哈希, 通过 `mergeValue` 管理:

```
Key: "blkht2blkhs_{height}"

初始状态:   Key不存在 (NotFound)
添加主块:   Value = "mainHash_"
添加分叉:   Value = "mainHash_forkHash1_"
添加更多:   Value = "mainHash_forkHash1_forkHash2_"
删除分叉:   Value = "mainHash_forkHash2_"
全部删除:   Value = "" → deleteData (删除Key)
```

注意: 尾部 `_` 是分隔符的一部分, 在 SplitString 时用于解析。

### 3.2 UTXO集合的数据状态

```
Key: "addr2utxo_{address}{assetType}"

初始状态:      Key不存在
添加UTXO:      Value = "utxoHash1_"
继续添加:      Value = "utxoHash1_utxoHash2_utxoHash3_"
消费UTXO:      Value = "utxoHash1_utxoHash3_"  (removeMergeValue删除utxoHash2)
全部消费:      Value = "" → deleteData (删除Key)
```

### 3.3 委托关系的数据状态

委托关系使用 "复合值" 存储, 分隔符为 `-`:
```
Key: "bonusaddr2delegatingaddrandassettype_{bonusAddr}"
Value: "delegatingAddr1-assetType1_delegatingAddr2-assetType2_"

其中 `_` 是顶层分隔符, `-` 是地址和资产类型之间的连接符
```
依据: `db/db_api.cpp:1062-1068` (setDelegatingAddrAndAssetTypeByBonusAddr)

---

## 4. 事务异常路径分析

### 4.1 事务提交失败

```
transactionCommit() 失败:
  1. autoOperationTrans 保持 true (不会设为false)
  2. DBReadWriter 析构时调用 transactionRollBack()
  3. Rollback成功 → 数据回滚
  4. Rollback失败 → 日志记录, 返回DB_ERROR
```

依据: `db/db_api.cpp:828-838`, `db/db_api.cpp:1555-1567`

### 4.2 kIOError 致命错误

在三个底层类中, 遇到 `kIOError` 都直接 `exit(-1)`:
- `RocksDBDataReader`: rocksdb_read.cpp:93-97
- `RocksDBReadWriter::readData`: rocksdb_read_write.cpp:338-342
- `RocksDBReadWriter::readForUpdate`: rocksdb_read_write.cpp:467-471
- `RocksDBReadWriter::multiReadData`: rocksdb_read_write.cpp:124-128

**分析**: 这意味着任何 RocksDB 底层 I/O 错误都会导致进程直接退出。在分布式区块链节点中, 这种设计可能导致所有节点同时崩溃。建议替换为优雅关闭流程。

---

**可信度说明**: 所有状态流转均基于源代码逻辑分析, 可信度: **高**。
