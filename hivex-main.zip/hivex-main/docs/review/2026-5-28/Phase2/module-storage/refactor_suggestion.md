# 模块2: 存储层 (RocksDB) 重构建议

## 1. 现状分析

### 1.1 文件规模

| 文件 | 大小 | 行数 | 说明 |
|------|------|------|------|
| `db/db_api.h` | 81.7 KB | 2694 行 | **核心问题**: 项目最大头文件 |
| `db/db_api.cpp` | 57.3 KB | 1675 行 | 实现文件 |
| `db/rocksdb.h` | 2.2 KB | 94 行 | 适量 |
| `db/rocksdb.cpp` | 3.3 KB | 118 行 | 适量 |
| `db/rocksdb_read.h` | 2.2 KB | 68 行 | 适量 |
| `db/rocksdb_read.cpp` | 3.0 KB | 99 行 | 适量 |
| `db/rocksdb_read_write.h` | 6.3 KB | 196 行 | 适量 |
| `db/rocksdb_read_write.cpp` | 13.3 KB | 473 行 | 适中 |

### 1.2 核心问题

`db/db_api.h` 是一个 2694 行的巨型头文件, 包含:
- 1 个枚举 (DBStatus)
- 2 个类 (DBReader, DBReadWriter)
- 约 **120个公开方法**
- 约 **20个私有方法**
- 跨越 **12个数据域**

**影响**:
1. **编译时间**: 任何上层模块 `#include "db/db_api.h"` 都会导致 db_api.h 中的所有模板/内联/方法声明被编译
2. **耦合度高**: 修改任何一个数据域的接口都需要重新编译所有包含此头文件的翻译单元
3. **可维护性差**: 在一个2694行的文件中查找定位特定方法困难
4. **代码审查困难**: PR 中的 diff 难以理解具体影响范围

---

## 2. 拆分方案

### 2.1 总体思路

按**数据域**和**操作类型**将 DBReader 和 DBReadWriter 拆分为独立模块:

```
db/
├── db_init.h / db_init.cpp              ← 全局初始化 DBInit()
├── db_status.h                           ← DBStatus 枚举 (独立)
│
├── db_reader.h                           ← 基础只读类 (readData, multiReadData)
├── db_writer.h                           ← 基础读写类 (writeData, deleteData, mergeValue, 事务)
│
├── db_block.h / db_block.cpp            ← 区块数据域 (get/set/remove)
├── db_transaction.h / db_transaction.cpp ← 交易数据域
├── db_utxo.h / db_utxo.cpp              ← UTXO/余额数据域
├── db_stake.h / db_stake.cpp            ← 质押数据域
├── db_delegation.h / db_delegation.cpp   ← 委托数据域
├── db_contract.h / db_contract.cpp      ← 合约/EVM 数据域
├── db_vote.h / db_vote.cpp              ← 投票/提案数据域
├── db_lock.h / db_lock.cpp              ← 锁定数据域
├── db_consensus.h / db_consensus.cpp    ← 共识统计数据域
├── db_global.h / db_global.cpp          ← 全局通缩数据域
│
├── db_rocksdb.h / db_rocksdb.cpp         ← 保持原有拆分
├── db_rocksdb_read.h / db_rocksdb_read.cpp
└── db_rocksdb_read_write.h / db_rocksdb_read_write.cpp
```

### 2.2 详细方案

#### 2.2.1 db_status.h - 状态码枚举

```cpp
// db/db_status.h (约15行)
#ifndef DB_STATUS_HEADER
#define DB_STATUS_HEADER

enum DBStatus {
    DB_SUCCESS = 0,
    DB_ERROR = 1,
    DB_PARAM_NULL = 2,
    DB_NOT_FOUND = 3,
    DB_IS_EXIST = 4,
    DB_DESERIALIZATION_FAILED = 5
};

#endif
```

**拆分理由**: DBStatus 被所有数据域模块引用, 作为独立头文件可以避免循环依赖。

#### 2.2.2 db_reader.h - 基础只读类

```cpp
// db/db_reader.h (约50行)
// 仅包含 readData / multiReadData 两个基础方法
// 作为所有数据域 Reader 的基类
```

#### 2.2.3 db_writer.h - 基础读写类

```cpp
// db/db_writer.h (约80行)
// 继承 db_reader, 添加事务管理 + writeData/deleteData/mergeValue
// 作为所有数据域 Writer 的基类
```

#### 2.2.4 数据域模块 (通用模式)

每个数据域模块遵循统一模式:

```cpp
// db/db_block.h (约150行)
class BlockReader : public DBReader {
public:
    DBStatus getBlockTop(uint64_t &height);
    DBStatus getBlockByBlockHash(const std::string &hash, std::string &block);
    DBStatus getBlockHashsByBlockHeight(uint64_t height, vector<string> &hashes);
    // ... 共约11个方法
};

class BlockWriter : public DBReadWriter {
public:
    DBStatus setBlockTop(unsigned int height);
    DBStatus setBlockByBlockHash(const std::string &hash, const std::string &block);
    // ... 共约19个方法
};
```

### 2.3 拆分后文件预估

| 文件 | 预估行数 | 类 | 方法数 |
|------|---------|-----|--------|
| `db_status.h` | ~15 | enum DBStatus | - |
| `db_reader.h` | ~50 | class DBReader | 3 |
| `db_writer.h` | ~80 | class DBReadWriter | 8 (基础操作) |
| `db_block.h/.cpp` | ~150 / ~200 | BlockReader, BlockWriter | 11 + 19 |
| `db_transaction.h/.cpp` | ~50 / ~100 | TxReader, TxWriter | 3 + 6 |
| `db_utxo.h/.cpp` | ~80 / ~200 | UtxoReader, UtxoWriter | 3 + 8 |
| `db_stake.h/.cpp` | ~60 / ~150 | StakeReader, StakeWriter | 2 + 6 |
| `db_delegation.h/.cpp` | ~100 / ~250 | DelegReader, DelegWriter | 5 + 14 |
| `db_contract.h/.cpp` | ~90 / ~200 | ContractReader, ContractWriter | 5 + 14 |
| `db_vote.h/.cpp` | ~120 / ~300 | VoteReader, VoteWriter | 9 + 20 |
| `db_lock.h/.cpp` | ~50 / ~120 | LockReader, LockWriter | 2 + 4 |
| `db_consensus.h/.cpp` | ~80 / ~200 | ConsensusReader, ConsensusWriter | 6 + 12 |
| `db_global.h/.cpp` | ~60 / ~150 | GlobalReader, GlobalWriter | 7 + 8 |

**总计**: 约 12 个新头文件, 12 个实现文件, 原有 4 组底层文件保留。

### 2.4 向后兼容方案

为保持向后兼容, 保留一个**聚合头文件**:

```cpp
// db/db_api.h (新, 约30行)
#ifndef DB_API_HEADER
#define DB_API_HEADER

#include "db/db_status.h"
#include "db/db_block.h"
#include "db/db_transaction.h"
#include "db/db_utxo.h"
#include "db/db_stake.h"
#include "db/db_delegation.h"
#include "db/db_contract.h"
#include "db/db_vote.h"
#include "db/db_lock.h"
#include "db/db_consensus.h"
#include "db/db_global.h"

#endif
```

这样现有代码 `#include "db/db_api.h"` 仍然有效, 无需修改上层业务代码。同时, 新代码可以按需引入具体数据域头文件。

---

## 3. 接口按数据域分组建议

### 3.1 区块域 (Block)

**当前**: 混杂在 DBReader/DBReadWriter 中
**建议**: `block_reader.h` / `block_writer.h`

方法: `getBlockTop`, `getBlockByBlockHash`, `getBlockHashsByBlockHeight`, `getBlockHashByBlockHeight`, `getBlockHeightByBlockHash`, `getBlockHashesByBlockHeight`, `getBlocksByBlockHash`, `getSumHashByHeight`, `getThousandSumHashByBlockHeight`, `getThousandSumHashTop`; `setBlockTop`, `setBlockByBlockHash`, `setBlockHashByBlockHeight`, `setBlockHeightByBlockHash`, `setSumHashByHeight`, `setThousandSumHashByBlockHeight`, `setThousandSumHashTop`, `removeBlockByBlockHash`, `removeBlockHashByBlockHeight`, `removeBlockHeightByBlockHash`, `removeSumHashByHeight`, `removeThousandSumHashByBlockHeight`, `removeThousandSumHashTop`

### 3.2 交易域 (Transaction)

**建议**: `transaction_reader.h` / `transaction_writer.h`

方法: `getTransactionByHash`, `getBlockHashByTransactionHash`; `setTransactionByHash`, `setBlockHashByTransactionHash`, `removeTransactionByHash`, `removeBlockHashByTransactionHash`

### 3.3 UTXO/余额域 (UTXO & Balance)

**建议**: `utxo_reader.h` / `utxo_writer.h`

方法: `getUtxoHashsByAddress`, `getUtxoValueByUtxoHashes`, `getBalanceByAddr`; `setUtxoHashesByAddr`, `setUtxoValueByUtxoHashes`, `setBalanceByAddr`, `removeUtxoHashesByAddr`, `removeUtxoValueByUtxoHashes`, `removeBalanceByAddr`

### 3.4 质押域 (Stake)

**建议**: `stake_reader.h` / `stake_writer.h`

方法: `getStakeAddr`, `getStakeUtxoByAddr`; `setStakeAddr`, `setStakeUtxoByAddr`, `removeStakeAddr`, `removeStakeUtxoByAddr`

### 3.5 委托域 (Delegation)

**建议**: `delegation_reader.h` / `delegation_writer.h`

方法: `getDelegatingAddrAndAssetTypeByBonusAddr`, `getBonusAddrAndAssetTypeByDelegatingAddr`, `getDelegatingAddrUtxoByBonusAddr`, `getBonusUtxoByPeriod`, `getFundUtxoByPeriod`, `getDelegatingUtxoByPeriod`; `setDelegatingAddrAndAssetTypeByBonusAddr`, `setBonusAddrAndAssetTypeByDelegatingAddr`, `setDelegatingAddrUtxoByBonusAddr`, `setBonusUtxoByPeriod`, `setFundUtxoByPeriod`, `setDelegatingUtxoByPeriod`, + remove 对应方法

### 3.6 合约域 (Contract/EVM)

**建议**: `contract_reader.h` / `contract_writer.h`

方法: `getEvmDeployerAddr`, `getContractAddrByDeployerAddr`, `getContractCodeByContractAddr`, `getContractDeployUtxoByContractAddr`, `getLatestUtxoByContractAddr`, `getMptValueByMptKey`; `setEvmDeployerAddr`, `setContractAddrByDeployerAddr`, `setContractCodeByContractAddr`, `setContractDeployUtxoByContractAddr`, `setLatestUtxoByContractAddr`, `setMptValueByMptKey`, + remove 对应方法

### 3.7 投票/提案域 (Vote & Proposal)

**建议**: `vote_reader.h` / `vote_writer.h`

方法: `getRevokeTxHashByAssetType`, `getApproveAddrsByAssetType`, `getAgainstAddrsByAssetType`, `getVoteTxHashByAssetType`, `getProposalInfoByAssetType`, `getRevokeProposalInfoByAssetType`, `getVoteCountByAssetType`, `getVoteCountByAddr`, `getTotalCountByAssetType`; `setRevokeTxHashByAssetType`, `setApproveAddrsByAssetType`, `setAgainstAddrsByAssetType`, `setVoteTxHashByAssetType`, `setProposalInfoByAssetType`, `setRevokeProposalInfoByAssetType`, `setVoteCountByAssetType`, `setVoteCountByAddr`, `setTotalCountByAssetType`, + remove 对应方法

### 3.8 锁定域 (Lock)

**建议**: `lock_reader.h` / `lock_writer.h`

方法: `getLockAddr`, `getLockAddrUtxo`; `setLockAddr`, `setLockAddrUtxo`, `removeLockAddr`, `removeLockAddrUtxo`

### 3.9 共识统计域 (Consensus)

**建议**: `consensus_reader.h` / `consensus_writer.h`

方法: `getSignCountByPeriod`, `getBlockNumberByPeriod`, `getSignAddrByPeriod`, `getBurnAmountByPeriod`, `getGasAmountByPeriod`, `getPackagerCountByPeriod`; `setSignCountByPeriod`, `setBlockNumberByPeriod`, `setSignAddrByPeriod`, `setBurnAmountByPeriod`, `setGasAmountByPeriod`, `setPackagerCountByPeriod`, + remove 对应方法

### 3.10 全局域 (Global/Deflation)

**建议**: `global_reader.h` / `global_writer.h`

方法: `getTotalCirculation`, `getTotalBurnAmount`, `getTotalDelegatingAmount`, `getNonceByAddr`, `getTotalLockedAmonut`, `getTotalLockedAmountByPeriod`, `getInitVer`, `getAssetType`, `getAssetTypeByAddr`, `getAssetTypeByContractAddr`, `getInternalHashByRlpHash`; `setTotalCirculation`, `setTotalBurnAmount`, `setTotalDelegatingAmount`, `setNonceByAddr`, `setTotalLockedAmonut`, `setTotalLockedAmonutByPeriod`, `setInitVer`, `setAssetType`, `setAssetTypeByAddr`, `setAssetTypeByContractAddr`, `setInternalHashByRlpHash`, + remove 对应方法

---

## 4. 预估值

### 4.1 各任务工时估算

| 任务 | 预估工时 | 说明 |
|------|---------|------|
| 1. 提取 DBStatus 到独立头文件 | 0.5h | 简单移动, 更新 include |
| 2. 创建 DBReader 基础类 | 1h | 提取 readData/multiReadData, 作为所有 Reader 基类 |
| 3. 创建 DBReadWriter 基础类 | 2h | 提取事务管理+基础写操作+mergeValue, 作为所有 Writer 基类 |
| 4. 拆分区块域 | 1.5h | 11个读 + 19个写 + remove方法 |
| 5. 拆分交易域 | 0.5h | 3个读 + 6个写 |
| 6. 拆分UTXO/余额域 | 1h | 3个读 + 8个写 |
| 7. 拆分质押域 | 0.5h | 2个读 + 6个写 |
| 8. 拆分委托域 | 1.5h | 6个读 + 14个写 (最复杂的域之一) |
| 9. 拆分合约域 | 1.5h | 6个读 + 14个写 |
| 10. 拆分投票域 | 2h | 9个读 + 20个写 (最多的方法) |
| 11. 拆分锁定域 | 0.5h | 2个读 + 4个写 |
| 12. 拆分共识统计域 | 1h | 6个读 + 12个写 |
| 13. 拆分全局域 | 1h | 7个读 + 8个写 |
| 14. 创建聚合头文件 | 0.5h | 向后兼容 include |
| 15. 更新上层模块 include | 2h | 搜索替换所有 `#include "db/db_api.h"` 调用点 |
| 16. 编译验证与修复 | 3h | 确保所有翻译单元通过编译 |
| 17. 单元测试更新 | 2h | 如有测试, 更新 include |
| 18. 回滚块域和30日锁定 | 1h | 处理 `setRollbackBlockNum` / `get30DayLockData` 等杂项方法 |
| **总计** | **22.5h** | 约 3 人天 |

### 4.2 风险与缓解措施

| 风险 | 等级 | 缓解措施 |
|------|------|---------|
| 循环依赖 | 中 | DBReader/DBReadWriter 作为最底层基类, 所有数据域类继承它们 |
| 上层模块修改遗漏 | 低 | 保留聚合头文件 `db_api.h`, 零修改风险 |
| mergeValue 的多分隔符参数化破坏 | 低 | 将 mergeValue 保留在 DBReadWriter 基类中 |
| 测试覆盖率不足 | 中 | 拆分前先补充关键路径的集成测试 |
| 性能影响 | 极低 | 方法定义移到 .cpp 不会影响性能, 继承关系不引入虚函数开销 (当前无虚函数) |

---

## 5. 补充建议

### 5.1 Bug 修复附带项

在拆分过程中, 建议同时修复以下问题:

| 优先级 | 问题 | 说明 |
|--------|------|------|
| 高 | 拼写错误 `sestoryDB` → `destroyDB` | rocksdb.h:60 |
| 高 | 拼写错误 `getTotalLockedAmonut` → `getTotalLockedAmount` | db_api.h:904 |
| 中 | 拼写错误常量名 `PEROID` → `PERIOD` | db_api.cpp:51-68 |
| 中 | 删除未使用的 `delete_keys_` 成员 | db_api.h:2689 |
| 中 | 删除 `multiReadData` 中的冗余代码 (str 变量) | db_api.cpp:1577-1580 |
| 低 | 删除 `db_api.cpp:2` 冗余 include `"db_api.h"` | db_api.cpp:2 |
| 低 | 30日锁定数据添加 Key 前缀 | db_api.cpp:1195 |
| 低 | Key前缀统一为spec定义的短前缀 | 全局 |

### 5.2 长期改进建议

1. **引入 Pimpl 模式**: 将 RocksDB 底层细节通过 Pimpl 隐藏, 减少编译依赖
2. **使用 Column Family**: 将不同数据域放入不同 Column Family, 获得独立的压缩和MemTable管理
3. **引入 Repository 模式**: 将数据域接口抽象为 Repository 接口, 便于将来切换存储后端
4. **Key 编码规范化**: 引入统一的 Key 编码类, 避免字符串拼接错误
5. **去除 bool deletekey 参数**: `set30DayLockData` 中的 `bool deletekey` 标志位违反单一职责原则, 应拆分为 set 和 remove 两个方法

### 5.3 与规范同步的建议

当前实现与 spec_dev.md 附录C 的 Key前缀不一致 (短前缀 vs 长前缀)。建议在重构时:

1. **方案A (推荐)**: 更新 spec_dev.md 以反映当前实现
   - 原因: 当前实现已稳定运行, 修改Key前缀需要数据迁移
   - 风险: 低
   - 工时: 0.5h

2. **方案B**: 将代码中的Key前缀改为spec定义
   - 原因: 使代码与规范一致
   - 风险: 高 (需要数据迁移或兼容处理)
   - 工时: 包含数据迁移工具开发

**推荐方案A**, 同步更新规范文档。

---

**可信度说明**: 工时估算基于代码结构分析和同类项目的重构经验, 可信度: **中** (实际工时受团队熟悉度和测试覆盖影响)。
