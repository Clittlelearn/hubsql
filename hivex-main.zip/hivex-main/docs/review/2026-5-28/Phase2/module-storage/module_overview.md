# 模块1: 存储层 (RocksDB) 模块总览

## 1. 模块职责与定位

存储层是 MeMeChain 区块链最底层基础设施，负责所有链上数据的持久化存储。其核心职责：

- **持久化存储**: 使用 RocksDB TransactionDB 模式存储所有区块链数据
- **事务保证**: 提供原子性的多键读写事务支持
- **数据组织**: 通过统一的 Key 前缀机制 (见 `db/db_api.cpp:10-81` DatabaseKeys 命名空间) 区分不同业务数据类型
- **读写分离**: 提供 DBReader (只读) 和 DBReadWriter (读写事务) 两种访问模式
- **版本管理**: 支持回滚块存储和数据库初始化版本记录

**在分层架构中的位置**:
```
共识层 (CA) ──→ 智能合约层 (EVM) ──→ 网络层
                    ↓
              ┌─────────────┐
              │   存储层     │  ← 本模块
              │  (RocksDB)  │
              └─────────────┘
```

依据: `//wsl$/wsl-mm/home/wbl/mm/HXD/spec_dev.md:1209-1233` 及 `db/db_api.h` 全文

## 2. 对外接口分类

### 2.1 按数据域分组

| 数据域 | DBReader 读取方法数 | DBReadWriter 写入方法数 | Key前缀数量 |
|--------|---------------------|------------------------|-------------|
| 区块 (Block) | 11 | 19 | 10 |
| 交易 (Transaction) | 3 | 6 | 3 |
| UTXO与余额 | 3 | 8 | 4 |
| 质押 (Stake) | 2 | 6 | 2 |
| 委托 (Delegation) | 5 | 14 | 4 |
| 合约 (Contract/EVM) | 5 | 14 | 6 |
| 投票/提案 (Vote/Proposal) | 9 | 20 | 6 |
| 锁定 (Lock) | 2 | 4 | 2 |
| 共识统计 | 6 | 12 | 6 |
| 通缩机制/全局 | 7 | 8 | 4 |
| 回滚/Rollback | 1 | 3 | 2 |
| 30日锁定 | 2 | 3 | 0(直接用地址) |
| RLP Hash映射 | 1 | 2 | 1 |
| EVM Nonce | 1 | 1 | 1 |

依据: `db/db_api.h:22-2692`

### 2.2 核心公共函数

| 函数 | 位置 | 说明 |
|------|------|------|
| `DBInit(path)` | `db/db_api.cpp:83` | 全局数据库初始化入口 |
| `DBReader::readData(key, value)` | `db/db_api.cpp:782` | 单键读取 (委托到 RocksDBDataReader) |
| `DBReader::multiReadData(keys, values)` | `db/db_api.cpp:738` | 批量读取 |
| `DBReadWriter::writeData(key, value)` | `db/db_api.cpp:1656` | 单键写入 |
| `DBReadWriter::mergeValue(key, value)` | `db/db_api.cpp:1628` | 合并写入 (追加模式) |
| `DBReadWriter::deleteData(key)` | `db/db_api.cpp:1665` | 单键删除 |
| `DBReadWriter::transactionCommit()` | `db/db_api.cpp:828` | 提交事务 |
| `DBReadWriter::reInitTransaction()` | `db/db_api.cpp:812` | 重新初始化事务 (先回滚再Begin) |

## 3. 与上层模块的依赖关系

| 上层模块 | 依赖方式 | 说明 |
|---------|---------|------|
| 共识层 (ca/) | 通过 DBReadWriter/DBReader 读写区块、交易、UTXO | 存储层是被动服务提供者 |
| 合约层 (contract/) | 通过 MPT Key 读写合约状态 | MPT节点存储在 RocksDB 中 |
| 网络层 (net/) | 通过 DBReader 读取同步所需的区块/交易数据 | 区块同步时需要查询 |
| RPC 层 (rpc/) | 通过 DBReader 读取查询请求 | 所有 RPC 查询都经过 DBReader |
| 工具层 (utils/) | 通过 RocksDB 全局单例 | 使用 MagicSingleton 模式 |

**依赖方向**: 所有上层模块都依赖于存储层，存储层本身不依赖任何业务模块，仅依赖 RocksDB 库和基础工具类 (MagicSingleton, 日志)。

### 3.1 核心依赖链

```
上层业务 (共识/合约/网络/RPC)
    ↓ 创建并使用
DBReader(只读) / DBReadWriter(读写事务)
    ↓ 持有/委托
RocksDBDataReader / RocksDBReadWriter
    ↓ 持有 shared_ptr<RocksDB>
RocksDB (全局单例, 通过 MagicSingleton<RocksDB>::GetInstance())
    ↓ 管理
rocksdb::TransactionDB* (底层RocksDB引擎)
```

依据: `db/db_api.cpp:95-96`, `db/db_api.cpp:802`, `db/rocksdb.cpp:22-65`

## 4. 规范对照表

| 功能点 | 规范定义 (spec_dev.md 第8章+附录C) | 当前实现 | 偏差原因 |
|--------|-------------------------------------|---------|---------|
| 数据库引擎 | RocksDB TransactionDB 模式 | **符合**: `rocksdb::TransactionDB::Open` (rocksdb.cpp:54) | 一致性实现 |
| Key前缀规范 | 使用如 `BH:` `B:` `TX:` 等短前缀 | **有偏差**: 实际使用长前缀如 `blkht2blkhs_` `blkhs2blkraw_` 等 (db_api.cpp:10-81) | 历史原因, 早期实现未与规范同步。短前缀可读性更好但长前缀通过下划线分隔也能正常使用 |
| 高度→区块哈希 | Key: `BH:{height}`, Value: `vector<blockHash>` | **符合**: `BLOCK_HEIGHT_TO_BLOCK_HASH = "blkht2blkhs_"` (db_api.cpp:29), value用`_`分隔存储多个hash (db_api.cpp:176-184) | 功能等价, 仅Key名和分隔符不同 |
| 区块数据 | Key: `B:{blockHash}`, Value: `blockRaw` | **符合**: `BLOCK_HASH_TO_BLOCK_RAW = "blkhs2blkraw_"` (db_api.cpp:33) | 功能等价 |
| 交易数据 | Key: `TX:{txHash}`, Value: `txRaw` | **符合**: `TRANSACTION_HASH_TO_TRANSACTION_RAW = "txhs2txraw_"` (db_api.cpp:37) | 功能等价 |
| 交易→区块映射 | Key: `TXBH:{txHash}`, Value: `blockHash` | **符合**: `TRANSACTION_HASH_TO_BLOCK_HASH = "txhs2blkhs_"` (db_api.cpp:38) | 功能等价 |
| UTXO余额 | Key: `UB:{addr}:{assetType}:{utxoHash}`, Value: `balance` | **符合**: `UTXO_HASH_TO_UTXO_VALUE = "utxohash2utxovalue_"` (db_api.cpp:36) | Key拼接方式有差异(`_`分隔符 vs `:`), 功能等价 |
| 地址余额 | Key: `BAL:{addr}:{assetType}`, Value: `balance` | **符合**: `ADDRESS_TO_BALANCE = "addr2bal_"` (db_api.cpp:47) | 功能等价 |
| 100高度SumHash | 每100块计算汇总哈希 | **符合**: `BLOCK_HEIGHT_TO_SUM_HASH = "blkht2sumhs_"` (db_api.cpp:30), 验证height%100==0 (db_api.cpp:201) | 功能等价 |
| 1000高度千区块哈希 | 每1000块一个校验哈希 | **符合**: `BLOCK_HEIGHT_TO_THOUSAND_SUM_HASH = "ht2thousandsumhs_"` (db_api.cpp:32) | 功能等价 |
| MPT存储 | Key: `MPT:{mptKey}`, Value: `mptValue` | **符合**: `MPT_KEY_TO_MPT_VALUE = "mptkey2mptvalue_"` (db_api.cpp:79) | 功能等价 |
| 事务支持 | Begin→Put/Delete→Commit/Rollback | **符合**: `RocksDBReadWriter` 实现完整事务生命周期 (rocksdb_read_write.cpp:17-77) | 一致性实现 |
| 读写分离 | DBReader只读, DBReadWriter读写 | **符合**: `DBReader` 继承关系实现分离 (db_api.h:22, 979) | 一致性实现 |
| BlockStatus追踪 | Protobuf BlockStatus 消息 | **未实现**: 代码中无 BlockStatus 相关存储Key | 【推测】BlockStatus 可能在内存中维护 (blockStatusMap), 不持久化到 RocksDB |
| 地址→资产类型 | 规范未明确定义 | **有实现**: `ADDRESS_TO_ASSET_TYPE = "addr2Assettype_"` (db_api.cpp:22) | 额外功能, 用于快速查询地址持有的资产类型列表 |
| 回滚块存储 | 支持回滚到指定高度 | **有实现**: `ROLLBACKBLOCKS` 和 `ROLLBLOCKNUM` (db_api.cpp:39-40) | 实现比规范更具体, 支持增量回滚块管理 |
| 30日锁定数据 | 规范未定义 | **有实现**: `get30DayLockData/set30DayLockData` (db_api.cpp:1194-1238) | 额外业务需求, 直接用地址作为Key前缀 |
| RLP→Internal Hash | 规范未定义 | **有实现**: `RLP_HASH_TO_INTERNAL_HASH = "rlphash2txhash_"` (db_api.cpp:71) | EVM兼容性需要的ETH RLP哈希到内部交易哈希映射 |

## 5. 关键问题清单

### 5.1 规范与实现不一致

| # | 位置 | 现象描述 | 风险等级 | 触发场景 | 修复建议 | 验证方法 |
|---|------|---------|---------|---------|---------|---------|
| 1 | `db/db_api.cpp:10-81` vs `spec_dev.md:2559-2599` | Key前缀命名规范不一致: 规范使用短前缀如`BH:` `B:` `TX:`, 实现使用长前缀如`blkht2blkhs_` `blkhs2blkraw_` `txhs2txraw_` | 中 | 将来如果有外部工具需要直接扫描 RocksDB 数据, 工具必须适配两种命名风格 | 统一为规范定义的短前缀, 或更新规范以反映当前实现 | 对比现有数据库文件中的Key格式与规范定义 |
| 2 | `db/db_api.h` 总行数 | db_api.h 达到 2694 行 (81.7KB), 是项目中最大的头文件 | 中 | 编译时间增加, 修改任何接口都触发大量重编译 | 按数据域拆分为多个子头文件 | 编译时间对比 |

### 5.2 潜在风险

| # | 位置 | 现象描述 | 风险等级 | 触发场景 | 修复建议 | 验证方法 |
|---|------|---------|---------|---------|---------|---------|
| 3 | `db/db_api.cpp:1194-1238` | 30日锁定数据的Key直接使用地址字符串, 无前缀隔离 (db_api.cpp:1195) | 高 | 地址字符串可能与其他Key前缀发生冲突; 数据无法通过前缀扫描区分 | 添加前缀如`_30DayLock_` | 检查数据库中是否存在Key冲突 |
| 4 | `db/rocksdb.cpp:49` | `options.IncreaseParallelism()` 自动设置线程数为CPU核数 | 低 | 在容器化部署中可能导致线程数过高 | 允许通过配置指定线程数 | 监控RocksDB线程数 |
| 5 | `db/rocksdb_read_write.cpp:163-176` | mergeValue使用readForUpdate加排他锁后读取-修改-写入, 但此操作与getMergeValue的readData之间存在读写竞争 | 中 | 一个事务正在mergeValue修改一个合并不完全的value时, 另一个getMergeValue可能读到不完整数据 | 合并操作结束后再次验证, 或使用Snapshot隔离级别 | 并发压测mergeValue和getMergeValue |

### 5.3 废弃/未完成标记

| # | 位置 | 现象描述 | 状态 |
|---|------|---------|------|
| 6 | `db/db_api.h:2689` | `delete_keys_` 成员变量未在任何cpp中使用 | **废弃**, 可信度: 高 |
| 7 | `db/db_api.cpp:9` | `// todo 校对key值` 注释 | **未完成**, 可信度: 高, 需要人工审核所有Key前缀值 |
| 8 | `db/db_api.h:975` | `rocksdb_read.h` 被重复包含 (db_api.h第4行已包含, db_api.cpp第2-3行又包含) | 无功能影响, 仅冗余 |

## 6. 关键常量对照

| 规范中定义 (spec_dev.md 附录C) | 实际实现 (db/db_api.cpp) | 功能一致性 |
|-----|-----|------|
| 无明确常量 | `TransactionDB::Open()` 使用默认配置 | 无Column Family, 无自定义Comparator |

**Column Family 情况**: 当前实现**未使用** RocksDB 的 Column Family 特性。所有数据存储在默认 Column Family 中。这简化了事务管理 (TransactionDB 跨 Column Family 事务需要额外处理), 但也意味着无法利用 Column Family 带来的性能隔离和管理优势。

依据: `db/rocksdb.cpp:40-65` 中 `rocksdb::Options options` 未设置任何 Column Family 相关配置, `TransactionDB::Open` 使用默认参数。

---

**可信度评级说明**:
- **高**: 由源代码直接证实
- **中**: 基于代码逻辑推理, 存在部分不确定性
- **低**: 推测性结论, 需要进一步验证
