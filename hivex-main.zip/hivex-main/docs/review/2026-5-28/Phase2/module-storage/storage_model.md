# 模块2: 存储层 (RocksDB) 完整 Key-Value 存储设计

## 概述

MeMeChain 使用 RocksDB TransactionDB 作为底层引擎, 所有数据以 Key-Value 形式存储。通过 Key 前缀区分数据类型。**未使用** RocksDB Column Family 特性, 所有数据存储在默认 Column Family 中。

**Key 前缀命名空间**: `db/db_api.cpp:10-81` (DatabaseKeys 命名空间)

---

## 1. Key 前缀完整对照表

### 1.1 规范前缀 vs 实现前缀对照

| 规范前缀 (spec_dev.md 附录C) | 实现前缀 (db_api.cpp) | 实现常量名 |
|------------------------------|----------------------|-----------|
| `BH:` | `blkht2blkhs_` | `BLOCK_HEIGHT_TO_BLOCK_HASH` |
| `B:` | `blkhs2blkraw_` | `BLOCK_HASH_TO_BLOCK_RAW` |
| `SH:` | `blkht2sumhs_` | `BLOCK_HEIGHT_TO_SUM_HASH` |
| `TH:` | `ht2thousandsumhs_` | `BLOCK_HEIGHT_TO_THOUSAND_SUM_HASH` |
| `TOP` | `blktop_` | `BLOCK_TOP` |
| `TX:` | `txhs2txraw_` | `TRANSACTION_HASH_TO_TRANSACTION_RAW` |
| `TXBH:` | `txhs2blkhs_` | `TRANSACTION_HASH_TO_BLOCK_HASH` |
| `UB:{addr}:{asset}:{utxo}` | `utxohash2utxovalue_{addr}_{utxo}_{asset}` | `UTXO_HASH_TO_UTXO_VALUE` |
| `UAH:{addr}:{asset}` | `addr2utxo_{addr}{asset}` | `ADDRESS_TO_UTXOS` |
| `BAL:{addr}:{asset}` | `addr2bal_{addr}{asset}` | `ADDRESS_TO_BALANCE` |
| `ASSET` | `assettype_` | `ASSET_TYPE` |
| `STAKE_ADDR` | `stakeaddr_` | `STAKE_ADDRESS` |
| `STAKE:{addr}:{asset}` | `addr2stakeutxos_{addr}{asset}` | `ADDRESS_TO_STAKE_UTXOS` |
| `DELEG:{bonus}:{del}:{asset}` | `bonusaddr2delegatingaddrutxos_{bonus}_{del}_{asset}` | `BONUS_ADDRESS_TO_DELEGATING_ADDRESS_UTXO` |
| `DELEG_ADDR` | 无独立常量, 委托关系存储在 `bonusaddr2delegatingaddrandassettype_` 和 `delegatingaddr2bonusaddrandassettype_` | `BONUS_ADDRESS_TO_DELEGATING_ADDRESS_AND_ASSET_TYPE` |
| `EVM_DEPLOYER` | `evmdeployeraddr_` | `EVM_DEPLOYER_ADDRESS` |
| `EVM_CODE:{contract}` | `contractaddr2contractcode_{contract}` | `CONTRACT_ADDRESS_TO_CONTRACT_CODE` |
| `EVM_DEPLOY:{deployer}` | `deployeraddr2contractaddr_{deployer}` | `DEPLOYER_ADDRESS_TO_CONTRACT_ADDRESS` |
| `EVM_UTXO:{contract}` | `contractaddr2deployutxo_{contract}` | `CONTRACT_ADDRESS_TO_DEPLOY_UTXO` |
| `EVM_LATEST_UTXO:{contract}` | `contractaddr2latestutxo_{contract}` | `CONTRACT_ADDRESS_TO_LATEST_UTXO` |
| `MPT:{key}` | `mptkey2mptvalue_{key}` | `MPT_KEY_TO_MPT_VALUE` |
| `EVM_ASSET:{contract}` | `contractaddr2assettype_{contract}` | `CONTRACT_ADDRESS_TO_ASSET_TYPE` |
| `SIGN:{period}:{addr}` | `peroid2signcount_{period}{addr}` | `PEROID_2_SIGN_COUNT` |
| `BLOCK_NUM:{period}` | `peroid2blockcount_{period}` | `PEROID_2_BLOCK_COUNT` |
| `SIGN_ADDR:{period}` | `peroid2signaddr_{period}` | `PEROID_2_SIGN_ADDRESS` |
| `BURN:{period}` | `peroid2burnamount_{period}` | `PEROID_2_BURN_AMOUNT` |
| `APPROVE:{asset}` | `assettype2approvevoteaddr_{asset}` | `ASSET_TYPE_TO_APPROVE_VOTE_ADDRESS` |
| `AGAINST:{asset}` | `assettype2againstvoteaddr_{asset}` | `ASSET_TYPE_TO_AGAINST_VOTE_ADDRESS` |
| `VOTE_TX:{asset}` | `assettype2votetxhash_{asset}` | `ASSET_TYPE_TO_VOTE_TX_HASH` |
| `PROPOSAL:{asset}` | `assettype2proposalinfo_{asset}` | `ASSET_TYPE_TO_PROPOSAL_INFO` |
| `REVOKE:{asset}` | `assettype2revokeproposalinfo_{asset}` | `ASSET_TYPE_TO_REVOKE_PROPOSAL_INFO` |
| `VOTE_CNT:{asset}` | `assettype2proposalvotescount_{asset}` | `ASSET_TYPE_TO_PROPOSAL_VOTE_COUNT` |
| `VOTE_ADDR:{addr}:{asset}` | `addr2votecount_{asset}{addr}` | `ADDRESS_TO_VOTE_COUNT` |
| `VOTE_TOTAL:{asset}` | `assettype2totalvotecount_{asset}` | `ASSET_TYPE_TO_TOTAL_VOTE_COUNT` |
| `LOCK_ADDR` | `lockaddr_` | `LOCK_ADDRESS` |
| `LOCK_UTXO:{addr}:{asset}` | `assettype2lockutxos_{addr}{asset}` | `ASSET_TYPE_TO_LOCK_UTXOS` |
| `PACKAGER` | `period2packagercount_{period}_{addr}` | `PERIOD_TO_PACKAGER_COUNT` |

**额外实现 (规范未定义)**:

| 实现前缀 | 实现常量名 | 说明 |
|---------|-----------|------|
| `blkhs2blkht_` | `BLOCK_HASH_TO_BLOCK_HEIGHT` | 区块哈希→高度反向映射 |
| `thousandsumhstop_` | `THOUSAND_SUM_HASH_TOP` | 千区块汇总哈希顶部编号 |
| `totalcirculation_` | `TOTAL_CIRCULATION` | 总循环供应量 |
| `totalburnamount_` | `TOTAL_BURN_AMOUNT` | 总销毁数量 |
| `totaldelegateAmount_` | `TOTAL_DELEGATE_AMOUNT` | 总委托数量 |
| `totallockedamount_` | `TOTAL_LOCKED_AMOUNT` | 总锁定金额 |
| `period2totallockedamount_` | `PERIOD_TO_TOTAL_LOCKED_AMOUNT` | 按周期总锁定金额 |
| `addr2nonce_` | `ADDRESS_TO_NONCE` | EVM 地址 nonce 值 |
| `addr2Assettype_` | `ADDRESS_TO_ASSET_TYPE` | 地址→资产类型列表 |
| `initver_` | `INITIALIZATION_VERSION` | 数据库初始化版本号 |
| `rollbackblocks_` | `ROLLBACKBLOCKS` | 回滚块数据 |
| `rollblocknum_` | `ROLLBLOCKNUM` | 回滚块编号列表 |
| `rlphash2txhash_` | `RLP_HASH_TO_INTERNAL_HASH` | ETH RLP哈希→内部交易哈希映射 |
| `assettype2revoketxhash_` | `ASSET_TYPE_TO_REVOKE_TX_HASH` | 资产类型→撤销交易哈希列表 |
| `period2gasamount_` | `PERIOD_TO_GAS_AMOUNT` | 按周期和类型的Gas消耗量 |
| `{addr}` (直接使用) | (无前缀) | 30日锁定数据, 风险: 无前缀隔离 |

---

## 2. 各数据域完整 Key-Value 设计

### 2.1 区块数据

#### 2.1.1 高度 → 区块哈希列表 (支持分叉)

| 属性 | 值 |
|------|-----|
| Key | `blkht2blkhs_{height}` |
| Value | `hash1_hash2_hash3_` (下划线分隔的多哈希字符串) |
| Value格式 | 字符串, 下划线分隔。首个为最新添加的主链哈希 |
| 写操作 | `setBlockHashByBlockHeight(height, hash, isMainBlock)` - mergeValue |
| 读操作 | `getBlockHashsByBlockHeight(height, hashes)` - SplitString |
| 位置 | db_api.cpp:890-894, db_api.cpp:174-184 |

**示例**:
```
Key:   "blkht2blkhs_12345"
Value: "abc123hash_def456hash_"   (2个分叉区块)
```

#### 2.1.2 区块哈希 → 区块高度

| 属性 | 值 |
|------|-----|
| Key | `blkhs2blkht_{blockHash}` |
| Value | `{height}` (十进制字符串) |
| Value格式 | uint64 → string |
| 写操作 | writeData |
| 读操作 | readData → std::stoul |
| 位置 | db_api.cpp:875-878, db_api.cpp:144-158 |

#### 2.1.3 区块哈希 → 区块原始数据

| 属性 | 值 |
|------|-----|
| Key | `blkhs2blkraw_{blockHash}` |
| Value | Protobuf序列化的区块数据 |
| Value格式 | 二进制/字符串 |
| 写操作 | writeData |
| 读操作 | readData |
| 位置 | db_api.cpp:906-909, db_api.cpp:188-196 |

#### 2.1.4 当前最高区块高度

| 属性 | 值 |
|------|-----|
| Key | `blktop_` |
| Value | `{height}` (十进制字符串) |
| Value格式 | uint64 → string |
| 写操作 | writeData |
| 读操作 | readData → std::stoul |
| 位置 | db_api.cpp:962-965, db_api.cpp:234-243 |

#### 2.1.5 高度 → 百区块汇总哈希 (每100块)

| 属性 | 值 |
|------|-----|
| Key | `blkht2sumhs_{height}` (height必须是100的倍数) |
| Value | SHA256 汇总哈希字符串 |
| Value格式 | 十六进制哈希字符串 |
| 约束 | height % 100 == 0 且 height != 0 |
| 位置 | db_api.cpp:922-925, db_api.cpp:199-208 |

#### 2.1.6 高度 → 千区块校验哈希 (每1000块)

| 属性 | 值 |
|------|-----|
| Key | `ht2thousandsumhs_{height}` (height必须是1000的倍数) |
| Value | SHA256 校验哈希字符串 |
| Value格式 | 十六进制哈希字符串 |
| 约束 | height % 1000 == 0 且 height != 0 |
| 位置 | db_api.cpp:937-940, db_api.cpp:211-220 |

#### 2.1.7 千区块汇总顶部编号

| 属性 | 值 |
|------|-----|
| Key | `thousandsumhstop_` |
| Value | `{thousandNum}` (十进制) |
| 位置 | db_api.cpp:951-954, db_api.cpp:223-232 |

---

### 2.2 交易数据

#### 2.2.1 交易哈希 → 交易原始数据

| 属性 | 值 |
|------|-----|
| Key | `txhs2txraw_{txHash}` |
| Value | Protobuf序列化的交易数据 |
| 写操作 | writeData |
| 读操作 | readData |
| 位置 | db_api.cpp:994-998, db_api.cpp:264-268 |

#### 2.2.2 交易哈希 → 所在区块哈希

| 属性 | 值 |
|------|-----|
| Key | `txhs2blkhs_{txHash}` |
| Value | `{blockHash}` (区块哈希字符串) |
| Value格式 | 十六进制哈希字符串 |
| 写操作 | writeData |
| 读操作 | readData |
| 位置 | db_api.cpp:1009-1012, db_api.cpp:271-275 |

---

### 2.3 UTXO 与余额

#### 2.3.1 地址 → UTXO 哈希集合

| 属性 | 值 |
|------|-----|
| Key | `addr2utxo_{address}{assetType}` |
| Value | `utxoHash1_utxoHash2_..._` (下划线分隔) |
| Value格式 | 字符串, 下划线分隔的UTXO哈希集合 |
| 写操作 | mergeValue / removeMergeValue |
| 读操作 | readData → SplitString |
| 位置 | db_api.cpp:968-972, db_api.cpp:245-255 |

#### 2.3.2 UTXO哈希 → UTXO余额值

| 属性 | 值 |
|------|-----|
| Key | `utxohash2utxovalue_{address}_{utxoHash}_{assetType}` |
| Value | `{balance}` (余额字符串) |
| Value格式 | 字符串表示的余额 (最小精度, int64) |
| 写操作 | writeData |
| 读操作 | readData |
| 位置 | db_api.cpp:981-984, db_api.cpp:257-261 |

**Key拼接顺序注意**: 实现中使用 `address + "_" + utxoHash + "_" + assetType`, 而规范定义的是 `{addr}:{assetType}:{utxoHash}`, 字段顺序和分隔符不同。此处为功能等价。

#### 2.3.3 地址 → 余额

| 属性 | 值 |
|------|-----|
| Key | `addr2bal_{address}{assetType}` |
| Value | `{balance}` (十进制字符串, int64) |
| 写操作 | writeData (std::to_string(balance)) |
| 读操作 | readData → std::stol |
| 特殊处理 | NotFound视为balance=0 (db_api.cpp:287-291) |
| 位置 | db_api.cpp:1023-1026, db_api.cpp:278-292 |

#### 2.3.4 资产类型集合

| 属性 | 值 |
|------|-----|
| Key | `assettype_` |
| Value | `assetType1_assetType2_..._` |
| Value格式 | 下划线分隔的资产类型字符串集合 |
| 写操作 | mergeValue / removeMergeValue |
| 读操作 | readData → SplitString |
| 位置 | db_api.cpp:1366-1369, db_api.cpp:518-527 |

---

### 2.4 质押 (Stake)

#### 2.4.1 质押地址集合

| 属性 | 值 |
|------|-----|
| Key | `stakeaddr_` |
| Value | `addr1_addr2_..._` |
| Value格式 | 下划线分隔的地址集合 |
| 写操作 | mergeValue / removeMergeValue |
| 读操作 | readData → SplitString |
| 位置 | db_api.cpp:1036-1039, db_api.cpp:307-316 |

#### 2.4.2 质押地址 → 质押UTXO列表

| 属性 | 值 |
|------|-----|
| Key | `addr2stakeutxos_{stakeAddr}{assetType}` |
| Value | `utxo1_utxo2_..._` |
| Value格式 | 下划线分隔的UTXO哈希集合 |
| 写操作 | mergeValue / removeMergeValue |
| 读操作 | readData → SplitString |
| 位置 | db_api.cpp:1048-1051, db_api.cpp:319-329 |

---

### 2.5 委托 (Delegation)

#### 2.5.1 分红地址 → 委托地址+资产类型映射

| 属性 | 值 |
|------|-----|
| Key | `bonusaddr2delegatingaddrandassettype_{bonusAddr}` |
| Value | `delegAddr1-assetType1_delegAddr2-assetType2_..._` |
| Value格式 | 下划线分隔, 每项为 `地址-资产类型` 格式 (用 `-` 连接) |
| 写操作 | mergeValue (值格式: `delegAddr + "-" + assetType`) |
| 读操作 | readData → SplitString到multimap |
| 位置 | db_api.cpp:1062-1068, db_api.cpp:331-342 |

#### 2.5.2 委托地址 → 分红地址+资产类型映射

| 属性 | 值 |
|------|-----|
| Key | `delegatingaddr2bonusaddrandassettype_{delegatingAddr}` |
| Value | `bonusAddr1-assetType1_bonusAddr2-assetType2_..._` |
| Value格式 | 同上, `地址-资产类型` 格式 |
| 写操作 | mergeValue |
| 读操作 | readData → SplitString到multimap |
| 位置 | db_api.cpp:1078-1082, db_api.cpp:344-354 |

#### 2.5.3 分红地址+委托地址+资产类型 → 委托UTXO列表

| 属性 | 值 |
|------|-----|
| Key | `bonusaddr2delegatingaddrutxos_{bonusAddr}_{delegAddr}_{assetType}` |
| Value | `utxo1_utxo2_..._` |
| 写操作 | mergeValue / removeMergeValue |
| 读操作 | readData → SplitString |
| 位置 | db_api.cpp:1093-1097, db_api.cpp:356-366 |

#### 2.5.4 按周期的分红/基金/委托 UTXO

| 数据类型 | Key | Value |
|---------|-----|-------|
| 分红UTXO | `period2bonusutxos_{period}` | `utxo1_utxo2_..._` |
| 基金UTXO | `period2fundutxos_{period}` | `utxo1_utxo2_..._` |
| 委托UTXO | `period2delegatingutxo_{period}` | `utxo1_utxo2_..._` |

位置: db_api.cpp:1108-1139

---

### 2.6 合约 (EVM)

#### 2.6.1 EVM 部署者地址集合

| 属性 | 值 |
|------|-----|
| Key | `evmdeployeraddr_` |
| Value | `deployer1_deployer2_..._` |
| 位置 | db_api.cpp:1141-1143, db_api.cpp:472-481 |

#### 2.6.2 部署者 → 合约地址列表

| Key | `deployeraddr2contractaddr_{deployerAddr}` |
| Value | `contract1_contract2_..._` |
| 位置 | db_api.cpp:1241-1244, db_api.cpp:484-494 |

#### 2.6.3 合约地址 → 合约代码

| Key | `contractaddr2contractcode_{contractAddr}` |
| Value | 合约字节码 (十六进制或二进制字符串) |
| 位置 | db_api.cpp:1253-1256, db_api.cpp:496-500 |

#### 2.6.4 合约地址 → 部署UTXO

| Key | `contractaddr2deployutxo_{contractAddr}` |
| Value | 部署UTXO哈希字符串 |
| 位置 | db_api.cpp:1265-1268, db_api.cpp:501-505 |

#### 2.6.5 合约地址 → 最新UTXO

| Key | `contractaddr2latestutxo_{contractAddr}` |
| Value | 最新UTXO哈希字符串 |
| 位置 | db_api.cpp:1277-1280, db_api.cpp:507-511 |

#### 2.6.6 MPT 键 → MPT 值

| Key | `mptkey2mptvalue_{mptKey}` |
| Value | RLP编码的MPT节点数据 (十六进制) |
| 位置 | db_api.cpp:1289-1292, db_api.cpp:513-517 |

#### 2.6.7 合约地址 → 资产类型

| Key | `contractaddr2assettype_{contractAddr}` |
| Value | 资产类型字符串 |
| 位置 | db_api.cpp:1533-1535, db_api.cpp:673-676 |

---

### 2.7 投票与提案

#### 2.7.1 资产管理

| 数据类型 | Key | Value | 位置 |
|---------|-----|-------|------|
| 资产→撤销交易哈希 | `assettype2revoketxhash_{assetType}` | `txHash1_txHash2_..._` | db_api.cpp:1377-1380 |
| 资产→赞成地址 | `assettype2approvevoteaddr_{assetType}` | `addr1_addr2_..._` (去重集合) | db_api.cpp:1390-1393 |
| 资产→反对地址 | `assettype2againstvoteaddr_{assetType}` | `addr1_addr2_..._` (去重集合) | db_api.cpp:1404-1407 |
| 资产→投票交易哈希 | `assettype2votetxhash_{assetType}` | `txHash1_txHash2_..._` | db_api.cpp:1417-1420 |
| 资产→提案信息 | `assettype2proposalinfo_{assetType}` | 提案信息字符串 | db_api.cpp:1429-1431 |
| 资产→撤销提案信息 | `assettype2revokeproposalinfo_{assetType}` | 撤销提案信息字符串 | db_api.cpp:1439-1441 |
| 资产→投票计数 | `assettype2proposalvotescount_{assetType}` | `{approve}_{against}` | db_api.cpp:1450-1453 |
| 地址→投票计数 | `addr2votecount_{assetType}{addr}` | `{voteCount}` | db_api.cpp:1461-1463 |
| 资产→投票者总数 | `assettype2totalvotecount_{assetType}` | `{totalVoters}` | db_api.cpp:1471-1473 |

#### 2.7.2 投票计数解析 (assettype2proposalvotescount_)

```
Value格式: "{approve}_{against}"
示例: "150_75" 表示 150票赞成, 75票反对

解析: SplitString(value, "_", vote_count)
      approve = vote_count[0]
      against = vote_count[1]
      必须恰好2个元素, 否则返回DB_NOT_FOUND
```
位置: db_api.cpp:592-609

---

### 2.8 锁定 (Lock)

| 数据类型 | Key | Value | 位置 |
|---------|-----|-------|------|
| 锁定地址集合 | `lockaddr_` | `addr1_addr2_..._` | db_api.cpp:1481-1483 |
| 地址+资产→锁定UTXO | `assettype2lockutxos_{addr}{assetType}` | `utxo1_utxo2_..._` | db_api.cpp:1491-1494 |

---

### 2.9 共识统计 (Consensus Statistics)

| 数据类型 | Key | Value | 位置 |
|---------|-----|-------|------|
| 周期+地址→签名数 | `peroid2signcount_{period}{addr}` | `{signCount}` (uint64字符串) | db_api.cpp:1300-1303 |
| 周期→区块数 | `peroid2blockcount_{period}` | `{blockCount}` (uint64字符串) | db_api.cpp:1314-1317 |
| 周期→签名地址列表 | `peroid2signaddr_{period}` | `addr1_addr2_..._` | db_api.cpp:1329-1331 |
| 周期→销毁数量 | `peroid2burnamount_{period}` | `{burnAmount}` (uint64字符串) | db_api.cpp:1340-1342 |
| 周期+类型→Gas消耗 | `period2gasamount_{period}_{type}` | `{gasAmount}` (uint64字符串) | db_api.cpp:1544-1547 |
| 周期+地址→打包次数 | `period2packagercount_{period}_{addr}` | `{count}` (uint64字符串) | db_api.cpp:1550-1552 |

---

### 2.10 全局通缩机制

| 数据类型 | Key | Value | 位置 |
|---------|-----|-------|------|
| 总循环供应量 | `totalcirculation_` | `{amount}` (uint64字符串) | db_api.cpp:846-848 |
| 总销毁数量 | `totalburnamount_` | `{amount}` (uint64字符串) | db_api.cpp:1349-1351 |
| 总委托数量 | `totaldelegateAmount_` | `{amount}` (uint64字符串) | db_api.cpp:1355-1357 |
| 总锁定金额 | `totallockedamount_` | `{amount}` (uint64字符串) | db_api.cpp:1503-1505 |
| 周期→锁定金额 | `period2totallockedamount_{period}` | `{amount}` (uint64字符串) | db_api.cpp:1508-1510 |

---

### 2.11 其他

| 数据类型 | Key | Value | 位置 |
|---------|-----|-------|------|
| 地址→nonce | `addr2nonce_{addr}` | `{nonce}` (uint64字符串) | db_api.cpp:840-843 |
| 初始化版本 | `initver_` | 版本字符串 | db_api.cpp:1361-1363 |
| 地址→资产类型 | `addr2Assettype_{addr}` | `asset1_asset2_..._` | db_api.cpp:1519-1522 |
| RLP哈希→内部哈希 | `rlphash2txhash_{rlpHash}` | `{internalHash}` | db_api.cpp:862-865 |
| 回滚块数据 | `rollbackblocks_{blockNum}` | `block1_rollbackblock_block2_rollbackblock_...` (特殊分隔符`_rollbackblock_`) | db_api.cpp:1149-1152 |
| 回滚块编号 | `rollblocknum_blocknum` | `num1_num2_..._` | db_api.cpp:1171-1173 |
| 30日锁定数据 | `{addr}` (直接使用) | 时间戳 (mergeValue模式) | db_api.cpp:1194-1238 |

**30日锁定数据的Key问题**: 见 `db/db_api.cpp:1195`, Key直接使用地址字符串, 无前缀隔离。此设计存在Key冲突风险, 已在 module_overview.md 问题清单中标出。

---

## 3. Value 组织模式总结

### 3.1 三种 Value 类型

| 类型 | 存储方式 | 示例 | 使用场景 |
|------|---------|------|---------|
| **单值** (Singular) | writeData / deleteData | 余额、nonce、区块数据、交易数据 | 一对一映射 |
| **集合** (Set/List) | mergeValue / removeMergeValue / getMergeValue | UTXO集合、质押地址、投票地址 | 一对多映射, 使用`_`分隔符 |
| **复合值** (Composite) | mergeValue + 子格式分隔 | 委托关系 `地址-资产类型`; 投票计数 `赞成_反对` | 结构化数据 |

### 3.2 分隔符使用规范

| 分隔符 | 用途 | 示例 |
|--------|------|------|
| `_` (下划线) | 默认集合元素分隔符 | `hash1_hash2_hash3_` |
| `-` (短横线) | 委托关系中的子字段分隔 | `delegAddr-assetType` |
| `_rollbackblock_` | 回滚块数据的特殊分隔符 | (避免与下划线分隔符歧义) |
| `_All30day_` | 30日锁定数据的特殊分隔符 | (同上) |

### 3.3 mergeValue 的分隔符参数化

注意 mergeValue 支持自定义分隔符 (默认`_`):
```cpp
// db/db_api.h:2637
DBStatus mergeValue(key, value, firstOrLast=false, Delimiter="_");

// 特殊用法示例:
mergeValue(db_key, blocks, false, "_rollbackblock_");  // db_api.cpp:1152
mergeValue(db_key, data, false, "_All30day_");         // db_api.cpp:1203
```

---

## 4. 数据组织架构图

```
RocksDB 数据库 (默认 Column Family)
│
├── 区块域
│   ├── blkht2blkhs_{h}     → hash1_hash2_...
│   ├── blkhs2blkht_{hash}  → height
│   ├── blkhs2blkraw_{hash} → blockRaw
│   ├── blktop_             → topHeight
│   ├── blkht2sumhs_{h}     → sumHash (h%100==0)
│   ├── ht2thousandsumhs_{h} → thousandHash (h%1000==0)
│   └── thousandsumhstop_   → topThousand
│
├── 交易域
│   ├── txhs2txraw_{hash}   → txRaw
│   └── txhs2blkhs_{hash}   → blockHash
│
├── UTXO/余额域
│   ├── addr2utxo_{addr}{asset}          → utxoHash1_utxoHash2_...
│   ├── utxohash2utxovalue_{addr}_{utxo}_{asset} → balance
│   ├── addr2bal_{addr}{asset}           → balance
│   └── assettype_                       → asset1_asset2_...
│
├── 质押/委托域
│   ├── stakeaddr_                       → addr1_addr2_...
│   ├── addr2stakeutxos_{addr}{asset}    → utxo1_utxo2_...
│   ├── bonusaddr2delegatingaddrandassettype_{bonus} → del1-asset1_...
│   ├── delegatingaddr2bonusaddrandassettype_{del}   → bonus1-asset1_...
│   ├── bonusaddr2delegatingaddrutxos_{bonus}_{del}_{asset} → utxo...
│   ├── period2bonusutxos_{period}       → utxo...
│   ├── period2fundutxos_{period}        → utxo...
│   └── period2delegatingutxo_{period}   → utxo...
│
├── 合约域
│   ├── evmdeployeraddr_                 → deployer1_deployer2_...
│   ├── deployeraddr2contractaddr_{dep}  → contract1_contract2_...
│   ├── contractaddr2contractcode_{c}    → bytecode
│   ├── contractaddr2deployutxo_{c}      → deployUtxo
│   ├── contractaddr2latestutxo_{c}      → latestUtxo
│   ├── mptkey2mptvalue_{key}            → rlpNode
│   └── contractaddr2assettype_{c}       → assetType
│
├── 投票/提案域
│   ├── assettype2revoketxhash_{a}       → txHash...
│   ├── assettype2approvevoteaddr_{a}    → addr...
│   ├── assettype2againstvoteaddr_{a}    → addr...
│   ├── assettype2votetxhash_{a}         → txHash...
│   ├── assettype2proposalinfo_{a}       → proposalInfo
│   ├── assettype2revokeproposalinfo_{a} → revokeInfo
│   ├── assettype2proposalvotescount_{a} → approve_against
│   ├── addr2votecount_{a}{addr}         → count
│   └── assettype2totalvotecount_{a}     → total
│
├── 锁定域
│   ├── lockaddr_                        → addr...
│   └── assettype2lockutxos_{addr}{a}    → utxo...
│
├── 共识统计域
│   ├── peroid2signcount_{p}{addr}       → count
│   ├── peroid2blockcount_{p}            → count
│   ├── peroid2signaddr_{p}              → addr...
│   ├── peroid2burnamount_{p}            → amount
│   ├── period2gasamount_{p}_{type}      → amount
│   └── period2packagercount_{p}_{addr}  → count
│
├── 全局域
│   ├── totalcirculation_                → amount
│   ├── totalburnamount_                 → amount
│   ├── totaldelegateAmount_             → amount
│   ├── totallockedamount_               → amount
│   └── period2totallockedamount_{p}     → amount
│
├── EVM辅助域
│   ├── addr2nonce_{addr}                → nonce
│   ├── addr2Assettype_{addr}            → asset...
│   ├── initver_                         → version
│   └── rlphash2txhash_{hash}            → internalHash
│
└── 回滚域
    ├── rollbackblocks_{num}             → block..._rollbackblock_...
    └── rollblocknum_blocknum            → num...
```

---

## 5. 附录: Column Family 分析

### 5.1 当前状态

**当前实现未使用 RocksDB Column Family**。所有数据存储在默认 Column Family 中。

依据:
- `db/rocksdb.cpp:40-65` 中 `rocksdb::Options` 未配置 Column Family
- `TransactionDB::Open` 使用默认参数 `TransactionDBOptions`
- 所有 `Get` / `Put` / `MultiGet` 调用均未指定 Column Family

### 5.2 潜在优化方向

如果将来需要引入 Column Family, 可考虑按以下维度划分:

| Column Family | 包含数据类型 | 理由 |
|--------------|-------------|------|
| `default` | 区块、交易、共识统计 | 高频读写 |
| `balance` | UTXO余额、地址余额、nonce | 高频读写, 需要独立MemTable |
| `contract` | 合约代码、MPT节点 | 大value, 独立压缩策略 |
| `governance` | 投票、提案、质押、委托 | 中低频, 独立Compaction |
| `rollback` | 回滚块数据 | 临时数据, 可配置更短TTL |

---

**可信度说明**: 所有Key-Value设计均基于源码直接分析, 可信度: **高**。规范对比部分标注了差异。
