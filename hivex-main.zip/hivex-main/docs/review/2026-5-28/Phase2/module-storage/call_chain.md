# 模块2: 存储层 (RocksDB) 核心调用链

## 1. 数据库初始化 -> 创世区块写入

```mermaid
sequenceDiagram
    participant Main as 应用启动
    participant DBInit as DBInit()
    participant RS as RocksDB
    participant TDB as TransactionDB
    participant DBW as DBReadWriter
    participant RDBW as RocksDBReadWriter

    Main->>DBInit: DBInit(db_path)
    DBInit->>RS: MagicSingleton<RocksDB>::GetInstance()
    DBInit->>RS: setDBPath(db_path)
    DBInit->>RS: initDB(retStatus)
    
    Note over RS,TDB: rocksdb.cpp:40-65
    RS->>RS: isInitialized check
    RS->>RS: Options: create_if_missing=true
    RS->>RS: IncreaseParallelism()
    RS->>RS: OptimizeLevelStyleCompaction()
    RS->>RS: Register BackgroundErrorListener
    RS->>TDB: TransactionDB::Open(options, txn_options, path, &db_)
    TDB-->>RS: Status::ok()
    RS->>RS: isInitialized = true
    
    Note over Main,DBW: 创世区块写入 (由上层 ca/ 模块发起)
    Main->>DBW: new DBReadWriter("genesis")
    DBW->>DBW: reInitTransaction()
    DBW->>RDBW: transactionInit()
    RDBW->>TDB: BeginTransaction(write_options_)
    TDB-->>RDBW: Transaction* txn_
    DBW->>DBW: autoOperationTrans = true
    
    Note over Main,DBW: 写入创世数据
    DBW->>DBW: setBlockByBlockHash(genesisHash, blockData)
    DBW->>RDBW: writeData(key, value)
    RDBW->>TDB: txn_->Put(key, value)
    DBW->>DBW: setBlockTop(0)
    DBW->>DBW: setBlockHashByBlockHeight(0, genesisHash)
    DBW->>DBW: setTransactionByHash(txHash, txData)
    
    DBW->>DBW: transactionCommit()
    DBW->>RDBW: transactionCommit(retStatus)
    RDBW->>TDB: txn_->Commit()
    TDB-->>RDBW: Status::ok()
    RDBW->>RDBW: delete txn_ / txn_ = nullptr
    DBW->>DBW: autoOperationTrans = false
```

**关键代码路径**:
- 启动入口: `db/db_api.cpp:83-93` (`DBInit`)
- RocksDB打开: `db/rocksdb.cpp:40-65` (`initDB`)
- 事务初始化: `db/rocksdb_read_write.cpp:17-25` (`transactionInit`)
- 数据写入: `db/db_api.cpp:1656-1664` (`writeData`) -> `db/rocksdb_read_write.cpp:346-390` (`writeData`)
- 事务提交: `db/db_api.cpp:828-838` (`transactionCommit`) -> `db/rocksdb_read_write.cpp:27-51` (`transactionCommit`)

---

## 2. 交易写入流程

```mermaid
sequenceDiagram
    participant CA as 共识层
    participant DBW as DBReadWriter
    participant RDBW as RocksDBReadWriter
    participant TDB as TransactionDB
    participant MERGE as mergeValue逻辑

    CA->>DBW: new DBReadWriter("tx_process")
    DBW->>DBW: reInitTransaction()
    Note over DBW: autoOperationTrans = true

    Note over CA,DBW: Step 1: 保存交易原始数据
    DBW->>DBW: setTransactionByHash(txHash, txRaw)
    DBW->>RDBW: writeData("txhs2txraw_"+txHash, txRaw)
    RDBW->>TDB: txn_->Put(key, value)

    Note over CA,DBW: Step 2: 建立交易->区块映射
    DBW->>DBW: setBlockHashByTransactionHash(txHash, blockHash)
    DBW->>RDBW: writeData("txhs2blkhs_"+txHash, blockHash)

    Note over CA,DBW: Step 3: 更新UTXO集合
    DBW->>DBW: setUtxoHashesByAddr(addr, assetType, utxoHash)
    DBW->>RDBW: mergeValue(key, utxoHash, firstOrLast=false)
    Note over MERGE: rocksdb_read_write.cpp:136-202
    RDBW->>TDB: txn_->GetForUpdate(key) -- 加排他锁读取
    TDB-->>RDBW: 当前值 (可能存在)
    RDBW->>RDBW: SplitString + push_back + 拼接
    RDBW->>TDB: txn_->Put(key, 拼接结果)

    Note over CA,DBW: Step 4: 更新UTXO余额
    DBW->>DBW: setUtxoValueByUtxoHashes(utxoHash, addr, assetType, balance)
    DBW->>RDBW: writeData(key, balance)

    Note over CA,DBW: Step 5: 更新账户余额
    DBW->>DBW: setBalanceByAddr(addr, "MM", newBalance)
    DBW->>RDBW: writeData("addr2bal_"+addr+"MM", to_string(newBalance))

    Note over CA,DBW: Step 6: 更新资产类型记录
    DBW->>DBW: setAssetTypeByAddr(addr, assetType)
    DBW->>RDBW: mergeValue("addr2Assettype_"+addr, assetType)

    CA->>DBW: transactionCommit()
    DBW->>RDBW: transactionCommit(retStatus)
    RDBW->>TDB: txn_->Commit()
    TDB-->>RDBW: OK
    DBW->>DBW: autoOperationTrans = false
```

**关键观察**:
- 交易写入是一个 **原子事务**, 所有关联数据要么全部写入, 要么全部回滚
- mergeValue 操作 (用于集合类数据) 在事务内使用 `GetForUpdate` 加锁, 保证并发安全
- 如果任一步骤失败, DBReadWriter 析构时自动回滚 (autoOperationTrans=true)

---

## 3. 区块保存流程

```mermaid
sequenceDiagram
    participant PACK as 打包节点
    participant DBW as DBReadWriter
    participant RDBW as RocksDBReadWriter
    participant TDB as TransactionDB

    PACK->>DBW: new DBReadWriter("save_block")
    DBW->>DBW: reInitTransaction()

    Note over PACK,DBW: Step 1: 保存区块数据
    DBW->>DBW: setBlockByBlockHash(blockHash, blockRaw)
    Note right of DBW: Key: blkhs2blkraw_ + blockHash

    Note over PACK,DBW: Step 2: 建立高度->区块哈希映射 (支持分叉)
    DBW->>DBW: setBlockHashByBlockHeight(height, blockHash, isMainBlock)
    Note right of DBW: mergeValue with isMainBlock顺序控制
    Note right of DBW: Key: blkht2blkhs_ + height
    Note right of DBW: Value: hash1_hash2_hash3_ (下划线分隔多hash)

    Note over PACK,DBW: Step 3: 建立区块哈希->高度映射
    DBW->>DBW: setBlockHeightByBlockHash(blockHash, height)
    Note right of DBW: Key: blkhs2blkht_ + blockHash

    Note over PACK,DBW: Step 4: 更新最高高度
    DBW->>DBW: setBlockTop(height)
    Note right of DBW: Key: blktop_ (单值)

    Note over PACK,DBW: Step 5: 每100高度计算SumHash
    alt height % 100 == 0
        DBW->>DBW: setSumHashByHeight(height, sumHash)
        Note right of DBW: Key: blkht2sumhs_ + height
    end

    Note over PACK,DBW: Step 6: 每1000高度计算千区块哈希
    alt height % 1000 == 0
        DBW->>DBW: setThousandSumHashByBlockHeight(height, sumHash)
        DBW->>DBW: setThousandSumHashTop(height/1000)
        Note right of DBW: Key: ht2thousandsumhs_ + height
    end

    Note over PACK,DBW: Step 7: 保存所有交易 (遍历区块交易列表)
    loop for each tx in block.txs
        DBW->>DBW: setTransactionByHash(tx.hash, tx.raw)
        DBW->>DBW: setBlockHashByTransactionHash(tx.hash, blockHash)
    end

    PACK->>DBW: transactionCommit()
    DBW->>RDBW: transactionCommit()
    RDBW->>TDB: txn_->Commit()
```

**关键设计**: `setBlockHashByBlockHeight` 使用 `mergeValue` 且 `isMainBlock` 参数控制顺序
- `isMainBlock=true`: 新区块哈希插入到列表**开头** (作为主链)
- `isMainBlock=false`: 新区块哈希追加到列表**末尾** (作为分叉区块)
- 依据: `db/db_api.cpp:890-894` (`setBlockHashByBlockHeight`); `rocksdb_read_write.cpp:163-176` (mergeValue 中 `firstOrLast` 分支)

---

## 4. 余额查询流程

```mermaid
sequenceDiagram
    participant RPC as RPC层
    participant R as DBReader
    participant RDR as RocksDBDataReader
    participant TDB as TransactionDB

    RPC->>R: new DBReader()
    Note over R: db_reader_(MagicSingleton<RocksDB>::GetInstance())
    Note over R: 自动获取全局RocksDB单例

    RPC->>R: getBalanceByAddr(address, "MM", balance)
    
    Note over R: db/db_api.cpp:278-292
    R->>R: readData("addr2bal_" + address + "MM", value)
    
    Note over R: db/db_api.cpp:782-800
    R->>R: key empty check → DB_PARAM_NULL
    R->>RDR: readData(key, value, retStatus)
    
    Note over RDR: db/rocksdb_read.cpp:62-99
    RDR->>RDR: isInitSuccess() check
    RDR->>RDR: key empty check
    RDR->>TDB: db_->Get(read_options_, key, &value)
    
    alt 数据存在
        TDB-->>RDR: Status::ok() + value
        RDR-->>R: true
        R-->>R: DB_SUCCESS
        R->>R: balance = std::stol(value)
        R-->>RPC: balance value
    else 数据不存在
        TDB-->>RDR: Status::NotFound()
        RDR-->>R: false (IsNotFound)
        R-->>R: DB_NOT_FOUND
        R->>R: balance = 0  (特殊处理)
        Note over R: getBalanceByAddr中NotFound视为余额为0
        R-->>RPC: 0
    else 其他错误
        TDB-->>RDR: Status::error
        RDR-->>R: false
        R-->>R: DB_ERROR
        R-->>RPC: DB_ERROR
    end
```

**余额查询的特殊处理** (db_api.cpp:287-291):
```cpp
if(DBStatus::DB_NOT_FOUND == ret) {
   balance = 0;  // NotFound = 余额为0, 不视为错误
}
```
这是一个重要的设计决策: 未在数据库中记录的地址余额被视为 0, 而不是错误。

---

## 5. mergeValue 完整流程图

```mermaid
flowchart TD
    A[DBReadWriter::mergeValue] --> B{key/value空?}
    B -->|是| C[返回 DB_ERROR]
    B -->|否| D[RocksDBReadWriter::mergeValue]
    
    D --> E{DB初始化?}
    E -->|否| F[Status::Aborted]
    E -->|是| G{txn_为空?}
    G -->|是| H[Status::Aborted]
    G -->|否| I{key/value空?}
    I -->|是| J[Status::Aborted]
    I -->|否| K[readForUpdate操作]
    
    K --> L{retStatus?}
    L -->|ok| M[SplitString当前值]
    L -->|NotFound| N[直接writeData新值]
    
    M --> O{value已在列表中?}
    O -->|否| P{firstOrLast?}
    O -->|是| Q[跳过, 不重复添加]
    
    P -->|true| R[插入到列表开头]
    P -->|false| S[追加到列表末尾]
    
    R --> T[重新拼接所有非空元素]
    S --> T
    Q --> U[返回true (已存在)]
    T --> V[writeData写入拼接结果]
    
    N --> W{写入成功?}
    V --> W
    W -->|是| X[返回true]
    W -->|否| Y[返回false]
```

**mergeValue 并发安全性**: 在事务内使用 `GetForUpdate(txn_)` 对Key加排他行锁, 确保同一事务内 Read-Modify-Write 的原子性。TransactionDB 负责锁管理, 不同事务间通过锁或 MVCC 隔离。

---

## 6. 数据读取调用链总览

```
上层业务 (共识/RPC/网络/合约)
    │
    ├── 创建 DBReader (栈/堆对象)  ← 轻量, 仅持有 shared_ptr<RocksDB>
    │   └── getBalanceByAddr / getBlockTop / ... (高层API)
    │       └── readData(key, value)
    │           └── RocksDBDataReader::readData(key, value, status)
    │               └── db_->Get(read_options_, key, &value)  ← 无事务, 快照读
    │
    ├── 批量读取
    │   └── multiReadData(keys, values)
    │       └── RocksDBDataReader::multiReadData(keys, values, statuses)
    │           └── db_->MultiGet(read_options_, keys, &values)
    │
    └── 创建 DBReadWriter (栈/堆对象)  ← 构造函数自动Begin Transaction
        ├── setBalanceByAddr / setBlockByBlockHash / ... (高层写入API)
        │   └── writeData(key, value)
        │       └── RocksDBReadWriter::writeData(key, value, status)
        │           └── txn_->Put(key, value)  ← 事务内写入
        │
        ├── mergeValue (追加集合元素)
        │   └── RocksDBReadWriter::mergeValue(key, value, status)
        │       ├── txn_->GetForUpdate(key, &oldValue)  ← 加排他锁
        │       ├── SplitString + append + Join
        │       └── txn_->Put(key, newValue)
        │
        ├── transactionCommit()  ← 显式提交
        │   └── RocksDBReadWriter::transactionCommit()
        │       ├── txn_->Commit()
        │       └── delete txn_
        │
        └── ~DBReadWriter()  ← 析构时自动回滚(如果未提交)
            └── transactionRollBack()
                └── RocksDBReadWriter::transactionRollBack()
                    ├── txn_->Rollback()
                    └── delete txn_
```

---

**可信度说明**: 所有调用链基于源代码直接跟踪, 可信度: **高**。
