# 模块2: 存储层 (RocksDB) 线程模型

## 1. 架构概述

MeMeChain 存储层的线程模型基于以下核心设计:

```
┌──────────────────────────────────────────────────────────┐
│          应用线程1          应用线程2          ...        │
│              │                  │                         │
│    DBReader(栈)      DBReadWriter(栈)                     │
│       (无锁读)          (事务内读写)                       │
│              │                  │                         │
│      ┌───────┴───────┐   ┌─────┴──────────┐              │
│      │ RocksDBData   │   │ RocksDBRead    │              │
│      │   Reader      │   │    Writer      │              │
│      │ (shared_ptr)  │   │ (shared_ptr)   │              │
│      └───────┬───────┘   └─────┬──────────┘              │
│              │                  │                         │
│    db_->Get()              txn_->Put()                    │
│    db_->MultiGet()         txn_->GetForUpdate()           │
│              │                  │                         │
│              └────────┬─────────┘                         │
│                       ↓                                   │
│           ┌──────────────────────┐                        │
│           │   RocksDB 全局单例   │                        │
│           │  (MagicSingleton)    │                        │
│           └──────────┬───────────┘                        │
│                      ↓                                    │
│           ┌──────────────────────┐                        │
│           │ rocksdb::Transaction │                        │
│           │       DB              │                        │
│           │  (线程安全引擎)       │                        │
│           └──────────────────────┘                        │
└──────────────────────────────────────────────────────────┘
```

**关键设计点**: 全局只有一个 `RocksDB` 实例 (通过 `MagicSingleton<RocksDB>::GetInstance()` 获取), 所有线程共享。并发安全由 RocksDB TransactionDB 引擎自身保证。

---

## 2. DBReader (只读) 并发模型

### 2.1 只读操作的线程安全性

`DBReader` 通过 `RocksDBDataReader` 执行只读操作:

**RocksDBDataReader 的线程安全分析** (rocksdb_read.h:17-67, rocksdb_read.cpp:7-99):

| 成员 | 并发访问 | 安全性 |
|------|---------|--------|
| `read_options_` | 不修改 (const语义) | **安全** - rocksdb::ReadOptions 在 Get/MultiGet 中是只读参数 |
| `rocksdb_` (shared_ptr) | 仅引用计数修改 | **安全** - shared_ptr 引用计数操作是原子的 |

**操作**:
- `db_->Get(read_options_, key, &value)` — RocksDB 的 Get 操作是线程安全的 (通过快照读取)
- `db_->MultiGet(read_options_, keys, &values)` — RocksDB 的 MultiGet 操作是线程安全的

**结论**: 多个线程可以**同时**创建各自的 `DBReader` 实例 (每个实例持有 shared_ptr<RocksDB>), 并安全地并发读取。RocksDB 的 MVCC 和多版本并发控制确保读操作不会被写操作阻塞。

**可信度**: 高 (基于 RocksDB 官方文档和源代码分析)

### 2.2 DBReader 的线程安全保证

```cpp
// 线程1 和 线程2 可以同时安全执行:
// 线程1
DBReader r1;
r1.getBlockTop(height);
r1.getBalanceByAddr(addr, "MM", balance);

// 线程2  
DBReader r2;
r2.getBlockTop(height);
r2.getTransactionByHash(hash, txRaw);
```

每个 `DBReader` 是独立的栈/堆对象, 没有共享可变状态, 完全线程安全。

---

## 3. DBReadWriter (读写事务) 并发模型

### 3.1 事务隔离级别

RocksDB TransactionDB 默认使用**快照隔离** (Snapshot Isolation):
- 每个事务看到的是事务开始时的数据快照
- 写操作在事务内可见, 但提交前对其他事务不可见
- 提交时检测写-写冲突 (通过 Sequence Number 机制)

依据: `rocksdb/db.h` TransactionDB 文档, 以及代码中未指定特殊隔离级别的事实。

### 3.2 单事务内的原子性

```cpp
DBReadWriter writer("tx_name");
// writer.reInitTransaction() 自动调用, 开始事务

writer.setBalanceByAddr(addr1, "MM", 100);    // 操作1: txn_->Put
writer.setBalanceByAddr(addr2, "MM", 50);     // 操作2: txn_->Put
writer.setUtxoHashesByAddr(addr1, "MM", utxo); // 操作3: readForUpdate + Put

writer.transactionCommit();  // 原子提交: 3个操作要么全部生效, 要么全部不生效
```

**底层保证**: RocksDB TransactionDB 通过 WriteBatch 和 WAL (Write-Ahead Log) 保证事务原子性。

### 3.3 mergeValue 的并发安全分析

`mergeValue` 是最复杂的并发场景, 因为它涉及 Read-Modify-Write:

```cpp
// rocksdb_read_write.cpp:136-202
bool RocksDBReadWriter::mergeValue(key, value, retStatus, firstOrLast, delimiter) {
    // Step 1: 加排他锁读取
    readForUpdate(key, ret_value, retStatus);  // → txn_->GetForUpdate(read_options_, key, &value)
    
    // Step 2: 修改 (在内存中)
    SplitString(ret_value, delimiter, split_values);
    // ... 添加/去重/排序逻辑 ...
    
    // Step 3: 写回
    writeData(key, ret_value, retStatus);  // → txn_->Put(key, value)
}
```

**并发场景分析**:

```
时间轴:  事务A                         事务B
───────  ────────                      ────────
T1       BeginTransaction              BeginTransaction
T2       mergeValue(key, "v1")         
T3         GetForUpdate(key) → 锁住key 
T4                                      mergeValue(key, "v2")
T5                                        GetForUpdate(key) → 等待锁...
T6         Put(key, "old_v1_")         
T7       Commit() → 释放锁             
T8                                        GetForUpdate返回 → 读到"old_v1_"
T9                                        Put(key, "old_v1_v2_")
T10                                     Commit()
```

**机制**: RocksDB TransactionDB 的 `GetForUpdate` 对行加排他锁, 其他事务对该行的 `GetForUpdate` 必须等待锁释放。这保证了 mergeValue 操作的原子性。

**可信度**: 高

### 3.4 事务间的并发安全

多个 `DBReadWriter` 可以同时存在, 各自持有独立的 Transaction:

```
线程1: DBReadWriter writer1 → Transaction1 → 操作 KeyA, KeyB
线程2: DBReadWriter writer2 → Transaction2 → 操作 KeyB, KeyC
线程3: DBReadWriter writer3 → Transaction3 → 操作 KeyA, KeyC
```

**写-写冲突检测**: 如果两个事务修改了相同的Key, TransactionDB 会在提交时检测冲突。先提交的事务成功, 后提交的事务可能收到写入冲突错误。

**注意**: 当前代码中 `writeData` 和 `transactionCommit` **不检测写入冲突错误**, 仅检查 `retStatus.ok()`:
```cpp
// db/rocksdb_read_write.cpp:375
if (retStatus.ok()) { return true; }
// 任何非ok状态 (包括写入冲突) 都返回false, 但不区分冲突类型
```

---

## 4. RocksDB TransactionDB 的并发保证

### 4.1 引擎层面的保证

| 保证类型 | 机制 | 说明 |
|---------|------|------|
| 原子性 (Atomicity) | WriteBatch + WAL | 事务内所有操作原子提交 |
| 一致性 (Consistency) | 快照隔离 | 事务看到一致的数据快照 |
| 隔离性 (Isolation) | Snapshot Isolation + 行锁 | GetForUpdate 加排他锁; 普通 Get 读快照 |
| 持久性 (Durability) | WAL (Write-Ahead Log) | 提交的数据在崩溃后可恢复 |

### 4.2 当前配置的并发参数

依据 `db/rocksdb.cpp:40-65`:

| 配置项 | 值 | 说明 |
|--------|-----|------|
| 并发后台任务 | `IncreaseParallelism()` | 最大后台压缩和刷新线程数 |
| 压缩方式 | `OptimizeLevelStyleCompaction()` | Level Compaction |
| WriteOptions | 默认 | 默认不等待sync (由OS决定刷盘时机) |
| ReadOptions | 默认 | 默认不指定snapshot (使用当前最新状态) |
| 事务锁超时 | 默认 (TransactionDBOptions 默认) | 未显式配置 |

### 4.3 RocksDB 引擎的线程模型

```
┌─────────────────────────────────────────────────┐
│           RocksDB TransactionDB 内部线程          │
│                                                  │
│  主线程 (调用者线程)                              │
│    ├─ Get / MultiGet (读操作)                    │
│    ├─ BeginTransaction / Commit / Rollback       │
│    └─ Put / Delete / GetForUpdate                │
│                                                  │
│  后台线程 (RocksDB 内部管理)                      │
│    ├─ Flush 线程: 将 MemTable 刷入 SST 文件       │
│    ├─ Compaction 线程: 合并排序 SST 文件          │
│    └─ WAL 写入线程: 预写日志持久化                │
│                                                  │
│  事件监听线程                                     │
│    └─ BackgroundErrorListener: 处理后台错误       │
└─────────────────────────────────────────────────┘
```

### 4.4 默认 WriteOptions 的风险

当前代码未显式配置 WriteOptions 的 sync 参数:
```cpp
// rocksdb_read_write.h:193
rocksdb::WriteOptions write_options_;  // 默认构造
```

**默认 WriteOptions**:
- `sync = false`: 每次写入不等待 OS fsync, 由 OS 决定何时刷盘
- `disableWAL = false`: WAL 启用 (TransactionDB 强制启用)

**风险**: 在操作系统崩溃时, 可能丢失已"提交"但未 fsync 的数据。对于区块链节点, 这可能导致账本不一致。
- **风险等级**: 中
- **修复建议**: 考虑在关键操作 (如区块保存) 中设置 `sync = true`, 或全局配置 `WriteOptions.sync = true`

---

## 5. 全局单例的线程安全

### 5.1 MagicSingleton 模式

```cpp
// utils/magic_singleton.h:18-33
template<typename T>
class MagicSingleton {
public:
    template<typename ...Args>
    static std::shared_ptr<T> GetInstance(Args&&... args) {
        static std::shared_ptr<T> instance = std::make_shared<T>(std::forward<Args>(args)...);
        return instance;
    }
};
```

**线程安全性**: C++11 保证 `static` 局部变量的初始化是线程安全的。MagicSingleton 的 `GetInstance` 在任何线程中首次调用时, `instance` 的构造是安全的。

**但**: `RocksDB` 的 `isInitialized` 字段由额外的 `std::mutex initSuccessMutex` 保护:
```cpp
// rocksdb.h:88, rocksdb.cpp:87-91
bool RocksDB::isInitSuccess() {
    std::lock_guard<std::mutex> lock(initSuccessMutex);
    return isInitialized;
}
```
这是合理的设计 — `initDB` 和 `sestoryDB` 都通过互斥锁保护状态变更。

### 5.2 全局访问模式

所有数据库访问都通过以下路径获取 RocksDB 实例:
```cpp
// 方式1: 直接获取
auto rocksdb_ptr = MagicSingleton<RocksDB>::GetInstance();

// 方式2: 通过 DBReader (构造时自动获取)
DBReader reader;  // db_reader_(MagicSingleton<RocksDB>::GetInstance())  // db_api.cpp:95

// 方式3: 通过 DBReadWriter (构造时自动获取)
DBReadWriter writer;  // dbReaderWriter(MagicSingleton<RocksDB>::GetInstance(), txn_name)  // db_api.cpp:802
```

---

## 6. 并发场景汇总

| 场景 | 实现方式 | 并发安全保障 | 可信度 |
|------|---------|-------------|--------|
| 多线程只读 | 各自 DBReader → db_->Get | RocksDB 快照读, 天然安全 | 高 |
| 多线程写不同Key | 各自 DBReadWriter(不同事务) | TransactionDB 锁管理 | 高 |
| 多线程写相同Key | 各自 DBReadWriter, GetForUpdate | 事务锁 (写入者互相等待) | 高 |
| mergeValue并发 | GetForUpdate 加排他锁 | Read-Modify-Write 原子 | 高 |
| 全局初始化 | MagicSingleton + mutex | static初始化 + 互斥锁 | 高 |
| 读-写并发 | DBReader (快照) + 写事务 | MVCC 非阻塞读 | 高 |

---

## 7. 风险与建议

### 7.1 已知风险

| # | 风险 | 位置 | 影响 |
|---|------|------|------|
| 1 | mergeValue 和 writeData 的 txn_->Put 之间无显式冲突检测 | rocksdb_read_write.cpp | 写冲突时无区分处理 |
| 2 | WriteOptions sync=false 默认配置 | rocksdb_read_write.h:193 | 崩溃时可能丢失数据 |
| 3 | BackgroundErrorListener 直接 exit(-1) | rocksdb.cpp:18 | 所有线程同时终止 |
| 4 | RocksDBReadWriter 析构为空, 不自动清理 txn_ | rocksdb_read_write.cpp:13-16 | txn_ 泄漏 (但被上层DBReadWriter保护) |

### 7.2 改进建议

1. **冲突检测增强**: 在 `writeData` 和 `transactionCommit` 中区分错误类型, 对写入冲突采取重试策略
2. **Sync策略**: 为区块保存等关键操作配置 `WriteOptions.sync = true`
3. **优雅关闭**: 替换 `exit(-1)` 为触发安全关闭流程, 至少尝试:
   - 取消所有进行中的事务
   - 关闭数据库 (触发WAL flush)
   - 通知其他模块
4. **锁超时配置**: TransactionDBOptions 中配置合适的锁超时时间, 避免死锁导致的长时间等待

---

**可信度说明**:
- RocksDB TransactionDB 并发保证机制基于 RocksDB 官方文档, 可信度: 高
- 特定于本项目的结论基于源代码直接分析, 可信度: 高
- 标记为【推测】的结论需要进一步验证
