# 模块2: 存储层 (RocksDB) 核心类分析

## 1. 类继承与分层架构

```
                    Global
                DBInit(path)              ← 全局初始化入口
                     ↓
        MagicSingleton<RocksDB>           ← 全局单例 (线程安全)
                     ↓
             RocksDB (全局单例)
         管理 rocksdb::TransactionDB*     ← 底层引擎实例
                     ↓
        ┌────────────┴────────────┐
        ↓                         ↓
 RocksDBDataReader          RocksDBReadWriter
 (只读, 共享DB)            (读写事务, 持有txn*)
        ↓                         ↓
    DBReader                   DBReadWriter
 (高层只读API)            (高层读写API, 继承DBReader)
```

依据: `db/rocksdb.h:22-91`, `db/rocksdb_read.h:17-67`, `db/rocksdb_read_write.h:9-196`, `db/db_api.h:22-979`

---

## 2. 类详细分析

### 2.1 RocksDB (全局数据库实例)

**文件**: `db/rocksdb.h:22-91`, `db/rocksdb.cpp:21-117`

**职责**: 管理 RocksDB TransactionDB 的生命周期, 充当全局单例

**关键成员**:

| 成员 | 类型 | 说明 |
|------|------|------|
| `db_path_` | `std::string` | 数据库文件路径 |
| `db_` | `rocksdb::TransactionDB*` | 底层引擎指针 |
| `isInitialized` | `bool` | 初始化状态标记 |
| `initSuccessMutex` | `std::mutex` | 保护 `isInitialized` 的互斥锁 |

**关键方法**:

| 方法 | 位置 | 说明 |
|------|------|------|
| `setDBPath(path)` | rocksdb.cpp:35 | 设置数据库路径 (初始化前调用) |
| `initDB(retStatus)` | rocksdb.cpp:40 | 打开/创建 TransactionDB |
| `sestoryDB()` | rocksdb.cpp:66 | 关闭并销毁数据库 (注意方法名拼写错误) |
| `isInitSuccess()` | rocksdb.cpp:87 | 线程安全地查询初始化状态 |
| `getDBMemoryUsage(info)` | rocksdb.cpp:93 | 查询RocksDB内存使用情况 |

**初始化流程** (`initDB`, rocksdb.cpp:40-65):
```
1. 检查 isInitialized, 已初始化则返回 false
2. 创建 Options, 设置:
   - create_if_missing = true     (自动创建数据库)    (rocksdb.cpp:48)
   - IncreaseParallelism()        (自动设置线程数)    (rocksdb.cpp:49)
   - OptimizeLevelStyleCompaction() (LSM树优化)      (rocksdb.cpp:50)
   - 注册 BackgroundErrorListener                     (rocksdb.cpp:51-52)
3. 创建 TransactionDBOptions (默认配置)
4. 调用 TransactionDB::Open(options, txn_options, path, &db_)
5. 成功则标记 isInitialized = true
```

**关键发现 - 拼写错误**:
- `sestoryDB()` 应为 `destroyDB()` (rocksdb.h:60, rocksdb.cpp:66)
- **风险等级**: 低 (不影响功能, 但降低代码可读性)
- **修复建议**: 重命名为 `destroyDB()`

**初始化配置分析**:

| 配置项 | 值 | 位置 | 可信度 |
|--------|-----|------|--------|
| create_if_missing | true | rocksdb.cpp:48 | 高 |
| IncreaseParallelism | 自动 | rocksdb.cpp:49 | 高 |
| OptimizeLevelStyleCompaction | 自动 | rocksdb.cpp:50 | 高 |
| Column Family | 无 (使用默认) | 全文件 | 高 |
| 自定义 Comparator | 无 | 全文件 | 高 |
| WAL | 默认启用 (TransactionDB 自带) | - | 高 |
| 内存管理 | 默认配置 | - | 中【推测】 |

---

### 2.2 BackgroundErrorListener (后台错误监听器)

**文件**: `db/rocksdb.h:12-18`, `db/rocksdb.cpp:7-19`

**职责**: 监听 RocksDB 后台错误

**关键行为**:
```cpp
void OnBackgroundError(reason, errorStatus) {
    ERRORLOG(...);  // 记录错误日志
    exit(-1);       // 直接退出进程!  (rocksdb.cpp:18)
}
```

**严重问题**: 后台错误直接调用 `exit(-1)`, 无优雅关闭流程。
- **风险等级**: 高
- **触发场景**: RocksDB 内部遇到不可恢复的后台错误 (如磁盘满、数据损坏)
- **影响**: 进程直接终止, 未保存的内存状态丢失, 可能导致数据库文件损坏
- **修复建议**: 替代为触发进程安全关闭流程, 至少尝试刷新WAL和关闭数据库
- **验证方法**: 模拟磁盘满场景测试

---

### 2.3 RocksDBDataReader (底层只读读取器)

**文件**: `db/rocksdb_read.h:17-67`, `db/rocksdb_read.cpp:7-99`

**职责**: 直接使用 rocksdb::TransactionDB 的 DB 接口进行只读操作 (不经过事务)

**关键成员**:

| 成员 | 类型 | 说明 |
|------|------|------|
| `read_options_` | `rocksdb::ReadOptions` | 读取选项 (默认配置) |
| `rocksdb_` | `std::shared_ptr<RocksDB>` | 共享持有 RocksDB 实例 |

**关键方法**:

| 方法 | 位置 | 说明 |
|------|------|------|
| `readData(key, value, retStatus)` | rocksdb_read.cpp:62 | 单键读取, 调用 `db_->Get()` |
| `multiReadData(keys, values, retStatus)` | rocksdb_read.cpp:12 | 批量读取, 调用 `db_->MultiGet()` |

**错误处理行为**:

| 错误类型 | 处理方式 | 位置 |
|---------|---------|------|
| 数据库未初始化 | `ERRORLOG`, 返回 `Status::Aborted()` | rocksdb_read.cpp:66-68 |
| Key为空 | `ERRORLOG`, 返回 `Status::Aborted()` | rocksdb_read.cpp:70-74 |
| NotFound | `TRACELOG` (trace级别), 返回false | rocksdb_read.cpp:83-87 |
| kIOError | `ERRORLOG`, `exit(-1)` | rocksdb_read.cpp:93-97 |
| 其他错误 | `ERRORLOG`, 返回false | rocksdb_read.cpp:88-91 |

**重要**: RocksDBDataReader 的 `multiReadData` 内部先调用 `retStatus.clear()` (rocksdb_read.cpp:14), 而 `MultiGet` 本身也会重写 `retStatus`, 这个 `clear()` 是冗余的 (但无害)。

---

### 2.4 RocksDBReadWriter (底层读写事务封装)

**文件**: `db/rocksdb_read_write.h:9-196`, `db/rocksdb_read_write.cpp:6-473`

**职责**: 封装 RocksDB TransactionDB 的事务操作, 提供原子性的多键读写

**关键成员**:

| 成员 | 类型 | 说明 |
|------|------|------|
| `txn_name_` | `std::string` | 事务名称 (用于日志标识) |
| `rocksdb_` | `std::shared_ptr<RocksDB>` | 共享持有 RocksDB 实例 |
| `txn_` | `rocksdb::Transaction*` | 当前事务指针 |
| `write_options_` | `rocksdb::WriteOptions` | 写入选项 (默认) |
| `read_options_` | `rocksdb::ReadOptions` | 读取选项 (默认) |

**核心事务操作方法**:

| 方法 | 位置 | 实现 |
|------|------|------|
| `transactionInit()` | rocksdb_read_write.cpp:17 | `txn_ = db_->BeginTransaction(write_options_)` |
| `transactionCommit(retStatus)` | rocksdb_read_write.cpp:27 | `txn_->Commit()`, 成功后 `delete txn_` |
| `transactionRollBack(retStatus)` | rocksdb_read_write.cpp:53 | `txn_->Rollback()`, 成功后 `delete txn_` |

**数据操作方法**:

| 方法 | 位置 | 底层调用 |
|------|------|---------|
| `readData(k, v, s)` | rocksdb_read_write.cpp:301 | `txn_->Get(read_options_, k, &v)` |
| `multiReadData(ks, vs, ss)` | rocksdb_read_write.cpp:79 | `txn_->MultiGet(read_options_, ks, &vs)` |
| `writeData(k, v, s)` | rocksdb_read_write.cpp:346 | `txn_->Put(k, v)` |
| `deleteData(k, s)` | rocksdb_read_write.cpp:391 | `txn_->Delete(k)` |
| `readForUpdate(k, v, s)` | rocksdb_read_write.cpp:430 | `txn_->GetForUpdate(read_options_, k, &v)` (加排他锁) |
| `mergeValue(k, v, s, firstOrLast, delimiter)` | rocksdb_read_write.cpp:136 | 自定义合并逻辑 (并非 RocksDB Merge操作符!) |
| `getMergeValue(k, vs, s, delimiter)` | rocksdb_read_write.cpp:204 | 自定义拆分逻辑 |
| `removeMergeValue(k, v, s, delimiter)` | rocksdb_read_write.cpp:239 | 自定义移除逻辑 |

**mergeValue 实现详解** (rocksdb_read_write.cpp:136-202):
```
1. readForUpdate(key) - 加排他锁读取当前值
2. StringUtil::SplitString(ret_value, Delimiter) - 按分隔符拆分
3. 如果 value 不在现有列表中:
   - 如果 firstOrLast==true: 插入到列表开头
   - 否则: 追加到列表末尾
4. 重新拼接所有非空元素 (用 Delimiter 连接)
5. writeData(key, 拼接后的字符串)
```

这是一个应用层的 "集合追加" 操作, **不是** RocksDB 的 Merge Operator。需要注意:
- 使用 `GetForUpdate` 加排他锁保证原子性 (在事务内)
- 默认分隔符为 `_` (下划线)
- 如果Key不存在 (NotFound), 直接写入 `value`
- 内部跳过空字符串元素

**removeMergeValue 实现详解** (rocksdb_read_write.cpp:239-300):
```
1. readForUpdate(key) - 加排他锁读取
2. StringUtil::SplitString(ret_value, Delimiter) - 拆分
3. 循环删除所有匹配的 value (while循环)  ← 注意: 会删除所有重复项
4. 重新拼接
5. 如果结果为空: deleteData(key)
6. 否则: writeData(key, 结果)
```

---

### 2.5 DBStatus (操作状态枚举)

**文件**: `db/db_api.h:12-19`

```cpp
enum DBStatus {
    DB_SUCCESS = 0,                  // 操作成功
    DB_ERROR = 1,                    // 通用错误
    DB_PARAM_NULL = 2,               // 参数为空
    DB_NOT_FOUND = 3,                // 数据未找到
    DB_IS_EXIST = 4,                 // 数据已存在
    DB_DESERIALIZATION_FAILED = 5    // 反序列化失败
};
```

**分析**:
- `DB_IS_EXIST` (值4): 在 db_api.cpp 中**所有写操作均不使用**此返回值。仅定义但未使用 【废弃/未完成】, 可信度: 高
- `DB_DESERIALIZATION_FAILED` (值5): 同理, **未在任何 db_api.cpp 代码路径中返回**【废弃/未完成】, 可信度: 高
- 实际使用的5个状态: `DB_SUCCESS`, `DB_ERROR`, `DB_PARAM_NULL`, `DB_NOT_FOUND` (对应4个路径)
- 底层 RocksDB 状态映射:
  - `Status::ok()` → `DB_SUCCESS`
  - `Status::IsNotFound()` → `DB_NOT_FOUND`
  - `Status::Aborted()` 或其他 → `DB_ERROR`
  - 空 key → `DB_PARAM_NULL`

---

### 2.6 DBReader (高层只读API)

**文件**: `db/db_api.h:22-978`, `db/db_api.cpp:95-800`

**职责**: 提供面向业务的高层只读接口, 将业务语义的查询转换为 Key-Value 读取

**生命周期管理**:
```cpp
DBReader::DBReader() : db_reader_(MagicSingleton<RocksDB>::GetInstance())  // db_api.cpp:95
```
- 构造函数自动获取 RocksDB 全局单例
- 析构函数使用默认 (~DBReader() = default)
- 不可拷贝/移动 (delete)

**关键方法按数据域分组**:

| 数据域 | 方法 | 位置 (db_api.cpp) |
|--------|------|-------------------|
| 区块 | `getBlockTop`, `getBlockHashesByBlockHeight`, `getBlocksByBlockHash`, `getBlockHeightByBlockHash`, `getBlockHashByBlockHeight`, `getBlockHashsByBlockHeight`, `getBlockByBlockHash`, `getSumHashByHeight`, `getThousandSumHashByBlockHeight`, `getThousandSumHashTop` | 234, 110, 133, 144, 161, 174, 188, 199, 211, 223 |
| 交易 | `getTransactionByHash`, `getBlockHashByTransactionHash` | 264, 271 |
| UTXO/余额 | `getUtxoHashsByAddress`, `getUtxoValueByUtxoHashes`, `getBalanceByAddr` | 245, 257, 278 |
| 质押 | `getStakeAddr`, `getStakeUtxoByAddr` | 307, 319 |
| 委托 | `getDelegatingAddrAndAssetTypeByBonusAddr`, `getBonusAddrAndAssetTypeByDelegatingAddr`, `getDelegatingAddrUtxoByBonusAddr`, `getBonusUtxoByPeriod`, `getFundUtxoByPeriod`, `getDelegatingUtxoByPeriod` | 331, 344, 356, 368, 380, 391 |
| 合约 | `getEvmDeployerAddr`, `getContractAddrByDeployerAddr`, `getContractCodeByContractAddr`, `getContractDeployUtxoByContractAddr`, `getLatestUtxoByContractAddr` | 472, 484, 496, 501, 507 |
| MPT | `getMptValueByMptKey` | 513 |
| 资产 | `getAssetType`, `getAssetTypeByAddr`, `getAssetTypeByContractAddr` | 518, 661, 673 |
| 投票 | `getRevokeTxHashByAssetType`, `getApproveAddrsByAssetType`, `getAgainstAddrsByAssetType`, `getVoteTxHashByAssetType`, `getProposalInfoByAssetType`, `getRevokeProposalInfoByAssetType`, `getVoteCountByAssetType`, `getVoteCountByAddr`, `getTotalCountByAssetType` | 530, 543, 556, 568, 582, 587, 592, 611, 622 |
| 锁定 | `getLockAddr`, `getLockAddrUtxo` | 634, 647 |
| 共识统计 | `getSignCountByPeriod`, `getBlockNumberByPeriod`, `getSignAddrByPeriod`, `getBurnAmountByPeriod`, `getTotalBurnAmount`, `getTotalDelegatingAmount`, `getGasAmountByPeriod`, `getPackagerCountByPeriod` | 403, 415, 427, 438, 449, 461, 678, 691 |
| 全局 | `getTotalCirculation`, `getNonceByAddr`, `getTotalLockedAmonut`, `getTotalLockedAmountByPeriod`, `getInitVer`, `getInternalHashByRlpHash` | 99, 294, 705, 716, 727, 856 |

**拼写错误标注**:
- `getTotalLockedAmonut` 应为 `getTotalLockedAmount` (db_api.h:904, db_api.cpp:705)
- `PEROID` (peroid_) 在多个常量名中应为 `PERIOD` (如 `PEROID_TO_BONUS_UTXOS`, db_api.cpp:51)

---

### 2.7 DBReadWriter (高层读写API)

**文件**: `db/db_api.h:979-2693`, `db/db_api.cpp:802-1673`

**职责**: 继承 DBReader, 添加写入和事务管理能力

**生命周期管理**:
```cpp
DBReadWriter(txn_name)                                              // db_api.cpp:802
~DBReadWriter() { transactionRollBack(); }                          // db_api.cpp:808
```

**关键设计点**:

1. **自动事务管理**: 使用 `autoOperationTrans` 标志位控制自动回滚
   - 构造时: `autoOperationTrans = false` → `reInitTransaction()` → 开启自动操作
   - 析构时: 如果 `autoOperationTrans == true`, 自动调用 Rollback
   - `transactionCommit()` 后: `autoOperationTrans = false` (已提交, 不需要回滚)
   - 依据: `db_api.cpp:804-836`

2. **reInitTransaction 逻辑** (db_api.cpp:812-826):
   ```
   1. transactionRollBack() - 先回滚之前的事务
   2. autoOperationTrans = true
   3. dbReaderWriter.transactionInit() - 开始新事务
   ```

3. **私有方法 (delegation to RocksDBReadWriter)**:

| 方法 | 底层调用 | 位置 |
|------|---------|------|
| `readData` | `dbReaderWriter.readData()` | db_api.cpp:1610 |
| `multiReadData` | `dbReaderWriter.multiReadData()` | db_api.cpp:1569 |
| `writeData` | `dbReaderWriter.writeData()` | db_api.cpp:1656 |
| `deleteData` | `dbReaderWriter.deleteData()` | db_api.cpp:1665 |
| `mergeValue` | `dbReaderWriter.mergeValue()` | db_api.cpp:1628 |
| `getMergeValue` | `dbReaderWriter.getMergeValue()` | db_api.cpp:1638 |
| `removeMergeValue` | `dbReaderWriter.removeMergeValue()` | db_api.cpp:1647 |
| `transactionCommit` | `dbReaderWriter.transactionCommit()` | db_api.cpp:828 |
| `transactionRollBack` | `dbReaderWriter.transactionRollBack()` | db_api.cpp:1555 |

4. **multiReadData Bug分析** (db_api.cpp:1569-1608):
   - 第1577-1580行存在一个**冗余的局部变量** `str` 被构造但从未使用:
     ```cpp
     std::vector<std::string> str;
     for(auto t : keys) {
         str.push_back(t);
     }
     ```
   - 紧接着第1583-1587行又创建了 `db_keys_str` 做同样的事
   - **风险等级**: 低 (仅浪费少量CPU和内存, 不影响正确性)
   - **修复建议**: 删除第1577-1580行的冗余代码

---

## 3. 类关系总结图

```
┌──────────────────────────────────────────────────────────┐
│                    db_api.h (81.7KB)                      │
│                                                           │
│  enum DBStatus { SUCCESS, ERROR, NULL, NOT_FOUND, ... }  │
│                                                           │
│  class DBReader {                                         │
│    RocksDBDataReader db_reader_;                          │
│    + getBlockTop() + getBalanceByAddr() ...              │
│    + readData() + multiReadData()                        │
│  }                                                        │
│         ↑ 继承                                            │
│  class DBReadWriter : public DBReader {                   │
│    RocksDBReadWriter dbReaderWriter;                      │
│    bool autoOperationTrans;                               │
│    std::set<string> delete_keys_;   ← 未使用              │
│    + setBlockTop() + setBalanceByAddr() ...              │
│    + writeData() + deleteData() + mergeValue()           │
│    + transactionCommit() + reInitTransaction()           │
│  }                                                        │
└──────────────────────────────────────────────────────────┘
         ↓ 委托                    ↓ 委托
┌──────────────────────┐  ┌──────────────────────────────┐
│  RocksDBDataReader    │  │  RocksDBReadWriter            │
│  (rocksdb_read.h/cpp) │  │  (rocksdb_read_write.h/cpp)  │
│                       │  │                               │
│  read_options_        │  │  txn_name_                    │
│  shared_ptr<RocksDB>  │  │  shared_ptr<RocksDB>          │
│                       │  │  rocksdb::Transaction* txn_   │
│  + readData()         │  │  write_options_               │
│  + multiReadData()    │  │  read_options_                │
│                       │  │                               │
│  (使用 db_->Get,      │  │  + transactionInit()          │
│   db_->MultiGet)      │  │  + transactionCommit()        │
│                       │  │  + transactionRollBack()      │
│                       │  │  + readData() (txn_->Get)     │
│                       │  │  + writeData() (txn_->Put)    │
│                       │  │  + deleteData() (txn_->Delete)│
│                       │  │  + mergeValue() (自定义)      │
│                       │  │  + readForUpdate()            │
│                       │  │    (txn_->GetForUpdate)       │
└──────────────────────┘  └──────────────────────────────┘
         ↓ shared_ptr            ↓ shared_ptr
    ┌──────────────────────────────────────┐
    │          RocksDB (全局单例)            │
    │          (rocksdb.h/cpp)              │
    │                                       │
    │  TransactionDB* db_                   │
    │  string db_path_                      │
    │  bool isInitialized                   │
    │  mutex initSuccessMutex               │
    │                                       │
    │  + initDB() / sestoryDB()             │
    │  + isInitSuccess()                    │
    │  + getDBMemoryUsage()                 │
    └──────────────────────────────────────┘
```

---

**可信度说明**:
- 所有源码位置引用基于直接代码审查, 可信度: **高**
- 标记为【推测】或【需人工验证】的结论需要进一步确认
