# 13_threading -- 全线线程全景图

> MeMeChain 全节点线程模型索引。涵盖 HTTP / P2P / CA / EVM / 定时器 / UTXO / 交易池 / 同步等所有线程, 关键锁分析, 线程安全问题清单, 死锁风险评估。
>
> 上级目录: [../README.md](../README.md)

---

## 1. 全局线程清单

### 1.1 线程总览 (按模块)

| # | 线程名称 | 所属模块 | 类型 | 周期/触发 | 线程数 | 详细文档 |
|---|---------|---------|------|----------|--------|---------|
| N1 | EpollMode 主线程 | Network | detached | epoll_wait(1s) | 1 | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| N2 | HTTP Server 主线程 | RPC | detached | 请求驱动 | 1 | [../../module-rpc/thread_model.md](../../module-rpc/thread_model.md) |
| N3 | 读线程池 WorkRead | Network | detached | queueReader.tryWaitTop | 8 | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| N4 | 写线程池 WorkWrite | Network | detached | queue_write_counter.tryWaitTop | 8 | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| N5 | 工作线程池 Work | Network | detached | queue_work.tryWaitTop | 128 | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| N6 | 心跳定时器 DealHeart | Network | AsyncLoop | 60 秒 | 1 | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| N7 | refreshNodeListThread | Network | detached | 节点发现 | 1 | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| N8 | nodeSwitchThread | Network | detached | 100 秒 | 1 | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| C1 | VRF 共识线程 | Consensus | detached | 10 秒 | 1 | [../../module-dag-consensus/thread_model.md](../../module-dag-consensus/thread_model.md) |
| C2 | 区块同步线程 | Consensus | detached | 10 秒 | 1 | [../../module-dag-consensus/thread_model.md](../../module-dag-consensus/thread_model.md) |
| C3 | BlockPool 定时器 | Consensus | CTimer 回调 | 可配置 | 1 | [../../module-dag-consensus/thread_model.md](../../module-dag-consensus/thread_model.md) |
| C4 | SeekBlock 定时器 | Consensus | CTimer 回调 | 可配置 | 1 | [../../module-dag-consensus/thread_model.md](../../module-dag-consensus/thread_model.md) |
| C5 | BlockStorage 定时器 | Consensus | AsyncLoop | 100ms | 1 | [../../module-dag-consensus/thread_model.md](../../module-dag-consensus/thread_model.md) |
| C6 | CheckBlocks 定时器 | Consensus | AsyncLoop | 30 秒 | 1 | [../../module-dag-consensus/thread_model.md](../../module-dag-consensus/thread_model.md) |
| C7 | VRF Cache Cleanup | Consensus | AsyncLoop | 3 秒 | 1 | [../../module-dag-consensus/thread_model.md](../../module-dag-consensus/thread_model.md) |
| C8 | 数据库维护定时器 | Storage | AsyncLoop | 可配置 | 1 | [../../module-storage/thread_model.md](../../module-storage/thread_model.md) |
| T1 | TransactionCache 打包线程 | TxPool | detached | 3 秒/阈值 | 1 | [../../module-txpool/thread_model.md](../../module-txpool/thread_model.md) |
| T2 | CTimer _buildTimer | TxPool | 主线程事件循环 | 3 秒 | 1 | [../../module-txpool/thread_model.md](../../module-txpool/thread_model.md) |
| T3 | doubleSpendCache CheckLoop | TxPool | AsyncLoop | 1 秒 | 1 | [../../module-txpool/thread_model.md](../../module-txpool/thread_model.md) |
| T4 | failedTransactionCache 重试 | TxPool | AsyncLoop | 2 秒 | 1 | [../../module-txpool/thread_model.md](../../module-txpool/thread_model.md) |
| T5 | TimerProcessor 合约分发 | EVM | detached | 3 秒 | 1 | [../../module-evm/thread_model.md](../../module-evm/thread_model.md) |
| T6 | TaskPool 工作线程 | TxPool/EVM | 线程池 | 按需 | N (可配) | [../../module-txpool/thread_model.md](../../module-txpool/thread_model.md) |
| T7 | sendBlockByUtxoRequest | Consensus | detached, 一次性 | 按需 | 1 | [../../module-dag-consensus/thread_model.md](../../module-dag-consensus/thread_model.md) |
| R1 | HTTP 工作线程 | RPC | httplib | 请求驱动 | M (httplib) | [../../module-rpc/thread_model.md](../../module-rpc/thread_model.md) |

**总计**: 网络层 ~149 线程 + 共识层 ~7 线程 + 交易池 ~5+N 线程 + EVM ~1 线程 + HTTP ~M 线程 + DB 1 线程 = **约 163+N+M 线程**。

### 1.2 按系统层级分类

| 层级 | 线程数 | 关键线程 |
|------|--------|---------|
| 网络层 (Network) | ~149 | EpollMode, HTTP Server, 读/写/工作线程池, 心跳, 节点管理 |
| 共识层 (Consensus) | ~8 | VRF, Sync, BlockPool, SeekBlock, BlockStorage, CheckBlocks, CacheCleanup, DB |
| 交易层 (TxPool) | ~5+N | 打包, doubleSpend, failedTx, TimerProcessor, TaskPool |
| 接口层 (Interface) | M | HTTP 工作线程 (httplib 动态分配) |

---

## 2. 线程间通信架构

```
┌─────────────────────────────────────────────────────────────────┐
│                         Network Layer                           │
│                                                                 │
│  EpollMode(1) ──Push──► ReadPool(8) ──Push──► WorkPool(128)    │
│       │                      ▲                      │           │
│       │                      │                      ▼           │
│       └──── EPOLLOUT Push ──►│              Protobuf Dispatcher  │
│                              │                      │           │
│                     WritePool(8) ◄── Push ──────────┘           │
└──────────────────────────┬──────────────────────────────────────┘
                           │ HandleVRFConsensusInfoReq / HandleBlock...
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Consensus Layer                          │
│                                                                 │
│  VRFConsensusNode(10s) ──── TaskPool ───► vrfBroadcastMessage  │
│           │                                                        │
│           ├── extractPackagerVRFData ──► BlockStorage(100ms)     │
│           │                                    │                  │
│           │                                    ▼                  │
│  SyncBlock(10s) ──── AddSyncBlock ──► BlockPool(timer)           │
│           │                              │                         │
│           │                              ▼                         │
│  CheckBlocks(30s) ──── get_sync_node ──► SumHash Verification    │
└──────────────────────────┬──────────────────────────────────────┘
                           │ commitWorkTask / verifyTransaction
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Execution Layer                          │
│                                                                 │
│  TransactionCache(3s) ── BuildBlock ──► Block Broadcast          │
│  TimerProcessor(3s) ──► DependencyManager ──► Contract Txs       │
│  TaskPool Workers ──► verifyTransaction / executeContracts      │
│  EVM execute_by_evmone ── std::async(10s timeout)               │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. 关键锁清单

### 3.1 全局锁 (高风险: 定义在头文件中)

| 锁名称 | 类型 | 声明位置 | 保护对象 | 跨编译单元风险 |
|--------|------|---------|---------|--------------|
| `bonusMutex` | `std::mutex` | ca/global.h:29 | 奖励计算 | **Critical**: static 在头文件 |
| `kDelegatingMutex` | `std::mutex` | ca/global.h:30 | 委托操作 | **Critical**: static 在头文件 |
| `BURN_MUTEX` | `std::mutex` | ca/global.h:31 | Gas 销毁 | **Critical**: static 在头文件 |
| `LOCK_MUTEX` | `std::mutex` | ca/global.h:32 | 锁定/解锁 | **Critical**: static 在头文件 |

**P0-6**: 这些 static mutex 声明在头文件中，每个包含该头文件的 .cpp 文件生成独立实例 -- 可能无法互斥。

### 3.2 网络层锁

| 锁名称 | 类型 | 保护对象 | 线程安全 | 文档 |
|--------|------|---------|---------|------|
| queueReader MsgQueue | mutex + CV | 读队列 (容量 50000) | 安全 | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| queue_work MsgQueue | mutex + CV | 工作队列 (容量 50000) | 安全 | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| queue_write_counter MsgQueue | mutex + CV | 写队列 (容量 50000) | 安全 | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| mutexForNodes | shared_mutex | _nodeMap | 安全 (读写锁) | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| fdMutex (per-fd) | mutex | socket 写互斥 | 安全 | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| keyExchangeMap.mtx | shared_mutex | 密钥交换 Map | 安全 | [../../module-network/thread_model.md](../../module-network/thread_model.md) |

### 3.3 共识层锁

| 锁名称 | 类型 | 保护对象 | 线程安全 |
|--------|------|---------|---------|
| VRF mutex_ | shared_mutex | validatedVRfs / newValidatedVRfs | 安全 |
| helperMutex | mutex | BlockHelper::Process 互斥 | 安全 |
| seekMutex | mutex | _missingBlocks | 安全 |
| _blockMutex | shared_mutex | BlockStorage::_blockCnt | 安全 |
| syncThreadRunningMutex | mutex + CV | SyncBlock 生命周期 | 基本安全 |

### 3.4 交易池层锁

| 锁名称 | 类型 | 保护对象 | 线程安全 |
|--------|------|---------|---------|
| transactionCacheMutex | mutex | _transactionCache | 安全 (持锁时间长) |
| contractCacheMutex | mutex | _contractCache | 安全 |
| contractInfoCacheMutex | shared_mutex | contractInfoCache | **Bug: shared_lock 下 erase** |
| doubleSpendMutex | mutex | _pending | 安全 |
| txPendingMutex | shared_mutex | _txPending | 安全 |
| dep_mutex_ + msg_mutex_ | mutex x2 | DependencyManager | 安全 (scoped_lock 防死锁) |

### 3.5 EVM 层

| 组件 | 锁 | 线程安全 |
|------|-----|---------|
| EvmHost | **无锁** (public mutable, 设计为单线程) | 不安全 (当前单请求使用, 安全) |
| Trie (MPT) | **无锁** | 不安全 |
| contractDataContainer | shared_mutex | 安全 |
| execute_by_evmone | std::future (10s 超时) | **Bug: 超时后数据竞争** |

---

## 4. 线程安全问题清单

### 4.1 Critical 级别

| # | 问题 | 位置 | 影响 | 修复计划 |
|---|------|------|------|---------|
| P0-6 | _accountList 无锁保护 | account_manager.h:434 | 批量加载时数据竞争 | P0 1 人日 |
| P0-7 | shared_lock 下执行 erase() | transaction_cache.cpp:1356 | UB / 崩溃 | P0 1 人日 |
| P0-8 | DB 损坏直接 exit(-1) | rocksdb.cpp:18 | 无优雅关闭, WAL 未 flush | P0 1 人日 |
| C-006 | global.h static mutex 跨编译单元 | ca/global.h:29-32 | 锁可能不互斥 | P0 |

### 4.2 High 级别

| # | 问题 | 位置 | 影响 | 修复计划 |
|---|------|------|------|---------|
| P1-2 | EVM 超时后线程泄漏 | contract.cpp:94-103 | 僵尸线程累积 | P1 3 人日 |
| P1-8 | 失败交易重试时重新计算 hash | failed_transaction_cache.cpp:85-87 | 签名失效 | P1 1 人日 |
| P1-10 | 信号路径用 _exit() 不走析构 | utils/init.cpp | RocksDB WAL 可能未 flush | P1 1 人日 |
| -- | Nonce 无并发保护 | trans.cpp:256-263 | 同一地址并发交易 nonce 重复 | UTXO P1 |
| -- | execute_by_evmone 超时后数据竞争 | contract.cpp:89-103 | 恶意合约触发 | EVM P1 |

### 4.3 Medium 级别

| # | 问题 | 位置 | 影响 | 修复计划 |
|---|------|------|------|---------|
| P1-9 | Config 热加载无锁写文件 | config.cpp:647-660 | 并发写损坏配置文件 | P1 1 人日 |
| -- | processTransactionCacheFunc 长时间持锁 | transaction_cache.cpp:397-452 | RPC AddCache 阻塞 | 待优化 |
| -- | Trie 无并发保护 | mpt/trie.h:152-155 | 若多线程共享则数据竞争 | 当前安全 (单线程) |
| -- | 128 工作线程硬编码 | work_thread.cpp:32 | 低配机器上下文切换多 | 待配置化 |
| -- | fileDescriptorSetMutex 未清理 | socket_buf.cpp:8-23 | 长期运行内存泄漏 | 待修复 |

---

## 5. 死锁风险评估

### 5.1 已知锁依赖链

```
RPC 线程 (AddCache):
  contractCacheMutex -> doubleSpendMutex
  transactionCacheMutex -> doubleSpendMutex

打包线程 (processTransactionCacheFunc):
  transactionCacheMutex (长时间持有)

ProcessContract:
  contractCacheMutex -> contractInfoCacheMutex -> dirtyContractMapMutex

DependencyManager:
  scoped_lock(dep_mutex_, msg_mutex_)  -- 同时锁定两个, 安全

治理/激励 (潜在风险):
  Bonus: bonusMutex -> kDelegatingMutex
  Delegating: kDelegatingMutex -> bonusMutex (?)
```

### 5.2 风险评估

| 锁对 | 风险 | 说明 |
|------|------|------|
| transactionCacheMutex / contractCacheMutex | **低** | 顺序一致, 无循环依赖 |
| bonusMutex / kDelegatingMutex | **中 (待验证)** | 两条路径可能顺序相反 |
| Lock / Unlock (LOCK_MUTEX) | **低** | 独立全局锁, 无交叉 |
| doubleSpendMutex | **低** | 仅在 RPC 线程获取 |

**总体结论**: 当前没有发现确定的死锁循环。主要风险是 `bonusMutex` 和 `kDelegatingMutex` 之间的获取顺序不一致 (需人工验证)，以及 `global.h` 中 static mutex 的跨编译单元问题。

---

## 6. 定时器配置汇总

| 定时器 | 模块 | 周期 | 类型 | 回调 |
|--------|------|------|------|------|
| VRF Consensus | Consensus | 10 秒 (对齐) | detached thread | VRFConsensusNode::run() |
| Block Sync | Consensus | 10 秒 (CV) | detached thread | SyncBlock::ThreadStart() |
| Block Pool Timer | Consensus | 可配置 | CTimer | BlockHelper::Process() |
| Seek Block Timer | Consensus | 可配置 | CTimer | SeekBlockThreadObject() |
| Block Storage Timer | Consensus | 100ms | AsyncLoop | BlockStorage::_BlockCheck() |
| Check Blocks Timer | Consensus | 30 秒 | AsyncLoop | CheckBlocks::_ToCheck() |
| VRF Cache Cleanup | Consensus | 3 秒 | AsyncLoop | VRF::ClearTimer |
| Database Timer | Storage | 可配置 | AsyncLoop | DB Maintenance |
| Transaction Build | TxPool | 3 秒 | CTimer | _buildTimer notify |
| Double Spend Check | TxPool | 1 秒 | AsyncLoop | CheckLoop() |
| Failed Tx Retry | TxPool | 2 秒 | AsyncLoop | _Check() |
| Contract Dispatch | EVM | 3 秒 | detached thread | ProcessingFunc() |
| Heartbeat | Network | 60 秒 | AsyncLoop | DealHeart() |
| ContractTransactionCache | EVM | 1 秒 | **已注释** | _CheckCachedTransactions() |

---

## 7. 文档索引

### 7.1 各模块线程文档

| 模块 | 线程模型文件 |
|------|-------------|
| UTXO | [../../module-utxo/thread_model.md](../../module-utxo/thread_model.md) |
| Crypto | [../../module-crypto/thread_model.md](../../module-crypto/thread_model.md) |
| DAG Consensus | [../../module-dag-consensus/thread_model.md](../../module-dag-consensus/thread_model.md) |
| Governance/Incentive | [../../module-governance-incentive/thread_model.md](../../module-governance-incentive/thread_model.md) |
| EVM | [../../module-evm/thread_model.md](../../module-evm/thread_model.md) |
| Network | [../../module-network/thread_model.md](../../module-network/thread_model.md) |
| TxPool | [../../module-txpool/thread_model.md](../../module-txpool/thread_model.md) |
| RPC | [../../module-rpc/thread_model.md](../../module-rpc/thread_model.md) |
| Storage | [../../module-storage/thread_model.md](../../module-storage/thread_model.md) |

### 7.2 相关文档

| 文档 | 路径 |
|------|------|
| 重构总体规划 | [../../refactor_master_plan.md](../../refactor_master_plan.md) |
| 本阶段共识 | [../12_consensus/README.md](../12_consensus/README.md) |
| 本阶段合约 | [../10_contract/README.md](../10_contract/README.md) |
| 本阶段密码学 | [../11_crypto/README.md](../11_crypto/README.md) |
| 本阶段状态机 | [../14_state_machine/README.md](../14_state_machine/README.md) |

---

*本文档基于阶段 2 全部模块的 thread_model.md 文件综合编写。线程数 / 周期值为基于源码分析的确切值，标注 "【需人工验证】" 处需进一步确认。*
