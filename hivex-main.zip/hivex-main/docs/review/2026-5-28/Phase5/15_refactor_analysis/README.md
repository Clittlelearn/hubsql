# 15 -- 重构分析汇总

> **阶段**: 阶段5 -- 文档重组
> **目录**: `15_refactor_analysis/`
> **用途**: 汇总所有模块的重构建议、P0-P3 问题分布与预估工时

---

## 一、文档索引

### 总规划

| 文档 | 路径 | 说明 |
|------|------|------|
| 重构总体规划 | [../../refactor_master_plan.md](../../refactor_master_plan.md) | 阶段4输出：P0-P3完整清单、目录重组方案、Namespace规范、接口抽象、Strangler Fig实施策略 |

### 各模块重构建议 (10 个模块)

| 模块 | 路径 | 核心问题数 |
|------|------|-----------|
| 模块1 - 密码学 | [../../module-crypto/refactor_suggestion.md](../../module-crypto/refactor_suggestion.md) | 双曲线并存(P0)、AccountManager职责过重(P1) |
| 模块2 - 存储层 | [../../module-storage/refactor_suggestion.md](../../module-storage/refactor_suggestion.md) | db_api.h巨型头文件(2694行)、接口跨12数据域 |
| 模块3 - UTXO | [../../module-utxo/refactor_suggestion.md](../../module-utxo/refactor_suggestion.md) | transaction.cpp/txhelper.cpp拆分、FindUtxo死代码 |
| 模块4 - DAG共识 | [../../module-dag-consensus/refactor_suggestion.md](../../module-dag-consensus/refactor_suggestion.md) | algorithm.cpp 382KB拆分、回滚逻辑分散、双VRF实现 |
| 模块5 - EVM集成 | [../../module-evm/refactor_suggestion.md](../../module-evm/refactor_suggestion.md) | EvmHost职责过重、超时线程泄漏、message.gas无限制 |
| 模块6 - 网络层 | [../../module-network/refactor_suggestion.md](../../module-network/refactor_suggestion.md) | 消息队列并发安全、epoll异常恢复、广播策略硬编码 |
| 模块7 - 交易池 | [../../module-txpool/refactor_suggestion.md](../../module-txpool/refactor_suggestion.md) | 无容量限制/超时淘汰(P0)、shared_lock下erase(P0) |
| 模块8-9 - 治理激励 | [../../module-governance-incentive/refactor_suggestion.md](../../module-governance-incentive/refactor_suggestion.md) | 年化率取整错误(P0)、治理逻辑混入algorithm.cpp |
| 模块10 - RPC服务 | [../../module-rpc/refactor_suggestion.md](../../module-rpc/refactor_suggestion.md) | 参数校验安全漏洞(P0)、http_api.cpp 223KB、ETH精度问题 |
| 模块11 - 特殊功能 | [../../module-special/refactor_suggestion.md](../../module-special/refactor_suggestion.md) | advanced_menu.cpp 141KB CLI与业务耦合 |

---

## 二、P0-P3 问题分布统计

### 按优先级汇总

| 优先级 | 问题数 | 工时(人日) | 人周 | 说明 |
|--------|--------|-----------|------|------|
| **P0 (Critical)** | 9 | 22.5 | 4.5 周 | 安全性/共识修复。必须立即修复。 |
| **P1 (High)** | 10 | 19.0 | 3.8 周 | Bug修复/并发安全。本迭代修复。 |
| **P2 (Medium)** | 11 | 35.0 | 7.0 周 | 代码结构优化。下迭代修复。 |
| **P3 (Low)** | 11 | 23.0 | 4.6 周 | 性能/风格优化。按需修复。 |
| **合计** | **41** | **99.5 人日** | **~20 周** | **约 5 个月 (单人)** |

### P0 Critical 问题清单 (9项)

| # | 问题 | 风险 | 工时 |
|---|------|------|------|
| P0-1 | MPT SHA256 与以太坊 Keccak256 不兼容 | 跨链验证不可行 | 3人日 |
| P0-2 | 回滚无原子 UTXO 恢复 (两条路径) | 可能导致双花 | 1周 |
| P0-3 | 区块签名不验证打包节点资格 | 非VRF节点可签名 | 3人日 |
| P0-4 | 年化率取整导致 ~5.8% 超额支付 | 代币经济破坏 | 1人日 |
| P0-5 | 交易池无容量限制/超时淘汰 | DoS可OOM | 3人日 |
| P0-6 | `_accountList` 无锁保护 | 多线程数据竞争 | 1人日 |
| P0-7 | `shared_lock` 下执行 `erase()` | UB/崩溃 | 1人日 |
| P0-8 | DB损坏直接 `exit(-1)` | 无优雅关闭 | 1人日 |
| P0-9 | 主链选择用75百分位而非共识权重 | 分叉选择不一致 | 1周 |

### P1 High 问题清单 (10项)

| # | 问题 | 工时 |
|---|------|------|
| P1-1 | 签名平均数整数除法错误 | 1人日 |
| P1-2 | EVM超时后线程泄漏 | 3人日 |
| P1-3 | `message.gas`=用户全部VOTE余额 | 3人日 |
| P1-4 | UnStake `checkParams()` 空函数体UB | 1人日 |
| P1-5 | FindUtxo 死代码致锁定期逻辑失效 | 3人日 |
| P1-6 | EIP-1559 使用 double 浮点 | 1人日 |
| P1-7 | 块签名阈值混乱(51/66/80/90%) | 3人日 |
| P1-8 | 失败交易重试时重新计算hash | 1人日 |
| P1-9 | Config 热加载无锁写文件 | 1人日 |
| P1-10 | 信号路径用 `_exit()` 不走析构 | 1人日 |

### P2 Medium 问题清单 (11项)

| # | 问题 | 工时 |
|---|------|------|
| P2-1 | 拆分 algorithm.cpp (382KB) 为13子模块 | 1周 |
| P2-2 | 拆分 http_api.cpp (223KB) 为8路由文件 | 3人日 |
| P2-3 | 拆分 txhelper.cpp (138KB) | 1周 |
| P2-4 | 拆分 sync_block.cpp (132KB) | 1周 |
| P2-5 | 拆分 transaction.cpp (128KB) | 1周 |
| P2-6 | 拆分 advanced_menu.cpp (141KB) | 3人日 |
| P2-7 | 拆分 db_api.h (81KB) 为10子接口 | 3人日 |
| P2-8 | 清理 contract.cpp `#if 0` 代码 | 1人日 |
| P2-9 | 清理 ContractTransactionCache 废弃代码 | 1人日 |
| P2-10 | 统一 Key 前缀命名 (41项偏差) | 3人日 |
| P2-11 | 统一共识阈值 (51/66/75/80/90) | 3人日 |

### P3 Low 问题清单 (11项)

| # | 问题 | 工时 |
|---|------|------|
| P3-1 | P-256/secp256k1 双曲线统一 | 3人日 |
| P3-2 | ETH 接口补全 (eth_getLogs/eth_getStorageAt) | 3人日 |
| P3-3 | RPC 参数校验补全 (多数checkParams为空) | 3人日 |
| P3-4 | RPC GET/POST 命名规范统一 | 1人日 |
| P3-5 | 拼写错误修正 | 1人日 |
| P3-6 | 添加 RPC 限流机制 | 3人日 |
| P3-7 | 广播策略可配置化 | 1人日 |
| P3-8 | Node 结构命名规范化 | 1人日 |
| P3-9 | 统一 3 种错误输出体系 | 3人日 |
| P3-10 | 添加请求级别的超时控制 | 1人日 |
| P3-11 | cpp_bin_float 替换 double 浮点计算 | 3人日 |

---

## 三、按模块预估工时汇总

| 模块 | P0 | P1 | P2 | P3 | 合计 |
|------|-----|-----|-----|-----|------|
| core/consensus | 1W+3d | 3d+3d | 1W+3d | -- | ~4W |
| core/block | 1W | -- | 1W | -- | ~2W |
| core/sync | -- | -- | 1W | -- | ~1W |
| core/txpool | 3d | -- | -- | -- | ~3d |
| core/utxo | -- | 3d | 1W | -- | ~2W |
| core/governance | 1d | -- | -- | -- | ~1d |
| execution/evm | -- | 3d+3d | -- | -- | ~6d |
| execution/mpt | 3d | -- | -- | -- | ~3d |
| execution/gas | -- | 1d | -- | 3d | ~4d |
| crypto | 1d | -- | -- | 3d | ~4d |
| infra/store | 1d | -- | 3d | 1d | ~5d |
| infra/net | -- | -- | -- | 1d+1d | ~2d |
| infra/config | -- | 1d | -- | -- | ~1d |
| interface/rpc | -- | -- | 3d | 3d+3d+1d | ~10d |
| interface/eth | -- | -- | -- | 3d | ~3d |
| app/cli | -- | -- | 3d | -- | ~3d |
| app/init | -- | 1d+1d | -- | -- | ~2d |

---

## 四、推荐实施路线图

```
第1-2周:   行为锁定测试编写 + P0 修复开始
第3-6周:   P0 修复完成 + P1 修复开始
第7-10周:  P1 修复完成 + P2 巨型文件拆分开始
第11-14周: P2 拆分继续 + 目录重组
第15-18周: P2 完成 + 接口抽象层引入
第19-20周: P3 优化 + 文档更新

关键里程碑:
  Week 2:  行为测试覆盖率达 40%
  Week 4:  P0 全部修复, 共识安全达标
  Week 8:  P1 全部修复, 无已知Bug
  Week 14: 无超过 2000 行的文件
  Week 18: MagicSingleton 减少到 5 个以内
  Week 20: 综合架构健康度 >= 7/10
```

---

## 五、Strangler Fig 实施策略

```
阶段 A (低风险): mpt/ contract/ silkpre/ errorn/
  → 4个小模块，依赖少，可独立重构

阶段 B (中风险): db/ net/ utils/ common/
  → 基础设施层，被广泛依赖，需接口兼容

阶段 C (中风险): rpc/ api/ ca/evm/
  → 接口层+执行层，可逐步迁移到新接口

阶段 D (高风险): ca/ core/
  → 核心共识+交易处理，需完整行为测试覆盖后操作
```

---

## 六、相关文档速查

| 需求 | 查阅文档 |
|------|---------|
| 全局架构 | [../01_architecture/README.md](../01_architecture/README.md) |
| 风险全景图 | [../16_risk_analysis/README.md](../16_risk_analysis/README.md) |
| API参考 | [../17_api_reference/README.md](../17_api_reference/README.md) |
| 序列图 | [../18_sequence_diagrams/README.md](../18_sequence_diagrams/README.md) |
| 各模块详情 | [../../module-crypto/](../../module-crypto/) 等10个 module-* 目录 |

---

*文档生成日期：2026-05-26*
*数据来源：阶段1-4 共 94 份分析文档*
