# 06 -- Network / P2P 网络层

> **阶段 5 重组索引** | 关联目录: `../../module-network/`, `../../03_core_flows/flow-02-block-sync/`
> **上游**: [05_block_flow](../05_block_flow/) | **下游**: [07_storage](../07_storage/)

---

## 1. 概览

MeMeChain 网络层采用自研 C++20 P2P 协议栈，架构分为三层: 底层 epoll 事件循环, 中层消息队列与打包, 上层节点管理与协议分发。通信加密基于 ECDH + AES-256-GCM。

**核心特性**: epoll ET 边缘触发 + 128 工作线程 + 三队列读写分离 + Protobuf 序列化 + ECDH P-256 密钥交换。

---

## 2. 三层架构

```
                            上层: 业务协议层
┌─────────────────────────────────────────────────────┐
│  PeerNode Manager         ProtobufDispatcher          │
│  (节点发现/连接管理/心跳)   (消息路由/回调注册)         │
│  UnregisterNode            广播策略                    │
│  (节点注销管理)             (Cycliclist 环形传播)       │
├─────────────────────────────────────────────────────┤
                            中层: 消息处理层
│  WorkThreads ×128          MsgQueue ×3                │
│  (读写工作线程池)           (队列读取/工作/写入分离)      │
│  Pack / Compress           消息打包/压缩               │
├─────────────────────────────────────────────────────┤
                            底层: 传输层
│  EpollMode (ET)            SocketBuf (双缓冲)          │
│  KeyExchangeManager        net_tcp (TCP 封装)          │
│  (ECDH + AES-256-GCM)      (Socket/Accept/Connect)     │
└─────────────────────────────────────────────────────┘
```

**数据流向**:
- **收**: epoll EPOLLIN -> queueReader -> handle_net_read -> SocketBuf 粘包处理 -> queue_work -> ProtobufDispatcher::Handle (解密/解压/反序列化/分发)
- **发**: SendMessage 模板 -> queue_write_counter -> handle_net_write -> TCP发送

---

## 3. 节点管理

### 3.1 节点注册与发现

| 阶段 | 消息 | 处理函数 | 关键逻辑 |
|------|------|---------|---------|
| 注册请求 | `RegisterNodeReq` | `handleRegisterNodeRequest` (handle_event.cpp:58) | 检查同IP重复注册 / 内网过滤 / ECDSA地址验证 / 版本兼容 |
| 注册响应 | `RegisterNodeAck` | `handleRegisterNodeAcknowledgment` | 返回自身节点信息 + 可选节点列表 |
| 同步请求 | `SyncNodeReq` | `handleSyncNodeRequest` | 请求同步节点列表 |
| 同步响应 | `SyncNodeAck` | `handleSyncNodeAcknowledgment` | 返回已知节点列表 |

### 3.2 心跳机制

| 参数 | 值 | 定义 |
|------|-----|------|
| HEARTBEAT_INTERVAL | 60s | `net/define.h:13` |
| HEARTBEAT_CHECKS | 3 | `net/define.h:14` (180s 超时) |
| 初始 pulse | 3 | `net/node.hpp:34` |

**流程**: `AsyncLoop(60s, DealHeart)` -> pulse-- -> pulse<=0 则删除 -> 否则发 PingReq。收到 Ping/Pong 时 `ResetHeart()` 重置 pulse=3。

### 3.3 连接状态机

```
NOTYET(0) -> dataRateToOutput(1, 主动连接) / PASSIV(2, 被动连接)
  -> ECDH 密钥交换 -> 已加密 -> 已注册 -> 活跃(pulse>0)
  -> pulse<=0 或 fd<=0 -> 断开 -> DeleteNode (epoll/fd/buffer/map 清理)
```

---

## 4. 消息格式

### 4.1 在线格式 (NetPack)

| 字段 | 长度 | 说明 |
|------|------|------|
| len | 4B | 数据长度 |
| data | N bytes | Protobuf 序列化的 CommonMsg |
| checkSum | 4B | 校验和 |
| flag | 4B | 优先级(0-15) 和加密/压缩标志 |
| endFlag | 4B | 结束标记 (7777777) |

### 4.2 CommonMsg 包装 (protobuf)

| 字段 | 类型 | 说明 |
|------|------|------|
| version | string | 协议版本 ("0.0") |
| type | uint32 | 消息类型枚举 |
| encrypt | uint32 | 加密标志 |
| compress | uint32 | 压缩标志 |
| data | bytes | 实际业务消息 (Protobuf) |

消息类型定义在 `proto/ca_protomsg.proto`, `proto/net.proto`, `proto/sync_block.proto` 等。

---

## 5. 同步模式 (网络视角)

| 模式 | 关键消息 | 说明 |
|------|---------|------|
| **FastSync** | `FastSyncGetHashRequest/Ack`, `FastSyncGetBlockRequest/Ack` | 获取hash列表 -> 下载差异块, 66% 拜占庭检查 |
| **NewSync** | `chainSyncGetBlockHeightAndHashRequest/Ack`, `sendSyncGetBlockRequest/Ack` | SumHash验证 51%共识 -> 差异区块下载 |
| **FromZero** | `SyncFromZeroGetSumHashRequest/Ack`, `sendSyncGetBlockRequest` | 千区块 SumHash -> 逐批下载 |
| **Broadcast** | `BuildBlockBroadcastMsg` | 环形邻居算法传播新区块 |

> 具体同步逻辑参见 [区块同步流程](../../03_core_flows/flow-02-block-sync/), 网络仅负责消息传输。

---

## 6. ECDH 密钥交换

| 参数 | 值 | 定义 |
|------|-----|------|
| 椭圆曲线 | NIST P-256 (secp256r1) | `utils/crypto.h:10` |
| 公钥长度 | 65B 未压缩 | `utils/crypto.h:13` |
| 私钥长度 | 32B | `utils/crypto.h:14` |
| Salt 长度 | 32B | `utils/crypto.h:15` |
| KDF | HKDF-SHA256, info="ENCRYPTION" | `utils/crypto.h:27` |
| 对称加密 | AES-256-GCM | `net/key_exchange.cpp` |
| IV 长度 | 12B | `utils/crypto.h:19` |
| Auth Tag | 16B | `utils/crypto.h:20` |

**流程**: 发起方生成ECDH密钥 -> 发送公钥+Salt -> 对端生成密钥 -> 返回公钥+Salt -> 双方 derive 共享密钥 (HKDF) -> AES-256-GCM 加密通信。

**额外安全**: Token 机制 (HMAC-SHA256(salt, ecdh_pub_key) 取前3字节) 用于消息认证。

---

## 7. 广播策略

| 场景 | 策略 | 阈值 |
|------|------|------|
| 未连接节点比例过高 | 拒绝广播 | >25% |
| 高度 < MIN_UNSTAKE_HEIGHT | 随机选 broadcast_threshold=15 个节点 | 包含非质押节点 |
| 高度 >= MIN_UNSTAKE_HEIGHT | 仅广播给质押合格节点 | 通过 `getStakeUtxoByAddr` 验证 |
| 大网络优化 | sqrt(nodeList) 数量节点 | nodeList >= broadcast_threshold^2 |

---

## 8. 关键常量

| 常量 | 值 | 定义位置 |
|------|-----|---------|
| MAXEPOLLSIZE | 100000 | `define.h:10` |
| MAXLINE | 10240 | `define.h:11` |
| END_FLAG | 7777777 | `define.h:7` |
| 工作线程数 | 128 | `work_thread.cpp:32` |
| 读线程数 | 8 | `work_thread.cpp:43` |
| 写线程数 | 8 | `work_thread.cpp:49` |
| 消息队列容量 | 50000 | `msg_queue.h:140` |
| broadcast_threshold | 15 | `global.cpp:23` |
| node_list_refresh_time | 100s | `global.cpp:7` |

---

## 9. 风险提示

| 风险 | 位置 | 等级 |
|------|------|------|
| NetPack 在线格式与规范定义不一致 (多了 len/checkSum/endFlag) | `define.h:34-41` | 中 |
| 无速率限制 / 无 RPC 鉴权 | `http_server.cpp` | 高 |
| CORS 全局开放所有来源 | `http_server.cpp:12` | 中 |
| 密钥交换 5s 超时未与业务超时协调 | `key_exchange.cpp` | 低 |

---

## 10. 相关文档

### 阶段 2 -- 模块分析
| 文档 | 路径 |
|------|------|
| 网络模块总览 | `../../module-network/module_overview.md` |
| 网络类分析 | `../../module-network/class_analysis.md` |
| 网络调用链 | `../../module-network/call_chain.md` |
| 网络状态流(连接/密钥交换) | `../../module-network/state_flow.md` |
| 网络存储模型 | `../../module-network/storage_model.md` |
| 网络线程模型 | `../../module-network/thread_model.md` |
| 网络重构建议 | `../../module-network/refactor_suggestion.md` |

### 阶段 3 -- 流程分析
| 文档 | 路径 |
|------|------|
| 区块同步时序(网络消息) | `../../03_core_flows/flow-02-block-sync/sequence_flow.md` |
| 区块同步调用栈 | `../../03_core_flows/flow-02-block-sync/call_stack.md` |

### 阶段 1 -- 全局架构
| 文档 | 路径 |
|------|------|
| 架构总览 (网络层目录结构) | `../../architecture_overview.md` |
| 模块依赖 (net 模块依赖矩阵) | `../../module_dependency.md` |
| 启动流程 (NetInit 初始化) | `../../startup_flow.md` |

### 阶段 4 -- 重构规划
| 文档 | 路径 |
|------|------|
| 重构总体规划 (网络安全相关) | `../../refactor_master_plan.md` |
