# 14_state_machine -- 全局状态机索引

> MeMeChain 全系统状态机汇总索引。涵盖交易 / 区块 / UTXO / 合约 / 治理 / 节点 / 同步 / 密钥 / 质押 / 委托 / 投票等所有状态机。
>
> 上级目录: [../README.md](../README.md)

---

## 1. 状态机总览

MeMeChain 系统包含 **16 个主要状态机**，分布于 5 个层级:

| 层级 | 状态机数量 | 关键状态机 |
|------|-----------|-----------|
| 密码学层 (Crypto) | 4 | 账户生命周期 / 密钥状态 / 地址验证 / EVP_PKEY |
| 网络层 (Network) | 3 | TCP 连接 / 密钥交换 / 节点连接 |
| 共识层 (Consensus) | 4 | VRF 共识 / 区块验证 / 同步 / 分叉解决 |
| 数据层 (Data) | 3 | UTXO / 交易全局 / 合约交易 |
| 治理层 (Governance) | 2 | 提案 / 投票 / 奖励 / 质押 / 委托 |

---

## 2. 状态机索引 (按编号)

### S1: 账户生命周期状态机

| 属性 | 内容 |
|------|------|
| 编号 | S1 |
| 所属模块 | Crypto (module-crypto) |
| 状态数 | 5 (未初始化 / 创建中 / 已创建 / 已锁定 / 已删除) |
| 持久化 | Keystore JSON 文件 |
| 入口 | `AccountManager::Initialize()` |
| 详档 | [../../module-crypto/state_flow.md](../../module-crypto/state_flow.md) |
| 阶段 3 | -- |

**状态转换汇总**:

| 源状态 | 目标状态 | 触发条件 |
|--------|---------|---------|
| 未初始化 | 创建中 | Initialize() 返回 EMPTY_KEYSTORE |
| 未初始化 | 加载中 | Keystore 目录有 .json 文件 |
| 创建中 | 已创建 | scrypt 加密 + 写入文件 + AddAccount |
| 加载中 | 已创建 | 密码解锁成功 |
| 已创建 | 已锁定 | 节点关闭, 私钥释放 |
| 已锁定 | 已创建 | 节点重启 + 密码解锁 |
| 已创建 | 已删除 | DeleteAccount() |

### S2: 密钥状态机

| 属性 | 内容 |
|------|------|
| 编号 | S2 |
| 所属模块 | Crypto (module-crypto) |
| 状态数 | 5 (未生成 / 明文内存 / DER 编码 / 加密磁盘 / 已释放) |
| 持久化 | Keystore JSON (加密磁盘) |
| 入口 | `Account(true)` / `generatePkey()` |
| 详档 | [../../module-crypto/state_flow.md](../../module-crypto/state_flow.md) |

**状态转换**:

| 源状态 | 目标状态 | 触发 |
|--------|---------|------|
| 未生成 | 明文内存 | EVP_PKEY_keygen 成功 |
| 明文内存 | DER 编码 | generatePublicString() |
| 明文内存 | 加密磁盘 | SavePrivateKeyToKeystoreFile() |
| 加密磁盘 | 明文内存 | load_account_from_key_store() 密码正确 |
| 明文内存 | 已释放 | Account 析构 / EVP_PKEY_free |

### S3: 地址验证状态机

| 属性 | 内容 |
|------|------|
| 编号 | S3 |
| 所属模块 | Crypto (module-crypto) |
| 状态数 | 2 (未验证 / 已验证) |
| 缓存 | VerifiedAddress 运行时缓存 (重启丢失) |
| 详档 | [../../module-crypto/state_flow.md](../../module-crypto/state_flow.md) |

### S4: EVP_PKEY 内部状态 (OpenSSL)

| 属性 | 内容 |
|------|------|
| 编号 | S4 |
| 所属模块 | Crypto (module-crypto) |
| 状态 | NULL / 仅有参数 / 有密钥对 / 仅有私钥 / 仅有公钥 / 已释放 |
| 详档 | [../../module-crypto/state_flow.md](../../module-crypto/state_flow.md) |

---

### S5: TCP 连接状态机

| 属性 | 内容 |
|------|------|
| 编号 | S5 |
| 所属模块 | Network (module-network) |
| 状态数 | 7 (socket / connect / listen / ecdh / encrypted / registered / closed) |
| 详档 | [../../module-network/state_flow.md](../../module-network/state_flow.md) |

**状态转换**:

| 源 | 目标 | 触发 |
|----|------|------|
| socket | connect | 主动连接 InitConnection |
| socket | listen | 被动监听 initialize_listen_server |
| connect | ecdh_exchange | EPOLLOUT 成功 |
| listen | ecdh_exchange | accept + AddBuffer |
| ecdh_exchange | encrypted | ECDH 密钥交换完成 |
| encrypted | registered | RegisterNodeReq/Ack |
| registered | active_heartbeat | pulse=3, DealHeart 启动 |
| active_heartbeat | closed | pulse <= 0 (3 次超时) |

### S6: ECDH 密钥交换状态机

| 属性 | 内容 |
|------|------|
| 编号 | S6 |
| 所属模块 | Network (module-network) |
| 状态 | 未交换 / 请求已发送 / 请求已收到 / 已交换 / 加密通道就绪 |
| 详档 | [../../module-network/state_flow.md](../../module-network/state_flow.md) |

### S7: 节点连接状态机 (ConnKind)

| 属性 | 内容 |
|------|------|
| 编号 | S7 |
| 所属模块 | Network (module-network) |
| 状态 | NOTYET(0) / dataRateToOutput(1) / PASSIV(2) |
| 详档 | [../../module-network/state_flow.md](../../module-network/state_flow.md) |

---

### S8: VRF 共识状态机

| 属性 | 内容 |
|------|------|
| 编号 | S8 |
| 所属模块 | Consensus (module-dag-consensus) |
| 周期 | 10 秒 |
| 状态数 | 8 (WaitForCycle / SeedGeneration / Signing / Broadcasting / Receiving / FrequencyCompute / PackagerSelect / BlockPackaging) |
| 详档 | [../../module-dag-consensus/state_flow.md](../../module-dag-consensus/state_flow.md) |

### S9: 区块验证状态机

| 属性 | 内容 |
|------|------|
| 编号 | S9 |
| 所属模块 | Consensus (module-dag-consensus) |
| 状态数 | 12 (Receive / VerifyPreHash / MemVerify / FullVerify / TxVerify / ContractVerify / PreSaveVerify / SaveDB / Commit / MainChain / ForkCandidate / Rollback) |
| 详档 | [../../module-dag-consensus/state_flow.md](../../module-dag-consensus/state_flow.md) |

### S10: 区块状态跟踪 (BlockStatus)

| 属性 | 内容 |
|------|------|
| 编号 | S10 |
| 所属模块 | Consensus (module-dag-consensus) |
| 状态 | Received / Flowing / CollectingSignatures / SignaturesComplete / BroadcastBuilt / Verified / Persisted / Confirmed / RolledBack |
| 详档 | [../../module-dag-consensus/state_flow.md](../../module-dag-consensus/state_flow.md) |

### S11: 同步状态机

| 属性 | 内容 |
|------|------|
| 编号 | S11 |
| 所属模块 | Consensus (module-dag-consensus) |
| 模式 | SyncNormal / SyncFast / SyncFromZero |
| 详档 | [../../module-dag-consensus/state_flow.md](../../module-dag-consensus/state_flow.md) |
| 阶段 3 | [../../03_core_flows/flow-02-block-sync/state_transition.md](../../03_core_flows/flow-02-block-sync/state_transition.md) |

### S12: 分叉解决状态机

| 属性 | 内容 |
|------|------|
| 编号 | S12 |
| 所属模块 | Consensus (module-dag-consensus) |
| 周期 | 10 秒检测 |
| 状态 | Idle / Triggered / QueryNodes / BuildConsensusMap / RollbackDecision / ExecuteRollback / ApplyNewChain |
| 详档 | [../../module-dag-consensus/state_flow.md](../../module-dag-consensus/state_flow.md) |

---

### S13: UTXO 状态机

| 属性 | 内容 |
|------|------|
| 编号 | S13 |
| 所属模块 | UTXO (module-utxo) |
| 状态数 | 8 (未创建 / 未确认 / 已确认可用 / 已花费 / 已锁定 / 已质押 / 已委托 / 作废) |
| 持久化 | RocksDB (UB: / UAH: / BAL: 前缀) |
| 详档 | [../../module-utxo/state_flow.md](../../module-utxo/state_flow.md) |

**UTXO 状态转换汇总**:

| 源状态 | 目标状态 | 触发条件 | 可回滚 |
|--------|---------|---------|--------|
| -- (未创建) | 未确认 | 交易构造完成 (vout 生成) | N/A |
| 未确认 | 已确认可用 | 区块确认 (写入 RocksDB) | 是 |
| 未确认 | 作废 | 交易超时 / 验证失败 | 否 |
| 已确认可用 | 已花费 | 新交易 vin 引用 | 是 (回滚恢复) |
| 已确认可用 | 已锁定 | LOCK 交易 | 是 (UNLOCK) |
| 已确认可用 | 已质押 | STAKE 交易 | 是 (UNSTAKE, 等 500 块) |
| 已确认可用 | 已委托 | DELEGATE 交易 | 是 (UNDELEGATE) |
| 已锁定 | 已确认可用 | UNLOCK 交易 | 否 |
| 已质押 | 已确认可用 | UNSTAKE 交易 (需 500 块) | 否 |
| 已委托 | 已确认可用 | UNDELEGATE 交易 | 否 |
| 已花费 | 已确认可用 | 区块回滚 | 是 |

### S14: 交易全局状态机

| 属性 | 内容 |
|------|------|
| 编号 | S14 |
| 所属模块 | UTXO / TxPool (module-utxo / module-txpool) |
| 状态数 | 13 (创建 / 参数校验 / UTXO选择 / Vin填充 / Vout填充 / 元信息 / 已构造 / 已签名 / 已广播 / 验证中 / 已加入缓存 / 已打包 / 已确认) |
| 详档 | [../../module-utxo/state_flow.md](../../module-utxo/state_flow.md) |
| 阶段 3 | [../../03_core_flows/flow-01-tx-lifecycle/state_transition.md](../../03_core_flows/flow-01-tx-lifecycle/state_transition.md) |

### S15: 交易在 TransactionCache 中的状态

| 属性 | 内容 |
|------|------|
| 编号 | S15 |
| 所属模块 | TxPool (module-txpool) |
| 状态 | Cached / Pending / Building / Built / Cleared / Retry |
| 详档 | [../../module-txpool/state_flow.md](../../module-txpool/state_flow.md) |

### S16: 合约交易状态机

| 属性 | 内容 |
|------|------|
| 编号 | S16 |
| 所属模块 | TxPool / EVM (module-txpool / module-evm) |
| 状态 | Cached / Processing / PreHashSeek / PreHashVerified / Building / Confirmed / Failed |
| 详档 | [../../module-txpool/state_flow.md](../../module-txpool/state_flow.md) |

---

### S17-S20: 治理与激励状态机

| 编号 | 状态机 | 所属模块 | 详档 |
|------|--------|---------|------|
| S17 | 提案状态机 | Governance | [../../module-governance-incentive/state_flow.md](../../module-governance-incentive/state_flow.md) |
| S18 | 锁定/投票状态机 | Governance | [../../module-governance-incentive/state_flow.md](../../module-governance-incentive/state_flow.md) |
| S19 | 奖励状态机 | Incentive | [../../module-governance-incentive/state_flow.md](../../module-governance-incentive/state_flow.md) |
| S20 | 质押/委托状态机 | Governance/Incentive | [../../module-txpool/state_flow.md](../../module-txpool/state_flow.md) |

#### S17: 提案状态机

| 状态 | 判定条件 |
|------|---------|
| 已创建 | `PROPOSAL:{assetType}` Key 存在 |
| 投票中 | beginTime <= currentTime < endTime |
| 已通过 | 赞成票 > 反对票 (投票期结束后) |
| 已否决 | 反对票 >= 赞成票 |
| 已撤销 | REVOKEPROPOSAL + 撤销投票通过 |

#### S18: 投票状态机

| 状态 | 条件 |
|------|------|
| 未投票 | 不在任何地址集合中 |
| 已投赞成 | 在 APPROVE 地址集合中, vote_type=1 |
| 已投反对 | 在 AGAINST 地址集合中, vote_type=0 |

**注意**: 投票不可撤销。

#### S19: 奖励状态机

| 状态 | 条件 |
|------|------|
| 未领取 | 初始 |
| 可领取 | CalcBonusValue >= 0, evaluateBonusEligibility == 0 |
| 不可领取 | 无签名记录 / 无资格 / 年化率计算失败 |
| 已领取 | BONUS 交易入块 |

---

### S21: EVM 执行状态机

| 属性 | 内容 |
|------|------|
| 编号 | S21 |
| 所属模块 | EVM (module-evm) |
| 状态 | IDLE / LOADING / EXECUTING / DONE / REVERT / OUT_OF_GAS / ERROR / TIMEOUT / ROLLBACK / COMMITTING / PERSISTED |
| 详档 | [../../module-evm/state_flow.md](../../module-evm/state_flow.md) |

### S22: 合约生命周期状态机

| 属性 | 内容 |
|------|------|
| 编号 | S22 |
| 所属模块 | EVM (module-evm) |
| 状态 | UNDEPLOYED / DEPLOYING / DEPLOYED / DEPLOY_FAILED / CALLING / SELF_DESTRUCTED |
| 详档 | [../../module-evm/state_flow.md](../../module-evm/state_flow.md) |

### S23: MPT 状态生命周期

| 属性 | 内容 |
|------|------|
| 编号 | S23 |
| 所属模块 | EVM (module-evm) |
| 状态 | EMPTY_TRIE / INSERTING / DIRTY / HASHING / COMMITTED / PERSISTED / LOADED |
| 详档 | [../../module-evm/state_flow.md](../../module-evm/state_flow.md) |

---

## 3. 状态转换汇总表

### 3.1 所有级联状态转换

| ID | 触发事件 | 影响的状态机 | 原子性 |
|----|---------|-------------|--------|
| TX_CREATE | RPC CreateTransaction | S14(未创建->已构造), S2(未生成->明文), S3(未验证->已验证) | 否 (多个独立系统) |
| TX_SIGN | signTx() | S2(明文->签名), S14(已构造->已签名) | 是 (单函数) |
| TX_BROADCAST | goMessage() | S14(已签名->已广播->验证中) | 否 (网络) |
| TX_MEMPOOL | AddCache() | S14(验证中->已加入缓存), S15(Cached) | 是 |
| TX_PACKAGE | BuildBlock() | S15(Building->Built), S14(已加入缓存->已打包) | 是 |
| BLOCK_CONFIRM | SaveBlock() | S9(SaveDB->Commit->MainChain), S10(Verified->Persisted), S13(未确认->已确认可用), S14(已打包->已确认) | 否 (分步) |
| BLOCK_ROLLBACK | 分叉解决 | S9(Rollback), S13(已花费->已确认可用), S14(已确认->已打包) | 否 (P0-2) |
| STAKE | STAKE 交易入块 | S13(已确认可用->已质押) | 是 |
| LOCK_VOTE | LOCK 交易入块 | S13(已确认可用->已锁定), S18(未投票) | 是 |
| VOTE | CreateVote | S18(未投票->已投赞成/反对) | 是 |
| BONUS_CLAIM | CalcBonusValue | S19(未领取->可领取->已领取) | 是 |
| CONTRACT_DEPLOY | CreateDeploy | S22(UNDEPLOYED->DEPLOYING->DEPLOYED), S23(EMPTY_TRIE->PERSISTED) | 否 |
| CONTRACT_CALL | CreateCall | S21(IDLE->EXECUTING->DONE/REVERT), S23(LOADED->DIRTY->PERSISTED) | 否 |
| VRF_CYCLE | 10 秒周期 | S8(WaitForCycle->PackagerSelect) | 否 (广播+收集) |
| NODE_CONNECT | TCP + 密钥交换 | S5(socket->connected), S6(未交换->加密通道就绪), S7(NOTYET->active) | 否 (多阶段) |

### 3.2 跨状态机的关键依赖

```
交易确认 (S14) 依赖:
  ├── 区块验证通过 (S9)
  ├── UTXO 未被花费 (S13)
  └── 共识确认 (S10)

奖励领取 (S19) 依赖:
  ├── 节点在签名列表中 (S8 VRF 周期记录)
  ├── 质押/委托状态 (S13)
  └── 年化率计算 (动态值, 无状态)

合约部署/调用 (S22/S21) 依赖:
  ├── UTXO 余额充足 (S13)
  ├── TransactionCache 打包 (S15)
  └── MPT 状态正确 (S23)

VRF 共识 (S8) 依赖:
  ├── 节点有质押资格 (S13 已质押)
  ├── 密钥可签名 (S2 有密钥对)
  └── 网络连接正常 (S5/S7)
```

---

## 4. 状态持久化矩阵

| 状态机 | 持久化方式 | 丢失后果 |
|--------|-----------|---------|
| S1 账户 | Keystore JSON | 无法签名 |
| S2 密钥 | 明文内存 (运行时) + Keystore JSON (持久) | 重启需解密 |
| S3 地址验证 | 内存缓存 (VerifiedAddress) | 重启重验证 |
| S5-S7 连接 | 内存 (无持久化) | 断连重建 |
| S8 VRF | 内存 (validatedVRfs) | **重启丢失** |
| S10 BlockStatus | 内存 | 重启重建 |
| S11 Sync | 部分持久化 | 重启重新同步 |
| S13 UTXO | RocksDB (UB:/UAH:/BAL:) | 永久数据 |
| S14 交易 | RocksDB (已确认) / 内存 (未确认) | 未确认交易丢失 |
| S15-S16 缓存 | 内存 | **重启丢失** |
| S17-S20 治理/激励 | RocksDB (提案/锁定/投票) / 内存 (年化率) | 未领取奖励可重建 |
| S21-S23 EVM | RocksDB (MptValue) / 内存 (EvmHost) | 合约状态持久化, 运行中丢失 |

**关键风险**:
1. VRF validatedVRfs 和 newValidatedVRfs 全内存存储，节点重启后 **丢失所有 VRF 历史数据** (AI-4)
2. TransactionCache 内存缓存，节点崩溃后未确认交易全部丢失
3. 年化率非持久化，每次按需计算，依赖历史签名数据完整性
4. ContractTransactionCache 已注释，不参与运行

---

## 5. 未完成/未定义的状态转换

| 状态机 | 问题 | 影响 |
|--------|------|------|
| S15 | 交易超时淘汰: `_kTxExpireInterval=10` 定义但未使用 | 过期交易永久留在池中 |
| S15 | 池溢出保护: 无 `Cached -> Rejected` 转换 | 内存可无限增长 |
| S15 | DECLARATION(6): 无对应处理器 | 交易类型未实现 |
| S15 | PROPOSAL(11): 无对应处理器 | 提案创建未实现 |
| S15 | REVOKEPROPOSAL(12): 无对应处理器 | 提案撤销未实现 |
| S9 | 签名节点资格验证缺失 | 非 VRF 选中节点也可签名 |

---

## 6. 文档索引

### 6.1 各模块状态流转文档

| 模块 | 状态流转文件 |
|------|-------------|
| UTXO | [../../module-utxo/state_flow.md](../../module-utxo/state_flow.md) |
| Crypto | [../../module-crypto/state_flow.md](../../module-crypto/state_flow.md) |
| DAG Consensus | [../../module-dag-consensus/state_flow.md](../../module-dag-consensus/state_flow.md) |
| Governance/Incentive | [../../module-governance-incentive/state_flow.md](../../module-governance-incentive/state_flow.md) |
| EVM | [../../module-evm/state_flow.md](../../module-evm/state_flow.md) |
| Network | [../../module-network/state_flow.md](../../module-network/state_flow.md) |
| TxPool | [../../module-txpool/state_flow.md](../../module-txpool/state_flow.md) |

### 6.2 阶段 3 状态转换文档

| 流程 | 状态转换文件 |
|------|-------------|
| 交易生命周期 | [../../03_core_flows/flow-01-tx-lifecycle/state_transition.md](../../03_core_flows/flow-01-tx-lifecycle/state_transition.md) |
| 区块同步 | [../../03_core_flows/flow-02-block-sync/state_transition.md](../../03_core_flows/flow-02-block-sync/state_transition.md) |
| 治理 | [../../03_core_flows/flow-03-governance/state_transition.md](../../03_core_flows/flow-03-governance/state_transition.md) |
| EVM 合约 | [../../03_core_flows/flow-04-evm-contract/state_transition.md](../../03_core_flows/flow-04-evm-contract/state_transition.md) |
| 激励 | [../../03_core_flows/flow-05-incentive/state_transition.md](../../03_core_flows/flow-05-incentive/state_transition.md) |
| 节点启动 | [../../03_core_flows/flow-06-startup/state_transition.md](../../03_core_flows/flow-06-startup/state_transition.md) |

### 6.3 相关文档

| 文档 | 路径 |
|------|------|
| 重构总体规划 | [../../refactor_master_plan.md](../../refactor_master_plan.md) |
| 本阶段合约 | [../10_contract/README.md](../10_contract/README.md) |
| 本阶段密码学 | [../11_crypto/README.md](../11_crypto/README.md) |
| 本阶段共识 | [../12_consensus/README.md](../12_consensus/README.md) |
| 本阶段线程 | [../13_threading/README.md](../13_threading/README.md) |

---

*本文档基于阶段 2 全部模块的 state_flow.md 和阶段 3 全部流程的 state_transition.md 分析综合编写。状态编号 S1-S23 为本阶段分配，非源码原生编号。*
