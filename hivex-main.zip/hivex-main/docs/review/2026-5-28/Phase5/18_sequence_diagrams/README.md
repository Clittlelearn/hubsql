# 18 -- 时序图 / 流程图 / 状态图索引

> **阶段**: 阶段5 -- 文档重组
> **目录**: `18_sequence_diagrams/`
> **用途**: 全部时序图、流程图、状态图的集中索引，按模块和流程双重分类

---

## 一、文档索引总览

### 核心流程时序图 (阶段3: 6个流程 x 4类图 = 24份)

| flow | 流程名 | 序列图 | 状态转换 | 调用栈 | 异步任务 |
|------|--------|--------|---------|--------|---------|
| flow-01 | 交易生命周期 | [sequence_flow.md](../../03_core_flows/flow-01-tx-lifecycle/sequence_flow.md) | [state_transition.md](../../03_core_flows/flow-01-tx-lifecycle/state_transition.md) | [call_stack.md](../../03_core_flows/flow-01-tx-lifecycle/call_stack.md) | [async_task_flow.md](../../03_core_flows/flow-01-tx-lifecycle/async_task_flow.md) |
| flow-02 | 区块同步 | [sequence_flow.md](../../03_core_flows/flow-02-block-sync/sequence_flow.md) | [state_transition.md](../../03_core_flows/flow-02-block-sync/state_transition.md) | [call_stack.md](../../03_core_flows/flow-02-block-sync/call_stack.md) | [async_task_flow.md](../../03_core_flows/flow-02-block-sync/async_task_flow.md) |
| flow-03 | 治理投票 | [sequence_flow.md](../../03_core_flows/flow-03-governance/sequence_flow.md) | [state_transition.md](../../03_core_flows/flow-03-governance/state_transition.md) | [call_stack.md](../../03_core_flows/flow-03-governance/call_stack.md) | [async_task_flow.md](../../03_core_flows/flow-03-governance/async_task_flow.md) |
| flow-04 | EVM合约执行 | [sequence_flow.md](../../03_core_flows/flow-04-evm-contract/sequence_flow.md) | [state_transition.md](../../03_core_flows/flow-04-evm-contract/state_transition.md) | [call_stack.md](../../03_core_flows/flow-04-evm-contract/call_stack.md) | [async_task_flow.md](../../03_core_flows/flow-04-evm-contract/async_task_flow.md) |
| flow-05 | 激励发放 | [sequence_flow.md](../../03_core_flows/flow-05-incentive/sequence_flow.md) | [state_transition.md](../../03_core_flows/flow-05-incentive/state_transition.md) | [call_stack.md](../../03_core_flows/flow-05-incentive/call_stack.md) | [async_task_flow.md](../../03_core_flows/flow-05-incentive/async_task_flow.md) |
| flow-06 | 启动流程 | [sequence_flow.md](../../03_core_flows/flow-06-startup/sequence_flow.md) | [state_transition.md](../../03_core_flows/flow-06-startup/state_transition.md) | [call_stack.md](../../03_core_flows/flow-06-startup/call_stack.md) | [async_task_flow.md](../../03_core_flows/flow-06-startup/async_task_flow.md) |

### 模块级图表 (阶段2: 10个模块 x 多种图类型)

| 模块 | 调用链 | 状态流程 | 类分析 | 线程模型 | 存储模型 | 模块概览 |
|------|--------|---------|--------|---------|---------|---------|
| 密码学 | [call_chain.md](../../module-crypto/call_chain.md) | [state_flow.md](../../module-crypto/state_flow.md) | [class_analysis.md](../../module-crypto/class_analysis.md) | [thread_model.md](../../module-crypto/thread_model.md) | [storage_model.md](../../module-crypto/storage_model.md) | [module_overview.md](../../module-crypto/module_overview.md) |
| DAG共识 | [call_chain.md](../../module-dag-consensus/call_chain.md) | [state_flow.md](../../module-dag-consensus/state_flow.md) | [class_analysis.md](../../module-dag-consensus/class_analysis.md) | [thread_model.md](../../module-dag-consensus/thread_model.md) | [storage_model.md](../../module-dag-consensus/storage_model.md) | [module_overview.md](../../module-dag-consensus/module_overview.md) |
| EVM集成 | [call_chain.md](../../module-evm/call_chain.md) | [state_flow.md](../../module-evm/state_flow.md) | [class_analysis.md](../../module-evm/class_analysis.md) | [thread_model.md](../../module-evm/thread_model.md) | [storage_model.md](../../module-evm/storage_model.md) | [module_overview.md](../../module-evm/module_overview.md) |
| 治理激励 | [call_chain.md](../../module-governance-incentive/call_chain.md) | [state_flow.md](../../module-governance-incentive/state_flow.md) | [class_analysis.md](../../module-governance-incentive/class_analysis.md) | [thread_model.md](../../module-governance-incentive/thread_model.md) | [storage_model.md](../../module-governance-incentive/storage_model.md) | [module_overview.md](../../module-governance-incentive/module_overview.md) |
| 网络层 | [call_chain.md](../../module-network/call_chain.md) | [state_flow.md](../../module-network/state_flow.md) | [class_analysis.md](../../module-network/class_analysis.md) | [thread_model.md](../../module-network/thread_model.md) | [storage_model.md](../../module-network/storage_model.md) | [module_overview.md](../../module-network/module_overview.md) |
| RPC服务 | [call_chain.md](../../module-rpc/call_chain.md) | [state_flow.md](../../module-rpc/state_flow.md) | [class_analysis.md](../../module-rpc/class_analysis.md) | [thread_model.md](../../module-rpc/thread_model.md) | [storage_model.md](../../module-rpc/storage_model.md) | [module_overview.md](../../module-rpc/module_overview.md) |
| 特殊功能 | [call_chain.md](../../module-special/call_chain.md) | [state_flow.md](../../module-special/state_flow.md) | [class_analysis.md](../../module-special/class_analysis.md) | [thread_model.md](../../module-special/thread_model.md) | [storage_model.md](../../module-special/storage_model.md) | [module_overview.md](../../module-special/module_overview.md) |
| 存储层 | [call_chain.md](../../module-storage/call_chain.md) | [state_flow.md](../../module-storage/state_flow.md) | [class_analysis.md](../../module-storage/class_analysis.md) | [thread_model.md](../../module-storage/thread_model.md) | [storage_model.md](../../module-storage/storage_model.md) | [module_overview.md](../../module-storage/module_overview.md) |
| 交易池 | [call_chain.md](../../module-txpool/call_chain.md) | [state_flow.md](../../module-txpool/state_flow.md) | [class_analysis.md](../../module-txpool/class_analysis.md) | [thread_model.md](../../module-txpool/thread_model.md) | [storage_model.md](../../module-txpool/storage_model.md) | [module_overview.md](../../module-txpool/module_overview.md) |
| UTXO | [call_chain.md](../../module-utxo/call_chain.md) | [state_flow.md](../../module-utxo/state_flow.md) | [class_analysis.md](../../module-utxo/class_analysis.md) | [thread_model.md](../../module-utxo/thread_model.md) | [storage_model.md](../../module-utxo/storage_model.md) | [module_overview.md](../../module-utxo/module_overview.md) |

### 全局图表 (阶段1)

| 图表 | 路径 | 说明 |
|------|------|------|
| 架构总览 | [../../architecture_overview.md](../../architecture_overview.md) | 系统分层架构、模块职责表、核心入口点 |
| 模块依赖图 | [../../module_dependency.md](../../module_dependency.md) | 跨模块 `#include` 依赖和循环依赖关系 |
| 启动流程 | [../../startup_flow.md](../../startup_flow.md) | 系统初始化完整流程 (CaInit + NetInit) |
| 风险全景图 | [../../refactor_risk_overview.md](../../refactor_risk_overview.md) | 高耦合区域、全局单例、模块风险矩阵 |

---

## 二、按流程分类索引

### 2.1 交易生命周期 (flow-01)

| 用途 | 文档 | 关键内容 |
|------|------|---------|
| 交易完整流程 | [sequence_flow.md](../../03_core_flows/flow-01-tx-lifecycle/sequence_flow.md) | 交易创建->签名->入池->打包->执行->确认全链路时序 |
| 交易状态机 | [state_transition.md](../../03_core_flows/flow-01-tx-lifecycle/state_transition.md) | TX_PENDING->TX_BROADCAST->TX_PACKED->TX_CONFIRMED->TX_ROLLBACK |
| 函数调用栈 | [call_stack.md](../../03_core_flows/flow-01-tx-lifecycle/call_stack.md) | HandleTx -> verifyTransaction -> SaveTx -> dispatchTx -> ExecuteTx |
| 异步任务 | [async_task_flow.md](../../03_core_flows/flow-01-tx-lifecycle/async_task_flow.md) | 交易广播线程、超时检测线程、双花检测线程 |

### 2.2 区块同步 (flow-02)

| 用途 | 文档 | 关键内容 |
|------|------|---------|
| 同步完整流程 | [sequence_flow.md](../../03_core_flows/flow-02-block-sync/sequence_flow.md) | 快同步/从零同步两条路径、增量同步、分叉检测 |
| 同步状态机 | [state_transition.md](../../03_core_flows/flow-02-block-sync/state_transition.md) | SYNC_IDLE->SYNC_FAST->SYNC_INCREMENTAL->SYNC_CAUGHT_UP |
| 函数调用栈 | [call_stack.md](../../03_core_flows/flow-02-block-sync/call_stack.md) | SyncBlock::ThreadSync -> getBlockByHash -> saveBlock -> verifyBlock |
| 异步任务 | [async_task_flow.md](../../03_core_flows/flow-02-block-sync/async_task_flow.md) | 同步重试、分叉解决、超时处理 |

### 2.3 治理投票 (flow-03)

| 用途 | 文档 | 关键内容 |
|------|------|---------|
| 治理全流程 | [sequence_flow.md](../../03_core_flows/flow-03-governance/sequence_flow.md) | 提案创建->投票->统计->执行 时序 |
| 治理状态机 | [state_transition.md](../../03_core_flows/flow-03-governance/state_transition.md) | PROPOSAL_CREATED->VOTING->PASSED/REJECTED->EXECUTED |
| 函数调用栈 | [call_stack.md](../../03_core_flows/flow-03-governance/call_stack.md) | CreateProposal -> CheckVoteTxInfo -> addVoteCount -> ExecuteProposal |
| 异步任务 | [async_task_flow.md](../../03_core_flows/flow-03-governance/async_task_flow.md) | 投票窗口定时器、提案过期检测 |

### 2.4 EVM合约执行 (flow-04)

| 用途 | 文档 | 关键内容 |
|------|------|---------|
| 合约执行流程 | [sequence_flow.md](../../03_core_flows/flow-04-evm-contract/sequence_flow.md) | 合约部署->调用->预编译->Gas计算->状态持久化 |
| 合约状态机 | [state_transition.md](../../03_core_flows/flow-04-evm-contract/state_transition.md) | CONTRACT_DEPLOYED->CALLED->SELFDESTRUCT |
| 函数调用栈 | [call_stack.md](../../03_core_flows/flow-04-evm-contract/call_stack.md) | EvmHost::call -> execute -> precompile -> saveContract -> commitState |
| 异步任务 | [async_task_flow.md](../../03_core_flows/flow-04-evm-contract/async_task_flow.md) | EVM超时线程、合约事件通知 |

### 2.5 激励发放 (flow-05)

| 用途 | 文档 | 关键内容 |
|------|------|---------|
| 激励全流程 | [sequence_flow.md](../../03_core_flows/flow-05-incentive/sequence_flow.md) | 年化率计算->奖励计算->发放->异常节点检测->惩罚 |
| 激励状态机 | [state_transition.md](../../03_core_flows/flow-05-incentive/state_transition.md) | CALCULATING->DISTRIBUTING->CLAIMED/SLASHED |
| 函数调用栈 | [call_stack.md](../../03_core_flows/flow-05-incentive/call_stack.md) | CalcBonusValue -> GetNetworkStakingRate -> calculateAnnualizedRates |
| 异步任务 | [async_task_flow.md](../../03_core_flows/flow-05-incentive/async_task_flow.md) | 奖励周期定时器、异常签名检测 |

### 2.6 启动流程 (flow-06)

| 用途 | 文档 | 关键内容 |
|------|------|---------|
| 启动完整流程 | [sequence_flow.md](../../03_core_flows/flow-06-startup/sequence_flow.md) | Init 7步顺序: 配置->创世->日志->账户->DB->CaInit->NetInit |
| 启动状态机 | [state_transition.md](../../03_core_flows/flow-06-startup/state_transition.md) | PRE_INIT->INIT_CONFIG->INIT_DB->CA_READY->NET_READY->RUNNING |
| 函数调用栈 | [call_stack.md](../../03_core_flows/flow-06-startup/call_stack.md) | main->Init()->CaInit()->RegisterInterface()->NetInit()->InitializeNetwork() |
| 异步任务 | [async_task_flow.md](../../03_core_flows/flow-06-startup/async_task_flow.md) | HTTP Server启动、VRF定时器启动、同步线程启动 |

---

## 三、按模块分类索引

### 模块级图表类型说明

| 图类型 | 说明 | 文件名模式 |
|--------|------|-----------|
| **调用链图** | 函数调用关系，跨模块桥接点标注 | `call_chain.md` |
| **状态流程图** | 模块内核心对象的状态转换 | `state_flow.md` |
| **类分析图** | 类继承/组合关系、接口实现 | `class_analysis.md` |
| **线程模型图** | 线程创建/协作/同步关系 | `thread_model.md` |
| **存储模型图** | RocksDB ColumnFamily/Key设计/数据流 | `storage_model.md` |
| **模块概览** | 模块职责/边界/头文件依赖 | `module_overview.md` |
| **重构建议** | 问题清单/推荐方案/预估工时 | `refactor_suggestion.md` |

### 快速定位

| 你想看什么 | 去哪个文档 |
|-----------|-----------|
| 交易如何从RPC到区块确认 | [flow-01 sequence_flow.md](../../03_core_flows/flow-01-tx-lifecycle/sequence_flow.md) |
| 区块同步如何检测和处理分叉 | [flow-02 sequence_flow.md](../../03_core_flows/flow-02-block-sync/sequence_flow.md) |
| EVM合约执行时Host如何桥接存储 | [flow-04 sequence_flow.md](../../03_core_flows/flow-04-evm-contract/sequence_flow.md) + [module-evm call_chain.md](../../module-evm/call_chain.md) |
| RocksDB key设计规范 | 各模块 `storage_model.md` |
| 多线程协作全景 | 各模块 `thread_model.md` |
| 并发锁的获取顺序 | [../../refactor_risk_overview.md](../../refactor_risk_overview.md) 第五节 |
| 系统启动7步初始化顺序 | [flow-06 sequence_flow.md](../../03_core_flows/flow-06-startup/sequence_flow.md) |
| 提交流程 链上数据 | [flow-01 state_transition.md](../../03_core_flows/flow-01-tx-lifecycle/state_transition.md) |

---

## 四、Mermaid 图类型列表

项目文档中使用的 Mermaid 图表类型：

| 图类型 | Mermaid 语法 | 使用场景 | 示例文档 |
|--------|-------------|---------|---------|
| **时序图** | `sequenceDiagram` | 跨模块/跨组件的交互顺序 | flow-01~06 sequence_flow.md |
| **状态图** | `stateDiagram-v2` | 交易/区块/同步/治理状态的转换 | flow-01~06 state_transition.md |
| **流程图** | `flowchart TD/LR` | 函数调用栈、模块依赖关系 | call_stack.md, module_dependency.md |
| **类图** | `classDiagram` | 类继承/组合关系 | module-* class_analysis.md |
| **甘特图** | `gantt` | 线程调度/异步任务时序 | async_task_flow.md, thread_model.md |
| **架构图** | `flowchart` (自定义布局) | 系统分层、模块边界 | architecture_overview.md |
| **实体关系图** | `erDiagram` | RocksDB 存储模型、数据实体关系 | module-* storage_model.md |

---

## 五、图表统计

| 阶段 | 图表数 | 说明 |
|------|--------|------|
| 阶段1 (全局) | 4 | 架构、依赖、启动、风险 |
| 阶段2 (模块) | 70 | 10模块 x 7类文档 (各含Mermaid图) |
| 阶段3 (流程) | 24 | 6流程 x 4类文档 (各含Mermaid图) |
| 阶段4 (规划) | 1 | refactor_master_plan.md (含流程图) |
| **合计** | **~99** | |

---

## 六、相关文档速查

| 需求 | 查阅文档 |
|------|---------|
| 重构规划 | [../15_refactor_analysis/README.md](../15_refactor_analysis/README.md) |
| 风险全景 | [../16_risk_analysis/README.md](../16_risk_analysis/README.md) |
| API参考 | [../17_api_reference/README.md](../17_api_reference/README.md) |
| 架构概览 | [../01_architecture/README.md](../01_architecture/README.md) |
| 模块依赖 | [../../module_dependency.md](../../module_dependency.md) |

---

*文档生成日期：2026-05-26*
*数据来源：阶段1-3 图表分析文档，10个模块 + 6个流程 共 ~99 份文档*
