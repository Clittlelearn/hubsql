# 03 — 核心模块索引 (Core Modules)

> **文档阶段**: 阶段5 — 重组索引
> **项目**: MeMeChain (`mm`)
> **最后更新**: 2026-05-26

---

## 一、模块分层图

```
┌──────────────────────────────────────────────────────────────┐
│                    应用入口层                                  │
│   main/ (main.cpp, menu.cpp)                                 │
├──────────────────────────────────────────────────────────────┤
│                    接口层                                      │
│   ┌──────────────────────┐  ┌──────────────────────────────┐ │
│   │  module-rpc/         │  │  module-special/ (HTTP/其他) │ │
│   │  JSON-RPC + ETH兼容  │  │  HTTP Server + 特色接口      │ │
│   └──────────┬───────────┘  └──────────────────────────────┘ │
├──────────────┼──────────────────────────────────────────────┤
│              │           共识与执行层                          │
│   ┌──────────┴───────────┐  ┌──────────────────────────────┐ │
│   │  module-dag-consensus│  │  module-evm/                 │ │
│   │  VRF + DAG + 打包    │  │  EVM Host + 合约执行         │ │
│   └──────────┬───────────┘  └──────────────┬───────────────┘ │
│   ┌──────────┴───────────┐  ┌──────────────┴───────────────┐ │
│   │  module-utxo/        │  │  module-governance-incentive/│ │
│   │  UTXO 选择/花费/验证  │  │  质押/委托/投票/激励         │ │
│   └──────────┬───────────┘  └──────────────┬───────────────┘ │
│   ┌──────────┴───────────┐                 │                 │
│   │  module-txpool/       │                 │                 │
│   │  交易池/缓存/去重     │                 │                 │
│   └──────────┬───────────┘                 │                 │
├──────────────┼─────────────────────────────┼─────────────────┤
│              │           基础设施层           │                 │
│   ┌──────────┴───────────┐  ┌──────────────┴───────────────┐ │
│   │  module-storage/     │  │  module-network/             │ │
│   │  RocksDB 封装/事务   │  │  epoll + P2P + ECDH         │ │
│   └──────────────────────┘  └──────────────────────────────┘ │
│   ┌──────────────────────┐                                   │
│   │  module-crypto/       │                                   │
│   │  ECDSA/ECVRF/Keccak  │                                   │
│   └──────────────────────┘                                   │
└──────────────────────────────────────────────────────────────┘
```

---

## 二、10 大核心模块索引

### module-crypto — 密码学与账户体系

| 属性 | 值 |
|------|-----|
| 源码目录 | `utils/crypto.cpp`, `utils/account_manager.cpp`, `silkpre/` |
| 职责 | ECDSA 签名/验签、ECVRF 证明、Keccak/SHA256 哈希、密钥库管理、账户创建/导入/导出 |
| 关键文件 | `crypto.cpp/h`, `ecvrf_p256_sha256_tai.cpp/h`, `account_manager.cpp/h`, `keystore.cpp/h`, `magic_singleton.h` |
| 文档目录 | `../../module-crypto/` (7 文件) |

### module-storage — 存储层

| 属性 | 值 |
|------|-----|
| 源码目录 | `db/` |
| 职责 | RocksDB TransactionDB 封装、读写分离事务、业务数据接口 (所有 KV 操作) |
| 关键文件 | `db_api.cpp/h` (57K/81K), `rocksdb.cpp/h`, `rocksdb_read_write.cpp/h`, `rocksdb_read.cpp/h` |
| 文档目录 | `../../module-storage/` (7 文件) |

### module-utxo — UTXO 模型

| 属性 | 值 |
|------|-----|
| 源码目录 | `ca/transaction/utxo_core.cpp` |
| 职责 | UTXO 选择算法、花费验证、双花检测、UTXO 集维护 |
| 关键文件 | `utxo_core.cpp/h`, `double_spend_cache.cpp/h`, `failed_transaction_cache.cpp/h` |
| 文档目录 | `../../module-utxo/` (7 文件) |

### module-dag-consensus — DAG 与共识

| 属性 | 值 |
|------|-----|
| 源码目录 | `ca/` (核心), `ca/ca/evm/` (EVM), `ca/ca/transaction/` (交易) |
| 职责 | VRF 共识节点选择、DAG 区块构建/验证/回滚、主链选择、区块同步、分叉解决 |
| 关键文件 | `algorithm.cpp/h` (~382KB), `block_helper.cpp/h`, `block_storage.cpp/h`, `block_monitor.cpp/h`, `sync_block.cpp/h` (~132KB), `vrf_consensus.cpp/h`, `check_blocks.cpp/h` |
| 文档目录 | `../../module-dag-consensus/` (7 文件) |

### module-evm — EVM 集成

| 属性 | 值 |
|------|-----|
| 源码目录 | `ca/evm/`, `contract/`, `mpt/` |
| 职责 | evmone Host 接口实现、合约执行管理、EVM 环境上下文、预编译合约、MPT 状态存储 |
| 关键文件 | `evm_host.cpp/h`, `evm_manager.cpp/h`, `evmEnvironment.cpp/h`, `precompiles.cpp/hpp`, `trie.cpp/h`, `rlp.cpp/h` |
| 文档目录 | `../../module-evm/` (7 文件) |

### module-network — 网络层

| 属性 | 值 |
|------|-----|
| 源码目录 | `net/` |
| 职责 | epoll 事件循环、Peer 节点发现与管理、心跳机制、Protobuf 消息分发、ECDH 密钥交换、消息压缩加密 |
| 关键文件 | `api.cpp/h`, `handle_event.cpp/h`, `epoll_mode.cpp/h`, `peer_node.cpp/h`, `dispatcher.cpp/h`, `key_exchange.cpp/h`, `pack.cpp/h`, `http_server.cpp/h` |
| 文档目录 | `../../module-network/` (7 文件) |

### module-txpool — 交易池

| 属性 | 值 |
|------|-----|
| 源码目录 | `ca/transaction_cache.cpp`, `ca/dispatchtx.cpp`, `ca/transaction.cpp` |
| 职责 | 交易缓存池、交易验证、交易分发/广播、交易去重、失败交易重试 |
| 关键文件 | `transaction_cache.cpp/h`, `dispatchtx.cpp/h`, `transaction.cpp/h` (~128KB), `txhelper.cpp/h` (~138KB) |
| 文档目录 | `../../module-txpool/` (7 文件) |

### module-governance-incentive — 治理与激励

| 属性 | 值 |
|------|-----|
| 源码目录 | `ca/transaction/` (stake/unstake/delegating/vote/lock/bonus/fund) |
| 职责 | 质押/解押、委托/取消委托、投票/锁定/解锁、奖励计算与领取、国库分配 |
| 关键文件 | `ca/transaction/stake.cpp/h`, `unstake.cpp/h`, `delegating.cpp/h`, `undelegating.cpp/h`, `vote.cpp/h`, `lock.cpp/h`, `unlock.cpp/h`, `bonus.cpp/h`, `fund.cpp/h` |
| 文档目录 | `../../module-governance-incentive/` (7 文件) |

### module-rpc — RPC 层

| 属性 | 值 |
|------|-----|
| 源码目录 | `rpc/`, `api/interface/` |
| 职责 | JSON-RPC 2.0 接口实现 (GET 38+ / POST 93+)、ETH 兼容接口、参数处理器/结果处理器、HTTP 路由注册 |
| 关键文件 | `rpc.cpp/h`, `http_api.cpp/h` (~223KB), `param_handle.cpp/h`, `result_handle.cpp/h`, `rpc/api/get/*`, `rpc/api/post/*`, `rpc/eth/*` |
| 文档目录 | `../../module-rpc/` (7 文件) |

### module-special — 其他特殊功能

| 属性 | 值 |
|------|-----|
| 源码目录 | 分散在 `utils/`, `common/`, `main/`, `errorn/`, `include/` |
| 职责 | 配置/创世管理、任务池/线程池、CLI 交互、错误码体系、日志、QR 码、基准测试等支撑功能 |
| 关键文件 | `config.cpp/h`, `genesis.cpp/h`, `task_pool.cpp/h`, `menu.cpp/h`, `error_module.h`, `logging.cpp/h`, `bench_mark.cpp/h` |
| 文档目录 | `../../module-special/` (7 文件) |

---

## 三、模块间核心依赖关系

```
main/ ──── 依赖 ────> 所有模块 (在 Init() 中按顺序初始化)

ca/   ──── 依赖 ────> db/      (区块/交易数据读写)
      ──── 依赖 ────> net/     (消息广播/接收)
      ──── 依赖 ────> utils/   (VRF/账户/密码学)
      ──── 依赖 ────> pb/      (Protobuf 消息)

net/  ──── 依赖 ────> utils/   (ECDH/加密)
      ──── 依赖 ────> pb/      (消息序列化)

rpc/  ──── 依赖 ────> ca/      (通过 interface.cpp 回调)
      ──── 依赖 ────> db/      (数据查询)
      ──── 依赖 ────> pb/      (消息格式)

所有模块 ──── 依赖 ────> pb/   (Protobuf 编译产物为公共依赖)
```

详细依赖图请参见 [模块依赖关系文档](../../module_dependency.md)。

---

## 四、相关文档

| 文档 | 路径 | 说明 |
|------|------|------|
| 架构概览 | `../../architecture_overview.md` | 第4节: 模块职责表 |
| 模块依赖 | `../../module_dependency.md` | 逐模块 include/链接关系 |
| 阶段2 各模块 | `../../module-crypto/` 等 10 个目录 | 每个模块 7 份详细分析 |
| 核心流程 | `../../03_core_flows/` | 6 条跨模块核心流程 |
| 重构规划 | `../../refactor_master_plan.md` | 第3节: 推荐目录重组方案 |
| 构建系统 | `../02_build_system/` | 各模块对应的构建配置 |
