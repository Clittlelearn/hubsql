# 04 — 交易生命周期 (Transaction Flow)

> **文档阶段**: 阶段5 — 重组索引
> **项目**: MeMeChain (`mm`)
> **最后更新**: 2026-05-26

---

## 一、交易生命周期概览

MeMeChain 采用 UTXO + Account 混合模型，交易从创建到最终确认经历以下阶段：

```
┌─────────────────────────────────────────────────────────────────┐
│                    交易生命周期 (6 阶段)                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  [1] 构造             [2] 签名              [3] 广播             │
│  txhelper.cpp         crypto.cpp            dispatchtx.cpp      │
│  rpc/创建接口         ECDSA 签名            P2P 网络广播         │
│      │                     │                     │               │
│      ▼                     ▼                     ▼               │
│  ┌─────────┐         ┌─────────┐         ┌──────────┐          │
│  │ 交易对象 │─────────│ 签名交易 │─────────│ 全网分发  │          │
│  │ 构造    │          │ 封装    │          │          │          │
│  └─────────┘         └─────────┘         └────┬─────┘          │
│                                               │                 │
│  [4] 入池                                        │                 │
│  transaction_cache.cpp                           │                 │
│  验证 + 去重 + 缓存                              │                 │
│      │                                           │                 │
│      ▼                                           ▼                 │
│  ┌──────────────┐                        ┌──────────────┐       │
│  │ 交易池缓存   │                        │ 打包节点接收  │       │
│  │ (TxPool)     │◄───────────────────────│ VRF 选中     │       │
│  └──────┬───────┘                        └──────┬───────┘       │
│         │                                       │                 │
│         │  [5] 打包                              │                 │
│         │  algorithm.cpp                         │                 │
│         │  VRF 打包节点构造区块                  │                 │
│         │                                       │                 │
│         ▼                                       ▼                 │
│  ┌──────────────────────────────────────────────────────┐       │
│  │  区块构造: 交易排序 → UTXO 选择 → 执行 → 状态更新   │       │
│  └──────────────────────────┬───────────────────────────┘       │
│                             │                                     │
│  [6] 确认                       │                                     │
│  block_helper.cpp              │                                     │
│  vrf_consensus.cpp             ▼                                     │
│  ┌──────────────────────────────────────────────────────┐       │
│  │  区块验证 → 共识签名 → 写入 RocksDB → UTXO 集更新   │       │
│  └──────────────────────────────────────────────────────┘       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 各阶段详解

| 阶段 | 入口代码 | 关键操作 | 产出 |
|------|---------|---------|------|
| **构造** | `txhelper.cpp` / RPC `rpc_create_transaction.cpp` | 选择交易类型、构造参数、生成未签名交易 | 未签名交易对象 |
| **签名** | `utils/crypto.cpp` (ECDSA) / `utils/keystore.cpp` | ECDSA 签名 (secp256k1/P-256)、信封封装 | 已签名交易 |
| **广播** | `ca/dispatchtx.cpp` → `net/api.cpp` | P2P 广播至所有已知节点 (Protobuf 序列化) | 全网分发 |
| **入池** | `ca/transaction_cache.cpp` → `ca/transaction.cpp` | 签名验证、格式检查、去重、双花检测、写入缓存 | 交易池条目 |
| **打包** | `ca/algorithm.cpp` → `ca/vrf_consensus.cpp` | VRF 打包节点选择、交易排序、UTXO 选择、执行交易 | 新区块 |
| **确认** | `ca/block_helper.cpp` → `ca/check_blocks.cpp` | 区块验证、共识签名收集、写入 DB、更新 UTXO 集 | 最终确认 |

---

## 二、交易类型表

MeMeChain 支持以下 16 种交易类型：

| # | 交易类型 | 处理文件 | 分类 | 说明 |
|---|---------|---------|------|------|
| 1 | **Transfer** (普通转账) | `ca/transaction/trans.cpp/h` | UTXO | MM 代币转账，UTXO 选择/构造/花费 |
| 2 | **Stake** (质押) | `ca/transaction/stake.cpp/h` | 治理 | 质押 MM 获得打包资格/投票权 |
| 3 | **UnStake** (解押) | `ca/transaction/unstake.cpp/h` | 治理 | 解除质押，进入锁定期后释放 |
| 4 | **Delegate** (委托) | `ca/transaction/delegating.cpp/h` | 治理 | 将投票权委托给其他节点 |
| 5 | **UnDelegate** (取消委托) | `ca/transaction/undelegating.cpp/h` | 治理 | 收回委托的投票权 |
| 6 | **Vote** (投票) | `ca/transaction/vote.cpp/h` | 治理 | 链上治理提案投票 |
| 7 | **Lock** (锁定) | `ca/transaction/lock.cpp/h` | 治理 | 锁定代币获取投票权重 |
| 8 | **Unlock** (解锁) | `ca/transaction/unlock.cpp/h` | 治理 | 解锁已锁定的代币 |
| 9 | **Claim Bonus** (领取奖励) | `ca/transaction/bonus.cpp/h` | 激励 | 领取质押/委托出块奖励 |
| 10 | **Claim Fund** (领取国库) | `ca/transaction/fund.cpp/h` | 激励 | 从国库按比例提取资金 |
| 11 | **Contract Deploy** (合约部署) | `ca/transaction/contract.cpp/h` | EVM | 部署 Solidity 合约到链上 |
| 12 | **Contract Call** (合约调用) | `ca/contract.cpp/h` → `ca/evm/` | EVM | 调用已部署合约的方法 |
| 13 | **ETH Transfer** (ETH 兼容转账) | `ca/eth_trans.cpp/h` | ETH兼容 | EVM 账户模型的 ETH 兼容转账 |
| 14 | **UTXO Core** (UTXO 核心操作) | `ca/transaction/utxo_core.cpp/h` | UTXO | UTXO 集合的底层增删查改 |
| 15 | **Gas Fee Payment** (Gas 付费) | EIP-1559 `fee_calculator.h` | 费用 | 动态 Gas 费用计算与扣除 |
| 16 | **Batch Transaction** (批量交易) | `ca/dispatchtx.cpp`【推测】 | 批量 | 批量提交多笔交易 |

> 注: 类型 13-16 标注【推测】, 为基于代码结构和功能描述的推断, 需人工验证具体数量与边界。

---

## 三、跨模块交易流程

以一笔 **Stake (质押)** 交易为例，展示横跨多个模块的完整流程：

```
用户 RPC 请求
    │
    ▼
[rpc/]  RPC 参数校验 → param_handle.cpp
[api/]  HTTP 路由分发 → http_api.cpp
    │
    ▼
[ca/]   交易构造 → ca/transaction/stake.cpp
[utils/] 签名验证 → crypto.cpp (ECDSA)
    │
    ▼
[ca/]   交易缓存 → transaction_cache.cpp (入池/去重)
[net/]  广播分发 → dispatchtx.cpp → net/api.cpp (P2P)
    │
    ▼
[ca/]   打包节点 VRF 选择 → vrf_consensus.cpp
[ca/]   区块构造 (含 Stake 交易) → algorithm.cpp
[ca/]   UTXO 操作 → utxo_core.cpp (锁定质押 UTXO)
    │
    ▼
[ca/]   区块验证 → check_blocks.cpp
[ca/]   区块保存 → block_helper.cpp
[db/]   写入 RocksDB → db_api.cpp
    │
    ▼
[ca/]   共识签名收集 → vrf_consensus.cpp
    │
    ▼
  最终确认 — 质押生效
```

### 涉及的模块 (按调用顺序)

| 顺序 | 模块 | 文件 | 操作 |
|------|------|------|------|
| 1 | RPC | `param_handle.cpp` | 参数解析与校验 |
| 2 | API | `http_api.cpp` | 路由到对应处理函数 |
| 3 | CA (交易) | `stake.cpp` | 构造质押交易对象 |
| 4 | Crypto | `crypto.cpp` | ECDSA 签名验证 |
| 5 | TxPool | `transaction_cache.cpp` | 入池/去重 |
| 6 | Network | `dispatchtx.cpp`, `api.cpp` | P2P 广播 |
| 7 | Consensus | `vrf_consensus.cpp` | VRF 打包节点选择 |
| 8 | Consensus | `algorithm.cpp` | 区块构造 |
| 9 | UTXO | `utxo_core.cpp` | UTXO 选择与锁定 |
| 10 | Consensus | `block_helper.cpp` | 区块保存 |
| 11 | Storage | `db_api.cpp` | RocksDB 事务写入 |

---

## 四、阶段3 核心流程文档索引

每条流程包含 4 份分析文档: 时序流 (sequence_flow), 调用栈 (call_stack), 状态转换 (state_transition), 异步任务流 (async_task_flow)。

| 流程 | 目录 | 内容 | 涉及模块 |
|------|------|------|---------|
| **Flow 01: 交易生命周期** | `../../03_core_flows/flow-01-tx-lifecycle/` | 从 RPC 请求到最终确认的完整交易流程 | RPC, CA, TxPool, Network, UTXO, DB |
| **Flow 02: 区块同步** | `../../03_core_flows/flow-02-block-sync/` | 快同步/从零同步/增量同步策略 | CA (sync_block), Network, DB |
| **Flow 03: 治理流程** | `../../03_core_flows/flow-03-governance/` | 质押/委托/投票/提案全流程 | CA (governance), UTXO, DB |
| **Flow 04: EVM 合约** | `../../03_core_flows/flow-04-evm-contract/` | 合约部署与调用的 EVM 执行流程 | EVM, MPT, Contract, DB |
| **Flow 05: 激励分配** | `../../03_core_flows/flow-05-incentive/` | 奖励计算/领取/国库分配流程 | CA (bonus/fund), DB |
| **Flow 06: 启动流程** | `../../03_core_flows/flow-06-startup/` | Init() 7 步启动与线程模型 | main, common, CA, Network, DB |

### Flow 01 文件列表 (交易生命周期最相关)

| 文件 | 路径 | 说明 |
|------|------|------|
| 时序流 | `../../03_core_flows/flow-01-tx-lifecycle/sequence_flow.md` | 交易各阶段的时序交互图 |
| 调用栈 | `../../03_core_flows/flow-01-tx-lifecycle/call_stack.md` | 从 RPC 到 DB 的完整函数调用链 |
| 状态转换 | `../../03_core_flows/flow-01-tx-lifecycle/state_transition.md` | 交易状态机 (pending→confirmed→finalized) |
| 异步任务流 | `../../03_core_flows/flow-01-tx-lifecycle/async_task_flow.md` | 异步线程/定时器任务交互 |

---

## 五、相关文档

| 文档 | 路径 | 说明 |
|------|------|------|
| Flow 01: 交易生命周期 | `../../03_core_flows/flow-01-tx-lifecycle/` | 交易流程 4 文档 |
| Flow 02: 区块同步 | `../../03_core_flows/flow-02-block-sync/` | 同步策略与分叉处理 |
| Flow 03: 治理流程 | `../../03_core_flows/flow-03-governance/` | 质押/委托/投票流程 |
| Flow 04: EVM 合约 | `../../03_core_flows/flow-04-evm-contract/` | 合约部署与执行 |
| Flow 05: 激励分配 | `../../03_core_flows/flow-05-incentive/` | 奖励计算与领取 |
| 模块-UTXO | `../../module-utxo/` | UTXO 选择/花费/双花检测 |
| 模块-交易池 | `../../module-txpool/` | 交易缓存/验证/分发 |
| 模块-RPC | `../../module-rpc/` | 交易创建接口 |
| 模块-DAG共识 | `../../module-dag-consensus/` | 打包/验证/确认 |
| 模块-治理激励 | `../../module-governance-incentive/` | 质押/委托/投票/奖励 |
| 模块-EVM | `../../module-evm/` | 合约交易执行 |
| 模块-网络 | `../../module-network/` | P2P 交易广播 |
| 模块-存储 | `../../module-storage/` | 交易/区块持久化 |
| 架构概览 | `../../architecture_overview.md` | ca/transaction/ 子目录结构 |
| RPC API (GET) | `//wsl$/wsl-mm/home/wbl/mm/HXD/rpc_api_get_doc.md` | GET 接口交易查询 |
| RPC API (POST) | `//wsl$/wsl-mm/home/wbl/mm/HXD/rpc_api_post_doc.md` | POST 接口交易创建 |
