# 17 -- API 参考

> **阶段**: 阶段5 -- 文档重组
> **目录**: `17_api_reference/`
> **用途**: 完整 RPC API 索引、JSON-RPC 2.0 格式说明、精度转换规则

---

## 一、文档索引

| 文档 | 路径 | 说明 |
|------|------|------|
| GET 接口文档 | `//wsl$/wsl-mm/home/wbl/mm/HXD/rpc_api_get_doc.md` | 17个HTTP GET接口：参数定义、响应格式、调用示例 |
| POST 接口文档 | `//wsl$/wsl-mm/home/wbl/mm/HXD/rpc_api_post_doc.md` | 35个JSON-RPC POST接口 + 16个ETH兼容接口：完整请求/响应定义 |
| RPC模块概览 | [../../module-rpc/module_overview.md](../../module-rpc/module_overview.md) | RPC架构三层设计、消息流转、精度转换原理 |

---

## 二、接口总览

| 接口类型 | 数量 | 请求格式 | 用途 |
|---------|------|---------|------|
| **HTTP GET** | 17 | URL参数 `?key=val` | 调试接口、区块浏览、节点监控 |
| **JSON-RPC POST** | 35 | `{"header":{...},"params":{...}}` | 业务接口：查询余额、创建交易、投票治理 |
| **ETH 兼容** | 16 | 标准JSON-RPC 2.0 | 以太坊工具链兼容：MetaMask/Hardhat/Truffle |
| **总计** | **68** | | |

---

## 三、GET 接口清单 (17个)

注册位置: `api/interface/http_api.cpp` 第278-296行

| 路径 | 功能 | 源文件 |
|------|------|--------|
| `/block` | 获取区块列表 (支持分页/HTML/纯文本) | rpc_api_getBlock |
| `/get_block` | 获取区块数据 (JSON格式) | rpc_api_getBlockRequest |
| `/pub` | 获取线程和请求统计 | rpc_api_getPub |
| `/account` | 获取账户列表 | rpc_api_getAccount |
| `/Node` | 获取节点列表 | rpc_api_getNode |
| `/ShowVRFInfo` | 获取 VRF 验证信息 | rpc_api_getVrfInfo |
| `/printCalcHash` | 打印千块汇总 hash | rpc_api_printCalcHash |
| `/printhundredhash` | 打印百块汇总 hash | rpc_api_printHundredSumHash |
| `/printblock` | 打印区块 hash 到文件 | rpc_api_printBlock |
| `/SystemInfo` | 获取系统信息 | rpc_api_getSystemInfo |
| `/printVoteInfo` | 打印投票信息 | rpc_api_printVoteInfo |
| `/printLockAddrs` | 打印锁定地址 | rpc_api_printLockAddrs |
| `/printProposalInfoByHash` | 打印提案详细信息 | rpc_api_printProposalInfo |
| `/printAvailableAssetType` | 打印可用资产类型 | rpc_api_printAssetType |
| `/printAsseTypeByContractAddr` | 根据合约地址查资产类型 | rpc_api_getAssetType |
| `/GetPublicIp` | 获取公网 IP | rpc_api_getPublicIp |
| `/GetRollbackBlocks` | 获取回滚区块信息 | rpc_api_getAllRollBackBlocks |

> GET 接口响应格式: `text/html` 或 `text/plain`，无统一JSON格式框架。

---

## 四、POST 接口清单 (35个)

注册位置: `api/interface/http_api.cpp` 第227-275行

### 基础查询 (11个)

| 方法名 | 功能 |
|--------|------|
| `GetVersion` | 获取客户端、配置、网络和数据库版本信息 |
| `GetBalance` | 获取余额 (支持多资产类型) |
| `GetBlockHeight` | 获取当前区块高度 |
| `GetChainId` | 获取链 ID |
| `GetAccounts` | 获取账户列表 |
| `GetNodeList` | 获取节点列表 |
| `GetAllStakeNodeList` | 获取所有质押节点列表 |
| `GetAddrType` | 获取地址类型 |
| `GetYieldInfo` | 获取收益信息 |
| `GetBonusInfo` | 获取奖励信息 |
| `GetAssetTypeByContractAddr` | 根据合约地址获取资产类型 |

### 投票治理查询 (4个)

| 方法名 | 功能 |
|--------|------|
| `GetVoteAddrs` | 获取投票地址 |
| `GetVoteTxHash` | 获取投票交易 hash |
| `GetAllAssetType` | 获取所有资产类型 |
| `GetAssetTypeInfo` | 获取资产类型信息 |

### 区块交易查询 (13个)

| 方法名 | 功能 |
|--------|------|
| `GetTransactionByHash` | 根据 hash 获取交易 |
| `GetBlockByHash` | 根据 hash 获取区块 |
| `GetBlockByHeight` | 根据高度获取区块 |
| `GetBlockByTransactionHash` | 根据交易 hash 获取区块 |
| `GetDelegatingUtxo` | 获取委托 UTXO |
| `GetStakingUtxo` | 获取质押 UTXO |
| `GetLockUtxo` | 获取锁定 UTXO |
| `GetBlockTransactionCountByHash` | 获取区块交易数量 |
| `GetDelegatingAddrsByBonusAddr` | 根据奖励地址获取委托地址 |
| `GetUtxoDeployerByConAddr` | 根据合约地址获取部署者 |
| `IsContract` | 判断是否为合约 |
| `GetTxByHash` | 根据 hash 获取交易详情 |
| `GetBlockNumberByHash` | 根据 hash 获取区块编号 |

### 创建交易 (14个)

| 方法名 | 功能 |
|--------|------|
| `CreateTransaction` | 创建普通交易 |
| `CreateStakingTransaction` | 创建质押交易 |
| `CreateUnstakingTransaction` | 创建解押交易 |
| `CreateDelegatingTransaction` | 创建委托交易 |
| `CreateUndelegatingTransaction` | 创建取消委托交易 |
| `CreateBonusTransaction` | 创建奖励交易 |
| `CreateCallContractTransaction` | 创建调用合约交易 |
| `CreateDeployContractTransaction` | 创建部署合约交易 |
| `SendMessage` | 发送消息 |
| `SendContractMessage` | 发送合约消息 |
| `CreateLockTransaction` | 创建锁定交易 |
| `CreateUnLockTransaction` | 创建解锁交易 |
| `CreateVoteTransaction` | 创建投票交易 |
| `CreateFundTransaction` | 创建资金交易 |

### 回滚查询 (1个)

| 方法名 | 功能 |
|--------|------|
| `GetRollbackBlocks` | 获取回滚区块信息/编号列表 |

---

## 五、ETH 兼容接口 (16个)

实现位置: `rpc/eth/eth_impl.cpp` + `rpc/eth/eth_rpc_json_def.h`
注册位置: `net/http_server.cpp:278-293` eth_dispatch

| 方法名 | 状态 | 说明 |
|--------|------|------|
| `eth_chainId` | 已实现 | 返回 `0x3027` (12315) |
| `eth_blockNumber` | 已实现 | 返回十六进制当前高度 |
| `eth_gasPrice` | 已实现 | 近100区块平均gas |
| `eth_getBalance` | 已实现 | 精度转换 `10^8 -> 10^18`，blockTag参数实质未生效 |
| `eth_getTransactionCount` | 已实现 | 返回nonce计数 |
| `eth_sendRawTransaction` | 已实现 | 支持部署/调用/转账三种类型 |
| `eth_getTransactionReceipt` | 已实现 | 完整收据字段 |
| `eth_call` | 已实现 | 只读合约调用 |
| `eth_getBlockByNumber` | 已实现 | 支持 `fullTx` 参数 |
| `eth_getBlockByHash` | 已实现 | 完整区块字段 |
| `eth_getCode` | 已实现 | 返回合约字节码 |
| `eth_getTransactionByHash` | 已实现 | 完整交易字段 |
| `eth_estimateGas` | 已实现 | **固定返回 `"1"`** (未实现实际估算) |
| `eth_accounts` | 已实现 | 返回本地账户列表 |
| `eth_getBlockReceipts` | 已实现 | -- |
| `eth_feeHistory` | 部分实现 | 已定义结构体但实现不完整 |

### 已知缺失的 ETH 方法

| 方法名 | 影响 |
|--------|------|
| `eth_getLogs` / `eth_newFilter` | 事件日志过滤不可用 |
| `eth_getStorageAt` | 无法直接读取合约存储 |
| `eth_subscribe` / `eth_unsubscribe` | WebSocket 订阅不可用 |
| `eth_sign` / `personal_sign` | 签名接口缺失 |

---

## 六、JSON-RPC 2.0 格式说明

### POST 原生接口格式

MeMeChain 原生 POST 接口使用自定义的 JSON-RPC 2.0 包装格式：

```json
{
  "header": {
    "id": "1",
    "jsonrpc": "2.0",
    "method": "GetBalance"
  },
  "params": {
    "addr": "0xabc...",
    "asset_type": "MM"
  }
}
```

- 方法名在 `header.method` 中，不在顶层
- 参数在 `params` 对象中，非数组格式
- 响应格式类似标准 JSON-RPC 2.0

### ETH 兼容接口格式

ETH 兼容接口严格遵循标准 JSON-RPC 2.0：

```json
{
  "jsonrpc": "2.0",
  "method": "eth_getBalance",
  "params": ["0xabc...", "latest"],
  "id": 1
}
```

- 方法名在顶层 `"method"` 字段
- 参数为数组格式 `"params": [...]`
- 支持批量请求 (数组形式)

### 错误格式

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32000,
    "message": "错误描述"
  }
}
```

---

## 七、精度转换规则

### 核心转换规则

| 转换方向 | 公式 | 实现位置 |
|---------|------|---------|
| **10^8 -> 10^18 (上传)** | `amount x 10^10` 返回 hex | `rpc/eth/eth_impl.cpp:444-458` `scale_up_10_8_to_18()` |
| **10^18 -> 10^8 (下传)** | `value / 10^10` 取整 | `rpc/eth/eth_impl.cpp:461-472` `scale_down_10_18_to_8()` |
| **防溢出** | 使用 `unsigned __int128` | scale_up 内部使用128位中间值 |

### 已知精度问题

| 问题 | 位置 | 影响 | 建议 |
|------|------|------|------|
| `eth_gasPrice` 返回 10^8 精度而非 10^18 | `eth_impl.cpp:97-98` | MetaMask 等工具显示的 gas price 错误 | 恢复被注释的 `scale_up_10_8_to_18` 转换 |
| `eth_estimateGas` 固定返回 `"1"` | `eth_impl.cpp:429-435` | Hardhat/Truffle 部署合约时 gas 估算为 1 导致失败 | 实现真实的 Gas 估算 (模拟执行) |
| `gas_average` 未初始化为 0 | `eth_impl.cpp:56` | gasPrice 计算结果包含垃圾值（首次调用） | 添加初始化 `uint64_t gas_average = 0;` |
| `scale_down` 接受 raw bytes 而非 hex 字符串 | `eth_impl.cpp:461-472` | 前端发送 hex 字符串时转换失败 | 支持 hex 格式输入 |

---

## 八、RPC 架构三层设计

```
HTTP 请求
   |
   v
api/interface/http_api.cpp  -- 路由注册 & 请求分发
   |
   +--> GET  /xxx       --> rpc/api/get/rpc_api_*.cpp   -- 直接调用 DBReader
   +--> POST /Method     --> rpc/api/post/rpc_api_*.cpp  -- JSON-RPC 解析引擎
   +--> POST eth_*       --> rpc/eth/eth_impl.cpp        -- ETH_PARAM 宏解析
   |
   v
ca/interface.cpp  -- CA 业务回调注册 (RPC -> CA 桥接)
```

---

## 九、相关文档速查

| 需求 | 查阅文档 |
|------|---------|
| GET 接口详细定义 | `//wsl$/wsl-mm/home/wbl/mm/HXD/rpc_api_get_doc.md` |
| POST 接口详细定义 | `//wsl$/wsl-mm/home/wbl/mm/HXD/rpc_api_post_doc.md` |
| RPC 模块架构与重构建议 | [../../module-rpc/refactor_suggestion.md](../../module-rpc/refactor_suggestion.md) |
| 重构总体规划 | [../15_refactor_analysis/README.md](../15_refactor_analysis/README.md) |

---

*文档生成日期：2026-05-26*
*数据来源：rpc_api_get_doc.md, rpc_api_post_doc.md, 阶段2 RPC模块分析*
