# 16 -- 风险全景图

> **阶段**: 阶段5 -- 文档重组
> **目录**: `16_risk_analysis/`
> **用途**: 重构风险全景视图、Critical 风险 Top 10、按模块/优先级的风险矩阵

---

## 一、文档索引

| 文档 | 路径 | 说明 |
|------|------|------|
| 风险全景总览 | [../../refactor_risk_overview.md](../../refactor_risk_overview.md) | 阶段1输出：高耦合区域、全局单例、循环依赖、模块风险评级 |
| 架构概览 | [../../architecture_overview.md](../../architecture_overview.md) | 阶段1输出：项目目录结构、系统分层、模块职责表 |
| 模块依赖分析 | [../../module_dependency.md](../../module_dependency.md) | 阶段1输出：跨模块 `#include` 依赖与循环依赖 |
| 重构总体规划 | [../../refactor_master_plan.md](../../refactor_master_plan.md) | 阶段4输出：P0-P3完整清单与实施路线 |

---

## 二、风险分布总图

```
高风险区       ████████████████████████████  ca/algorithm.cpp (382KB)
               ████████████████████████      ca/transaction.cpp (128KB)
               ████████████████████████      ca/txhelper.cpp (138KB)
               ██████████████████████        ca/sync_block.cpp (132KB)
               ██████████████████████        api/interface/http_api.cpp (223KB)

中高风险区     ████████████████              ca/advanced_menu.cpp (141KB)
               ████████████████              MagicSingleton 全局单例 (20+ 个)
               ████████████████              ca/global.h 全局可变状态

中风险区       ████████████                  db/db_api.h (81KB 巨型头文件)
               ████████████                  ca/block_helper.cpp (75KB)
               ████████████                  跨模块直接调用 (ca<->net<->rpc)

低风险区       ████████                      utils/ 目录 (73 文件, 职责分散)
               ████████                      net/ 网络层 (相对独立)
               ██████                        mpt/ MPT 实现 (相对独立)
               ████                          contract/ 合约辅助 (小模块)
               ██                            common/ 公共配置 (小模块)
```

---

## 三、Critical 风险 Top 10

### 共识安全类

| # | 风险项 | 位置 | 影响 | 修复工时 |
|---|--------|------|------|---------|
| 1 | **MPT SHA256 与以太坊 Keccak256 不兼容** | `mpt/trie.cpp:429` | 合约状态根哈希无法与以太坊互操作，跨链验证不可行 | 3人日 |
| 2 | **回滚无原子 UTXO 恢复** | `algorithm.cpp:7511` vs `block_helper.cpp:1155` | 回滚后UTXO状态可能不一致导致双花 | 1周 |
| 3 | **区块签名不验证打包节点资格** | `algorithm.cpp:3923` verifyPreSaveBlock_ | 非VRF选中节点也可对区块签名 | 3人日 |
| 4 | **主链选择用75百分位而非共识权重** | `block_helper.cpp:2113` getChainHeight | 与规范定义的DAG共识权重选择不一致 | 1周 |

### 资金安全类

| # | 风险项 | 位置 | 影响 | 修复工时 |
|---|--------|------|------|---------|
| 5 | **年化率取整导致 ~5.8% 超额支付** | `algorithm.cpp:7835` | 所有奖励超额发放，影响代币经济 | 1人日 |
| 6 | **FindUtxo 死代码致锁定期逻辑失效** | `transaction/utxo_core.cpp` | 质押锁定逻辑可能被绕过 | 3人日 |

### 并发安全类

| # | 风险项 | 位置 | 影响 | 修复工时 |
|---|--------|------|------|---------|
| 7 | **`_accountList` 无锁保护** | `account_manager.h:434` | 批量加载时多线程数据竞争 | 1人日 |
| 8 | **`shared_lock` 下执行 `erase()`** | `transaction_cache.cpp:1356` | 读锁下修改容器，UB/崩溃 | 1人日 |

### 可用性类

| # | 风险项 | 位置 | 影响 | 修复工时 |
|---|--------|------|------|---------|
| 9 | **交易池无容量限制/超时淘汰** | `transaction_cache.cpp` | DoS攻击可OOM，内存膨胀 | 3人日 |
| 10 | **DB损坏直接 `exit(-1)`** | `rocksdb.cpp:18` | 无优雅关闭，WAL未flush | 1人日 |

---

## 四、按模块风险矩阵

| 模块 | 代码规模 | 风险等级 | 耦合度 | 可测试性 | 关键风险点 |
|------|---------|---------|--------|---------|-----------|
| **ca/** | ~1.2MB | **Critical** | 极高 | 极低 | 共识核心、巨型文件、全局状态、VRF双实现 |
| **api/interface/** | ~350KB | **High** | 高 | 低 | 注册中心单文件过大、所有路由集中 |
| **rpc/api/** | ~140文件 | **High** | 高 | 中 | 参数校验缺失、ETH精度不兼容 |
| **net/** | ~500KB | **Medium** | 中 | 中 | 相对独立，但handle_event复杂、httplib内嵌 |
| **db/** | ~170KB | **Medium** | 低 | 中 | 巨型头文件db_api.h、接口粒度过细 |
| **utils/** | ~73文件 | **Medium** | 中 | 中 | 职责分散、工具混杂、MagicSingleton泛滥 |
| **mpt/** | ~13文件 | **Low** | 低 | 高 | SHA256 vs Keccak256不兼容 |
| **contract/** | ~9文件 | **Low** | 低 | 高 | #if 0 废弃代码过多 |
| **common/** | ~15文件 | **Low** | 低 | 高 | 配置与创世混放、任务池耦合 |
| **ca/evm/** | ~7文件 | **High** | 中 | 低 | 超时线程泄漏、Gas无限制 |

---

## 五、循环依赖热点

| 区域 | 循环 | 风险等级 | 说明 |
|------|------|---------|------|
| ca <-> net | ca 调 net 发送消息, net 回调调 ca 处理 | **Medium** | 通过 Protobuf 回调机制部分解耦 |
| ca <-> rpc | ca 注册 RPC 回调, rpc 调 ca 执行业务 | **Medium** | 通过 interface.cpp 解耦但非完全 |
| ca <-> ca/evm | ca 调 EVM 执行, EVM 回调 ca 访问状态 | **Medium** | evmc::Host 接口提供解耦 |
| ca/transaction <-> db | 交易处理读写 db, db 层不依赖 ca | **Low** | 单向依赖, 风险可控 |

---

## 六、区块链专项风险

| 风险领域 | 发现 | 严重程度 |
|---------|------|---------|
| **UTXO + EVM 状态原子性** | `ca/transaction.cpp` 和 `ca/evm/evm_host.cpp` 独立处理 UTXO 和 EVM 状态，原子性保障不清晰 | **Critical** |
| **DAG 分叉处理** | `ca/sync_block.cpp` (132KB) 中分叉逻辑和同步逻辑混杂 | **High** |
| **并发安全** | `ca/global.h` 中 `static std::mutex` 全局锁，锁粒度与获取顺序不明确 | **High** |
| **VRF 随机性** | `ca/algorithm.cpp` 中 VRF 选择逻辑与大文件混杂，难以独立审查 | **High** |
| **年化激励计算** | 时间源依赖、整型精度风险 | **Medium** |
| **RocksDB 事务性** | `db/db_api.h` 声明了大量单键操作，WriteBatch 使用模式需确认 | **Medium** |
| **治理(锁定/解锁)** | 分散在 `lock.cpp`, `vote.cpp` 等6+个文件 | **Medium** |
| **双花防护** | `double_spend_cache.cpp` 设计正确性未验证 | **High** |

---

## 七、架构健康度评分

| 维度 | 评分 | 说明 |
|------|------|------|
| 模块边界 | **3/10** | CA 模块承载过多职责，交易/共识/EVM/同步混杂 |
| 耦合度 | **3/10** | MagicSingleton 导致隐式全局耦合，无法独立测试 |
| 代码组织 | **4/10** | 6 个巨型文件(>100KB)，65% 代码集中在 10 个文件中 |
| 并发安全 | **4/10** | _accountList 无锁、shared_lock下erase、EVM超时线程泄漏 |
| 测试覆盖 | **1/10** | 仅 8 个测试文件，无共识/交易/EVM 行为测试 |
| 错误恢复 | **3/10** | DB损坏直接 exit(-1)、回滚路径不一致、信号用 _exit() |
| 规范一致性 | **5/10** | MPT SHA256 vs Keccak256、共识阈值混乱、Key前缀命名偏差 |
| **综合** | **3.3/10** | **需要系统性重构** |

---

## 八、各模块问题清单索引

| 模块 | 问题清单文档 |
|------|-------------|
| 密码学 | [../../module-crypto/refactor_suggestion.md](../../module-crypto/refactor_suggestion.md) |
| 存储层 | [../../module-storage/refactor_suggestion.md](../../module-storage/refactor_suggestion.md) |
| UTXO | [../../module-utxo/refactor_suggestion.md](../../module-utxo/refactor_suggestion.md) |
| DAG共识 | [../../module-dag-consensus/refactor_suggestion.md](../../module-dag-consensus/refactor_suggestion.md) |
| EVM集成 | [../../module-evm/refactor_suggestion.md](../../module-evm/refactor_suggestion.md) |
| 网络层 | [../../module-network/refactor_suggestion.md](../../module-network/refactor_suggestion.md) |
| 交易池 | [../../module-txpool/refactor_suggestion.md](../../module-txpool/refactor_suggestion.md) |
| 治理激励 | [../../module-governance-incentive/refactor_suggestion.md](../../module-governance-incentive/refactor_suggestion.md) |
| RPC服务 | [../../module-rpc/refactor_suggestion.md](../../module-rpc/refactor_suggestion.md) |
| 特殊功能 | [../../module-special/refactor_suggestion.md](../../module-special/refactor_suggestion.md) |

---

## 九、相关文档速查

| 需求 | 查阅文档 |
|------|---------|
| 重构总体规划 | [../15_refactor_analysis/README.md](../15_refactor_analysis/README.md) |
| API参考 | [../17_api_reference/README.md](../17_api_reference/README.md) |
| 序列图 | [../18_sequence_diagrams/README.md](../18_sequence_diagrams/README.md) |
| 架构概览 | [../01_architecture/README.md](../01_architecture/README.md) |

---

*文档生成日期：2026-05-26*
*数据来源：阶段1-4 共 94 份分析文档*
