# 07 -- Storage / RocksDB 存储层

> **阶段 5 重组索引** | 关联目录: `../../module-storage/`
> **上游**: [06_network](../06_network/) | **下游**: [08_rpc](../08_rpc/)

---

## 1. 概览

存储层是 MeMeChain 区块链最底层基础设施，使用 RocksDB TransactionDB 模式提供原子性多键事务支持。所有数据以 Key-Value 形式存储在同一默认 Column Family 中，通过 Key 前缀区分业务数据类型。提供 DBReader (只读) 和 DBReadWriter (读写事务) 两种访问模式。

**核心特性**: TransactionDB 原子事务 + 读写分离 + Key 前缀命名空间 + 无 Column Family。

---

## 2. 架构层次

```
共识层 (CA) ──→ 合约层 (EVM/MPT) ──→ 网络层 ──→ RPC 层
                    │
              ┌─────▼──────────────────────────────┐
              │       存储层 (db/)                   │
              │                                     │
              │  DBReader (只读)   DBReadWriter (事务) │
              │       │                │              │
              │       └───────┬────────┘              │
              │               ▼                       │
              │    RocksDBDataReader                  │
              │    RocksDBReadWriter                  │
              │               │                       │
              │               ▼                       │
              │    RocksDB (MagicSingleton 全局单例)    │
              │               │                       │
              │               ▼                       │
              │    rocksdb::TransactionDB*             │
              └──────────────────────────────────────┘
```

**依赖方向**: 所有上层模块 (ca/net/rpc/mpt/contract) 依赖存储层，存储层本身不依赖任何业务模块，仅依赖 RocksDB 库。

---

## 3. Key 前缀规范 -- 核心数据域

### 3.1 区块域

| 前缀 | 常量 | Key 模式 | Value | 操作 |
|------|------|---------|-------|------|
| `blkht2blkhs_` | BLOCK_HEIGHT_TO_BLOCK_HASH | `{prefix}{height}` | `hash1_hash2_` (下划线分隔, DAG 支持) | mergeValue / readData |
| `blkhs2blkht_` | BLOCK_HASH_TO_BLOCK_HEIGHT | `{prefix}{blockHash}` | `{height}` (十进制字符串) | writeData / readData |
| `blkhs2blkraw_` | BLOCK_HASH_TO_BLOCK_RAW | `{prefix}{blockHash}` | Protobuf 序列化区块 | writeData / readData |
| `blkht2sumhs_` | BLOCK_HEIGHT_TO_SUM_HASH | `{prefix}{height}` (height % 100 == 0) | SHA256 汇总哈希 | writeData / readData |
| `ht2thousandsumhs_` | BLOCK_HEIGHT_TO_THOUSAND_SUM_HASH | `{prefix}{height}` (height % 1000 == 0) | SHA256 千块校验哈希 | writeData / readData |
| `blktop_` | BLOCK_TOP | `{prefix}` | `{height}` (当前最高高度) | writeData / readData |
| `thousandsumhstop_` | THOUSAND_SUM_HASH_TOP | `{prefix}` | 千区块汇总顶部编号 | writeData / readData |

### 3.2 交易域

| 前缀 | 常量 | Key 模式 | Value |
|------|------|---------|-------|
| `txhs2txraw_` | TRANSACTION_HASH_TO_TRANSACTION_RAW | `{prefix}{txHash}` | Protobuf 序列化交易 |
| `txhs2blkhs_` | TRANSACTION_HASH_TO_BLOCK_HASH | `{prefix}{txHash}` | `{blockHash}` |
| `rlphash2txhash_` | RLP_HASH_TO_INTERNAL_HASH | `{prefix}{rlpHash}` | `{internalTxHash}` |

### 3.3 UTXO 与余额域

| 前缀 | 常量 | Key 模式 | Value |
|------|------|---------|-------|
| `addr2utxo_` | ADDRESS_TO_UTXOS | `{prefix}{addr}{asset}` | `utxoHash1_utxoHash2_` |
| `utxohash2utxovalue_` | UTXO_HASH_TO_UTXO_VALUE | `{prefix}{addr}_{utxo}_{asset}` | `{value}` (字符串) |
| `addr2bal_` | ADDRESS_TO_BALANCE | `{prefix}{addr}{asset}` | `{balance}` (字符串) |
| `assettype_` | ASSET_TYPE | `{prefix}` | 资产类型列表 |
| `addr2Assettype_` | ADDRESS_TO_ASSET_TYPE | `{prefix}{addr}` | 地址持有的资产类型 |

### 3.4 质押与委托域

| 前缀 | 常量 | Key 模式 |
|------|------|---------|
| `stakeaddr_` | STAKE_ADDRESS | `{prefix}` |
| `addr2stakeutxos_` | ADDRESS_TO_STAKE_UTXOS | `{prefix}{addr}{asset}` |
| `bonusaddr2delegatingaddrutxos_` | BONUS_ADDRESS_TO_DELEGATING_ADDRESS_UTXO | `{prefix}{bonus}_{del}_{asset}` |
| `bonusaddr2delegatingaddrandassettype_` | BONUS_ADDRESS_TO_DELEGATING_ADDRESS_AND_ASSET_TYPE | `{prefix}{bonus}_{del}` |
| `delegatingaddr2bonusaddrandassettype_` | DELEGATING_ADDRESS_TO_BONUS_ADDRESS_AND_ASSET_TYPE | `{prefix}{del}_{bonus}` |

### 3.5 合约/EVM 域

| 前缀 | 常量 | Key 模式 | 说明 |
|------|------|---------|------|
| `contractaddr2contractcode_` | CONTRACT_ADDRESS_TO_CONTRACT_CODE | `{prefix}{contract}` | 合约字节码 |
| `deployeraddr2contractaddr_` | DEPLOYER_ADDRESS_TO_CONTRACT_ADDRESS | `{prefix}{deployer}` | 部署者->合约 |
| `contractaddr2deployutxo_` | CONTRACT_ADDRESS_TO_DEPLOY_UTXO | `{prefix}{contract}` | 部署UTXO |
| `contractaddr2latestutxo_` | CONTRACT_ADDRESS_TO_LATEST_UTXO | `{prefix}{contract}` | 最新UTXO |
| `mptkey2mptvalue_` | MPT_KEY_TO_MPT_VALUE | `{prefix}{key}` | MPT 状态节点 |
| `contractaddr2assettype_` | CONTRACT_ADDRESS_TO_ASSET_TYPE | `{prefix}{contract}` | 合约资产类型 |
| `evmdeployeraddr_` | EVM_DEPLOYER_ADDRESS | `{prefix}` | 部署者地址列表 |
| `addr2nonce_` | ADDRESS_TO_NONCE | `{prefix}{addr}` | EVM nonce |

### 3.6 共识与投票域

| 前缀 | 常量 | Key 模式 | 说明 |
|------|------|---------|------|
| `peroid2signcount_` | PEROID_2_SIGN_COUNT | `{prefix}{period}{addr}` | 周期签名计数 |
| `peroid2blockcount_` | PEROID_2_BLOCK_COUNT | `{prefix}{period}` | 周期区块计数 |
| `peroid2signaddr_` | PEROID_2_SIGN_ADDRESS | `{prefix}{period}` | 周期签名地址 |
| `period2packagercount_` | PERIOD_TO_PACKAGER_COUNT | `{prefix}{period}_{addr}` | 打包者计数 |
| `assettype2approvevoteaddr_` | ASSET_TYPE_TO_APPROVE_VOTE_ADDRESS | `{prefix}{asset}` | 赞成票地址 |
| `assettype2againstvoteaddr_` | ASSET_TYPE_TO_AGAINST_VOTE_ADDRESS | `{prefix}{asset}` | 反对票地址 |
| `assettype2votetxhash_` | ASSET_TYPE_TO_VOTE_TX_HASH | `{prefix}{asset}` | 投票交易哈希 |
| `assettype2proposalinfo_` | ASSET_TYPE_TO_PROPOSAL_INFO | `{prefix}{asset}` | 提案信息 |
| `addr2votecount_` | ADDRESS_TO_VOTE_COUNT | `{prefix}{asset}{addr}` | 投票计数 |

### 3.7 全局统计与回滚域

| 前缀 | 常量 | 说明 |
|------|------|------|
| `totalcirculation_` | TOTAL_CIRCULATION | 总流通量 |
| `totalburnamount_` | TOTAL_BURN_AMOUNT | 总销毁量 |
| `totaldelegateAmount_` | TOTAL_DELEGATE_AMOUNT | 总委托量 |
| `totallockedamount_` | TOTAL_LOCKED_AMOUNT | 总锁定量 |
| `period2totallockedamount_` | PERIOD_TO_TOTAL_LOCKED_AMOUNT | 按周期锁定量 |
| `peroid2burnamount_` | PEROID_2_BURN_AMOUNT | 按周期销毁量 |
| `period2gasamount_` | PERIOD_TO_GAS_AMOUNT | 按周期 Gas 消耗 |
| `rollbackblocks_` | ROLLBACKBLOCKS | 回滚块数据 |
| `rollblocknum_` | ROLLBLOCKNUM | 回滚块编号 |
| `lockaddr_` | LOCK_ADDRESS | 锁定地址 |
| `initver_` | INITIALIZATION_VERSION | 数据库初始化版本 |

> **注意**: 30日锁定数据直接使用地址作为 Key (无前缀隔离), 存在 Key 冲突风险。见 [storage_model.md](../../module-storage/storage_model.md)。

---

## 4. 读写分离模型

```
        ┌─────────────────────────────────┐
        │         上层业务调用              │
        │    ca/ net/ rpc/ contract/ mpt   │
        └────┬────────────────────────┬────┘
             │                        │
        ┌────▼────────────┐   ┌──────▼───────────────────┐
        │   DBReader       │   │   DBReadWriter            │
        │  (只读操作)       │   │  (读写事务)               │
        │                  │   │                          │
        │  readData()      │   │  writeData()             │
        │  multiReadData() │   │  mergeValue()  (追加)     │
        │                  │   │  deleteData()            │
        │                  │   │  removeMergeValue()      │
        │                  │   │  transactionCommit()     │
        │                  │   │  reInitTransaction()     │
        └────────┬─────────┘   └──────────┬───────────────┘
                 │                        │
        ┌────────▼─────────┐   ┌──────────▼───────────────┐
        │  RocksDBDataReader│   │  RocksDBReadWriter       │
        └────────┬─────────┘   └──────────┬───────────────┘
                 │                        │
                 └──────────┬─────────────┘
                            ▼
              MagicSingleton<RocksDB>::GetInstance()
                            │
                            ▼
                 rocksdb::TransactionDB*
```

---

## 5. 数据库初始化

```
DBInit(path) [db/db_api.cpp:83]:
  1. RocksDB::Open(configPath):
     a. options.IncreaseParallelism()       (线程数 = CPU 核数)
     b. options.create_if_missing = true
     c. options.OptimizeLevelStyleCompaction()
     d. TransactionDB::Open(options, txnDBOptions, path, &txnDB)
  2. 创建全局 DBReader / DBReadWriter 实例
  3. 读取 INITIALIZATION_VERSION (initver_) 检查数据库是否已初始化
  4. 首次初始化时写入创世区块数据
```

---

## 6. 事务模型

- **TransactionDB**: 支持 `BeginTransaction -> Put/Delete/Merge -> Commit/Rollback` 原子操作
- **DBReadWriter** 封装事务生命周期: `writeData()` 使用 `txn->Put()`, `mergeValue()` 使用 `Merge`, `deleteData()` 使用 `Delete`
- **reInitTransaction()**: 先 `Rollback()` 再 `Begin()`, 用于区块保存后的事务重启
- **无跨 CF 事务问题**: 仅使用默认 Column Family, 事务自动保证原子性

---

## 7. 规范偏差与风险

| 项目 | 规范定义 | 实际实现 | 风险等级 |
|------|---------|---------|---------|
| Key 前缀命名 | 短前缀 `BH:` `B:` `TX:` | 长前缀 `blkht2blkhs_` `blkhs2blkraw_` | 中 |
| 30日锁定数据 | 未定义 | 无前缀直接用地址, Key 冲突风险 | 高 |
| Column Family | 未指定 | 未使用 (全部默认 CF) | 低 |
| db_api.h 大小 | 无约束 | 2694 行 (81.7KB), 项目最大头文件 | 中 |
| mergeValue 并发 | 无文档 | readForUpdate 与 getMergeValue 有读写竞争 | 中 |
| delete_keys_ 成员 | 无 | 未在任何 cpp 中使用 (废弃) | 低 |

---

## 8. 相关文档

### 阶段 2 -- 模块分析
| 文档 | 路径 |
|------|------|
| 存储模块总览 | `../../module-storage/module_overview.md` |
| 存储模型详解 (Key 前缀完整对照) | `../../module-storage/storage_model.md` |
| 存储类分析 | `../../module-storage/class_analysis.md` |
| 存储调用链 | `../../module-storage/call_chain.md` |
| 存储状态流 | `../../module-storage/state_flow.md` |
| 存储线程模型 | `../../module-storage/thread_model.md` |
| 存储重构建议 | `../../module-storage/refactor_suggestion.md` |

### 阶段 1 -- 全局架构
| 文档 | 路径 |
|------|------|
| 架构总览 (db/ 目录结构) | `../../architecture_overview.md` |
| 模块依赖 (db 为最底层) | `../../module_dependency.md` |

### 阶段 4 -- 重构规划
| 文档 | 路径 |
|------|------|
| 重构总体规划 (DBInit/Key 前缀相关) | `../../refactor_master_plan.md` |
