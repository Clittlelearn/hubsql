# MeMeChain 项目文档库

> **项目**: MeMeChain (`mm`)
> **语言**: C++20 | **构建**: CMake | **共识**: VRF-DAG | **存储**: RocksDB | **EVM**: evmone
> **文档版本**: 阶段5 -- 文档重组
> **生成日期**: 2026-05-26
> **文档总量**: ~99 份 (含阶段1-4输出 + 各模块/流程分析文档)

---

## 一、项目简介

MeMeChain 是一个基于 **UTXO + 账户混合模型**、**VRF 随机选择打包节点**、**DAG 区块结构**的区块链节点工程。核心特性：

- 共识机制: VRF (Verifiable Random Function) 选择打包节点，DAG 并行出块
- 双账户模型: UTXO (安全/隐私) + 账户 (EVM 兼容)
- EVM 兼容: 基于 evmone 引擎，支持 Solidity 智能合约
- ETH RPC 兼容: 16个标准以太坊 JSON-RPC 方法，可与 MetaMask/Hardhat/Truffle 对接
- 治理系统: 链上投票 + 质押经济 + 年化率激励
- 存储: RocksDB TransactionDB，支持 WriteBatch 原子写入
- 网络: epoll 事件循环 + Protobuf 序列化 + ECDH 加密

**当前架构健康度**: 3.3/10 -- 需要系统性重构 (详见 `15_refactor_analysis/README.md`)

---

## 二、文档库结构总览

```
阶段5/
├── README.md                          # 本文件 -- 总导航
├── 00_project_overview/               # 项目概述、背景、核心概念
├── 01_architecture/                   # 系统架构: 分层设计、模块职责、第三方依赖
├── 02_build_system/                   # 构建系统: CMakeLists、编译配置、依赖管理
├── 03_core_modules/                   # 核心模块: 共识/交易/同步/EVM/网络/存储
├── 04_transaction_flow/               # 交易流程: 创建->签名->入池->执行->确认
├── 05_block_flow/                     # 区块流程: 出块->验证->同步->分叉解决
├── 06_network/                        # 网络层: P2P通信、节点发现、消息协议
├── 07_storage/                        # 存储层: RocksDB Schema、读写分离、事务
├── 08_rpc/                            # RPC服务: JSON-RPC 2.0、HTTP路由、回调注册
├── 09_evm/                            # EVM集成: evmone宿主、预编译、Gas计算
├── 10_contract/                       # 合约体系: 部署、调用、MPT状态树
├── 11_crypto/                         # 密码学: ECDSA、VRF、Keccak、密钥库
├── 12_consensus/                      # 共识机制: VRF选择、DAG权重、打包验证
├── 13_threading/                      # 并发模型: 线程池、异步任务、锁策略
├── 14_state_machine/                  # 状态机: 交易/区块/同步/治理状态转换
├── 15_refactor_analysis/              # [本阶段] 重构分析汇总: P0-P3清单、工时预估
├── 16_risk_analysis/                  # [本阶段] 风险全景图: Critical Top10、风险矩阵
├── 17_api_reference/                  # [本阶段] API参考: GET 17+POST 35+ETH 16
├── 18_sequence_diagrams/              # [本阶段] 时序图索引: 6流程 + 10模块 全部图表
└── 19_agent_context/                  # Agent上下文: 分析提示词、元数据
```

### 各目录简要说明

| 目录 | 内容 | 主要受众 |
|------|------|---------|
| `00_project_overview/` | 项目背景、代币经济、核心概念、技术栈 | 新人、产品经理 |
| `01_architecture/` | 系统分层、模块职责、目录结构、入口点 | 架构师、Tech Lead |
| `02_build_system/` | CMake配置、编译选项、依赖版本、构建脚本 | DevOps、构建工程师 |
| `03_core_modules/` | 共识层/执行层/存储层/网络层的职责和边界 | 架构师、后端开发 |
| `04_transaction_flow/` | 交易完整生命周期: 创建到确认/回滚 | 后端开发、安全审计 |
| `05_block_flow/` | 区块生成、验证、同步、分叉解决 | 共识工程师 |
| `06_network/` | P2P网络、消息协议、节点管理、加密通道 | 网络工程师 |
| `07_storage/` | RocksDB Schema、Key设计、读写事务 | 存储工程师 |
| `08_rpc/` | JSON-RPC接口、HTTP服务、请求分发 | 前端、DApp开发者 |
| `09_evm/` | EVM集成、合约执行、Host接口 | 智能合约开发者 |
| `10_contract/` | 合约部署、预编译、MPT状态存储 | 合约开发者 |
| `11_crypto/` | 密码学原语、VRF证明、密钥管理 | 安全工程师 |
| `12_consensus/` | VRF共识、DAG权重、打包节点选择 | 共识算法工程师 |
| `13_threading/` | 线程模型、锁策略、异步任务 | 性能工程师 |
| `14_state_machine/` | 交易/区块/同步/治理的状态转换 | 全栈开发 |
| `15_refactor_analysis/` | P0-P3问题清单、工时预估、实施路线 | 重构工程师 |
| `16_risk_analysis/` | Critical风险Top10、风险矩阵、区块链专项风险 | 安全审计员 |
| `17_api_reference/` | 完整API索引 (GET+POST+ETH)、精度规则 | 前端、集成开发 |
| `18_sequence_diagrams/` | 全部时序/流程/状态图索引 | 所有技术角色 |
| `19_agent_context/` | 分析所用的提示词模板、分析元数据 | AI/工具开发者 |

---

## 三、按角色推荐阅读路径

### 新开发者 (7步入门)

```
00_project_overview → 01_architecture → 02_build_system → 03_core_modules
→ 04_transaction_flow → 05_block_flow → 17_api_reference
```

1. [00_project_overview/](./00_project_overview/) -- 了解项目是什么，核心概念
2. [01_architecture/](./01_architecture/) -- 理解系统分层和模块关系
3. [02_build_system/](./02_build_system/) -- 搭建本地开发环境
4. [03_core_modules/](./03_core_modules/) -- 深入核心模块职责
5. [04_transaction_flow/](./04_transaction_flow/) -- 走通交易全流程
6. [05_block_flow/](./05_block_flow/) -- 理解区块生成和同步
7. [17_api_reference/](./17_api_reference/) -- 学习如何通过API与链交互

### 架构师 (6步深入)

```
01_architecture → 12_consensus → 04_transaction_flow → 05_block_flow
→ 13_threading → 14_state_machine → 15_refactor_analysis
```

1. [01_architecture/](./01_architecture/) -- 全面了解系统设计
2. [12_consensus/](./12_consensus/) -- 深入VRF共识和DAG机制
3. [04_transaction_flow/](./04_transaction_flow/) -- 理解UTXO+EVM双模型交互
4. [05_block_flow/](./05_block_flow/) -- 理解分叉检测和解决策略
5. [13_threading/](./13_threading/) -- 审查并发模型和锁策略
6. [14_state_machine/](./14_state_machine/) -- 掌握系统状态转换逻辑
7. [15_refactor_analysis/](./15_refactor_analysis/) -- 审查重构规划和架构评分

### 安全审计员 (6步重点)

```
16_risk_analysis → 11_crypto → 12_consensus → 04_transaction_flow
→ 09_evm → 13_threading
```

1. [16_risk_analysis/](./16_risk_analysis/) -- 从风险全景图开始，了解全部已知风险
2. [11_crypto/](./11_crypto/) -- 审查密码学实现，双曲线问题
3. [12_consensus/](./12_consensus/) -- 审查共识安全，区块签名验证
4. [04_transaction_flow/](./04_transaction_flow/) -- 审查UTXO+EVM原子性
5. [09_evm/](./09_evm/) -- 审查EVM执行安全性，Gas限制
6. [13_threading/](./13_threading/) -- 审查并发数据竞争

### 重构工程师 (5步执行)

```
15_refactor_analysis → 16_risk_analysis → 03_core_modules
→ 各模块 refactor_suggestion → 18_sequence_diagrams
```

1. [15_refactor_analysis/](./15_refactor_analysis/) -- 从总体规划开始，了解P0-P3全貌
2. [16_risk_analysis/](./16_risk_analysis/) -- 了解风险等级和修复优先级
3. [03_core_modules/](./03_core_modules/) -- 理解模块边界和当前耦合情况
4. 各模块 refactor_suggestion.md:
   - [module-crypto](../../module-crypto/refactor_suggestion.md)
   - [module-storage](../../module-storage/refactor_suggestion.md)
   - [module-utxo](../../module-utxo/refactor_suggestion.md)
   - [module-dag-consensus](../../module-dag-consensus/refactor_suggestion.md)
   - [module-evm](../../module-evm/refactor_suggestion.md)
   - [module-network](../../module-network/refactor_suggestion.md)
   - [module-txpool](../../module-txpool/refactor_suggestion.md)
   - [module-governance-incentive](../../module-governance-incentive/refactor_suggestion.md)
   - [module-rpc](../../module-rpc/refactor_suggestion.md)
   - [module-special](../../module-special/refactor_suggestion.md)
5. [18_sequence_diagrams/](./18_sequence_diagrams/) -- 参考时序图理解调用链再动手

---

## 四、关键发现速查 -- 最重要的 5 个 Critical 问题

| # | 问题 | 风险 | 工时 | 详情 |
|---|------|------|------|------|
| 1 | **MPT SHA256 与以太坊 Keccak256 不兼容** | 跨链验证不可行 | 3人日 | [refactor_master_plan.md P0-1](../../refactor_master_plan.md) |
| 2 | **回滚无原子 UTXO 恢复** | 双花风险 | 1周 | [refactor_master_plan.md P0-2](../../refactor_master_plan.md) |
| 3 | **区块签名不验证打包节点资格** | 非VRF节点可签名 | 3人日 | [refactor_master_plan.md P0-3](../../refactor_master_plan.md) |
| 4 | **年化率取整导致 ~5.8% 超额支付** | 代币经济破坏 | 1人日 | [refactor_master_plan.md P0-4](../../refactor_master_plan.md) |
| 5 | **交易池无容量限制/超时淘汰** | DoS可OOM | 3人日 | [module-txpool](../../module-txpool/refactor_suggestion.md) |

> 完整清单见 [15_refactor_analysis/README.md](./15_refactor_analysis/README.md) 和 [16_risk_analysis/README.md](./16_risk_analysis/README.md)

---

## 五、架构健康度评分

| 维度 | 评分 | 说明 |
|------|------|------|
| 模块边界 | **3/10** | CA 模块承载过多职责 |
| 耦合度 | **3/10** | MagicSingleton 全局单例泛滥 |
| 代码组织 | **4/10** | 6个巨型文件(>100KB) |
| 并发安全 | **4/10** | 多处数据竞争和锁误用 |
| 测试覆盖 | **1/10** | 仅8个测试文件 |
| 错误恢复 | **3/10** | DB损坏直接exit |
| 规范一致性 | **5/10** | 共识阈值混乱、Key命名偏差 |
| **综合** | **3.3/10** | **需要系统性重构** |

---

## 六、文档统计

| 阶段 | 文档数 | 产出 |
|------|--------|------|
| 阶段1 -- 全局架构扫描 | 5 | architecture_overview, refactor_risk_overview, module_dependency, startup_flow |
| 阶段2 -- 模块深度分析 | 70 | 10模块 x 7类文档 (module_overview, call_chain, state_flow, class_analysis, thread_model, storage_model, refactor_suggestion) |
| 阶段3 -- 核心流程分析 | 24 | 6流程 x 4类文档 (sequence_flow, state_transition, call_stack, async_task_flow) |
| 阶段4 -- 重构总体规划 | 1 | refactor_master_plan (P0-P3完整清单 + Strangler Fig实施策略) |
| 阶段5 -- 文档重组 | 5 | 4个专题索引 + 1个总导航 (本文件) |
| 规范文档 | 2 | rpc_api_get_doc.md, rpc_api_post_doc.md |
| **合计** | **~107** | |

---

## 七、源代码与规范文档链接

| 资源 | 路径 |
|------|------|
| 源代码根目录 | `/home/wbl/mm/` (WSL: `//wsl$/wsl-mm/home/wbl/mm/`) |
| GET API 规范 | `//wsl$/wsl-mm/home/wbl/mm/HXD/rpc_api_get_doc.md` |
| POST API 规范 | `//wsl$/wsl-mm/home/wbl/mm/HXD/rpc_api_post_doc.md` |
| 协议规范 | `//wsl$/wsl-mm/home/wbl/mm/HXD/spec_dev.md` |
| 架构概览 | [../../architecture_overview.md](../../architecture_overview.md) |
| 模块依赖 | [../../module_dependency.md](../../module_dependency.md) |
| 启动流程 | [../../startup_flow.md](../../startup_flow.md) |
| 风险全景 | [../../refactor_risk_overview.md](../../refactor_risk_overview.md) |
| 重构总规划 | [../../refactor_master_plan.md](../../refactor_master_plan.md) |

---

## 八、快速进入

- 我想了解项目是什么 -- [00_project_overview/](./00_project_overview/)
- 我想知道有哪些风险需要立刻修复 -- [16_risk_analysis/](./16_risk_analysis/)
- 我想查某个 API 的调用方式 -- [17_api_reference/](./17_api_reference/)
- 我想看交易怎么从头走到尾 -- [18_sequence_diagrams/](./18_sequence_diagrams/) → flow-01
- 我想评估重构工作量 -- [15_refactor_analysis/](./15_refactor_analysis/)
- 我想了解 EVM 怎么集成的 -- [09_evm/](./09_evm/) + [10_contract/](./10_contract/)
- 我想审查共识安全性 -- [12_consensus/](./12_consensus/) + [16_risk_analysis/](./16_risk_analysis/)
- 我想搭建开发环境 -- [02_build_system/](./02_build_system/)

---

## 九、命名空间速查

当前项目使用以下命名空间层级 (重构后目标):

```cpp
// 旧 → 新映射
mmc::rpc    → memechain::rpc
mmc::ca     → memechain::core
mmc::net    → memechain::net

// 目标命名空间树
memechain::core::{consensus, block, sync, txpool, utxo, governance}
memechain::execution::{evm, mpt, gas}
memechain::interface::{rpc, eth}
memechain::infra::{store, net, config}
memechain::crypto::{vrf, keystore}
memechain::app::{cli, init}
```

---

*文档生成日期：2026-05-26*
*维护者：按需更新，每次重大重构后同步修改本索引*
