# 05 -- Block Flow / 区块生命周期

> **阶段 5 重组索引** | 关联目录: `../../module-dag-consensus/`, `../../03_core_flows/flow-02-block-sync/`
> **上游**: [04_transaction_flow](../04_transaction_flow/) | **下游**: [06_network](../06_network/)

---

## 1. 概览

MeMeChain 采用 DAG 区块结构，同一高度允许多个分叉区块共存，通过 VRF 共识权重选择主链。每个新区块经历 **创建 -> 验证 -> 保存 -> 广播 -> 确认** 五个阶段。

---

## 2. 区块生命周期五阶段

| 阶段 | 触发条件 | 核心函数 | 所在文件 | 关键操作 |
|------|---------|---------|---------|---------|
| **1. 创建** | VRF 选定打包节点, 每 10s 周期 | `BuildBlock()`, `composeEndBlockMessage()` | `ca/algorithm.cpp`, `ca/block_stroage.cpp` | 收集交易 -> 计算 Merkle -> 签名 -> 生成区块哈希 (SHA256, 不含hash/signature字段) |
| **2. 验证** | 接收广播块 / 同步收到块 | `memVerifyBlock()` -> `VerifyBlock()` -> `verifyPreSaveBlock_()` | `ca/algorithm.cpp:3759-3938` | 四阶段流水线: 内存预验 -> 完整验证(prevhash/高度/时间/交易/合约) -> 预保存验证(签名数量==kConsensus) -> 保存 |
| **3. 保存** | 验证通过后 | `SaveBlock()`, `BlockHelper::Process()` | `ca/block_helper.cpp`, `ca/block_stroage.cpp` | 五级缓存处理: broadcast -> sync -> fastSync -> utxoMissing -> hashPending; 写入 RocksDB (BH/B 前缀) |
| **4. 广播** | 保存成功后 | `HandleBroadcastMsg()`, `BroadcastBlock()` | `net/handle_event.cpp:777-999` | Cycliclist 环形邻居传播; 低于阈值高度随机选15节点, 高于阈值仅广播给质押节点 |
| **5. 确认** | 后续区块引用 | `getChainHeight()`, `BlockStatus` 追踪 | `ca/block_helper.cpp:2113-2177`, `ca/block_stroage.cpp` | 取节点高度第75百分位为全网高度; BlockStatusWrapper 内存追踪每个区块验证状态 |

---

## 3. DAG 分叉处理

### 3.1 多区块共存机制

| 维度 | 实现 |
|------|------|
| **存储结构** | Key `blkht2blkhs_{height}` -> Value `hash1_hash2_hash3_` (下划线分隔多哈希) |
| **主链选择** | 取节点高度第 **75 百分位** 作为全网高度 (规范为 51%, 实际更保守) |
| **权重累计** | 规范定义三级优先级(共识权重 > 最长链 > 时间戳), 实现仅简单高度分位统计 |
| **分叉检测** | 10s 周期向质押节点查询 +/-100 高度范围, 80% 响应阈值 |

> **偏差**: 规范定义51%阈值为主链选择, 实现使用75%。缺少按共识权重的 DAG 级别比较。详见 [module-dag-consensus 偏差表](../../module-dag-consensus/module_overview.md#4-key-findings-summary)。

### 3.2 分叉解决流程

```
分叉检测 (sync_block.cpp) -> 查询质押节点高度 -> 51%/75%共识判定
  |
  +-- 本地方案一致 -> 继续
  +-- 本地方案不一致 -> rollback_block_() -> 回滚到分叉点 -> 重新同步
```

---

## 4. 回滚机制

| 回滚类型 | 入口函数 | 触发场景 | 深度保护 |
|---------|---------|---------|---------|
| **按高度回滚** | `RollBackToHeight()` (algorithm.cpp:7511) | 共识判定分叉失败 | 从 top 向下遍历收集所有区块, 批量删除 |
| **按哈希回滚** | `RollbackBlock()` (block_helper.cpp:1155) | 单个区块损坏 | 从远程获取新区块, 调用 `DeleteBlock` 替换 |
| **快速同步回滚** | `rollback_block_()` (sync_block.cpp) | 快速同步 hash 不满足 66% 共识 | `runFastSyncCount >= 5` 后彻底放弃 |

> **风险**: 回滚逻辑分散在 3 个文件 (algorithm/block_helper/sync_block), 缺少 UTXO 恢复原子性保证。`RollBackTime = 15s` 在 sync_block.cpp:46 和 block_helper.cpp:1405 冗余定义。

---

## 5. VRF 共识关联

| 步骤 | 说明 | 文件 |
|------|------|------|
| **Seed 生成** | `floor(time / 10) * 10` 每 10 秒周期 | `ca/vrf_consensus.cpp:628` |
| **VRF 结构构造** | 倒查 10 个高度, 取 hash 前 8 字符 | `ca/vrf_consensus.cpp:82` |
| **打包节点选择** | 从 validatedVRfs 按频率筛选 + SHA256 随机 shuffle, 选 kConsensus=3 个 | `ca/vrf_consensus.cpp:339-625` |
| **异常节点惩罚** | 低于平均签名数的节点 dividendRate = own/average | `ca/algorithm.cpp:66` |
| **签名验证** | 去重后签名数量 == kConsensus (但未验证节点资格) | `ca/algorithm.cpp:3923` |

---

## 6. 同步模式摘要

| 模式 | 触发条件 | 验证方式 | 数据获取 |
|------|---------|---------|---------|
| **FastSync** | `sync_fail_height != 0` 且 `runFastSync == true` | SumHash 66% 拜占庭检查 | hash列表 -> 下载差异块 |
| **NewSync** | 常规追高 | SumHash 51% 共识判定 | SumHash验证 -> 差异hash -> 下载区块 |
| **FromZero** | 新建节点 / 高度差异极大 | 千区块 SumHash 验证 | 每 ~1000 块为一批次请求 |

---

## 7. 关键常量

| 常量 | 值 | 定义位置 |
|------|-----|---------|
| `kConsensus` | 3 | `ca/global.h` 打包节点数量 |
| `CYCLE_DURATION_SECONDS` | 10 | `ca/vrf_consensus.cpp` VRF 周期 |
| `RollBackTime` | 15 * 1000000 us | `ca/block_helper.cpp:1405` |
| `SYNC_HEIGHT_TIME` | 10s | `ca/sync_block.cpp:37` 同步周期 |
| `send_node_threshold` | 5 | `ca/global.h:18` |
| `broadcast_threshold` | 15 | `net/global.cpp:23` |

---

## 8. 相关文档

### 阶段 2 -- 模块分析
| 文档 | 路径 |
|------|------|
| DAG 共识模块总览 | `../../module-dag-consensus/module_overview.md` |
| DAG 共识类分析 | `../../module-dag-consensus/class_analysis.md` |
| DAG 共识调用链 | `../../module-dag-consensus/call_chain.md` |
| DAG 共识状态流 | `../../module-dag-consensus/state_flow.md` |
| DAG 共识存储模型 | `../../module-dag-consensus/storage_model.md` |
| DAG 共识线程模型 | `../../module-dag-consensus/thread_model.md` |
| DAG 共识重构建议 | `../../module-dag-consensus/refactor_suggestion.md` |

### 阶段 3 -- 流程分析
| 文档 | 路径 |
|------|------|
| 区块同步时序图 | `../../03_core_flows/flow-02-block-sync/sequence_flow.md` |
| 区块同步调用栈 | `../../03_core_flows/flow-02-block-sync/call_stack.md` |
| 区块同步状态迁移 | `../../03_core_flows/flow-02-block-sync/state_transition.md` |
| 区块同步异步任务 | `../../03_core_flows/flow-02-block-sync/async_task_flow.md` |

### 阶段 1 -- 全局架构
| 文档 | 路径 |
|------|------|
| 架构总览 | `../../architecture_overview.md` |
| 模块依赖 | `../../module_dependency.md` |
| 启动流程 | `../../startup_flow.md` |
| 重构风险总览 | `../../refactor_risk_overview.md` |

### 阶段 4 -- 重构规划
| 文档 | 路径 |
|------|------|
| 重构总体规划 | `../../refactor_master_plan.md` |
