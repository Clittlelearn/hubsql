# 11_crypto -- 密码学体系

> MeMeChain 密码学基础设施索引。涵盖双曲线架构 (P-256 + secp256k1) / ECDSA / Keccak / SHA256 / ECVRF / SilkPre / 地址生成 / 密钥管理。
>
> 上级目录: [../README.md](../README.md)

---

## 1. 架构概览

MeMeChain 密码学体系分为三层:

```
┌────────────────────────────────────────────────┐
│  交易 / 共识 / RPC 层 (上层)                     │
├────────────────────────────────────────────────┤
│  AccountManager (账户管理层 - secp256k1)        │
│  - Account::Sign / Verify (ETH 格式 65 字节)    │
│  - GenerateAddr (EIP-55 校验和)                 │
│  - KeyStore (scrypt + AES-128-CTR)             │
├────────────────────────────────────────────────┤
│  crypto 模块 (底层 - P-256 / NIST)              │
│  - ECDSA / ECDH / HKDF / AES-256-GCM / HMAC   │
├────────────────────────────────────────────────┤
│  辅助模块                                        │
│  - SHA256 / Keccak256 / ECVRF / SilkPre        │
│  - hex_code / base64 / envelop / contract_utils│
├────────────────────────────────────────────────┤
│  外部依赖                                        │
│  - OpenSSL 3.x / ethash / libff / GMP / intx   │
│  - secp256k1 / nlohmann-json                   │
└────────────────────────────────────────────────┘
```

**关键设计决策**: crypto 模块 (P-256) 与账户层 (secp256k1) 使用不同椭圆曲线，彼此物理隔离。账户层不调用 `crypto::ecdsa_sign`，而是直接使用 OpenSSL EVP API。

---

## 2. 椭圆曲线体系

### 2.1 双曲线架构

| 属性 | P-256 (NIST) | secp256k1 |
|------|-------------|-----------|
| OpenSSL NID | `NID_X9_62_prime256v1` | `NID_secp256k1` |
| 用途 | 通信加密 (ECDH) / 通用签名 / HKDF / ECVRF | 账户签名 / 交易签名 / 地址生成 |
| 曲线类型 | Weierstrass (NIST 标准) | Weierstrass (SEC 标准) |
| 以太坊兼容 | 否 | 是 |
| 文件 | `utils/crypto.cpp/h` | `utils/account_manager.cpp/h` |
| 定义 | `crypto.cpp:10` | `account_manager.cpp:431` |
| 模块文档 | [../../module-crypto/module_overview.md](../../module-crypto/module_overview.md) | -- |

### 2.2 双曲线隔离原理

```
crypto 模块 (P-256)                 账户模块 (secp256k1)
     │                                     │
     ├─ ecdsa_sign(P-256)                  ├─ Account::Sign(secp256k1)
     ├─ ecdsa_verify(P-256)                ├─ Account::Verify(secp256k1)
     ├─ ECDH(P-256)                        ├─ generatePkey(secp256k1)
     ├─ HKDF(P-256)                        ├─ GenerateAddr(secp256k1)
     ├─ AES-256-GCM                        └─ KeyStore(secp256k1)
     └─ HMAC-SHA256
```

**风险**: 若代码试图用 `crypto::ecdsa_verify` 验证账户签名数据，会验证失败 (不同曲线)。已确认为 High 风险项 (C-001)。

---

## 3. 核心密码学原语

### 3.1 ECDSA 签名

| 曲线 | 签名格式 | 签名长度 | 降 s 归一化 | 使用位置 |
|------|---------|---------|------------|---------|
| secp256k1 | ETH 格式 (r32 + s32 + v1) | 65 字节 | 是 (低 s 值) | Account::Sign / EthSignRaw |
| P-256 | DER 编码 | 变长 (~70-72 字节) | 否 | crypto::ecdsa_sign |

**消息哈希**:
- `EthMessageHash()` 前缀: `"\x19Ethereum Signed Message:\n" + len + msg` **已被注释掉** (account_manager.cpp:726-741)
- 当前仅用于链上交易，直接 keccak256 哈希
- 反馈: 与以太坊生态工具签名互操作时可能不兼容 (C-005)

### 3.2 ECDH 密钥协商 (P-256)

| 函数 | 说明 |
|------|------|
| `generate_ecdh_keys()` | 生成 ECDH 密钥对 |
| `calculate_ecdh_shared_key()` | 计算 ECDH 共享密钥 (32 字节) |
| `rand_salt()` | 生成随机盐 (32 字节) |

### 3.3 哈希函数

| 哈希 | 库 | 输出 | 用途 |
|------|-----|------|------|
| SHA256 | OpenSSL / utils/sha256.cpp | 32 字节 | 区块哈希 / MPT 根哈希 / 交易哈希 |
| Keccak256 | ethash / keccak_cryopp.hpp | 32 字节 | 地址生成 / 合约地址 / EIP-55 / EVM |
| HMAC-SHA256 | crypto::hmac_sha256 | 32 字节 | 消息认证 / Token 生成 |

### 3.4 对称加密

| 算法 | 密钥长度 | 模式 | 用途 |
|------|---------|------|------|
| AES-256-GCM | 256 位 | GCM (认证加密) | 通信加密 (crypto 模块) |
| AES-128-CTR | 128 位 | CTR | Keystore 文件加密 |

### 3.5 HKDF 密钥派生 (P-256)

```cpp
createHkdfBytes(shared_key, salt, "ENCRYPTION", 32) -> aes_key (32 字节)
// HKDF-SHA256: aes_key = HKDF(ikm=shared_key, salt=saltXor, info="ENCRYPTION", L=32)
```

### 3.6 ECVRF (P-256, RFC 9381)

| 属性 | 值 |
|------|-----|
| 规范 | RFC 9381 ECVRF-P256-SHA256-TAI |
| 文件 | `utils/ecvrf_p256_sha256_tai.cpp` |
| 用途 | VRF 共识中的可验证随机数生成 |
| 状态 | **新接口已定义 (vrf_selection.h)，但 vrf_consensus 中仍是旧实现** (Q-3) |

---

## 4. 地址生成

### 4.1 生成流程

```
公钥 (65字节未压缩: 0x04 + X + Y)
    |
    v
keccak256(X || Y) -- 注意: 不含 0x04 前缀
    |
    v
取后 40 字符 (20 字节)
    |
    v
EIP-55 校验和: 计算 keccak256 后的大小写混合
    |
    v
0x + 40 hex = EVM 地址
```

### 4.2 公钥格式支持

| 格式 | 长度 | 支持 |
|------|------|------|
| 未压缩 | 65 字节 (0x04 + X + Y) | 是 |
| 压缩 | 33 字节 (0x02/0x03 + X) | 是 |
| DER | 变长 | 是 |

### 4.3 地址验证

- `isValidAddress()` -- EIP-55 校验和验证
- 缓存: `VerifiedAddress.verifiedAddresses` 集合 (运行时缓存, 重启丢失)
- 流程: 长度检查 (40 hex) -> EIP-55 大小写校验 -> 缓存命中

---

## 5. 密钥管理

### 5.1 Keystore 格式

| 属性 | 值 |
|------|-----|
| KDF | scrypt (n=262144, r=8, p=1) |
| 加密算法 | AES-128-CTR |
| MAC | Keccak256(derivedKey[16:] + ciphertext) |
| 序列化 | JSON (类 Ethereum keystore) |
| 存储路径 | `KEYSTORE_PATH/<address>.json` |
| 文件 | `utils/keystore.cpp/h` |

### 5.2 账户生命周期

| 状态 | 含义 | 私钥位置 |
|------|------|---------|
| 未初始化 | 节点首次启动, 无 keystore 文件 | 无 |
| 创建中 | `Account(true)` 生成密钥对 -> 密码 -> scrypt 加密 -> 写入文件 | 明文内存 |
| 加载中 | 从 keystore 文件解密 (逐个或批量, 最多重试 3 次) | 解密后明文内存 |
| 已创建 | 账户在内存 + 磁盘 | _pkey (EVP_PKEY 指针) |
| 已锁定 | 节点关闭, 私钥已释放 | 仅加密磁盘 |
| 已删除 | `DeleteAccount()` | 无 |

### 5.3 密钥存储安全

- `unique_ptr<EVP_PKEY>` 管理私钥生命周期
- 析构时自动调用 `EVP_PKEY_free`
- 风险: 明文私钥在内存中可通过 dump 泄露
- `_priStr` 字段存有原始私钥字节 (非安全擦除)

---

## 6. 预编译合约密码学 (SilkPre)

| 预编译 | 地址 | 密码学原语 | 库 |
|--------|------|-----------|-----|
| ecrecover | 0x01 | secp256k1 ECDSA 公钥恢复 | silkpre |
| SHA256 | 0x02 | SHA256 | silkpre |
| RIPEMD160 | 0x03 | RIPEMD160 | silkpre |
| modexp | 0x05 | 模幂运算 | silkpre |
| bn_add | 0x06 | alt_bn128 椭圆曲线点加法 | silkpre (libff) |
| bn_mul | 0x07 | alt_bn128 椭圆曲线标量乘 | silkpre |
| snarkv | 0x08 | alt_bn128 配对检查 | silkpre |
| blake2_f | 0x09 | BLAKE2b 压缩函数 | silkpre |

文件: `silkpre/lib/silkpre/precompile.cpp/h`, `contract/precompiles.cpp/hpp`

---

## 7. 通信加密层 (数字信封)

| 组件 | 文件 | 说明 |
|------|------|------|
| 数字信封 | `utils/envelop.cpp` | 公钥加密 + 私钥解密 |
| Token 生成 | `key_exchange.cpp` | HMAC-SHA256 短 Token 防重放 |
| 消息加密 | `key_exchange.cpp` | AES-256-GCM 加密通道 |

---

## 8. 规范对照

| 功能点 | 规范 (spec_dev.md) | 当前实现 | 偏差 |
|--------|-------------------|----------|------|
| 底层 ECDSA 曲线 | 未明确定义 | P-256 + secp256k1 双曲线 | 历史遗留 |
| 地址生成 | EIP-55 标准 | keccak256(XY)[12:32] + ToChecksumAddress | **一致** |
| 签名格式 | ETH 格式 (65字节) | EthSignRaw 返回 65 字节, 低 s 归一化 | **一致** |
| 消息哈希 | EIP-191 前缀 | **前缀已注释**, 直接 keccak256 | 设计选择 |
| VRF | 未详述 | RFC 9381 ECVRF-P256-SHA256-TAI | 额外特性 |
| Keystore | 未明确定义 | 类 Ethereum: scrypt+AES-128-CTR+Keccak256 MAC | 兼容性增强 |
| 预编译合约 | EVM Istanbul | silkpre: 9 个预编译 | **一致** |
| 哈希函数 | -- | Keccak-256 (ethash) | **一致** |

---

## 9. 已知问题

| 编号 | 问题 | 风险 | 位置 |
|------|------|------|------|
| C-001 | P-256 / secp256k1 双曲线不互通 | High | crypto.cpp:10 vs account_manager.cpp:431 |
| C-003 | UUID 使用非加密 PRNG | Low | keystore.cpp:72 |
| C-004 | GetPasswordFromUser 递归栈溢出风险 | Medium | keystore.cpp:458 |
| C-005 | EIP-191 前缀被注释 | Medium | account_manager.cpp:726-741 |
| C-006 | calculate_ecdh_shared_key 双 public key 设置 | Medium | crypto.cpp:165 |
| P3-1 | P-256/secp256k1 双曲线统一 | Low | 重构 P3 |

---

## 10. 文档索引

### 10.1 本目录文档

| 文档 | 内容 |
|------|------|
| (待产出) 密码学原语规范 | 所有密码学算法的接口 / 参数 / 测试向量 |
| (待产出) 地址体系设计 | EIP-55 地址 / 合约地址 / 密钥派生 |
| (待产出) 密钥管理规范 | Keystore 格式 / 生命周期 / 安全审计 |

### 10.2 相关文档

| 文档 | 路径 | 说明 |
|------|------|------|
| Crypto 模块概览 | [../../module-crypto/module_overview.md](../../module-crypto/module_overview.md) | 密码学模块完整概述 |
| Crypto 状态流转 | [../../module-crypto/state_flow.md](../../module-crypto/state_flow.md) | 账户 / 密钥 / 地址状态机 |
| Crypto 线程模型 | [../../module-crypto/thread_model.md](../../module-crypto/thread_model.md) | 密码学模块线程分析 |
| Crypto 调用链 | [../../module-crypto/call_chain.md](../../module-crypto/call_chain.md) | 密码学调用堆栈 |
| Crypto 存储模型 | [../../module-crypto/storage_model.md](../../module-crypto/storage_model.md) | Keystore 持久化 |
| Crypto 类分析 | [../../module-crypto/class_analysis.md](../../module-crypto/class_analysis.md) | 密码学类关系 |
| 共识 VRF 分析 | [../../module-dag-consensus/module_overview.md](../../module-dag-consensus/module_overview.md) | VRF 在共识中的使用 |
| 合约密码学 | [../../module-evm/module_overview.md](../../module-evm/module_overview.md) | 预编译合约密码学 |
| 重构总体规划 | [../../refactor_master_plan.md](../../refactor_master_plan.md) | P3-1 双曲线统一 |
| 本阶段共识 | [../12_consensus/README.md](../12_consensus/README.md) | VRF 共识机制 |

---

*本文档基于阶段 2 (module-crypto) 分析综合编写。标注 "【需人工验证】" 处需进一步确认。*
