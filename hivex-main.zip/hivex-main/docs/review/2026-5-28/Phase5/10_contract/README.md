# 10_contract -- 智能合约系统

> MeMeChain EVM 智能合约系统索引。涵盖合约部署/调用/预编译合约/合约地址生成/合约依赖管理/ABI 兼容性。
>
> 上级目录: [../README.md](../README.md)

---

## 1. 架构概览

MeMeChain 集成 **evmone** 作为 EVM 执行引擎，遵循 **EVMC** (Ethereum Virtual Machine Connector) C 接口。核心桥接组件是 `EvmHost` (继承 `evmc::Host`)，负责将 UTXO 模型的世界状态适配为 EVM 所需的账户模型。

```
RPC 层 --> ca/contract.cpp (DeployContract / CallContract)
                |
                v
           ca/evm/evmEnvironment.cpp (准备 EVM 上下文)
                |
                v
           ca/evm/evm_host.cpp (EvmHost: 适配 UTXO -> 账户模型)
                |
                v
           evmone VM (EVM 字节码执行)
                |
                v
           预编译合约 (precompiles.cpp / silkpre)
                |
                v
           mpt/trie.cpp (合约状态持久化, SHA256 哈希)
```

---

## 2. 核心组件索引

### 2.1 合约入口层

| 组件 | 文件 | 职责 | 详细分析 |
|------|------|------|----------|
| 合约部署/调用入口 | `ca/contract.cpp/h` (56KB) | DeployContract / CallContract 主流程 | [../../module-evm/module_overview.md](../../module-evm/module_overview.md) |
| ETH 交易兼容 | `ca/eth_trans.cpp/h` (13KB) | Legacy / EIP-1559 交易 RLP 解码和签名验证 | [../../module-evm/module_overview.md](../../module-evm/module_overview.md) |
| 合约交易分发 | `ca/dispatchtx.cpp/h` (38KB) | 合约交易依赖管理与分组分发 | [../../module-evm/module_overview.md](../../module-evm/module_overview.md) |
| 合约交易缓存 | `ca/contract_transaction_cache.cpp/h` (7KB) | 合约交易缓存 (**已注释, 未启用**) | [../../module-evm/module_overview.md](../../module-evm/module_overview.md) |

### 2.2 EVM 执行核心

| 组件 | 文件 | 职责 |
|------|------|------|
| EVM Host 桥接 | `ca/evm/evm_host.cpp/h` (22KB) | evmc::Host 接口实现，UTXO -> 账户模型适配 |
| Host 数据结构 | `ca/evm/evm_host_data.hpp` (4KB) | StateAccount / StorageValue 定义 |
| EVM 管理器 | `ca/evm/evm_manager.cpp/h` (5KB) | evmone 实例化与合约保存 |
| EVM 环境构建 | `ca/evm/evmEnvironment.cpp/h` (13KB) | 交易消息和环境上下文构建 |

### 2.3 预编译合约

| 预编译 | 地址 | 说明 | Gas 计算 | 实际执行 |
|--------|------|------|----------|----------|
| ecrecover | 0x01 | ECDSA 公钥恢复 | precompiles.cpp | silkpre |
| SHA256 | 0x02 | SHA256 哈希 | precompiles.cpp (60+12/word) | silkpre |
| RIPEMD160 | 0x03 | RIPEMD160 哈希 | precompiles.cpp | silkpre |
| identity | 0x04 | 恒等映射 | precompiles.cpp | silkpre |
| modexp | 0x05 | 模幂运算 | precompiles.cpp | silkpre |
| bn_add | 0x06 | alt_bn128 点加法 | precompiles.cpp | silkpre |
| bn_mul | 0x07 | alt_bn128 标量乘法 | precompiles.cpp | silkpre |
| snarkv | 0x08 | alt_bn128 配对检查 | precompiles.cpp | silkpre |
| blake2_f | 0x09 | BLAKE2b 压缩 | precompiles.cpp | silkpre |

**预编译组件文件**:
- `contract/precompiles.cpp/hpp` (9KB) -- 9 个标准 EVM 预编译 Gas 计算
- `contract/precompiles_silkpre.cpp/hpp` (3KB) -- 通过 SilkPre 库实际执行预编译
- `contract/precompiles_cache.cpp/hpp` (3KB) -- 预编译结果 Keccak256 缓存

### 2.4 合约状态存储 (MPT)

| 组件 | 文件 | 职责 |
|------|------|------|
| MPT Trie | `mpt/trie.cpp/h` (15KB) | Merkle Patricia Trie 实现 |
| RLP 编解码 | `mpt/rlp.cpp/h` (12KB) | Aleth 移植的 RLP |
| MPT 节点定义 | `mpt/node.h` (2KB) | HashNode / ValueNode / ShortNode / FullNode |
| MPT 通用定义 | `mpt/common.cpp/h` (3KB) | SHA256 哈希 (注意: 非 Keccak256) |

---

## 3. 合约地址生成

### 3.1 CREATE 地址 (EIP-161 标准)

```
合约地址 = Keccak256(RLP([sender, nonce])) 取后 20 字节
```

实现位置: `evm_host.cpp:419-420` 调用 `GenerateContractAddrEth`; `evm_manager.cpp:77` 同样调用。

### 3.2 CREATE2 地址 (EIP-1014 标准)

```
合约地址 = Keccak256(0xff + sender + salt + Keccak256(init_code)) 取后 20 字节
```

实现位置: `evm_host.cpp:623-652`, 完整实现。

### 3.3 EIP-55 校验和

实现 `ToChecksumAddress()` 函数，将地址转为 EIP-55 格式 (大小写混合校验和)。

---

## 4. 合约依赖管理

### 4.1 DependencyManager (dispatchtx.cpp:87-176)

采用 **并查集 (Union-Find)** 算法对合约交易进行依赖分组:

1. `AddContractInfo()` -- 添加合约依赖关系
2. `AddMessageRequest()` -- 添加交易消息
3. `AddContractRequest()` -- 添加合约请求
4. `GetDependentData()` -- 获取分组后的依赖数据

### 4.2 TimerProcessor 分发定时器

- 线程: `TimerProcessor::ProcessingFunc()`
- 周期: 每 3 秒 (`kContractWaitingTime = 3 * 1000000`)
- 流程: GetDependentData -> GroupData -> DistributionContractTransactionRequest -> SendTransactionInfoRequest

### 4.3 ContractTransactionCache (已注释, 未启用)

设计上使用 `shared_mutex` 保护 `_cachedTransactions`, 1 秒定时器检查。**当前全部注释，功能未启用。** (refactor_master_plan P2-9)

---

## 5. Gas 机制

### 5.1 EIP-1559 动态基础费用

| 参数 | 值 | 位置 |
|------|-----|------|
| INITIAL_BASE_FEE | 10 | contract.cpp:715 |
| 弹性系数 | 12.5% (目标 Gas 使用率 50%) | fee_calculator.h |
| 基础 Gas 计算 | UTXO 计算 + EIP-1559 公式 | contract.cpp:708 |
| Gas 限额 | 120,000 (KTargetGasPrice * 2) | contract.cpp:710 |

### 5.2 合约验证 Gas 费用

`VerifyContractBaseFee` 实现基于 UTXO 的基础 Gas 验证。

---

## 6. EVM 执行规范对照

| 功能点 | 规范 (spec_dev.md) | 当前实现 | 偏差 |
|--------|-------------------|----------|------|
| 合约地址生成 | EIP-161: Keccak256(RLP([sender,nonce])) | `GenerateContractAddrEth` | **一致** |
| CREATE2 | sender+salt+initCodeHash | evm_host.cpp:623-652 | **一致** |
| EvmHost 接口 | 8 个方法 | 全部实现 + EIP-2929 访问列表 | **一致** |
| 预编译合约 | ecrecover(0x01) ~ blake2bf(0x09) | 9 个全实现 (silkpre) | **一致** |
| MPT 哈希函数 | SHA256 (8.7.9 节) | `trie.cpp:429` SHA256 | **不一致: 以太坊使用 Keccak256** |
| block_prev_randao | TODO 需确认 | UTXO 哈希拼接转数字 | **偏差: 与 RANDAO 语义完全不同** |
| EVM 执行超时 | 无规范定义 | 10 秒超时 | **额外防御机制** |
| SELFDESTRUCT | 无明确规范 | 支持 EIP-6049 之前语义 | **EIP-6049 已变更语义** |

---

## 7. 合约 ABI 兼容性

### 7.1 以太坊 ABI 兼容层

| 功能 | 实现状态 | 说明 |
|------|---------|------|
| eth_sendRawTransaction | 已实现 | RLP 解码 + 签名验证 + 入池 |
| eth_call (只读) | 已实现 | EVM 执行, 不修改状态 |
| eth_getLogs | **未实现** | 需补全 (refactor_master_plan P3-2) |
| eth_getStorageAt | **未实现** | 需补全 (refactor_master_plan P3-2) |
| 合约事件日志 (emit_log) | 已实现 | recorded_logs 收集 |
| 合约返回数据 | 已实现 | output 字段为 hex 字符串 |

### 7.2 不兼容项

1. **MPT 状态根**: 使用 SHA256 而非 Keccak256，与以太坊主网不兼容，跨链验证不可行 (P0-1)
2. **block_prev_randao**: 使用 UTXO 哈希拼接，非标准 RANDAO
3. **MPT 终止符**: 使用 'z' 字符，非标准 hex prefix (HP) 编码

---

## 8. 已知问题与风险

| 编号 | 问题 | 严重程度 | 位置 | 修复计划 |
|------|------|---------|------|---------|
| P0-1 | MPT SHA256 与 Keccak256 不兼容 | Critical | mpt/trie.cpp:429 | 重构 P0 |
| P1-2 | EVM 超时后线程泄漏 | High | contract.cpp:94-103 | 重构 P1 |
| P1-3 | message.gas = 用户全部 VOTE 余额 | High | evmEnvironment.cpp:116 | 重构 P1 |
| P2-8 | contract.cpp `#if 0` 代码未清理 | Low | contract.cpp 全文件 | 重构 P2 |
| P2-9 | ContractTransactionCache 废弃代码 | Low | contract_transaction_cache | 重构 P2 |

---

## 9. 文档索引 (阶段 5)

### 9.1 本目录文档

| 文档 | 内容 |
|------|------|
| (待产出) 合约生命周期设计 | 部署/调用/自毁完整流程 |
| (待产出) 预编译合约规范 | 9 个预编译的 Gas 计算与接口 |
| (待产出) 合约 ABI 兼容性分析 | ETH JSON-RPC 兼容层详细对照 |
| (待产出) MPT 状态树规范 | 节点结构 / RLP 编码 / 哈希方案 |

### 9.2 相关文档

| 文档 | 路径 | 说明 |
|------|------|------|
| EVM 模块概览 | [../../module-evm/module_overview.md](../../module-evm/module_overview.md) | 合约系统完整概述 |
| EVM 状态流转 | [../../module-evm/state_flow.md](../../module-evm/state_flow.md) | EVM 执行/合约/MPT 状态机 |
| EVM 线程模型 | [../../module-evm/thread_model.md](../../module-evm/thread_model.md) | EVM 线程安全分析 |
| EVM 调用链 | [../../module-evm/call_chain.md](../../module-evm/call_chain.md) | 合约调用完整堆栈 |
| EVM 存储模型 | [../../module-evm/storage_model.md](../../module-evm/storage_model.md) | MPT 持久化 |
| EVM 类分析 | [../../module-evm/class_analysis.md](../../module-evm/class_analysis.md) | 核心类关系 |
| EVM 合约流程 | [../../03_core_flows/flow-04-evm-contract/sequence_flow.md](../../03_core_flows/flow-04-evm-contract/sequence_flow.md) | EVM 合约完整时序 |
| EVM 状态转换 | [../../03_core_flows/flow-04-evm-contract/state_transition.md](../../03_core_flows/flow-04-evm-contract/state_transition.md) | 合约交易状态机 |
| 重构总体规划 | [../../refactor_master_plan.md](../../refactor_master_plan.md) | 重构优先级与策略 |
| 本阶段线程全景 | [../13_threading/README.md](../13_threading/README.md) | 线程安全分析 |
| 本阶段状态机 | [../14_state_machine/README.md](../14_state_machine/README.md) | 全局状态机索引 |

---

*本文档基于阶段 2 (module-evm) 和阶段 3 (flow-04-evm-contract) 分析综合编写。标注 "【需人工验证】" 处需进一步确认。*
