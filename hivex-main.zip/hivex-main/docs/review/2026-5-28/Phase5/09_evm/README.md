# 09 -- EVM / EVM 集成与智能合约

> **阶段 5 重组索引** | 关联目录: `../../module-evm/`, `../../03_core_flows/flow-04-evm-contract/`
> **上游**: [08_rpc](../08_rpc/) | **下游**: [10_contract](../10_contract/)

---

## 1. 概览

MeMeChain 集成 **evmone** 作为 EVM 执行引擎，遵循 EVMC (Ethereum Virtual Machine Connector) C 接口标准。核心桥接组件 `EvmHost` 继承 `evmc::Host`，负责将 UTXO 模型的世界状态适配为 EVM 所需的账户模型。合约状态使用自定义 MPT (Merkle Patricia Trie) 持久化，但哈希算法为 SHA256 而非以太坊标准 Keccak256。

**核心组件**: evmone (独立编译静态库) + EvmHost (UTXO-账户桥接) + MPT (SHA256 状态树) + 9 个预编译合约。

---

## 2. 集成架构

```
RPC 层 -> ca/contract.cpp (DeployContract / CallContract)
              │
              ▼
         ca/evm/evmEnvironment.cpp (EVM 上下文构建)
              │
              ▼
         ca/evm/evm_host.cpp (EvmHost: UTXO -> 账户模型桥接)
              │
              ▼
         evmone VM (EVM 字节码执行, MAX_REVISION)
              │
              ▼
         预编译合约 (precompiles.cpp / precompiles_silkpre.cpp)
              │
              ▼
         mpt/trie.cpp (合约状态 MPT 持久化, SHA256)
              │
              ▼
         db/ (RocksDB: mptkey2mptvalue_ / contractaddr2contractcode_ 等前缀)
```

---

## 3. 核心文件映射

| 层级 | 文件 | 大小 | 职责 |
|------|------|------|------|
| EVM 核心 | `ca/evm/evm_host.cpp/h` | 22KB/5KB | evmc::Host 接口实现 (8 个标准方法 + EIP-2929) |
| EVM 核心 | `ca/evm/evm_host_data.hpp` | 4KB | StateAccount / StorageValue 数据结构定义 |
| EVM 核心 | `ca/evm/evm_manager.cpp/h` | 5KB/2KB | evmone 实例化与合约保存 |
| EVM 核心 | `ca/evm/evmEnvironment.cpp/h` | 13KB/2KB | 交易消息和环境上下文构建 |
| 合约入口 | `ca/contract.cpp/h` | 56KB/9KB | DeployContract / CallContract 主流程 |
| 合约入口 | `ca/eth_trans.cpp/h` | 13KB/1KB | ETH 交易 RLP 解码与签名验证 |
| 预编译 | `contract/precompiles.cpp/hpp` | 9KB/1KB | 9 个标准 EVM 预编译 Gas 计算 |
| 预编译 | `contract/precompiles_silkpre.cpp/hpp` | 3KB/1KB | SilkPre 库实际执行预编译 |
| 预编译 | `contract/precompiles_cache.cpp/hpp` | 3KB/1KB | 预编译结果 Keccak256 缓存 |
| MPT | `mpt/trie.cpp/h` | 15KB/4KB | MPT 树操作 (SHA256, 自定义终止符) |
| MPT | `mpt/rlp.cpp/h` | 12KB/21KB | RLP 编解码 (Aleth 移植) |
| 分发 | `ca/dispatchtx.cpp/h` | 38KB/5KB | 合约交易依赖管理与分组分发 (并查集) |
| Gas | `ca/fee_calculator.h` | 6KB | EIP-1559 动态基础费用计算 |
| 缓存 | `ca/contract_transaction_cache.cpp/h` | 7KB/3KB | 合约交易缓存 (全部注释, 未启用) |

---

## 4. EvmHost 接口实现

`EvmHost` 继承 `evmc::Host`，实现以下接口方法:

| 方法 | 标签 | 实现方式 |
|------|------|---------|
| `account_exists(addr)` | E.A. | accounts map 查找 + 缓存预热 |
| `get_storage(addr, key)` | E.A. | accounts[addr].storage + MPT 查询 |
| `set_storage(addr, key, val)` | E.A. | accounts[addr].storage 更新 + `trie.Update()` |
| `get_balance(addr)` | E.A. | UTXO 余额查询 (`get_balance_by_utxo`) |
| `get_code_size(addr)` | E.A. | `accounts[addr].code.size()` |
| `get_code_hash(addr)` | E.A. | `accounts[addr].codehash` (Keccak256) |
| `copy_code(addr, buf)` | E.A. | `accounts[addr].code` 复制到缓冲区 |
| `selfdestruct(addr, ben)` | E.A. | coinTransfersInProgress + recorded_selfdestructs |
| `call(msg)` | E.A. | 预编译优先 / 合约代码加载 / 嵌套 EVM 执行 |
| `get_tx_context()` | E.A. | 返回 chainId / gasPrice / timestamp 等 |
| `get_block_hash(number)` | E.A. | 返回区块哈希 |
| `emit_log(data, topics)` | E.A. | 写入 recorded_logs |
| `access_account(addr)` | EIP-2929 | warm/cold 访问追踪 |
| `access_storage(addr, key)` | EIP-2929 | storage 访问追踪 |

> **E.A.** = 以太坊标准 EVM 必需接口; **EIP-2929** = 柏林硬分叉访问列表优化。

---

## 5. 合约部署流程

```
1. RPC: CreateDeployContractTransaction 接收参数
2. TxHelper: createDeploy() 选择 UTXO -> EIP-1559 费用计算 -> 签名
3. RPC: SendContractMessage -> ContractTxCache -> CA 打包
4. CA: BuildBlock 收集交易
5. CA: DeployContract() -> EvmHost::call(CREATE)
   a. 检查合约是否已部署 (防重复)
   b. GenerateContractAddrEth(sender, nonce) 生成合约地址
      算法: Keccak256(RLP([sender, nonce])) 取后 20 字节
   c. CreateTrie(empty_root, contractAddr) 初始化空 MPT
   d. vm.execute(EVM_CREATE) 执行初始化代码
   e. SaveContract (写入 RocksDB):
      - EVM_CODE:{contractAddr} = runtimeCode
      - EVM_DEPLOY:{deployer} += contractAddr
      - EVM_UTXO:{contractAddr} = deploymentUtxo
   f. trie.Save() -> Commit -> Encode -> SHA256 -> RocksDB (mptkey2mptvalue_)
6. DB: transactionCommit() 原子提交
7. CA: 广播新区块
```

---

## 6. 合约调用流程

```
1. RPC: CreateCallContractTransaction -> createCall(addr, deployer, utxo, args, contractAddr, money)
2. CA: BuildBlock -> CallContract()
3. EvmHost::call(CALL):
   a. 自毁检查 (recorded_selfdestructs)
   b. 预编译检查 (0x01-0x09), hit 则直接返回预编译结果
   c. fetchContractRootHash 从 RocksDB 加载 MPT 状态根
   d. 创建嵌套 evmone VM 实例
   e. vm.execute(EVM_CALL) 执行合约代码
   f. 回写 MPT 状态变更
4. 事件: emit_log -> recorded_logs (内存, 不持久化到事件表)
```

**嵌套 VM 机制**: 每个 `call()` 创建新的 evmone VM 实例 (evm_host.cpp:507)，支持合约间调用 (CALL/CALLCODE/DELEGATECALL/STATICCALL/CREATE/CREATE2)。

---

## 7. Gas 计算 (EIP-1559)

| 参数 | 值 | 说明 |
|------|-----|------|
| MAX_GAS_LIMIT | 120000 | UTXO 模型基础 Gas 限制 |
| INITIAL_BASE_FEE | 10 | 动态基础费用初始值 |
| KTargetGasPrice | 60000 | 目标 Gas 价格基准 |
| Gas 上限公式 | `gasCost > KTargetGasPrice * 2` | 拒绝超过 2 倍目标价的交易 |
| 动态调整 | `EIP1559FeeCalculator::calculateNewFee()` | old_baseFee -> adjustment_factor -> new_baseFee (ceil/floor) |
| eth_estimateGas | 固定返回 "1" | **未实现**真实的 Gas 估算 (eth_impl.cpp:429) |

---

## 8. MPT 状态树

### 8.1 与以太坊的差异

| 维度 | 以太坊标准 | MeMeChain 实现 | 影响 |
|------|-----------|---------------|------|
| **哈希函数** | Keccak256 | SHA256 | 状态根与以太坊不兼容，无法跨链验证 |
| **Key 编码** | Hex-Prefix (HP) 编码 | 追加 `'z'` 终止符 | 与以太坊工具链不兼容 |
| **存储后端** | LevelDB | RocksDB (mptkey2mptvalue_ 前缀) | 功能等价 |
| **节点类型** | Branch/Extension/Leaf | FullNode/ShortNode/HashNode/ValueNode | 内部实现差异，功能等价 |

### 8.2 MPT 节点结构

| 节点 | 文件 | 说明 |
|------|------|------|
| `HashNode` | `mpt/node.h` | 哈希引用 (指向已持久化子树) |
| `ValueNode` | `mpt/node.h` | 叶节点值 |
| `ShortNode` | `mpt/node.h` | 短路径节点 (扩展/叶) |
| `FullNode` | `mpt/node.h` | 分支节点 (16 个子节点 + value) |

### 8.3 MPT 操作

| 操作 | 函数 | 文件 |
|------|------|------|
| 插入 | `Trie::Insert(key, value)` | `mpt/trie.cpp` |
| 查询 | `Trie::Search(key)` | `mpt/trie.cpp` |
| 提交 | `Trie::Save()` -> Commit -> Encode -> Getsha256Hash | `mpt/trie.cpp` |
| 创建 | `CreateTrie(empty_root, contractAddr)` | `mpt/trie.cpp` |

---

## 9. 预编译合约 (9个)

| 地址 | 名称 | Gas 公式 | 实际执行 |
|------|------|---------|---------|
| 0x01 | ecrecover | 3000 | SilkPre 库 |
| 0x02 | sha256 | 60 + 12 * word | SilkPre 库 |
| 0x03 | ripemd160 | 600 + 120 * word | SilkPre 库 |
| 0x04 | identity | 15 + 3 * word | precompiles.cpp 直接实现 |
| 0x05 | modexp | 复杂公式 | SilkPre 库 |
| 0x06 | ecadd | 150 | SilkPre 库 |
| 0x07 | ecmul | 6000 | SilkPre 库 |
| 0x08 | ecpairing | 45000 * pair | SilkPre 库 |
| 0x09 | blake2bf | 由 rounds 决定 | SilkPre 库 |

**缓存机制**: `precompiles_cache.cpp` 使用 Keccak256((address, input)) 作为缓存 Key，内存缓存预编译结果。

---

## 10. 已知风险与未启用功能

### 10.1 关键风险

| 风险 | 位置 | 等级 |
|------|------|------|
| MPT SHA256 与以太坊 Keccak256 不兼容 | `mpt/trie.cpp:429` | 高 |
| EvmHost const_cast 操作 mutable 成员, 线程安全存疑 | `ca/evm/evm_host.cpp` | 中 |
| block_prev_randao 使用 UTXO 哈希拼接 (非确定性) | `ca/evm/evmEnvironment.cpp:297` | 低 |
| 合约地址 nonce 并发冲突风险 | `GetNextNonce` | 中 |
| EVM 执行 10s 超时, 超时线程可能泄漏 | `ca/contract.cpp:96` | 中 |
| eth_estimateGas 固定返回 "1" | `rpc/eth/eth_impl.cpp:429` | 中 |

### 10.2 已注释/未启用功能

| 功能 | 文件 | 说明 |
|------|------|------|
| ContractTransactionCache | `ca/contract_transaction_cache.cpp/h` | 全部注释 (1s 定时器 / 15s 强制发送) |
| DependencyManager::CanSendTransaction | `ca/dispatchtx.cpp` | 已注释 |
| transaction/contract.h | `ca/transaction/contract.h` | 全部在 `#if 0` 块内 |
| contract_error.h 宏定义 | `contract/contract_error.h` | 大部分注释 |

---

## 11. 相关文档

### 阶段 2 -- 模块分析
| 文档 | 路径 |
|------|------|
| EVM 模块总览 | `../../module-evm/module_overview.md` |
| EVM 类分析 | `../../module-evm/class_analysis.md` |
| EVM 调用链 | `../../module-evm/call_chain.md` |
| EVM 状态流 | `../../module-evm/state_flow.md` |
| EVM 存储模型 | `../../module-evm/storage_model.md` |
| EVM 线程模型 | `../../module-evm/thread_model.md` |
| EVM 重构建议 | `../../module-evm/refactor_suggestion.md` |

### 阶段 3 -- 流程分析
| 文档 | 路径 |
|------|------|
| EVM 合约部署/调用时序图 | `../../03_core_flows/flow-04-evm-contract/sequence_flow.md` |
| EVM 合约调用栈 | `../../03_core_flows/flow-04-evm-contract/call_stack.md` |
| EVM 合约状态迁移 | `../../03_core_flows/flow-04-evm-contract/state_transition.md` |
| EVM 合约异步任务流 | `../../03_core_flows/flow-04-evm-contract/async_task_flow.md` |

### 阶段 1 -- 全局架构
| 文档 | 路径 |
|------|------|
| 架构总览 (evm/mpt/contract 目录) | `../../architecture_overview.md` |
| 模块依赖 (EVM 依赖链) | `../../module_dependency.md` |

### 阶段 4 -- 重构规划
| 文档 | 路径 |
|------|------|
| 重构总体规划 (MPT/EVM 相关) | `../../refactor_master_plan.md` |

### 其他模块
| 文档 | 路径 |
|------|------|
| 存储模块 (MPT Key 前缀) | `../../module-storage/storage_model.md` |
| 密码模块 (Keccak/SHA256) | `../../module-crypto/module_overview.md` |
