# 00 — 项目总览 (Project Overview)

> **文档阶段**: 阶段5 — 重组索引
> **项目**: MeMeChain (`mm`)
> **最后更新**: 2026-05-26

---

## 一、项目基本信息

| 属性 | 值 |
|------|-----|
| 项目名称 | **MeMeChain** (`mm`) |
| 语言标准 | C++20 |
| 构建系统 | CMake (>= 3.15) |
| 源码根目录 | `/home/wbl/mm/` |
| 输出产物 | `bin/mm` (单一可执行文件) |
| 核心模型 | UTXO + 账户混合模型 + DAG 区块结构 |
| 共识算法 | VRF (Verifiable Random Function) 随机选择打包节点 |
| EVM 引擎 | evmone (独立编译为静态库) |
| 存储引擎 | RocksDB (TransactionDB 模式) |
| 网络模型 | epoll 事件循环 + Protobuf 序列化 + ECDH 加密 |
| 签名算法 | ECDSA (secp256k1 / P-256) |
| RPC 协议 | JSON-RPC 2.0 + ETH 兼容接口 |

---

## 二、核心特性列表

1. **混合账户模型** — UTXO (安全性/可追溯) + Account (易用性/EVM兼容) 双模型并行
2. **DAG 区块结构** — 有向无环图拓扑，支持并行出块与高吞吐
3. **VRF 共识** — 基于 ECVRF 的可验证随机函数选择打包节点，防预测/防操纵
4. **EVM 完全兼容** — 基于 evmone 引擎，支持 Solidity 合约部署与调用
5. **质押与治理** — 原生 stake/delegate/vote/lock 机制，链上治理全流程
6. **EIP-1559 费用** — 动态 Gas 费用市场，基础费用 + 小费模型
7. **MPT 状态树** — Merkle Patricia Trie 存储合约状态，支持状态证明
8. **ECDH 加密网络** — 节点间通信经过 ECDH 密钥交换 + 压缩加密
9. **JSON-RPC 2.0** — 93+ POST 接口 + 38+ GET 接口，含 ETH 兼容子集
10. **Protobuf 序列化** — 10 组 .proto 定义覆盖区块/交易/网络/同步/签名全协议

---

## 三、文档导航总入口

本文档库分 5 个阶段共 19 个目录组织：

### 阶段5 — 索引层 (当前)

| # | 目录 | 说明 |
|---|------|------|
| 00 | [`00_project_overview/`](./) | 项目总览 (本文件) |
| 01 | [`01_architecture/`](../01_architecture/) | 系统架构与设计决策 |
| 02 | [`02_build_system/`](../02_build_system/) | 构建系统与第三方依赖 |
| 03 | [`03_core_modules/`](../03_core_modules/) | 10 大核心模块索引 |
| 04 | [`04_transaction_flow/`](../04_transaction_flow/) | 交易生命周期与交易类型 |
| 05 | [`05_block_flow/`](../05_block_flow/) | 区块流转 (待补充) |
| 06 | [`06_network/`](../06_network/) | 网络层索引 (待补充) |
| 07 | [`07_storage/`](../07_storage/) | 存储层索引 (待补充) |
| 08 | [`08_rpc/`](../08_rpc/) | RPC 层索引 (待补充) |
| 09 | [`09_evm/`](../09_evm/) | EVM 集成索引 (待补充) |
| 10 | [`10_contract/`](../10_contract/) | 合约层索引 (待补充) |
| 11 | [`11_crypto/`](../11_crypto/) | 密码学索引 (待补充) |
| 12 | [`12_consensus/`](../12_consensus/) | 共识层索引 (待补充) |
| 13 | [`13_threading/`](../13_threading/) | 线程模型索引 (待补充) |
| 14 | [`14_state_machine/`](../14_state_machine/) | 状态机索引 (待补充) |
| 15 | [`15_refactor_analysis/`](../15_refactor_analysis/) | 重构分析索引 (待补充) |
| 16 | [`16_risk_analysis/`](../16_risk_analysis/) | 风险分析索引 (待补充) |
| 17 | [`17_api_reference/`](../17_api_reference/) | API 参考索引 (待补充) |
| 18 | [`18_sequence_diagrams/`](../18_sequence_diagrams/) | 时序图索引 (待补充) |
| 19 | [`19_agent_context/`](../19_agent_context/) | Agent 上下文索引 (待补充) |

### 阶段1–4 — 原始分析文档

| 阶段 | 路径 | 说明 |
|------|------|------|
| 阶段1 | [`../../architecture_overview.md`](../../architecture_overview.md) | 全局架构扫描 |
| 阶段1 | [`../../module_dependency.md`](../../module_dependency.md) | 模块依赖关系 |
| 阶段1 | [`../../startup_flow.md`](../../startup_flow.md) | 启动流程 |
| 阶段1 | [`../../refactor_risk_overview.md`](../../refactor_risk_overview.md) | 重构风险概览 |
| 阶段2 | [`../../module-crypto/`](../../module-crypto/) | 密码学与账户体系 |
| 阶段2 | [`../../module-storage/`](../../module-storage/) | 存储层 (RocksDB) |
| 阶段2 | [`../../module-utxo/`](../../module-utxo/) | UTXO 模型 |
| 阶段2 | [`../../module-dag-consensus/`](../../module-dag-consensus/) | DAG 与共识 |
| 阶段2 | [`../../module-evm/`](../../module-evm/) | EVM 集成 |
| 阶段2 | [`../../module-network/`](../../module-network/) | 网络层 |
| 阶段2 | [`../../module-txpool/`](../../module-txpool/) | 交易池 |
| 阶段2 | [`../../module-governance-incentive/`](../../module-governance-incentive/) | 治理与激励 |
| 阶段2 | [`../../module-rpc/`](../../module-rpc/) | RPC 层 |
| 阶段2 | [`../../module-special/`](../../module-special/) | 其他特殊功能 |
| 阶段3 | [`../../03_core_flows/`](../../03_core_flows/) | 6 条核心流程分析 |
| 阶段4 | [`../../refactor_master_plan.md`](../../refactor_master_plan.md) | 重构总体规划 |

---

## 四、快速开始 — 如何阅读本文档库

### 推荐阅读路径

1. **新人入门** → `00_project_overview` (本文件) → `01_architecture` → 选取感兴趣的模块进入阶段2
2. **开发者** → `02_build_system` (构建) → `03_core_modules` (模块) → 阶段3 核心流程
3. **架构师** → 阶段1 全局文档 → `15_refactor_analysis` → `16_risk_analysis` → 阶段4 重构规划
4. **运维/测试** → `04_transaction_flow` → `05_block_flow` → `17_api_reference` → `18_sequence_diagrams`

### 文档约定

- **标注 `【推测】`** — 通过命名/结构/模式推断，未经代码逐行确认
- **标注 `【需人工验证】`** — 信息不完整或有冲突，需要人工核实
- **路径前缀 `../../`** — 指向 `<doc>/` 根目录，所有交叉引用基于此

---

## 五、相关文档

| 文档 | 路径 | 说明 |
|------|------|------|
| 架构概览 | `../../architecture_overview.md` | 目录结构、分层架构、依赖项 |
| 模块依赖 | `../../module_dependency.md` | 模块间 include/链接关系 |
| 启动流程 | `../../startup_flow.md` | Init() 7 步启动详解 |
| 重构风险 | `../../refactor_risk_overview.md` | 高耦合/高风险区域识别 |
| 重构规划 | `../../refactor_master_plan.md` | P0–P3 优先级与目标架构 |
| 核心流程 | `../../03_core_flows/` | 6 条流程的时序/状态/调用栈 |
| 规范文档 | `//wsl$/wsl-mm/home/wbl/mm/HXD/spec_dev.md` | 协议开发规范 |
| RPC API | `//wsl$/wsl-mm/home/wbl/mm/HXD/rpc_api_get_doc.md` | GET 接口文档 |
| RPC API | `//wsl$/wsl-mm/home/wbl/mm/HXD/rpc_api_post_doc.md` | POST 接口文档 |
