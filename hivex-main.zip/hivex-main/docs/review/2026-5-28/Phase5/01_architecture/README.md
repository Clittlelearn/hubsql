# 01 — 系统架构 (Architecture)

> **文档阶段**: 阶段5 — 重组索引
> **项目**: MeMeChain (`mm`)
> **最后更新**: 2026-05-26

---

## 一、系统分层架构图

```
┌────────────────────────────────────────────────────────────────┐
│                      CLI / 入口层                               │
│    entry.cpp → main/main.cpp → Init() → CaInit() + NetInit()   │
├────────────────────────────────────────────────────────────────┤
│                      RPC / API 层                               │
│  ┌─────────────────┐  ┌────────────────┐  ┌─────────────────┐  │
│  │  JSON-RPC 2.0   │  │  ETH 兼容接口  │  │  HTTP Server    │  │
│  │  rpc/api/get/*  │  │  rpc/eth/*     │  │  cpp-httplib    │  │
│  │  rpc/api/post/* │  │                │  │  (net/http_srv) │  │
│  └────────┬────────┘  └───────┬────────┘  └────────┬────────┘  │
│           │                   │                     │           │
│           └───────────────────┼─────────────────────┘           │
│                               │                                 │
│  ┌────────────────────────────┴────────────────────────────┐   │
│  │  api/interface/http_api.cpp  (路由注册与分发, ~223KB)    │   │
│  └─────────────────────────────────────────────────────────┘   │
├────────────────────────────────────────────────────────────────┤
│                      共识层 (CA)                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ VRF 共识     │  │ 区块管理     │  │ 交易处理             │  │
│  │ vrf_consensus│  │ block_helper │  │ transaction.cpp      │  │
│  │ algorithm    │  │ block_storage│  │ txhelper.cpp         │  │
│  │              │  │ block_monitor│  │ dispatchtx.cpp       │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ 同步管理     │  │ EVM 集成     │  │ 治理与交易子模块     │  │
│  │ sync_block   │  │ evm/evm_host │  │ ca/transaction/*    │  │
│  │ check_blocks │  │ evm/evm_mgr  │  │ stake/unstake/vote..│  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│                      智能合约层                                  │
│  ┌──────────────────┐  ┌────────────────┐  ┌───────────────┐   │
│  │ EVM (evmone)     │  │ Precompiles    │  │ MPT 状态树    │   │
│  │ EvmHost          │  │ precompiles    │  │ trie/rlp      │   │
│  │ EvmManager       │  │ Cache + SilkPre│  │ common/node   │   │
│  └──────────────────┘  └────────────────┘  └───────────────┘   │
├────────────────────────────────────────────────────────────────┤
│                      存储层 (DB)                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  RocksDB (TransactionDB mode)                            │   │
│  │  db_api.cpp/h (业务数据接口, ~138KB)                      │   │
│  │  rocksdb_read_write.cpp (读写事务)                        │   │
│  │  rocksdb_read.cpp (只读查询)                              │   │
│  └─────────────────────────────────────────────────────────┘   │
├────────────────────────────────────────────────────────────────┤
│                      网络层 (Net)                                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ PeerNode 管理│  │ Protobuf 分发│  │ epoll 事件循环       │  │
│  │ peer_node    │  │ dispatcher   │  │ handle_event/epoll   │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ ECDH 加密    │  │ 消息打包     │  │ HTTP Server(内置)    │  │
│  │ key_exchange │  │ pack.cpp     │  │ http_server          │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│                      公共组件层                                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌───────────────┐  │
│  │ Config   │  │ Genesis  │  │ TaskPool │  │ Logging(spdlog)│ │
│  │ Manager  │  │ Manager  │  │ /Timer   │  │               │  │
│  └──────────┘  └──────────┘  └──────────┘  └───────────────┘  │
│  ┌──────────┐  ┌──────────┐  ┌────────────────────────────────┐ │
│  │ Account  │  │ Crypto   │  │ MagicSingleton (20+ 全局单例)  │ │
│  │ Manager  │  │ Utils    │  │                                │ │
│  └──────────┘  └──────────┘  └────────────────────────────────┘ │
│  ┌──────────┐  ┌──────────┐                                     │
│  │ Protobuf │  │ 错误模块 │                                     │
│  │ proto/pb │  │ errorn/  │                                     │
│  └──────────┘  └──────────┘                                     │
└────────────────────────────────────────────────────────────────┘
```

---

## 二、核心子系统职责摘要

| 子系统 | 源码目录 | 职责 | 关键文件 | 代码规模 |
|--------|---------|------|---------|---------|
| **共识层 (CA)** | `ca/` | VRF 选择打包节点、区块验证回滚、交易处理、同步管理、EVM集成 | `ca.cpp`, `algorithm.cpp`, `block_helper.cpp`, `sync_block.cpp` | ~54 文件, ~1.2MB |
| **网络层 (Net)** | `net/` | epoll 事件循环、节点发现与管理、心跳、Protobuf 消息分发、ECDH 加密 | `api.cpp`, `handle_event.cpp`, `peer_node.cpp`, `dispatcher.cpp` | ~34 文件, ~500KB |
| **存储层 (DB)** | `db/` | RocksDB TransactionDB 封装、读写分离事务、业务数据访问接口 | `db_api.cpp/h` (57K/81K), `rocksdb.cpp` | ~8 文件, ~170KB |
| **RPC 层** | `rpc/` + `api/` | JSON-RPC 2.0 (GET 38 + POST 93)、ETH 兼容接口、HTTP 路由 | `http_api.cpp` (~223KB), `param_handle.cpp` | ~140+ 文件 |
| **EVM 集成** | `ca/evm/` | evmone Host 接口实现、合约执行环境与上下文管理 | `evm_host.cpp`, `evm_manager.cpp` | ~7 文件 |
| **合约辅助** | `contract/` | EVM 预编译合约、Gas 计算、哈希工具 | `precompiles.cpp`, `fee_calculator.h` | ~9 文件 |
| **MPT 状态树** | `mpt/` | Merkle Patricia Trie (SHA256)、RLP 编解码、合约状态存储 | `trie.cpp`, `rlp.cpp` | ~13 文件 |
| **密码学** | `utils/` + `silkpre/` | ECDSA 签名、Keccak/SHA256、ECVRF 证明、密钥库 | `crypto.cpp`, `ecvrf_*.cpp`, `keystore.cpp` | 分散在 utils/ |
| **账户管理** | `utils/account_manager.cpp` | 密钥库管理、账户创建/导入/导出、账户列表维护 | `account_manager.cpp` | ~76KB |
| **配置与创世** | `common/` | config.json 管理、genesis.json 管理、任务池/线程池 | `config.cpp`, `genesis.cpp`, `task_pool.cpp` | ~15 文件 |
| **协议定义** | `proto/` + `pb/` | Protobuf 消息格式定义 (10 .proto) + 编译产物 | `block.proto`, `ca_protomsg.proto`, `sdk.proto` | 10 定义, pb产物 ~1.3MB |
| **日志** | `include/` | 基于 spdlog 的异步日志系统 | `logging.cpp/h` | ~2 文件 |
| **错误处理** | `errorn/` | 分层错误码定义 (ca/contract/global/rpc) | `error_module.h` | ~5 文件 |

---

## 三、关键设计决策

| # | 决策 | 理由 | 影响范围 |
|---|------|------|---------|
| 1 | **UTXO + Account 双模型** | UTXO 适合高频转账(安全性)，Account 适合合约(易用性/EVM兼容) | ca/transaction/, ca/evm/, db/ |
| 2 | **DAG 而非单链** | 允许并行出块，消除单一区块大小与间隔的限制 | ca/algorithm.cpp, ca/sync_block.cpp |
| 3 | **VRF 随机选择打包节点** | 不可预测/不可操纵的出块权分配，防止 MEV 前端运行 | ca/vrf_consensus.cpp, utils/ecvrf_*.cpp |
| 4 | **单一可执行文件** | 简化部署与运维，所有功能编译为一个 `mm` 二进制 | CMakeLists.txt |
| 5 | **MagicSingleton 全局单例** | 快速开发期的简单依赖管理方式，但导致高耦合、难测试 | utils/magic_singleton.h (20+ 实例) |
| 6 | **SHA256 而非 Keccak256 for MPT** | 与以太坊 Keccak256 不兼容，使跨链状态验证不可行【P0 修复项】 | mpt/trie.cpp:429 |
| 7 | **Protobuf 为统一序列化** | 跨语言互操作，类型安全，相比 JSON 体积更小 | proto/*.proto, pb/*.pb.cc |
| 8 | **RocksDB TransactionDB 模式** | 支持原子批量写入，保证多 Key 操作的 ACID | db/rocksdb_read_write.cpp |
| 9 | **EIP-1559 动态费用** | 基于以太坊 EIP-1559 的 Gas 费用市场机制 | ca/transaction/fee_calculator.h |
| 10 | **ECDH + 压缩加密传输** | 点对点密钥交换后压缩+加密，兼顾安全与带宽 | net/key_exchange.cpp, net/pack.cpp |

---

## 四、模块依赖总览 (简化)

```
entry.cpp
  └─> main/main.cpp: Init()
        ├─> Config / Genesis / Account / DB  (顺序初始化)
        ├─> CaInit()
        │     ├─> net/  (消息注册)
        │     ├─> db/   (数据查询)
        │     └─> utils/ (VRF, 账户)
        └─> NetInit()
              ├─> epoll 事件循环
              ├─> Protobuf 消息分发
              └─> ECDH 密钥交换

所有模块依赖:
  ├─> pb/   (Protobuf 编译产物)
  ├─> utils/ (crypto, account_manager, time_util, ...)
  └─> include/ (logging, scope_guard)
```

详细依赖分析请参见 [模块依赖关系文档](../../module_dependency.md)。

---

## 五、相关文档

| 文档 | 路径 | 说明 |
|------|------|------|
| 架构概览 | `../../architecture_overview.md` | 目录结构、分层架构、入口点、单例列表 |
| 模块依赖 | `../../module_dependency.md` | 10 个模块的 include/链接依赖图 |
| 启动流程 | `../../startup_flow.md` | Init() 7 步启动详解 |
| 重构风险 | `../../refactor_risk_overview.md` | 高风险区域与耦合分析 |
| 重构规划 | `../../refactor_master_plan.md` | P0-P3 优先级、目标目录结构 |
| 核心模块索引 | `../03_core_modules/` | 10 个核心模块的详细索引 |
| 构建系统 | `../02_build_system/` | CMake 配置与第三方依赖 |
