# 02 — 构建系统 (Build System)

> **文档阶段**: 阶段5 — 重组索引
> **项目**: MeMeChain (`mm`)
> **最后更新**: 2026-05-26

---

## 一、构建配置摘要

| 属性 | 值 |
|------|-----|
| 构建系统 | CMake (>= 3.15) |
| 编译入口 | `entry.cpp` → `main/main.cpp` |
| 输出产物 | `bin/mm` (单一可执行文件) |
| 语言标准 | C++20 |
| 测试框架 | GTest (Google Test) |
| 编译脚本 | `xbuild.sh` |
| 配置位置 | `<源码根>/CMakeLists.txt` |

### 构建入口说明

- `CMakeLists.txt` 第 87-88 行明确将 `entry.cpp` 从 `SOURCES` 中排除 (`list(REMOVE_ITEM SOURCES ${MAIN_FILE})`)
- `entry.cpp` 和 `main/main.cpp` 各自定义了 `main()` 函数
- 【需人工验证】实际编译使用的入口可能是 `entry.cpp` 中的 `main()`，`main/main.cpp` 可能通过 `test_main.cpp` 编译为独立测试入口

---

## 二、第三方依赖表

| 依赖 | 版本 | 用途 | 链接方式 | 源码位置 |
|------|------|------|---------|---------|
| **RocksDB** | 9.6.1 | KV 存储引擎 (TransactionDB 模式) | 静态库 | `deps/rocksdb-v9.6.1/` |
| **Protobuf** | 3.20.3 | 消息序列化/反序列化 | 静态库 | `deps/protobuf-v3.20.3/` |
| **OpenSSL** | 3.5.1 | 密码学原语 (ECDSA/SHA256) + TLS | 静态库 | `deps/openssl-3.5.1/` |
| **evmone** | (独立构建) | EVM 字节码执行引擎 | 静态库 (libevmone-standalone.a) | `deps/evmone/` (deps_build 管理) |
| **Boost** | 1.89.0 | filesystem, thread, chrono, atomic | 静态库 | `deps/boost_1_89_0/` |
| **spdlog** | 1.8.2 | 异步日志系统 | 静态库 | `deps/spdlog-v1.8.2/` |
| **nlohmann/json** | 3.12.0 | JSON 解析 (配置/创世/RPC 响应) | Header-only | `deps/json-v3.12.0/` |
| **cpp-httplib** | (内置) | HTTP 服务器 (RPC/回调端点) | Header-only | `net/httplib.h` (~195KB) |
| **fmt** | 7.1.3 | 字符串格式化 (spdlog 底层依赖) | 静态库 | `deps/libfmt-7.1.3/` |
| **ethash** | 1.1.0 | 以太坊哈希算法 (Ethash) | Header-only | `deps/ethash-v1.1.0/` |
| **intx** | 0.12.1 | 256-bit 大整数运算 (evmone 依赖) | Header-only | `deps/intx-v0.12.1/` |
| **silkpre** | (独立构建) | 自定义 SilkPre 签名算法 | 静态库 (libsilkpre-standalone.a) | `silkpre/` (独立 CMake 项目) |
| **qrcode** | 1.8.0 | QR 码生成 (账户导出/分享) | 静态库 | `deps/qrcode-v1.8.0/` |
| **GTest** | (内置) | 单元测试框架 | 静态库 | 测试目录 |

### Protobuf 协议定义

| .proto 文件 | 用途 | 编译产物大小 |
|-------------|------|-------------|
| `interface.proto` | 接口消息 | ~635KB (.pb.cc) |
| `sync_block.proto` | 区块同步消息 | ~324KB (.pb.cc) |
| `sdk.proto` | SDK 消息 | ~243KB (.pb.cc) |
| `ca_protomsg.proto` | 共识层消息 | - |
| `block.proto` | 区块数据结构 | - |
| `transaction.proto` | 交易数据结构 | - |
| `net.proto` | 网络层消息 | - |
| `key_exchange.proto` | ECDH 密钥交换消息 | - |
| `common.proto` | 公共消息定义 | - |
| `sign.proto` | 签名消息 | - |

---

## 三、构建命令示例

```bash
# 进入源码根目录
cd /home/wbl/mm/

# 方式一: 使用编译脚本
chmod +x xbuild.sh
./xbuild.sh

# 方式二: CMake 手动构建
mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(nproc)

# 方式三: Debug 构建 (含测试)
mkdir -p build_debug && cd build_debug
cmake .. -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTS=ON
make -j$(nproc)

# 运行测试
./bin/test_runner

# 生成 Protobuf 代码 (通常已预生成)
cd tools && bash gen_proto.sh

# 运行节点
./bin/mm --config /path/to/config.json
```

---

## 四、目录结构 (构建相关)

```
/home/wbl/mm/
├── CMakeLists.txt          # 顶层构建配置
├── xbuild.sh               # 一键编译脚本
├── entry.cpp               # 编译入口 (可能被排除)
├── test_main.cpp            # 测试入口
├── cmake/                   # CMake 工具模块
├── deps/                    # 第三方依赖源码
│   ├── boost_1_89_0/
│   ├── rocksdb-v9.6.1/
│   ├── openssl-3.5.1/
│   ├── protobuf-v3.20.3/
│   ├── spdlog-v1.8.2/
│   ├── evmone/
│   ├── ethash-v1.1.0/
│   ├── intx-v0.12.1/
│   ├── json-v3.12.0/
│   ├── libfmt-7.1.3/
│   ├── qrcode-v1.8.0/
│   └── threadpool/
├── deps_build/              # 第三方依赖编译产物 (静态库)
├── 3rd/                     # 第三方源码压缩包备份
├── silkpre/                 # SilkPre 独立 CMake 项目
├── tools/
│   └── gen_proto.sh         # Protobuf 代码生成脚本
└── build/ / build_debug/    # 构建输出目录
```

---

## 五、关键注意事项

1. **巨型编译单元**: `algorithm.cpp` (382KB)、`http_api.cpp` (223KB)、`txhelper.cpp` (138KB) 等巨型文件导致增量编译耗时长。重构规划 (P2) 建议拆分为 15 个子模块。

2. **标头依赖爆炸**: `net/api.h` 包含了几乎所有网络子模块头文件，`ca/ca.h` 包含了多个交易类型头文件，任何修改都触发大范围重编译。

3. **静态链接全部依赖**: 所有第三方库均以静态库方式链接，最终产物 `bin/mm` 为单一可执行文件，无需运行时依赖。

4. **预编译头 (PCH)**: 未使用预编译头文件，可能影响编译速度。

5. **Protobuf 代码生成**: Protobuf 编译产物 (`.pb.cc/h`) 已预生成在 `pb/` 目录，通常不需要重新生成。如需修改协议，运行 `tools/gen_proto.sh` 并重新编译。

6. **【需人工验证】** `entry.cpp` 的 `main()` 与 `main/main.cpp` 的 `main()` 哪个是实际编译入口，取决于 CMakeLists.txt 中 SOURCES 变量是否排除 `entry.cpp`。

---

## 六、相关文档

| 文档 | 路径 | 说明 |
|------|------|------|
| 架构概览 | `../../architecture_overview.md` | 第5节: 第三方依赖完整列表 |
| 模块依赖 | `../../module_dependency.md` | 模块间链接关系 |
| 核心模块 | `../03_core_modules/` | 各模块源码结构 |
| 启动流程 | `../../startup_flow.md` | Init() 顺序初始化 |
| 重构规划 | `../../refactor_master_plan.md` | P2 策略: 拆分巨型文件 |
| 模块-存储 | `../../module-storage/` | RocksDB 构建与初始化 |
| 模块-加密 | `../../module-crypto/` | OpenSSL/silkpre 集成 |
| 模块-EVM | `../../module-evm/` | evmone 静态库链接 |
