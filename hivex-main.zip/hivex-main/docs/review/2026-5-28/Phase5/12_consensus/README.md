# 12_consensus -- VRF 共识机制

> MeMeChain DAG 共识系统索引。涵盖 VRF 10 秒周期共识 / 种子生成 / 打包节点选择 / VRF 签名验证 / 异常节点检测与惩罚 / 拜占庭容错 / 分叉解决。
>
> 上级目录: [../README.md](../README.md)

---

## 1. 共识架构概览

MeMeChain 采用 **DAG + VRF 混合共识**机制: 同一高度允许多个区块共存 (DAG 分叉)，通过 VRF (可验证随机函数) 每 10 秒随机选择打包节点，共识权重选择主链。

```
VRF 共识周期 (10秒)
    |
    v
┌──────────────┐    ┌────────────────┐    ┌─────────────────┐
│ 种子生成     │ -> │ VRF 签名验证   │ -> │ 打包节点选择    │
│ floor(t/10)  │    │ 时间/质押/去重 │    │ 频率计算+随机   │
│ * 10         │    │ 签名/blockinfo │    │ kConsensus=3    │
└──────────────┘    └────────────────┘    └─────────────────┘
                                                  |
                                                  v
                                          ┌─────────────────┐
                                          │ 区块打包+广播    │
                                          │ composeEndBlock  │
                                          │ BlockStorage     │
                                          └─────────────────┘
```

---

## 2. VRF 共识核心机制

### 2.1 10 秒周期

| 参数 | 值 | 定义位置 |
|------|-----|---------|
| 周期时长 | 10 秒 | CYCLE_DURATION_SECONDS |
| 种子计算 | `seconds -= seconds % CYCLE_DURATION_SECONDS` | vrf_consensus.cpp:628-633 |
| 周期对齐 | `sleep_until(nextCycleStart)` | vrf_consensus.cpp:284-336 |
| 线程类型 | detached, 无限循环 | VRFConsensusNode::run() |

### 2.2 VRF 种子生成

```
generateVRSeed():
  floor(currentTime / 10) * 10
  -> 每个 10 秒周期产生统一的种子值
```

### 2.3 VRF 结构体生成

| 字段 | 来源 | 数量 |
|------|------|------|
| seed | 当前 10 秒周期种子 | 1 |
| blockinfo | 从链顶倒查 10 个高度, 每个取 hash 前 8 字符 | 10 |
| 签名 | ECDSA 签名(整个 VRFConsensusInfo, 不含签名字段) | 1 |

代码位置: `generateVRFStructure()` (vrf_consensus.cpp:82-122)

### 2.4 VRF 请求验证

```mermaid
flowchart TD
    A[receiveVRRequest] --> B{时间差 <= 10s?}
    B -->|否| X1[丢弃]
    B -->|是| C{有质押资格?}
    C -->|否| X2[丢弃]
    C -->|是| D{blockinfo 数量 = 10?}
    D -->|否| X3[丢弃]
    D -->|是| E{blockinfo 有重复 hash?}
    E -->|是| X3
    E -->|否| F{ECDSA 签名验证通过?}
    F -->|否| X4[丢弃]
    F -->|是| G[加入 validatedVRfs]
    G --> H[vrfBroadcastMessage 转发]
```

代码位置: `receiveVRRequest()` (vrf_consensus.cpp:166-226)。**额外增加 blockinfo 哈希去重检查 (152-159)，规范未提及但属安全性增强。**

---

## 3. 打包节点选择

### 3.1 频率计算

| 步骤 | 描述 | 位置 |
|------|------|------|
| 1. 取倒数第 3 个周期 | `std::prev(validatedVRfs.end(), 3)` | vrf_consensus.cpp:339 |
| 2. 计算 optimalFrequency | `sum(avgRatio * h) / sum(h)` (加权平均) | vrf_consensus.cpp:400 |
| 3. validateNodeThreshold | `size * 0.55` (55% 节点合格) | vrf_consensus.cpp:420 |
| 4. frequencyThreshold 递减 | 从 optimalFrequency 逐步降低 (步长 0.1) | vrf_consensus.cpp:423-481 |

### 3.2 随机选择

| 步骤 | 描述 | 位置 |
|------|------|------|
| 1. 按频率升序排序 | 低频率优先 | vrf_consensus.cpp:544 |
| 2. maxValue 递减筛选 | 从 1.0 逐步递减 | vrf_consensus.cpp:562 |
| 3. 随机种子 | SHA256(所有 signatureHash 之和) | vrf_consensus.cpp:521 |
| 4. shuffle + 选取 | `selectRandomNodes()` 随机选择 kConsensus 个 | vrf_consensus.cpp:521-541 |

**打包节点数**: `kConsensus = 3`

### 3.3 选择流程总览

```mermaid
flowchart TD
    A[computeMaxHeightWithMinFrequency] --> B[validatedVRfs.size() >= 3?]
    B -->|否| C[数据不足, 等待]
    B -->|是| D[取倒数第3周期]
    D --> E[计算 optimalFrequency]
    E --> F[设置 validateNodeThreshold = 0.55]
    F --> G[frequencyThreshold 递减筛选]
    G --> H{合格节点 >= kConsensus?}
    H -->|否| G
    H -->|是| I[按频率升序排序]
    I --> J[SHA256(sumSeed) 种子]
    J --> K[shuffle + 选取前 kConsensus]
    K --> L[extractPackagerVRFData 返回]
```

---

## 4. 区块验证流程

### 4.1 多阶段验证

```
BlockMsg 到达
    |
    v
1. memVerifyBlock (内存验证)
   - 版本检查 (kCurrentBlockVersion)
   - 大小检查 (< 4MB)
   - 哈希校验 (CalcBlockHash)
   - Merkle 根校验 (calculateBlockMerkle)
   - 交易去重
    |
    v
2. VerifyBlock (完整验证)
   - prevhash 存在性
   - 高度连续性
   - 时间窗口检查
   - 交易验证 (TaskPool 并行)
   - 合约验证 (verifyContractBlock)
    |
    v
3. verifyPreSaveBlock_ (预保存验证)
   - 签名数量 == kConsensus
    |
    v
4. SaveBlock (保存)
   - RocksDB 事务提交
   - TransactionCommit
```

### 4.2 区块哈希计算

```cpp
block.clear_hash();       // 清除 hash 字段
block.clear_signature();  // 清除 signature 字段
return Getsha256Hash(block.SerializeAsString());  // SHA256 哈希
```

### 4.3 Merkle 根计算

```cpp
// 双 SHA256 归并 Merkle 树
// 每轮: hash = SHA256(SHA256(tx1) + SHA256(tx2))
// 迭代归并直至单根
```

---

## 5. 区块同步机制

### 5.1 三种同步模式

| 模式 | 触发条件 | 方式 | 位置 |
|------|---------|------|------|
| **NewSync** | 本地高度接近全网高度 | SumHash 验证 -> 差异哈希 -> 下载区块 | sync_block.cpp |
| **FastSync** | `runFastSync = true` (SetFastSync 触发) | 哈希列表 -> 批量下载 -> 快速应用 | sync_block.cpp |
| **FromZero** | chainHeight - localHeight > hashRangeSum | 千区块 SumHash 验证 -> 逐高度下载 | sync_block.cpp |

### 5.2 Sync 状态机

```
Start
  |
  v
SyncNormal (10s 周期, nodeSelfHeight < chainHeight)
  |
  ├─ 6 周期未同步 -> ByzCheck -> NewSync
  ├─ runFastSync=true -> SyncFast
  └─ 高度差过大 -> SyncFromZero

SyncFast
  ├─ 成功 -> SyncNormal
  └─ 失败 >= 5 次 -> SyncFromZero

SyncFromZero
  └─ 完成 -> SyncNormal
```

### 5.3 同步线程

- 线程: `SyncBlock::ThreadStart()` (sync_block.cpp:175-395)
- 周期: `SYNC_HEIGHT_TIME = 10` 秒
- 同步高度范围: `syncHeightCount = 100`

---

## 6. DAG 分叉检测与解决

### 6.1 分叉检测

| 参数 | 值 | 位置 |
|------|-----|------|
| 检测周期 | 10 秒 (非规范中的 15 秒) | sync_block.cpp:37 |
| 查询对象 | 质押节点 (VerifyBonusAddr 过滤) | block_helper.cpp:2113 |
| 高度范围 | +/- 100 | sync_block.cpp |
| 响应阈值 | sendNum * 0.8 (80%) | sync_block.cpp |
| 共识判定 | 51% (规范) vs 75% (实现) | block_helper.cpp:2168 |

**偏差**: 规范定义 51% 共识阈值，但实现使用 75%。更保守但偏离规范 (DEV-2)。

### 6.2 主链选择

当前实现 (`getChainHeight()` block_helper.cpp:2113-2177):
- 取节点高度第 75 百分位作为全网高度
- 用 `VerifyBonusAddr` 过滤有质押资格节点
- **未按共识权重排序** (DEV-1)

规范定义三级优先级: 累计共识权重 > 最长链 > 时间戳，但实现仅采用简单高度分位统计。

### 6.3 区块回滚

| 参数 | 值 |
|------|-----|
| 回滚超时保护 | RollBackTime = 15 秒 |
| 快速同步回滚深度 | runFastSyncCount >= 5 后触发从零同步 |
| 回滚操作 | RollBackToHeight / rollback_by_hash / RollbackBlock |

**Critical 风险 (P0-2)**: 回滚无原子 UTXO 恢复保证，两条回滚路径 (`algorithm.cpp:7511` vs `block_helper.cpp:1155`) 不一致。

---

## 7. 拜占庭容错

### 7.1 checkByzantineFault

声明: `sync_block.h:96` (`SyncBlock::checkByzantineFault`)

```cpp
checkByzantineFault(receiveCount, hitCount)
// hitCount / receiveCount < threshold -> 拜占庭行为
```

**Q-1**: 具体阈值需在 sync_block.cpp 函数体中确认。

### 7.2 千区块 SumHash 验证

CheckBlocks 定时器 (每 30 秒):
1. 计算本地千区块 SumHash
2. 向质押节点查询 SumHash
3. 等待 >= 90% 响应 (90s 超时)
4. 对比本地 vs 远程
5. 不匹配 -> calculateByzantineSumHash -> 可能触发 performNewSynchronization

---

## 8. 异常节点检测与惩罚

### 8.1 检测算法

```
fetchAbnormalSignAddrListByPeriod(period):
  1. 获取 period-1 周期的签名地址
  2. 计算平均签名数
  3. 低于平均的节点 -> dividendRate = own / average
  4. 返回异常节点列表
```

代码位置: `algorithm.cpp:66-106`

**Bug (P1-1)**: 签名平均数使用整数除法 (`algorithm.cpp:95`)，可能导致阈值不准确。

### 8.2 惩罚机制

异常节点的委托者奖励系数降低: `dividendRate = ownSignCount / averageSignCount`

---

## 9. 规范对照与偏差

| 功能点 | 规范定义 | 当前实现 | 偏差严重度 |
|--------|---------|----------|-----------|
| VRF 周期 | seed = floor(time / 10) * 10 | `generateVRSeed()` 一致 | 无 |
| VRF blockinfo | 最近 10 区块, hash 前 8 字符 | 一致 + 去重检查 | 增强 |
| VRF 签名范围 | seed + blockinfo | 整个 VRFConsensusInfo (不含签名字段) | 无 |
| 打包节点选择 | 频率+随机, kConsensus=3 | 倒数第 3 周期频率 + SHA256 种子 shuffle | 无 |
| 主链选择 | 共识权重 > 最长链 > 时间戳 | 75 百分位高度 (未比较权重) | **High** |
| 共识阈值 | 51% | 75% | **Medium** |
| 区块签名验证 | 需验证节点为合法打包节点 | 仅检查签名数量 == kConsensus | **Critical** |
| 同步周期 | 15 秒 | 10 秒 | Low |
| 回滚 | 原子 UTXO 恢复 | 两路径不一致 + 无原子保证 | **Critical** |
| 拜占庭容错 | checkByzantineFault | 声明存在, 具体实现待确认 | 待验证 |

---

## 10. 已知问题汇总

| 编号 | 问题 | 严重度 | 位置 | 修复计划 |
|------|------|--------|------|---------|
| P0-2 | 回滚无原子 UTXO 恢复 | Critical | algorithm.cpp:7511, block_helper.cpp:1155 | P0 |
| P0-3 | 区块签名不验证打包节点资格 | Critical | algorithm.cpp:3923 | P0 |
| P0-9 | 主链选择用 75 分位而非共识权重 | Critical | block_helper.cpp:2113 | P0 |
| DEV-2 | 共识阈值 75% (非 51%) | Medium | block_helper.cpp:2168 | P2 |
| P1-1 | 签名平均整数除法错误 | High | algorithm.cpp:95 | P1 |
| P1-7 | 块签名阈值混乱 (51/66/80/90%) | High | 多处 | P1 |
| Q-1 | checkByzantineFault 阈值待确认 | 待验证 | sync_block.cpp | -- |

---

## 11. 文档索引

### 11.1 本目录文档

| 文档 | 内容 |
|------|------|
| (待产出) VRF 共识协议规范 | VRF 周期 / 种子 / 选择算法 / 签名验证 |
| (待产出) DAG 分叉解决策略 | 分叉检测 / 共识权重 / 回滚机制 |
| (待产出) 区块验证流程规范 | 多阶段验证 / Merkle 树 / 异常处理 |

### 11.2 相关文档

| 文档 | 路径 | 说明 |
|------|------|------|
| DAG 共识模块概览 | [../../module-dag-consensus/module_overview.md](../../module-dag-consensus/module_overview.md) | 共识模块完整概述 |
| DAG 共识状态流转 | [../../module-dag-consensus/state_flow.md](../../module-dag-consensus/state_flow.md) | 区块 / VRF / 同步状态机 |
| DAG 共识线程模型 | [../../module-dag-consensus/thread_model.md](../../module-dag-consensus/thread_model.md) | 共识线程分析 |
| DAG 共识调用链 | [../../module-dag-consensus/call_chain.md](../../module-dag-consensus/call_chain.md) | 共识调用堆栈 |
| DAG 共识存储模型 | [../../module-dag-consensus/storage_model.md](../../module-dag-consensus/storage_model.md) | 区块存储 |
| 区块同步流程 | [../../03_core_flows/flow-02-block-sync/sequence_flow.md](../../03_core_flows/flow-02-block-sync/sequence_flow.md) | 同步时序流程 |
| 区块同步状态 | [../../03_core_flows/flow-02-block-sync/state_transition.md](../../03_core_flows/flow-02-block-sync/state_transition.md) | 同步状态机 |
| 启动流程 | [../../03_core_flows/flow-06-startup/sequence_flow.md](../../03_core_flows/flow-06-startup/sequence_flow.md) | 节点启动 |
| 重构总体规划 | [../../refactor_master_plan.md](../../refactor_master_plan.md) | 共识层重构 P0/P1 |
| 本阶段密码学 | [../11_crypto/README.md](../11_crypto/README.md) | ECVRF 密码学基础 |
| 本阶段状态机 | [../14_state_machine/README.md](../14_state_machine/README.md) | 全局状态机索引 |

---

*本文档基于阶段 2 (module-dag-consensus) 和阶段 3 (flow-02-block-sync) 分析综合编写。标注 "【需人工验证】" 处需进一步确认。*
