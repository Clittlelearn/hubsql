# MeMeChain Governance Rules -- Fact Base

## 1. Proposal Initiation

- **Proposer**: Only the genesis account can initiate proposals.
  - Source: `ca/ca.h:187-188` comments indicate genesis account for `HandleProposal()` and `revokeProposalRequest()`.
  - 可信度: 高

- **ProposalInfo structure**: Defined in `TxHelper::ProposalInfo`:
  ```cpp
  struct ProposalInfo {
      int version;           // KProposalInfoVersion = 0
      uint64_t BeginTime;
      uint64_t EndTime;
      std::string Name;
      std::string ExchangeRate;
      uint32_t CrossChainTxType;
      std::string ContractAddr;
      std::string CrossChainInvestmentContractAddr;
      uint64_t canBeStake;
      uint64_t MIN_VOTE_NUM;
      std::string Title;
      std::string Identifier;
      std::string PeerChainTokenAddr;
  };
  ```
  - Source: `ca/txhelper.h:37-69`
  - 可信度: 高

- **KProposalInfoVersion = 0**: Current proposal info version.
  - Source: `ca/global.h:154`
- **KRevokeProposalInfoVersion = 0**: Current revoke proposal info version.
  - Source: `ca/global.h:156`
- 可信度: 高

- **Proposal transaction type**: `TxType::PROPOSAL = 11`
  - Source: `ca/global.h:103`

## 2. Vote Eligibility

- **Voters**: All users who have locked (LOCK) tokens via the Lock mechanism.
  - `LOCK = 9` transaction type grants voting rights.
  - Source: `ca/global.h:100`

- **Vote asset type**: `ASSET_TYPE_VOTE = "Vote"`
  - Source: `ca/global.h:67`

- **Asset type MM**: `assetType_MM = "MM"` -- base asset type hash.
  - Source: `ca/global.h:68`

## 3. Vote Rules

- **Vote type**: Binary choice:
  ```cpp
  enum class VoteType {
      Against = 0,  // 反对
      Approve = 1,  // 赞成
      Count         // enum count marker
  };
  ```
  - Source: `ca/global.h:137-141`
  - 可信度: 高

- **Vote weight**: Vote weight equals the amount of locked tokens (`voteNumber`).
  - Source: `ca/algorithm.h:373` -- `int addVoteCount(DBReadWriter& db, const std::string &assetType, const int voteType, const std::string& addr, const uint64_t& voteNumber);`

- **Duplicate prevention**: `CheckForDuplicateVotes()` prevents same address from voting twice on the same proposal.
  - Source: `ca/algorithm.h:371` -- `int CheckForDuplicateVotes(const std::string &assetType, const std::string addr);`
  - 可信度: 高

- **Vote count retrieval**: `GetVoteNum()` returns `approveNum` and `againstNum`.
  - Source: `ca/algorithm.h:369`
  - 可信度: 高

## 4. Vote Cycle Timing

- **KVoteCycle = 10 * 60 * 1000000** (= 10 minutes in microseconds): Vote period duration.
  - Source: `ca/global.h:132` -- `const uint32_t KVoteCycle = 10 * 60 * 1000000; //10 分钟`
  - 可信度: 高

- **KVrfVoteBeginTime = 10 * 1000000** (= 10 seconds in microseconds): VRF voting begin time.
  - Source: `ca/global.h:133` -- `const uint32_t KVrfVoteBeginTime = 10 * 1000000; //10 秒`
  - 可信度: 高

- **CheckVoteTxInfo()**: Validates vote transaction info.
  - Source: `ca/algorithm.h:377`
  - 可信度: 高

## 5. Vote Result Determination

- **Approval criterion**: `approveNum > againstNum` => proposal passes.
  - Source: `ca/algorithm.h:369` defines the vote count query; result determination is in the calling logic.
  - 可信度: 中 (API defined but exact comparison operator not verified in code)

- **MIN_VOTE_NUM**: Each proposal sets a minimum vote number threshold.
  - Part of `ProposalInfo` (field `MIN_VOTE_NUM`).
  - Source: `ca/txhelper.h:49`
  - 可信度: 高

## 6. Lock/Unlock Mechanism

- **LOCK_AMOUNT = 1** (in standard precision, = 1 / kDecimalNum = 0.00000001):
  - Source: `ca/global.h:37` -- `const uint32_t LOCK_AMOUNT = 1;//1000;`
  - Note: Original value was 1000 but has been changed to 1 (commented out).
  - 可信度: 高

- **kLockTypeNet = "LockNet"**: Lock type identifier.
  - Source: `ca/global.h:57`
  - 可信度: 高

- **VIRTUAL_LOCK_ADDRESS = "LockVirtualStake"**: Virtual lock address.
  - Source: `ca/global.h:58`
  - 可信度: 高

- **GetLockValue()**: Retrieves locked amount for an address.
  - Source: `ca/algorithm.h:389`

- **HandleLock()**: Lock menu handler.
  - Source: `ca/ca.h:185`
- **HandleUnLock()**: Unlock menu handler.
  - Source: `ca/ca.h:187`
- 可信度: 高

## 7. Proposal Revocation

- **REVOKEPROPOSAL = 12**: Transaction type for proposal revocation.
  - Source: `ca/global.h:104`

- **revokeProposalRequest()**: Handler for revoking proposals.
  - Source: `ca/ca.h:190`

- **canBeRevoked()**: Checks if an asset type can be revoked.
  - Source: `ca/algorithm.h:364`

- **GetCanBeRevokeAssetType()**: Gets the asset type eligible for revocation.
  - Source: `ca/algorithm.h:386`

## 8. Proposal Cross-Chain Types

```cpp
enum class CrossChainTxType {
    EnteringMore = 0,           // 越入越出 (inbound+outbound)
    CrossChainInvestment = 1,   // 跨链投资 (cross-chain investment)
    Both = 2,                   // 两者皆含
    Null = 3,                   // 不含任何跨链交易
};
```
- Source: `ca/global.h:145-151`
- 可信度: 高

## 9. Vote Handling Functions

- **addVoteCount()**: Increments vote count and adds voter ID.
  - Source: `ca/algorithm.h:373`

- **subVoteNum()**: Decrements vote count and removes voter ID (for undo/revert).
  - Source: `ca/algorithm.h:375`

- **GetVoteAssetType()**: Gets currently votable assets.
  - Source: `ca/algorithm.h:349`

- **AssetTypeIsValid()**: Validates if an asset type is valid.
  - Source: `ca/algorithm.h:354`

- **fetchAvailableAssetType()**: Gets all available asset types for voting.
  - Source: `ca/algorithm.h:359`

- **GetUnavailableAssetType()**: Gets all unavailable asset types.
  - Source: `ca/algorithm.h:361`
- 可信度: 高

## 10. Treasury

- **HandleTresury()**: Claim treasury fund rewards handler.
  - Source: `ca/ca.h:195`
- **CheckFundQualificationAndGetRewardAmount()**: Validates fund claim qualification.
  - Source: `ca/transaction.h:211`
- **VOTE_CIRCULATION = 100000000000000000**: Vote circulation amount constant.
  - Source: `ca/global.h:52`
- 可信度: 高
