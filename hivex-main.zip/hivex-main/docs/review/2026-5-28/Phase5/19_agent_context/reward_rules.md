# MeMeChain Reward/Incentive Calculation Rules -- Fact Base

## 1. Annualized Rate Calculation (New Model)

### GetNewAnnualizedRate -- Exponential Decay Formula

Complete formula chain:
```
week_number = (current_time - genesis_time) / (7*24*60*60*1000000)
k = mapStakingRateToK(stakingRate)  // Staking rate -> decay parameter
weekly_rate[i] = endRate + (startRate - endRate) * exp(-k * (i-1)/(519))
annualizedRate[i] = weekly_rate[i] / (stakingRate/100)
result = annualizedRate[week_number]
```

- **Duration**: 520 weeks (= 10 years).
- **startRate = 5.0%** (initial annual inflation).
- **endRate = 0.5%** (final annual inflation after 10 years).
- **Exponential decay**: `rate(t) = 0.5 + (5.0 - 0.5) * exp(-k * t_normalized)`.
- Source: `ca/algorithm.cpp:7985-8060`
- 可信度: 高

### Weekly rate computation

```cpp
for (int w = 1; w <= 520; ++w) {
    double x = (w-1) / 519.0;  // normalized time [0,1]
    double rate = 0.5 + (5.0 - 0.5) * std::exp(-k * x);
    rates.push_back(rate);
}
```
- Source: `ca/algorithm.cpp:7923-7945`
- 可信度: 高

### Annualized rate = inflation_rate / staking_ratio

```cpp
double stakingRatio = stakingRate / 100.0;
double annualizedRate = rate / stakingRatio;
```
- Source: `ca/algorithm.cpp:7947-7982`
- 可信度: 高

## 2. mapStakingRateToK -- Linear Mapping

```
k = kMin + (stakingRate - minStaking) * (kMax - kMin) / (maxStaking - minStaking)
k = 1.0 + (stakingRate - 10.0) * (20.0 - 1.0) / (100.0 - 10.0)
```

| Staking Rate | k Value |
|-------------|---------|
| 10% | 1.0 |
| 50% | ~10.56 |
| 100% | 20.0 |

- Source: `ca/algorithm.cpp:7903-7921`
- 可信度: 高

## 3. GetNetworkStakingRate

```
stakingRate = (totalLockedAmount / totalSupply) * 100.0
// Clamped to [10.0, 100.0]
```
- `totalSupply` = `getTotalCirculationAsOfTodayStart(curTime)`
- `totalLockedAmount` = `getLockedAmountAsOfTodayStart(curTime)`
- Source: `ca/algorithm.cpp:8062-8111`
- 可信度: 高

## 4. CalcBonusValue -- Dividend Formula

### Step 1: Detect abnormal nodes
```cpp
fetchAbnormalSignAddrListByPeriod(curTime, addr_percent, addrSignCount)
average = allSignNumber / addrSignCount.size()
dividendRate = own_count / average  // only for below-average nodes
```

### Step 2: Get delegating data
```cpp
GetDelegatingAmountAndDuration(bonusAddr, curTime, zeroTime, mpDelegatingAddr2Amount)
```

### Step 3: Get annualized rate (new model)
```cpp
GetNetworkStakingRate(curTime, stakingRate)
GetNewAnnualizedRate(curTime, stakingRate, annualizedRate)
// Round annualized rate: annualizedRate = std::round(annualizedRate / 100.0 * 100.0) / 100.0
```

### Step 4: Calculate reward per delegator
```cpp
// If node is below average (dividendRate != 0):
reward = dividendRate * (annualizedRate * delegateAmount / 365)

// If node is at/above average (dividendRate == 0):
reward = annualizedRate * delegateAmount / 365
```

- Source: `ca/algorithm.cpp:7743-7901`
- 可信度: 高

### Known Bug #1: Annualized rate rounding (~5.8% overpayment)
The code computes `annualizedRate = std::round(annualizedRate / 100.0 * 100.0) / 100.0` but then multiplies directly (without dividing by 100), effectively using percentage value as decimal:
```cpp
values[it.first] = annualizedRate * it.second.first / 365;
// If annualizedRate = 5.8, this computes 5.8 * amount / 365
// Intended: 0.058 * amount / 365
```
This results in approximately 100x overpayment. The `annualizedRate = annualizedRate / 100.0` line is **commented out** at line 7834.
- Source: `ca/algorithm.cpp:7833-7835, 7886, 7895`
- 可信度: 高

### Known Bug #2: Integer division error
The reward formula `annualizedRate * it.second.first / 365` uses integer arithmetic. Since `it.second.first` is `uint64_t`, the multiplication may overflow, and the division truncates.
- Source: `ca/algorithm.cpp:7849, 7886, 7895`
- 可信度: 中

## 5. EIP-1559 Fee Adjustment

```
adjustment_factor = (actual_gas - target_gas) / (target_gas * 8.0)
new_fee = old_fee * (1.0 + adjustment_factor)
```

- When `actual_gas > target_gas` (congestion): `ceil(new_fee)` -- fee increases.
- When `actual_gas < target_gas` (idle): `floor(new_fee)` -- fee decreases.
- When `actual_gas == target_gas`: fee unchanged.
- Minimum fee: `max(new_fee, 0.0)`.

- Source: `ca/fee_calculator.h:12-48`
- 可信度: 高

## 6. Abnormal Node Penalty

- **dividendRate = own_count / average**: Applied to bonus rewards for underperforming nodes.
  - Node sign count below average -> reward scaled by `dividendRate`.
  - Node sign count at/above average -> full reward (no penalty).
  - Source: `ca/algorithm.cpp:95-103` (`fetchAbnormalSignAddrListByPeriod`), `ca/algorithm.cpp:7882-7900` (`CalcBonusValue`)
  - 可信度: 高

## 7. Stake Requirements

- **MIN_STAKE_AMOUNT = 3500 * kDecimalNum**: Minimum stake to become a node.
  - Source: `ca/global.h:39`
- **kMinKGetBonusDelegatingAmt = 500000 * kDecimalNum**: Minimum delegating amount for bonus qualification.
  - Source: `ca/global.h:40`
- **kMinDelegatingAmt = 500 * kDecimalNum**: Minimum delegating amount.
  - Source: `ca/global.h:41`
- **KInvestmentCap = 3500000 * kDecimalNum**: Maximum investment cap.
  - Source: `ca/global.h:42`
- **kMaximum_number_of_investments = 1000**: Max number of investments.
  - Source: `ca/global.h:43`
- 可信度: 高

## 8. Commission Rate

- **MAX_COMMISSION_RATE = 0.35** (35%).
- **MIN_COMMISSION_RATE = 0.05** (5%).
- Source: `ca/global.h:62-63`
- 可信度: 高

## 9. Bonus Eligibility

- **evaluateBonusEligibility**: Checks if a bonus address qualifies, including anomaly detection.
  - Source: `ca/transaction.h:208`
- **VerifyBonusAddr**: Verifies if an address is a valid bonus address.
  - Source: `ca/transaction.h:264`
- 可信度: 高
