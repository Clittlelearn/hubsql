# MeMeChain Consensus Rules -- Fact Base

## 1. VRF Seed Generation (VRF Cycle)

- **CYCLE_DURATION_SECONDS = 10**: The VRF consensus cycle runs every 10 seconds.
  - Source: `ca/vrf_consensus.h:16` -- `const int CYCLE_DURATION_SECONDS = 10;`
  - 可信度: 高

- **Seed formula**: `seed = floor(current_time / 10) * 10`
  - Implementation: `generateVRSeed()` divides epoch seconds by `CYCLE_DURATION_SECONDS`, discards the remainder.
    ```cpp
    seconds -= seconds % CYCLE_DURATION_SECONDS;
    return std::to_string(seconds);
    ```
  - Source: `ca/vrf_consensus.cpp:628-633`
  - 可信度: 高

- **Next cycle boundary**: `cycleStartTimestamp()` adds `CYCLE_DURATION_SECONDS` and snaps to the next multiple.
  - Source: `ca/vrf_consensus.cpp:635-640`
  - 可信度: 高

- **Previous cycle lookup**: `getPreviousCycleTime()` subtracts `2 * CYCLE_DURATION_SECONDS` (uses data from 2 cycles ago for consensus).
  - Source: `ca/vrf_consensus.cpp:642-648`
  - 可信度: 高

- **Seed time validation**: reject if `|timeDiff| > 10` seconds.
  - Source: `ca/vrf_consensus.cpp:181-184`
  - 可信度: 高

## 2. Minimum Consensus Nodes

- **kConsensus = 3**: Minimum number of consensus nodes required.
  - Source: `ca/global.h:16` -- `static const int kConsensus = 3;`
  - 可信度: 高

- **MIN_SYNC_QUAL_NODES = 3**: Minimum qualified nodes for sync operations.
  - Source: `ca/global.h:20` -- `const uint32_t MIN_SYNC_QUAL_NODES = 3;`
  - 可信度: 高

- **send_node_threshold = 5**: Threshold for sending block stream.
  - Source: `ca/global.h:18`
  - 可信度: 高

## 3. Packager Node Selection Algorithm

- **computeMaxHeightWithMinFrequency**: Selects packager candidates by analyzing height-hash frequency across VRF submissions.
  - Algorithm steps:
    1. Collects height-hash votes from all VRF participants in the target period (skipped forward 2 cycles).
    2. Counts hash occurrences per height: `heightHashCounts[height][hash]++`.
    3. Computes frequency ratio per hash: `ratio = count / total_nodes_in_period`.
    4. Computes weighted average "optimal frequency": `optimalFrequency = sum(avgRatio[i] * height[i]) / sum(height[i])`.
    5. Filters hashes with `ratio >= optimalFrequency`.
    6. Counts how many optimal hashes each node contributed. Threshold starts at 55% of nodes, decrementing frequency by 0.1 until threshold met.
    7. Nodes achieving `frequency >= frequencyThreshold` become packager candidates.
  - Source: `ca/vrf_consensus.cpp:339-481`
  - 可信度: 高

- **extractPackagerVRFData**: Sorts candidates by frequency ascending, then selects `kConsensus` nodes from those with frequency >= decreasing threshold.
  - Uses `selectRandomNodes()` with SHA256-based shuffle for final selection.
  - Source: `ca/vrf_consensus.cpp:544-625`
  - 可信度: 高

- **Minimum VRF data threshold**: Requires `validatedVRfs.size() >= 3` before computing.
  - Source: `ca/vrf_consensus.cpp:344-348`
  - 可信度: 高

- **Validator node threshold**: `validateNodeThreshold = it->second.size() * 0.55` (55% of VRF participants).
  - Source: `ca/vrf_consensus.cpp:455`
  - 可信度: 高

## 4. Block Signature Verification

- **AddBlockSign**: Signs the serialized block (without signatures field) with the node's default private key (ECDSA secp256k1).
  - Process: `clear_signature()` -> `SerializeAsString()` -> `Getsha256Hash()` -> `TxHelper::Sign()` -> append signature.
  - Source: `ca/transaction.cpp:3495-3513`
  - 可信度: 高

- **VerifyBlockSign**: Clears signatures from block copy, SHA256 hashes the serialized block, verifies each signature against the public key.
  - Uses `Account::Verify()` with ECDSA secp256k1.
  - Source: `ca/transaction.cpp:3515-3545`
  - 可信度: 高

- **Block hash calculation**: `Getsha256Hash(SerializeAsString(block_without_signatures))`.
  - Used for both signing and verification.
  - Source: `ca/transaction.cpp:3499,3519`
  - 可信度: 高

## 5. Abnormal Node Detection

- **fetchAbnormalSignAddrListByPeriod**: Identifies underperforming nodes by comparing their sign count to the average.
  - `average = allSignNumber / addrSignCount.size()`
  - Nodes with `count < average` get a penalty ratio: `dividendRate = own_count / average`
  - Period uses `getPeriod(curTime) - 1` (previous period).
  - Source: `ca/algorithm.cpp:66-106`
  - 可信度: 高

- **dividendRate formula**: `dividendRate = node_sign_count / (total_sign_count / num_signing_nodes)`
  - Applied when `dividendRate != 0.0` (i.e., node's count is below average).
  - Source: `ca/algorithm.cpp:95-103`
  - 可信度: 高

## 6. Byzantine Fault Tolerance Threshold

- **checkByzantineFault**: BFT result checking function (returns bool).
  - Source: `ca/sync_block.h:96` -- `static bool checkByzantineFault(int receiveCount, int hitCount);`
  - Implementation in `ca/sync_block.cpp:2440`
  - 可信度: 高

- **55% validator threshold**: Used in VRF selection for determining qualified VRF participants.
  - Source: `ca/vrf_consensus.cpp:455`
  - 可信度: 中 (code uses 55%, but standard BFT would expect 67%)

- **75% failure rate for block status**: `_failureRate = 0.75` used in `BlockStorage`.
  - Source: `ca/block_stroage.h:238`
  - 可信度: 中

## 7. VRF Message Validation

- **validate_block_info**: Checks that a VRF message contains exactly 10 block references with no duplicate hashes, and the sender is a qualified bonus address.
  - Source: `ca/vrf_consensus.cpp:139-163`
  - 可信度: 高

- **VRF structure deduplication**: `checkVRFExists` prevents duplicate VRF submissions from the same node for the same seed.
  - Source: `ca/vrf_consensus.cpp:266-276`
  - 可信度: 高

- **MAX_VRFS_SIZE = 10**: Maximum number of VRF periods stored in memory before pruning.
  - Source: `ca/vrf_consensus.h:17`
  - 可信度: 高
