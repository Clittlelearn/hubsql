# MeMeChain EVM Integration Rules -- Fact Base

## 1. Contract Address Generation

- **EIP-161 / Ethereum-compatible**: `keccak256(rlp([sender_bytes, nonce]))` then take bytes [12..31] (last 20 bytes).
  - Implementation in `evm_utils::GenerateContractAddrEth()`:
    ```cpp
    auto rlp = RlpEncodeAddressNonce(sender_bytes, nonce);
    const auto h = evmone::keccak256(evmc::bytes_view{rlp.data(), rlp.size()});
    // Extract bytes 12-31
    for (size_t i = 12; i < 32; ++i) ss << hex << h.bytes[i];
    ```
  - Source: `utils/contract_utils.cpp:73-89`
  - 可信度: 高

- **EIP-55 Checksum address**: `evm_utils::ToChecksumAddress()` produces EIP-55 mixed-case addresses.
  - Source: `utils/contract_utils.cpp` via `GenerateAddr()` and checksum logic
  - 可信度: 高

- **CREATE2 address**: `calculateCreate2Address()` using `keccak256(0xff + sender + salt + keccak256(initCode))`.
  - Source: `ca/evm/evm_host.cpp:623-647`
  - 可信度: 高

- **Nonce source**: `evmEnvironment::GetNextNonce(from)` returns the next nonce.
  - Source: `ca/evm/evm_manager.cpp:69-70`
  - 可信度: 高

## 2. EvmHost Interface (16 evmc::Host methods)

All 16 `evmc::Host` methods are overridden in `EvmHost`:
| # | Method | Description |
|---|--------|-------------|
| 1 | `account_exists` | Account existence check |
| 2 | `get_storage` | Read contract storage |
| 3 | `set_storage` | Write contract storage |
| 4 | `get_balance` | Get account balance |
| 5 | `get_code_size` | Get contract code size |
| 6 | `get_code_hash` | Get contract code hash |
| 7 | `copy_code` | Copy contract code |
| 8 | `selfdestruct` | Selfdestruct handling |
| 9 | `call` | Cross-contract call |
| 10 | `get_tx_context` | Transaction context |
| 11 | `get_block_hash` | Block hash query |
| 12 | `emit_log` | Event log emission |
| 13 | `access_account` | Account access tracking (EIP-2929) |
| 14 | `access_storage` | Storage access tracking (EIP-2929) |
| 15 | `get_transient_storage` | Transient storage read (EIP-1153) |
| 16 | `set_transient_storage` | Transient storage write (EIP-1153) |

- Source: `ca/evm/evm_host.h:35-75`
- 可信度: 高

- **EvmHost data members**: accounts, tx_context, block_hash, call_result, recorded_blockhashes, recorded_account_accesses, recorded_calls, recorded_logs, recorded_selfdestructs, callInputsRecorded, code, gas_cost, coinTransfersInProgress, contractDataStorage.
  - Source: `ca/evm/evm_host.h:79-138`
  - 可信度: 高

## 3. MPT (Merkle Patricia Trie) Root Hash

- **Formula**: `Getsha256Hash(hex(RLP(node)))`
  - The `ToHash()` function:
    ```cpp
    dev::RLPStream rlp = Encode(n);
    dev::bytes data = rlp.out();
    std::string stringData = dev::toHex(data);
    strSha256 = Getsha256Hash(stringData);
    ```
  - Source: `mpt/trie.cpp:422-435`
  - 可信度: 高

- **DEV-与以太坊差异**: 以太坊使用 `Keccak256(rlp(node))` 作为 MPT 节点哈希，MeMeChain 使用 `SHA256(hex(RLP(node)))`。这导致与以太坊的 MPT 根哈希不兼容，无法直接用于跨链验证（如 LayerZero、Axelar 等桥接协议的轻客户端验证）。
  - 通过硬分叉修改: 是 (采用 Keccak256 替换 SHA256)
  - 可信度: 高

- **MPT encoding**: Standard Ethereum RLP encoding per `mpt/rlp.h`.
  - Nodes: `ShortNode`, `FullNode`, `HashNode`, `ValueNode`.
  - Source: `mpt/node.h`
  - 可信度: 高

- **contractDataContainer**: Thread-safe key-value storage for contract state during block execution, with `set()` and `get()` for JSON data.
  - Source: `mpt/trie.h:45-73`
  - 可信度: 高

## 4. Precompiled Contracts

- **evmone standard precompiles**: Standard EVM precompiled contracts 0x01 through 0x09 are inherited from evmone library.
  - Called via `evmone::state::call_precompile(EVMC_MAX_REVISION, msg)`.
  - Source: `ca/evm/evm_host.cpp:447-450`
  - 可信度: 高

- **silkpre_ecrecover**: Custom ecrecover precompile used for Ethereum-compatible signature recovery.
  - Function: `silkpre_ecrecover_execute(input, 128, output, 32)`.
  - Used in `ca/eth_trans.cpp:173` for RLP-encoded eth transactions.
  - Source: `ca/eth_trans.cpp:173`
  - 可信度: 高

## 5. EIP-1559 Gas Parameters

- **KTargetGasPrice = 60000**: Target gas price (described as "half of max gas fee").
  - Source: `ca/global.h:65` -- `const uint64_t KTargetGasPrice = 60000;`
  - 可信度: 高

- **block_base_fee = 1**: The EVM transaction context sets `block_base_fee` to 1 (minimal initial value).
  - Source: `ca/evm/evmEnvironment.cpp:285`
  - 可信度: 高

- **block_gas_limit = int64_t::max()**: Effectively unlimited block gas limit.
  - Source: `ca/evm/evmEnvironment.cpp:283`
  - 可信度: 高

- **EIP1559FeeCalculator**: Fee adjustment formula:
  ```
  adjustment_factor = (actual_gas - target_gas) / (target_gas * 8.0)
  new_fee = old_fee * (1.0 + adjustment_factor)
  Rounding: CEIL when growing (actual > target), FLOOR when reducing (actual < target)
  ```
  - Source: `ca/fee_calculator.h:12-48`
  - 可信度: 高

## 6. EVM Execution

- **Execution engine**: `evmone` library via `evmc_create_evmone()`.
  - Source: `ca/evm/evm_manager.cpp:13-28`
  - 可信度: 高

- **Execution with timeout**: `std::async(std::launch::async, ...)` with `futureResult.wait_for(std::chrono::seconds(10))` -- 10-second timeout.
  - Source: `ca/contract.cpp:94-97`
  - 可信度: 高

- **executeSynchronouslyWithEvmone**: Synchronous execution via evmone VM.
  - Source: `ca/evm/evm_manager.cpp:29-55`
  - 可信度: 高

- **execute_by_evmone**: Alternative execution path with async/timeout pattern.
  - Source: `ca/contract.cpp:72-128`
  - 可信度: 高

- **Contract packager selection**: `get_contract_distribution_manager()` selects packager for contract transactions.
  - Source: `ca/transaction.h:152`
  - 可信度: 高

- **Contract packager verification**: `ContractVerifier()` validates contract packager selection.
  - Source: `ca/transaction.h:161`
  - 可信度: 高

## 7. Contract Storage

- **fetchContractRootHash**: Retrieves MPT root hash for a contract's storage.
  - Source: `ca/transaction.h:368`

- **SaveContract**: Persists contract code, deploy hash, and references to database.
  - Source: `ca/evm/evm_manager.cpp:86-133`

- **DeleteContract**: Removes contract code, deploy hash, and address references from database.
  - Source: `ca/evm/evm_manager.cpp:135-172`

## 8. EVM Transaction Context

- **txContext fields populated**: `block_coinbase` (packager), `block_gas_limit` (int64 max), `block_base_fee` (1), `tx_gas_price`, `tx_origin`, `block_number`, `block_timestamp`, `chain_id`.
  - Source: `ca/evm/evmEnvironment.cpp:273-287`
  - 可信度: 高
