# MeMeChain UTXO Rules -- Fact Base

## 1. UTXO Data Structures

### CTxPrevOutput (reference to previous output)
```protobuf
message CTxPrevOutput {
  string hash = 1;  // utxo hash
  uint32 n    = 2;  // utxo output index
}
```
- Source: `proto/transaction.proto:17-20`
- 可信度: 高

### CTxInput (transaction input)
```protobuf
message CTxInput {
  repeated CTxPrevOutput prevOut = 1;  // previous outputs being spent
  CSign  vinSign      = 2;            // input signature
  uint32 sequence     = 3;            // sequence number
  string contractAddr = 4;            // contract address
}
```
- Source: `proto/transaction.proto:23-28`
- 可信度: 高

### CTxOutput (transaction output)
```protobuf
message CTxOutput {
  int64 value = 1;  // amount
  string addr = 2;  // recipient address
}
```
- Source: `proto/transaction.proto:31-34`
- 可信度: 高

### CTxUtxos (UTXO set per asset type)
```protobuf
message CTxUtxos {
  repeated string owner    = 1;    // owner addresses
  repeated CTxInput vin    = 2;    // inputs
  repeated CTxOutput vout  = 3;    // outputs
  repeated CSign multisign = 4;    // multi-signatures
  string assettype         = 5;    // asset type identifier
  int64 gas                = 6;    // gas
}
```
- Source: `proto/transaction.proto:36-43`
- 可信度: 高

### Utxo helper struct (TxHelper::Utxo)
```cpp
struct Utxo {
    std::uint64_t value;
    std::string addr;
    std::string hash;
    std::uint32_t n;
};
```
- Source: `ca/txhelper.h:87-93`
- 可信度: 高

### UtxoCore class
- `UtxoCore`: Abstract base class for UTXO-based transaction creation.
  - Transfer params: `TransferToParam`, `TransferFromParam`, `UtxoGasParam`
  - `createUtxoTransferTo()`: Create output UTXOs
  - `createUtxoTransferFrom()`: Select and spend input UTXOs
  - `signUtxo()`: Sign UTXO with private key
  - Source: `ca/transaction/utxo_core.h:23-117`
  - 可信度: 高

- **max_vin_size = 10000**: Maximum UTXO inputs to prevent performance degradation.
  - Source: `ca/transaction/utxo_core.h:15`

## 2. UTXO Selection Algorithm (FindUtxo)

- **FindUtxoParam**: Parameters for UTXO selection:
  ```cpp
  struct FindUtxoParam {
      mmc::CowString addr;         // owner address
      mmc::CowString asset_type;   // asset type
      int64_t need_amount;         // amount needed
      bool need_wid_utxo;          // whether wide UTXO needed
  };
  ```
  - Source: `ca/transaction/utxo_core.h:100-105`
  - 可信度: 高

- **findUtxoByAddrAndCheckBalance()**: Finds UTXOs for an address and verifies balance sufficiency.
  - Takes `FindUtxoParam` and returns total available amount `_total`.
  - Returns vector of `TxHelper::Utxo` selected for spending.
  - Source: `ca/transaction/utxo_core.h:106`
  - 可信度: 高

## 3. Double-Spend Detection

- **doubleSpendCheck()**: 3-phase detection:

  **Phase 1 (SingleBlock)**: Check if same UTXO appears more than once in own UTXO list.
  - Returns `DoubleSpend::SingleBlock = -66`.

  **Phase 2 (DoubleBlock)**: Check against database -- `getUtxoHashsByAddress()` retrieves all UTXO hashes for the address. If the UTXO was already spent (not in the list), it's a double-spend.
  - Returns `DoubleSpend::DoubleBlock = -99`.

  **Phase 3 (Cross-node)**: If `enableMissingBlockRequest` is true, cross-checks with other nodes for UTXO status.

  - Source: `ca/algorithm.h:73`, `ca/algorithm.cpp:2688`
  - Source: `ca/global.h:127-130` for enum values
  - 可信度: 高

- **Special cases**: BONUS transaction type has relaxed double-spend check (allows DB_NOT_FOUND for non-existing UTXOs).
  - Source: `ca/algorithm.cpp:2758-2762`

## 4. Precision Constants

- **kDecimalNum = 100000000** (1e8): Standard precision decimal places. Used for converting between user-facing amounts and internal uint64 values.
  - Source: `ca/global.h:35` -- `const uint64_t kDecimalNum = 100000000;`
  - 可信度: 高

- **Conversion**: `standard_precision_value * kDecimalNum = internal_value`
  - Example: `MIN_STAKE_AMOUNT = 3500 * kDecimalNum = 350000000000`
  - Source: `ca/global.h:39`
  - 可信度: 高

- **MIN_DOUBLE_CONSTANT_PRECISION = 0.000000005**: Minimum double precision for floating point comparisons.
  - Source: `ca/global.h:36`

## 5. UTXO Storage Key Prefixes

All confirmed from `spec/spec_dev.md:1260-1262`:

| Key Pattern | Value | Description |
|-------------|-------|-------------|
| `UB:{addr}:{assetType}:{utxoHash}` | `balance` | UTXO record per address and asset |
| `UAH:{addr}:{assetType}` | `vector<utxoHash>` | List of UTXO hashes for an address |
| `BAL:{addr}:{assetType}` | `balance` | Address balance per asset type |
| `BH:{height}` | `vector<blockHash>` | Block hashes at a given height |
| `TXBH:{txHash}` | `blockHash` | Block containing a transaction |

- 可信度: 高

## 6. Interest Constraint Rules

- **IsQualifiedToUnstake()**: Checks if address can unstake -- requires UTXO has been staked for > 30 days.
  - Source: `ca/transaction.h:188`
  - `isMoreThan30DaysForUnstake()`: Time check for unstaking.
  - Source: `ca/transaction.h:248`

- **IsQualifiedToUnLock()**: Checks if address can unlock -- requires similar qualification check.
  - Source: `ca/transaction.h:189`

- **IsQualifiedToUndelegating()**: Checks undelegating qualification with time constraint (> 1 day).
  - Source: `ca/transaction.h:222`
  - `IsMoreThan1DayForUndelegating()`: Time check.
  - Source: `ca/transaction.h:257`

- **CheckDelegatingQualification()**: Validates delegating prerequisites.
  - Source: `ca/transaction.h:198`

## 7. Balance Query

- **get_balance_by_utxo()**: Returns total balance for an address by aggregating unspent UTXOs for a given asset type.
  - Source: `ca/transaction.h:43` -- `int get_balance_by_utxo(const std::string & address, const std::string & assetType, uint64_t &balance);`
  - 可信度: 高
