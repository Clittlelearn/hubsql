# MeMeChain DAG Rules -- Fact Base

## 1. Multi-Block Same-Height Storage (DAG Structure)

- **BH:{height} -> vector\<blockHash\>**: Database stores multiple block hashes per height, enabling DAG / fork-aware storage.
  - Key format: `BH:{height}` maps to a vector of block hashes.
  - Source: spec document `spec/spec_dev.md:440,1243`
  - 可信度: 高

- **getBlockHashsByBlockHeight()**: API to retrieve all block hashes at a given height.
  - Source: `db/db_api.h:129` -- `DBStatus getBlockHashsByBlockHeight(uint64_t blockHeight, std::vector<std::string> &hashes);`
  - Used in VRF consensus: `ca/vrf_consensus.cpp:85`
  - 可信度: 高

## 2. BlockStatus Tracking

- **BlockStatusWrapper**: Wraps block status with broadcast type, verification counts, and node lists.
  ```cpp
  struct BlockStatusWrapper {
      std::string blockHash;
      CBlock block;
      BroadcastType broadcastType;
      uint32_t nodeVerificationCount;
      uint32_t level1_node_count;
      std::vector<BlockStatus> blockStatusList;
      std::set<std::string> verifyNodes;
      std::set<std::string> level1Nodes;
  };
  ```
  - Source: `ca/block_stroage.h:28-38`
  - 可信度: 高

- **blockStatusMap**: `map<string, BlockStatusWrapper>` tracks all blocks by hash.
  - Source: `ca/block_stroage.h:236`
  - 可信度: 高

- **AddBlockStatus()**: 3 overloads for adding block status entries.
  - Source: `ca/block_stroage.h:120-139`
  - 可信度: 高

- **_failureRate = 0.75**: Threshold for block status consensus.
  - Source: `ca/block_stroage.h:238`

## 3. Main Chain Selection Rules

- **Current implementation: 75 percentile height voting** via `computeMaxHeightWithMinFrequency()`.
  - Nodes submit their top-10 block hashes via VRF. A weighting algorithm selects the most commonly agreed-upon hashes.
  - Threshold: 55% of nodes must agree on the same hash pattern.
  - Source: `ca/vrf_consensus.cpp:339-481`
  - 可信度: 高

- **DEV-规范: 共识权重主链选择** (per spec design, but NOT fully implemented):
  - Per `spec/spec_dev.md`, the intended mechanism is "consensus-weight-based main chain selection."
  - The current code uses frequency-of-hash voting, not a formal consensus-weight calculation.
  - **偏差标注**: 规范描述基于共识权重的主链选择，当前实现使用VRF哈希频率投票。
  - 可信度: 中 (规范意图，但代码未对齐)

## 4. Rollback Mechanism

- **RollBackTime = 15 * 1000000** (= 15 seconds): Blocks older than this threshold are not rolled back.
  - Source: `ca/sync_block.cpp:46` -- `const static uint32_t RollBackTime = 15 * 1000000;`
  - 可信度: 高

- **Two rollback paths**:
  1. **RollBackToHeight**: Rollback to a specified height.
     - Source: `ca/algorithm.h:193` -- `int RollBackToHeight(uint64_t height);`
  2. **rollback_by_hash**: Rollback from a specified block hash.
     - Source: `ca/algorithm.h:201` -- `int rollback_by_hash(const std::string &blockHash);`

- **RollbackBlocks()**: Internal function that processes the rollback block queue.
  - Source: `ca/block_helper.h:390`
  - 可信度: 高

- **Rollback condition**: Block with `block.time() < nowTime - RollBackTime` is eligible for rollback.
  - Used in sync logic: `ca/sync_block.cpp:1286,1478,2108,2251,2296,2775`
  - 可信度: 高

- **MAX_MISSING_BLOCK_SIZE = 10**, **MAX_MISSING_UXTO_SIZE = 10**: Limits on missing block/UxTO tracking.
  - Source: `ca/block_helper.h:414-415`
  - 可信度: 高

## 5. Fork Detection

- **CheckBlocks** class: Periodically verifies sum hashes per 1000 heights.
  - Source: `ca/check_blocks.h:25-108`
  - 可信度: 高

- **Sum hash verification**: `calculateSumHashOf1000Heights()` computes SHA256 of sorted block hashes for each height range, then hashes those results.
  - `sumHeightsHash()`: Concat of sorted hashes per height, then SHA256.
  - Source: `ca/sync_block.cpp:67-86`
  - 可信度: 高

- **Byzantine detection via sum hash**: When sum hash mismatch is detected, `calculateByzantineSumHash()` queries multiple nodes to find the deviation.
  - Source: `ca/check_blocks.h:62`
  - 可信度: 高

- **SYNC_HEIGHT_TIME = 10** (seconds): Polling interval for sync status check.
  - Source: `ca/sync_block.cpp:37`
  - 可信度: 高

- **SYNC_STUCK_OVERTIME_COUNT = 6**: If height stays equal for 6 consecutive checks, triggers re-sync.
  - Source: `ca/sync_block.cpp:38`
  - 可信度: 高

## 6. Synchronization Modes

Three modes defined in `ca/global.h:110-116` as `enum class SaveType`:

| Mode | Description |
|------|-------------|
| `SyncNormal` | Normal incremental sync |
| `SyncFromZero` | Full chain sync from genesis |
| `Broadcast` | Block broadcast sync |
| `Unknow` | Unknown |

- 可信度: 高

- **Fast Sync**: `runFastSyncOnce()`, `SetFastSync()`, downloads block hashes first, then block data.
  - Source: `ca/sync_block.h:135,79`
  - 可信度: 高

- **New Sync**: `runNewSyncOnce()`, uses sum hash verification to identify divergent blocks.
  - Source: `ca/sync_block.h:148`
  - 可信度: 高

- **From Zero Sync**: `runFromZeroSyncOnce()`, downloads the entire chain from genesis.
  - Source: `ca/sync_block.h:158`
  - 可信度: 高

- **kSynchronizationBoundary = 200**: Sync boundary value for from-zero sync grouping.
  - Source: `ca/sync_block.h:348`
  - 可信度: 高

- **syncHeightCount = 100**: Number of heights to sync per batch.
  - Source: `ca/sync_block.cpp:36`
  - 可信度: 高

## 7. Block Validity Boundary

- **Height + 50 boundary**: Blocks with `blockHeight + 50 < nodeHeight` are rejected.
  - Source: `ca/block_helper.cpp:920` -- `if(computeMeanValue == global::ca::blockMean::Normal && blockHeight + 50 < nodeHeight)`
  - 可信度: 高

## 8. Block Processing Modes

Defined in `ca/global.h:118-123` as `enum class blockMean`:

| Mode | Description |
|------|-------------|
| `Normal` | Standard processing |
| `processByPreHash` | Process using previous block hash |
| `ByUtxo` | Process using UTXO-based lookup |

- 可信度: 高

## 9. Sync Node Selection

- **getSyncNodeSimplified()**: Selects sync nodes by network stake qualification.
  - Source: `ca/sync_block.h:72-73`
  - 可信度: 高

- **checkRequirementAndFilterQualifyingNodes()**: Filters nodes by stake requirements.
  - Source: `ca/sync_block.h:312-313`
  - 可信度: 高

- **KScalingFactor = 0.95**: Used in sync node selection scaling.
  - Source: `ca/sync_block.cpp:39`
  - 可信度: 中 (static variable, usage unclear from available context)

- **kStabilityTime = 60 * 1000000** (60 seconds): Stability period for chain height.
  - Source: `ca/sync_block.cpp:28`
  - 可信度: 高
