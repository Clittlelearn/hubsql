# MeMeChain Immutable Consensus Invariants -- Fact Base

## 1. Block Hash Rule

- **Rule**: `block_hash = SHA256(SerializeAsString(block_without_signatures))`
- **Source**: `ca/transaction.cpp:3499,3519` (`AddBlockSign`/`VerifyBlockSign`)
- **变更后果**: Changing the hash function would break all signature verifications, requiring all nodes to re-sign all historical blocks. All stored block hashes in database would be invalid.
- **可否硬分叉修改**: Yes, with a hard fork at a specific block height introducing the new hashing rule.

## 2. Transaction Hash Rule

- **Rule**: `tx_hash = SHA256(SerializeAsString(CTransaction without hash field))`
- **Source**: `ca/algorithm.h:48` (`calculateTransactionHash`)
- **变更后果**: All historical transaction references (TXBH database keys, block Merkle trees, UTXO references) would be invalidated. All stored transaction indexes would need rebuilding.
- **可否硬分叉修改**: Yes, with a hard fork. New transactions could use new hash; old transactions would need migration.

## 3. Signature Rules (ECDSA secp256k1)

- **Rule**: All signatures are ECDSA secp256k1, using `TxHelper::Sign()` / `Account::Verify()`.
- **Source**: `ca/transaction.cpp:3503` (`TxHelper::Sign`), `ca/transaction.cpp:3537` (`Account::Verify`)
- **变更后果**: Changing the signature algorithm (e.g., to EdDSA, BLS) would invalidate all existing public keys and signatures. All addresses derived from public keys would be incompatible. All staked nodes with existing keys would lose identity.
- **可否硬分叉修改**: Extremely difficult. Would need a migration mechanism where users can register new keys. Essentially requires a new genesis for accounts.

## 4. UTXO Selection Rules

- **Rule**: UTXO selection follows `findUtxoByAddrAndCheckBalance()` algorithm -- selects UTXOs belonging to the address and asset type to cover the required amount. Selection order affects which UTXOs are consumed.
- **Source**: `ca/transaction/utxo_core.h:106`
- **变更后果**: Changing the UTXO selection algorithm could cause transactions that were previously valid to fail (different UTXO set consumed), or could invalidate double-spend checks. Backward compatibility is essential.
- **可否硬分叉修改**: The selection algorithm itself can be modified within a soft fork, provided balance checks and double-spend detection remain compatible. The core UTXO model (input references prev_output_hash+index) must remain unchanged.

## 5. Address Generation Rule (EIP-55)

- **Rule**: Addresses are generated from public keys: `GenerateAddr(pub)` produces a hex address string. EIP-55 checksum formatting via `ToChecksumAddress()`.
- **Source**: `utils/contract_utils.cpp:91-95` (`GetEvmAddr`), `ca/evm/evm_manager.cpp:64`
- **变更后果**: Changing address derivation would orphan all existing accounts and their balances. All UTXO ownership would be unresolvable. This is a consensus-breaking change affecting every account.
- **可否硬分叉修改**: No practical migration path. Would effectively require a new chain.

## 6. Contract Address Generation (EIP-161)

- **Rule**: `contract_address = keccak256(rlp([sender_20bytes, nonce]))[12:32]` -- fully Ethereum-compatible per EIP-161.
- **Source**: `utils/contract_utils.cpp:73-89` (`GenerateContractAddrEth`)
- **变更后果**: Changing this rule would mean the same sender+nonce produces a different contract address. All existing deployed contracts would be unreachable at their known addresses. Cross-chain compatibility with Ethereum tooling would be broken.
- **可否硬分叉修改**: Yes, but with extreme care. A hard fork could introduce a new scheme for new contracts only, keeping old scheme for previously deployed contracts. However, this creates two address spaces and complexity.

## 7. Reward Calculation Formulas

- **Rule**: 
  ```
  reward = annualizedRate * delegateAmount / 365  (normal node)
  reward = dividendRate * annualizedRate * delegateAmount / 365  (below-average node)
  ```
- **Source**: `ca/algorithm.cpp:7886,7895` (`CalcBonusValue`)
- **变更后果**: Changing reward formulas affects the economic model and token supply schedule. Any change creates winners and losers among stakeholders. The transition must be handled carefully.
- **可否硬分叉修改**: Yes, reward formulas can be modified through a governance proposal and hard fork activation. Historical rewards once distributed cannot be reversed. Note: the current code has a known bug (~100x overpayment) due to commented-out division by 100.

## 8. Transaction Serialization Format (Protobuf Field Numbers)

- **Rule**: Transaction fields are serialized using Protocol Buffers with fixed field numbers defined in `proto/transaction.proto`. Key numbers: version=1, time=2, type=7, data=8, utxos=13, nonce=15, rlp=16, selection_vrf=17.
- **Source**: `proto/transaction.proto:47-68`
- **变更后果**: Changing field numbers would break deserialization of all historical transactions. Adding new optional fields is safe; removing or renumbering existing fields is not. Field number reuse causes silent data corruption.
- **可否硬分叉修改**: Adding new optional fields at unused numbers is backward-compatible (soft fork). Renumbering or removing existing fields requires a hard fork with data migration.

## 9. DAG Confirmation Rules

- **Rule**: Block confirmation is based on the VRF consensus frequency voting mechanism (`computeMaxHeightWithMinFrequency`), which selects a main chain based on the most commonly reported block hashes across VRF participants.
- **Source**: `ca/vrf_consensus.cpp:339-481`
- **变更后果**: Changing the confirmation rule would cause temporary chain splits. Nodes running old rules would disagree with nodes running new rules on which blocks are "confirmed." A hard fork block height is needed for clean transition.
- **可否硬分叉修改**: Yes, at a specified hard fork height. The existing consensus rule can be replaced with a different mechanism (e.g., formal consensus-weight as specified in the design doc but not implemented).

## 10. MPT Root Hash Rule

- **Rule**: `mpt_root = SHA256(hex(RLP(node)))` -- MeMeChain uses SHA256 for MPT node hashing, NOT Keccak256.
- **Source**: `mpt/trie.cpp:422-435` (`Trie::ToHash`)
- **变更后果**: This is a major deviation from Ethereum's standard (`Keccak256(RLP(node))`). MeMeChain's MPT root hashes are incompatible with Ethereum's. Any cross-chain verification system (light clients, bridges, Layer-2 rollups) expecting Ethereum-compatible state roots will produce incorrect results.
- **可否硬分叉修改**: Yes, through a hard fork. The MPT root would change for all contracts at the fork boundary. All contract state would need to be re-hashed with Keccak256. The old state root can be stored for historical reference. This is the highest-priority technical debt item.

---

## Summary Table

| # | Invariant | Mutability | Fork Type |
|---|-----------|------------|-----------|
| 1 | Block hash = SHA256(serialized) | Mutable | Hard fork |
| 2 | Tx hash = SHA256(serialized) | Mutable | Hard fork |
| 3 | ECDSA secp256k1 signatures | Near-immutable | Implausible |
| 4 | UTXO selection model | Core immutable, algo mutable | Soft fork (algo only) |
| 5 | Address derivation | Immutable | Impossible |
| 6 | EIP-161 contract address | Core immutable | Hard fork (additive only) |
| 7 | Reward formulas | Mutable | Hard fork + governance |
| 8 | Protobuf field numbers | Additive only | Soft (add) / Hard (change) |
| 9 | DAG confirmation | Mutable | Hard fork |
| 10 | MPT hash = SHA256 (NOT Keccak) | Mutable | Hard fork |

All sources are verified from the project source code. Trust level: High for all items.
