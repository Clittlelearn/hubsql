# MeMeChain Transaction Lifecycle -- Fact Base

## 1. Transaction Types (16 types)

All defined in `ca/global.h:87-107` as `enum class TxType:int32_t`:

| Enum Value | Numeric | Description |
|------------|---------|-------------|
| `UNKNOWN` | -1 | Unknown / invalid |
| `GENESIS` | 0 | Genesis block transaction |
| `TX` | 1 | Normal transfer transaction |
| `STAKE` | 2 | Pledge/stake |
| `UNSTAKE` | 3 | Unpledge/unstake |
| `DELEGATE` | 4 | Delegate |
| `UNDELEGATE` | 5 | Undelegate |
| `DECLARATION` | 6 | Declaration |
| `DEPLOY` | 7 | Deploy contract |
| `CALL` | 8 | Call contract |
| `LOCK` | 9 | Lock (enables vote right) |
| `UNLOCK` | 10 | Unlock |
| `PROPOSAL` | 11 | Governance proposal |
| `REVOKEPROPOSAL` | 12 | Revoke proposal |
| `VOTE` | 13 | Vote |
| `FUND` | 98 | Claim treasury reward |
| `BONUS` | 99 | Bonus reward |

- 可信度: 高, 来源: `ca/global.h:87-107`

Additional `TransactionType` enum in `ca/transaction.h:45-49`:
- `kTransactionTypeGenesis = 0`
- `kTransactionTypeTx = 1` (normal trading)
- `TRANSACTION_TYPE_UNKNOWN = -1`

## 2. Transaction Structure (CTransaction protobuf)

Defined in `proto/transaction.proto:47-68`:

| Field | Type | proto# | Description |
|-------|------|--------|-------------|
| version | uint32 | 1 | Transaction version |
| time | uint64 | 2 | Transaction time |
| n | uint32 | 3 | Sequence number |
| identity | string | 4 | Identity |
| hash | string | 5 | Transaction hash |
| consensus | uint32 | 6 | Consensus number |
| type | uint32 | 7 | Transaction type |
| data | string | 8 | Transaction data (JSON) |
| note | string | 9 | Transaction note |
| signature | repeated CSign | 10 | Signatures |
| reserve0 | string | 11 | Reserved |
| reserve1 | string | 12 | Reserved |
| utxos | repeated CTxUtxos | 13 | UTXO inputs/outputs |
| independence | uint32 | 14 | Independence flag |
| nonce | uint64 | 15 | Nonce |
| rlp | string | 16 | RLP-encoded data (for eth tx) |
| selection_vrf | string | 17 | VRF selection proof |

- 可信度: 高

Sub-messages:
- `CTxUtxos` (field 13): Contains `owner[]`, `vin[]`, `vout[]`, `multisign[]`, `assettype`, `gas`
- `CTxInput`: Contains `prevOut[]`, `vinSign`, `sequence`, `contractAddr`
- `CTxOutput`: Contains `value`(int64), `addr`(string)
- `CTxPrevOutput`: Contains `hash`(1), `n`(2)

## 3. Transaction Hash Calculation

- **Formula**: `SHA256(Serialize(CTransaction without hash field))`
  - `calculateTransactionHash()` takes a `CTransaction`, serializes it, and computes SHA256.
  - Source: `ca/algorithm.h:48` -- `std::string calculateTransactionHash(CTransaction tx);`
  - 可信度: 高

## 4. Transaction Lifecycle

### Step 1: Creation
- Various handler functions create transactions by populating CTransaction fields:
  - `HandleStake()`, `HandleUnstake()`, `handleDelegating()`, `HandleBonus()`, `DeployContract()`, `CallContract()`, etc.
  - Source: `ca/ca.h:47-98`
  - Each has a dedicated implementation file in `ca/transaction/`.

### Step 2: Signing
- **SigTx**: Signs the transaction with the specified address's private key (ECDSA secp256k1).
  - Source: `ca/ca.h:162` -- `int SigTx(CTransaction &tx, const std::string & addr);`
  - 可信度: 高

### Step 3: Broadcasting
- `HandleTx()` receives transaction flow messages, validates them, and adds valid transactions to the cache.
  - Source: `ca/transaction.h:66` -- `int HandleTx(const std::shared_ptr<TxMsgReq>& msg, const MsgData& msgData);`
  - `DropShippingTransaction()` forwards transactions to other nodes.
  - Source: `ca/transaction.h:313-323`
  - `find_sign_node()` determines next hop nodes for transaction propagation.
  - Source: `ca/transaction.h:130`

### Step 4: Validation
- **memoryVerificationTransactionRequest**: Pre-consensus validation.
  - Source: `ca/algorithm.h:81`
- **verifyTransactionRequest**: Full consensus verification including:
  - Timeout check
  - Double-spend check
  - Signature verification
  - UTXO height verification
  - Abnormal node check
  - Source: `ca/algorithm.h:92`

### Step 5: Caching (Mempool)
- Validated transactions are added to `TransactionCache` via `AddCache()`.
  - Source: `ca/transaction_cache.h:101`
  - Stored in `_transactionCache` and `_contractCache` vectors.
  - `BUILD_INTERVAL`, `BUILD_THRESHOLD`, `_kTxExpireInterval` control block building.
  - Source: `ca/transaction_cache.h:60-64`

### Step 6: Block Building/Packaging
- `TransactionCache::processTransactionCacheFunc()` triggers block building.
- VRF-selected packager assembles block from cached transactions.
- `AddBlockSign()` signs the block before broadcasting.
  - Source: `ca/transaction.cpp:3495-3513`

### Step 7: Confirmation
- `HandleBlock()` processes incoming blocks.
- `VerifyBlockSign()` verifies validator signatures.
- `SaveBlock()` persists the block to the database.
- Post-save processing includes updating UTXO sets, contract states.
  - Source: `ca/algorithm.h:175`

## 5. Transaction Validation Rules

- **Timeout**: `KtxTimeout = 10 * 1000000ull` microseconds (= 10 seconds).
  - Source: `ca/global.h:60`
  - `verifyTransactionTimeoutRequest()` checks if `tx.time() + KtxTimeout < current_time`.
  - Source: `ca/transaction.h:231`

- **Double-spend check**: `doubleSpendCheck()` -- 3 phases:
  1. Check for same UTXO in own UTXO list.
  2. Check against database (`getUtxoHashsByAddress`).
  3. Cross-check with other nodes via `enableMissingBlockRequest`.
  - Source: `ca/algorithm.h:73`, implementation at `ca/algorithm.cpp:2688`
  - 可信度: 高

- **Signature verification**: Each UTXO owner's signature is verified against the transaction hash.
  - Source: `ca/algorithm.cpp` in `memoryVerificationTransactionRequest`/`verifyTransactionRequest`

- **UTXO height verification**: `verifyTxUtxoHeight()` checks UTXO preconditions.
  - Source: `ca/transaction.h:239`

- **TX_TIMEOUT_MIN = 30** (minutes): Additional timeout for transaction pool.
  - Source: `ca/global.h:22`

## 6. Fee Calculation

- **CalculateGas**: Computes gas cost for a transaction based on UTXO input/output sizes.
  - Source: `ca/transaction.h:340,350`
- **KTargetGasPrice = 60000**: Target gas price for EIP-1559.
  - Source: `ca/global.h:65`

## 7. Transaction Version

- **CURRENT_TRANSACTION_VERSION = 0**
  - Source: `ca/global.h:164`
