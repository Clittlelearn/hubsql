# 08 -- RPC / RPC 服务层

> **阶段 5 重组索引** | 关联目录: `../../module-rpc/`
> **上游**: [07_storage](../07_storage/) | **下游**: [09_evm](../09_evm/)

---

## 1. 概览

MeMeChain RPC 层为外部客户端提供区块链数据查询和交易提交接口，采用三层架构设计，分别服务于不同场景:

- **POST 层 (JSON-RPC 2.0 风格)**: 业务操作 (查询/创建交易), ~93 个 cpp 文件
- **GET 层 (调试接口)**: 浏览器监控与调试, ~38 个 cpp 文件
- **ETH 兼容层**: MetaMask/Hardhat/Web3.js 工具链, 1 个主 cpp 文件 (~43KB)

HTTP 服务器基于 cpp-httplib 库, 支持 HTTP + HTTPS (mTLS), 托管在 `net/http_server.cpp`。

---

## 2. 三层架构

```
                          ┌──────────────────────────┐
                          │        HTTP Server        │
                          │   (0.0.0.0:port)         │
                          │   HTTP + HTTPS (mTLS)    │
                          └──────────┬───────────────┘
                                     │
                ┌────────────────────┼────────────────────┐
                │                    │                    │
         ┌──────▼──────┐    ┌───────▼───────┐    ┌───────▼──────┐
         │ POST 路由     │    │ GET 路由       │    │ ETH 路由      │
         │ JSON-RPC 2.0  │    │ HTTP GET       │    │ 标准 JSON-RPC │
         │ (自定义header) │    │ URL 参数        │    │ 统一 / 根路由  │
         └──────┬──────┘    └───────┬───────┘    └───────┬──────┘
                │                    │                    │
         ┌──────▼──────┐    ┌───────▼───────┐    ┌───────▼──────┐
         │ ParamHandle  │    │ DBReader 直调  │    │ ETH_PARAM宏   │
         │ ResultHandle │    │ HTML/Plain/JSON│    │ eth_ret 格式化 │
         └──────┬──────┘    └───────┬───────┘    └───────┬──────┘
                │                    │                    │
                └────────────────────┼────────────────────┘
                                     │
                            ┌────────▼────────┐
                            │  CA 层 / DB 层   │
                            │  TxHelper        │
                            │  DBReader        │
                            └─────────────────┘
```

---

## 3. 三层对比

| 维度 | POST (JSON-RPC 2.0) | GET (调试) | ETH 兼容 |
|------|---------------------|------------|----------|
| **协议** | 自定义 JSON-RPC 2.0 (header 内嵌) | HTTP GET 参数 | 标准 JSON-RPC 2.0 |
| **路由** | 每个 path 单独注册 | 每个 path 单独注册 | 根路径 `/` 统一分发 |
| **请求格式** | `{"header":{id,jsonrpc,method},"params":{...}}` | `?key=val` | `{"jsonrpc":"2.0","method":"...","params":[...],"id":...}` |
| **响应格式** | `{"id":"...","jsonrpc":"2.0","result":{...},"status":{code,errorCallstack}}` | text/html, text/plain, application/json | `{"jsonrpc":"2.0","result":{...},"id":...}` |
| **主要用途** | 业务操作 (查询/创建交易) | 浏览器调试/监控 | MetaMask/Hardhat/Web3.js |
| **参数校验** | ParamHandle::parse() | 无统一框架 | ETH_PARAM 宏 |
| **文件规模** | ~93 个 cpp | ~38 个 cpp | 1 个 cpp + 辅助 |

---

## 4. 完整接口分类表

### 4.1 POST -- 基础查询 (12个)

| 方法 | 路由 | 功能 |
|------|------|------|
| GetVersion | /GetVersion | 获取节点版本 |
| GetBalance | /GetBalance | 获取地址余额 |
| GetBlockHeight | /GetBlockHeight | 获取当前区块高度 |
| GetChainId | /GetChainId | 获取链 ID (12315) |
| GetAccounts | /GetAccounts | 获取本地账户列表 |
| GetNodeList | /GetNodeList | 获取已知节点列表 |
| GetAllStakeNodeList | /GetAllStakeNodeList | 获取所有质押节点 |
| GetAddrType | /GetAddrType | 获取地址类型 |
| GetYieldInfo | /GetYieldInfo | 获取收益信息 |
| GetBonusInfo | /GetBonusInfo | 获取奖励信息 |
| GetAssetTypeByContractAddr | /GetAssetTypeByContractAddr | 按合约查资产类型 |
| IsContract | /IsContract | 检查是否为合约地址 |

### 4.2 POST -- 区块/交易查询 (13个)

| 方法 | 路由 | 功能 |
|------|------|------|
| GetTransactionByHash | /GetTransactionByHash | 按哈希查交易 |
| GetBlockByHash | /GetBlockByHash | 按哈希查区块 |
| GetBlockByHeight | /GetBlockByHeight | 按高度查区块 |
| GetBlockByTransactionHash | /GetBlockByTransactionHash | 按交易哈希查所属区块 |
| GetBlockTransactionCountByHash | /GetBlockTransactionCountByHash | 获取区块交易数 |
| GetDelegatingUtxo | /GetDelegatingUtxo | 获取委托 UTXO |
| GetStakingUtxo | /GetStakingUtxo | 获取质押 UTXO |
| GetLockUtxo | /GetLockUtxo | 获取锁定 UTXO |
| GetDelegatingAddrsByBonusAddr | /GetDelegatingAddrsByBonusAddr | 获取委托地址列表 |
| GetUtxoDeployerByConAddr | /GetUtxoDeployerByConAddr | 获取部署者 UTXO |
| GetTxByHash | /GetTxByHash | 获取交易详情 (变体) |
| GetBlockNumberByHash | /GetBlockNumberByHash | 获取区块编号 |
| GetTransactions | (共用 GetTransactionByHash method) | 获取交易列表 |

### 4.3 POST -- 投票/资产查询 (5个)

| 方法 | 路由 | 功能 |
|------|------|------|
| GetVoteAddrs | /GetVoteAddrs | 获取投票地址 |
| GetVoteTxHash | /GetVoteTxHash | 获取投票交易哈希 |
| GetAllAssetType | /GetAllAssetType | 获取所有资产类型 |
| GetAssetTypeInfo | /GetAssetTypeInfo | 获取资产类型详情 |
| GetAllRollBackBlocks | /GetRollbackBlocks | 获取回滚区块列表 |

### 4.4 POST -- 交易创建 (14个)

| 方法 | 路由 | 交易类型 |
|------|------|---------|
| CreateTransaction | /CreateTransaction | 普通转账 |
| CreateStakingTransaction | /CreateStakingTransaction | 质押 |
| CreateUnstakingTransaction | /CreateUnstakingTransaction | 解押 |
| CreateDelegatingTransaction | /CreateDelegatingTransaction | 委托 |
| CreateUndelegatingTransaction | /CreateUndelegatingTransaction | 取消委托 |
| CreateBonusTransaction | /CreateBonusTransaction | 领取奖励 |
| CreateCallContractTransaction | /CreateCallContractTransaction | 调用合约 |
| CreateDeployContractTransaction | /CreateDeployContractTransaction | 部署合约 |
| CreateLockTransaction | /CreateLockTransaction | 锁定(投票) |
| CreateUnLockTransaction | /CreateUnLockTransaction | 解锁 |
| CreateVoteTransaction | /CreateVoteTransaction | 投票 |
| CreateFundTransaction | /CreateFundTransaction | 领取国库 |
| SendMessage | /SendMessage | 发送网络消息 |
| SendContractMessage | /SendContractMessage | 发送合约消息 |

### 4.5 GET -- 调试接口 (18个)

| 端点 | 路由 | 功能 | 响应类型 |
|------|------|------|----------|
| /block | /block | 区块列表 (HTML 可视化) | text/html |
| /get_block | /get_block | 区块数据 (JSON) | application/json |
| /pub | /pub | 线程和请求统计 | text/plain |
| /account | /account | 账户列表 | text/plain |
| /Node | /Node | 节点列表 | text/plain |
| /ShowVRFInfo | /ShowVRFInfo | VRF 验证信息 | text/plain |
| /printCalcHash | /printCalcHash | 千块汇总 hash | text/plain |
| /printhundredhash | /printhundredhash | 百块汇总 hash | text/plain |
| /printblock | /printblock | 打印区块 hash 到文件 | text/plain |
| /SystemInfo | /SystemInfo | 系统信息 | text/plain |
| /printVoteInfo | /printVoteInfo | 投票信息 | text/plain |
| /printLockAddrs | /printLockAddrs | 锁定地址列表 | text/plain |
| /printProposalInfoByHash | /printProposalInfoByHash | 提案详情 | text/plain |
| /printAvailableAssetType | /printAvailableAssetType | 可用资产类型 | text/plain |
| /printAsseTypeByContractAddr | /printAsseTypeByContractAddr | 按合约查资产类型 | text/plain |
| /GetPublicIp | /GetPublicIp | 公网 IP | text/plain |
| /GetRollbackBlocks | /GetRollbackBlocks | 回滚区块信息 | application/json |
| /api | /api | API 模板 | application/json |

### 4.6 ETH 兼容接口 (16个)

| 方法 | 实现状态 | 备注 |
|------|---------|------|
| eth_chainId | 已实现 | 返回 0x3027 (12315) |
| eth_blockNumber | 已实现 | 十六进制当前高度 |
| eth_gasPrice | 已实现 | 近100区块平均 gas |
| eth_getBalance | 已实现 | 精度转换 10^8 -> 10^18 |
| eth_getTransactionCount | 已实现 | 返回 nonce |
| eth_sendRawTransaction | 已实现 | 支持部署/调用/转账 |
| eth_getTransactionReceipt | 已实现 | 完整收据字段 |
| eth_call | 已实现 | 只读合约调用 |
| eth_getBlockByNumber | 已实现 | 支持 fullTx 参数 |
| eth_getBlockByHash | 已实现 | 完整区块字段 |
| eth_getCode | 已实现 | 返回合约字节码 |
| eth_getTransactionByHash | 已实现 | 完整交易字段 |
| eth_estimateGas | 部分实现 | 固定返回 gas=1 |
| eth_accounts | 已实现 | 返回本地账户列表 |
| net_version | 已实现 | 返回网络 ID |
| web3_clientVersion | 已实现 | 返回客户端版本 |

**缺失的 ETH 方法**: `eth_getLogs`, `eth_newFilter`, `eth_getStorageAt`, `eth_subscribe`, `eth_sign`, `eth_feeHistory` (结构体已定义但未完成), `eth_getBlockReceipts`。

---

## 5. 精度转换

MeMeChain 内部使用 **10^8** 精度，ETH 生态使用 **10^18** 精度。RPC 层提供双向转换:

| 方向 | 函数 | 位置 | 算法 |
|------|------|------|------|
| 内部 -> ETH | `scale_up_10_8_to_18(int64_t)` | `rpc/eth/eth_impl.cpp:444-458` | `amount * 10^10`, 使用 `unsigned __int128` 防溢出 |
| ETH -> 内部 | `scale_down_10_18_to_8(bytes)` | `rpc/eth/eth_impl.cpp:461-472` | 位移解析 raw bytes 再除以 10^10 |

> **已知问题**: `eth_gasPrice` 未做精度转换，返回 10^8 精度字符串，与 ETH 工具链期望 (10^18) 不符。

---

## 6. 安全与风险

| 项目 | 状态 | 风险等级 |
|------|------|---------|
| RPC 鉴权 | **未实现** (规范标记 TODO) | 高 |
| 请求速率限制 | **无** | 高 |
| CORS 策略 | 全局开放所有来源 | 中 |
| SSL/TLS | 支持 HTTPS + mTLS | 正面 |
| 参数校验 | 覆盖不均衡 (部分接口跳过校验) | 中 |
| 批量请求 | eth_dispatch 支持数组批量请求 | 正面 |

---

## 7. 相关文档

### 阶段 2 -- 模块分析
| 文档 | 路径 |
|------|------|
| RPC 模块总览 | `../../module-rpc/module_overview.md` |
| RPC 类分析 | `../../module-rpc/class_analysis.md` |
| RPC 调用链 | `../../module-rpc/call_chain.md` |
| RPC 状态流 | `../../module-rpc/state_flow.md` |
| RPC 存储模型 | `../../module-rpc/storage_model.md` |
| RPC 线程模型 | `../../module-rpc/thread_model.md` |
| RPC 重构建议 | `../../module-rpc/refactor_suggestion.md` |

### 阶段 3 -- 流程分析
| 文档 | 路径 |
|------|------|
| 交易生命周期 (含 RPC 入口) | `../../03_core_flows/flow-01-tx-lifecycle/sequence_flow.md` |
| EVM 合约流程 (含 RPC 调用) | `../../03_core_flows/flow-04-evm-contract/sequence_flow.md` |

### 阶段 1 -- 全局架构
| 文档 | 路径 |
|------|------|
| 架构总览 (rpc/ api/ 目录) | `../../architecture_overview.md` |
| 模块依赖 (rpc 依赖矩阵) | `../../module_dependency.md` |

### 阶段 4 -- 重构规划
| 文档 | 路径 |
|------|------|
| 重构总体规划 (RPC 安全/鉴权) | `../../refactor_master_plan.md` |
