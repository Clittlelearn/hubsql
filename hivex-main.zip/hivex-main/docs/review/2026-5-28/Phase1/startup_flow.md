# 启动流程与主线程模型分析

> **分析阶段**: 阶段 1 — 全局架构扫描 (Phase 0)
> **分析日期**: 2026-05-26
> **分析范围**: `entry.cpp` → `main/main.cpp` → `CaInit()` + `NetInit()`
> **可信度**: 中等可信度 — 基于入口代码分析，部分线程创建和定时器行为需要通过运行时跟踪确认

---

## 一、启动流程总览

```
程序启动
  │
  ├─ entry.cpp:main()                      [进程入口]
  │   ├─ init_signal_handlers()            [注册信号处理]
  │   ├─ parse_cmdline_args(argc, argv)    [解析命令行参数]
  │   └─ quick_exit(0)                     [立即退出 — 参见注 1]
  │
  └─ main/main.cpp:init_check()            [实际主流程 — 参见注 1]
      │
      ├─ 阶段 1: Init()                    [系统初始化]
      │   ├─ 1.1 InitConfig()              [加载 config.json]
      │   ├─ 1.2 InitGenesis()             [加载 genesis.json]
      │   ├─ 1.3 InitLog()                 [初始化 spdlog 日志]
      │   ├─ 1.4 InitAccount()             [账户初始化/创建]
      │   ├─ 1.5 InitRocksDb()             [数据库初始化 + 创世区块写入]
      │   ├─ 1.6 CaInit()                  [共识层初始化]
      │   └─ 1.7 NetInit()                 [网络层初始化]
      │
      ├─ 阶段 2: Check()                   [创世区块一致性验证]
      │   └─ 对比数据库中的创世区块与重新生成的创世区块
      │
      └─ 阶段 3: CleanUp() (仅在 initFail 时)
          └─ CaCleanup()                   [清理所有线程/定时器/连接]
```

> **注 1**: `CMakeLists.txt` 第 87-88 行明确将 `entry.cpp` 从 `SOURCES` 中排除（`list(REMOVE_ITEM SOURCES ${MAIN_FILE})`），同时 `entry.cpp` 和 `main/main.cpp` 各自定义了 `main()` 函数。根据构建配置，**实际编译使用的是 `entry.cpp` 中的 `main()`**【需人工验证】。`main/main.cpp` 可能通过 `test_main.cpp` 或其他方式编译为独立测试入口。

---

## 二、各阶段详细流程

### 2.1 阶段 1.1: InitConfig()

```
InitConfig():
  1. MagicSingleton<Config>::GetInstance(flag)
  2. Config 构造函数:
     a. InitFile()                         [读取并解析 config.json]
        - 解析 IP, server_port, http_port, https_port
        - 解析 info (logo, name)
        - 解析 log (level, path, console)
        - 解析 http_callback (ip, port, path)
        - 解析 rpc (enable/disable)
        - 解析 SSL 证书路径 (enable_https, mTLS)
        - 读取 tracker IPs (种子节点列表)
     b. _Verify()                          [验证配置合法性]
     c. _Filter()                          [过滤服务器地址]
     d. 启动后台线程 _Check()              [配置文件变更监控线程]
  3. 返回 flag (true=成功)
```

**涉及文件**: `common/config.cpp`, `common/config.h`
**线程**: 启动 `_Check()` 后台线程，监控 config.json 文件变更

---

### 2.2 阶段 1.2: InitGenesis()

```
InitGenesis():
  1. MagicSingleton<Genesis>::GetInstance()
  2. Genesis 构造函数:
     a. 读取并解析 genesis.json
     b. 提取:
        - genesisTime (创世时间戳, 微秒)
        - initAccountAddr (初始账户地址)
        - initialBalance (MM, Vote 初始分配)
        - network.type (dev/test/primary)
        - network.name (网络名称)
     c. 确定链 ID (chainId)
  3. 始终返回 true
```

**涉及文件**: `common/genesis.cpp`, `common/genesis.h`

---

### 2.3 阶段 1.3: InitLog()

```
InitLog():
  1. 从 Config 读取日志配置
  2. MagicSingleton<Log>::GetInstance()->LogInit(path, console, level)
  3. 基于 spdlog 初始化异步日志
```

**涉及文件**: `include/logging.cpp`, `include/logging.h`

---

### 2.4 阶段 1.4: InitAccount()

```
InitAccount():
  1. MagicSingleton<AccountManager>::GetInstance()
  2. accountManager->Initialize()
     结果可能是:
     a. SUCCESS: 已有账户，直接使用
     b. EMPTY_KEYSTORE: 无现有账户
        → accountManager->CreateInitialAccount() [创建新账户]
     c. kAccountsNotInitialized: 交互式询问用户是否创建
  3. 返回 true/false
```

**涉及文件**: `utils/account_manager.cpp`, `utils/account_manager.h`, `utils/keystore.cpp`

---

### 2.5 阶段 1.5: InitRocksDb()

```
InitRocksDb():
  1. DBInit("./data.db")                   [打开/创建 RocksDB]
  2. dbReadWriter.getBlockTop(top)         [检查是否已有区块]
  3. 如果 top 不存在 (首次启动):
     a. GenesisBlock::GenerateGenesisBlock(block)  [动态生成创世区块]
     b. 验证创世交易 (txs_size > 0, utxos_size > 0)
     c. 写入区块数据:
        - setBlockHeightByBlockHash
        - setBlockHashByBlockHeight
        - setBlockByBlockHash
        - setBlockTop(0)
     d. 遍历 UTXO 输出, 写入 UTXO 和余额
        - 对每个 vout: 写入 UTXO hash, 写入余额
     e. 写入创世交易
  4. setInitVer(mm::GetVersion())           [记录初始版本]
  5. transactionCommit()                    [原子提交]
```

**涉及文件**: `db/rocksdb.cpp`, `db/rocksdb_read_write.cpp`, `db/db_api.cpp`, `utils/genesis_block.cpp`

---

### 2.6 阶段 1.6: CaInit() [共识层初始化 — 核心]

```
CaInit():
  1. RegisterInterface()                   [注册 CA 接口到 RPC 层]
  2. RegisterCallback()                    [注册交易回调到网络层]
     - 注册各种 TxMsg 回调: handleTx, handleStake 等
     - 注册各种广播回调
     - 注册同步区块回调
  3. subscribeToHttpCallbacks()            [注册 HTTP RPC 路由]
     (仅在 Config::GetRpc() == true 时)
  4. StartTimerTask()                      [启动定时任务]
     【需人工验证】具体启动的定时器列表
  5. CheckNtpTime()                        [NTP 时间同步验证]
  6. MagicSingleton<TransactionCache>->Process()    [启动交易缓存处理线程]
  7. MagicSingleton<ContractDispatcher>->Process()  [启动合约分发处理线程]
  8. MagicSingleton<VRFConsensusNode>->Process()    [启动 VRF 共识处理线程]
  9. 创建 CONTRACT_PATH 目录
```

**涉及文件**: `ca/ca.cpp`, `ca/interface.cpp`
**启动的线程**【推测】:
- TransactionCache 处理线程
- ContractDispatcher 处理线程
- VRFConsensusNode 处理线程
- 定时器线程 (BlockPool, SeekBlock, Database)

---

### 2.7 阶段 1.7: NetInit() [网络层初始化]

```
NetInit():
  1. MagicSingleton<TaskPool>->initializeTaskPool()  [初始化任务线程池]
  2. 注册 Protobuf 消息回调:
     - RegisterNodeReq → handleRegisterNodeRequest
     - RegisterNodeAck → handleRegisterNodeAcknowledgment
     - SyncNodeReq → handleSyncNodeRequest
     - SyncNodeAck → handleSyncNodeAcknowledgment
     - CheckTxReq → handleCheckTransactionRequest
     - CheckTxAck → handleCheckTransactionAck
     - GetUtxoHashReq → handleGetTxUtxoHashRequest
     - GetUtxoHashAck → handleGetTxUtxoHashAcknowledgment
     - PrintMsgReq → processPrintMessageRequest
     - PingReq → HandlePingReq
     - PongReq → handle_pong_request
     - EchoReq → HandleEchoReq
     - EchoAck → handleEchoAcknowledge
     - TestNetAck → networkTestAcknowledge
     - TestNetReq → networkTestRequest
     - NodeHeightChangedReq → processNodeHeightChangeRequest
     - NodeAddrChangedReq → handleNodeAddressChangeRequest
     - KeyExchangeRequest → handleKeyExchangeRequest
     - KeyExchangeResponse → handleKeyExchangeAcknowledgment
     - BuildBlockBroadcastMsg → HandleBroadcastMsg
  3. net_com::InitializeNetwork()          [启动 epoll 事件循环]
     【推测】包括:
     - 监听服务器端口 (kServerMainPort)
     - 连接种子节点
     - 启动心跳定时器 (60s 周期)
     - 启动 epoll 事件循环线程
```

**涉及文件**: `net/interface.h`, `net/api.cpp`, `net/peer_node.cpp`

---

## 三、启动后的持续运行线程模型【推测】

```
主线程: [CLI 菜单循环 或 epoll 等待]
  │
  ├── epoll 主事件循环线程
  │   ├─ 处理 TCP 连接/断开
  │   ├─ 分发 Protobuf 消息到注册的回调
  │   └─ 管理发送/接收缓冲区
  │
  ├── 心跳定时器线程 (每 60 秒)
  │   └─ DealHeart()
  │       ├─ 遍历节点, pulse--
  │       ├─ pulse <= 0 → 删除节点
  │       └─ 发送 Ping 请求
  │
  ├── VRF 共识线程 (每 10 秒周期)
  │   └─ VRFConsensusNode::Process()
  │       ├─ 生成 VRF 种子
  │       ├─ 签名 VRF 信息
  │       ├─ 广播 VRFConsensusInfo
  │       └─ 选择打包节点
  │
  ├── 区块同步线程
  │   └─ SyncBlock::ThreadSync()
  │       ├─ 检测高度差异
  │       ├─ 快速同步 / 从零同步
  │       └─ 分叉检测与解决
  │
  ├── 交易缓存处理线程
  │   └─ TransactionCache::Process()
  │       ├─ 接收新交易
  │       ├─ 验证 (超时/双花/签名)
  │       └─ 打包到区块
  │
  ├── 合约分发线程
  │   └─ ContractDispatcher::Process()
  │       ├─ 依赖检查 (DependencyManager)
  │       ├─ 合约交易缓存管理
  │       └─ 定时重试 (每 1 秒)
  │
  ├── 区块保存定时器
  │   └─ BlockHelper 定时器
  │       └─ 周期性保存区块到数据库
  │
  ├── 分叉检测定时器 (每 15 秒)
  │   └─ CheckBlocks 定时器
  │       ├─ 向质押节点查询 ±50 高度
  │       └─ 51% 共识判定
  │
  ├── 配置监控线程
  │   └─ Config::_Check()
  │       └─ 监控 config.json 变更并重新加载
  │
  ├── BlockHttpCallback 线程
  │   └─ 向外部 HTTP 回调发送区块通知
  │
  └── HTTP 服务器线程
      └─ httplib 监听 http_port
          └─ 分发到注册的 GET/POST 处理函数
```

---

## 四、关键时序问题

### 4.1 初始化顺序依赖

```
InitConfig → InitGenesis → InitLog → InitAccount → InitRocksDb → CaInit → NetInit
     │            │           │           │              │           │         │
     └─ 必须最先 ─┘           │           │              │           │         │
                              └─ 日志依赖配置 ─┘         │           │         │
                                  └─ 账户依赖日志 ──────┘           │         │
                                      └─ 数据库依赖账户 ───────────┘         │
                                          └─ CA 依赖数据库+账户 ───────────┘  │
                                              └─ 网络依赖 CA+数据库 ─────────┘
```

**关键**: InitRocksDb 中使用 `GenesisBlock::GenerateGenesisBlock()` 需要创世配置，因此 InitGenesis 必须在 InitRocksDb 之前。

### 4.2 CaInit vs NetInit 时序

- `CaInit()` 中 `RegisterCallback()` 依赖于 `NetInit()` 中 `ProtobufDispatcher` 的注册机制已就绪
- 但代码中 `main/main.cpp:79` 使用 `CaInit() && NetInit()` 短路求值，意味着 **CaInit 先于 NetInit 执行**
- 【需人工验证】`RegisterCallback()` 的注册操作是否可以在 `ProtobufDispatcher` 初始化之前安全执行（可能是向待注册列表添加而非立即使用）

### 4.3 CleanUp 顺序 (CaCleanup)

从 `ca/ca.cpp:137` 可以看到清理顺序有明确设计:
```
1. CaEndTimerTaskV2()        [取消 DATABASE/BLOCK_POOL/SEEK_BLOCK 定时器]
2. g_heartTimer.Cancel()     [取消心跳定时器]
3. failedTransactionCache->StopTimer()
4. BlockHelper->stopSaveBlock()
5. Benchmark->Clear()
6. TransactionCache->Stop()
7. SyncBlock->ThreadStop()
8. BlockStorage->StopTimer()
9. doubleSpendCache->StopTimer()
10. EpollMode->EpollStop()   [停止 epoll 事件循环]
11. BlockHttpCallbackHandler->Stop()
12. PeerNode->stopNodesSwap()
13. CheckBlocks->StopTimer()
14. VRF->StopTimer()
15. sleep(5)                 [等待所有线程退出]
```

---

## 五、注意事项与风险

1. **`entry.cpp` vs `main/main.cpp` 的双入口问题**: 两个文件都定义了 `main()` 函数，CMakeLists.txt 排除了 `entry.cpp`。但 `entry.cpp` 的 main() 仅做信号处理和命令行解析后立即退出，实际初始化在 `main/main.cpp`。**需确认实际编译使用的是哪个 main()**。

2. **Init() 失败时的不完整清理**: 如果 Init 的中间步骤失败（例如 InitAccount 失败），已经初始化完成的步骤（Config、Genesis、Log）不会被清理。`CleanUp()` 仅在 `init_check()` 检测到 `initFail` 时调用，但 `CleanUp()` 中 `CaCleanup()` 假设 CA 已完全初始化。

3. **MagicSingleton 初始化顺序**: 多个 MagicSingleton 的首次调用分散在 Init 各阶段，没有显式的依赖注入机制。单例的构造顺序实际由调用顺序决定，可能导致潜在的使用未初始化单例问题【低可信度】。

4. **线程创建时机不透明**: `CaInit()` 中 `StartTimerTask()` 和多个 `Process()` 调用的具体行为（是启动新线程还是向已有线程池提交任务）未在入口代码中体现。
