# 重构风险概览 — 高耦合区域与高风险区域

> **分析阶段**: 阶段 1 — 全局架构扫描 (Phase 0)
> **分析日期**: 2026-05-26
> **原则**: 共识安全 > 资金安全 > 性能
> **可信度**: 中等 — 基于静态代码结构分析，未进行运行时验证

---

## 一、风险分布总图

```
高风险区       ████████████████████████████  ca/algorithm.cpp (382KB)
               ████████████████████████      ca/transaction.cpp (128KB)
               ████████████████████████      ca/txhelper.cpp (138KB)
               ██████████████████████        ca/sync_block.cpp (132KB)
               ██████████████████████        api/interface/http_api.cpp (223KB)

中高风险区     ████████████████              ca/advanced_menu.cpp (141KB)
               ████████████████              MagicSingleton 全局单例 (20+ 个)
               ████████████████              ca/global.h 全局可变状态

中风险区       ████████████                  db/db_api.h (81KB 巨型头文件)
               ████████████                  ca/block_helper.cpp (75KB)
               ████████████                  跨模块直接调用 (ca↔net↔rpc)

低风险区       ████████                      utils/ 目录 (73 文件, 职责分散)
               ████████                      pb/ Protobuf 产物 (大但可自动生成)
               ██████                        net/ 网络层 (相对独立)
               ██████                        mpt/ MPT 实现 (相对独立)
               ████                          contract/ 合约辅助 (小模块)
               ██                            common/ 公共配置 (小模块)
```

---

## 二、高耦合区域识别

### 2.1 风险点 #1: `ca/algorithm.cpp` — 算法黑洞

| 属性 | 描述 |
|------|------|
| **位置** | `ca/algorithm.cpp` (~382KB) / `ca/algorithm.h` (~14KB) |
| **风险等级** | **Critical** |
| **耦合模块** | ca (全部子模块), utils, pb, db |
| **现象** | 单个文件承载了 VRF 选择、Hash 计算、共识权重、数据处理等多种算法逻辑 |
| **具体问题** | 1. 无法独立测试某个算法 2. 修改任何算法都有全局影响风险 3. 头文件 14KB 暴露了大量实现细节 |
| **重构难度** | **极高** — 需要深入理解所有算法语义后才能拆分 |

---

### 2.2 风险点 #2: `MagicSingleton` 全局单例泛滥

| 属性 | 描述 |
|------|------|
| **位置** | `utils/magic_singleton.h` + 20+ 个单例类遍布各模块 |
| **风险等级** | **Critical** |
| **耦合模块** | 全部模块 |
| **现象** | 所有模块通过 `MagicSingleton<T>::GetInstance()` 直接获取任意其他模块的实例 |
| **具体问题** | 1. 隐式依赖图 — 无法从接口看出依赖关系 2. 初始化顺序依赖脆弱 3. 测试时需要 mock 全局单例 4. 无法创建隔离的测试环境 |
| **已识别单例** | Config, Genesis, PeerNode, ProtobufDispatcher, KeyExchangeManager, EpollMode, TaskPool, BlockHelper, BlockStorage, BlockMonitor, SyncBlock, TransactionCache, ContractDispatcher, VRFConsensusNode, VRF, CheckBlocks, doubleSpendCache, failedTransactionCache, Benchmark, AccountManager, TimeUtil, BlockHttpCallbackHandler |
| **重构难度** | **极高** — 需要引入依赖注入框架或服务定位器 |

---

### 2.3 风险点 #3: `ca/global.h` — 全局可变状态

| 属性 | 描述 |
|------|------|
| **位置** | `ca/global.h` `namespace global::ca` |
| **风险等级** | **High** |
| **耦合模块** | ca, net, rpc, utils (任何包含此头文件的模块) |
| **现象** | 命名空间中定义了 `static` 定时器、`static` 互斥锁、大量常量和枚举 |
| **具体问题** | 1. `static std::mutex bonusMutex` 等全局锁 — 潜在的锁竞争/死锁风险 2. `static CTimer BLOCK_POOL_TIMER_INTERVAL` 等全局定时器 3. 如果该头文件被多个编译单元包含，static 变量会重复定义【需人工验证】 |
| **重构难度** | **中等** — 需要将全局状态封装为有明确生命周期的对象 |

---

### 2.4 风险点 #4: `api/interface/http_api.cpp` — 注册中心枢纽

| 属性 | 描述 |
|------|------|
| **位置** | `api/interface/http_api.cpp` (~223KB) |
| **风险等级** | **High** |
| **耦合模块** | rpc/api/get/*, rpc/api/post/*, ca, net, utils |
| **现象** | 所有 HTTP 路由注册和 RPC 请求分发集中在一个文件 |
| **具体问题** | 1. 单文件过大, 难以维护 2. 添加/删除 RPC 接口都需要修改此文件 3. 与所有 RPC handler 直接耦合 |
| **重构难度** | **中等** — 可以拆分为按功能模块的路由注册文件 |

---

### 2.5 风险点 #5: 巨型交易处理文件

| 属性 | 描述 |
|------|------|
| **位置** | `ca/transaction.cpp` (~128KB), `ca/txhelper.cpp` (~138KB) |
| **风险等级** | **High** |
| **耦合模块** | ca/evm, ca/transaction/*, db, pb, utils |
| **现象** | 交易验证、UTXO 处理、交易构造逻辑集中在大文件中 |
| **具体问题** | 1. 交易处理逻辑（共识关键路径）难以审查 2. UTXO 花费逻辑和 EVM 状态更新的原子性无法从代码结构上看清 3. 单点故障影响所有交易类型 |
| **重构难度** | **高** — 需要先编写行为锁定测试 |

---

### 2.6 风险点 #6: `db/db_api.h` — 巨型头文件

| 属性 | 描述 |
|------|------|
| **位置** | `db/db_api.h` (~81KB) |
| **风险等级** | **Medium** |
| **耦合模块** | ca, rpc, mpt, utils (任何需要数据库访问的模块) |
| **现象** | 头文件声明了全部数据库访问接口（数百个函数） |
| **具体问题** | 1. 任何 db_api.h 的修改都会触发大面积重编译 2. 接口粒度太细，缺乏按领域的分组 |
| **重构难度** | **中等** — 可以拆分为按领域的子接口（BlockDB, TxDB, UTXODB, ContractDB 等） |

---

### 2.7 风险点 #7: CLI 逻辑与业务逻辑混合

| 属性 | 描述 |
|------|------|
| **位置** | `ca/advanced_menu.cpp` (~141KB) |
| **风险等级** | **Medium** |
| **耦合模块** | ca, rpc, utils |
| **现象** | CLI 交互菜单代码内嵌了交易构造、签名、查询等业务逻辑 |
| **具体问题** | 1. 业务逻辑与 UI 耦合 — 无法独立测试业务逻辑 2. 141KB 的菜单代码远超合理规模 |
| **重构难度** | **中等** — 需要将业务逻辑提取到独立函数/类 |

---

## 三、循环依赖热点

| 区域 | 循环 | 风险 | 说明 |
|------|------|------|------|
| ca ↔ net | ca 调 net 发送消息, net 回调调 ca 处理 | Medium | 通过 Protobuf 回调机制部分解耦 |
| ca ↔ rpc | ca 注册 RPC 回调, rpc 调 ca 执行业务 | Medium | 通过 interface.cpp 解耦但非完全 |
| ca ↔ ca/evm | ca 调 EVM 执行, EVM 回调 ca 访问状态 | Medium | evmc::Host 接口提供解耦 |
| ca/transaction ↔ db | 交易处理读写 db, db 层不依赖 ca | Low | 单向依赖, 风险可控 |

---

## 四、按模块的风险评级

| 模块 | 代码规模 | 风险等级 | 耦合度 | 可测试性 | 关键风险 |
|------|---------|---------|--------|---------|---------|
| **ca/** | ~1.2MB | **Critical** | 极高 | 极低 | 共识核心, 巨型文件, 全局状态 |
| **api/interface/** | ~350KB | **High** | 高 | 低 | 注册中心, 单文件过大 |
| **rpc/api/** | ~140 文件 | **High** | 高 | 中 | 文件数量多但模式统一 |
| **net/** | ~500KB | **Medium** | 中 | 中 | 相对独立, 但 handle_event 复杂 |
| **db/** | ~170KB | **Medium** | 低 | 中 | 巨型头文件, 接口粒度过细 |
| **utils/** | ~73 文件 | **Medium** | 中 | 中 | 文件多, 职责分散, 工具混杂 |
| **mpt/** | ~13 文件 | **Low** | 低 | 高 | 独立模块, 可单独测试 |
| **contract/** | ~9 文件 | **Low** | 低 | 高 | 小模块, 职责清晰 |
| **common/** | ~15 文件 | **Low** | 低 | 高 | 配置管理, 相对独立 |

---

## 五、区块链专项风险预警

根据提示词文档中的区块链专项风险清单，以下是在架构扫描阶段识别出的潜在风险区域：

| 风险领域 | 发现 | 风险等级 |
|---------|------|---------|
| **UTXO + EVM 状态原子性** | `ca/transaction.cpp` 和 `ca/evm/evm_host.cpp` 独立处理 UTXO 和 EVM 状态，原子性保障不清晰 | **Critical** |
| **DAG 分叉处理** | `ca/sync_block.cpp` (132KB) 中分叉逻辑和同步逻辑混杂 | **High** |
| **并发安全** | `ca/global.h` 中 `static std::mutex` 全局锁，锁粒度与获取顺序不明确 | **High** |
| **RocksDB 事务性** | `db/db_api.h` 声明了大量单键操作，WriteBatch 使用模式需要确认 | **Medium** |
| **VRF 随机性** | `ca/algorithm.cpp` 中 VRF 选择逻辑与大文件混杂，难以独立审查 | **High** |
| **年化激励计算** | 算法代码在 `ca/algorithm.cpp` 中，时间源依赖、整型精度风险待确认 | **Medium** |
| **治理(锁定/解锁)** | 分散在 `ca/transaction/lock.cpp`, `ca/transaction/vote.cpp` 等多个文件 | **Medium** |

---

## 六、重构优先级建议 (初步)

| 优先级 | 操作 | 目标 | 预估工时 |
|--------|------|------|---------|
| **P0** | 编写行为锁定测试 | 锁定当前共识行为、UTXO 处理、VRF 选择结果 | 大 (1 周+) |
| **P0** | 确认 entry.cpp/main.cpp 双入口问题 | 消除不确定性 | 小 (1 人日) |
| **P1** | 拆分 `ca/algorithm.cpp` (382KB) | 按 VRF/Hash/共识权重/年化率 拆分为独立模块 | 大 (1 周+) |
| **P1** | 消除 `ca/global.h` 全局可变状态 | 将静态定时器/锁封装到有明确生命周期的类中 | 中 (3 人日) |
| **P1** | 重构 MagicSingleton → 依赖注入 | 解除模块间隐式耦合 | 大 (1 周+) |
| **P2** | 拆分 `api/interface/http_api.cpp` | 按功能区域拆分为多个路由注册文件 | 中 (3 人日) |
| **P2** | 拆分 `db/db_api.h` | 按数据域拆分为子接口 | 中 (3 人日) |
| **P2** | 剥离 `ca/advanced_menu.cpp` 中的业务逻辑 | CLI 与业务逻辑分离 | 中 (3 人日) |
| **P3** | 拆解 `ca/transaction.cpp` + `ca/txhelper.cpp` | 按交易类型拆分，降低单文件大小 | 大 (1 周) |
| **P3** | 重构 `utils/` 目录 | 按密码学/编码/时间/格式化 分类组织 | 中 (3 人日) |

---

## 七、下一步建议

1. **优先编写行为锁定测试**: 在重构任何模块之前，先对 `algorithm.cpp`、`transaction.cpp`、`block_helper.cpp` 的核心函数编写测试，锁定当前行为。
2. **运行静态分析工具**: 使用 cppcheck、clang-tidy 扫描 `ca/` 和 `api/` 目录，识别死代码和潜在 Bug。
3. **确认编译配置**: 明确 `TESTCHAIN` 和 `PRIMARYCHAIN` 宏的使用范围和代码路径差异。
4. **优先重构风险最高的文件**: `ca/algorithm.cpp` (382KB) → `api/interface/http_api.cpp` (223KB) → `ca/transaction.cpp` (128KB)
