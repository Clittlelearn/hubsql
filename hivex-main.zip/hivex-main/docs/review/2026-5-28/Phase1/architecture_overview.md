# MeMeChain 项目架构概览

> **分析阶段**: 阶段 1 — 全局架构扫描 (Phase 0)
> **分析日期**: 2026-05-26
> **可信度说明**: 基于目录结构、头文件依赖、CMakeLists.txt 和源代码入口推断。标注【推测】处为通过命名/结构推断，标注【需人工验证】处为未完全确认。

---

## 一、项目基本信息

| 属性 | 值 |
|------|-----|
| 项目名称 | MeMeChain (`mm`) |
| 语言标准 | C++20 |
| 构建系统 | CMake (>= 3.15) |
| 源码根目录 | `/home/wbl/mm/` |
| 编译入口 | `entry.cpp` → `main/main.cpp` |
| 输出产物 | `bin/mm` (单一可执行文件) |
| 核心模型 | UTXO + 账户混合模型 + DAG 区块结构 |
| 共识算法 | VRF (Verifiable Random Function) 随机选择打包节点 |
| EVM 引擎 | evmone (独立编译为静态库) |
| 存储引擎 | RocksDB (TransactionDB 模式) |
| 网络模型 | epoll 事件循环 + Protobuf 序列化 |

---

## 二、项目目录结构总览

```
/home/wbl/mm/
├── entry.cpp                  # 程序入口 (信号处理 + 命令行解析)
├── CMakeLists.txt             # 构建配置 (单一可执行文件 + GTest)
├── main/                      # 主程序初始化与菜单系统
│   ├── main.cpp               # Init() / Check() / CleanUp() 核心流程
│   └── menu.cpp               # CLI 交互菜单
├── ca/                        # [核心] 共识层 (Consensus Algorithm)
│   ├── ca.cpp/h               # CaInit/CaCleanup 入口, 线程管理
│   ├── algorithm.cpp/h        # 核心算法 (VRF 选择、Hash 计算) ~382KB 巨型文件
│   ├── block_helper.cpp/h     # 区块保存/回滚/验证核心
│   ├── block_stroage.cpp/h    # 区块存储管理
│   ├── block_monitor.cpp/h    # 区块监控
│   ├── sync_block.cpp/h       # 区块同步 (快同步/从零同步) ~132KB
│   ├── transaction.cpp/h      # 交易验证与处理 ~128KB
│   ├── transaction_cache.cpp/h# 交易池缓存
│   ├── txhelper.cpp/h         # 交易构造帮助函数 ~138KB
│   ├── dispatchtx.cpp/h       # 交易分发
│   ├── vrf_consensus.cpp/h    # VRF 共识节点管理
│   ├── contract.cpp/h         # 合约交易入口
│   ├── check_blocks.cpp/h     # 区块验证
│   ├── double_spend_cache.cpp/h # 双花检测缓存
│   ├── failed_transaction_cache.cpp/h # 失败交易缓存
│   ├── interface.cpp/h        # CA 对外接口 (RPC 回调注册)
│   ├── global.h               # 全局常量、枚举、锁定义
│   ├── advanced_menu.cpp/h    # 高级 CLI 菜单 ~141KB 【推测】包含大量 UI 逻辑
│   ├── eth_trans.cpp/h        # ETH 交易兼容处理
│   ├── packager_dispatch.cpp/h# 打包分发
│   ├── ca/evm/                # EVM 集成子模块
│   │   ├── evm_host.cpp/h     # EvmHost 实现 (evmc::Host 接口)
│   │   ├── evm_manager.cpp/h  # EVM 执行管理
│   │   └── evmEnvironment.cpp/h # EVM 环境上下文
│   └── ca/transaction/        # 交易类型子模块 (每种交易独立文件)
│       ├── trans.cpp/h        # 普通转账
│       ├── stake.cpp/h        # 质押
│       ├── unstake.cpp/h      # 解押
│       ├── delegating.cpp/h   # 委托
│       ├── undelegating.cpp/h # 取消委托
│       ├── bonus.cpp/h        # 领取奖励
│       ├── fund.cpp/h         # 领取国库
│       ├── lock.cpp/h         # 锁定(投票)
│       ├── unlock.cpp/h       # 解锁
│       ├── vote.cpp/h         # 投票
│       ├── contract.cpp/h     # 合约交易构造
│       └── utxo_core.cpp/h    # UTXO 核心操作
├── net/                       # [核心] 网络层 (epoll + Protobuf + ECDH)
│   ├── api.cpp/h              # 网络 API (TCP 封装、消息发送)
│   ├── interface.h            # NetInit() + 消息注册/发送模板
│   ├── dispatcher.cpp/h       # Protobuf 消息分发器
│   ├── peer_node.cpp/h        # Peer 节点管理 (增删查改)
│   ├── handle_event.cpp/h     # epoll 事件处理
│   ├── epoll_mode.cpp/h       # epoll 模式封装
│   ├── socket_buf.cpp/h       # Socket 缓冲区
│   ├── pack.cpp/h             # 消息打包 (压缩+加密)
│   ├── key_exchange.cpp/h     # ECDH 密钥交换
│   ├── http_server.cpp/h      # HTTP 服务器封装 (基于 httplib)
│   ├── httplib.h              # cpp-httplib 单头文件库 ~195KB
│   ├── ip_port.cpp/h          # IP/端口转换
│   ├── work_thread.cpp/h      # 网络工作线程
│   ├── msg_queue.h            # 消息队列
│   ├── unregister_node.cpp/h  # 节点注销
│   ├── node.hpp               # Node 结构定义
│   ├── define.h / global.h    # 网络层定义与全局状态
│   └── test.hpp               # 网络测试工具
├── db/                        # [核心] 存储层 (RocksDB 封装)
│   ├── db_api.cpp/h           # 高层数据库 API (Get/Put/Delete 全部业务接口) ~57K/.h 81K
│   ├── rocksdb.cpp/h          # RocksDB 初始化封装
│   ├── rocksdb_read.cpp/h     # 只读读取器
│   └── rocksdb_read_write.cpp/h # 读写事务封装
├── rpc/                       # RPC 服务层
│   ├── rpc.cpp/h              # RPC 分发入口
│   ├── rpc_api.h              # RPC API 基类
│   ├── rpc_data_base.h        # RPC 数据基类
│   ├── rpc_error.h            # RPC 错误码
│   ├── param_handle.cpp/h     # 参数处理器
│   ├── result_handle.cpp/h    # 结果处理器
│   ├── rpc/api/get/           # GET 接口实现 (38 个文件)
│   ├── rpc/api/post/          # POST 接口实现 (93 个文件)
│   ├── rpc/api/               # RPC API 公共文件
│   ├── rpc/eth/               # ETH 兼容接口 (eth_rpc.cpp 等)
│   └── rpc/error/             # RPC 错误定义
├── api/                       # HTTP API 注册层
│   └── interface/
│       ├── http_api.cpp/h     # HTTP 路由注册 (~223KB) + RPC 请求分发
│       ├── rpc_create_transaction.cpp/h # 交易创建请求处理
│       └── rpc_tx.cpp/h       # 交易相关请求
├── contract/                  # 智能合约辅助
│   ├── precompiles.cpp/hpp    # EVM 预编译合约
│   ├── precompiles_cache.cpp  # 预编译结果缓存
│   ├── precompiles_silkpre.cpp# SilkPre 预编译
│   └── hash_utils.cpp/hpp     # 合约哈希工具
├── mpt/                       # Merkle Patricia Trie 实现
│   ├── trie.cpp/h             # MPT 树操作 (插入/查询/提交)
│   ├── rlp.cpp/h              # RLP 编码/解码
│   ├── common.cpp/h           # MPT 通用定义
│   ├── commondata.cpp/h       # MPT 数据存储
│   ├── fixedhash.cpp/h        # 固定长度哈希类型
│   ├── node.h                 # MPT 节点定义
│   ├── exceptions.h           # MPT 异常
│   └── vector_ref.h           # 向量引用工具
├── common/                    # 公共配置与基础设施
│   ├── config.cpp/h           # 配置文件管理 (config.json)
│   ├── genesis.cpp/h          # 创世配置管理 (genesis.json)
│   ├── global_data.cpp/h      # 全局数据对象
│   ├── task_pool.cpp/h        # 任务池/线程池
│   └── time_report.cpp/h      # 耗时统计
├── utils/                     # 工具库 (73 个文件)
│   ├── account_manager.cpp/h  # 账户管理 (创建/导入/导出)
│   ├── crypto.cpp/h           # 密码学工具 (ECDSA/Keccak)
│   ├── ecvrf_p256_sha256_tai.cpp/h # ECVRF 实现
│   ├── contract_utils.cpp/h   # 合约工具函数
│   ├── genesis_block.cpp/h    # 创世区块生成器
│   ├── keystore.cpp/h         # 密钥库 (加密存储)
│   ├── magic_singleton.h      # 全局单例模板 (大量使用)
│   ├── vrf_selection.cpp/h    # VRF 选择算法
│   ├── vrf_trace.cpp/h        # VRF 追踪
│   ├── bench_mark.cpp/h       # 性能基准测试
│   ├── time_util.cpp/h        # 时间工具
│   ├── string_util.cpp/h      # 字符串工具
│   ├── hex_code.cpp/h         # 十六进制编解码
│   ├── base64.cpp/h           # Base64 编解码
│   ├── sha256.cpp/h           # SHA256 封装
│   ├── json_output.cpp/h      # JSON 输出格式化
│   ├── pretty_print.cpp/h     # 格式化打印 ~44KB
│   ├── compress.cpp/h         # 压缩工具
│   ├── envelop.cpp/h          # 信封加解密
│   ├── tmp_log.cpp/h          # 临时日志
│   └── ...                    # 其他工具
├── proto/                     # Protobuf 协议定义 (10 个 .proto)
│   ├── block.proto            # 区块结构
│   ├── transaction.proto      # 交易结构
│   ├── ca_protomsg.proto      # CA 消息
│   ├── net.proto              # 网络消息
│   ├── sync_block.proto       # 同步消息
│   ├── interface.proto        # 接口消息
│   ├── key_exchange.proto     # 密钥交换消息
│   ├── common.proto           # 公共消息
│   ├── sdk.proto              # SDK 消息
│   └── sign.proto             # 签名消息
├── pb/                        # Protobuf 编译产物 (C++ 代码)
├── include/                   # 全局头文件
│   ├── logging.cpp/h          # 日志模块 (基于 spdlog)
│   └── scope_guard.h          # RAII 作用域守卫
├── silkpre/                   # SilkPre 签名算法库 (独立 CMake 项目)
├── errorn/                    # 错误模块
│   ├── ca/ contract/ global/ rpc/ # 分层错误定义
│   └── error_module.h         # 错误模块入口
├── deps/                      # 第三方依赖源码压缩包
│   ├── boost_1_89_0/          # Boost (filesystem, thread, chrono, atomic)
│   ├── rocksdb-v9.6.1/        # RocksDB 存储引擎
│   ├── openssl-3.5.1/         # OpenSSL (密码学 + TLS)
│   ├── protobuf-v3.20.3/      # Protocol Buffers
│   ├── spdlog-v1.8.2/         # spdlog 日志库
│   ├── evmone/                # evmone EVM 引擎 (通过 deps_build 管理)
│   ├── ethash-v1.1.0/         # Ethash (以太坊哈希算法)
│   ├── intx-v0.12.1/          # intx (大整数库)
│   ├── json-v3.12.0/          # nlohmann/json
│   ├── libfmt-7.1.3/          # fmt 格式化库
│   ├── qrcode-v1.8.0/         # QR 码生成
│   └── threadpool/            # 线程池库
├── deps_build/                # 第三方依赖编译产物 (静态库)
├── 3rd/                       # 第三方源码压缩包备份
├── cmake/                     # CMake 工具模块
├── tools/                     # 构建工具脚本 + 测试工具
│   ├── gen_proto.sh           # Protobuf 代码生成
│   └── ecvrf_rfc9381_demo.cpp # ECVRF 演示
├── tests/                     # 单元测试 (GTest)
├── spec/                      # 【推测】规范文档目录
├── wiki/ + wiki_en/           # 【推测】文档目录
├── HXD/                       # 【推测】项目文档 (包含 spec_dev.md 等)
├── build/                     # 构建输出目录
├── test_main.cpp              # 独立测试入口
├── xbuild.sh                  # 编译脚本
└── log.txt + build.log        # 日志文件
```

---

## 三、系统分层架构

```
┌──────────────────────────────────────────────────────────────┐
│                   CLI / 入口层                                │
│   entry.cpp → main/main.cpp → Init() → CaInit() + NetInit()  │
├──────────────────────────────────────────────────────────────┤
│                   RPC / API 层                                │
│   ┌──────────────┐ ┌──────────────┐ ┌────────────────────┐  │
│   │ JSON-RPC 2.0 │ │  ETH 兼容    │ │ HTTP Server(httplib)│  │
│   │ (rpc/api/*)  │ │ (rpc/eth/*)  │ │ (net/http_server)   │  │
│   └──────────────┘ └──────────────┘ └────────────────────┘  │
│   注册: api/interface/http_api.cpp                            │
├──────────────────────────────────────────────────────────────┤
│                   共识层 (CA)                                  │
│   ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐  │
│   │VRF 共识  │ │区块管理  │ │交易处理  │ │同步管理      │  │
│   │vrf_cons* │ │block_help│ │transact*.│ │sync_block    │  │
│   │algorithm │ │block_stor│ │txhelper  │ │check_blocks  │  │
│   └──────────┘ └──────────┘ └──────────┘ └──────────────┘  │
├──────────────────────────────────────────────────────────────┤
│                   智能合约层                                   │
│   ┌──────────────┐ ┌──────────────┐ ┌────────────────────┐  │
│   │ EVM (evmone) │ │  Precompiles │ │ MPT 状态存储       │  │
│   │ EvmHost      │ │  Cache       │ │ (mpt/trie)         │  │
│   │ EvmManager   │ │ (contract/*) │ │                    │  │
│   └──────────────┘ └──────────────┘ └────────────────────┘  │
├──────────────────────────────────────────────────────────────┤
│                   存储层                                      │
│   ┌──────────────────────────────────────────────────────┐  │
│   │  RocksDB (TransactionDB)                             │  │
│   │  - DBReadWriter (读写事务)                            │  │
│   │  - DBReader (只读)                                    │  │
│   │  - db_api (业务接口)                                  │  │
│   └──────────────────────────────────────────────────────┘  │
├──────────────────────────────────────────────────────────────┤
│                   网络层                                      │
│   ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐  │
│   │PeerNode  │ │Protobuf  │ │epoll     │ │ECDH 加密     │  │
│   │Manager   │ │Dispatcher│ │EventLoop │ │Key Exchange  │  │
│   └──────────┘ └──────────┘ └──────────┘ └──────────────┘  │
├──────────────────────────────────────────────────────────────┤
│                   公共组件                                    │
│   ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐  │
│   │Config    │ │Genesis   │ │TaskPool  │ │Logging(spdlog)│  │
│   │Manager   │ │Manager   │ │Timer     │ │              │  │
│   └──────────┘ └──────────┘ └──────────┘ └──────────────┘  │
│   ┌──────────┐ ┌──────────┐ ┌────────────────────────────┐  │
│   │Account   │ │Crypto    │ │MagicSingleton (全局单例)   │  │
│   │Manager   │ │Utils     │ │                            │  │
│   └──────────┘ └──────────┘ └────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

---

## 四、模块职责表

### 4.1 核心子系统

| 子系统 | 目录 | 职责 | 关键文件 | 代码规模 |
|--------|------|------|---------|---------|
| **共识层 (CA)** | `ca/` | VRF 选择打包节点、区块验证与回滚、交易处理、同步管理 | `ca.cpp`, `algorithm.cpp`, `block_helper.cpp` | ~54 文件, ~1.2MB |
| **网络层 (Net)** | `net/` | epoll 事件循环、节点发现与管理、心跳、Protobuf 消息分发、ECDH 加密 | `api.cpp`, `handle_event.cpp`, `peer_node.cpp` | ~34 文件, ~500KB |
| **存储层 (DB)** | `db/` | RocksDB 封装、读写分离、事务支持、业务数据接口 | `db_api.cpp/h` | ~8 文件, ~170KB |
| **RPC 层** | `rpc/` + `api/` | JSON-RPC 2.0 + ETH 兼容接口、HTTP 路由注册 | `http_api.cpp`, 各 `rpc_api_*.cpp` | ~140+ 文件 |
| **EVM 集成** | `ca/evm/` | evmone 宿主接口实现、合约执行环境 | `evm_host.cpp`, `evm_manager.cpp` | ~7 文件 |
| **合约辅助** | `contract/` | 预编译合约、Gas 计算、哈希工具 | `precompiles.cpp` | ~9 文件 |
| **MPT 状态树** | `mpt/` | Merkle Patricia Trie (SHA256, RLP)、合约状态存储 | `trie.cpp`, `rlp.cpp` | ~13 文件 |
| **密码学** | `utils/crypto.cpp`, `silkpre/` | ECDSA 签名、Keccak/SHA256 哈希、VRF 证明 | `crypto.cpp`, `ecvrf_*.cpp` | 分散在 utils/ |
| **账户管理** | `utils/account_manager.cpp` | 密钥库管理、账户创建/导入/导出 | `account_manager.cpp` | ~76KB |
| **配置与创世** | `common/` | config.json 管理、genesis.json 管理、任务池 | `config.cpp`, `genesis.cpp` | ~15 文件 |

### 4.2 支撑子系统

| 子系统 | 目录 | 职责 | 关键文件 |
|--------|------|------|---------|
| **协议定义** | `proto/` | Protobuf 消息格式定义 (10 个 .proto) | `block.proto`, `transaction.proto` |
| **协议编译产物** | `pb/` | Protobuf 生成的 C++ 代码 | `*.pb.cc/h` |
| **日志** | `include/logging.cpp/h` | 基于 spdlog 的日志系统 | `logging.cpp` |
| **错误处理** | `errorn/` | 分层错误码定义 (ca/contract/global/rpc) | `error_module.h` |
| **工具库** | `utils/` | 时间/字符串/编码/压缩/Vrf/基准测试等 | 73 个文件 |
| **CLI 入口** | `main/` | 主程序入口、初始化流程、交互菜单 | `main.cpp`, `menu.cpp` |
| **文档** | `wiki/`, `wiki_en/`, `HXD/`, `spec/` | 项目文档、协议规范 | `spec_dev.md` |

---

## 五、第三方依赖

| 依赖 | 版本 | 用途 | 链接方式 |
|------|------|------|---------|
| **RocksDB** | 9.6.1 | KV 存储引擎 (TransactionDB) | 静态库 |
| **Protobuf** | 3.20.3 | 消息序列化 | 静态库 |
| **evmone** | (独立构建) | EVM 字节码执行引擎 | 静态库 (libevmone-standalone.a) |
| **OpenSSL** | 3.5.1 | 密码学原语 + TLS | 静态库 |
| **spdlog** | 1.8.2 | 异步日志 | 静态库 |
| **Boost** | 1.89.0 | filesystem, thread, chrono, atomic | 静态库 |
| **nlohmann/json** | 3.12.0 | JSON 解析 | Header-only |
| **cpp-httplib** | (内置) | HTTP 服务器 | Header-only (httplib.h, ~195KB) |
| **fmt** | 7.1.3 | 字符串格式化 | 静态库 |
| **ethash** | 1.1.0 | 以太坊哈希算法 | Header-only |
| **intx** | 0.12.1 | 大整数运算 | Header-only |
| **silkpre** | (独立构建) | 自定义签名算法 | 静态库 (libsilkpre-standalone.a) |
| **qrcode** | 1.8.0 | QR 码生成 | 静态库 |

---

## 六、核心入口点

| 入口 | 位置 | 说明 |
|------|------|------|
| **程序入口** | `entry.cpp:5` (`main()`) | 信号处理初始化 → 命令行解析 → 直接调用 `quick_exit(0)`【需人工验证】实际逻辑似乎不在此处 |
| **实际主入口** | `main/main.cpp:282` (`init_check()`) | Init → Check → CleanUp 完整流程 |
| **系统初始化** | `main/main.cpp:34` (`Init()`) | 配置→创世→日志→账户→数据库→CaInit+NetInit |
| **CA 初始化** | `ca/ca.cpp:98` (`CaInit()`) | 注册接口 → HTTP 回调 → 启动定时器 → 启动交易缓存/合约分发/VRF |
| **网络初始化** | `net/interface.h:13` (`NetInit()`) | 注册所有 Protobuf 消息回调 → InitializeNetwork() |
| **HTTP 路由注册** | `api/interface/http_api.cpp:278-296` | GET/POST 路由注册 |
| **区块验证入口** | `ca/block_helper.cpp` | `SaveBlock()` / `RollbackBlock()` |
| **交易处理入口** | `ca/transaction.cpp` | 交易验证 + UTXO 处理 |
| **EVM 入口** | `ca/evm/evm_host.cpp` | `EvmHost::call()` |
| **VRF 共识入口** | `ca/vrf_consensus.cpp` | `VRFConsensusNode::Process()` |
| **区块同步入口** | `ca/sync_block.cpp` | `SyncBlock::ThreadSync()` |

---

## 七、全局单例 (MagicSingleton) 使用情况

项目通过 `utils/magic_singleton.h` 大量使用全局单例模式，以下为已识别的核心单例：

| 单例类 | 所在模块 | 职责 |
|--------|---------|------|
| `Config` | common | 配置管理 |
| `Genesis` | common | 创世配置 |
| `PeerNode` | net | 节点列表管理 |
| `ProtobufDispatcher` | net | 消息回调注册/分发 |
| `KeyExchangeManager` | net | ECDH 密钥管理 |
| `EpollMode` | net | epoll 事件循环 |
| `TaskPool` | common | 线程任务池 |
| `BlockHelper` | ca | 区块保存/回滚 |
| `BlockStorage` | ca | 区块存储 |
| `BlockMonitor` | ca | 区块监控 |
| `SyncBlock` | ca | 区块同步 |
| `TransactionCache` | ca | 交易池 |
| `ContractDispatcher` | ca | 合约分发 |
| `VRFConsensusNode` | ca | VRF 共识 |
| `VRF` | utils | VRF 签名 |
| `CheckBlocks` | ca | 区块验证 |
| `doubleSpendCache` | ca | 双花检测 |
| `failedTransactionCache` | ca | 失败交易缓存 |
| `Benchmark` | utils | 性能基准 |
| `AccountManager` | utils | 账户管理 |
| `TimeUtil` | utils | 时间工具 |
| `BlockHttpCallbackHandler` | ca | HTTP 回调 |

---

## 八、重点关注项

1. **`entry.cpp` 与实际启动流程不一致**: `entry.cpp` 的 `main()` 仅做信号处理和命令行解析后直接 `quick_exit(0)`，实际的 `Init()` 流程在 `main/main.cpp`。`CMakeLists.txt` 中 `entry.cpp` 被排除在 `SOURCES` 之外【需人工验证】实际编译入口。

2. **巨型文件**: `ca/algorithm.cpp` (~382KB)、`ca/sync_block.cpp` (~132KB)、`ca/txhelper.cpp` (~138KB)、`ca/transaction.cpp` (~128KB)、`api/interface/http_api.cpp` (~223KB)、`ca/advanced_menu.cpp` (~141KB) 存在严重代码膨胀。

3. **MagicSingleton 全局状态**: 至少 20+ 个全局单例散布各模块，大量使用模板 `MagicSingleton<T>::GetInstance()`，导致模块间强耦合。

4. **头文件依赖爆炸**: `net/api.h` 包含了几乎所有网络子模块头文件；`ca/ca.h` 包含了多个交易类型头文件。

5. **Protobuf 编译产物巨大**: `interface.pb.cc` (~635KB)、`sync_block.pb.cc` (~324KB)、`sdk.pb.cc` (~243KB) 等，反映协议定义复杂。
