# 模块依赖关系分析

> **分析阶段**: 阶段 1 — 全局架构扫描 (Phase 0)
> **分析日期**: 2026-05-26
> **表示法**: `A → B` 表示模块 A 依赖模块 B
> **可信度**: 基于 `#include` 关系、CMakeLists.txt 链接顺序和函数调用分析推断

---

## 一、模块依赖关系总图

```
                        ┌─────────────┐
                        │   entry.cpp │ (编译入口，独立)
                        └──────┬──────┘
                               │
                        ┌──────▼──────┐
                        │  main/      │
                        │  main.cpp   │
                        └──┬───┬───┬──┘
                           │   │   │
              ┌────────────┼───┼───┼────────────┐
              │            │   │   │            │
       ┌──────▼──────┐  ┌──▼───▼───▼──┐  ┌─────▼──────┐
       │  common/    │  │    ca/      │  │   net/     │
       │  config     │◄─│   ca.cpp    │──│  api.cpp   │
       │  genesis    │  │  algorithm  │  │  dispatcher│
       │  task_pool  │  │  block_*    │  │  peer_node │
       └──────┬──────┘  │  sync_block │  │  epoll_*   │
              │         │  transaction│  │  key_exch  │
              │         │  txhelper   │  │  http_srv  │
              │         │  vrf_cons*  │  └─────┬──────┘
              │         │  evm/       │        │
              │         │  transaction│        │
              │         └──────┬──────┘        │
              │                │               │
       ┌──────▼──────┐  ┌──────▼──────┐  ┌─────▼──────┐
       │   utils/    │  │    db/      │  │   api/     │
       │  crypto     │  │  db_api     │  │  http_api  │
       │  account_*  │  │  rocksdb_*  │  │  rpc_tx    │
       │  ecvrf_*    │  └──────┬──────┘  └─────┬──────┘
       │  magic_sing │         │               │
       │  time_util  │         │        ┌──────▼──────┐
       │  ...        │         │        │    rpc/     │
       └──────┬──────┘         │        │  rpc.cpp    │
              │                │        │  param/     │
       ┌──────▼──────┐         │        │  result_*   │
       │   mpt/      │         │        │  api/get/   │
       │  trie       │         │        │  api/post/  │
       │  rlp        │         │        │  eth/       │
       └──────┬──────┘         │        └────────────┘
              │                │
       ┌──────▼──────┐         │
       │  contract/  │         │
       │  precompiles│         │
       └──────┬──────┘         │
              │                │
       ┌──────▼──────┐         │
       │   pb/       │◄────────┘  (所有模块依赖 pb/)
       │  proto 产物  │
       └─────────────┘
```

---

## 二、逐模块依赖详解

### 2.1 main/ (入口模块)

```
main/ ──→ common/    (Config, Genesis)
     ──→ utils/     (AccountManager, TimeUtil, HexCode, PrettyPrint, GenesisBlock)
     ──→ ca/        (CaInit, CaCleanup, Algorithm, Interface, AdvancedMenu, BlockHelper)
     ──→ net/       (NetInit, httplib)
     ──→ db/        (DBInit, DBReadWriter)
     ──→ pb/        (interface.pb.h)
     ──→ mpt/       (RLP)
     ──→ include/   (Logging)
```

**说明**: main 模块是最上层，几乎依赖所有核心模块。它本身很小（~7KB），但通过 Init() 串联了全部子系统。

---

### 2.2 ca/ (共识层 — 核心最重模块)

```
ca/ ──→ net/        (网络消息发送/广播/注册)
   ──→ db/         (区块/交易/UTXO 持久化)
   ──→ pb/         (全部 Protobuf 消息类型)
   ──→ utils/      (Crypto, TimeUtil, MagicSingleton, AccountManager, 等)
   ──→ common/     (Config, Genesis, TaskPool)
   ──→ mpt/        (合约状态 MPT 操作)
   ──→ contract/   (预编译合约)
   ──→ ca/evm/     (EVM 执行)
   ──→ ca/transaction/ (各交易类型处理)
   ──→ include/    (Logging)
```

**内部依赖链**（按子模块）:
- `ca.cpp` → `algorithm.cpp` → `block_helper.cpp` → `transaction.cpp` → `txhelper.cpp`
- `ca.cpp` → `vrf_consensus.cpp` → `algorithm.cpp`
- `ca.cpp` → `sync_block.cpp` → `block_helper.cpp` → `transaction.cpp`
- `ca.cpp` → `contract.cpp` → `ca/evm/evm_host.cpp` → `mpt/trie.cpp`
- `ca.cpp` → `interface.cpp` → `rpc/`, `api/`

**关键依赖链** (对外):
```
ca/ca.cpp → net/interface.h   (CaInit 后注册网络回调)
ca/ca.cpp → api/interface/    (注册 HTTP 路由)
ca/contract.cpp → mpt/trie.cpp (合约状态 MPT 操作)
ca/evm/evm_host.cpp → db/db_api.cpp (合约代码/状态读写)
ca/evm/evm_host.cpp → contract/precompiles.cpp
```

---

### 2.3 net/ (网络层)

```
net/ ──→ common/    (Config, Genesis)
   ──→ pb/         (全部网络/同步/CA 消息)
   ──→ utils/      (MagicSingleton, Crypto, TimeUtil)
   ──→ include/    (Logging)
```

**说明**: 网络层相对独立，不依赖 ca/、db/、rpc/。它通过 Protobuf 回调机制与上层解耦。但 `net/api.h` 包含了大量 `utils/` 头文件。

**内部依赖链**:
```
api.cpp → peer_node.cpp → socket_buf.cpp
api.cpp → handle_event.cpp → epoll_mode.cpp
api.cpp → key_exchange.cpp → utils/crypto.cpp
handle_event.cpp → dispatcher.cpp → pack.cpp
```

---

### 2.4 db/ (存储层 — 最底层)

```
db/ ──→ pb/         (区块/交易 Protobuf 消息)
   ──→ include/    (Logging)
   ──→ 第三方      (RocksDB, Protobuf)
```

**说明**: db/ 是本项目最底层的业务模块，几乎不依赖其他内部模块。`db_api.h` (81KB) 定义了所有数据库 Key-Value 操作接口。

---

### 2.5 rpc/ + api/ (RPC 服务层)

```
rpc/ ──→ ca/        (交易构造、查询接口)
    ──→ db/         (区块/交易/UTXO 查询)
    ──→ pb/         (全部消息类型)
    ──→ utils/      (Crypto, TimeUtil, AccountManager, HexCode, 等)
    ──→ common/     (Config, Genesis)
    ──→ net/        (HttpServer)
    ──→ include/    (Logging)

api/ ──→ rpc/       (RPC 分发入口)
    ──→ ca/         (ca/interface.h)
    ──→ net/        (HttpServer, httplib)
    ──→ pb/
```

**说明**: RPC 层通过 `ca/interface.h` 间接依赖 ca 模块的核心逻辑，也直接依赖 db/ 进行数据查询。`api/interface/http_api.cpp` (223KB) 是 HTTP 路由注册的中心枢纽。

---

### 2.6 其他模块依赖

| 模块 | 依赖项 | 说明 |
|------|--------|------|
| **mpt/** | `pb/`, `db/`, `utils/` | MPT 节点通过 db/db_api 持久化 |
| **contract/** | `mpt/`, `utils/`, evmone | 预编译合约执行 |
| **utils/** | `pb/`, `common/`, `silkpre/`, OpenSSL | 工具库广泛依赖底层库 |
| **common/** | `utils/`, `pb/` | Config 依赖 nlohmann/json, Timer |
| **include/** | 无内部依赖 | logging 仅依赖 spdlog |
| **pb/** | 无内部依赖 | Protobuf 产物，被所有模块依赖 |
| **proto/** | 无内部依赖 | 定义文件，不参与编译 |
| **silkpre/** | OpenSSL | 独立 CMake 项目 |
| **errorn/** | 无内部依赖 | 纯头文件错误定义 |

---

## 三、全局依赖矩阵

| 依赖→<br>被依赖↓ | main | ca | net | db | rpc/api | utils | common | mpt | contract | pb |
|:---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **main** | - | ✓ | ✓ | ✓ | - | ✓ | ✓ | ✓ | - | ✓ |
| **ca** | - | - | ✓ | ✓ | - | ✓ | ✓ | ✓ | ✓ | ✓ |
| **net** | - | - | - | - | - | ✓ | ✓ | - | - | ✓ |
| **rpc/api** | - | ✓ | ✓ | ✓ | - | ✓ | ✓ | - | - | ✓ |
| **db** | - | - | - | - | - | - | - | - | - | ✓ |
| **mpt** | - | - | - | ✓ | - | ✓ | - | - | - | ✓ |
| **contract** | - | - | - | - | - | ✓ | - | ✓ | - | - |
| **utils** | - | - | - | - | - | - | ✓ | - | - | ✓ |
| **common** | - | - | - | - | - | ✓ | - | - | - | ✓ |
| **pb** | - | - | - | - | - | - | - | - | - | - |

> ✓ = 行模块依赖列模块

---

## 四、高耦合热点

### 4.1 `utils/magic_singleton.h` — 全局单例模板

所有模块通过 `MagicSingleton<T>::GetInstance()` 直接访问其他模块的实例，导致隐式耦合：

```
ca/ca.cpp 使用:
  MagicSingleton<Config>           (common)
  MagicSingleton<TaskPool>         (common)
  MagicSingleton<TransactionCache> (ca)
  MagicSingleton<ContractDispatcher>(ca)
  MagicSingleton<VRFConsensusNode> (ca)
  MagicSingleton<BlockHttpCallbackHandler> (ca)

net/api.cpp 使用:
  MagicSingleton<PeerNode>         (net)
  MagicSingleton<KeyExchangeManager>(net)
  MagicSingleton<Config>           (common)
  MagicSingleton<Genesis>          (common)

main/main.cpp 使用:
  MagicSingleton<Config>
  MagicSingleton<Genesis>
  MagicSingleton<Log>              (include)
  MagicSingleton<AccountManager>   (utils)
  MagicSingleton<TimeUtil>         (utils)
```

### 4.2 `ca/global.h` — 全局常量与全局锁

`global::ca` 命名空间定义了所有模块共享的常量、静态定时器、静态互斥锁。这导致：
- 任何包含 `ca/global.h` 的模块都隐式依赖这些全局状态
- `bonusMutex`, `kDelegatingMutex`, `BURN_MUTEX`, `LOCK_MUTEX` 是全局可见锁
- `BLOCK_POOL_TIMER_INTERVAL`, `SEEK_BLOCK_TIMER`, `DATABASE_TIMER` 是全局定时器

### 4.3 `api/interface/http_api.cpp` — 注册中心枢纽

所有 RPC 接口都在此文件注册（~223KB），直接依赖几乎所有 rpc/api/get/ 和 rpc/api/post/ 中的处理函数，以及 ca/interface.cpp 中的回调。任何 RPC 接口的新增/修改都需要编辑此文件。

### 4.4 `ca/algorithm.cpp` — 算法黑洞

~382KB 单文件，包含【推测】VRF 选择算法、Hash 计算、共识权重计算、数据处理等多种算法逻辑，是项目最大的单一文件。

---

## 五、循环依赖风险

| 风险区域 | 描述 | 严重度 |
|---------|------|--------|
| ca ↔ net | ca 通过 net 发送消息, net 通过回调调用 ca 处理函数 | 中 (通过 Protobuf 回调解耦) |
| ca ↔ rpc/api | ca 通过 interface.cpp 注册 RPC 回调, rpc/api 通过 http_api.cpp 调用 ca | 中 (通过回调机制解耦) |
| ca/evm ↔ mpt | EVM 执行依赖 MPT 状态, MPT 存储依赖 EVM 交易触发 | 低 (单向为主) |
| ca/transaction ↔ db | 交易处理依赖 db 读写, 但 db 层不依赖 ca | 无风险 (单向) |

---

## 六、依赖深度

```
层级 4 (顶层):     main/
层级 3 (业务层):   ca/, rpc/, api/
层级 2 (服务层):   net/, utils/, contract/, mpt/
层级 1 (基础设施): db/, common/, pb/, include/
层级 0 (外部):     RocksDB, evmone, OpenSSL, Protobuf, Boost, spdlog
```

**标注**: ca/ 模块横跨层级 3 和部分层级 2 功能（通过 ca/evm/ 和 ca/transaction/），是事实上的核心枢纽模块。

---

## 七、注意事项

1. **所有依赖关系基于 `#include` 指令静态分析**，实际运行时依赖（通过回调/P2P 消息）可能不同。
2. **MagicSingleton 导致的隐式依赖**未完全体现在 `#include` 层面，但运行时高度耦合。
3. **`pb/` 是全局依赖**，任何模块修改 .proto 文件都可能导致大面积重编译。
4. **`db/db_api.h` (81KB)** 虽然只是头文件，但由于被 ca/、rpc/ 广泛包含，修改成本高。
