# MeMeChain 重构总体规划 (Refactor Master Plan)

> **阶段**: 阶段 4 — 重构规划
> **分析日期**: 2026-05-26
> **视角**: 长期可维护的大型区块链节点工程
> **核心原则**: 共识安全 > 资金安全 > 性能
> **重构策略**: Strangler Fig 模式 — 逐步替换，保留回滚路径

---

## 一、当前架构问题总览

### 1.1 架构健康度评分

| 维度 | 评分 | 说明 |
|------|------|------|
| 模块边界 | 3/10 | CA 模块承载过多职责，交易/共识/EVM/同步混杂 |
| 耦合度 | 3/10 | MagicSingleton 导致隐式全局耦合，无法独立测试 |
| 代码组织 | 4/10 | 6 个巨型文件(>100KB)，65% 代码集中在 10 个文件中 |
| 并发安全 | 4/10 | _accountList 无锁、shared_lock下erase、EVM超时线程泄漏 |
| 测试覆盖 | 1/10 | 仅 8 个测试文件，无共识/交易/EVM 行为测试 |
| 错误恢复 | 3/10 | DB损坏直接 exit(-1)、回滚路径不一致、信号用 _exit() |
| 规范一致性 | 5/10 | MPT SHA256 vs Keccak256、共识阈值混乱、Key前缀命名偏差 |
| **综合** | **3.3/10** | **需要系统性重构** |

### 1.2 核心问题地图

```
                   ┌──────────────────────────────┐
                   │     全局状态污染 (Critical)    │
                   │  MagicSingleton ×20+         │
                   │  ca/global.h static mutex ×4  │
                   └──────────────┬───────────────┘
                                  │ 导致
          ┌───────────────────────┼───────────────────────┐
          │                       │                       │
┌─────────▼─────────┐  ┌─────────▼─────────┐  ┌─────────▼─────────┐
│ 模块间隐式耦合     │  │ 测试不可行        │  │ 初始化顺序脆弱    │
│ ca↔net↔rpc↔db    │  │ 无依赖注入        │  │ Init 7步严格顺序  │
└─────────┬─────────┘  └─────────┬─────────┘  └─────────┬─────────┘
          │                       │                       │
          └───────────────────────┼───────────────────────┘
                                  │
                   ┌──────────────▼───────────────┐
                   │     巨型文件 (Critical)       │
                   │  algorithm.cpp   382KB       │
                   │  http_api.cpp    223KB       │
                   │  txhelper.cpp    138KB       │
                   │  advanced_menu   141KB       │
                   │  sync_block.cpp  132KB       │
                   │  transaction.cpp 128KB       │
                   └──────────────────────────────┘
```

---

## 二、重构优先级排序

### P0 — 必须立即修复（影响共识安全/双花风险/状态不一致）

| # | 问题 | 位置 | 风险 | 工时 |
|---|------|------|------|------|
| P0-1 | **MPT SHA256 与以太坊 Keccak256 不兼容** | `mpt/trie.cpp:429` | Critical — 合约状态根哈希无法与以太坊互操作，跨链验证不可行 | 中 3人日 |
| P0-2 | **回滚无原子 UTXO 恢复** | 两条路径: `algorithm.cpp:7511` vs `block_helper.cpp:1155` | Critical — 回滚后UTXO状态可能不一致导致双花 | 大 1周 |
| P0-3 | **区块签名不验证打包节点资格** | `algorithm.cpp:3923` verifyPreSaveBlock_ | Critical — 非VRF选中节点也可对区块签名 | 中 3人日 |
| P0-4 | **年化率取整导致~5.8%超额支付** | `algorithm.cpp:7835` `round(rate/100*100)/100` | Critical — 所有奖励超额发放，影响代币经济 | 小 1人日 |
| P0-5 | **交易池无容量限制/超时淘汰** | `transaction_cache.cpp` `_kTxExpireInterval=10` 未使用 | Critical — DoS攻击可OOM，内存膨胀 | 中 3人日 |
| P0-6 | **`_accountList` 无锁保护** | `account_manager.h:434` | Critical — 批量加载时多线程数据竞争 | 小 1人日 |
| P0-7 | **`shared_lock` 下执行 `erase()`** | `transaction_cache.cpp:1356` removeContractInfoCacheRequest | Critical — 读锁下修改容器，UB/崩溃 | 小 1人日 |
| P0-8 | **DB损坏直接 `exit(-1)`** | `rocksdb.cpp:18` BackgroundErrorListener | Critical — 无优雅关闭，WAL未flush | 小 1人日 |
| P0-9 | **主链选择用75百分位而非共识权重** | `block_helper.cpp:2113` getChainHeight | Critical — 与规范定义的DAG共识权重选择不一致 | 大 1周 |

**P0 合计工时: 约 4.5 周 (22.5 人日)**

### P1 — 本迭代修复（逻辑错误/内存泄漏/并发竞态）

| # | 问题 | 位置 | 风险 | 工时 |
|---|------|------|------|------|
| P1-1 | **签名平均数整数除法错误** | `algorithm.cpp:95` | High — 异常节点检测阈值不准确 | 小 1人日 |
| P1-2 | **EVM超时后线程泄漏** | `contract.cpp:94-103` | High — 僵尸线程累积 | 中 3人日 |
| P1-3 | **`message.gas`=用户全部VOTE余额** | `evmEnvironment.cpp:116` | High — EVM执行无Gas限制 | 中 3人日 |
| P1-4 | **UnStake `checkParams()` 空函数体UB** | `transaction/unstake.cpp` | High — 未定义行为 | 小 1人日 |
| P1-5 | **FindUtxo 死代码致锁定期逻辑失效** | `transaction/utxo_core.cpp` | High — 质押锁定逻辑可能被绕过 | 中 3人日 |
| P1-6 | **EIP-1559 使用 double 浮点** | `fee_calculator.h:27` | Medium — 跨平台精度差异 | 小 1人日 |
| P1-7 | **块签名阈值混乱(51/66/80/90%)** | 多处 | High — 共识判定不可预测 | 中 3人日 |
| P1-8 | **失败交易重试时重新计算hash** | `failed_transaction_cache.cpp:85-87` | High — 签名失效 | 小 1人日 |
| P1-9 | **Config 热加载无锁写文件** | `config.cpp:647-660` | Medium — 并发写损坏配置文件 | 小 1人日 |
| P1-10| **信号路径用 `_exit()` 不走析构** | `utils/init.cpp` | High — RocksDB WAL可能未flush | 小 1人日 |

**P1 合计工时: 约 3.8 周 (19 人日)**

### P2 — 下迭代修复（代码结构优化/解耦/废弃代码清理）

| # | 问题 | 位置 | 风险 | 工时 |
|---|------|------|------|------|
| P2-1 | **拆分 `algorithm.cpp` (382KB)** | 拆为 13 个子模块 | Medium | 大 1周 |
| P2-2 | **拆分 `http_api.cpp` (223KB)** | 拆为 8 个路由文件 | Medium | 中 3人日 |
| P2-3 | **拆分 `txhelper.cpp` (138KB)** | 按交易类型拆分 | Medium | 大 1周 |
| P2-4 | **拆分 `sync_block.cpp` (132KB)** | 同步/分叉/回滚三分离 | Medium | 大 1周 |
| P2-5 | **拆分 `transaction.cpp` (128KB)** | 按交易类型拆分 | Medium | 大 1周 |
| P2-6 | **拆分 `advanced_menu.cpp` (141KB)** | MVC分离 | Medium | 中 3人日 |
| P2-7 | **拆分 `db_api.h` (81KB)** | 按数据域拆为 10 个子接口 | Medium | 中 3人日 |
| P2-8 | **清理 `contract.cpp` `#if 0` 代码** | 全文件注释 | Low | 小 1人日 |
| P2-9 | **清理 ContractTransactionCache 废弃代码** | 全文件注释 | Low | 小 1人日 |
| P2-10| **统一 Key 前缀命名** | 规范短前缀 vs 实现长前缀(41项) | Low | 中 3人日 |
| P2-11| **统一共识阈值** | 51/66/75/80/90 → 规范定义 | Medium | 中 3人日 |

**P2 合计工时: 约 7 周 (35 人日)**

### P3 — 按需优化（性能优化/代码风格统一）

| # | 问题 | 工时 |
|---|------|------|
| P3-1 | P-256/secp256k1 双曲线统一 | 中 3人日 |
| P3-2 | ETH 接口补全 (eth_getLogs/eth_getStorageAt) | 中 3人日 |
| P3-3 | RPC 参数校验补全 (多数 checkParams 为空) | 中 3人日 |
| P3-4 | RPC GET/POST 命名规范统一 | 小 1人日 |
| P3-5 | 拼写错误修正 (sestoryDB→destroyDB, PEROID→PERIOD等) | 小 1人日 |
| P3-6 | 添加 RPC 限流机制 | 中 3人日 |
| P3-7 | 广播策略可配置化 | 小 1人日 |
| P3-8 | Node 结构命名规范化 | 小 1人日 |
| P3-9 | 统一 3 种错误输出体系 (EXP_ERROR/protobuf status/cout) | 中 3人日 |
| P3-10| 添加请求级别的超时控制 | 小 1人日 |
| P3-11| cpp_bin_float 替换 double 浮点计算 | 中 3人日 |

**P3 合计工时: 约 4.6 周 (23 人日)**

---

## 三、推荐目录重组方案

### 当前结构 vs 目标结构

```
当前 (扁平)                          目标 (分层)
/home/wbl/mm/                        /home/wbl/mm/
├── ca/  (54文件, ~1.2MB)           ├── core/           # 核心协议层
│   ├── algorithm.cpp 382KB         │   ├── consensus/   # VRF共识/打包节点选择
│   ├── block_*.cpp                 │   ├── block/       # 区块管理/验证/回滚
│   ├── transaction*.cpp            │   ├── sync/        # 区块同步/分叉解决
│   ├── vrf_consensus.cpp           │   ├── txpool/      # 交易池/缓存
│   ├── sync_block.cpp 132KB        │   ├── utxo/        # UTXO操作/选择/花费
│   ├── contract.cpp 56KB           │   └── governance/  # 治理/投票/提案
│   ├── evm/                        │
│   └── transaction/                ├── execution/      # 执行层
│                                   │   ├── evm/         # EVM宿主/管理/环境
├── net/  (34文件)                  │   ├── precompiles/ # 预编译合约
├── rpc/  (140+文件)                │   ├── mpt/         # MPT状态树
├── api/                            │   └── gas/         # Gas计算(EIP-1559)
├── db/   (8文件)                   │
├── mpt/  (13文件)                  ├── interface/      # 接口层
├── contract/ (9文件)               │   ├── rpc/         # JSON-RPC接口
├── common/ (15文件)                │   ├── eth/         # ETH兼容
├── utils/ (73文件)                 │   └── http/        # HTTP服务器
├── proto/                          │
├── pb/                             ├── infrastructure/ # 基础设施层
├── main/                           │   ├── store/       # RocksDB封装
├── include/                        │   ├── net/         # P2P网络
├── silkpre/                        │   ├── config/      # 配置管理
├── errorn/                         │   └── logging/     # 日志
│                                   │
│                                   ├── crypto/         # 密码学层
│                                   │   ├── ecdsa/       # ECDSA/secp256k1
│                                   │   ├── hash/        # SHA256/Keccak
│                                   │   ├── vrf/         # ECVRF
│                                   │   └── keystore/    # 密钥库
│                                   │
│                                   ├── app/            # 应用层
│                                   │   ├── cli/         # 命令行界面
│                                   │   └── init/        # 启动/初始化
│                                   │
│                                   └── proto/          # 协议定义
```

### 重组原则

1. **按依赖层次组织**：crypto → infrastructure → core → execution → interface → app
2. **每个目录不超过 15 个文件**
3. **每个 .cpp 文件不超过 2000 行**
4. **头文件只暴露公共接口，内部头文件放 `internal/` 子目录**

---

## 四、推荐 Namespace 规范

```cpp
// 旧命名空间 → 新命名空间映射
mmc::rpc           → memechain::rpc
mmc::ca            → memechain::core
mmc::net           → memechain::net
(全局作用域)        → memechain::crypto
(全局作用域)        → memechain::store

// 完整 namespace 层级
namespace memechain {
  namespace core {       // 核心协议
    namespace consensus {}  // VRF/打包
    namespace block {}      // 区块
    namespace sync {}       // 同步
    namespace txpool {}     // 交易池
    namespace utxo {}       // UTXO
    namespace governance {} // 治理
  }
  namespace execution {  // 执行层
    namespace evm {}        // EVM引擎
    namespace mpt {}        // 状态树
    namespace gas {}        // Gas
  }
  namespace interface {  // 接口层
    namespace rpc {}        // JSON-RPC
    namespace eth {}        // ETH兼容
  }
  namespace infra {      // 基础设施
    namespace store {}      // 存储
    namespace net {}        // 网络
    namespace config {}     // 配置
  }
  namespace crypto {     // 密码学
    namespace vrf {}        // ECVRF
    namespace keystore {}   // 密钥管理
  }
  namespace app {        // 应用
    namespace cli {}        // CLI
    namespace init {}       // 初始化
  }
}
```

### 实施规则

1. **禁止 `using namespace` 在头文件中**
2. **新代码使用全限定名** `memechain::core::block::SaveBlock()`
3. **旧命名空间保留为别名** (过渡期): `namespace mmc::ca = memechain::core;`
4. **`ca/global.h` 中的全局常量迁移到各自模块的 `constants.h`**

---

## 五、接口抽象建议（依赖反转）

### 5.1 当前依赖问题

```
当前 (强耦合):
  RPC层 ──直接包含──► CA头文件 ──直接访问──► DB单例
   │                     │                      │
   └── 编译时依赖 ───────┴──────────────────────┘
```

### 5.2 目标架构

```
目标 (依赖反转):
  RPC层 ──依赖──► IServiceLayer (抽象接口)
                      ▲
                      │ 实现
                  ServiceLayer ──依赖──► IStore (抽象接口)
                                             ▲
                                             │ 实现
                                         RocksDBStore
```

### 5.3 核心接口定义

```cpp
// 存储层抽象 (infra/store/store_interface.h)
class IStoreReader {
public:
  virtual ~IStoreReader() = default;
  virtual std::optional<Block> getBlock(const Hash& hash) = 0;
  virtual std::optional<uint64_t> getBlockTop() = 0;
  virtual std::optional<Transaction> getTransaction(const Hash& hash) = 0;
  virtual std::optional<uint64_t> getBalance(const Address& addr, const AssetType& asset) = 0;
  // ... 其他只读接口
};

class IStoreWriter {
public:
  virtual ~IStoreWriter() = default;
  virtual bool beginTransaction() = 0;
  virtual bool commitTransaction() = 0;
  virtual bool rollbackTransaction() = 0;
  virtual bool saveBlock(const Block& block) = 0;
  // ... 其他写入接口
};

// 共识层抽象 (core/consensus/consensus_interface.h)
class IConsensusEngine {
public:
  virtual ~IConsensusEngine() = default;
  virtual std::vector<NodeId> selectPackagers(uint64_t period) = 0;
  virtual bool verifyBlockSignature(const Block& block) = 0;
  virtual ChainHeight getChainHeight() = 0;
};

// 执行层抽象 (execution/evm/executor_interface.h)
class IEvmExecutor {
public:
  virtual ~IEvmExecutor() = 0;
  virtual ExecutionResult execute(const Transaction& tx, IStoreReader& store) = 0;
  virtual Hash getStateRoot(const Address& contract) = 0;
};

// 服务层抽象 (提供给 RPC 层)
class IServiceLayer {
public:
  virtual ~IServiceLayer() = default;
  virtual std::optional<uint64_t> getBalance(const Address&, const AssetType&) = 0;
  virtual std::optional<Transaction> createTransaction(const TxParams&) = 0;
  virtual std::optional<std::string> sendTransaction(const Transaction&) = 0;
  // ... 所有 RPC 需要的操作
};
```

### 5.4 依赖注入替代 MagicSingleton

```cpp
// 旧方式 (全局单例)
auto& config = MagicSingleton<Config>::GetInstance();
auto& peerNode = MagicSingleton<PeerNode>::GetInstance();

// 新方式 (依赖注入)
class Application {
  std::unique_ptr<IConfig> config_;
  std::unique_ptr<IPeerManager> peerManager_;
  std::unique_ptr<IStoreWriter> storeWriter_;
  std::unique_ptr<IConsensusEngine> consensus_;
  std::unique_ptr<IEvmExecutor> executor_;
  std::unique_ptr<IServiceLayer> serviceLayer_;
public:
  Application(AppConfig cfg)
    : config_(std::make_unique<JsonConfig>(cfg.configPath))
    , peerManager_(std::make_unique<PeerNodeManager>(*config_))
    , storeWriter_(std::make_unique<RocksDBStore>(cfg.dbPath))
    , consensus_(std::make_unique<VRFConsensus>(*storeWriter_, *config_))
    , executor_(std::make_unique<EvmoneExecutor>(*storeWriter_))
    , serviceLayer_(std::make_unique<ServiceImpl>(*storeWriter_, *consensus_, *executor_))
  {}
};
```

---

## 六、模块边界重新划分建议

### 当前 vs 建议边界

| 当前模块 | 问题 | 建议拆分 |
|---------|------|---------|
| `ca/` (54 文件) | 承载共识+交易+同步+EVM+治理+激励 | core/ (6个子模块) + execution/ (4个子模块) |
| `utils/` (73 文件) | 工具混杂(密码学+编码+时间+基准+VRF+...) | crypto/ + infra/util/ |
| `rpc/` + `api/` (140+ 文件) | RPC与业务耦合 | interface/rpc/ |
| `net/` (34 文件) | 相对独立，但 api.h 头文件膨胀 | 保持，拆分 api.h |
| `db/` (8 文件) | 接口文件过大 | infra/store/ (拆分 db_api.h) |
| `common/` (15 文件) | 配置+创世+任务池混放 | infra/config/ + core/genesis/ |
| `mpt/` (13 文件) | 独立但SHA256需改造 | execution/mpt/ |
| `contract/` (9 文件) | 预编译合约 | execution/precompiles/ |
| `main/` (5 文件) | 过小 | app/ (合并CLI和初始化) |

---

## 七、推荐采用 Strangler Fig 模式逐步替换

### 7.1 实施策略

```
第1步: 编写行为锁定测试
  ├─ 对 algorithm.cpp/transaction.cpp/block_helper.cpp 核心函数
  ├─ 使用 GTest + RocksDB 内存模式
  └─ 输出的测试集作为"当前行为"的规范

第2步: 抽象接口层 (不修改业务逻辑)
  ├─ 提取 IStoreReader/IStoreWriter 接口
  ├─ RocksDBStore 适配现有 db_api
  ├─ 新代码使用接口，旧代码保持不变
  └─ 风险: 低 — 仅添加抽象层

第3步: 逐个模块"绞杀"
  ├─ 选择最独立的模块开始 (mpt/ → contract/ → db/ → net/)
  ├─ 新模块通过接口与旧系统交互
  ├─ 旧模块逐步废弃
  └─ 风险: 中 — 需要适配层

第4步: 拆分巨型文件
  ├─ 每个巨型文件拆为 ≤2000行 的子模块
  ├─ algorithm.cpp → consensus/ + hash/ + incentive/ + ...
  └─ 风险: 低 — 纯重构，不改行为

第5步: 替换 MagicSingleton
  ├─ 引入 Application 类管理对象生命周期
  ├─ 通过构造函数注入依赖
  └─ 风险: 高 — 大面积修改，需分阶段实施
```

### 7.2 推荐的绞杀顺序

```
阶段 A (低风险): mpt/ contract/ silkpre/ errorn/
  → 4个小模块，依赖少，可独立重构

阶段 B (中风险): db/ net/ utils/ common/
  → 基础设施层，被广泛依赖，需接口兼容

阶段 C (中风险): rpc/ api/ ca/evm/
  → 接口层+执行层，可逐步迁移到新接口

阶段 D (高风险): ca/ core/
  → 核心共识+交易处理，需完整行为测试覆盖后操作
```

---

## 八、各模块重构预估工时汇总

### 按优先级汇总

| 优先级 | 工时 | 人周 | 说明 |
|--------|------|------|------|
| P0 (Critical) | 22.5 人日 | 4.5 周 | 安全性/共识修复 |
| P1 (High) | 19 人日 | 3.8 周 | Bug修复/并发安全 |
| P2 (Medium) | 35 人日 | 7 周 | 代码结构优化 |
| P3 (Low) | 23 人日 | 4.6 周 | 性能/风格 |
| **合计** | **99.5 人日** | **~20 周** | **约 5 个月 (单人)** |

### 按模块汇总

| 模块 | P0 | P1 | P2 | P3 | 合计 |
|------|-----|-----|-----|-----|------|
| core/consensus | 1W+3d | 3d+3d | 1W+3d | — | ~4W |
| core/block | 1W | — | 1W | — | ~2W |
| core/sync | — | — | 1W | — | ~1W |
| core/txpool | 3d | — | — | — | ~3d |
| core/utxo | — | 3d | 1W | — | ~2W |
| core/governance | 1d | — | — | — | ~1d |
| execution/evm | — | 3d+3d | — | — | ~6d |
| execution/mpt | 3d | — | — | — | ~3d |
| execution/gas | — | 1d | — | 3d | ~4d |
| crypto | 1d | — | — | 3d | ~4d |
| infra/store | 1d | — | 3d | 1d | ~5d |
| infra/net | — | — | — | 1d+1d | ~2d |
| infra/config | — | 1d | — | — | ~1d |
| interface/rpc | — | — | 3d | 3d+3d+1d | ~10d |
| interface/eth | — | — | — | 3d | ~3d |
| app/cli | — | — | 3d | — | ~3d |
| app/init | — | 1d+1d | — | — | ~2d |

---

## 九、测试策略

### 9.1 行为锁定测试（重构前必须）

```
优先级最高的测试目标:
1. VRF 选择算法 → 给定种子+节点集, 验证选择结果确定性
2. UTXO 选择算法 → 给定UTXO集合+目标金额, 验证选择结果
3. 交易哈希计算 → 给定交易字段, 验证哈希一致性
4. 区块哈希计算 → 给定区块字段, 验证哈希一致性
5. MPT 根哈希计算 → 给定状态变更序列, 验证根哈希
6. 年化率计算 → 给定质押率+时间, 验证年化率数值
7. EIP1559 Gas计算 → 给定oldFee+gasCost, 验证newFee
```

### 9.2 测试基础设施

```
tests/
├── unit/                  # 单元测试
│   ├── crypto/            # 密码学测试
│   ├── store/             # 存储层测试 (RocksDB内存模式)
│   ├── mpt/               # MPT测试
│   ├── consensus/         # 共识算法测试
│   ├── utxo/              # UTXO操作测试
│   ├── gas/               # Gas计算测试
│   └── incentive/         # 激励计算测试
├── integration/           # 集成测试
│   ├── tx_flow/           # 交易全流程测试
│   ├── block_flow/        # 区块流程测试
│   └── evm/               # EVM执行测试
└── fixtures/              # 测试数据
    ├── genesis.json
    ├── keys/
    └── blocks/
```

---

## 十、实施路线图

```
第1-2周:  行为锁定测试编写 + P0 修复开始
第3-6周:  P0 修复完成 + P1 修复开始
第7-10周: P1 修复完成 + P2 巨型文件拆分开始
第11-14周: P2 拆分继续 + 目录重组
第15-18周: P2 完成 + 接口抽象层引入
第19-20周: P3 优化 + 文档更新

关键里程碑:
  Week 2: 行为测试覆盖率达到 40%
  Week 4: P0 全部修复, 共识安全达标
  Week 8: P1 全部修复, 无已知Bug
  Week 14: 无超过 2000 行的文件
  Week 18: MagicSingleton 减少到 5 个以内
  Week 20: 综合架构健康度 ≥ 7/10
```

---

## 十一、不可破坏共识清单

重构中必须保持 100% backward compatible 的规则：

| 规则 | 说明 | 变更风险 |
|------|------|---------|
| 区块哈希规则 | SHA256(Protobuf序列化 不含hash字段) | 破坏性 — 所有历史区块需重新验证 |
| 交易哈希规则 | SHA256(Protobuf序列化 不含hash字段) | 破坏性 |
| 签名规则 | ECDSA secp256k1 | 破坏性 |
| UTXO 选择规则 | FindUtxo 算法 | 影响交易打包结果 |
| 地址生成规则 | Keccak256(X\|\|Y)[12:32] EIP-55 | 破坏性 — 地址将改变 |
| 合约地址生成 | keccak256(rlp([sender, nonce]))[12:32] | 破坏性 |
| 奖励计算公式 | 年化率×委托金额÷365 | 影响所有节点经济收益 |
| 交易序列化格式 | Protobuf 字段编号/类型 | 破坏性 — 旧交易无法解析 |
| DAG 确认规则 | 共识投票逻辑 | 影响链分叉选择 |
| **MPT 根哈希** | SHA256(hex(RLP(node))) → Keccak256? | **如果修改需硬分叉** |

---

*本文档基于阶段1-3共94份分析文档综合得出。标注【推测】处需进一步验证。*
