# MeMeChain 交易生命周期 - 函数调用栈

## 文档元信息
- **项目**: MeMeChain (mm)
- **流程**: 交易从 RPC 进入 -> 验证 -> UTXO 处理 -> DAG 打包 -> EVM 执行 -> 持久化
- **日期**: 2026-05-26
- **信任度**: 高 (基于源码直接分析)

---

## 完整调用栈: 入口 -> 出口

### 路径1: 普通交易 (非合约)

```
Layer 0: RPC入口层 (HTTP工作线程, 同步)
├── HttpServer callback
│   └── [route: /SendMessage]
│       └── sendApiMessageRequest(req, res)
│           📄 api/interface/http_api.cpp:1381
│           
│           ├── VALIDATE_PARSINREQUEST (宏)
│           │   └── req_t._parseFromJson(req.body)
│           │       📄 api/interface/http_api.cpp:82 (宏定义)
│           │
│           ├── google::protobuf::util::JsonStringToMessage(req_t.txJson, &tx)
│           │   📄 api/interface/http_api.cpp:1393
│           │   [同步, 将JSON转为CTransaction protobuf]
│           │
│           ├── google::protobuf::util::JsonStringToMessage(req_t.vrfJson, &info)
│           │   📄 api/interface/http_api.cpp:1395
│           │   [同步]
│           │
│           ├── [🔒 doubleSpendMutex]
│           │   └── MagicSingleton<doubleSpendCache>::GetInstance()->AddFromAddr(...)
│           │       📄 api/interface/http_api.cpp:1416
│           │       📄 ca/double_spend_cache.cpp:7
│           │       [双花预检查: 冲突UTXO检测]
│           │
│           ├── Getsha256Hash(tx.SerializeAsString())
│           │   📄 api/interface/http_api.cpp:1425
│           │   [计算交易Hash]
│           │
│           └── SendMessage(tx, height, info, type) ──────┐
│               📄 api/interface/http_api.cpp:1427          │
│                                                           │
Layer 1: 交易构造层                                          │
│           ┌───────────────────────────────────────────────┘
│           └── SendMessage(outTx, height, info, type)
│               📄 rpc/api/post/rpc_api_post_message.cpp:17
│               签名: int SendMessage(CTransaction&, int, Vrf&, TxHelper::vrfAgentType)
│               
│               ├── Getsha256Hash(outTx.SerializeAsString())
│               │   📄 rpc/api/post/rpc_api_post_message.cpp:19
│               │
│               ├── TxMsgReq 构造 (protobuf)
│               │   📄 rpc/api/post/rpc_api_post_message.cpp:22
│               │   - set_version(GetVersion())
│               │   - set_type(0)
│               │   - set_tx(outTx.SerializeAsString())
│               │   - set_nodeheight(height)
│               │
│               ├── TxHelper::get_tx_utxo_height(outTx, txUtxoLocalHeight)
│               │   📄 rpc/api/post/rpc_api_post_message.cpp:38
│               │   📄 ca/txhelper.cpp [~5065行]
│               │   [获取UTXO所在高度]
│               │   [阻塞点: DB读取]
│               │
│               ├── MagicSingleton<AccountManager>::GetDefaultAddr()
│               │   📄 rpc/api/post/rpc_api_post_message.cpp:46
│               │   [获取本地节点地址]
│               │
│               └── DropShippingTransaction(msg, outTx, identity) ──┐
│                   📄 rpc/api/post/rpc_api_post_message.cpp:51/55   │
│                                                                     │
Layer 2: 网络发送层                                                   │
│           ┌─────────────────────────────────────────────────────────┘
│           └── DropShippingTransaction(txMsg, tx, addr)
│               📄 ca/transaction.cpp:3812
│               签名: int DropShippingTransaction(shared_ptr<TxMsgReq>&, const CTransaction&, const string&)
│               
│               ├── BuildTxPackagerSelectionProofJson(tx, ...)
│               │   📄 ca/transaction.cpp:3815
│               │   [构建VRF选择证明: EC-VRF RFC 9381]
│               │
│               ├── MagicSingleton<PeerNode>::FindNode(tx.identity(), node)
│               │   📄 ca/transaction.cpp:3827
│               │   [在节点列表中查找目标打包节点]
│               │
│               ├── [分支: 节点在线]
│               │   └── NetSendMessage<TxMsgReq>(addr, *txMsg, ...)
│               │       📄 ca/transaction.cpp:3832
│               │       net_com::Compress::COMPRESS_TRUE
│               │       net_com::Encrypt::ENCRYPT_FALSE
│               │       net_com::Priority::PRIORITY_HIGH_LEVEL_1
│               │       [通过P2P网络发送TxMsgReq]
│               │       [阻塞点: 网络IO]
│               │
│               └── [分支: 节点离线]
│                   ├── MagicSingleton<PeerNode>::GetNodelist()
│                   │   📄 ca/transaction.cpp:3838
│                   │
│                   ├── std::random_shuffle + getRandomElements(nodelist, 1)
│                   │   📄 ca/transaction.cpp:3839-3841
│                   │   [随机选择其他节点转发]
│                   │
│                   └── NetSendMessage<TxMsgReq>(randomNode, *txMsg, ...)
│                       📄 ca/transaction.cpp:3845
│
│
│ ═══════════════════ 🧵 线程切换 (网络接收线程) ═══════════════════
│
│
Layer 3: 网络接收/分发层 (网络接收线程, 异步回调)
│
├── [ProtobufDispatcher 消息分发]
│   📄 ca/interface.cpp:1853
│   └── registerCallback<TxMsgReq> -> HandleTx
│       
│       └── HandleTx(msg, msgData) ──────┐
│           📄 ca/transaction.cpp:1262    │
│           签名: int HandleTx(shared_ptr<TxMsgReq>&, const MsgData&)
│           [同步]                         │
│                                          │
│           ├── tempTx.ParseFromString(msg->txmsginfo().tx())
│           │   📄 ca/transaction.cpp:1267
│           │   [反序列化交易]
│           │
│           ├── [非目标节点检查]
│           │   └── NetSendMessage<TxMsgReq>(tx.identity(), *msg, ...)
│           │       📄 ca/transaction.cpp:1281
│           │       [转发到目标打包节点, 自身不处理]
│           │
│           └── handleTransaction(msg, tx) ──────┐
│               📄 ca/transaction.cpp:1300         │
│                                                   │
Layer 4: 交易验证层                                   │
│           ┌────────────────────────────────────────┘
│           └── handleTransaction(msg, outTx)
│               📄 ca/transaction.cpp:1375
│               签名: int handleTransaction(shared_ptr<TxMsgReq>&, CTransaction&)
│               
│               ├── Util::IsVersionCompatible(msg->version())
│               │   📄 ca/transaction.cpp:1377
│               │   [版本兼容检查]
│               │
│               ├── tx.ParseFromString(msg->txmsginfo().tx())
│               │   📄 ca/transaction.cpp:1386
│               │
│               ├── DBReader.getBlockTop(top)
│               │   📄 ca/transaction.cpp:1391
│               │   [阻塞点: RocksDB读取链顶高度]
│               │
│               ├── verifyTransactionTimeoutRequest(tx)
│               │   📄 ca/transaction.cpp:1422
│               │   📄 ca/transaction.cpp:3961 (实现)
│               │   [超时检查: 非合约tx->ktxTimeout, 合约tx->3*ktxTimeout]
│               │
│               ├── [非合约交易]
│               │   ├── verifyTxUtxoHeight(tx, txUtxoHeight)
│               │   │   📄 ca/transaction.cpp:1244 (实现)
│               │   │   📄 ca/transaction.cpp:1426 (调用)
│               │   │   [验证UTXO高度合理性]
│               │   │
│               │   └── [utxoHeight > top]
│               │       └── failedTransactionCache::Add(...)
│               │           📄 ca/transaction.cpp:1436
│               │           [UTXO高度超前: 加入重试缓存]
│               │
│               ├── checkTop(nodeHeight)
│               │   📄 ca/transaction.cpp:1468
│               │   [验证发送者报告的节点高度合理]
│               │
│               ├── 🔒 BuildTxPackagerSelectionProofJson(tx, ...)
│               │   📄 ca/transaction.cpp:1483
│               │   [构建EC-VRF选择证明]
│               │
│               ├── verifyTransactionMessageRequest(*msg)
│               │   📄 ca/transaction.cpp:1491
│               │   [完整交易验证]
│               │   ├── 签名验证 (CSign in utxo.multisign)
│               │   ├── UTXO可用性检查
│               │   ├── 余额充足性检查
│               │   └── Sequence验证
│               │   [阻塞点: 多处DB读取]
│               │
│               ├── TxHelper::addVerifySign(defaultAddr, tx)
│               │   📄 ca/transaction.cpp:1503
│               │   📄 ca/txhelper.cpp
│               │   [追加本地节点CSign到utxo.multisign]
│               │
│               ├── [VRF打包者验证]
│               │   ├── getTransactionStartIdentity(...)
│               │   │   📄 ca/transaction.cpp:1515
│               │   │
│               │   ├── VerifyBlockPackager(tx, kStageTxPostAttachCheck)
│               │   │   📄 ca/transaction.cpp:1522
│               │   │   [验证本地节点是选中打包者]
│               │   │
│               │   └── [或] ContractVerifier(tx, ...)
│               │       📄 ca/transaction.cpp:1528
│               │       [验证合约交易打包者]
│               │
│               └── 🔒 TransactionCache::AddCache(tx, msg) ──┐
│                   📄 ca/transaction.cpp:1535                │
│                                                              │
Layer 5: 交易池层                                               │
│           ┌──────────────────────────────────────────────────┘
│           └── TransactionCache::AddCache(transaction, msg)
│               📄 ca/transaction_cache.cpp:245
│               签名: int TransactionCache::AddCache(CTransaction&, shared_ptr<TxMsgReq>&)
│               
│               ├── [合约交易分支]
│               │   ├── 🔒 unique_lock<mutex> locker(contractCacheMutex)
│               │   │   📄 ca/transaction_cache.cpp:252
│               │   │
│               │   ├── Checker::CheckConflict(transaction, _contractCache)
│               │   │   📄 ca/transaction_cache.cpp:253
│               │   │   [合约池双花检测]
│               │   │
│               │   └── _contractCache.push_back({transaction, nodeHeight, false})
│               │       📄 ca/transaction_cache.cpp:258
│               │
│               └── [普通交易分支]
│                   ├── 🔒 unique_lock<mutex> locker(transactionCacheMutex)
│                   │   📄 ca/transaction_cache.cpp:261
│                   │
│                   ├── Checker::CheckConflict(transaction, _transactionCache)
│                   │   📄 ca/transaction_cache.cpp:262
│                   │   [交易池双花检测]
│                   │
│                   ├── _transactionCache.push_back({msg, transaction, utxoHeight})
│                   │   📄 ca/transaction_cache.cpp:270
│                   │
│                   └── [if size >= BUILD_THRESHOLD (1000000)]
│                       └── _blockBuilder.notify_one()
│                           📄 ca/transaction_cache.cpp:275
│                           [唤醒打包线程]
│
│
│ ═══════════════ 🧵 线程切换 (独立打包线程) ═══════════════
│
│
Layer 6: 打包线程 (detach线程, 异步)
│
├── TransactionCache::Process()
│   📄 ca/transaction_cache.cpp:282
│   └── std::thread(&TransactionCache::processTransactionCacheFunc).detach()
│       
│       └── processTransactionCacheFunc()
│           📄 ca/transaction_cache.cpp:397
│           签名: void TransactionCache::processTransactionCacheFunc()
│           循环: while(_threadRun)
│           
│           ├── 🔒 unique_lock<mutex> locker(transactionCacheMutex)
│           │   📄 ca/transaction_cache.cpp:404
│           │
│           ├── _blockBuilder.wait(locker)
│           │   📄 ca/transaction_cache.cpp:405
│           │   [阻塞点: 等待信号]
│           │   [触发: cache.size>=BUILD_THRESHOLD 或 3s定时器]
│           │
│           ├── get_build_block_height(_transactionCache)
│           │   📄 ca/transaction_cache.cpp:413
│           │   📄 ca/transaction_cache.cpp:293 (实现)
│           │   签名: int TransactionCache::get_build_block_height(vector<TransactionEntity>&)
│           │   ├── 收集所有交易UTXO高度
│           │   ├── 获取质押/委托节点及其高度
│           │   ├── 75%节点共识高度 >= max_utxo_height
│           │   └── return buildHeight
│           │   [阻塞点: DB读取获取top]
│           │
│           ├── BlockStorage::commitLookupTask(buildHeight)
│           │   📄 ca/transaction_cache.cpp:422
│           │   [提交前驱块查找任务]
│           │
│           ├── BuildBlock(buildTxs, buildHeight, false) ──────┐
│           │   📄 ca/transaction_cache.cpp:431                  │
│           │                                                     │
│           ├── [失败处理]                                         │
│           │   ├── [-103/-104/-105: continue (重试)]              │
│           │   └── [其他: _transactionCache.clear()]              │
│           │       📄 ca/transaction_cache.cpp:438                │
│           │                                                     │
│           └── [成功] _transactionCache.clear()                   │
│               └── 🔓 locker.unlock()                             │
│                                                                  │
Layer 7: 区块构造层                                                 │
│           ┌──────────────────────────────────────────────────────┘
│           └── BuildBlock(txs, blockHeight, build_first, isContractTx)
│               📄 ca/transaction_cache.cpp:173
│               签名: int BuildBlock(list<CTransaction>&, uint64_t, bool, bool)
│               
│               ├── CreateBlock(txs, blockHeight, cblock)
│               │   📄 ca/transaction_cache.cpp:83
│               │   签名: int CreateBlock(list<CTransaction>&, uint64_t, CBlock&)
│               │   ├── cblock.set_version(kCurrentBlockVersion)
│               │   ├── cblock.set_height(prevBlockHeight + 1)
│               │   ├── [循环] cblock.add_txs() -> 逐交易添加
│               │   ├── [合约交易] get_contract_info_cache(txHash, ...)
│               │   │   📄 ca/transaction_cache.cpp:106
│               │   │   [获取EVM执行后的合约存储数据]
│               │   ├── [合约交易] contractData -> blockData JSON
│               │   │   📄 ca/transaction_cache.cpp:56 (packDispatch)
│               │   └── calculateMerkleRoot -> cblock.set_hash(merkleRoot)
│               │
│               ├── cblock.SerializeAsString() -> serBlock
│               │
│               ├── BlockMsg 构造
│               │   - set_version / set_time / set_block(serBlock)
│               │
│               └── handleBlock(msg) ──────┐
│                   📄 ca/transaction_cache.cpp:211
│                   [进入Block Flow流程]
│
│ ═══════════════ 🧵 线程: 网络接收线程 (BlockMsg分发) ═══════
│
│
Layer 8: Block Flow 层
│
├── [ProtobufDispatcher block分发]
│   📄 ca/interface.cpp:1857
│   └── blockRegisterCallback<BlockMsg> -> HandleBlock
│       
│       └── HandleBlock(msg, msgData) ──────┐
│           📄 ca/transaction.cpp  [由block dispatch调用]   │
│           签名: int HandleBlock(shared_ptr<BlockMsg>&, const MsgData&)
│                                                             │
│           └── [重定向到]                                     │
│               handleBlock(msg, node) ──────┐                 │
│               📄 ca/transaction.cpp:3567    │                │
│                                               │              │
│           ┌───────────────────────────────────┘              │
│           └── handleBlock(msg, node)
│               📄 ca/transaction.cpp:3582
│               签名: int handleBlock(shared_ptr<BlockMsg>&, Node*)
│               
│               ├── Util::IsVersionCompatible(msg->version())
│               ├── cblock.ParseFromString(msg->block())
│               │
│               ├── [2签名情况: 打包者已收到验证回执]
│               │   ├── VRF::getBlockFlowSignNodes(cblock.hash(), ...)
│               │   │   [获取Block Flow签名节点]
│               │   └── BlockStorage::UpdateBlock(*msg)
│               │       [更新区块存储]
│               │
│               └── [0或1签名情况]
│                   ├── VerifyBlockSign(cblock)
│                   │   📄 ca/transaction.cpp:3515
│                   │   [验证打包者签名]
│                   │
│                   ├── AddBlockSign(cblock)
│                   │   📄 ca/transaction.cpp:3495
│                   │   [本节点签名, 追加到cblock.signature]
│                   │
│                   ├── 🔒 BlockHelper::verifyFlowedBlockStatus(cblock, ...) ──────┐
│                   │   📄 ca/block_helper.cpp:473                                   │
│                   │                                                                 │
│                   ├── [0签名: 打包者发送给验证节点]                                    │
│                   │   └── SearchNodeToSendMsg(*msg, cblock)                         │
│                   │       📄 ca/transaction.cpp:3671                                 │
│                   │       [VRF选择验证节点并发送BlockMsg]                             │
│                   │                                                                  │
│                   └── [1签名: 验证节点回传给打包者]                                    │
│                       ├── VerifyTxIdentity(cblock) [async]                           │
│                       │   📄 ca/transaction.cpp:1057                                 │
│                       │                                                              │
│                       └── NetSendMessage<BlockMsg>(packagerAddr, *msg)                │
│                           📄 ca/transaction.cpp:3778                                  │
│                                                                                       │
Layer 9: Block Flow 验证层                                                              │
│           ┌───────────────────────────────────────────────────────────────────────────┘
│           └── BlockHelper::verifyFlowedBlockStatus(block, blockStatus, msg)
│               📄 ca/block_helper.cpp:473
│               签名: int BlockHelper::verifyFlowedBlockStatus(const CBlock&, BlockStatus*, BlockMsg*)
│               
│               ├── block.version() == kCurrentBlockVersion
│               │   📄 ca/block_helper.cpp:475
│               │
│               ├── DBReadWriter.getBlockTop(nodeHeight)
│               │   📄 ca/block_helper.cpp:491
│               │   [阻塞点: DB读取]
│               │
│               ├── 高度验证: (nodeHeight-9 > blockHeight) || (nodeHeight+1 < blockHeight)
│               │   📄 ca/block_helper.cpp:495
│               │   [容忍落后9块或超前1块]
│               │
│               ├── 稳定性检查 (broadcast overtime)
│               │   📄 ca/block_helper.cpp:511
│               │   [低于chainHeight-10且超过60s: 拒绝]
│               │
│               ├── DBReadWriter.getBlockByBlockHash(blockHash, tempHeader)
│               │   📄 ca/block_helper.cpp:520
│               │   [不能已存在]
│               │
│               ├── DBReadWriter.getBlockByBlockHash(block.prevhash(), prev_header_str)
│               │   📄 ca/block_helper.cpp:535
│               │   [前驱块必须存在]
│               │
│               ├── 🔒 Checker::CheckConflict(block, double_spent_transactions)
│               │   📄 ca/block_helper.cpp:550
│               │   [块内交易双花检测]
│               │
│               └── 🔒 ca_algorithm::VerifyBlock(block, false, true, isVerify, ...)
│                   📄 ca/block_helper.cpp:565
│                   📄 ca/algorithm.cpp
│                   签名: int ca_algorithm::VerifyBlock(const CBlock&, bool, bool, bool, BlockStatus*, BlockMsg*, SaveType)
│                   ├── Merkle根验证
│                   ├── 逐交易: verifyTransactionRequest
│                   │   ├── 签名验证 (CSign multisign)
│                   │   ├── UTXO合法性 (prevOut.hash + prevOut.n)
│                   │   ├── 余额检查
│                   │   ├── Gas计算验证
│                   │   └── Sequence验证
│                   └── [合约交易] 合约前置Hash验证
│                       ├── 合约代码存在性
│                       └── 合约状态根Hash匹配
│
│
│ ═══════════════ ═══ BuildBlockBroadcastMsg 广播 ═══ ═══════════
│
│
Layer 10: 广播区块接收层
│
├── [ProtobufDispatcher saveBlock分发]
│   📄 ca/interface.cpp:1856
│   └── registerSaveBlockCallback<BuildBlockBroadcastMsg> -> handleBuildBlockBroadcastMessage
│       
│       └── handleBuildBlockBroadcastMessage(msg, msgData)
│           📄 ca/transaction.cpp:1106
│           签名: int handleBuildBlockBroadcastMessage(shared_ptr<BuildBlockBroadcastMsg>&, const MsgData&)
│           
│           ├── IsVersionCompatible
│           ├── block.ParseFromString
│           ├── 签名验证: genesis签名节点
│           ├── VerifyBlockSignatureNodeSelection [async]
│           │   📄 ca/transaction.cpp:1204
│           │   [验证VRF节点选择]
│           │
│           └── BlockHelper::AddBroadcastBlock(block, status)
│               📄 ca/block_helper.cpp:1952
│               └── 加入 _broadcastBlocks 队列
│                   └── ⤳ 触发 BlockHelper::SaveBlock
│
│ ═══════════════ ═══ BlockHelper::Process 线程 ═══ ═══════════
│
│
Layer 11: 区块持久化层 (BlockHelper线程, 异步)
│
├── BlockHelper::Process()
│   📄 ca/block_helper.cpp:1311
│   循环处理各类区块队列
│   
│   └── SaveBlock(block, SaveType::Broadcast, blockMean::Normal)
│       📄 ca/block_helper.cpp:1512 (broadcastBlocks处理)
│       
│       └── BlockHelper::SaveBlock(block, saveType, computeMeanValue)
│           📄 ca/block_helper.cpp:597
│           签名: int BlockHelper::SaveBlock(const CBlock&, SaveType, blockMean)
│           
│           ├── 🔒 DBReadWriter* dbWriterInstance = new DBReadWriter()
│           │   📄 ca/block_helper.cpp:599
│           │   [创建RocksDB事务]
│           │   [rocksdb_read_write.cpp: 内部 db_->BeginTransaction(write_options_)]
│           │   [同步, 阻塞点: 整个DB事务期间]
│           │
│           ├── dbWriterInstance->getBlockTop(nodeHeight)
│           │   📄 ca/block_helper.cpp:614
│           │
│           ├── [高度检查] block.height >= nodeHeight + 2 -> return -4
│           │   📄 ca/block_helper.cpp:620
│           │
│           ├── [已存储检查] getBlockByBlockHash -> skip
│           │   📄 ca/block_helper.cpp:626
│           │
│           ├── PreSaveProcess(block, saveType, computeMeanValue)
│           │   📄 ca/block_helper.cpp:638
│           │   📄 ca/block_helper.cpp:885 (实现)
│           │   ├── [Broadcast模式]
│           │   │   ├── verifyPreSaveBlock_(block)
│           │   │   │   📄 ca/algorithm.cpp:3923
│           │   │   │   [预保存验证]
│           │   │   │
│           │   │   ├── [逐交易] doubleSpendCheck(tx, false, ...)
│           │   │   │   📄 ca/algorithm.cpp:73 (声明)
│           │   │   │   [跨区块双花检测]
│           │   │   │
│           │   │   └── [双花处理] dealDoubleSpend(block, tx, missingUtxo)
│           │   │       ├── isDoubleSpend -> return -7
│           │   │       ├── previousDoubleSpend -> continue (跳过)
│           │   │       └── isInvalidDoubleSpend -> return -8
│           │   │
│           │   └── [Sync模式] ca_algorithm::VerifyBlock(true, false, true, ...)
│           │
│           ├── 🔒 ca_algorithm::SaveBlock(*dbWriterInstance, block, saveType, ...) ──────┐
│           │   📄 ca/block_helper.cpp:646                                                │
│           │                                                                              │
│           ├── 🔒 dbWriterInstance->transactionCommit()                                   │
│           │   📄 ca/block_helper.cpp:664                                                 │
│           │   📄 db/rocksdb_read_write.cpp:30                                            │
│           │   [🗄️ RocksDB txn_->Commit() - 原子提交]                                     │
│           │                                                                              │
│           ├── doubleSpendCache::Detection(block)                                          │
│           │   📄 ca/block_helper.cpp:680                                                  │
│           │   📄 ca/double_spend_cache.cpp:78                                             │
│           │   [🔒 doubleSpendMutex, 清理pending缓存]                                      │
│           │                                                                               │
│           ├── ResendReconnectNode::RemoveResendBlock(block.hash())                         │
│           │   📄 ca/block_helper.cpp:681                                                   │
│           │                                                                                │
│           └── PostSaveProcess(block)                                                       │
│               📄 ca/block_helper.cpp:685                                                    │
│               📄 ca/block_helper.cpp:1007 (实现)                                             │
│               ├── processPostTransaction(block) [通过TaskPool异步]                           │
│               │   📄 ca/block_helper.cpp:991                                                 │
│               │   ├── contractBlockNotification(block.hash())                                │
│               │   │   📄 ca/transaction_cache.cpp:870                                        │
│               │   │   [通知合约块已确认]                                                      │
│               │   │
│               │   ├── PeerNode::SetSelfHeight(block.height())                                 │
│               │   │   [更新本地节点高度]                                                      │
│               │   │
│               │   └── BlockHttpCallbackHandler::AddBlock(block)                               │
│               │       [HTTP回调通知]                                                          │
│               │
│               └── _pendingBlocks处理 + contractBlocks检查                                     │
│                   📄 ca/block_helper.cpp:1013-1060                                            │
│                                                                                               │
Layer 12: 核心持久化层 (ca_algorithm::SaveBlock)                                                │
│           ┌──────────────────────────────────────────────────────────────────────────────────┘
│           └── ca_algorithm::SaveBlock(dbWriter, block, saveType, computeMeanValue)
│               📄 ca/algorithm.cpp:3986
│               签名: int ca_algorithm::SaveBlock(DBReadWriter&, const CBlock&, SaveType, blockMean)
│               [🗄️ 所有DB写入在同一个RocksDB Transaction内]
│               
│               ├── [已缓存检查] getBlockByBlockHash(block.hash(), blockRaw)
│               │   ├── DBStatus::DB_SUCCESS -> skip (已缓存)
│               │   └── DBStatus::DB_NOT_FOUND -> 继续
│               │
│               ├── [前驱块检查] getBlockByBlockHash(block.prevhash(), preBlockRaw)
│               │   └── 不存在 -> set_missing_prehash() -> return -2
│               │
│               ├── [高度更新] getBlockTop -> setBlockTop(block.height())
│               │   📄 ca/algorithm.cpp:4019-4027
│               │
│               ├── [Hash映射] setBlockHeightByBlockHash + setBlockHashByBlockHeight
│               │   📄 ca/algorithm.cpp:4032-4040
│               │
│               ├── [区块数据] setBlockByBlockHash(block.hash(), block.SerializeAsString())
│               │   📄 ca/algorithm.cpp:4045
│               │
│               ├── [签名统计] setSignAddrByPeriod + setSignCountByPeriod
│               │   📄 ca/algorithm.cpp:4048-4075
│               │
│               ├── [打包统计] setBlockNumberByPeriod + setPackagerCountByPeriod
│               │   📄 ca/algorithm.cpp:4078-4101
│               │
│               ├── 🔒 [逐交易处理] for each tx in block.txs():
│               │   │
│               │   ├── [Nonce] setNonceByAddr(owner, nonce+1)
│               │   │   📄 ca/algorithm.cpp:4150-4163
│               │   │
│               │   ├── [交易类型分发]
│               │   │   ├── STAKE: setStakeUtxoByAddr + setStakeAddr
│               │   │   ├── UNSTAKE: removeStakeUtxo
│               │   │   ├── DELEGATE: setDelegatingUtxo
│               │   │   ├── UNDELEGATE: removeDelegatingUtxo
│               │   │   ├── LOCK/UNLOCK: lock/unlock处理
│               │   │   └── BONUS/FUND: 特殊余额处理
│               │   │
│               │   ├── [Vin处理: UTXO花费]
│               │   │   📄 ca/algorithm.cpp:5070-5170
│               │   │   ├── [逐UTXO] readForUpdate(utxoKey + balanceKey)
│               │   │   ├── 验证余额充足
│               │   │   ├── removeUtxoHashesByAddr / setUtxoHashsByAddr
│               │   │   │   [标记UTXO为已花费]
│               │   │   └── setBalanceByAddr(addr, currency, balance - amount)
│               │   │       [更新余额(减)]
│               │   │
│               │   ├── [Vout处理: UTXO创建]
│               │   │   📄 ca/algorithm.cpp:5170-5340
│               │   │   ├── [Burn地址] setBurnAmountByPeriod + setTotalBurnAmount
│               │   │   │   [🔒 global::ca::BURN_MUTEX]
│               │   │   │
│               │   │   ├── [普通地址] setUtxoHashesByAddr + setUtxoValueByUtxoHashes
│               │   │   │   [创建新UTXO记录]
│               │   │   │
│               │   │   └── setBalanceByAddr(addr, currency, balance + amount)
│               │   │       [更新余额(加)]
│               │   │
│               │   └── [合约交易: DEPLOY/CALL]
│               │       📄 ca/algorithm.cpp:5490-5650
│               │       ├── Evmone::SaveContract(deployer, hash, addr, code, dbWriter)
│               │       │   📄 ca/evm/evm_manager.cpp
│               │       │   [保存合约字节码到DB]
│               │       │
│               │       ├── setLatestUtxoByContractAddr(addr, txHash)
│               │       │   [更新合约前置Hash]
│               │       │
│               │       ├── removeContractDeployUtxoByContractAddr (如有)
│               │       │   removeContractCodeByContractAddr (如有)
│               │       │   [合约销毁]
│               │       │
│               │       └── setMptValueByMptKey(key, value)
│               │           [MPT状态Trie更新]
│               │
│               └── calculateHeightsSumHash(block.height(), dbWriter)
│                   📄 ca/algorithm.cpp:5764
│                   [更新累加Merkle哈希]
│
│── [返回 BlockHelper::SaveBlock]
│
│── [RocksDB Commit]
│   📄 ca/block_helper.cpp:664
│   📄 db/rocksdb_read_write.cpp:30
│   └── txn_->Commit()
│       [🗄️ 原子提交所有DB变更]
│
│── [失败处理]
│   ├── ON_SCOPE_EXIT: delete dbWriterInstance
│   ├── 未commit的事务自动丢弃
│   └── 触发同步: SyncBlock::set_new_sync_height
│
└── ✅ 交易生命周期完成
```

---

## 路径2: 合约交易 (CALL/DEPLOY)

合约交易与普通交易在主流程上大部分共享，关键差异点如下:

```
[Layer 0] HTTP入口
└── sendMessageRequest(req, res)  [非 sendApiMessageRequest]
    📄 api/interface/http_api.cpp:1510
    ├── 解析 contractJs -> ContractTxMsgReq (包含合约参数/ABI/deployer/args)
    ├── 解析 txJson -> CTransaction
    └── [双花检查, 同上]
        └── dropCallShippingRequest(msg, tx)  [非 SendMessage]
            📄 ca/transaction.cpp:1597
            └── dropCallShippingRequest(Msg, tx)
                📄 ca/transaction.cpp:3858
                
                ├── [本地节点处理] contractTransactionRequest(Msg, msgData)
                │   📄 ca/transaction.cpp:3870
                │   ├── IsVersionCompatible
                │   ├── ParseFromString -> contractTx
                │   ├── ContractVerifier(tx, ...)
                │   │   📄 ca/transaction.cpp:1539
                │   │   └── calculatePackerByTime(tx.time()) [基于时间VRF]
                │   ├── TxHelper::addVerifySign(defaultAddr, contractTx)
                │   ├── 提取依赖地址 (contractstoragelist)
                │   └── ContractDispatcher::AddContractRequest(hash, deps, *msg)
                │       └── 进入合约依赖管理队列
                │
                └── [远程节点] NetSendMessage<ContractTxMsgReq>(targetAddr, *Msg, ...)

[Layer 3] 网络接收: contractTransactionRequest (非HandleTx)
    📄 ca/transaction.cpp:1308
    ├── ...验证同上...
    └── ContractDispatcher::AddContractRequest(...) [入合约队列]

[Layer 7] 区块构造: CreateBlock
    合约交易额外处理:
    ├── get_contract_info_cache(txHash, txStorage) [EVM执行结果]
    │   📄 ca/transaction_cache.cpp:106
    ├── contractData -> blockData JSON [合约存储数据]
    └── 依赖排序: packDispatch.GetDependentData()

[Layer 12] SaveBlock: 合约持久化
    ├── Evmone::SaveContract [保存合约代码]
    ├── setLatestUtxoByContractAddr [合约前置Hash]
    ├── setMptValueByMptKey [状态Trie更新]
    └── EventManager::Publish("TransactionConfirmed") [通知]
```

---

## 路径3: 查询类交易 (GetBalance/GetBlock等)

```
Layer 0: HTTP入口
├── apiJsonRpcRequest [通用JSON-RPC转发]
│   📄 api/interface/http_api.cpp:319
│   └── 读取JSON-RPC method字段, 转发到对应处理器
│
├── _GetBalance(req, res)
│   📄 api/interface/http_api.cpp:988
│   ├── DBReader.getBalanceByAddr(addr, currency, balance)
│   └── 返回JSON响应
│   [同步, 仅DB读取]
│
├── getTransactionInfo / get_transaction_info
│   📄 api/interface/http_api.cpp:360/1193
│   └── DBReader查找 + 格式化输出
│
└── _ConfirmTransaction(req, res)
    📄 api/interface/http_api.cpp:862
    └── sendConfirmationTransactionRequest -> 全网确认

- 查询路径: [同步, HTTP线程完成]
- 不经过TransactionCache/BlockFlow
- 不涉及写事务
```

---

## 关键同步/异步标注

| 函数 | 同步/异步 | 说明 |
|------|-----------|------|
| sendApiMessageRequest | **同步** | HTTP回调内同步执行 |
| SendMessage | **同步** | 同步构造并发送 |
| DropShippingTransaction | **同步** | 同步网络IO |
| HandleTx (回调) | **异步** | ProtobufDispatcher异步回调 |
| TransactionCache::AddCache | **同步** | 加锁同步操作 |
| buildTimer (定时器) | **异步** | AsyncLoop callback触发 |
| processTransactionCacheFunc | **异步** | 独立detach线程 |
| handleBlock (回调) | **异步** | ProtobufDispatcher分发 |
| handleBuildBlockBroadcastMessage | **异步** | saveBlock回调分发 |
| SaveBlock | **同步** | 长阻塞DB事务 |
| VerifyTxIdentity | **async** | std::async(std::launch::async) |
| processPostTransaction | **异步** | TaskPool异步任务 |
| 20 | 异步 | 格式匹配情况 |
| DBReader 读操作 | **同步** | 阻塞直到返回 |
| DBReadWriter 写操作 | **同步** | RocksDB txn->Put/Get/Delete |

---

## 异常传播路径

```
Level 0: HTTP入口
  ├── JSON解析失败 -> 直接返回HTTP 200 + error code
  │   [不进入后续流程]
  
Level 1-2: 网络发送
  ├── SendMessage失败 -> DropShippingTransaction失败
  │   -> 返回给sendApiMessageRequest
  │   -> 设置ack_t.code = error code
  │   -> HTTP返回客户端
  
Level 3-4: 网络接收验证  
  ├── HandleTx失败 -> handleTransaction失败
  │   -> 返回给ProtobufDispatcher (丢弃消息)
  │   [不返回给原始客户端, P2P消息无响应通道]
  
Level 5-6: 交易池/打包
  ├── AddCache冲突 -> 静默丢弃
  ├── BuildBlock失败 -> _transactionCache.clear() + continue
  │   [-103/-104/-105: 不清理池, 重试]
  
Level 7-8: Block Flow
  ├── handleBlock失败 -> 返回错误码
  │   -> 发送BlockStatus消息通知打包者
  ├── VerifyBlockSign失败 -> 返回-6
  ├── verifyFlowedBlockStatus失败 -> 返回-7
  
Level 9-12: 持久化
  ├── PreSaveProcess失败 -> 不上报给原始交易者
  │   -> 仅在日志记录
  ├── ca_algorithm::SaveBlock失败
  │   -> RocksDB Transaction未commit (自动丢弃)
  │   -> 触发同步: SyncBlock::set_new_sync_height
  ├── transactionCommit失败 -> 返回-9
  │   -> dbWriterInstance析构 (事务已创建但未commit)

┌──────────────────────────────────────────┐
│ 注意: P2P消息处理没有请求-响应模型        │
│ 交易失败时客户端不会自动收到通知          │
│ 客户端需要通过 /ConfirmTransaction 轮询   │
└──────────────────────────────────────────┘
```

---

## 信任度评估

| 调用栈层级 | 信任度 | 依据 |
|-----------|--------|------|
| Layer 0-1 (RPC入口) | 高 | 直接源码阅读 |
| Layer 2 (网络发送) | 高 | 直接源码阅读 |
| Layer 3-4 (接收验证) | 高 | 直接源码阅读 |
| Layer 5 (交易池) | 高 | 直接源码阅读 |
| Layer 6-7 (打包) | 高 | 直接源码阅读 |
| Layer 8-9 (Block Flow) | 高 | 直接源码阅读 |
| Layer 10-11 (广播持久化) | 高 | 直接源码阅读 |
| Layer 12 (SaveBlock) | 高 | 直接源码阅读 algorithm.cpp |
| EVMManager 细节 | 中 | 部分逻辑未深入阅读 |
| VRF/EC-VRF | 中 | 内联汇编部分未分析 |
| DependencyManager | 中 | 部分代码注释掉【需人工验证】 |
