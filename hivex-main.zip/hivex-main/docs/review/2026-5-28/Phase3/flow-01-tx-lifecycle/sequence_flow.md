# MeMeChain 交易生命周期 - 时序图

## 文档元信息
- **项目**: MeMeChain (mm)
- **流程**: 交易从 RPC 进入 -> 验证 -> UTXO 处理 -> DAG 打包 -> EVM 执行 -> 持久化
- **日期**: 2026-05-26
- **信任度**: 高 (基于源码直接分析)

---

## 一、完整 Mermaid 时序图

```mermaid
sequenceDiagram
    autonumber
    participant Client as 外部客户端
    participant HTTP as HttpServer<br/>(http_api.cpp)
    participant DS as DoubleSpendCache<br/>(double_spend_cache.cpp)
    participant Net as NetSendMessage<br/>(P2P网络层)
    participant HandleTx as HandleTx<br/>(transaction.cpp:1262)
    participant Cache as TransactionCache<br/>(transaction_cache.cpp)
    participant BuildThr as BuildThread<br/>(processTransactionCacheFunc)
    participant BlockH as BlockHelper<br/>(block_helper.cpp)
    participant Algo as ca_algorithm<br/>(algorithm.cpp)
    participant EVMMgr as EVMManager<br/>(evm_manager.cpp)
    participant DB as RocksDBReadWriter<br/>(rocksdb_read_write.cpp)

    %% ===================== 阶段1: RPC 接收 =====================
    Note over Client,DB: ═══ 阶段1: RPC 接收与初步验证 ═══

    Client->>HTTP: POST /SendMessage (JSON)
    Note right of HTTP: [HTTP工作线程] 同步

    HTTP->>HTTP: VALIDATE_PARSINREQUEST<br/>JsonStringToMessage -> CTransaction+Vrf
    Note right of HTTP: http_api.cpp:1381-1396

    HTTP->>DS: 🔒 MUTEX: doubleSpendMutex.lock()
    HTTP->>DS: AddFromAddr(fromaddr, usedUtxos)
    Note right of DS: double_spend_cache.cpp:7<br/>检查是否存在冲突UTXO
    alt UTXO冲突
        DS-->>HTTP: -1 (UTXO is using)
        HTTP-->>Client: {"code":-16, "message":"utxo is using!"}
        Note right of Client: 流程终止
    end
    HTTP->>DS: 🔓 doubleSpendMutex.unlock()

    HTTP->>HTTP: Getsha256Hash(tx) -> txHash
    Note right of HTTP: http_api.cpp:1425

    %% ===================== 阶段2: 交易发送 =====================
    Note over HTTP,Net: ═══ 阶段2: 网络发送 ═══

    HTTP->>HTTP: SendMessage(tx, height, info, type)
    Note right of HTTP: rpc_api_post_message.cpp:17

    HTTP->>HTTP: TxHelper::get_tx_utxo_height(tx)
    Note right of HTTP: 获取UTXO所在高度

    HTTP->>HTTP: BuildTxPackagerSelectionProofJson
    Note right of HTTP: transaction.cpp:3793<br/>构建VRF选择证明

    HTTP->>Net: NetSendMessage<TxMsgReq>(targetAddr, msg)
    Note right of Net: [同一HTTP线程]<br/>P2P网络发送<br/>Compress:COMPRESS_TRUE<br/>Encrypt:ENCRYPT_FALSE<br/>Priority:PRIORITY_HIGH_LEVEL_1

    %% ===================== 阶段3: 网络接收 =====================
    Note over Net,Cache: ═══ 阶段3: 网络接收 🧵线程切换 ═══

    Net->>HandleTx: 🧵 [网络接收线程] HandleTx(msg, msgData)
    Note right of HandleTx: transaction.cpp:1262<br/>ProtobufDispatcher dispatch

    HandleTx->>HandleTx: ParseFromString(txmsginfo.tx()) -> CTransaction
    Note right of HandleTx: 反序列化交易

    alt 不是目标打包节点
        HandleTx->>Net: 转发TxMsgReq到目标节点
        Note right of HandleTx: transaction.cpp:1283<br/>流程终止
    end

    HandleTx->>HandleTx: handleTransaction(msg, tx)
    Note right of HandleTx: transaction.cpp:1375

    %% ===================== 阶段4: 交易验证 =====================
    Note over HandleTx,Algo: ═══ 阶段4: 交易验证 ═══

    HandleTx->>HandleTx: Util::IsVersionCompatible(msg->version())
    Note right of HandleTx: 版本兼容性检查

    HandleTx->>DB: dbReader.getBlockTop(top)
    Note right of DB: DB读: 获取当前链顶高度

    HandleTx->>HandleTx: verifyTransactionTimeoutRequest(tx)
    Note right of HandleTx: transaction.cpp:3961<br/>超时检查 (普通Tx: ktxTimeout, 合约: 3*ktxTimeout)

    alt 非合约/非FUND交易
        HandleTx->>HandleTx: verifyTxUtxoHeight(tx, txUtxoHeight)
        Note right of HandleTx: transaction.cpp:1244<br/>验证UTXO高度合理性
    end

    HandleTx->>HandleTx: 🔒 checkTop(nodeHeight)
    Note right of HandleTx: 验证发送者高度合理

    HandleTx->>HandleTx: BuildTxPackagerSelectionProofJson
    Note right of HandleTx: 构建VRF选择证明

    HandleTx->>HandleTx: verifyTransactionMessageRequest(*msg)
    Note right of HandleTx: 完整交易验证<br/>- 签名验证<br/>- UTXO可用性<br/>- 余额充足性

    HandleTx->>HandleTx: TxHelper::addVerifySign(defaultAddr, tx)
    Note right of HandleTx: 追加本地节点验证签名(CSign)

    HandleTx->>HandleTx: 🔒 getTransactionStartIdentity
    Note right of HandleTx: 获取交易发起身份类型

    alt VRF模式
        HandleTx->>HandleTx: VerifyBlockPackager(tx)
        Note right of HandleTx: transaction.cpp<br/>验证本地节点是否为选中的打包者
        alt 验证失败
            HandleTx-->>Net: return -13 (not issuer node)
        end
    end

    %% ===================== 阶段5: 交易入池 =====================
    Note over HandleTx,Cache: ═══ 阶段5: 交易入池 ═══

    HandleTx->>Cache: 🔒 MUTEX: transactionCacheMutex.lock()
    HandleTx->>Cache: AddCache(tx, msg)
    Note right of Cache: transaction_cache.cpp:245

    alt 合约交易 (CALL/DEPLOY)
        Cache->>Cache: 🔒 MUTEX: contractCacheMutex.lock()
        Cache->>Cache: Checker::CheckConflict(tx, _contractCache)
        Note right of Cache: 双花检测
        Cache->>Cache: _contractCache.push_back({tx, ...})
        Cache->>Cache: 🔓 contractCacheMutex.unlock()
    else 普通交易
        Cache->>Cache: Checker::CheckConflict(tx, _transactionCache)
        Cache->>Cache: _transactionCache.push_back({msg, tx, utxoHeight})
        Cache->>Cache: 🔓 transactionCacheMutex.unlock()
        alt cache.size >= BUILD_THRESHOLD
            Cache->>BuildThr: 🧵 _blockBuilder.notify_one()
            Note right of Cache: 唤醒打包线程
        end
    end

    HandleTx-->>Net: return 0 (success)

    %% ===================== 阶段6: 区块打包 =====================
    Note over BuildThr,Algo: ═══ 阶段6: 区块打包 🧵独立线程 ═══

    Note right of BuildThr: processTransactionCacheFunc<br/>transaction_cache.cpp:397<br/>detach 线程

    BuildThr->>BuildThr: 🔒 MUTEX: transactionCacheMutex.lock()
    BuildThr->>BuildThr: _blockBuilder.wait(locker)
    Note right of BuildThr: 等待信号(3s定时器或阈值触发)

    BuildThr->>BuildThr: get_build_block_height(_transactionCache)
    Note right of BuildThr: transaction_cache.cpp:293<br/>计算打包高度(75%节点共识)

    BuildThr->>BuildThr: BuildBlock(buildTxs, buildHeight, false)
    Note right of BuildThr: transaction_cache.cpp:173

    BuildThr->>BuildThr: CreateBlock(txs, blockHeight, cblock)
    Note right of BuildThr: transaction_cache.cpp:83<br/>组装CBlock protobuf<br/>- 设置version, height, prevhash<br/>- 添加所有tx<br/>- 计算合约存储信息<br/>- 生成merkle根

    BuildThr->>BuildThr: 🔓 transactionCacheMutex.unlock()

    BuildThr->>Net: handleBlock(blockMsg)
    Note right of Net: transaction_cache.cpp:211<br/>进入Block Flow流程

    %% ===================== 阶段7: Block Flow 签名与验证 =====================
    Note over BuildThr,Algo: ═══ 阶段7: Block Flow 多签验证 ═══

    activate Net
    Net->>Net: handleBlock(msg) [BlockMsg处理器]
    Note right of Net: transaction.cpp:3582

    Net->>Net: IsVersionCompatible
    Net->>Net: ParseFromString -> CBlock
    Net->>Net: VerifyBlockSign(cblock)
    Note right of Net: transaction.cpp:3515<br/>验证打包者签名

    Net->>Net: AddBlockSign(cblock)
    Note right of Net: transaction.cpp:3495<br/>添加本节点签名

    Net->>BlockH: verifyFlowedBlockStatus(cblock, ...)
    Note right of BlockH: block_helper.cpp:473

    BlockH->>BlockH: 检查区块版本 kCurrentBlockVersion
    BlockH->>DB: getBlockTop(nodeHeight)
    BlockH->>BlockH: 验证高度 (nodeHeight-9 <= blockHeight <= nodeHeight+1)
    BlockH->>DB: getBlockByBlockHash(blockHash) -> 不存在
    BlockH->>DB: getBlockByBlockHash(prevHash) -> 必须存在
    BlockH->>BlockH: Checker::CheckConflict(block, ...)
    Note right of BlockH: 块内交易双花检测
    BlockH->>Algo: ca_algorithm::VerifyBlock(block, false, true, isVerify)
    Note right of Algo: 完整区块验证<br/>- 所有交易签名<br/>- UTXO合法性<br/>- 余额检查

    alt signCount == 0 (打包者)
        Net->>Net: SearchNodeToSendMsg(msg, cblock)
        Note right of Net: VRF选择验证节点并发送
        Net->>Net: BlockStorage::AddBlock(msg)
    else signCount == 1 (验证者)
        Net->>Net: VerifyTxIdentity(cblock) [async]
        Net->>Net: VerifyBlockSignatureNodeSelection
        Note right of Net: 验证VRF节点选择合法性
        Net->>Net: 回传签名的BlockMsg给打包者
    else signCount == 2 (完成)
        Net->>Net: BlockStorage::UpdateBlock(msg)
    end
    deactivate Net

    %% ===================== 阶段8: 区块广播 =====================
    Note over BuildThr,DB: ═══ 阶段8: 区块广播与持久化 ═══

    Net->>Net: 🧵 [广播接收线程] handleBuildBlockBroadcastMessage
    Note right of Net: transaction.cpp:1106

    Net->>BlockH: BlockHelper::AddBroadcastBlock(block)
    Note right of BlockH: block_helper.cpp:1952<br/>加入广播区块队列

    Net->>BlockH: BlockHelper::SaveBlock(block, Broadcast, Normal)
    Note right of BlockH: block_helper.cpp:597

    BlockH->>DB: 🔒 RocksDBReadWriter 创建 (new)
    Note right of DB: rocksdb_read_write.cpp<br/>创建DB事务对象

    BlockH->>DB: 🔒 getBlockByBlockHash (检查是否已存储)
    alt 已存储
        BlockH->>DB: skip (已保存)
    end

    BlockH->>BlockH: PreSaveProcess(block, Broadcast, Normal)
    Note right of BlockH: block_helper.cpp:885

    alt Broadcast模式
        BlockH->>Algo: verifyPreSaveBlock_(block)
        BlockH->>Algo: doubleSpendCheck(tx, false) [per tx]
        Note right of Algo: 跨区块双花检测
        alt 双花检测失败
            BlockH-->>Net: return -7 ~ -9
            BlockH->>DB: 🔓 清理ReadWriter (不commit)
        end
    end

    %% ===================== 阶段9: 数据库写入 =====================
    Note over BlockH,DB: ═══ 阶段9: 数据库原子写入 (RocksDB Transaction) ═══

    BlockH->>Algo: 🔒 ca_algorithm::SaveBlock(dbWriter, block, ...)
    Note right of Algo: algorithm.cpp:3986<br/>🗄️ 以下所有DB写入在同一个RocksDB Transaction内

    Algo->>DB: check block not cached
    Algo->>DB: getBlockByBlockHash(prevhash) -> 必须存在
    Note right of DB: 确保前驱块已持久化

    Algo->>DB: ✏️ setBlockTop(height)
    Note right of DB: DB写入点1: 更新链顶高度

    Algo->>DB: ✏️ setBlockHeightByBlockHash(hash, height)
    Note right of DB: DB写入点2: Hash->高度映射

    Algo->>DB: ✏️ setBlockHashByBlockHeight(height, hash)
    Note right of DB: DB写入点3: 高度->Hash映射

    Algo->>DB: ✏️ setBlockByBlockHash(hash, serializedBlock)
    Note right of DB: DB写入点4: 区块数据存储

    Algo->>DB: ✏️ setSignAddrByPeriod / setSignCountByPeriod
    Note right of DB: DB写入点5: 签名者统计

    Algo->>DB: ✏️ setBlockNumberByPeriod / setPackagerCountByPeriod
    Note right of DB: DB写入点6: 打包者统计

    loop 每个交易 (for block.txs())
        Algo->>DB: ✏️ setNonceByAddr(owner, nonce+1)
        Note right of DB: DB写入点7: 更新nonce

        loop 每个UTXO - Vin (花费)
            Algo->>DB: 🔒 readForUpdate(balanceKey)
            Algo->>DB: ✏️ setUtxoHashsByAddress(vin.addr, currency, txHash) [remove]
            Note right of DB: DB写入点8: 标记UTXO为已花费
            Algo->>DB: ✏️ setBalanceByAddr(addr, currency, newBalance)
            Note right of DB: DB写入点9: 更新余额(减)
        end

        loop 每个UTXO - Vout (产出)
            alt 合约Gas/Burn地址
                Algo->>DB: ✏️ setBurnAmountByPeriod / setTotalBurnAmount
                Note right of DB: DB写入点10: Burn统计
            else 普通收款地址
                Algo->>DB: ✏️ setUtxoHashesByAddr(addr, currency, txHash)
                Note right of DB: DB写入点11: 创建新UTXO
                Algo->>DB: ✏️ setBalanceByAddr(addr, currency, newBalance)
                Note right of DB: DB写入点12: 更新余额(加)
            end
        end

        opt 合约交易 (DEPLOY/CALL)
            Algo->>EVMMgr: Evmone::SaveContract(deployer, hash, addr, code, dbWriter)
            Note right of EVMMgr: 保存合约代码到DB
            Algo->>DB: ✏️ setLatestUtxoByContractAddr(addr, txHash)
            Note right of DB: DB写入点13: 合约状态更新
            Algo->>DB: ✏️ setMptValueByMptKey(key, value)
            Note right of DB: DB写入点14: MPT存储更新
            Algo->>DB: ✏️ removeContractCodeByContractAddr (如有销毁)
            Note right of DB: DB写入点15: 合约销毁
        end
    end

    Algo->>Algo: calculateHeightsSumHash(block.height, dbWriter)
    Note right of Algo: 更新Merkle累加哈希

    Algo-->>BlockH: return 0

    BlockH->>DB: 🔓 🔒 transactionCommit()
    Note right of DB: rocksdb_read_write.cpp:30<br/>🗄️ RocksDB txn_->Commit()<br/>原子提交所有变更

    alt Commit失败
        BlockH->>DB: transactionRollBack()
        Note right of DB: 回滚所有变更
        BlockH-->>Net: return -9 (commit fail)
    end

    %% ===================== 阶段10: 提交后处理 =====================
    Note over BlockH,DS: ═══ 阶段10: 提交后清理 ═══

    BlockH->>DS: 🔒 MUTEX: doubleSpendMutex.lock()
    BlockH->>DS: Detection(block)
    Note right of DS: double_spend_cache.cpp:78<br/>从pending中移除已确认交易
    BlockH->>DS: 🔓 doubleSpendMutex.unlock()

    BlockH->>BlockH: PostSaveProcess(block)
    Note right of BlockH: block_helper.cpp:1007

    BlockH->>BlockH: 🧵 TaskPool::commitCaTask(processPostTransaction)
    Note right of BlockH: 异步: 合约通知+HTTP回调

    BlockH->>BlockH: _pendingBlocks处理
    Note right of BlockH: 处理等待前驱块的区块

    BlockH->>DB: delete dbWriterInstance
    Note right of DB: 析构RocksDBReadWriter

    Note over Client,DB: ✅ 交易生命周期完成
```

---

## 二、线程切换标注

| 位置 | 线程 | 说明 |
|------|------|------|
| HTTP回调 `sendApiMessageRequest` | **HTTP工作线程** | httplib 线程池 |
| `NetSendMessage` | **HTTP工作线程** (同步) | 在当前HTTP线程中完成P2P发送 |
| `HandleTx` 回调 | **网络接收线程** | ProtobufDispatcher 线程池 |
| `processTransactionCacheFunc` | **独立detach线程** | TransactionCache::Process() 启动 |
| `handleBlock` 回调 | **网络接收线程** | ProtobufDispatcher block线程 |
| `handleBuildBlockBroadcastMessage` | **网络接收线程** | ProtobufDispatcher saveBlock线程 |
| `processPostTransaction` | **TaskPool线程** | 异步任务 |

---

## 三、锁获取/释放标注

| 锁 | 持有位置 | 保护范围 | 文件:行号 |
|----|---------|---------|-----------|
| `doubleSpendMutex` | `doubleSpendCache::AddFromAddr` | 双花缓存写入 | double_spend_cache.cpp:7 |
| `doubleSpendMutex` | `doubleSpendCache::Detection` | 双花缓存清理 | double_spend_cache.cpp:78 |
| `doubleSpendMutex` | `doubleSpendCache::CheckLoop` | 定时清理过期项 | double_spend_cache.cpp:55 |
| `transactionCacheMutex` | `TransactionCache::AddCache` (普通交易) | 交易池写入 | transaction_cache.cpp:261 |
| `transactionCacheMutex` | `processTransactionCacheFunc` | 交易池读取+处理 | transaction_cache.cpp:404 |
| `contractCacheMutex` | `TransactionCache::AddCache` (合约交易) | 合约交易池写入 | transaction_cache.cpp:252 |
| RocksDB Transaction | `ca_algorithm::SaveBlock` | 整个区块持久化 | algorithm.cpp:3986-5763 |
| `global::ca::BURN_MUTEX` | `ca_algorithm::SaveBlock` (Burn段) | Burn统计更新 | algorithm.cpp:5171 |

**锁获取顺序 (从入口到持久化):**
1. `doubleSpendMutex` (AddFromAddr)
2. `transactionCacheMutex` / `contractCacheMutex` (AddCache)
3. RocksDB Transaction (SaveBlock)
4. `BURN_MUTEX` (SaveBlock 内 Burn)
5. `doubleSpendMutex` (Detection)

这些锁在不同阶段获取，没有形成交叉获取环路 => **死锁风险: 低** (信任度: 中)

---

## 四、数据库写入点汇总

| ID | 操作 | 文件:行号 | 说明 |
|----|------|-----------|------|
| W1 | `setBlockTop` | algorithm.cpp:4025 | 更新链顶高度 |
| W2 | `setBlockHeightByBlockHash` | algorithm.cpp:4032 | Hash->高度 |
| W3 | `setBlockHashByBlockHeight` | algorithm.cpp:4038 | 高度->Hash |
| W4 | `setBlockByBlockHash` | algorithm.cpp:4045 | 区块序列化数据 |
| W5 | `setSignAddrByPeriod/Count` | algorithm.cpp:4058-4072 | 签名者统计 |
| W6 | `setBlockNumberByPeriod/PackagerCount` | algorithm.cpp:4083-4097 | 打包者统计 |
| W7 | `setNonceByAddr` | algorithm.cpp:4161 | Nonce更新 |
| W8 | 标记UTXO已花费 (remove/set) | algorithm.cpp:5130-5163 | 花费UTXO |
| W9 | `setBalanceByAddr` (减) | algorithm.cpp:5143-5165 | 余额更新 |
| W10 | `setBurnAmountByPeriod/Total` | algorithm.cpp:5180-5195 | Burn统计 |
| W11 | `setUtxoHashesByAddr` (产出) | algorithm.cpp:5230 | 新UTXO创建 |
| W12 | `setBalanceByAddr` (加) | algorithm.cpp:5310 | 余额增加 |
| W13 | `setLatestUtxoByContractAddr` | algorithm.cpp:5545 | 合约前置Hash |
| W14 | `setMptValueByMptKey` | algorithm.cpp:5565 | MPT状态Trie |
| W15 | `removeContractCodeByContractAddr` | algorithm.cpp:5572 | 合约销毁 |

---
## 五、网络广播点

| 位置 | 消息类型 | 文件:行号 | 说明 |
|------|---------|-----------|------|
| `sendApiMessageRequest` | `NetSendMessage<TxMsgReq>` | 通过DropShippingTransaction | RPC入口广播交易 |
| `sendMessageRequest` | `NetSendMessage<ContractTxMsgReq>` | http_api.cpp:1589 | RPC入口广播合约交易 |
| `HandleTx` (转发) | `NetSendMessage<TxMsgReq>` | transaction.cpp:1281 | 非目标节点转发 |
| `buildBlock` | `handleBlock(BlockMsg)` | transaction_cache.cpp:211 | 打包后Block Flow |
| `handleBlock` (搜索节点) | `SearchNodeToSendMsg` | transaction.cpp:3671 | VRF选验证节点 |
| `handleBlock` (回传) | `NetSendMessage<BlockMsg>` | transaction.cpp:3769-3778 | 回传给打包者 |
| `handleBuildBlockBroadcastMessage` | 触发`SaveBlock` | 广播区块 | 区块确认广播 |

---

## 六、状态修改点

| 状态变更 | 文件:行号 | 说明 |
|---------|-----------|------|
| UTXO: 可用→使用中 | double_spend_cache.cpp:14 | AddFromAddr 标记 |
| 交易: 已签名→池中 | transaction_cache.cpp:273 | AddCache 入池 |
| 交易: 池中→已打包 | transaction_cache.cpp:446 | CreateBlock 打包 |
| 区块: 构造中→BlockFlow | transaction_cache.cpp:211 | handleBlock |
| 区块: BlockFlow→已保存 | block_helper.cpp:665 | transactionCommit |
| UTXO: 使用中→已花费 | algorithm.cpp:5143 | SaveBlock (Vin处理) |
| UTXO: 新UTXO创建 | algorithm.cpp:5230 | SaveBlock (Vout处理) |
| 双花缓存: pending→已确认 | double_spend_cache.cpp:78 | Detection 清理 |
| 合约状态: 执行后提交 | algorithm.cpp:5520-5565 | 合约存储/MPT更新 |

---

## 七、异常处理与回滚路径

```mermaid
graph TD
    A[RPC接收] --> B{JSON解析}
    B -->|失败| E1[返回 -9090 parse fail]
    B -->|成功| C{双重花费检查}
    C -->|冲突| E2[返回 -16 UTXO using]
    C -->|通过| D[SendMessage]
    D --> F{P2P发送}
    F -->|失败| E3[返回 -1 send fail]
    F -->|成功| G[网络接收 HandleTx]
    G --> H{版本检查}
    H -->|失败| E4[返回 -1 incompatible]
    H -->|成功| I{超时检查}
    I -->|超时| E5[返回 -7 timeout]
    I -->|通过| J{UTXO高度检查}
    J -->|不合理| E6[返回 -4/-5/-6 utxoHeight]
    J -->|通过| K{交易验证}
    K -->|失败| E7[返回 -10000+ verify fail]
    K -->|通过| L{AddCache}
    L -->|冲突| E8[返回 -1/-2 DoubleSpent]
    L -->|成功| M[BuildBlock]
    M --> N{CreateBlock}
    N -->|失败| E9[ret -100 block create fail]
    N -->|成功| O{handleBlock}
    O --> P{verifyFlowedBlockStatus}
    P -->|失败| E10[返回 -1~-13 verify fail]
    P -->|成功| Q{PreSaveProcess}
    Q --> R{双花检查}
    R -->|双花冲突| E11[返回 -7~-9 doubleSpend]
    R -->|通过| S{ca_algorithm::SaveBlock}
    S -->|失败| E12[RocksDB Transaction RollBack]
    S -->|成功| T{transactionCommit}
    T -->|失败| E13[返回 -9 commit fail<br/>RocksDB自动回滚]
    T -->|成功| U[PostSaveProcess]
    
    style E12 fill:#ff6b6b
    style E13 fill:#ff6b6b
```

**关键回滚机制:**
1. **RocksDB Transaction Rollback** (rocksdb_read_write.cpp:55): 如果 `ca_algorithm::SaveBlock` 中任何一步失败，`BlockHelper::SaveBlock` 中不会调用 `transactionCommit`，而是清理 `dbWriterInstance`。RocksDB transaction 未commit自动丢弃。
2. **双花缓存回滚** (double_spend_cache.cpp:78): 已确认的区块通过 `Detection` 从 pending 中移除。
3. **交易池回滚** (transaction_cache.cpp:430): BuildBlock 失败时 `_transactionCache.clear()`。

---

## 八、信任度评估

| 模块 | 信任度 | 依据 |
|------|--------|------|
| RPC入口 | 高 | 直接阅读 http_api.cpp 源码 |
| SendMessage | 高 | 直接阅读 rpc_api_post_message.cpp |
| HandleTx | 高 | 直接阅读 transaction.cpp:1262-1306 |
| TransactionCache | 高 | 直接阅读 transaction_cache.cpp |
| BuildBlock | 高 | 直接阅读 transaction_cache.cpp:173 |
| handleBlock | 高 | 直接阅读 transaction.cpp:3582 |
| SaveBlock | 高 | 直接阅读 block_helper.cpp:597 + algorithm.cpp:3986 |
| DB层 (RocksDB) | 高 | 直接阅读 rocksdb_read_write.h/cpp |
| EVM执行 | 中 | 部分EVMManager逻辑未完全阅读 |
| VRF选择 | 中 | ecvrf内联汇编逻辑未深入 |
| 合约依赖管理 | 中 | DependencyManager部分功能注释掉 |
