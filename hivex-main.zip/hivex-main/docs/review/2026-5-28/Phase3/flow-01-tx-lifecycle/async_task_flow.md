# MeMeChain 交易生命周期 - 异步任务流转

## 文档元信息
- **项目**: MeMeChain (mm)
- **流程**: 交易从 RPC 进入 -> 验证 -> UTXO 处理 -> DAG 打包 -> EVM 执行 -> 持久化
- **日期**: 2026-05-26
- **信任度**: 高 (基于源码直接分析)

---

## 一、线程模型总览

```mermaid
graph TB
    subgraph "线程1: HTTP工作线程池"
        A[httplib Server]
        A1[sendApiMessageRequest]
        A2[sendMessageRequest]
        A3[apiJsonRpcRequest]
        A4[其他RPC处理]
    end

    subgraph "线程2: P2P网络接收线程池"
        B[ProtobufDispatcher]
        B1[TxMsgReq -> HandleTx]
        B2[ContractTxMsgReq -> contractTransactionRequest]
        B3[BlockMsg -> HandleBlock]
        B4[BuildBlockBroadcastMsg -> handleBuildBlockBroadcastMessage]
        B5[其他消息回调]
    end

    subgraph "线程3: 独立打包线程"
        C[TransactionCache Detach Thread]
        C1[processTransactionCacheFunc]
        C2[_buildTimer AsyncLoop 3s]
    end

    subgraph "线程4: BlockHelper 处理线程"
        D[BlockHelper::Process thread]
        D1[SaveBlock处理队列]
        D2[SeekBlockThreadObject]
    end

    subgraph "线程5: TaskPool 异步任务"
        E[TaskPool]
        E1[processPostTransaction]
        E2[其他异步任务]
    end

    subgraph "线程6: 合约依赖处理"
        F[ContractDispatcher]
        F1[Process]
        F2[TimerProcessor::ProcessingFunc]
    end

    A1 -->|同步| B1
    A2 -->|同步| B2
    C1 -->|handleBlock| B3
    B3 -->|广播| B4
    B4 -->|AddBlock| D1
    D1 -->|commitCaTask| E1
    F1 -->|异步触发| C2
```

---

## 二、异步任务详细流转

### 2.1 RPC线程 -> TransactionCache 任务传递

```
┌─ HTTP工作线程 ─────────────────────────────────────────────┐
│                                                             │
│  sendApiMessageRequest()                                    │
│    │                                                        │
│    ├── SendMessage() [同步]                                  │
│    │ └── DropShippingTransaction()                          │
│    │     └── NetSendMessage<TxMsgReq>(target, msg)          │
│    │         📤 网络发送                                     │
│                                                             │
└────────────────────┬────────────────────────────────────────┘
                     │ P2P网络
                     ▼
┌─ P2P接收线程 ───────────────────────────────────────────────┐
│                                                             │
│  ProtobufDispatcher 分发:                                    │
│  TxRegisterCallback<TxMsgReq> -> HandleTx()                 │
│    │                                                        │
│    └── handleTransaction()                                  │
│        └── TransactionCache::AddCache(tx, msg)  ───────────┐│
│            │                                               ││
│            ├── [普通交易]                                    ││
│            │   transactionCacheMutex.lock()                 ││
│            │   _transactionCache.push_back(...)             ││
│            │   if size >= BUILD_THRESHOLD:                  ││
│            │       _blockBuilder.notify_one()  ───────────┐││
│            │                                              │││
│            └── [合约交易]                                   │││
│                contractCacheMutex.lock()                   │││
│                _contractCache.push_back(...)               │││
│                                                            │││
└────────────────────────────────────────────────────────────┘││
                                                              ││
┌─ 独立打包线程 ──────────────────────────────────────────────┘│
│                                          ◄───────────────────┘
│  processTransactionCacheFunc() [while(_threadRun)]
│    │
│    ├── transactionCacheMutex.lock()
│    ├── _blockBuilder.wait(locker)
│    │   [触发条件]:
│    │   1. _blockBuilder.notify_one() [阈值触发]
│    │      文件: transaction_cache.cpp:275
│    │      阈值: BUILD_THRESHOLD = 1000000
│    │
│    │   2. _buildTimer.AsyncLoop(BUILD_INTERVAL, callback)
│    │      文件: transaction_cache.cpp:237
│    │      间隔: BUILD_INTERVAL = 3 * 1000 ms
│    │      回调: [=](){ _blockBuilder.notify_one(); }
│    │
│    ├── get_build_block_height(_transactionCache)
│    │   [检查75%共识节点高度 >= max_utxo_height]
│    │   [文件: transaction_cache.cpp:293]
│    │
│    ├── BuildBlock(buildTxs, buildHeight, false)
│    │   └── CreateBlock -> handleBlock
│    │
│    └── [循环继续]
│
└──────────────────────────────────────────────────────────────

传递机制: 生产者-消费者 (条件变量)
  - 生产者: HandleTx (网络线程) -> AddCache -> push + notify
  - 消费者: processTransactionCacheFunc (独立线程) -> wait -> pop_all
  - 锁: transactionCacheMutex (std::mutex)
  - 信号量: _blockBuilder (std::condition_variable)
  
  信任度: 高 (源码明确)
```

---

### 2.2 交易池任务队列机制

```
TransactionCache 内部数据结构:

┌─ _transactionCache ──────────────────────────────────────┐
│ vector<TransactionEntity>                                │
│                                                          │
│ TransactionEntity {                                      │
│   TxMsgReq msg;           // 原始网络消息                 │
│   CTransaction tx;        // 解析后的交易                │
│   uint64_t txUtxoHeight;  // UTXO高度                   │
│   ...                                                     │
│ }                                                        │
│                                                          │
│ 保护锁: transactionCacheMutex (std::mutex)               │
│ 触发条件: size >= BUILD_THRESHOLD (1000000)              │
│                                                           │
└──────────────────────────────────────────────────────────┘

┌─ _contractCache ────────────────────────────────────────┐
│ vector<ContractTransactionEntity>                        │
│                                                          │
│ 保护锁: contractCacheMutex (std::mutex)                  │
│ 处理: ProcessContract() 函数                             │
│                                                          │
└──────────────────────────────────────────────────────────┘

┌─ 缓存超时清理 ──────────────────────────────────────────┐
│ _kTxExpireInterval = 10 (秒)                            │
│ 定期清理过期交易 (removeExpired)                         │
│ 文件: transaction_cache.cpp:930                          │
│                                                        │
└────────────────────────────────────────────────────────┘
```

---

### 2.3 区块打包异步触发

```mermaid
sequenceDiagram
    autonumber
    participant Timer as _buildTimer<br/>AsyncLoop(3s)
    participant Cache as _transactionCache<br/>(临界区)
    participant Thread as processTransactionCacheFunc<br/>(detach线程)
    participant NodeList as PeerNode<br/>(节点列表)
    participant DB as DBReader

    loop 每3秒触发一次
        Timer->>Cache: _blockBuilder.notify_one()
        Note right of Timer: 定时信号
    end

    Note over Cache,Thread: 当有新交易入池时 (立即触发)
    
    Cache->>Thread: _blockBuilder.notify_one()
    Note right of Cache: cache.size >= BUILD_THRESHOLD (1000000)
    
    Thread->>Cache: 🔒 transactionCacheMutex.lock()
    Thread->>Cache: _blockBuilder.wait(locker)
    Note right of Thread: 阻塞等待信号

    Thread->>Cache: 检查 _transactionCache 是否为空
    alt 为空
        Thread->>Cache: continue (跳过本轮)
    end

    Thread->>Thread: get_build_block_height(_transactionCache)
    
    Thread->>NodeList: GetNodelist()
    Note right of NodeList: 获取所有节点及其高度

    Thread->>NodeList: VerifyBonusAddr(node.address)
    Note right of NodeList: 仅统计有质押/委托资格的节点

    Thread->>Thread: 计算75%共识高度 >= max_utxo_height
    
    alt 共识不足
        Thread->>Cache: _transactionCache.clear()
        Note right of Thread: 清空交易池, 跳过打包
    end

    Thread->>DB: getBlockTop(top)
    Note right of DB: 获取当前链顶高度

    Thread->>Thread: BuildBlock(buildTxs, buildHeight, false)
    Note right of Thread: 开始打包

    Thread->>Cache: _transactionCache.clear()
    Note right of Thread: 打包成功, 清空交易池

    Thread->>Cache: 🔓 locker.unlock()
```

---

### 2.4 合约依赖管理的异步检查

```mermaid
sequenceDiagram
    autonumber
    participant RPC as sendMessageRequest
    participant DepMgr as DependencyManager
    participant Disp as ContractDispatcher
    participant Timer as TimerProcessor
    participant MsgDisp as MessageDispatcher
    participant Net as NetSendMessage

    RPC->>RPC: dropCallShippingRequest(msg, tx)
    
    alt 本地节点为打包者
        RPC->>Disp: ContractDispatcher::AddContractRequest(txHash, deps, msg)
        Note right of Disp: dispatchtx.h<br/>加入合约依赖队列
        
        Disp->>Disp: contract_dep_cache_[txHash] = deps
        Disp->>Disp: contract_msg_cache_[txHash] = msg

        alt 合约依赖未满足
            Note over Disp: 等待依赖合约先执行
        else 依赖已满足或超时
            Disp->>MsgDisp: GetDependentData()
            Note right of MsgDisp: 获取可处理的合约交易组
            MsgDisp->>Net: DistributionContractTransactionRequest
            Note right of Net: 分发合约交易到打包节点
        end
    end

    Timer-->>Disp: TimerProcessor::SetTimeValue(contractTx.time)
    Note right of Timer: 设置超时时间
    Timer-->>Disp: ProcessingFunc() 定期检查
    Note right of Timer: kContractWaitingTime = 3 * 1000000 us

    Note over Disp,MsgDisp: ContractDispatcher::Process()<br/>由TimerProcessor触发
```

**合约依赖管理现有实现状态:**
- `DependencyManager` 中部分关键方法已注释掉 (dispatchtx.h:89-100 行范围):
  - `HandleContractDependencyBroadcastMsg` -- 注释掉
  - `StoreBroadcastDependencies` -- 注释掉
  - `CanSendTransaction` -- 注释掉
  - `ClearDependency` -- 注释掉
  - `BroadcastAddedDependency` -- 注释掉
- 内部缓存字段 `dependency_tx_hashes_`, `dependency_hash_times_`, `cleared_dependency_hashes_` 也被注释
- **信任度: 低** -- 合约依赖管理似乎处于开发/重构中状态
- **【需人工验证】** 当前合约交易的依赖处理实际如何工作

---

### 2.5 定时器触发的清理/重试任务

```
┌─ 定时任务列表 ────────────────────────────────────────────────────┐
│                                                                    │
│ 1. 交易池打包定时器                                                │
│    文件: transaction_cache.cpp:235-240                             │
│    类: _buildTimer (AsyncLoop)                                     │
│    间隔: BUILD_INTERVAL = 3 * 1000 ms                              │
│    动作: _blockBuilder.notify_one()                                │
│    说明: 即使交易池未达阈值, 也定期尝试打包                         │
│                                                                    │
│ 2. 双花缓存清理                                                    │
│    方法: doubleSpendCache::CheckLoop()                             │
│    文件: double_spend_cache.cpp:55                                  │
│    清理条件: item.second.time + 30s < now                          │
│    说明: 超时30秒的pending UTXO标记自动清除                        │
│    【需人工验证】 CheckLoop 是否被定期调用, 调用频率待确认        │
│                                                                    │
│ 3. 过期交易缓存清理                                                │
│    方法: TransactionCache::removeExpiredFromDirtyContractMap()      │
│    文件: transaction_cache.cpp:930                                  │
│    过期时间: _kTxExpireInterval = 10 (seconds?)                    │
│    说明: 清理脏合约映射 (dirtyContractMap)                          │
│    【需人工验证】单位确认 (row 844 定义为time_t 10)                │
│                                                                    │
│ 4. 失败交易缓存重试                                                │
│    类: failedTransactionCache                                       │
│    文件: ca/failed_transaction_cache.h                              │
│    触发条件: txUtxoHeight > top (高度超前)                         │
│    调用点: transaction.cpp:1436                                     │
│    方法: Add(txUtxoHeight, msg)                                     │
│    【需人工验证】失败交易重试机制的具体实现                         │
│                                                                    │
│ 5. 合约依赖超时处理                                                │
│    类: TimerProcessor                                              │
│    文件: dispatchtx.h                                              │
│    方法: ProcessingFunc() (timer_thread_)                          │
│    超时: kContractWaitingTime = 3 * 1000000 us                     │
│    动作: 触发 ContractDispatcher::Process()                        │
│                                                                    │
│ 6. 区块存储重连重发                                                │
│    类: ResendReconnectNode                                         │
│    文件: ca/resend_reconnect_node.h                                 │
│    清理: block_helper.cpp:681                                      │
│    代码: RemoveResendBlock(block.hash())                           │
│    【需人工验证】重发机制详细实现                                   │
│                                                                    │
│ 7. 区块查找线程                                                    │
│    方法: BlockHelper::SeekBlockThreadObject()                       │
│    文件: block_helper.cpp:1549                                      │
│    说明: 查找缺失的区块/UTXO                                       │
│    【需人工验证】线程启动和停止条件                                 │
│                                                                    │
│ 8. BlockStorage Lookup Task                                        │
│    调用: commitLookupTask(buildHeight)                              │
│    调用点: transaction_cache.cpp:422                                │
│    说明: 提交区块前置Hash查找任务                                  │
│                                                                     │
└────────────────────────────────────────────────────────────────────┘
```

---

## 三、任务传递总结

```mermaid
graph LR
    subgraph "HTTP线程"
        A[RPC接收]
    end
    
    subgraph "P2P+验证线程"
        B[HandleTx]
        C[contractTransactionRequest]
    end
    
    subgraph "交易池"
        D[_transactionCache]
        E[_contractCache]
    end
    
    subgraph "打包线程"
        F[processTransactionCacheFunc]
        G[_buildTimer 3s]
    end
    
    subgraph "Block Flow"
        H[handleBlock]
        I[BlockHelper::Process]
    end
    
    subgraph "持久化"
        J[SaveBlock]
        K[RocksDB Commit]
    end
    
    subgraph "后处理"
        L[PostSaveProcess]
        M[HTTP Callbacks]
    end

    A -->|同步 SendMessage| B
    A -->|同步 dropCallShippingRequest| C
    B -->|同步 AddCache| D
    C -->|同步 AddCache| E
    G -->|notify_one| F
    F -->|BuildBlock| H
    H -->|block flow 完成| I
    I -->|SaveBlock| J
    J -->|transactionCommit| K
    K -->|PostSaveProcess| L
    L -->|TaskPool::commitCaTask| M

    style A fill:#e3f2fd
    style B fill:#fff3e0
    style F fill:#e8f5e9
    style J fill:#fce4ec
    style K fill:#fce4ec
```

---

## 四、关键异步机制的信任度评估

| 机制 | 信任度 | 依据 | 待验证 |
|------|--------|------|--------|
| 交易池生产者-消费者 | 高 | 源码明确 mutex+condvar | - |
| 打包线程3s定时器 | 高 | _buildTimer.AsyncLoop 源码 | - |
| 打包阈值触发 | 高 | BUILD_THRESHOLD 常量明确 | 100万阈值是否合理 |
| 双花缓存超时清理 | 中 | CheckLoop 源码有 | 调用频率不确定【需人工验证】 |
| 合约依赖管理 | 低 | 大量代码注释掉 | 实际工作机制【需人工验证】 |
| EVM执行与SaveBlock关系 | 中 | SaveBlock 见到EVM持久化 | 执行时机细节【需人工验证】 |
| 失败交易重试 | 中 | failedTransactionCache 存在 | 触发条件+重试策略【需人工验证】 |
| BlockStorage Lookup | 中 | commitLookupTask 调用 | 内部队列处理机制【需人工验证】 |
| 预占Hash查找 | 中 | SeekBlockThreadObject 存在 | 线程生命周期【需人工验证】 |
| Block Flow 超时 | 低 | 未见显式超时 | 如果某签名者掉线如何处理【需人工验证】 |

---

## 五、死锁风险评估

### 锁获取顺序分析

```
路径1 (普通交易RPC):
  1. doubleSpendMutex (AddFromAddr)
  2. transactionCacheMutex (AddCache)

路径2 (网络接收 -> 打包):
  1. transactionCacheMutex (AddCache, 在HandleTx线程)
  2. transactionCacheMutex (processTransactionCacheFunc, 在打包线程)
  [两个线程获取同一锁, 但通过condvar协调, 不会同时持有]

路径3 (SaveBlock):
  1. RocksDB Transaction (BeginTransaction, 仅一个WriteBatch)
  2. global::ca::BURN_MUTEX (在Transaction内短暂持有)

路径4 (SaveBlock后清理):
  1. doubleSpendMutex (Detection)

全局锁获取顺序:
  doubleSpendMutex -> transactionCacheMutex -> RocksDB Transaction -> BURN_MUTEX -> doubleSpendMutex
                                                                    └─────────────────────────┘
                                                                           (跨事务, 无死锁)
```

**死锁风险: 低**
- 所有主要锁在不同上下文(线程)中获取, 没有形成交叉获取环路
- RocksDB Transaction 是单线程内顺序操作
- BURN_MUTEX 在Transaction内部, 不存在跨事务交叉
- 合约相关锁(contractCacheMutex/dep_mutex_/msg_mutex_)使用 std::mutex, 作用域清晰

**风险点:**
- DependencyManager 中的 dep_mutex_ 和 msg_mutex_ 如果同时持有可能形成环路【需人工验证】
- 合约依赖处理的异步特性增加了锁排序的复杂度【需人工验证】

---

## 六、待人工验证清单

| 序号 | 问题 | 影响范围 | 优先级 |
|------|------|---------|--------|
| 1 | doubleSpendCache::CheckLoop 是否被周期性调用 | 双花标记泄漏 | 高 |
| 2 | 合约依赖管理 (DependencyManager) 的实际工作流程 | 合约执行顺序 | 高 |
| 3 | EVM 执行是否在 SaveBlock 同一事务内 | 原子性 | 高 |
| 4 | Block Flow 中某签名节点掉线的处理 | 区块确认超时 | 中 |
| 5 | failedTransactionCache 的重试触发和策略 | 交易重试 | 中 |
| 6 | _kTxExpireInterval 的时间单位 (10s vs 10ms) | 缓存清理 | 中 |
| 7 | processTransactionCacheFunc 线程启动/停止条件 | 线程安全 | 中 |
| 8 | ContractDispatcher::Process 的调用链完整性 | 合约打包 | 中 |
| 9 | MessageDispatcher::DistributionContractTransactionRequest | 合约分发 | 低 |
| 10 | VRF/EC-VRF 内联汇编跨平台兼容性 | 跨平台 | 低 |
