# MeMeChain 交易生命周期 - 状态转换

## 文档元信息
- **项目**: MeMeChain (mm)
- **流程**: 交易从 RPC 进入 -> 验证 -> UTXO 处理 -> DAG 打包 -> EVM 执行 -> 持久化
- **日期**: 2026-05-26
- **信任度**: 高 (基于源码直接分析)

---

## 一、交易状态转换 (CTransaction)

### 状态枚举 (源码分析推导)

CTransaction 通过以下字段隐式表达状态:
- `version`: 版本号
- `type`: 交易类型 (TX, STAKE, UNSTAKE, DELEGATE, UNDELEGATE, CALL, DEPLOY, BONUS, FUND, LOCK, UNLOCK 等)
- `hash`: 交易Hash (SHA256 of serialized body)
- `signature`: 签名列表
- `consensus`: 共识确认数
- `utxos[].multisign`: 多重签名 (逐UTXO)

状态判断逻辑:
```cpp
// 交易状态判断伪代码
if (tx.signature_size() == 0) -> "构造中"
if (tx.hash().empty()) -> "未序列化/未计算Hash"
if (tx.consensus() == 0) -> "未确认"
if (checked in BlockHelper::SaveBlock) -> "已确认"
```

### 状态图

```mermaid
stateDiagram-v2
    [*] --> 构造中: RPC请求创建交易
    构造中 --> 构造中: TxHelper::Check参数<br/>TxHelper::FindUtxo选择UTXO<br/>UtxoCore::createUtxoTransferFrom
    构造中 --> 已签名: UtxoCore::signUtxo(addr, utxo)<br/>UtxoCore::signTx(addr)
    已签名 --> 已计算Hash: Getsha256Hash(tx)<br/>outTx.set_hash(txHash)
    已计算Hash --> 双花预检中: doubleSpendCache::AddFromAddr<br/>(http_api.cpp:1416)
    
    双花预检中 --> 已广播: NetSendMessage<TxMsgReq><br/>DropShippingTransaction
    双花预检中 --> 双花冲突: UTXO已被使用
    双花冲突 --> [*]: 返回错误 -16

    已广播 --> 网络转发中: HandleTx 非目标节点转发
    已广播 --> 验证中: HandleTx -> handleTransaction<br/>(transaction.cpp:1300)

    网络转发中 --> 验证中: 转发到目标节点后
    
    验证中 --> 验证失败: 超时/签名错误/余额不足
    验证失败 --> [*]: 返回错误码
    验证中 --> 池中: TransactionCache::AddCache<br/>(transaction_cache.cpp:245)

    池中 --> 待打包: _blockBuilder.notify_one()
    池中 --> [*]: 超时清理 (_kTxExpireInterval=10s)

    待打包 --> 打包中: BuildBlock -> CreateBlock<br/>(transaction_cache.cpp:83)
    打包中 --> 打包失败: CreateBlock失败
    打包失败 --> 池中: _transactionCache.clear()<br/>下次循环重试 (如果是-103/-104/-105)
    打包失败 --> [*]: 非可恢复错误

    打包中 --> BlockFlow中: handleBlock(blockMsg)<br/>(transaction_cache.cpp:211)

    BlockFlow中 --> 签名收集中: 0签名->SearchNodeToSendMsg<br/>VRF选择验证节点
    BlockFlow中 --> 签名收集中: 1签名->回传打包者
    BlockFlow中 --> 已广播区块: 2签名->重新广播<br/>(BuildBlockBroadcastMsg)

    签名收集中 --> BlockFlow验证失败: verifyFlowedBlockStatus失败
    BlockFlow验证失败 --> [*]: 返回错误

    已广播区块 --> 待持久化: BlockHelper::AddBroadcastBlock<br/>(block_helper.cpp:1952)
    待持久化 --> 持久化中: BlockHelper::SaveBlock<br/>(block_helper.cpp:597)

    持久化中 --> 持久化失败: PreSaveProcess失败<br/>ca_algorithm::SaveBlock失败<br/>transactionCommit失败
    持久化失败 --> 重试: 触发SyncBlock重新同步
    持久化失败 --> [*]: 同步重试后放弃

    持久化中 --> 已确认: transactionCommit成功<br/>(block_helper.cpp:664)

    已确认 --> 后处理中: PostSaveProcess<br/>(block_helper.cpp:1007)
    后处理中 --> [*]: contractBlockNotification<br/>PeerNode::SetSelfHeight<br/>HTTP Callback通知
```

---

## 二、UTXO 状态转换

UTXO 在 protobuf 中作为 `CTxUtxos` 表达，每个交易包含 `repeated CTxUtxos utxos`。
每个 UTXO 通过 `CTxInput.vin[].prevOut.hash + prevOut.n` 唯一标识。

### 数据库中的 UTXO 生命周期

UTXO 在 RocksDB 中以以下 Key-Value 形式存储:
```
key: utxo_hash_by_addr_{addr}_{assettype}  
value: {txHash1_txHash2_...} (mergeValue 拼接)
```

```mermaid
stateDiagram-v2
    [*] --> 可用: 新UTXO产生于已确认区块<br/>setUtxoHashesByAddr(addr, currency, txHash)<br/>algorithm.cpp:5230
    
    可用 --> 已选择: TxHelper::FindUtxo 找到该UTXO<br/>用于新交易构造<br/>(仅内存状态, 未写入DB)
    
    已选择 --> 使用中: doubleSpendCache::AddFromAddr<br/>标记pending (内存锁定)
    已选择 --> 可用: 交易构造失败/放弃<br/>(未提交任何变更)
    
    使用中 --> 已花费: ca_algorithm::SaveBlock<br/>Vin处理: removeUtxoHashesByAddr<br/>algorithm.cpp:5130<br/>(DB状态变更)
    使用中 --> 使用中: CheckLoop超时 (30秒)<br/>double_spend_cache.cpp:55<br/>(过期自动清除标记)
    使用中 --> 可用: doubleSpendCache::CheckLoop<br/>(如果标记超时被清除)
    
    已花费 --> 不可逆: transactionCommit成功<br/>(RocksDB原子提交)

    state 回滚状态 {
        已花费 --> 已恢复: RocksDB transactionRollBack<br/>rocksdb_read_write.cpp:55<br/>(所有变更回滚)
        已恢复 --> 可用: UTXO重新可用
    }
```

### UTXO 来源

| 交易类型 | UTXO 产生方式 | 文件:行号 |
|---------|-------------|-----------|
| 所有交易 Vout | `setUtxoHashesByAddr(vout.addr, currency, tx.hash)` | algorithm.cpp:5230 |
| STAKE | `setStakeUtxoByAddr(addr, currency, tx.hash)` | algorithm.cpp:4190 |
| DELEGATE | `setDelegatingUtxo...` | algorithm.cpp (相关段) |
| BONUS | `bonusUtxoValue.insert(...)` | algorithm.cpp (相关段) |
| BURN | `setBurnAmountByPeriod` 但不创建新UTXO | algorithm.cpp:5180 |

---

## 三、合约状态转换 (EVM)

### 合约交易类型

```cpp
global::ca::TxType::DEPLOY  // 部署合约
global::ca::TxType::CALL    // 调用合约
```

### 状态图

```mermaid
stateDiagram-v2
    [*] --> EVM未执行: msg进入ContractDispatcher<br/>contractTransactionRequest
    
    EVM未执行 --> 依赖等待中: DependencyManager::AddContractRequest<br/>dispatchtx.h (ContractDispatcher)
    依赖等待中 --> 依赖已满足: TimerProcessor到期<br/>或所有依赖合约已确认
    依赖等待中 --> [*]: 超时未满足 (被清理)
    
    依赖已满足 --> EVM执行中: EvmManager::execute<br/>(在 SaveBlock 前或期间执行)
    
    EVM执行中 --> EVM执行成功: 执行完成, 收集:<br/>- contractOutputKey (runtime code)<br/>- contractCreationKeyLabel (内部合约)<br/>- contractPreHashKey (前置Hash)<br/>- contractDestructionKey (销毁列表)<br/>- storageKeyForContract (MPT变更)
    
    EVM执行中 --> EVM执行失败: 异常/out-of-gas/REVERT
    EVM执行失败 --> [*]: 交易标记为失败<br/>仍然在链上 (消耗Gas)
    
    EVM执行成功 --> 待提交: 执行结果加入blockData JSON<br/>cache: addContractInfoCache
    
    待提交 --> 已提交: RocksDB transactionCommit
    待提交 --> 已回滚: RocksDB transactionRollBack
    EVM执行中 --> 已回滚: block打包失败
    
    已提交 --> 合约已确认: PostSaveProcess<br/>EventManager::Publish("TransactionConfirmed")
    
    state EVM执行中详细状态 {
        记录account access -> recordAccountAccess
        读取storage -> get_storage (MPT trie)
        写入storage -> set_storage (内存, 放入blockData)
        合约间调用 -> execute (递归)
        SELFDESTRUCT -> contractDestructionKey
    }
```

### 合约存储变更 (DB持久化)

在 `ca_algorithm::SaveBlock` 中 (algorithm.cpp:5490-5650):

```
DEPLOY 交易持久化:
├── Evmone::SaveContract(deployer, deployHash, contractAddr, code, dbWriter)
│   └── setContractDeployUtxoByContractAddr
│   └── setContractCodeByContractAddr
│   └── setLatestUtxoByContractAddr
│
├── [内部合约创建循环]
│   └── Evmone::SaveContract(deployer, deployHash, internalAddr, code, dbWriter)
│
├── setLatestUtxoByContractAddr(contractAddr, txHash)
│
├── removeContractDeployUtxoByContractAddr (如有销毁)
│
└── setMptValueByMptKey(key, value) [MPT状态Trie更新]

CALL 交易持久化:
├── [内部合约创建] Evmone::SaveContract
├── setLatestUtxoByContractAddr
├── removeContractDeployUtxoByContractAddr + removeContractCodeByContractAddr
└── setMptValueByMptKey [MPT状态Trie更新]
```

---

## 四、区块状态转换

```mermaid
stateDiagram-v2
    [*] --> 构造中: CreateBlock<br/>(transaction_cache.cpp:83)
    构造中 --> 已构造: Merkle根计算完成<br/>block.hash() 设置

    已构造 --> BlockFlow_0sig: handleBlock (打包者发送)
    
    BlockFlow_0sig --> BlockFlow_1sig: 验证节点签名<br/>AddBlockSign + 回传

    BlockFlow_1sig --> BlockFlow_2sig: 打包者收集回执
    
    BlockFlow_2sig --> 广播中: handleBuildBlockBroadcastMessage<br/>(transaction.cpp:1106)
    
    广播中 --> 待保存: BlockHelper::AddBroadcastBlock<br/>(block_helper.cpp:1952)
    
    待保存 --> 保存中: BlockHelper::SaveBlock<br/>PreSaveProcess -> SaveBlock
    
    保存中 --> 已确认: transactionCommit成功
    保存中 --> 保存失败: 双花/验证失败/DB错误
    保存失败 --> 重试: SyncBlock重新同步
    保存失败 --> 孤立块: 前驱块不存在
    
    已确认 --> after_post: PostSaveProcess
    after_post --> [*]: _pendingBlocks处理完成
```

### 区块验证状态 (BlockStatus)

通过 `BlockStatus` protobuf 传递验证状态:
```cpp
// block_helper.cpp:552
if(blockStatus != NULL) {
    for(const auto& tx : double_spent_transactions) {
        auto txStatus = blockStatus->add_txstatus();
        txStatus->set_txhash(tx.hash());
        txStatus->set_status(global::ca::DoubleSpend::SingleBlock);
    }
}
```

---

## 五、双花缓存状态转换

```mermaid
stateDiagram-v2
    [*] --> Pending: AddFromAddr(fromaddr, usedUtxos)<br/>double_spend_cache.cpp:14
    Pending --> Pending: 追加新UTXO (标记为使用中)
    Pending --> Conflict: 检测到冲突UTXO
    Conflict --> [*]: 返回 -1 (拒绝该交易)
    
    Pending --> Expired: CheckLoop 30秒超时<br/>double_spend_cache.cpp:78
    Expired --> [*]: Remove(txTimeKey) 清理
    
    Pending --> Confirmed: Detection(block) 在已确认区块中找到<br/>double_spend_cache.cpp:78
    Confirmed --> [*]: Remove(txTimeKey) 清理
```

---

## 六、关键状态修改的原子性分析

### 普通交易的 UTXO 原子性

```
ca_algorithm::SaveBlock 中:
  所有 Vin(花费) + Vout(产出) 操作在同一个 DBReadWriter 事务内
  -> 多个 dbWriter.setBalanceByAddr / setUtxoHashesByAddr 调用
  -> 最后通过 transactionCommit() 原子提交
  -> 如果中间任何一步失败, 返回错误码
  -> BlockHelper::SaveBlock 会跳过 transactionCommit() 调用
  -> RocksDB Transaction 自动回滚未提交的所有更改

结论: UTXO花费与产出的原子性由 RocksDB Transaction 保证 [信任度: 高]
```

### 合约交易的 UTXO + EVM 原子性

```
ca_algorithm::SaveBlock 中 contract 分支:
  1. Vin/Vout (UTXO) 操作 -> dbWriter
  2. Evmone::SaveContract -> dbWriter (合约代码存储)
  3. setLatestUtxoByContractAddr -> dbWriter (合约Hash更新)
  4. setMptValueByMptKey -> dbWriter (MPT Trie更新)
  5. 以上全部在同一事务内, transactionCommit() 原子提交

结论: UTXO + EVM状态更新的原子性由 RocksDB Transaction 保证 [信任度: 高]

但需注意:
  - EVM 执行结果在 SaveBlock 之前就已经收集 (在 blockData JSON中)
  - SaveBlock 只是将已执行的结果持久化
  - 如果 EVM 执行成功但 SaveBlock 中某个DB写失败, 整体回滚
  - 【需人工验证】: EVM执行是否在 SaveBlock 的同一DB事务内, 还是提前执行
```

### 多交易区块的原子性

```
一个区块包含多个交易 (普通+合约)
SaveBlock 中 for (auto &tx : block.txs()) 循环处理所有交易
所有交易的处理在同一事务内
-> 区块要么全部提交, 要么全部回滚
-> 不会出现"部分交易已确认"的情况

结论: 区块内多交易的原子性由 RocksDB Transaction 保证 [信任度: 高]
```

---

## 七、信任度评估

| 状态模型 | 信任度 | 依据 |
|---------|--------|------|
| 交易状态 | 高 | 跟踪源码状态修改点 |
| UTXO状态 | 高 | 分析 DB Read/Write 操作 |
| 合约状态 | 中 | EVM内部执行细节未完全分析 |
| 区块状态 | 高 | 分析 Block Flow + block_helper |
| 双花缓存 | 高 | 直接阅读 double_spend_cache.cpp |
| 原子性: UTXO | 高 | RocksDB Transaction 机制明确 |
| 原子性: UTXO+EVM | 高 | SaveBlock 同一事务内处理 |
| 原子性: 多交易 | 高 | 同一事务内循环处理 |
