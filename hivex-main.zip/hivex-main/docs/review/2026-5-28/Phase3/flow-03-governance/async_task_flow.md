# MeMeChain 治理流程异步任务与定时器

## 1. 定时器总览

| 定时器常量 | 值 | 定义位置 | 用途 |
|-----------|-----|---------|------|
| `KVoteCycle` | 10*60*1000000 (10分钟) | ca/global.h:132 | 提案/投票最小周期 |
| `KVrfVoteBeginTime` | 10*1000000 (10秒) | ca/global.h:133 | VRF投票开始前预留窗口 |
| 30天锁定期 | 30*24*3600*1000000 | ca/transaction.cpp:2930 | 解锁前必须锁定满30天 |
| Dev网锁定期 | 60*1000000 (60秒) | ca/transaction.cpp:2933 | 开发环境测试用 |

**重要发现**: 当前代码中 **KVoteCycle 和 KVrfVoteBeginTime 仅作为时间窗口常量使用**，并非独立的异步定时器。没有找到显式的周期性投票统计任务（如每10分钟触发一次自动计票的定时器）。投票结果判定是**惰性触发**的：在 `GetAssetTypeIsValid()` 或 `GetVoteAssetType()` 被调用时才检查和统计。

---

## 2. 投票周期定时器 (KVoteCycle) 分析

### 2.1 KVoteCycle 的使用方式

KVoteCycle 作为**最小时间窗口校验**使用，而非周期性触发器：

```
// ca/algorithm.cpp:623 - PROPOSAL 交易校验
if(proposalEndTime - proposalStartTime < global::ca::KVoteCycle)
{
    ERRORLOG("proposalEndTime error: begin: {}, end:{}", proposalEndTime, proposalStartTime);
    return -26;
}

// ca/algorithm.cpp:680 - REVOKEPROPOSAL 交易校验
if(endTime - beginTime < global::ca::KVoteCycle)
{
    ERRORLOG("proposalEndTime error: begin: {}, end:{}", endTime, beginTime);
    return -31;
}

// ca/ca.cpp:3979 - 提案创建校验 (console命令路径)
if(endTime - beginTime < global::ca::KVoteCycle)
{
    ERRORLOG("endTime - beginTime < KVoteCycle");
    return -1;
}
```

**结论**: KVoteCycle = 10分钟，含义为保证提案/投票窗口至少持续10分钟，防止过短的投票窗口导致攻击。

### 2.2 投票结果判定的触发方式

```
// 入口1: GetAssetTypeIsValid() - 被多种场景调用
ca/algorithm.cpp:8602
  ├── 被 GetVoteAssetType() 调用 (rpc_api_vote.cpp:51)
  ├── 被 CheckVoteTxInfo() 调用 (algorithm.cpp:9465)
  ├── 被 fetchAvailableAssetType() 调用
  └── 被 GetUnavailableAssetType() 调用

// 入口2: GetVoteAssetType() - RPC查询可用投票类型
ca/algorithm.cpp:8476
  ├── 遍历所有资产类型
  ├── 检查投票窗口: time >= beginTime && time < endTime → 可投票
  ├── 检查撤销投票窗口: time >= beginTime2 && time < endTime2 → 撤销可投票
  └── 投票窗口已过的, 不会被返回（隐含已结束）

// 入口3: GetAssetTypeIsValid() - 提案有效性查询
ca/algorithm.cpp:8602
  ├── time > endTime (投票窗口已关闭)
  ├── GetVoteNum() 统计票数
  ├── 判定通过/否决/撤销
  └── 返回0(提案有效)或负值(无效)
```

### 2.3 异步任务流程图

```mermaid
flowchart TB
    subgraph External_Trigger["外部触发 (非定时器)"]
        direction TB
        A1["RPC查询: GetVoteAssetType()"]
        A2["交易校验: CheckVoteTxInfo()"]
        A3["交易校验: verifyTransactionRequest()"]
        A4["资产查询: GetAssetTypeIsValid()"]
        A5["提案查询: fetchAvailableAssetType()"]
    end

    subgraph Time_Window_Check["时间窗口检查"]
        direction TB
        B1{"beginTime <= now < endTime?"}
        B2{"now > endTime?"}
    end

    subgraph Vote_Actions["投票操作"]
        direction TB
        C1["CheckForDuplicateVotes()<br/>去重检查"]
        C2["addVoteCount()<br/>计票写入"]
        C3["setVoteCountByAssetType()<br/>DB: APPROVE:/AGAINST:"]
    end

    subgraph Result_Evaluation["结果判定 (惰性)"]
        direction TB
        D1["GetVoteNum()<br/>统计赞成/反对"]
        D2{"approveNum > againstNum<br/>AND totalVoters >= minVote?"}
        D3["提案通过 ✓"]
        D4["提案否决 ✗"]
    end

    A1 --> B1
    A2 --> B1
    A3 --> B1
    A3 --> C1
    A3 --> C2
    C1 --> C2
    A4 --> B2
    A5 --> B2
    B2 --> D1
    D1 --> D2
    D2 -->|Yes| D3
    D2 -->|No| D4

    style Time_Window_Check fill:#fff3e0,stroke:#e65100
    style Vote_Actions fill:#e8f5e9,stroke:#2e7d32
    style Result_Evaluation fill:#e3f2fd,stroke:#1565c0
    style External_Trigger fill:#f3e5f5,stroke:#7b1fa2
```

---

## 3. VRF投票开始窗口 (KVrfVoteBeginTime)

### 3.1 定时常量

```
// ca/global.h:133
const uint32_t KVrfVoteBeginTime = 10 * 1000000; // 10秒
```

### 3.2 使用方式

KVrfVoteBeginTime 用于确保提案/投票的beginTime在当前时间之后留有足够余量，防止VRF分片选择过程消耗的时间导致beginTime在上链时已过期：

```
// PROPOSAL 交易创建 - txhelper.cpp:4362
if(currentTime - global::ca::KVrfVoteBeginTime > beinTime)
{
    ERRORLOG("begin time error, current time:{}, begin time:{}", currentTime, beinTime);
    return -12;
}

// PROPOSAL 交易验证 - algorithm.cpp:619
if(tx.time() - global::ca::KVrfVoteBeginTime > proposalStartTime)
{
    return -25;
}

// REVOKEPROPOSAL 交易创建 - txhelper.cpp:4593
if(currentTime - global::ca::KVrfVoteBeginTime > beinTime)
{
    ERRORLOG("begin time error");
    return -12;
}

// REVOKEPROPOSAL 交易验证 - algorithm.cpp:676
if(tx.time() - global::ca::KVrfVoteBeginTime > beginTime)
{
    return -30;
}
```

### 3.3 时间线

```
    提案构建时间                   提案上链时间
        |                              |
        v                              v
<---10秒--->|<----KVoteCycle(>=10分钟)---->|
            |                              |
      KVrfVoteBeginTime               endTime
          预留窗口

beginTime ---^
```

**约束**: `beginTime >= currentTime - KVrfVoteBeginTime` 即 beginTime 必须在当前时间之后（允许10秒的VRF开销余量）。

---

## 4. 去重检查的异步验证

### 4.1 CheckForDuplicateVotes 去重机制

```mermaid
flowchart TB
    Start("[addVoteCount 被调用]") --> CallDupCheck["CheckForDuplicateVotes(assetType, addr)"]

    CallDupCheck --> ReadApprove["db.getApproveAddrsByAssetType(assetType, addrs)"]
    ReadApprove --> CheckApprove{"addr IN approveSet?"}
    CheckApprove -->|Yes| Reject1["❌ return -4<br/>Repetition of approval"]
    CheckApprove -->|No| ReadAgainst["db.getAgainstAddrsByAssetType(assetType, addrs)"]

    ReadAgainst --> CheckAgainst{"addr IN againstSet?"}
    CheckAgainst -->|Yes| Reject2["❌ return -6<br/>Repetition of opposition"]
    CheckAgainst -->|No| Pass["✓ return 0<br/>可以投票"]

    style Reject1 fill:#ffcdd2,stroke:#c62828
    style Reject2 fill:#ffcdd2,stroke:#c62828
    style Pass fill:#c8e6c9,stroke:#2e7d32
```

### 4.2 去重可靠性分析

**双重校验点**:
```
校验点1: 交易构建时 - ca/transaction/vote.cpp:51-65
  └─ CheckVoteTxInfo() 只检查时间窗口, 不做去重

校验点2: 交易验证时 - ca/algorithm.cpp:710
  └─ CheckVoteTxInfo() 只检查时间窗口, 不做去重

校验点3: SaveBlock时 - ca/algorithm.cpp:4939
  └─ addVoteCount() 内调用 CheckForDuplicateVotes() + 写入APPROVE/AGAINST集合
  └─ 这是唯一的去重检查点!
```

**风险分析**:

1. **去重检查只在SaveBlock阶段**: addVoteCount() 的调用位置 (algorithm.cpp:4939) 位于 SaveBlock 函数中，即区块确认阶段。交易构建和广播验证阶段均不检查重复投票。【需人工验证: 是否应该在前端也加入去重检查以提高用户体验?】

2. **无事务性**: CheckForDuplicateVotes() 查询 DB 和后续的 setApproveAddrsByAssetType() 写入之间没有数据库事务保护。在区块层面，SaveBlock 整体失败会触发 RollBack，但在单区块内不会出现插入竞争。
   - **文件**: algorithm.cpp:9179-9222 (查询) vs algorithm.cpp:9258-9267 (写入)
   - **结论**: 在单线程区块处理模型下，该竞态不存在。但如果未来引入并行区块处理，则需要加锁。

3. **地址格式**: CheckForDuplicateVotes 使用原始地址字符串进行查找匹配，依赖于:
   - addr 格式的一致性（统一使用同一个字符串表示）
   - `set.find(addr)` 是精确匹配，不存在大小写/前缀问题

4. **数据一致性**: addVoteCount 中的 `setVoteCountByAddr(addr, assetType, voteNumber)` (algorithm.cpp:9285) 记录了每个地址投给每个资产的票数，可用于回滚时校验 (subVoteNum 中检查 voteNum == voteNumber, algorithm.cpp:9340)。

---

## 5. LOCK_MUTEX 的持有范围

### 5.1 全局锁定义

```
// ca/global.h:32
static std::mutex LOCK_MUTEX;
```

### 5.2 持有位置

```
位置1: algorithm.cpp:4370 (SaveBlock - LOCK交易)
  std::lock_guard<std::mutex> lock(global::ca::LOCK_MUTEX);
  持有范围: setLockAddrUtxo() → getTotalLockedAmonut() → setTotalLockedAmonut()
  代码行: algorithm.cpp:4370-4409
  作用: 保护锁定地址-UTXO映射 + 总锁定金额的原子更新

位置2: algorithm.cpp:6068 (RollBack - LOCK交易回滚)
  std::lock_guard<std::mutex> lock(global::ca::LOCK_MUTEX);
  持有范围: removeLockAddrUtxo() → removeLockAddr()
  代码行: algorithm.cpp:6068-6082
  作用: 保护回滚时的锁定状态清理
```

### 5.3 未被锁覆盖的路径

**解锁流程 (UNLOCK) 不在 LOCK_MUTEX 保护下**:
- `algorithm.cpp:4478` → removeLockAddrUtxo() 不在 LOCK_MUTEX 内
- `algorithm.cpp:6196` → setLockAddrUtxo() (回滚) 不在 LOCK_MUTEX 内

**潜在问题**:
如果 LOCK 和 UNLOCK 交易在同一个区块中发生，且并行处理:
- LOCK 的 SaveBlock 持有 LOCK_MUTEX (algorithm.cpp:4370)
- UNLOCK 的 SaveBlock 不持有 LOCK_MUTEX
- 如果 UNLOCK 先于 LOCK 执行，可能造成同一地址上锁和解锁的竞争。
- **实际影响**: 当前实现中区块处理是串行的（顺序遍历txs），所以在单区块内不会出现真正竞争。但 LOCK_MUTEX 的保护范围不对称。

**与此对比**: STAKE/UNSTAKE 的操作也不在 LOCK_MUTEX 内（LOCK_MUTEX 只用于锁交易）。
- 当前锁的命名和范围可能不完整。【需人工验证】

---

## 6. TOCTOU 竞态分析

### 6.1 投票时间窗口 TOCTOU

**问题**: 交易构建时检查时间和上链检查时间之间有时间差。

```
时刻线:
  t1: RPC构建投票交易
       → CheckVoteTxInfo(currentTime=t1) → t1 在 [beginTime, endTime) 内 → 通过
  t2: 交易广播到网络
  t3: 交易被打包进区块 (tx.time = 广播时的时间)
       → verifyTransactionRequest → CheckVoteTxInfo(tx.time=t3)
       → 可能 t3 >= endTime → 交易被拒绝

潜在窗口: t3 - t1, 取决于网络延迟和区块打包速度
```

**防御层次**:
1. KVrfVoteBeginTime (10秒) 提供缓冲
2. 交易验证时再次检查 (algorithm.cpp:710)
3. SaveBlock 时 addVoteCount 不检查时间窗口（假设验证已通过）

**残余风险**: 如果 endTime 临近, 交易在广播验证时通过但被打包区块时已过时。协议处理方式: 验证失败返回 -34 (algorithm.cpp:714)，交易不会被包含在区块中。

### 6.2 提案 TOCTOU

与投票类似，PROPOSAL 交易的 beginTime 在两处校验:
- 构建时: txhelper.cpp:4362 (currentTime - KVrfVoteBeginTime > beinTime → 拒绝)
- 验证时: algorithm.cpp:619 (tx.time() - KVrfVoteBeginTime > proposalStartTime → 拒绝)

### 6.3 lockValue 竞态

**问题**: GetLockValue() 在投票构建时期和SaveBlock时获取的锁定值可能不一致。

```
时刻线:
  t1: VoteTrans::trans() 调用 GetLockValue(addr) → lockValue = X
  t2: 用户发起 UNLOCK 交易
  t3: UNLOCK 先被打包 → lockValue 变为 0
  t4: VOTE 被打包
       → verifyTransactionRequest: GetLockValue(addr) → lockValue = 0
       → voteNumber 从 txInfo 读取 = X (旧的锁定值)
       → lockValue(0) != voteNumber(X) → 验证失败 -702 (algorithm.cpp:2259)
```

**结论**: 协议通过交易打包时重新验证 lockValue == voteNumber 来防止此竞态。如果解锁先于投票上链，投票将失败。

---

## 7. 完整生命周期异步任务流

```mermaid
flowchart TB
    subgraph Phase1["1. 提案阶段"]
        P1["创始账号提交PROPOSAL交易"] --> P2["广播到网络"]
        P2 --> P3["节点验证: version, time, minVote, 创始账号"]
        P3 --> P4["SaveBlock: setAssetType, setProposalInfo, 初始化票数0"]
        P4 --> P5{"达到beginTime?"}
    end

    subgraph Phase2["2. 锁定阶段"]
        L1["用户提交LOCK交易"] --> L2["校验: LOCK_AMOUNT, 无重复锁定"]
        L2 --> L3["SaveBlock: LOCK_MUTEX保护, setLockAddrUtxo"]
        L3 --> L4["用户获得投票权 (GetLockValue = 锁定金额/kDecimalNum)"]
    end

    subgraph Phase3["3. 投票阶段"]
        V1["用户提交VOTE交易"] --> V2["校验: CheckVoteTxInfo时间窗口"]
        V2 --> V3["广播验证: lockValue==voteNumber"]
        V3 --> V4{"SaveBlock: addVoteCount"}
        V4 --> V5["CheckForDuplicateVotes去重"]
        V5 --> V6["写入APPROVE:或AGAINST:"]
    end

    subgraph Phase4["4. 结果判定 (惰性)"]
        E1["GetAssetTypeIsValid()被调用"] --> E2{"now > endTime?"}
        E2 -->|No| E3["返回-2 (投票中)"]
        E2 -->|Yes| E4["GetVoteNum()统计"]
        E4 --> E5{"approveNum>againstNum AND<br/>totalVoters>=minVote?"}
        E5 -->|Yes| E6["✓ 提案通过"]
        E5 -->|No| E7["✗ 提案否决"]
    end

    subgraph Phase5["5. 解锁阶段"]
        UL1["用户提交UNLOCK交易"] --> UL2["校验: IsQualifiedToUnLock"]
        UL2 --> UL3["30天锁定期检查"]
        UL3 --> UL4["removeLockAddrUtxo → 失去投票权"]
    end

    Phase1 --> Phase2
    Phase2 --> Phase3
    Phase3 --> Phase4
    Phase3 --> Phase5

    style Phase1 fill:#e3f2fd,stroke:#1565c0
    style Phase2 fill:#e8f5e9,stroke:#2e7d32
    style Phase3 fill:#fff3e0,stroke:#e65100
    style Phase4 fill:#f3e5f5,stroke:#7b1fa2
    style Phase5 fill:#ffebee,stroke:#c62828
```

---

## 8. 异步安全总结

| 机制 | 实现方式 | 文件:行号 | 安全评级 |
|------|---------|----------|---------|
| LOCK_MUTEX | 锁定地址写入/删除保护 | algorithm.cpp:4370,6068 | 部分保护(UNLOCK未加锁) |
| 去重检查 | set查找 + DB读写分离 | algorithm.cpp:9179-9222 | 可靠(单线程区块处理) |
| TOCTOU-时间窗口 | 构建+验证双重检查 | algorithm.cpp:9479,619 | 有多重防护 |
| TOCTOU-lockValue | 构建+验证双重校验 | algorithm.cpp:2259,2249 | 协议级别防护 |
| 投票过期统计 | 惰性触发的GetVoteNum | algorithm.cpp:9162-9175 | 被动判定 |
| 30天锁定期 | 交易时间戳比较 | transaction.cpp:2916-2937 | 可靠 |
| VRF窗口 | 10秒预留 | algorithm.cpp:619,676 | 缓冲TOCTOU |

### 未解问题

1. UNLOCK 操作的 SaveBlock/RollBack 不受 LOCK_MUTEX 保护 — 如果同一区块内同时处理 LOCK 和 UNLOCK 可能有问题。【需人工验证: 确认区块内交易处理顺序保证不会同时处理同一地址的 LOCK/UNLOCK】

2. 无显式的周期性自动投票统计定时器 — 投票结果依赖外部查询触发。如果长时间无人查询，提案结果不会被自动执行。【需人工验证: 确认是否有其他触发机制(如区块打包时自动检查)】

3. `ReplaceCreateProposalTransaction` 和 `ReplaceCreateRevokeProposalTransaction` 被注释 (rpc_create_transaction.cpp:2999,3262) 但仍在 http_api.cpp:3652,3719 被调用。【需人工验证: 当前提案创建是否通过 console 命令(advanced_menu.cpp)或其它路径实现】
