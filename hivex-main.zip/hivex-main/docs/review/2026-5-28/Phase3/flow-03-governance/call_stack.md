# MeMeChain 治理流程函数调用栈

## 1. 锁定流程 (CreateLock -> LockTrans -> UTXO -> DB)

```
RPC入口:
  rpc/api/post/rpc_api_lock.cpp:16              createLock(request, response)
    └─ rpc_api_lock.cpp:46                        Util::stringToDecimal(lock_amount) [金额解析]
    └─ rpc_api_lock.cpp:53                        LockTrans::LockTransParam param_t 构造
    └─ rpc_api_lock.cpp:69                        LockTrans lockt(param_t)

交易构建:
  ca/transaction/lock.cpp:11                     LockTrans::trans()
    ├─ lock.cpp:15                                 transactionDiscoveryHeight() [获取当前高度]
    ├─ lock.cpp:25                                 TxHelper::Check(addressVector, ASSET_TYPE_VOTE, top+1)
    │   └─ ca/txhelper.cpp:609                    [地址/资产类型/高度校验]
    ├─ lock.cpp:32                                 isValidAddress(lock_addr) [地址格式校验]
    ├─ lock.cpp:37                ⚠️              s_lock_param.lock_amount >= LOCK_AMOUNT * kDecimalNum
    │   [错误日志中打印kDecimalNum而非LOCK_AMOUNT*kDecimalNum, 提示信息不准确]    【需人工验证】
    ├─ lock.cpp:56                                 dbReader.getLockAddrUtxo(addr, ASSET_TYPE_VOTE, utxos)
    │   └─ db/db_api.cpp:647                DBReader::getLockAddrUtxo()
    │       └─ key = "assettype2lockutxos_" + addr + "Vote"  [拼接读取key]
    │   [返回值检查: DB_NOT_FOUND视为初次锁定, 否则已锁定拒绝]                  (lock.cpp:57-61)
    ├─ lock.cpp:74                                 createUtxoTransferFrom(u, vin_param, 0) [UTXO构造]
    │   └─ ca/transaction/utxo_core.cpp            [UTXO转移核心, 从地址的Vote余额中扣除]
    ├─ lock.cpp:93                                 GetUTCTimestamp() [获取当前时间戳]
    ├─ lock.cpp:113                                vout[0]: VIRTUAL_LOCK_ADDRESS("LockVirtualStake"), lock_amount
    │                                             [锁定金额转入虚拟地址]
    ├─ lock.cpp:117                                vout[1]: lock_addr, total-expend [找零返回用户]
    ├─ lock.cpp:128                                vout[2]: VirtualBurnGas, gas [Gas燃烧]
    ├─ lock.cpp:144                                set_version(CURRENT_TRANSACTION_VERSION)
    ├─ lock.cpp:147                                set_type(LOCK=9)
    ├─ lock.cpp:150                                TxHelper::fetchIdentityNodes() [VRF分片身份选择]
    └─ lock.cpp:161                                return true

消息发送:
  ca/transaction/lock.cpp:165                    LockTrans::goMessage()
    ├─ lock.cpp:181                                TxHelper::get_tx_utxo_height() [获取UTXO高度]
    ├─ lock.cpp:194                                identity == defaultAddr ? handleTransaction(msg,tx) : DropShippingTransaction(...)
    │   [本节点是打包者则本地处理, 否则委托发送]

交易验证(SaveBlock路径):
  ca/algorithm.cpp:400-409                       TxType::LOCK (verifyTransactionRequest)
    ├─ algorithm.cpp:402                           isLock = true; lockQuantity = txInfo["LockAmount"]
    ├─ algorithm.cpp:404                           kLockTypeNet 校验 [锁类型必须为"LockNet"]
    ├─ algorithm.cpp:2093-2104                    LOCK tx 验证 (verifyTransactionRequest第二阶段)
    │   ├─ algorithm.cpp:2096                      utxo.assettype() == ASSET_TYPE_VOTE ["Vote"]
    │   ├─ algorithm.cpp:2099                      getLockAddrUtxo(owner, ASSET_TYPE_VOTE, utxos)
    │   └─ algorithm.cpp:2100-2103                DB_SUCCESS → "There has been a lock transaction before" → -700
    │                                              [重复锁定拒绝]
    └─ algorithm.cpp:1130-1152                    LOCK tx VOUT校验
        ├─ algorithm.cpp:1132                      i==0: vout.addr == VIRTUAL_LOCK_ADDRESS && vout.value == lockQuantity
        ├─ algorithm.cpp:1139                      vout.value >= LOCK_AMOUNT * kDecimalNum
        ├─ algorithm.cpp:1144                      i==1: isValidAddress(vout.addr)
        └─ algorithm.cpp:1148                      i>=3: return -74 [多余vout拒绝]

SaveBlock写入:
  ca/algorithm.cpp:4335-4410                     TxType::LOCK (SaveBlock)
    ├─ algorithm.cpp:4337                          txInfo["LockAmount"] 获取
    ├─ algorithm.cpp:4370                          lock_guard LOCK_MUTEX
    ├─ algorithm.cpp:4371                          dbWriter.setLockAddrUtxo(addr, ASSET_TYPE_VOTE, tx.hash())
    │   └─ db/db_api.cpp:1491               DBReadWriter::setLockAddrUtxo()
    │       └─ key = "assettype2lockutxos_" + addr + "Vote" + "_" + utxo
    ├─ algorithm.cpp:4378                          dbWriter.getTotalLockedAmonut()
    ├─ algorithm.cpp:4388                          totalLockedAmount += lockAmount
    └─ algorithm.cpp:4389                          dbWriter.setTotalLockedAmonut()

RollBack(撤销):
  ca/algorithm.cpp:6050-6100                     TxType::LOCK (RollBack)
    ├─ algorithm.cpp:6068                          lock_guard LOCK_MUTEX
    ├─ algorithm.cpp:6069                          removeLockAddrUtxo(addr, ASSET_TYPE_VOTE, tx.hash())
    ├─ algorithm.cpp:6075                          若无剩余锁定UTXO → removeLockAddr(addr)
    ├─ algorithm.cpp:6086                          getTotalLockedAmonut()
    └─ algorithm.cpp:6093                          totalLockedAmount -= lockAmount
```

## 2. 投票流程 (CreateVote -> VoteTrans -> 校验 -> 计票)

```
RPC入口:
  rpc/api/post/rpc_api_vote.cpp:18              createVote(request, response)
    ├─ rpc_api_vote.cpp:51                         ca_algorithm::GetVoteAssetType(voteAsset)
    │   └─ ca/algorithm.cpp:8476            GetVoteAssetType()
    │       ├─ algorithm.cpp:8480                  db.getAssetType(ASSERT_TYPES) [获取所有资产类型]
    │       ├─ algorithm.cpp:8495                  for each: getProposalInfoByAssetType(t, info)
    │       ├─ algorithm.cpp:8507                  time>=beginTime && time<endTime → PROPOSAL可投票
    │       │   └─ algorithm.cpp:8522              voteAsset[t] = proposalInfo
    │       ├─ algorithm.cpp:8526                  time>=endTime → 检查撤销提案
    │       └─ algorithm.cpp:8553                  time>=beginTime2 && time<endTime2 → REVOKEPROPOSAL可投票
    ├─ rpc_api_vote.cpp:80                         voteHash 在 voteAsset 中的查找校验
    ├─ rpc_api_vote.cpp:116-128                    VoteTrans::VoteTransParam 构造
    └─ rpc_api_vote.cpp:128                        VoteTrans votet(param_t)

交易构建:
  ca/transaction/vote.cpp:13                     VoteTrans::trans()
    ├─ vote.cpp:15                                 transactionDiscoveryHeight() [获取当前高度]
    ├─ vote.cpp:22                                 isValidAddress(addr) [地址格式]
    ├─ vote.cpp:29                                 TxHelper::Check(fromaddr, gas.asset_type, top+1)
    ├─ vote.cpp:37                                 db.getAssetType(assertTypes)
    ├─ vote.cpp:51                 ⚠️              ca_algorithm::GetLockValue(addr, lockValue)
    │   └─ ca/algorithm.cpp:9572            GetLockValue()
    │       ├─ algorithm.cpp:9576                  getLockAddrUtxo(addr, ASSET_TYPE_VOTE, utxos)
    │       ├─ algorithm.cpp:9583                  std::reverse(utxos) [取最后一条锁定UTXO]
    │       ├─ algorithm.cpp:9587                  getTransactionByHash(utxo, txRaw)
    │       ├─ algorithm.cpp:9595                  tx.ParseFromString(txRaw)
    │       ├─ algorithm.cpp:9606                  遍历vout找 VIRTUAL_LOCK_ADDRESS → lockValue
    │       └─ algorithm.cpp:9615                  lockValue / kDecimalNum → 投票权重
    ├─ vote.cpp:60                 ⚠️              ca_algorithm::CheckVoteTxInfo(voteHash, txType, voteType, currentTime)
    │   └─ ca/algorithm.cpp:9422            CheckVoteTxInfo()
    │       ├─ algorithm.cpp:9424                  pollType: Approve(1) 或 Against(0) 校验
    │       ├─ algorithm.cpp:9433                  PROPOSAL分支:
    │       │   ├─ algorithm.cpp:9436              db.getProposalInfoByAssetType(voteHash, info)
    │       │   ├─ algorithm.cpp:9444              Base64Decode + json.parse
    │       │   ├─ algorithm.cpp:9445              beginTime = dataJson["BeginTime"]
    │       │   └─ algorithm.cpp:9446              endTime = dataJson["EndTime"]
    │       ├─ algorithm.cpp:9448                  REVOKEPROPOSAL分支:
    │       │   ├─ algorithm.cpp:9451              db.getRevokeProposalInfoByAssetType(voteHash, info)
    │       │   ├─ algorithm.cpp:9459              Base64Decode + json.parse
    │       │   ├─ algorithm.cpp:9460              proposalHash = dataJson["ProposalHash"]
    │       │   ├─ algorithm.cpp:9461              beginTime, endTime 获取
    │       │   └─ algorithm.cpp:9465              GetAssetTypeIsValid(proposalHash) [提案有效性]
    │       └─ algorithm.cpp:9479    🔴  TOCTOU   currentTime < beginTime || currentTime >= endTime → -6
    │           [TOCTOU 风险点: 交易构建时通过, 但到上链时可能已过窗口]
    ├─ vote.cpp:81                                 createUtxoGasBylameda() [Lambda方式构建Gas UTXO]
    │   └─ vote.cpp:87                             makeTxData(&tx)
    │       └─ ca/transaction/vote.cpp:233  VoteTrans::makeTxData()
    │           ├─ vote.cpp:235                    txInfo["VoteHash"] = vote_hash
    │           ├─ vote.cpp:236                    txInfo["VoteTxType"] = tx_type
    │           ├─ vote.cpp:237                    txInfo["VoteType"] = vote_type
    │           └─ vote.cpp:238                    txInfo["VoteNumber"] = lockValue [锁定金额=投票权重]
    ├─ vote.cpp:110                                set_type(VOTE=13)
    ├─ vote.cpp:119                                TxHelper::fetchIdentityNodes() [VRF分片]
    └─ vote.cpp:131                                return true

交易验证(SaveBlock):
  ca/algorithm.cpp:704-717                       TxType::VOTE (verifyTransactionRequest)
    ├─ algorithm.cpp:706                          voteHash = txInfo["VoteHash"]
    ├─ algorithm.cpp:707                          voteTxType = txInfo["VoteTxType"]
    ├─ algorithm.cpp:708                          pollType = txInfo["VoteType"]
    └─ algorithm.cpp:710                          ca_algorithm::CheckVoteTxInfo(voteHash, voteTxType, pollType, tx.time(), saveType)
        [广播端再次校验时间窗口]

  ca/algorithm.cpp:2230-2264                     VOTE tx 深度验证 (第二阶段)
    ├─ algorithm.cpp:2232                          utxo.assettype() == ASSET_TYPE_VOTE
    ├─ algorithm.cpp:2235                          dbReader.getAssetType(assertTypes)
    ├─ algorithm.cpp:2243                          创始账号特殊情况: lockValue=1
    ├─ algorithm.cpp:2249                          GetLockValue(owner, lockValue) [再次获取锁定金额]
    ├─ algorithm.cpp:2257                          voteNumber = txInfo["VoteNumber"]
    └─ algorithm.cpp:2259               ⚠️         lockValue MUST EQUAL voteNumber [-702]

计票写入(SaveBlock):
  ca/algorithm.cpp:4929-4952                     TxType::VOTE (SaveBlock)
    ├─ algorithm.cpp:4932                          voteHash, pollType, voteNumber 从txInfo读取
    └─ algorithm.cpp:4939               ⚠️         ca_algorithm::addVoteCount(dbWriter, voteHash, pollType, owner, voteNumber)
        └─ ca/algorithm.cpp:9228            addVoteCount()
            ├─ algorithm.cpp:9239    🔴            CheckForDuplicateVotes(assetType, addr)
            │   └─ ca/algorithm.cpp:9179    CheckForDuplicateVotes()
            │       ├─ algorithm.cpp:9192          db.getApproveAddrsByAssetType(assetType, addrs)
            │       ├─ algorithm.cpp:9200          addrs.find(addr) != end() → -4 [赞成重复]
            │       ├─ algorithm.cpp:9208          db.getAgainstAddrsByAssetType(assetType, addrs)
            │       └─ algorithm.cpp:9216          addrs.find(addr) != end() → -6 [反对重复]
            ├─ algorithm.cpp:9248                  GetVoteNum(db, assetType, approveNum, againstNum)
            │   └─ ca/algorithm.cpp:9162    GetVoteNum()
            │       └─ algorithm.cpp:9169          db.getVoteCountByAssetType(assetType, approveNum, againstNum)
            ├─ algorithm.cpp:9255                  Approve分支: approveNum += voteNumber
            │   └─ algorithm.cpp:9258              db.setApproveAddrsByAssetType(assetType, addr)  [APPROVE:前缀]
            ├─ algorithm.cpp:9264                  Against分支: againstNum += voteNumber
            │   └─ algorithm.cpp:9267              db.setAgainstAddrsByAssetType(assetType, addr)  [AGAINST:前缀]
            ├─ algorithm.cpp:9279                  db.setVoteCountByAssetType(assetType, approveNum, againstNum)
            ├─ algorithm.cpp:9285                  db.setVoteCountByAddr(addr, assetType, voteNumber)
            └─ algorithm.cpp:9303                  db.setTotalCountByAssetType(assetType, ++totalNumberOfVoters)

计票回滚(RollBack):
  ca/algorithm.cpp:6628+                         TxType::VOTE (RollBack)
    └─ ca_algorithm::subVoteNum(dbWriter, voteHash, pollType, owner, voteNumber)
        └─ ca/algorithm.cpp:9313            subVoteNum()
            ├─ algorithm.cpp:9326                  GetVoteNum() [获取当前票数]
            ├─ algorithm.cpp:9334                  getVoteCountByAddr(addr, assetType, voteNum)
            ├─ algorithm.cpp:9340                  voteNum == voteNumber [数据一致性校验]
            ├─ algorithm.cpp:9346                  赞成: approveNum -= voteNum
            │   └─ algorithm.cpp:9354              db.removeApproveAddrsByAssetType(assetType, addr)
            ├─ algorithm.cpp:9360                  反对: againstNum -= voteNum
            │   └─ algorithm.cpp:9368              db.removeAgainstAddrsByAssetType(assetType, addr)
            ├─ algorithm.cpp:9380                  db.setVoteCountByAssetType(assetType, approveNum, againstNum)
            ├─ algorithm.cpp:9386                  db.removeVoteCountByAddr(addr, assetType)
            └─ algorithm.cpp:9408-9417             totalNumberOfVoters-- [或清零]
```

## 3. 解锁流程 (CreateUnlock -> UnlockTrans -> UTXO释放)

```
RPC入口:
  rpc/api/post/rpc_api_unlock.cpp:18            createUnlock(request, response)
    ├─ rpc_api_unlock.cpp:48                       Gas类型 != ASSET_TYPE_VOTE 校验
    ├─ rpc_api_unlock.cpp:62                       encodedInfo.size() <= 1024 长度限制
    ├─ rpc_api_unlock.cpp:76-84                    UnlockTrans::UnlockTransParam 构造
    └─ rpc_api_unlock.cpp:85                       UnlockTrans unlockt(param_t)

交易构建:
  ca/transaction/unlock.cpp:10                   UnlockTrans::trans()
    ├─ unlock.cpp:14                               transactionDiscoveryHeight()
    ├─ unlock.cpp:25                               TxHelper::Check(addressVector, ASSET_TYPE_VOTE, top+1)
    ├─ unlock.cpp:32                               isValidAddress(lock_addr)
    ├─ unlock.cpp:40               ⚠️              IsQualifiedToUnLock(lock_addr, utxo_hash, lock_amount, ASSET_TYPE_VOTE)
    │   └─ ca/transaction.cpp:2449          IsQualifiedToUnLock()
    │       ├─ transaction.cpp:2453                dbReader.getLockAddr(addresses) [获取所有锁定地址]
    │       ├─ transaction.cpp:2458                find(addresses, fromAddr) [地址在锁定列表中]
    │       ├─ transaction.cpp:2465                dbReader.getLockAddrUtxo(fromAddr, ASSET_TYPE_VOTE, utxos)
    │       ├─ transaction.cpp:2470                find(utxos, utxoHash) [UTXO在锁定列表中]
    │       ├─ transaction.cpp:2476    🔴         isMoreThan30DaysForUnstake(utxoHash)
    │       │   └─ ca/transaction.cpp:2916  isMoreThan30DaysForUnstake()
    │       │       ├─ transaction.cpp:2921        getTransactionByHash(utxo, strTransaction)
    │       │       ├─ transaction.cpp:2929        nowTime - lock_tx.time() >= 30*24*3600*10^6
    │       │       │   [主网: 30天; Dev网: 60秒]                               (transaction.cpp:2930-2933)
    │       │       └─ transaction.cpp:2937        return bool
    │       ├─ transaction.cpp:2484                getTransactionByHash(utxoHash, stakeTransaction)
    │       ├─ transaction.cpp:2491                ParseFromString
    │       ├─ transaction.cpp:2496-2506           遍历utxo找VIRTUAL_LOCK_ADDRESS → lockedAmount
    │       └─ transaction.cpp:2508                lockedAmount >= LOCK_AMOUNT * kDecimalNum
    ├─ unlock.cpp:50                               txUtxo->add_owner(lock_addr)
    ├─ unlock.cpp:55                               vin->prevout: hash=utxo_hash, n=1 [指向被解锁的UTXO]
    ├─ unlock.cpp:69                               createUtxoTransferFrom(txUtxo, vin_param, 1)
    ├─ unlock.cpp:112                              vout[0]: lock_addr, lock_amount [释放锁定金额]
    ├─ unlock.cpp:116                              vout[1]: lock_addr, total-expend [找零]
    ├─ unlock.cpp:146                              set_type(UNLOCK=10)
    └─ unlock.cpp:155                              fetchIdentityNodes() [VRF分片]

交易验证:
  ca/algorithm.cpp:411-419                       TxType::UNLOCK (verifyTransactionRequest)
    ├─ algorithm.cpp:413                           isUnLock = true
    └─ algorithm.cpp:414                           redeemUtxoHashValue = txInfo["UnLockUtxo"]

  ca/algorithm.cpp:2106-2127                     UNLOCK tx验证 (第二阶段)
    ├─ algorithm.cpp:2108                          utxo.assettype() == ASSET_TYPE_VOTE
    ├─ algorithm.cpp:2111                          setOwner.size() == 1 [单所有者]
    ├─ algorithm.cpp:2117               ⚠️         IsQualifiedToUnLock(owner, lockUtxo, amount, utxo.assettype())
    │   [广播端再次校验解锁资格]
    └─ algorithm.cpp:2123                          vout[0].addr == owner [释放回原地址]

SaveBlock写入:
  ca/algorithm.cpp:4436-4485                     TxType::UNLOCK (SaveBlock)
    ├─ algorithm.cpp:4442                          redeemUtxoHashValue = txInfo["UnLockUtxo"]
    ├─ algorithm.cpp:4478                          dbWriter.removeLockAddrUtxo(addr, ASSET_TYPE_VOTE, redeemUtxoHashValue)
    │   └─ db/db_api.cpp:1497               DBReadWriter::removeLockAddrUtxo()
    │       └─ key = "assettype2lockutxos_" + addr + "Vote" [移除锁定UTXO]
    └─ algorithm.cpp:4484                          若无剩余锁定UTXO → removeLockAddr(addr)

撤销:
  ca/algorithm.cpp:6178-6218                     TxType::UNLOCK (RollBack)
    ├─ algorithm.cpp:6182                          isUnLock = true
    ├─ algorithm.cpp:6183                          redeemUtxoHashValue = txInfo["UnLockUtxo"]
    ├─ algorithm.cpp:6196                          dbWriter.setLockAddrUtxo(addr, ASSET_TYPE_VOTE, redeemUtxoHashValue)
    │   [回滚: 恢复锁定UTXO记录]
    └─ algorithm.cpp:6210                          dbWriter.setLockAddr(addr) [恢复锁地址记录]
```

## 4. 提案创建流程 (CreateProposal -> TxHelper -> 广播)

```
RPC入口:
  api/interface/http_api.cpp:3594               _GetProposal(request, response)
    ├─ http_api.cpp:3607                          regex校验 duration格式
    ├─ http_api.cpp:3634                          beginTime = GetUTCTimestamp()
    ├─ http_api.cpp:3635                          endTime = beginTime + time*3600*1000000
    ├─ http_api.cpp:3638                          regex校验 minVoteNum
    ├─ http_api.cpp:3648-3651                     参数提取: peerChainTokenAddr, contractAddr, crossChainInvestmentContractAddr, taskType
    └─ http_api.cpp:3652                          ReplaceCreateProposalTransaction(fromAddr, gasTrade, ...)
        ⚠️ 注意: 该函数在rpc_create_transaction.cpp:2999被注释掉
             但http_api.cpp中仍被调用 → 【需人工验证】当前是否可用

交易构建(实际可用路径):
  ca/txhelper.cpp:4188                           TxHelper::CreateProposalTransaction(fromAddr, height, outTx, type, ...)
    ├─ txhelper.cpp:4195                           fromAddr == GetInitAccountAddr() [创始账号独占]
    ├─ txhelper.cpp:4200                           ca_algorithm::CheckProposaInfo(rate, contractAddr, ...)
    │   └─ ca/algorithm.cpp:8981            CheckProposaInfo()
    │       └─ 汇率范围, 合约地址, CrossChainTxType, minVote, 资产名称校验
    ├─ txhelper.cpp:4278                           txInfo["Version"] = KProposalInfoVersion(0)
    ├─ txhelper.cpp:4279                           txInfo["BeginTime"] = beinTime
    ├─ txhelper.cpp:4280                           txInfo["EndTime"] = endTime
    ├─ txhelper.cpp:4281                           txInfo["ExpirationDate"] = UINT64_MAX
    ├─ txhelper.cpp:4282-4291                      汇率/跨链/合约地址/canBeStake/MIN_VOTE_NUM写入
    ├─ txhelper.cpp:4362    🔴                     currentTime - KVrfVoteBeginTime > beinTime → 拒绝
    │   [TOCTOU: 构建时校验, 上链时可能已过期]
    ├─ txhelper.cpp:4373                           set_type(PROPOSAL=11)
    └─ txhelper.cpp:4413                           TxHelper::fetchIdentityNodes() [VRF分片]

交易验证(广播端):
  ca/algorithm.cpp:595-662                       TxType::PROPOSAL (verifyTransactionRequest)
    ├─ algorithm.cpp:614                           proposalVersion == KProposalInfoVersion(0)
    ├─ algorithm.cpp:619    🔴                     tx.time() - KVrfVoteBeginTime > proposalStartTime → -25
    │   [TOCTOU: 上链时再校验, 可能已过期]
    ├─ algorithm.cpp:623                           proposalEndTime - proposalStartTime >= KVoteCycle(10分钟)
    ├─ algorithm.cpp:628                           CheckProposaInfo() [提案信息校验]
    ├─ algorithm.cpp:634                           expirationDate == UINT64_MAX [未过期]
    ├─ algorithm.cpp:639                           AssetTypeListIsEmpty() [获取已有资产类型数量]
    ├─ algorithm.cpp:646                           canBeStake == isEmpty [一致性校验]
    ├─ algorithm.cpp:651                           title.size() <= 1024
    └─ algorithm.cpp:656                           identifier.size() <= 1024

SaveBlock写入:
  ca/algorithm.cpp:4874-4902                     TxType::PROPOSAL (SaveBlock)
    ├─ algorithm.cpp:4876                          setAssetType(tx.hash()) [注册资产类型]
    ├─ algorithm.cpp:4881                          setVoteCountByAssetType(tx.hash(), 0, 0) [初始化票数]
    ├─ algorithm.cpp:4886-4895                     setProposalInfoByAssetType(tx.hash(), base64(proposalInfo))
    └─ algorithm.cpp:4896-4900                     setAssetTypeByContractAddr(contractAddr, tx.hash())

撤销:
  ca/algorithm.cpp:6559-6594                     TxType::PROPOSAL (RollBack)
    ├─ algorithm.cpp:6561                          removeAssetType(tx.hash())
    ├─ algorithm.cpp:6566                          GetVoteNum() [获取当前票数]
    ├─ algorithm.cpp:6573                          approveNum==0 && againstNum==0 [只能撤销无投票的提案]
    ├─ algorithm.cpp:6578                          removeVoteCountByAssetType(tx.hash())
    ├─ algorithm.cpp:6583                          removeProposalInfoByAssetType(tx.hash())
    └─ algorithm.cpp:6590                          removeAssetTypeByContractAddr(contractAddr)
```

## 5. 撤销提案流程 (CreateRevokeProposal)

```
RPC入口:
  api/interface/http_api.cpp:3657               _GetRevokeProposal(request, response)
    ├─ http_api.cpp:3681                          duration校验, beginTime/endTime计算
    ├─ http_api.cpp:3710                          minVote >= 1
    └─ http_api.cpp:3719                          ReplaceCreateRevokeProposalTransaction(...)
        [同样被注释, 需验证]

交易构建(实际可用路径):
  ca/txhelper.cpp:4429                           TxHelper::CreateRevokeProposalTransaction(fromAddr, ...)
    ├─ txhelper.cpp:4440                           fromAddr == GetInitAccountAddr() [创始账号独占]
    ├─ txhelper.cpp:4593    🔴                     currentTime - KVrfVoteBeginTime > beinTime → 拒绝
    ├─ txhelper.cpp:4625                           set_type(REVOKEPROPOSAL=12)
    └─ txhelper.cpp:4645                           fetchIdentityNodes()

交易验证:
  ca/algorithm.cpp:663-703                       TxType::REVOKEPROPOSAL (verifyTransactionRequest)
    ├─ algorithm.cpp:671                           version == KRevokeProposalInfoVersion(0)
    ├─ algorithm.cpp:676                           beginTime时间校验
    ├─ algorithm.cpp:680                           endTime-beginTime >= KVoteCycle
    ├─ algorithm.cpp:685                           GetAssetTypeIsValid(revokeHash) [被撤销提案有效性]
    ├─ algorithm.cpp:691                           canBeRevoked(revokeHash) [无进行中的撤销]
    │   └─ ca/algorithm.cpp:8945            canBeRevoked()
    │       ├─ algorithm.cpp:8949                  getRevokeTxHashByAssetType(assetType, revokeTxHashs)
    │       ├─ algorithm.cpp:8950                  DB_NOT_FOUND → 可撤销(无进行中撤销)
    │       ├─ algorithm.cpp:8961                  getRevokeProposalInfoByAssetType(最新撤销提案)
    │       └─ algorithm.cpp:8972                  time > endTime → 前次撤销已结束 → 可撤销
    └─ algorithm.cpp:697                           minVote >= 1

SaveBlock写入:
  ca/algorithm.cpp:4903-4928                     TxType::REVOKEPROPOSAL (SaveBlock)
    ├─ algorithm.cpp:4906                          proposalHash = txInfo["ProposalHash"]
    ├─ algorithm.cpp:4913                          setRevokeProposalInfoByAssetType(tx.hash(), base64)
    └─ algorithm.cpp:4923                          setVoteCountByAssetType(tx.hash(), 0, 0)
```

## 6. 投票结果判定

```
入口:
  ca/algorithm.cpp:8602                           GetAssetTypeIsValid(assetType, proposalInfo*)
    ├─ algorithm.cpp:8608                          getProposalInfoByAssetType [获取提案信息]
    ├─ algorithm.cpp:8623    🔴                    time <= endTime || time > expirationDate → 返回错误
    │   [投票窗口未关闭或已过期 → 提案未完成验证]
    ├─ algorithm.cpp:8631               ⚠️         GetVoteNum(db, assetType, approveNum, againstNum)
    │   └─ ca/algorithm.cpp:9162            GetVoteNum()
    │       └─ db.getVoteCountByAssetType(assetType, approveNum, againstNum)
    ├─ algorithm.cpp:8639                          getTotalCountByAssetType(assetType, totalNumberOfVoters)
    ├─ algorithm.cpp:8650    🔴                    totalNumberOfVoters < minVote → -5 [投票人数不足]
    ├─ algorithm.cpp:8655    🔴                    approveNum <= againstNum → -6 [提案失败]
    ├─ algorithm.cpp:8686                          getRevokeTxHashByAssetType(assetType, revokeTxHashs)
    │   [获取撤销提案列表]
    ├─ algorithm.cpp:8687                          DB_NOT_FOUND → flag=true, return 0 [提案有效]
    ├─ algorithm.cpp:8699                          getRevokeProposalInfoByAssetType(最新撤销提案)
    ├─ algorithm.cpp:8710    🔴                    time <= endTime2 → 撤销投票未结束 → 提案仍有效
    ├─ algorithm.cpp:8716               ⚠️         GetVoteNum(db, 撤销提案, approveNum, againstNum)
    ├─ algorithm.cpp:8724                          getTotalCountByAssetType(撤销提案, totalNumberOfVoters2)
    ├─ algorithm.cpp:8735                          totalNumberOfVoters2 < minVote → 撤销失败 → 提案仍有效
    └─ algorithm.cpp:8742                          againstNum >= approveNum → flag=true → 撤销通过 → 提案失效
```

## 数据库Key前缀

| 操作 | Key前缀 | 源文件:行号 |
|------|---------|------------|
| LOCK地址列表 | `lockaddr_` | db_api.cpp:17, 638, 1483-1488 |
| LOCK UTXO | `assettype2lockutxos_<addr><assetType>` | db_api.cpp:18, 647-649, 1491-1500 |
| 资产类型列表 | `assetType`前缀 | db_api.cpp:4876 |
| 提案信息 | `ProposalInfo_<assetType>` | db_api.cpp:4891 |
| 撤销提案信息 | `RevokeProposalInfo_<assetType>` | db_api.cpp:4913 |
| 投票计数 | `VoteCount_<assetType>` | db_api.cpp:4881, 9279 |
| APPROVE地址 | `ApproveAddrs_<assetType>` | db_api.cpp:9258 |
| AGAINST地址 | `AgainstAddrs_<assetType>` | db_api.cpp:9267 |
| 投票交易 | `VoteTxHash_<assetType>` | db_api.cpp:4947 |
| 投票人数 | `TotalCount_<assetType>` | db_api.cpp:9303 |
| 锁定总量 | `TotalLockedAmount` | db_api.cpp:705, 1503 |

## 关键安全点总结

| 检查点 | 位置 | 防护作用 |
|--------|------|----------|
| 创始账号独占提案/撤销 | txhelper.cpp:4195, 4440 | 防止非授权提案 |
| LOCK_MUTEX锁保护 | algorithm.cpp:4370, 6068 | 锁定状态原子性 |
| 重复锁定拒绝(交易构建) | lock.cpp:56-61 | 账户级去重 |
| 重复锁定拒绝(广播验证) | algorithm.cpp:2099-2103 | 共识级去重 |
| 锁定金额==投票权重 | algorithm.cpp:2259 | 权重绑定 |
| CheckForDuplicateVotes(赞成) | algorithm.cpp:9190-9198 | 投票去重 |
| CheckForDuplicateVotes(反对) | algorithm.cpp:9207-9215 | 投票去重 |
| IsQualifiedToUnLock | transaction.cpp:2449-2514 | 解锁资格(30天+) |
| 时间窗口校验(beginTime~endTime) | algorithm.cpp:9479-9483 | 投票时效 |
| 投票人数门槛 | algorithm.cpp:8650 | 最低参与度 |
| 赞成>反对判定 | algorithm.cpp:8655 | 投票结果 |
