# MeMeChain 治理流程时序图

## 1. 提案创建流程

```mermaid
sequenceDiagram
    participant FA as 创始账号
    participant RPC as RPC API
    participant TH as TxHelper
    participant TX as 交易对象
    participant NET as 网络广播
    participant CA as ca_algorithm
    participant DB as RocksDB

    Note over FA,DB: 提案创建 (PROPOSAL tx_type=11)

    FA->>RPC: POST /CreateProposalTransaction
    RPC->>RPC: _GetProposal()<br/>api/interface/http_api.cpp:3594

    RPC->>RPC: beginTime = GetUTCTimestamp()<br/>http_api.cpp:3634
    RPC->>RPC: endTime = beginTime + duration*3600*1000000<br/>http_api.cpp:3635

    RPC->>TH: CreateProposalTransaction(fromAddr, gasTrade, ...)<br/>txhelper.cpp:4188

    TH->>TH: 校验 fromAddr == GetInitAccountAddr()<br/>【创始账号检查】
    TH->>CA: CheckProposaInfo(rate, contractAddr, ...)<br/>algorithm.cpp:8981
    CA-->>TH: 0=通过

    TH->>TH: txInfo["BeginTime"] = beinTime<br/>txInfo["EndTime"] = endTime<br/>txInfo["Version"] = KProposalInfoVersion(0)
    TH->>TH: 时间窗口校验:<br/>currentTime - KVrfVoteBeginTime <= beginTime<br/>(10秒预留)<br/>txhelper.cpp:4362

    TH->>TX: set_type(PROPOSAL=11)<br/>txhelper.cpp:4373

    TX-->>TH: 签名的完整交易
    TH-->>RPC: 返回交易JSON
    RPC-->>FA: 交易数据

    FA->>NET: 广播交易
    NET->>CA: verifyTransactionRequest()
    Note over CA: 提案校验规则:

    CA->>CA: BEGIN_TIME_CHECK:<br/>tx.time() - KVrfVoteBeginTime <= proposalStartTime<br/>algorithm.cpp:619

    CA->>CA: WINDOW_MIN_CHECK:<br/>endTime-beginTime >= KVoteCycle(10分钟)<br/>algorithm.cpp:623

    CA->>CA: VERSION_CHECK:<br/>version == KProposalInfoVersion(0)<br/>algorithm.cpp:614

    CA->>CA: EXPIRATION_CHECK:<br/>expirationDate == UINT64_MAX<br/>algorithm.cpp:634

    CA->>CA: canBeStake_CHECK:<br/>canBeStake == AssetTypeListIsEmpty()<br/>algorithm.cpp:646

    CA-->>NET: 校验通过

    NET->>DB: SaveBlock()写入

    DB->>DB: setAssetType(tx.hash())<br/>algorithm.cpp:4876
    DB->>DB: setVoteCountByAssetType(tx.hash(), 0, 0)<br/>algorithm.cpp:4881
    DB->>DB: setProposalInfoByAssetType(tx.hash(), base64)<br/>algorithm.cpp:4891
    DB->>DB: setAssetTypeByContractAddr(contractAddr, tx.hash())<br/>algorithm.cpp:4897

    Note over DB: 提案生效 - 投票窗口开始
```

## 2. 锁定流程 (获取投票权)

```mermaid
sequenceDiagram
    participant U as 用户
    participant RPC as RPC API
    participant LT as LockTrans
    participant TX as 交易对象
    participant NET as 网络广播
    participant CA as ca_algorithm
    participant DB as RocksDB
    participant LOCK as LOCK_MUTEX

    Note over U,DB: 锁定流程 (LOCK tx_type=9)

    U->>RPC: POST /CreateLockTransaction
    RPC->>RPC: createLock()<br/>rpc/api/post/rpc_api_lock.cpp:16

    RPC->>RPC: lock_amount >= LOCK_AMOUNT*kDecimalNum<br/>rpc_api_lock.cpp:46 (Util::stringToDecimal)

    RPC->>LT: LockTrans(param_t).trans()
    LT->>LT: LOCK_AMOUNT阈值检查:<br/>lock_amount >= LOCK_AMOUNT*kDecimalNum<br/>lock.cpp:37

    LT->>DB: getLockAddrUtxo(addr, ASSET_TYPE_VOTE)<br/>lock.cpp:56
    Note over DB: 【去重检查: 已锁定则拒绝】<br/>若已有锁定的UTXO，返回错误

    LT->>TX: 构建交易:
    LT->>TX: vout[0]: LockVirtualStake, lock_amount<br/>lock.cpp:113
    LT->>TX: vout[1]: 用户地址, 找零<br/>lock.cpp:117
    LT->>TX: vout[2]: VirtualBurnGas, gas<br/>lock.cpp:128

    LT->>TX: set_type(LOCK=9)<br/>lock.cpp:147

    LT->>TX: VRF分片身份选择<br/>lock.cpp:151

    LT-->>U: 签名交易

    U->>NET: 广播

    NET->>CA: verifyTransactionRequest()

    CA->>DB: getLockAddrUtxo(owner, ASSET_TYPE_VOTE)<br/>algorithm.cpp:2099
    Note over CA: 【双重去重: 交易广播端再次校验】<br/>已有锁定的拒绝打包

    CA->>CA: vout[0].addr == VIRTUAL_LOCK_ADDRESS<br/>且 vout[0].value >= LOCK_AMOUNT*kDecimalNum<br/>algorithm.cpp:1132

    CA-->>NET: 校验通过

    NET->>DB: SaveBlock()写入

    LOCK->>LOCK: lock_guard LOCK_MUTEX<br/>algorithm.cpp:4370
    DB->>DB: setLockAddrUtxo(addr, tx.hash())<br/>algorithm.cpp:4371
    DB->>DB: updateTotalLockedAmount<br/>algorithm.cpp:4388
    Note over LOCK: 释放LOCK_MUTEX

    Note over DB: 用户现在拥有投票权
```

## 3. 投票流程

```mermaid
sequenceDiagram
    participant U as 用户
    participant RPC as RPC API
    participant VT as VoteTrans
    participant CA as ca_algorithm
    participant NET as 网络广播
    participant DB as RocksDB

    Note over U,DB: 投票流程 (VOTE tx_type=13)

    U->>RPC: POST /CreateVoteTransaction
    RPC->>RPC: createVote()<br/>rpc/api/post/rpc_api_vote.cpp:18

    RPC->>CA: GetVoteAssetType()<br/>rpc_api_vote.cpp:51
    Note over CA: 获取所有可投票的资产类型<br/>检查投票时间窗口: beginTime <= time < endTime<br/>algorithm.cpp:8492-8572

    CA-->>RPC: voteAsset map<资产类型, 投票信息>

    RPC->>RPC: 校验 voteHash 在 voteAsset 中<br/>rpc_api_vote.cpp:80

    RPC->>VT: VoteTrans(param_t).trans()
    VT->>CA: GetLockValue(addr, lockValue)<br/>vote.cpp:51
    Note over CA: 获取用户的锁定Vote数量 = 投票权重<br/>algorithm.cpp:9572
    CA-->>VT: lockValue

    VT->>CA: CheckVoteTxInfo(voteHash, txType, voteType, currentTime)<br/>vote.cpp:60

    Note over CA: 【时间窗口检查】<br/>beginTime <= currentTime < endTime<br/>若提案(PROPOSAL), 解析提案信息获取窗口<br/>若撤销(REVOKEPROPOSAL), 追加校验提案有效性<br/>algorithm.cpp:9422-9482

    CA-->>VT: 0=通过

    VT->>VT: 投票数据写入: VoteHash, VoteTxType, VoteType, VoteNumber

    VT-->>U: 签名交易 (voteNumber=lockValue)

    U->>NET: 广播

    NET->>CA: verifyTransactionRequest()

    CA->>CA: CheckVoteTxInfo() [广播端再次校验]<br/>algorithm.cpp:710
    CA->>DB: getLockValue(owner) → lockValue<br/>algorithm.cpp:2249
    CA->>CA: lockValue MUST EQUAL voteNumber<br/>algorithm.cpp:2259

    CA-->>NET: 校验通过

    NET->>DB: SaveBlock()写入

    DB->>CA: addVoteCount(dbWriter, voteHash, voteType, owner, voteNumber)<br/>algorithm.cpp:4939

    CA->>CA: CheckForDuplicateVotes(voteHash, owner)<br/>algorithm.cpp:9179

    Note over CA: 【去重检查】<br/>1. 查询 APPROVE: 地址列表<br/>2. 查询 AGAINST: 地址列表<br/>3. addr 不在任一列表中则通过<br/>algorithm.cpp:9190-9222

    CA->>CA: GetVoteNum() 获取当前票数<br/>→ approveNum += voteNumber (赞成)<br/>→ againstNum += voteNumber (反对)

    CA->>DB: setApproveAddrsByAssetType / setAgainstAddrsByAssetType<br/>setVoteCountByAssetType→APPROVE:/AGAINST:前缀
    DB->>DB: setVoteTxHashByAssetType(voteHash, tx.hash())<br/>algorithm.cpp:4947
    DB->>DB: setVoteCountByAddr(addr, assetType, voteNumber)<br/>algorithm.cpp:9285
    DB->>DB: totalNumberOfVoters++<br/>algorithm.cpp:9303
```

## 4. 解锁流程 (失去投票权)

```mermaid
sequenceDiagram
    participant U as 用户
    participant RPC as RPC API
    participant UT as UnlockTrans
    participant TX as 交易对象
    participant NET as 网络广播
    participant CA as ca_algorithm
    participant DB as RocksDB

    Note over U,DB: 解锁流程 (UNLOCK tx_type=10)

    U->>RPC: POST /CreateUnLockTransaction
    RPC->>RPC: createUnlock()<br/>rpc/api/post/rpc_api_unlock.cpp:18

    RPC->>RPC: Gas资产类型 != ASSET_TYPE_VOTE<br/>(不能用锁定的Vote付gas)<br/>rpc_api_unlock.cpp:48

    RPC->>UT: UnlockTrans(param_t).trans()

    UT->>CA: IsQualifiedToUnLock(fromAddr, utxoHash, lockedAmount, ASSET_TYPE_VOTE)<br/>unlock.cpp:40

    Note over CA: 【解锁资格检查】<br/>1. 地址在锁定地址列表中<br/>2. utxoHash在锁定UTXO列表中<br/>3. 锁定超过30天(主网)/1分钟(开发)<br/>4. 解析LOCK交易的vout[0]获取锁定金额<br/>transaction.cpp:2449-2514

    CA-->>UT: 0=通过 + lock_amount

    UT->>TX: vin[0]指向被锁定的UTXO<br/>unlock.cpp:56-58
    UT->>TX: vout[0]: 用户地址, lock_amount(释放)<br/>unlock.cpp:112
    UT->>TX: vout[1]: 用户地址, 找零<br/>unlock.cpp:116

    UT->>TX: set_type(UNLOCK=10)<br/>unlock.cpp:146

    UT-->>U: 签名交易

    U->>NET: 广播

    NET->>CA: verifyTransactionRequest()

    CA->>CA: utxo.assettype() == ASSET_TYPE_VOTE<br/>algorithm.cpp:2108
    CA->>CA: IsQualifiedToUnLock() [广播端再次校验]<br/>algorithm.cpp:2117
    CA->>CA: vout[0].addr == owner<br/>algorithm.cpp:2123

    CA-->>NET: 校验通过

    NET->>DB: SaveBlock()写入

    DB->>DB: removeLockAddrUtxo(addr, utxoHash)<br/>algorithm.cpp:4478
    DB->>DB: 若无剩余锁定UTXO, removeLockAddr(addr)<br/>algorithm.cpp:4485
    DB->>DB: updateTotalLockedAmount<br/>(减去解锁金额)

    Note over DB: 用户失去投票权
```

## 5. 撤销提案流程

```mermaid
sequenceDiagram
    participant FA as 创始账号
    participant RPC as RPC API
    participant TH as TxHelper
    participant NET as 网络广播
    participant CA as ca_algorithm
    participant DB as RocksDB

    Note over FA,DB: 撤销提案 (REVOKEPROPOSAL tx_type=12)

    FA->>RPC: POST /CreateRevokeProposalTransaction
    RPC->>RPC: _GetRevokeProposal()<br/>http_api.cpp:3657

    RPC->>TH: CreateRevokeProposalTransaction(fromAddr, ...)<br/>txhelper.cpp:4429

    TH->>TH: fromAddr == GetInitAccountAddr()<br/>【仅创始账号可撤销】

    TH->>TH: txInfo["ProposalHash"] = proposalHash<br/>txInfo["BeginTime"] = beginTime<br/>txInfo["EndTime"] = endTime<br/>txInfo["Version"] = KRevokeProposalInfoVersion(0)

    TH->>TX: set_type(REVOKEPROPOSAL=12)<br/>txhelper.cpp:4625

    FA->>NET: 广播

    NET->>CA: verifyTransactionRequest()

    CA->>CA: version == KRevokeProposalInfoVersion(0)<br/>algorithm.cpp:671

    CA->>CA: BEGIN_TIME_CHECK:<br/>tx.time() - KVrfVoteBeginTime <= beginTime<br/>algorithm.cpp:676

    CA->>CA: WINDOW_MIN_CHECK:<br/>endTime-beginTime >= KVoteCycle<br/>algorithm.cpp:680

    CA->>CA: GetAssetTypeIsValid(proposalHash)<br/>algorithm.cpp:685
    Note over CA: 检查被撤销的提案是否存在且有效

    CA->>CA: canBeRevoked(proposalHash)<br/>algorithm.cpp:691
    Note over CA: 检查没有正在进行的撤销提案<br/>algorithm.cpp:8945

    CA->>CA: minVote >= 1<br/>algorithm.cpp:697

    CA-->>NET: 校验通过

    NET->>DB: SaveBlock()写入

    DB->>DB: setRevokeProposalInfoByAssetType(tx.hash(), base64)<br/>algorithm.cpp:4913
    DB->>DB: setRevokeTxHashByAssetType(proposalHash, tx.hash())<br/>algorithm.cpp:4918
    DB->>DB: setVoteCountByAssetType(tx.hash(), 0, 0)<br/>algorithm.cpp:4923

    Note over DB: 撤销投票窗口开始<br/>用户可对撤销提案投票
```

## 6. 投票到期后结果判定流程

此流程在 `GetAssetTypeIsValid()` 中触发，非独立定时器：
**算法位置**: `ca/algorithm.cpp:8602-8751`

```mermaid
sequenceDiagram
    participant C as 调用方
    participant CA as ca_algorithm::GetAssetTypeIsValid
    participant DB as RocksDB

    C->>CA: GetAssetTypeIsValid(assetType)

    CA->>DB: getProposalInfoByAssetType(assetType)<br/>algorithm.cpp:8608
    DB-->>CA: beginTime, endTime, expirationDate, minVote

    CA->>CA: CHECK: time > endTime<br/>且 time <= expirationDate<br/>algorithm.cpp:8623

    Note over CA: 【投票窗口已关闭但未过期】

    CA->>CA: GetVoteNum(db, assetType)<br/>algorithm.cpp:8631

    CA->>CA: 【计票规则】<br/>1. totalNumberOfVoters >= minVote<br/>   (投票人数达标)<br/>2. approveNum > againstNum<br/>   (赞成 > 反对)

    CA->>CA: 若通过: flag=true<br/>返回0 (资产类型有效)

    CA->>CA: 检查撤销提案:
    Note over CA: getRevokeTxHashByAssetType(assetType)<br/>algorithm.cpp:8686

    CA->>CA: 撤销投票判定:<br/>1. 撤销投票窗口未关闭: 仍有效<br/>2. 投票人数 >= minVote 且<br/>   againstNum >= approveNum:<br/>   撤销通过

    Note over CA: 【结论】<br/>赞成>反对 → 提案通过(生效)<br/>反对>=赞成 → 撤销通过(提案无效)<br/>任一条件不满足 → 返回错误
```

## 关键时间常量

| 常量 | 值 | 说明 |
|------|-----|------|
| `KVoteCycle` | 600,000,000 us (10分钟) | 投票最小周期 |
| `KVrfVoteBeginTime` | 10,000,000 us (10秒) | 提案/投票开始前的VRF预留 |
| `LOCK_AMOUNT` | 1 (原始=1, 注释掉1000) | 最小锁定数量(单位:kDecimalNum) |
| `kDecimalNum` | 100,000,000 | 小数精度倍率 |
| `VOTE_CIRCULATION` | 100,000,000,000,000,000 | 投票流通总量上限 |
| 30天锁定期 | 30*24*3600*1,000,000 us | 解锁前必须等待 |

## 关键检查点

1. **PROPOSAL校验**: 创始账号独占, beginTime/endTime/expirationDate, version, canBeStake与已有资产类型一致性
2. **LOCK校验**: LOCK_MUTEX保护, 去重(每地址只能锁定一次), VIRTUAL_LOCK_ADDRESS
3. **VOTE校验**: GetLockValue(锁定金额=投票权重), CheckVoteTxInfo(时间窗口), CheckForDuplicateVotes(去重)
4. **UNLOCK校验**: IsQualifiedToUnLock(30天锁定期+地址+UTXO验证)
5. **REVOKEPROPOSAL校验**: canBeRevoked(无进行中的撤销), 创始账号独占
6. **投票结果**: approveNum > againstNum 且 totalVoters >= minVote
