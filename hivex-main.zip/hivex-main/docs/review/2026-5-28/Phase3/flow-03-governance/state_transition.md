# MeMeChain 治理流程状态转换

## 1. 提案生命周期状态

### Mermaid 状态图

```mermaid
stateDiagram-v2
    [*] --> 提案创建: 创始账号发起
    提案创建 --> 投票中: 广播+打包+区块确认

    投票中 --> 已通过: time > endTime<br/>approveNum > againstNum<br/>totalVoters >= minVote
    投票中 --> 已否决: time > endTime<br/>approveNum <= againstNum

    投票中 --> 撤销投票中: 创始账号发起撤销<br/>(canBeRevoked=true)
    撤销投票中 --> 已撤销: time > revocationEndTime<br/>againstNum >= approveNum<br/>totalVoters >= minVote
    撤销投票中 --> 仍有效: time > revocationEndTime<br/>撤销条件不满足

    已撤销 --> [*]
    已否决 --> [*]
    已通过 --> [*]: 资产类型生效
```

### 状态详细说明

| 状态 | 进入条件 | 退出条件 | 触发操作 |
|------|---------|---------|---------|
| **提案创建** | 创始账号调用 CreateProposalTransaction<br/>txhelper.cpp:4188 | 区块打包确认 | setAssetType(tx.hash())<br/>setProposalInfoByAssetType()<br/>setVoteCountByAssetType(tx.hash(), 0, 0)<br/>algorithm.cpp:4876-4901 |
| **投票中** | 提案已写入区块<br/>time >= beginTime AND time < endTime | endTime到达 | 用户可投票(LOCK后VOTE)<br/>投票写入APPROVE:/AGAINST: |
| **已通过** | time > endTime<br/>approveNum > againstNum<br/>totalVoters >= minVote<br/>algorithm.cpp:8622-8658 | 不可逆 | 资产类型生效<br/>可用于质押/转账/跨链 |
| **已否决** | time > endTime<br/>approveNum <= againstNum<br/>(或 totalVoters < minVote) | 不可逆 | 提案无效 |
| **撤销投票中** | 创始账号发起REVOKEPROPOSAL<br/>提案已存在且无进行中的撤销<br/>canBeRevoked()=0<br/>algorithm.cpp:8945-8978 | revocationEndTime到达 | 用户对撤销提案投票 |
| **已撤销** | revocationEndTime到达<br/>againstNum >= approveNum<br/>totalVoters >= minVote<br/>algorithm.cpp:8742-8745 | 不可逆 | 原提案失效 |
| **仍有效** | revocationEndTime到达<br/>撤销条件不满足<br/>(againstNum < approveNum) | 继续生效 | 提案继续作为有效资产 |

### 提案状态转换伪代码

```
// ca/algorithm.cpp:8602-8751 GetAssetTypeIsValid()

INPUT: assetType (提案hash)
OUTPUT: 0=有效, 负数=无效/错误

1. 获取提案信息: getProposalInfoByAssetType(assetType)
   → beginTime, endTime, expirationDate, minVote

2. IF time <= endTime OR time > expirationDate:
      RETURN -2  // 投票窗口未结束, 无法判定结果

3. 统计票数: GetVoteNum(assetType, approveNum, againstNum)

4. IF totalNumberOfVoters < minVote:
      RETURN -5  // 投票人数不足 → 提案否决

5. IF approveNum <= againstNum:
      RETURN -6  // 赞成票不足 → 提案否决

6. IF 无撤销提案记录 (DB_NOT_FOUND):
      RETURN 0   // 提案通过!

7. IF 撤销投票未结束 (time <= endTime2):
      RETURN 0   // 撤销投票仍在进行, 提案暂有效

8. IF 撤销投票人数不足 (totalNumberOfVoters2 < minVoteThreshold):
      RETURN 0   // 撤销失败, 提案仍有效

9. IF againstNum(撤销) >= approveNum(撤销):
      RETURN -11 // 撤销通过, 提案失效

10. RETURN 0     // 撤销不通过, 提案有效
```

## 2. 锁定状态转换

### Mermaid 状态图

```mermaid
stateDiagram-v2
    [*] --> 未锁定: 初始状态
    未锁定 --> 已锁定: CreateLock交易上链

    state 已锁定 {
        [*] --> 锁定中: LOCK交易已确认
        锁定中 --> 获得投票权: GetLockValue(addr)成功
        获得投票权 --> 投票: VOTE交易使用lockValue
    }

    已锁定 --> 已解锁: CreateUnlock交易上链<br/>(超过30天锁定期)
    已解锁 --> 未锁定: Vote UTXO释放回用户
```

### 状态详细说明

| 状态 | 进入条件 | 退出条件 | 票权状态 |
|------|---------|---------|---------|
| **未锁定** | 初始/解锁后 | LOCK交易上链 | 无投票权 |
| **已锁定** | LOCK交易写入区块<br/>setLockAddrUtxo(addr, tx.hash())<br/>algorithm.cpp:4371 | UNLOCK交易上链<br/>removeLockAddrUtxo()<br/>algorithm.cpp:4478 | 有投票权<br/>lockValue=锁定金额/kDecimalNum |
| **已解锁** | UNLOCK交易上链<br/>30天后+IsQualifiedToUnLock() | LOCK交易可再次锁定 | 投票权丧失 |

### 锁定状态关键检查点

```
LOCK 交易创建 (lock.cpp):
  1. 金额 >= LOCK_AMOUNT * kDecimalNum           →lock.cpp:37
  2. 无已有锁定UTXO (去重)                        →lock.cpp:56-61
  3. Vote从fromAddr转移到VIRTUAL_LOCK_ADDRESS    →lock.cpp:113
  4. set_type(LOCK=9)                            →lock.cpp:147

LOCK 交易验证 (algorithm.cpp):
  1. utxo.assettype() == ASSET_TYPE_VOTE("Vote")  →algorithm.cpp:2096
  2. 无已有锁定(双重验证)                          →algorithm.cpp:2099-2103
  3. vout[0] == VIRTUAL_LOCK_ADDRESS              →algorithm.cpp:1132
  4. vout[0].value >= LOCK_AMOUNT * kDecimalNum   →algorithm.cpp:1139

LOCK 交易保存 (algorithm.cpp):
  1. LOCK_MUTEX 持锁                               →algorithm.cpp:4370
  2. setLockAddrUtxo(addr, utxo_hash)             →algorithm.cpp:4371
  3. totalLockedAmount += lockAmount              →algorithm.cpp:4388

UNLOCK 交易创建 (unlock.cpp):
  1. IsQualifiedToUnLock(addr, utxo, amount)      →unlock.cpp:40
     a. 地址在锁定列表中                          →transaction.cpp:2458
     b. utxo在锁定列表中                          →transaction.cpp:2470
     c. 超过30天锁定期                             →transaction.cpp:2476
     d. 锁定金额 >= LOCK_AMOUNT*kDecimalNum       →transaction.cpp:2508
  2. vin指向被解锁UTXO(preout.n=1)                →unlock.cpp:57-58
  3. vout[0]: 释放到原地址                        →unlock.cpp:112

UNLOCK 交易保存 (algorithm.cpp):
  1. removeLockAddrUtxo(addr, utxo_hash)           →algorithm.cpp:4478
  2. 若无剩余 → removeLockAddr(addr)               →algorithm.cpp:4485
```

## 3. 投票状态转换

### Mermaid 状态图

```mermaid
stateDiagram-v2
    [*] --> 未投票: 初始状态
    未投票 --> 已投票_赞成: CreateVote(vote_type=Approve)
    未投票 --> 已投票_反对: CreateVote(vote_type=Against)

    state 已投票_赞成 {
        [*] --> 赞成_已写入: addVoteCount(...Approve...)
        赞成_已写入 --> 赞成_已计票: 到期统计
    }

    state 已投票_反对 {
        [*] --> 反对_已写入: addVoteCount(...Against...)
        反对_已写入 --> 反对_已计票: 到期统计
    }

    已投票_赞成 --> 未投票: RollBack(区块回滚)
    已投票_反对 --> 未投票: RollBack(区块回滚)

    赞成_已计票 --> [*]: 提案通过(赞成>反对)
    反对_已计票 --> [*]: 提案否决(赞成<=反对)
```

### CheckForDuplicateVotes 状态防护

```mermaid
stateDiagram-v2
    [*] --> 查询赞成集: getApproveAddrsByAssetType
    查询赞成集 --> 地址不存在: addr NOT IN approveSet
    查询赞成集 --> 重复投票_否决: addr IN approveSet (return -4)

    地址不存在 --> 查询反对集: getAgainstAddrsByAssetType
    查询反对集 --> 通过: addr NOT IN againstSet (return 0)
    查询反对集 --> 重复投票_否决: addr IN againstSet (return -6)
```

### 投票权重

```
投票权重 = GetLockValue(addr)  // 锁定金额 / kDecimalNum
                                // algorithm.cpp:9615

特殊: 创始账号在仅有1个资产类型时, lockValue=1
      vote.cpp:45-47, algorithm.cpp:2243-2245
```

## 4. 复合状态: 提案+投票+撤销 全生命周期

```mermaid
stateDiagram-v2
    direction LR

    state ProposalFullLifecycle {
        [*] --> ProposalCreated
        ProposalCreated --> VotingActive: beginTime到达

        VotingActive --> VotingActive: 用户LOCK+VOTE<br/>赞成票/反对票累计

        VotingActive --> Passed: endTime到达<br/>赞成>反对 AND 人数>=minVote
        VotingActive --> Rejected: endTime到达<br/>赞成<=反对 OR 人数<minVote
        VotingActive --> RevocationStarted: 创始账号发起REVOKEPROPOSAL

        RevocationStarted --> RevocationVoting: 撤销投票窗口开启
        RevocationVoting --> RevocationVoting: 用户对撤销投票
        RevocationVoting --> StillActive: 撤销不通过<br/>(againstRevoke<approveRevoke)
        RevocationVoting --> Revoked: 撤销通过<br/>(againstRevoke>=approveRevoke)
    }

    StateDiagram
```

## 5. 临界条件汇总

| 条件 | 判定位置 | 含义 |
|------|---------|------|
| `lock_amount < LOCK_AMOUNT*kDecimalNum` | lock.cpp:37 | 最小锁定金额门槛 |
| `DB_NOT_FOUND` (getLockAddrUtxo) | lock.cpp:57 | 初次锁定(允许) |
| `DB_SUCCESS` (getLockAddrUtxo) | lock.cpp:57 | 已锁定(拒绝) |
| `currentTime < beginTime OR >= endTime` | algorithm.cpp:9479 | 投票时间窗口外 |  
| `lockValue != voteNumber` | algorithm.cpp:2259 | 锁定金额与投票权重不匹配 |
| `addr IN approveAddrs OR againstAddrs` | algorithm.cpp:9200,9216 | 重复投票检测 |
| `totalVoters < minVote` | algorithm.cpp:8650 | 投票参与率不足 |
| `approveNum <= againstNum` | algorithm.cpp:8655 | 提案未通过 |
| `nowTime - lockTx.time() >= 30*24*3600*1e6` | transaction.cpp:2931 | 锁定期未满 |
| `lockedAmount < LOCK_AMOUNT*kDecimalNum` | transaction.cpp:2508 | 解锁金额不足门槛 |
| `time <= endTime (撤销)` | algorithm.cpp:8710 | 撤销投票仍在进行 |
| `againstNum(撤销) >= approveNum(撤销)` | algorithm.cpp:8742 | 撤销通过判定 |
