# Flow-02: 区块同步与 DAG 确认 -- 函数调用栈

## 1. 同步主线程入口: SyncBlock::ThreadStart()

```
sync_block.cpp:175   SyncBlock::ThreadStart()
  | 创建 detached thread, sleepTime=SYNC_HEIGHT_TIME (10s)
  |
  +-- sync_block.cpp:199   lock(syncThreadRunningMutex)  [阻塞点: condition_variable.wait_for]
  |   |  每10秒唤醒检查，若 syncThreadRunning==false 则跳过
  |   |
  |   +-- block_helper.cpp:2113   BlockHelper::getChainHeight(chainHeight)  [同步]
  |   |   |  读取本地 blockTop
  |   |   |  获取所有节点高度列表
  |   |   +-- L2167   verifyNum = nodeHeights.size() * 0.75  [注: 代码实际使用 0.75 而非注释的 0.8]
  |   |   +-- L2174   chainHeight = nodeHeights.at(verifyNum)  [75百分位高度投票]
  |   |
  |   +-- sync_block.cpp:219   DBReader::getBlockTop(nodeSelfHeight)  [同步, DB读]
  |   |
  |   +-- sync_block.cpp:242   [决策树]
  |       |
  |       +-- [分支A] runFastSync==true  -> sync_block.cpp:295
  |       |   |   sync_block.cpp:400   runFastSyncOnce(pledgeAddr, chainHeight, initH, endH, nodeCount)
  |       |   |     |
  |       |   |     +-- sync_block.cpp:538   getSyncNode()  [异步网络, 30s超时]
  |       |   |     |     L551: 若 nodeSelfHeight==chainHeight 且连续6次相同 -> 拜占庭调整
  |       |   |     |
  |       |   |     +-- sync_block.cpp:794   get_fast_sync_sum_hash_node()
  |       |   |     |     L802: CreateWait(30, sendNum*0.8)  80%响应阈值
  |       |   |     |     L885: 拜占庭: hits >= ret_num * 0.66
  |       |   |     |     L939: rollbackHeightNeeded 检测
  |       |   |     |     L974: rollback_block_()  触发回滚
  |       |   |     |     L986-1018: 计算需同步hash的节点ID交集
  |       |   |     |
  |       |   |     +-- sync_block.cpp:1022   get_fast_sync_block_data()
  |       |   |           L1031: CreateWait(30, 1)
  |       |   |           L1064: 验证 block.hash == SHA256(block_without_hash)
  |       |   |           L1093: AddFastSyncBlock(fastSyncBlockData, syncType)
  |       |   |
  |       |   +-- [分支B] SyncFromZero  -> sync_block.cpp:329
  |       |   |   |   sync_block.cpp:475   runFromZeroSyncOnce(pledgeAddr, chainHeight, nodeSelfHeight, nodeCount)
  |       |   |   |     |
  |       |   |   |     +-- sync_block.cpp:607   getSyncNodeSimplified()  [简化: 使用nodeSelfHeight]
  |       |   |   |     |
  |       |   |   |     +-- sync_block.cpp:1504   get_from_zero_sync_sum_hash_node()
  |       |   |   |     |     L1516: CreateWait(90, sendNum * acceptanceRate)
  |       |   |   |     |     L1576: 66%拜占庭检查 (全网络模式80%)
  |       |   |   |     |     L1595: consensus: hash_data_total.second.size() >= success_count * 0.66
  |       |   |   |     |
  |       |   |   |     +-- sync_block.cpp:1653   getSyncBlockDataFromZero()
  |       |   |   |           L1742: sumHeightsHash() 验证
  |       |   |   |           L1750: 本地SumHash vs 远程SumHash 比较
  |       |   |   |           L1778: 若不同 -> rollback_block_()
  |       |   |   |           L1829: lock(cacheSyncMutex) -> syncFromZeroCache
  |       |   |   |           L1860: 创建 sync_add_thread_from_zero.detach()
  |       |   |   |
  |       |   +-- [分支C] SyncNormal (NewSync)  -> sync_block.cpp:374
  |       |       |   sync_block.cpp:434   runNewSyncOnce(pledgeAddr, chainHeight, nodeSelfHeight, initH, endH, nodeCount)
  |       |       |     |
  |       |       |     +-- sync_block.cpp:538   getSyncNode()  [同分支A]
  |       |       |     |
  |       |       |     +-- sync_block.cpp:1883   getSyncBlockHashVerification()
  |       |       |     |     L1897: CreateWait(60, sendNum * 0.8)
  |       |       |     |     L2012: verifyNum = (retDatas.size() + 1) * 0.51  [51%共识]
  |       |       |     |     L2036: hash_and_node.second.size() >= verifyNum -> 加入needToSync
  |       |       |     |     L2047: 计算节点交集 (需所有缺失hash都有该节点)
  |       |       |     |
  |       |       |     +-- sync_block.cpp:2345   getSyncBlockData()
  |       |       |           L2353: CreateWait(60, 3) 至少3个响应
  |       |       |           L2360: 最多SEND_MAX_NUM=10个节点
  |       |       |           L2408: 验证 block.hash == SHA256(block_without_hash)
  |       |       |           L2425: AddSyncBlock(syncBlockData, SyncNormal)
  |       |       |
  |       |       +-- sync_block.cpp:1097   get_sync_sum_hash_node()  [备选路径, NewSync降级]
  |       |               L1113: CreateWait(60, sendNum * 0.8)
  |       |               L1177: verifyNum = node_tops_result.size() * 0.66
  |       |               L1184: chainHeight = node_tops_result.at(verifyNum)
  |       |               L1257: 51%共识 -> 若最大分叉<51%且80%响应 -> rollback_block_
  |       |               L1300: 若最大分叉>=51% -> get_sync_block_by_sum_hash_node()
  |       |               L1390: get_sync_block_by_sum_hash_node() -> getSyncBlockData
```

## 2. 分叉检测: CheckBlocks::_ToCheck()

```
check_blocks.cpp:38    CheckBlocks::StartTimer()  [异步定时器, 30s]
  |
  +-- check_blocks.cpp:78   _ToCheck()  [同步执行, isRunning防重入]
      |
      +-- L92   _Init()  从DB读取 topBlockHeight
      |   L106: 若 topBlockHeight==0 且 nodeSelfHeight<1100 -> 跳过
      |   L108: 若 nodeSelfHeight < topBlockHeight + 1100 -> 跳过
      |
      +-- L117   ca_algorithm::calculateSumHashOf1000Heights(topBlockHeight + 1000)  [DB读, 阻塞]
      |   algorithm.cpp:309   -> 读取1000个高度区块, 计算SumHash
      |
      +-- L124   setTemporaryTopData(top+1000, tempHash)  [lock(topDateMutex)]
      |
      +-- L135   SyncBlock::getSyncNode(UINT32_MAX, top+1000)  [全网络节点]
      |   sync_block.cpp:538
      |   L674: 全网络模式: heightBaseline=minHeight, num=全网节点数
      |
      +-- L148-154   checksumHashRequest -> 向90%节点请求SumHash
      |   L144: CreateWait(90, sendNum * 0.9)
      |
      +-- L167-199   [共识统计]
      |   L201: successNum >= retDatas.size() * 0.8  [80%响应阈值]
      |   L212: max_element (取最多票数的hash)
      |   L217: maxIterator->second >= successNum * 0.9  [90%共识阈值]
      |
      +-- [分支] 90%共识且hash匹配 -> L223-252
      |   L224: setThousandSumHashByBlockHeight()
      |   L247: setThousandSumHashTop()
      |   L249: transactionCommit()  [DB写入]
      |   L252: return 0;
      |
      +-- [分支] 共识未达90%或hash不匹配 -> L271
          |
          +-- check_blocks.cpp:271   performNewSynchronization()
              |
              +-- L274-277: heights = [top+100, top+200, ..., top+1000]
              |
              +-- L280   calculateByzantineSumHash()
              |   L315: CreateWait(90, sendNum * 0.9)
              |   L339-366: 按高度+SumHash统计
              |   L381: successCount >= sendNum * 0.8  [80%拜占庭]
              |   L409: maxIterator->second >= successCount * 0.85  [85%共识]
              |
              +-- L295   runNewSyncOnce()  [每个异常高度]
                  L295: UINT32_MAX = 全网络拜占庭模式
                  L296: sleep(10)  每1000高度间隔10秒
```

## 3. BlockHelper 主处理循环

```
block_helper.cpp:1311   BlockHelper::Process()  [同步调用, 由CA主循环驱动]
  |
  +-- L1313-1319: processing_ 防重入检查
  +-- L1321:    lock(helperMutex)  [主锁, 阻塞所有AddXXX操作]
  |
  +-- L1333-1402: ON_SCOPE_EXIT 清理
  |   |   L1335: BlockManager::remove_expired_blocks_(60s)
  |   |   L1341: notifyNodeHeightChangeRequest()  [通知高度变化]
  |   |   L1362: rollbackBlocks.clear()
  |   |   L1363: _syncBlocks.clear()
  |   |   L1364: broadcastBlocks.clear()
  |
  +-- L1408-1435: [回滚超时过滤]
  |   |   L1412: 仅处理 nowTime <= RollbackTimeout(15s) + blockTime 的区块
  |
  +-- L1437:   RollbackBlocks()  [回滚优先]
  |   |
  |   +-- block_helper.cpp:1233
  |       +-- L1240: rollbackContractBlock()  [先处理合约区块回滚]
  |       +-- L1247: 逆序遍历 rollbackBlocks
  |       |   L1252: RollbackBlock(hash, height)  [对每个回滚区块]
  |       |     block_helper.cpp:1155
  |       |     L1189: getSyncNodeSimplified() -> 向网络请求正确的区块
  |       |     L1192: fetchRollbackBlock() -> 获取51%共识的正确区块
  |       |     L1216: ca_algorithm::DeleteBlock(dbWriter, blockHash)
  |       |     L1217: transactionCommit()  [DB写入, 原子操作]
  |
  +-- L1449-1472: [fastSyncBlocks 处理]
  |   |   L1457: SaveBlock(block, g_syncType, obtain_mean)
  |
  +-- L1473-1486: [utxoMissingBlocks 处理]
  |   |   L1476: SaveBlock(block, g_syncType, ByUtxo)
  |
  +-- L1488-1502: [_syncBlocks 处理]
  |   |   L1497: SaveBlock(block, g_syncType, Normal)
  |
  +-- L1504-151X: [broadcastBlocks 处理]
      |   L1511: SaveBlock(block, Broadcast, Normal)
```

## 4. BlockHelper::SaveBlock() 详细调用栈

```
block_helper.cpp:597   BlockHelper::SaveBlock(block, saveType, computeMeanValue)
  |
  +-- L613-617: 检查 block.height < nodeHeight + 2  (防过度超前)
  +-- L629-634: 防重复保存检查  [DB读]
  |
  +-- L636:    PreSaveProcess(block, saveType, computeMeanValue)  [预验证]
  |   |
  |   +-- block_helper.cpp:885
  |       |
  |       +-- [SyncNormal] L893: ca_algorithm::VerifyBlock(block, true, false, true)  [同步, 完整验证]
  |       |   L894: 失败时 missing_prehash/missingUtxos 处理
  |       |   L900: 若missing_prehash -> set_new_sync_height(blockHeight-1)
  |       |
  |       +-- [Broadcast]  L926: ca_algorithm::verifyPreSaveBlock_(block)  [轻量验证]
  |       |   L920: 若 blockHeight+50 < nodeHeight -> 拒绝 (太旧)
  |       |   L939: ca_algorithm::doubleSpendCheck(tx, false)  [双花检查]
  |       |   L947: 若双花 -> dealDoubleSpend(block, tx, missingUtxo)
  |       |     block_helper.cpp:789
  |       |     L841-876: 判断双花类型并RollbackBlock 或 记录
  |       |   L971: 若UTXO缺失 -> _missingBlocks.insert()
  |
  +-- L646:    ca_algorithm::SaveBlock(*dbWriter, block, saveType, computeMeanValue)
  |   algorithm.cpp  [DB写入核心, 同步阻塞]
  |   |   写入区块数据, UTXO, 交易索引, SumHash等
  |
  +-- L669:    dbWriter->transactionCommit()  [同步，原子提交]
  |
  +-- L694:    PostSaveProcess(block)  [异步投递]
      |   L1010: TaskPool::commitCaTask -> processPostTransaction()
      |   L1012-1022: 检查 _pendingBlocks -> SaveBlock 链式保存
      |   L1024-1062: 检查 contractBlocks 合约区块
      |   L1064: processPostMembershipCancellation(block)
```

## 5. getChainHeight() -- 主链高度选择

```
block_helper.cpp:2113   BlockHelper::getChainHeight(chainHeight)  [同步]
  |
  +-- L2115-2121: DBReader::getBlockTop(top)  [DB读]
  +-- L2123-2130: 若无节点 -> chainHeight = top
  |
  +-- L2134-2156: [节点过滤]
  |   L2134: 若 top < MIN_UNSTAKE_HEIGHT(500) -> 所有节点
  |   L2140: 否则 -> 仅 VerifyBonusAddr 通过的节点
  |
  +-- L2159-2163: 收集 qualifyingNode 高度列表
  +-- L2164:     sort(降序)
  +-- L2166:     sampleRate = 0.75
  +-- L2168:     verifyNum = nodeHeights.size() * 0.75
  +-- L2174:     chainHeight = nodeHeights.at(verifyNum)
  |
  [关键: 使用75百分位而非共识权重, 非comment说的80百分位]
```

## 6. verifyPreSaveBlock_() -- 区块预验证

```
algorithm.cpp  ca_algorithm::verifyPreSaveBlock_(block)  [同步]
  |
  轻量验证, 在 SaveBlock 的 PreSaveProcess 中调用 (Broadcast模式)
  仅验证区块结构完整性，不做完整交易验证

  [与 VerifyBlock 的区别: verifyPreSaveBlock_ 是快速预检，
   VerifyBlock 是完整验证 (含签名、交易、合约等)]
```

## 7. 调用标记汇总

| 函数 | 文件:行号 | 同步/异步 | 阻塞点 |
|------|----------|----------|--------|
| ThreadStart() | sync_block.cpp:175 | 异步(detach) | condition_variable (L200) |
| runFastSyncOnce() | sync_block.cpp:400 | 同步(在线程内) | WaitData 30s (L817) |
| runNewSyncOnce() | sync_block.cpp:434 | 同步(在线程内) | WaitData 60s (L1916) |
| runFromZeroSyncOnce() | sync_block.cpp:475 | 同步(在线程内) | WaitData 90s (L1532) |
| getSyncBlockHashVerification() | sync_block.cpp:1883 | 同步(在线程内) | WaitData 60s (L1916) |
| getSyncBlockDataFromZero() | sync_block.cpp:1653 | 同步(在线程内) | WaitData 90s (L1700) |
| StartTimer() / _ToCheck() | check_blocks.cpp:38/78 | 异步定时器 | WaitData 90s (L158) |
| Process() | block_helper.cpp:1311 | 同步 | lock(helperMutex) |
| SaveBlock() | block_helper.cpp:597 | 同步 | DB transactionCommit (L669) |
| RollbackBlocks() | block_helper.cpp:1233 | 同步 | DB transactionCommit (L1217) |
| getChainHeight() | block_helper.cpp:2113 | 同步 | DB getBlockTop (L2116) |
| rollback_block_() | block_helper.cpp:2100 | 同步 | lock(helperMutex) (L2102) |
| AddBroadcastBlock() | block_helper.cpp:1952 | 同步 | lock(helperMutex) (L1956) |
| AddSyncBlock() | block_helper.cpp:2071 | 同步 | lock(helperMutex) (L2074) |
| AddFastSyncBlock() | block_helper.cpp:2086 | 同步 | lock(helperMutex) (L2088) |
| _BlockCheck() | block_stroage.cpp:69 | 异步定时器 | lock(_blockMutex) (L71) |
| verifyFlowedBlockStatus() | block_helper.cpp:473 | 同步 | DB getBlockTop (L495) |
| RollBackToHeight() | algorithm.cpp:7511 | 同步 | DB 多步操作 (L7522-7566) |

## 8. 同步降级路径

```
runFastSyncOnce() 失败
  -> isFastSyncFailed=true -> 下轮重试 runFastSync
     连续失败5次 (runFastSyncCount >= 5) -> 放弃 FastSync
        -> 进入 SyncNormal

SyncNormal (runNewSyncOnce) 失败
  -> 返回 < 0 -> sync_fail_height=0, runFastSync=false
     若 runZeroSyncCount > 2 -> force SyncNormal

SyncFromZero (runFromZeroSyncOnce) 失败
  -> sync_send_zero_sync_num = UINT32_MAX (全网络拜占庭模式)
     ++runZeroSyncCount
     下轮: 全网络模式 + 更大节点数
```
