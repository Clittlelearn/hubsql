# Flow-02: 区块同步与 DAG 确认 -- 时序图

## 1. 快速同步流程 (FastSync)

触发条件: `sync_fail_height != 0` 且 `runFastSync == true` (sync_block.cpp:273)

```mermaid
sequenceDiagram
    participant ST as SyncBlock线程
    participant SN as getSyncNode
    participant GH as get_fast_sync_sum_hash_node
    participant NET as 网络层
    participant BP as BlockHelper::AddFastSyncBlock
    participant PROC as BlockHelper::Process

    ST->>ST: 检测 runFastSync==true (L273)
    note right of ST: sync_block.cpp:175 ThreadStart()
    ST->>ST: syncInitHeight = sync_fail_height - fastSyncHeightCount
    ST->>SN: getSyncNode(syncNodeCount, chainHeight, pledgeAddr)
    note right of SN: sync_block.cpp:538
    SN-->>ST: node_ids_to_send []
    ST->>GH: get_fast_sync_sum_hash_node(nodes, initH, endH)
    note right of GH: sync_block.cpp:794
    GH->>NET: fastSyncGetHashRequest -> 各节点
    note right of NET: 80%响应阈值 (L802)
    NET-->>GH: FastSyncGetHashAck (hash列表)
    GH->>GH: 拜占庭检查: hits >= ret_num * 0.66 (L885)
    alt 本地hash不满足66%共识
        GH->>BP: rollback_block_(rollbackBlockData_)
        note right of BP: 触发回滚 (L974)
    end
    GH->>GH: 计算需同步的hash交集 (L986-1018)
    GH->>NET: sendFastSyncGetBlockRequest -> 选中节点
    NET-->>GH: FastSyncGetBlockAck (区块数据)
    GH->>BP: AddFastSyncBlock(fastSyncBlockData, syncType)
    note right of BP: sync_block.cpp:1093
    BP->>PROC: 等待 Process() 定时器消费
```

## 2. 常规同步流程 (NewSync -- SumHash验证)

```mermaid
sequenceDiagram
    participant ST as SyncBlock线程
    participant SN as getSyncNode
    participant GV as getSyncBlockHashVerification
    participant NET as 网络层
    participant GD as getSyncBlockData
    participant BP as BlockHelper::AddSyncBlock
    participant PROC as BlockHelper::Process
    participant DB as RocksDB

    ST->>ST: syncType != SyncFromZero (L314)
    ST->>ST: syncInitHeight = nodeSelfHeight - syncHeightCount<br/>endSyncHeight_ = nodeSelfHeight + syncHeightCount (L350,L360)
    ST->>ST: 若 execute_new_sync, 使用 initialSyncStartHeight (L364-372)
    ST->>SN: getSyncNode(syncNodeCount, chainHeight, pledgeAddr)
    note right of SN: sync_block.cpp:538<br/>选择高度>=chainHeight的质押节点
    SN-->>ST: node_ids_to_send []
    ST->>GV: getSyncBlockHashVerification(nodes, initH, endH)
    note right of GV: sync_block.cpp:1883
    GV->>NET: chainSyncGetBlockHeightAndHashRequest (L1912)
    note right of NET: 80%响应阈值 (L1897)
    NET-->>GV: SyncGetBlockHeightAndHashAck
    GV->>GV: 51%共识判定 (L2012)<br/>verifyNum = (retDatas.size() + 1) * 0.51
    alt hash未达51%共识
        GV->>GV: 检测本地hash差异
        GV->>BP: rollback_block_() (L2122)
    end
    GV->>GV: 计算需同步hash交集 (L2046-2061)
    GV-->>ST: reqHashes, node_ids_returned
    ST->>GD: getSyncBlockData(node_ids, reqHashes, chainHeight)
    note right of GD: sync_block.cpp:2345
    GD->>NET: sendSyncGetBlockRequest (最多10个节点, L2360)
    NET-->>GD: SyncGetBlockAck (区块数据)
    GD->>GD: 验证 hash = SHA256(block_without_hash)
    GD->>BP: AddSyncBlock(syncBlockData, SyncNormal)
    note right of BP: sync_block.cpp:2425
    BP->>PROC: 等待 Process() 定时器消费
    PROC->>DB: SaveBlock() 写入数据库
```

## 3. 从零同步流程 (SyncFromZero)

```mermaid
sequenceDiagram
    participant ST as SyncBlock线程
    participant ZN as getSyncNodeSimplified
    participant ZH as get_from_zero_sync_sum_hash_node
    participant NET as 网络层
    participant ZD as getSyncBlockDataFromZero
    participant CACHE as syncFromZeroCache
    participant ADDT as sync_add_thread (detach)
    participant BP as BlockHelper::AddSyncBlock

    ST->>ST: syncType == SyncFromZero (L321)
    note right of ST: 判定条件: chainHeight <= hashRangeSum<br/>或 nodeSelfHeight < get_sum_hash_floor_height(chainHeight) - hashRangeSum
    ST->>ST: heights[] = [syncHeight, syncHeight+100, ...]
    note right of ST: 每个高度间隔 global::ca::hashRangeSum=100 (L503)
    ST->>ZN: getSyncNodeSimplified(syncNodeCount, chainHeight, pledgeAddr)
    ZN-->>ST: node_ids_to_send []
    ST->>ZH: get_from_zero_sync_sum_hash_node(nodes, heights)
    note right of ZH: sync_block.cpp:1504<br/>90% / 80% 响应阈值 (L1510,L1516)
    NET-->>ZH: SyncFromZeroGetSumHashAck
    ZH->>ZH: 66%共识检查 (L1576-1589)
    zh->>ZH: 若全网络拜占庭失败, 只同步最后100高度 (L1607)
    ZH-->>ST: sumHashes, node_ids_returned
    ST->>ZD: getSyncBlockDataFromZero(sumHashes, heights, nodes)
    note right of ZD: sync_block.cpp:1653
    ZD->>NET: sendFromZeroSyncGetBlockRequest (每个高度向不同节点)
    NET-->>ZD: SyncFromZeroGetBlockAck
    ZD->>ZD: 验证 SumHash: sumHeightsHash(返回) == sumHashes (L1750)
    alt SumHash不匹配
        ZD->>BP: rollback_block_() (L1815)
    end
    ZD->>ZD: 写入 syncFromZeroCache (L1829-1831)
    note right of CACHE: mutex: cacheSyncMutex
    ZD->>ZD: 全部高度成功 -> 启动独立线程 (L1860)
    ZD->>ADDT: sync_add_thread_from_zero.detach()
    ADDT->>BP: AddSyncBlock(cache.second, SyncFromZero)
    note right of BP: L1871-1872
    ADDT->>ADDT: syncFromZeroCache.clear()
```

## 4. 分叉检测流程 (CheckBlocks 定时器)

```mermaid
sequenceDiagram
    participant TM as CheckBlocks定时器 (30s)
    participant CB as CheckBlocks::_ToCheck()
    participant ALG as ca_algorithm
    participant NET as 网络层
    participant CONS as 共识判定
    participant PNS as performNewSynchronization
    participant ST as SyncBlock

    TM->>CB: AsyncLoop(30000) 触发 (check_blocks.cpp:38)
    CB->>CB: 检查 isRunning 防重入 (L80)
    CB->>CB: _Init() 获取 topBlockHeight (L92)
    CB->>CB: nodeSelfHeight < topBlockHeight + 1100? -> 跳过 (L108)
    CB->>ALG: calculateSumHashOf1000Heights(top+1000) (L117)
    note right of ALG: 计算本地1000高度SumHash
    ALG-->>CB: tempHash
    CB->>CB: setTemporaryTopData(top+1000, tempHash) (L124)

    loop while(true)
        CB->>CB: getSyncNode(UINT32_MAX, top+1000) (L135)
        note right of CB: 全网络节点
        CB->>NET: checksumHashRequest -> 90%节点 (L148,L154)
        NET-->>CB: GetCheckSumHashAck (各节点SumHash)
        CB->>CB: 统计共识: 80% successNum >= retDatas*0.8 (L201)
        CB->>CONS: 取最多票数的hash (L212)

        alt 90%共识且hash匹配
            CB->>CB: 写入ThousandSumHash到DB (L224)
            CB->>CB: return 0; 继续下一轮
        else SumHash不一致
            CB->>PNS: performNewSynchronization() (L256)
            PNS->>PNS: calculateByzantineSumHash (每100高度, L280)
            note right of PNS: 85%共识阈值 (check_blocks.cpp:409)
            loop 每个异常高度
                PNS->>ST: runNewSyncOnce() (L295)
                note right of ST: UINT32_MAX = 全网络拜占庭模式
            end
        end
    end
```

## 5. 回滚流程

```mermaid
sequenceDiagram
    participant SYNC as 同步层(SyncBlock)
    participant BH as BlockHelper
    participant RB as RollbackBlocks()
    participant ALG as ca_algorithm
    participant DB as RocksDB

    Note over SYNC: 路径A: rollback_block_() 设置回滚数据

    SYNC->>BH: rollback_block_(rollbackBlockData_)
    note right of BH: sync_block.cpp:974,1296,1487,1815,2122,2326
    BH->>BH: lock(helperMutex) (L2102)
    BH->>BH: rollbackBlocks = rollbackBlockInfo (L2103)

    Note over BH: 路径B: Process() 消费回滚队列

    BH->>BH: Process() 定时触发 (L1311)
    BH->>BH: lock(helperMutex) (L1321)
    BH->>BH: 过滤超时回滚块 (15s RollbackTimeout) (L1408-1416)
    BH->>RB: RollbackBlocks() (L1437)

    RB->>RB: rollbackContractBlock() (L1240)
    note right of RB: 先回滚合约区块
    RB->>RB: 逆序遍历 rollbackBlocks (L1247)
    loop 每个回滚区块
        RB->>ALG: DeleteBlock(dbWriter, blockHash) (L1216)
        note right of ALG: block_helper.cpp:1216
        DB-->>ALG: transactionCommit()
    end

    Note over ALG: 路径C: RollBackToHeight() 从顶向下回滚

    ALG->>DB: getBlockTop(nodeHeight) (algorithm.cpp:7516)
    ALG->>DB: 遍历 nodeHeight .. height: 收集所有区块hash (L7522-7535)
    ALG->>ALG: RollBackBlock(hashs) (L7552)
    note right of ALG: 调用DB回滚原语
```

## 6. 广播接收与处理流程

```mermaid
sequenceDiagram
    participant NET as 网络层
    participant HE as HandleBroadcastMsg
    participant BS as BlockStorage
    participant BC as BlockStorage::_BlockCheck (100ms)
    participant BM as BlockMonitor
    participant BH as BlockHelper
    participant DB as RocksDB

    NET->>HE: BuildBlockBroadcastMsg 到达
    note right of HE: net/handle_event.cpp:777
    HE->>HE: 版本兼容检查 (L782)
    HE->>HE: ParseFromString (L791)
    HE->>HE: 环形邻居转发 (type==1时, 周边节点扩散)
    HE->>HE: msg->set_type(2) 标记已处理 (L960)
    HE->>BS: 调用网络API投递到BlockStorage

    BS->>BS: AddBlock(msg) / UpdateBlock(msg) (L27/L43)
    note right of BS: 收集同一区块的多节点签名
    note right of BS: mutex: _blockMutex (shared_mutex)

    BC->>BC: _BlockCheck() 每100ms触发 (L20)
    BC->>BC: lock(_blockMutex) (L71)
    BC->>BC: 检查 msgSize >= kConsensus(3) 且 lagTime <= 10s (L85)
    alt 达到共识签名数
        BC->>BC: composeEndBlockMessage() VRF随机选签名 (L89)
        BC->>BC: 写入 blockStatusMap (L96)
        BC->>BM: sendBroadcastAddBlockRequest(outMsg, height) (L100)
        note right of BM: 向全网广播完成签名的区块
    else 超10秒未达共识
        BC->>BC: _Remove(hash) 清理 (L106-110)
    end

    Note over BM: 节点收到广播区块后

    BM->>BH: verifyFlowedBlockStatus(block)  (transaction.cpp:3648)
    note right of BH: block_helper.cpp:473
    BH->>BH: 版本检查 (L475)
    BH->>BH: 高度验证: nodeHeight-9 <= blockHeight <= nodeHeight+1 (L500-509)
    BH->>BH: 稳定性检查: 高度低于chainHeight-10且超过60s -> 拒绝 (L522)
    BH->>BH: 防重复: getBlockByBlockHash (L531)
    BH->>BH: 前置区块存在性检查 (L544-554)
    BH->>BH: 双花冲突检查 (L556-574)
    BH->>BH: ca_algorithm::VerifyBlock() (L581)
    BH->>BH: AddBroadcastBlock(block) 加入广播队列 (transaction.cpp)
    note right of BH: block_helper.cpp:1952

    BH->>BH: Process() 定时器消费 broadcastBlocks
    BH->>DB: SaveBlock(block, Broadcast, Normal) (L1511)
```

## 7. 关键标注

### 线程切换点
| 位置 | 线程 | 说明 |
|------|------|------|
| sync_block.cpp:184 | SyncBlock线程 (detach) | 主同步循环 (sleepTime=10s) |
| sync_block.cpp:1860 | sync_add_thread_from_zero (detach) | 从零同步的区块应用线程 |
| check_blocks.cpp:38 | CheckBlocks定时器 | 30秒周期分叉检测 |
| block_stroage.cpp:20 | BlockStorage定时器 | 100ms周期区块检查 |
| block_helper.cpp:1311 | BlockHelper::Process (被CA主循环调用) | 周期性保存/回滚 |
| block_helper.cpp:1297 | sendBlockByUtxoRequest (detach) | 异步获取缺失utxo的区块 |

### 锁获取/释放
| 锁 | 文件:行号 | 保护对象 | 持有者 |
|-----|----------|---------|--------|
| syncThreadRunningMutex | sync_block.cpp:199 | syncThreadRunning + condition_variable | SyncBlock线程 |
| cacheSyncMutex | sync_block.cpp:244 | syncFromZeroCache | SyncBlock线程 / sync_add_thread |
| helperMutex | block_helper.cpp:1321 | rollbackBlocks, broadcastBlocks, _syncBlocks, fastSyncBlocks | Process(), AddXXX() |
| helperMutexLow1 | block_helper.cpp:1955 | AddBroadcastBlock 去重 | AddBroadcastBlock |
| _blockMutex (shared) | block_stroage.cpp:29 | _blockCnt | BlockStorage |
| topDateMutex | check_blocks.cpp:67 | tempTopDate | CheckBlocks |
| seekMutex | block_helper.cpp:971 | _missingBlocks | PreSaveProcess |

### 数据库写入点
| 操作 | 文件:行号 |
|------|----------|
| ca_algorithm::SaveBlock() | block_helper.cpp:646 |
| transactionCommit() | block_helper.cpp:669 |
| setThousandSumHashByBlockHeight() | check_blocks.cpp:224 |
| DeleteBlock() | block_helper.cpp:1216 |
| DeleteBlock() rollback | block_helper.cpp:1216 |
