# Flow-02: 区块同步与 DAG 确认 -- 异步任务流转

## 1. 系统全局异步任务拓扑

```
┌──────────────────────────────────────────────────────────────────┐
│                        CA 主循环 (ca.cpp)                         │
│  BlockHelper::Process() 周期性调用                                 │
└──────────────┬────────────────────┬──────────────────┬───────────┘
               │                    │                  │
      ┌────────▼────────┐  ┌───────▼─────────┐  ┌─────▼───────────┐
      │ BlockHelper      │  │ CheckBlocks      │  │ BlockStorage     │
      │ 消费各类缓存队列  │  │ 30s分叉检测     │  │ 100ms签名聚合    │
      └────────┬─────────┘  └───────┬─────────┘  └─────┬───────────┘
               │                    │                  │
┌──────────────▼────────────────────▼──────────────────▼───────────┐
│                      SyncBlock 线程 (10s循环)                     │
│  FastSync / NewSync / FromZeroSync 决策                           │
└──────────────────────────────────────────────────────────────────┘
```

## 2. SyncBlock 后台线程持续运行

```mermaid
flowchart TD
    START([CA启动]) --> INIT[ThreadStart调用]
    INIT --> THREAD[创建 _syncThread detached]
    THREAD --> LOOP{while 1}

    LOOP --> WAIT[condition_variable.wait_for<br/>10秒超时]
    WAIT --> CHECK{syncThreadRunning?}
    CHECK -->|false| WAIT
    CHECK -->|true| GET_CH[getChainHeight]
    GET_CH --> GET_SH[getBlockTop<br/>获取 nodeSelfHeight]
    GET_SH --> CLEAN[syncFromZeroCache清理<br/>删除已处理的高度]
    CLEAN --> DECISION{同步路径选择}

    DECISION -->|runFastSync| FAST[FastSync 路径]
    DECISION -->|SyncFromZero| ZERO[FromZeroSync 路径]
    DECISION -->|默认| NEW[NewSync 路径]

    FAST --> POST[runFastSyncCount++]
    POST --> WAIT
    ZERO --> WAIT
    NEW --> WAIT

    style THREAD fill:#e1f5fe
    style WAIT fill:#fff3e0
    style DECISION fill:#f3e5f5
```

**关键细节:**
- 线程类型: `std::thread::detach()` (sync_block.cpp:394)
- 唤醒方式: `condition_variable::wait_for(10s)` (sync_block.cpp:200)
- 停止方式: 修改 `syncThreadRunning` 原子变量 (sync_block.cpp:167)
- 线程ID: 通过 `syncThreadRunningMutex` 保护 (sync_block.cpp:199)

## 3. CheckBlocks 30秒定时器触发分叉检测

```mermaid
flowchart TD
    TMER([CA初始化]) --> STIMER[CheckBlocks::StartTimer]
    STIMER --> TIMER[CTimer::AsyncLoop 30000ms]

    TIMER --> TICK{每30秒}
    TICK --> RUNCHECK{isRunning?}
    RUNCHECK -->|true 已在运行| TICK
    RUNCHECK -->|false| SETTRUE[isRunning = true]
    SETTRUE --> INIT[_Init: 获取 topBlockHeight]
    INIT --> COMPARE{topBlockHeight==0<br/>且 nodeSelfHeight<1100?}
    COMPARE -->|是| SKIP[跳过检测]
    COMPARE -->|否| COMPARE2{nodeSelfHeight<br/>&lt; topBlockHeight+1100?}
    COMPARE2 -->|是| SKIP
    COMPARE2 -->|否| CALC_SUM[calculateSumHashOf1000Heights]

    CALC_SUM --> SET_TEMP[setTemporaryTopData]
    SET_TEMP --> LOOP_START{while true}

    LOOP_START --> GETNODES[getSyncNode<br/>UINT32_MAX 全网络]
    GETNODES --> REQHASH[checksumHashRequest<br/>向90%节点请求SumHash]
    REQHASH --> WAIT[WaitData 90秒超时]
    WAIT --> STATS[统计共识Map]

    STATS --> CHECK80{successNum<br/>>= retDatas*0.8?}
    CHECK80 -->|否| LOOP_START
    CHECK80 -->|是| MAXELEM[max_element 取最多票数]

    MAXELEM --> CHECK90{max >= successNum*0.9?}
    CHECK90 -->|是| CMP_LOCAL{与本地tempHash匹配?}
    CMP_LOCAL -->|匹配| WRITEDB[写入ThousandSumHash<br/>transactionCommit]
    WRITEDB --> NEXT_ROUND[return 0<br/>等待下一轮30s]
    CMP_LOCAL -->|不匹配| PERFORM[performNewSynchronization]
    CHECK90 -->|否| PERFORM

    PERFORM --> BYZ[calculateByzantineSumHash<br/>每100高度 ×10次]
    BYZ --> SYNC_EACH[对每个异常高度<br/>runNewSyncOnce]
    SYNC_EACH --> SLEEP[sleep 10秒每个]
    SLEEP --> LOOP_START

    SKIP --> NEXT_ROUND
    NEXT_ROUND --> TICK

    style TIMER fill:#e8f5e9
    style LOOP_START fill:#f3e5f5
    style PERFORM fill:#ffebee
```

**关键细节:**
- 定时器: `CTimer::AsyncLoop(30000, callback)` (check_blocks.cpp:38)
- 防重入: `isRunning` 原子变量 (check_blocks.cpp:80-90)
- 停止: `StopTimer() -> _timer.Cancel()` (check_blocks.cpp:43)
- 高度跳过条件: nodeSelfHeight 未超过 topBlockHeight+1100 (check_blocks.cpp:108)
- 异常同步: 每1000高度执行10次 runNewSyncOnce，每次间隔10秒 (check_blocks.cpp:274-302)

## 4. BlockHelper::Process() 周期性消费队列

```mermaid
flowchart TD
    CALLER([CA主循环 周期性调用]) --> PROCESS[BlockHelper::Process]

    PROCESS --> GUARD{processing_?}
    GUARD -->|true 跳过| DONE([return])
    GUARD -->|false| LOCK[lock helperMutex<br/>获取主锁]

    LOCK --> GETTOP[DBReader.getBlockTop]

    GETTOP --> SCOPE_SET[设置 ON_SCOPE_EXIT<br/>清理回调]

    SCOPE_SET --> RB_FILTER[回滚超时过滤<br/>RollbackTimeout=15秒]

    RB_FILTER --> DO_RB[RollbackBlocks 执行回滚]
    DO_RB --> DO_FS[处理 fastSyncBlocks<br/>SaveBlock each]
    DO_FS --> DO_UM[处理 utxoMissingBlocks<br/>SaveBlock each]
    DO_UM --> DO_SB[处理 _syncBlocks<br/>SaveBlock each]
    DO_SB --> DO_BB[处理 broadcastBlocks<br/>SaveBlock each]

    DO_BB --> SCOPE_EXEC[ON_SCOPE_EXIT 触发]
    SCOPE_EXEC --> NOTIFY[notifyNodeHeightChangeRequest]
    NOTIFY --> CLEAN[清理过期数据]
    CLEAN --> DONE

    subgraph SCOPE[ON_SCOPE_EXIT 清理逻辑]
        E1[BlockManager::remove_expired_blocks_ 60s]
        E2[rollbackBlocks.clear]
        E3[_syncBlocks.clear]
        E4[broadcastBlocks.clear]
        E5[_pendingBlocks 过期清理 20高度]
        E6[doubleSpendBlocks 30秒过期清理]
        E7[_duplicateChecker 60秒过期清理]
        E8[contractBlocks 10高度/30秒清理]
    end

    style LOCK fill:#ffcdd2
    style SCOPE_EXEC fill:#e8f5e9
```

**关键细节:**
- 调用者: CA主循环 (由外部周期性驱动, 非独立线程)
- 主锁: `helperMutex` (block_helper.cpp:1321)
- 防御标志: `processing_` 局部静态变量 (block_helper.cpp:1314)
- 处理顺序: **回滚 > FastSync > UTXO缺失 > 同步块 > 广播块** (优先级从高到低)
- 每次 Process() 结束清理所有队列 (L1362-1364)
- 过期区块自动跳过: `_stopBlocking == false` 时中断 (L1492)

## 5. BlockStorage::_BlockCheck() 100ms签名聚合

```mermaid
flowchart TD
    START2([CA启动]) --> STIMER2[BlockStorage::_StartTimer]
    STIMER2 --> TIMER2[CTimer::AsyncLoop 100ms]

    TIMER2 --> TICK2{每100ms}
    TICK2 --> LOCK2[unique_lock shared_mutex<br/>_blockMutex]

    LOCK2 --> ITER[遍历 _blockCnt]

    ITER --> CHECK_EACH{每个区块}
    CHECK_EACH --> NOWTIME[计算 lagTime<br/>= |nowTime - block.time()|]

    NOWTIME --> CONSENSUS{msgSize >= kConsensus=3<br/>且 lagTime <= 10秒?}

    CONSENSUS -->|是| COMPOSE[composeEndBlockMessage<br/>VRF随机选签名]
    COMPOSE --> STATUS[写入 blockStatusMap]
    STATUS --> BROADCAST[sendBroadcastAddBlockRequest<br/>全网络广播]
    BROADCAST --> MARK_DEL[标记hash待删除]

    CONSENSUS -->|否, 超10秒| TIMEOUT[标记hash待删除<br/>ERRORLOG 超时]
    CONSENSUS -->|否, 未达共识| NEXT_BLOCK[继续下一区块]

    MARK_DEL --> NEXT_BLOCK

    NEXT_BLOCK -->|遍历完成| DELETE_ALL[_Remove 清理已处理hash]
    DELETE_ALL --> CHECK_EXP[checkExpiredDelete<br/>清理过期 blockStatusMap]
    CHECK_EXP --> TICK2

    style LOCK2 fill:#ffcdd2
    style CONSENSUS fill:#fff3e0
    style BROADCAST fill:#e8f5e9
```

**关键细节:**
- 定时器: `CTimer::AsyncLoop(100, callback)` (block_stroage.cpp:20) -- 每100毫秒
- 锁: `shared_mutex::unique_lock` (_blockMutex) (block_stroage.cpp:71)
- 共识条件: msgSize >= 3 (kConsensus) AND 10秒内 (L85)
- VRF选择: `getRandomElements(secondMsg, kConsensus-1)` (L135) -- 随机选2个签名
- 超时清理: lagTime > 10s 标记删除并警告 (L106-110)

## 6. 广播消息的异步处理链路

```mermaid
flowchart TD
    NET_RECV([网络层收到 BuildBlockBroadcastMsg]) --> HANDLE[HandleBroadcastMsg<br/>net/handle_event.cpp:777]

    HANDLE --> VC[版本兼容检查]
    VC --> PARSE[ParseFromString 解析]
    PARSE --> FLOOD{msg->type()==1?}

    FLOOD -->|是 需要扩散| INIT_CYCLE[初始化环形邻居列表]
    INIT_CYCLE --> FIND_TARGET[查找目标位置]
    FIND_TARGET --> UP_DOWN[获取上下邻居]
    UP_DOWN --> SEND_FLOOD[向邻居转发 type=2]
    SEND_FLOOD --> SET_TYPE[msg->set_type 2]

    FLOOD -->|否| FLOW[BlockStorage::AddBlock/UpdateBlock]

    SET_TYPE --> FLOW

    FLOW -->|AddBlock| INSERT[插入 _blockCnt<br/>shared_mutex lock]
    INSERT --> WAIT_SIG[等待100ms定时器]

    FLOW -->|UpdateBlock| PUSH[追加到 _blockCnt<br/>shared_mutex lock]
    PUSH --> WAIT_SIG

    WAIT_SIG --> CHECK100[_BlockCheck 100ms触发]
    CHECK100 --> CONSENSUS{签名数>=3?}
    CONSENSUS -->|是| BUILD[组装最终区块<br/>VRF选择签名]
    CONSENSUS -->|否| WAIT_SIG

    BUILD --> BM_SEND[BlockMonitor::sendBroadcastAddBlockRequest]
    BM_SEND --> NET_BC[net_com::broadcastMessage<br/>全网广播]

    NET_BC --> STATUS_SAVE[AddBlockStatus<br/>记录投票信息]
    STATUS_SAVE --> DONE2([广播完成])

    style FLOOD fill:#fff3e0
    style CONSENSUS fill:#f3e5f5
    style BM_SEND fill:#e8f5e9
```

**关键细节:**
- 环形邻居扩散: 从发送者在环形列表中的位置向两侧扩散 (handle_event.cpp:825-843)
- type字段: 1=需扩散, 2=已扩散完成
- BlockStorage 收到后: AddBlock 创建新条目, UpdateBlock 追加签名
- 最终广播: 由 BlockMonitor 通过 `net_com::broadcastMessage` 发送

## 7. 从零同步的渐进式任务

```mermaid
flowchart TD
    START3([SyncBlock 线程检测到 SyncFromZero]) --> CHECK_CACHE{syncFromZeroReserveHeights<br/>非空?}
    CHECK_CACHE -->|是| USE_RESERVE[使用上次失败的待同步高度]
    CHECK_CACHE -->|否| CALC_HEIGHTS[计算待同步高度]

    CALC_HEIGHTS --> GET_FLOOR[get_sum_hash_floor_height<br/>chainHeight - hashRangeSum]
    GET_FLOOR --> CALC_CEIL[calculateSumHashCeilingHeight<br/>nodeSelfHeight]
    CALC_CEIL --> LIMIT{heightCeiling - syncHeight<br/>> 1000?}
    LIMIT -->|是| CAP[syncHeight + 1000]
    LIMIT -->|否| USE_CEIL[使用heightCeiling]

    CAP --> GEN_LIST[生成 heights[] =<br/>[syncHeight, syncHeight+100, ...]]
    USE_CEIL --> GEN_LIST
    USE_RESERVE --> SKIP_GEN[直接使用保留高度]

    GEN_LIST --> REQ_SUM[get_from_zero_sync_sum_hash_node<br/>向多个节点请求SumHash]
    SKIP_GEN --> REQ_SUM

    REQ_SUM --> VERIFY_BYZ[66%拜占庭共识验证]
    VERIFY_BYZ --> REQ_BLOCK[getSyncBlockDataFromZero<br/>向每个高度对应节点请求区块]

    REQ_BLOCK --> CHECK_SUM{远程区块SumHash<br/>== 本地SumHash?}
    CHECK_SUM -->|不同| CHECK_QUAL{sync_send_zero_sync_num<br/>< qualifyingNode.size?}
    CHECK_QUAL -->|是| RB[sync_send_zero_sync_num=UINT32_MAX<br/>升级全网络模式]
    CHECK_QUAL -->|否| DO_RB2[rollback_block_ 触发回滚]

    CHECK_SUM -->|相同| CACHE_SAVE[lock cacheSyncMutex<br/>写入 syncFromZeroCache]

    CACHE_SAVE --> ERASE_SUCC[从 heightsForSending 移除成功高度]

    ERASE_SUCC --> ALL_DONE{heightsForSending.empty?}
    ALL_DONE -->|是| SPAWN_THREAD[创建 sync_add_thread_from_zero<br/>独立线程 detach]
    ALL_DONE -->|否| SAVE_RESERVE[syncFromZeroReserveHeights<br/>= 失败高度]

    SPAWN_THREAD --> APPLY_ALL[遍历 syncFromZeroCache<br/>调用 AddSyncBlock 逐个应用]
    APPLY_ALL --> CLEAR_CACHE[syncFromZeroCache.clear]
    CLEAR_CACHE --> DONE3([完成])

    SAVE_RESERVE --> WAIT_NEXT[返回 -9<br/>等待下一轮10秒]

    style SPAWN_THREAD fill:#e8f5e9
    style ALL_DONE fill:#fff3e0
    style CACHE_SAVE fill:#ffcdd2
```

## 8. 区块投递到 BlockHelper 的多条异步路径

```mermaid
flowchart TD
    subgraph 来源1[来源: 同步线程]
        A1[FastSync] --> A_ADD[AddFastSyncBlock]
        A2[NewSync] --> B_ADD[AddSyncBlock]
        A3[FromZeroSync] --> C_ADD[AddSyncBlock Cache线程]
    end

    subgraph 来源2[来源: 广播接收]
        B1[BuildBlockBroadcastMsg] --> B2[verifyFlowedBlockStatus]
        B2 --> B3[AddBroadcastBlock]
    end

    subgraph 来源3[来源: UTXO缺失协议]
        C1[sendBlockByUtxoRequest] --> C2[AddMissingBlock]
        C2 --> C3[utxoMissingBlocks队列]
    end

    subgraph 来源4[来源: Hash缺失协议]
        D1[sendBlockByHashRequest] --> D2[add_seek_block -> 投递到TaskPool]
        D2 --> D3[broadcastBlocks队列]
    end

    subgraph 目的地[BlockHelper 队列]
        Q1[_syncBlocks<br/>sync_block.cpp:2080]
        Q2[fastSyncBlocks<br/>sync_block.cpp:2094]
        Q3[broadcastBlocks<br/>sync_block.cpp:2042]
        Q4[utxoMissingBlocks<br/>sync_block.cpp:2109]
        Q5[rollbackBlocks<br/>sync_block.cpp:2103]
    end

    subgraph 消费者[消费者: Process]
        PROC[BlockHelper::Process<br/>优先级: RB > FS > UM > SB > BB]
    end

    A_ADD --> Q2
    B_ADD --> Q1
    C_ADD --> Q1
    B3 --> Q3
    C3 --> Q4
    D3 --> Q3

    Q1 --> PROC
    Q2 --> PROC
    Q3 --> PROC
    Q4 --> PROC
    Q5 --> PROC

    style 消费者 fill:#e8f5e9
```

## 9. 异步调用标记汇总

| 异步组件 | 触发方式 | 周期 | 文件:行号 | 线程安全 |
|---------|---------|------|----------|---------|
| SyncBlock::ThreadStart | detached thread | 10s | sync_block.cpp:175 | syncThreadRunningMutex |
| CheckBlocks::StartTimer | CTimer::AsyncLoop | 30s | check_blocks.cpp:38 | isRunning 原子变量 |
| BlockStorage::_StartTimer | CTimer::AsyncLoop | 100ms | block_stroage.cpp:20 | _blockMutex (shared_mutex) |
| BlockHelper::Process | CA主循环驱动 | 不定 | block_helper.cpp:1311 | helperMutex |
| sync_add_thread_from_zero | detached thread | 一次性 | sync_block.cpp:1860 | cacheSyncMutex |
| sendBlockByUtxoRequest | detached thread | 一次性 | block_helper.cpp:1297 | 内部同步 |
| getMissingBlock | 触发 sendBlockByUtxoRequest | 一次性 | block_helper.cpp:1284 | missingUtxosMutex |
| TaskPool::commitCaTask | TaskPool投递 | 一次性 | block_helper.cpp:1010 | TaskPool内部同步 |
| TaskPool::CommitSyncBlockJob | TaskPool投递 | 一次性 | block_helper.cpp:373 | TaskPool内部同步 |
| PostSaveProcess | SaveBlock内同步调用 | 每次保存 | block_helper.cpp:1007 | 同步 |

## 10. 重点关注分析

### 10.1 回滚原子性: 两条不同路径的问题

```
路径A: rollback_block_() -> Process() -> RollbackBlocks() -> DeleteBlock()
  - 锁定 helperMutex, 在 Process() 中执行
  - 回滚后不恢复UTXO, 仅删除区块数据
  - 依赖后续同步重新下载正确区块并重建UTXO
  - 风险: 回滚和重新同步之间存在状态不一致窗口

路径B: RollBackToHeight() -> RollBackBlock(hashs)
  - algorithm.cpp:7511 调用, 无 helperMutex
  - 从 top 逐高度回滚到目标高度
  - 同样仅删除区块数据, UTXO恢复逻辑不明确
  - 风险: 与路径A可能产生锁竞争
  - 【需人工验证】: RollBackBlock() 是否包含UTXO回滚逻辑

关键问题:
  1. rollback_block_() 设置 rollbackBlocks 后立即返回 (L2102-2103),
     实际回滚在下一个 Process() 调用时才执行
  2. 如果 SaveBlock 和 rollback_block_ 被同时调用,
     Process() 的处理顺序是 先回滚后保存,
     但在 helperMutex 锁外可能存在竞争
```

### 10.2 主链选择: 规范定义 vs 实际实现

```
规范定义 (期望): 基于共识权重 (VRF + 质押权重) 选择主链
实际实现: getChainHeight() 使用 75百分位高度投票
  - block_helper.cpp:2166: sampleRate = 0.75
  - 收集所有 qualifyingNode 的高度
  - 排序取 0.75 百分位
  - 完全不考虑质押权重或共识权重
  - 注释标注的 25%恶意节点容忍度被注释掉 (L2165)

风险:
  - 少数高质押节点的高度可能被低质押节点的多数高度覆盖
  - 不区分节点权重可能导致不准确的主链高度
```

### 10.3 分叉解决: 51%共识判定的实际实现

```
NewSync (getSyncBlockHashVerification):
  - sync_block.cpp:2012: verifyNum = (retDatas.size() + 1) * 0.51
  - 注意: 使用 (retDatas + 1) 而非严格的 retDatas, 偏向保守
  - 若某个hash的node数量 >= verifyNum -> 视为正确
  - 本地hash不足51% -> rollback_block_()

FastSync:
  - sync_block.cpp:885: hits >= ret_num * 0.66 (66%拜占庭)
  - 66%而非51%: FastSync使用更高阈值

SyncFromZero:
  - sync_block.cpp:1576: success_count > backNum (66%)
  - sync_block.cpp:1595: node_count >= success_count * 0.66 (66%共识)
  - 全网络模式: 80% (L1580)

CheckBlocks:
  - check_blocks.cpp:217: >= successNum * 0.9 (90%共识)
  - 更严格: 1000高度SumHash要求90%一致

结论: 不同同步路径的共识阈值不一致 (51%-90%),
      NewSync最低(51%), CheckBlocks最高(90%)
```

### 10.4 同步降级: 快速同步失败后的从零同步

```
快速同步失败处理:
  sync_block.cpp:296-310
  1. runFastSyncOnce 失败
  2. syncSendFastSyncCount = UINT32_MAX (下轮全网络)
  3. 若 isFastSyncFailed = true -> 再试一次 (L308-310)
  4. runFastSyncCount >= 5 -> 放弃 FastSync (L258-265)

NewSync失败触发从零:
  sync_block.cpp:49-66: get_save_sync_type()
  若 chainHeight <= hashRangeSum(100) -> SyncNormal
  若 get_sum_hash_floor_height(chainHeight) - hashRangeSum <= height -> SyncNormal
  否则 -> SyncFromZero

从零同步降级:
  sync_block.cpp:334-338
  1. runFromZeroSyncOnce 失败
  2. sync_send_zero_sync_num = UINT32_MAX (全网络模式)
  3. runZeroSyncCount++
  4. 若 runZeroSyncCount > 2 -> force SyncNormal (L316-318)

全部失败后的行为:
  sync_block.cpp:374-378
  runNewSyncOnce 返回 < 0 -> sync_fail_height = 0, runFastSync = false
  退出当前轮, 等待下轮10秒重试
```

### 10.5 锁顺序: 回滚和保存的锁依赖

```
正常流程锁顺序:
  1. helperMutexLow1 (AddBroadcastBlock) -> helperMutex (AddBroadcastBlock)
  2. helperMutex (Process) -> DB Write锁 (SaveBlock)
  3. helperMutex (Process) -> DB Write锁 (RollbackBlocks)

潜在死锁风险:
  - RollbackBlock() (block_helper.cpp:1155)
    内部调用 getSyncNodeSimplified() -> get_sync_node_basic()
    这个流程会持锁访问网络, 但 helperMutex 在其调用者 Process() 中已获取

  - 但 rollback_block_() (L2100) 获取 helperMutex 设置 rollbackBlocks后返回
    实际 RollbackBlock 在 Process() 中调用 (L1252)
    此时 helperMutex 已被 Process() 获取 -> 是安全的

  - 注意: helperMutexLow1 和 helperMutex 存在嵌套锁定
    AddBroadcastBlock L1955-1956: 先 lockLow1 后 lock helperMutex
    这要求所有同时需要这两个锁的代码都遵循相同顺序

  - cacheSyncMutex (sync_block.cpp) 独立于 helperMutex
    sync_add_thread (L1865) 先获取 cacheSyncMutex 再调用 AddSyncBlock
    而 AddSyncBlock 内部获取 helperMutex -> 形成 cacheSyncMutex -> helperMutex 顺序
    【需人工验证】ThreadSync 主循环中 cacheSyncMutex 和 helperMutex 的获取顺序

结论:
  主锁 helperMutex 保护的回滚/保存操作通常是安全的,
  但 RollbackBlock() 内部网络请求时间不可控,
  持锁期间进行网络IO是一个潜在风险点.
```
