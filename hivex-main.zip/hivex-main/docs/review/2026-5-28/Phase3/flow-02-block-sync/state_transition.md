# Flow-02: 区块同步与 DAG 确认 -- 状态转换

## 1. 同步状态机 (SyncBlock 线程级别)

```mermaid
stateDiagram-v2
    [*] --> SyncStopped: 初始状态
    SyncStopped --> SyncRunning: ThreadStart()
    SyncRunning --> SyncStopped: ThreadStop()

    state SyncRunning {
        [*] --> DecisionPoint: 每10秒唤醒

        DecisionPoint --> FastSync: runFastSync==true<br/>(sync_block.cpp:273)
        DecisionPoint --> FromZeroSync: SyncFromZero判定<br/>(sync_block.cpp:321)
        DecisionPoint --> NewSync: 默认路径<br/>(sync_block.cpp:362)

        FastSync --> Success: runFastSyncOnce() == true
        FastSync --> FastSyncRetry: isFastSyncFailed<br/>(sync_block.cpp:306-310)
        FastSyncRetry --> FastSync: 下轮重试
        FastSync --> DecisionPoint: runFastSyncCount>=5<br/>(sync_block.cpp:258-265)

        FromZeroSync --> DecisionPoint: runFromZeroSyncOnce()==0
        FromZeroSync --> FromZeroSyncFullNet: 失败升级全网络
        FromZeroSyncFullNet --> DecisionPoint: 同步成功或达到上限

        NewSync --> DecisionPoint: runNewSyncOnce()==0
        NewSync --> FallbackFastSync: 返回2 -> runFastSync=true<br/>(sync_block.cpp:464-467)
        NewSync --> Failure: 返回<0 -> sync_fail_height=0<br/>(sync_block.cpp:376-378)

        state ExecuteNewSync {
            [*] --> CalcRange: use initialSyncStartHeight
            CalcRange --> Run: runNewSyncOnce()
            Run --> [*]: 完成
        }
    }

    SyncRunning --> SyncStopped: ThreadStop()
```

### 状态判定条件

| 状态 | 触发条件 | 源码位置 |
|------|---------|---------|
| FastSync | `runFastSync == true` | sync_block.cpp:273 |
| FromZeroSync | `chainHeight <= hashRangeSum(100)` 或 `nodeSelfHeight < get_sum_hash_floor_height(chainHeight) - hashRangeSum` | sync_block.cpp:49-66, L321 |
| NewSync | 默认路径 (非FastSync且非FromZeroSync) | sync_block.cpp:362 |
| ExecuteNewSync | `execute_new_sync == true` (由 `set_new_sync_height()` 设置) | sync_block.cpp:267-271, L781-792 |
| FastSyncRetry | `isFastSyncFailed == true` 连续失败 | sync_block.cpp:306-310 |

## 2. 区块生命周期状态转换

```mermaid
stateDiagram-v2
    [*] --> Received: 网络接收

    Received --> Verified: verifyFlowedBlockStatus()==0<br/>(block_helper.cpp:473)
    Received --> Rejected: 验证失败
    Rejected --> [*]: 丢弃

    Verified --> PendingBroadcast: AddBroadcastBlock()
    Verified --> PendingSync: AddSyncBlock() / AddFastSyncBlock()

    PendingBroadcast --> PreSaved: Process() -> SaveBlock(Broadcast)
    PendingSync --> PreSaved: Process() -> SaveBlock(SyncNormal/SyncFromZero)

    PreSaved --> MainChain: 交易验证通过, DB写入成功
    PreSaved --> MainChainForked: 同一高度已有其他区块

    MainChain --> Rollback: 分叉检测发现异hash
    MainChainForked --> Rollback: rollback_block_()
    Rollback --> Deleted: DeleteBlock() / RollBackToHeight()
    Deleted --> Received: 重新同步正确区块

    MainChain --> Confirmed: 持续被主链引用
    Confirmed --> [*]: 最终确认

    note right of PreSaved
        SaveBlock() = PreSaveProcess +
        ca_algorithm::SaveBlock(DB) +
        transactionCommit() +
        PostSaveProcess
    end note
```

## 3. BlockStatus (区块共识状态) 流转

投票状态跟踪 (BlockStorage::blockStatusMap):

```mermaid
stateDiagram-v2
    [*] --> AwaitSignatures: 首个节点提交区块<br/>(AddBlock -> _blockCnt)

    AwaitSignatures --> AwaitSignatures: UpdateBlock() 收集更多签名
    AwaitSignatures --> ConsensusReached: msgSize >= kConsensus(3)<br/>且 lagTime <= 10s<br/>(block_stroage.cpp:85)

    ConsensusReached --> Broadcasted: composeEndBlockMessage()<br/>sendBroadcastAddBlockRequest()<br/>(block_stroage.cpp:89-100)

    Broadcasted --> [*]: 区块已被全网广播

    AwaitSignatures --> Expired: lagTime > 10s<br/>(block_stroage.cpp:106-110)
    Expired --> [*]: _Remove(hash) 清理

    note right of ConsensusReached
        VRF随机选择足够的签名
        组装最终区块
        通过 BlockMonitor 广播
    end note
```

## 4. DAG/链状态转换 (分叉与重组)

```mermaid
stateDiagram-v2
    [*] --> SingleChain: 正常单链

    SingleChain --> ForkDetected: 同一高度出现多个区块

    ForkDetected --> MainChainSelect: CheckBlocks::_ToCheck()<br/>SumHash不一致

    MainChainSelect --> ConsensusAgreed: 90%共识支持同一SumHash<br/>(check_blocks.cpp:217)

    MainChainSelect --> ConsensusFailed: 无法达成90%共识

    ConsensusAgreed --> SingleChain: 本地hash匹配 -> 写入ThousandSumHash
    ConsensusAgreed --> Reorganization: 本地hash不匹配 -> performNewSynchronization

    ConsensusFailed --> Reorganization: performNewSynchronization<br/>逐100高度runNewSyncOnce

    Reorganization --> RollbackPhase: rollback_block_() 触发
    RollbackPhase --> SyncPhase: Process() 中 RollbackBlocks()
    SyncPhase --> RecoveryPhase: AddSyncBlock() 应用新区块
    RecoveryPhase --> SingleChain: 重组完成

    ForkDetected --> TimeoutResolve: 超时清理
    TimeoutResolve --> SingleChain: 清理过期分叉区块

    note left of MainChainSelect
        检测方法:
        1. 每30秒计算1000高度SumHash
        2. 向全网络请求相同SumHash
        3. 比对结果
    end note

    note right of Reorganization
        重组核心逻辑:
        1. determine fork point
        2. rollback divergent blocks
        3. recover UTXO state
        4. apply new chain blocks
    end note
```

## 5. 同步路径选择状态图

```mermaid
stateDiagram-v2
    [*] --> CheckNodeHeight: 获取chainHeight vs nodeSelfHeight

    CheckNodeHeight --> AtChainTop: nodeSelfHeight == chainHeight
    CheckNodeHeight --> BehindChain: nodeSelfHeight < chainHeight<br/>(sync_block.cpp:588)
    CheckNodeHeight --> AheadOfChain: nodeSelfHeight > chainHeight<br/>(sync_block.cpp:596)

    AtChainTop --> StuckDetection: 连续6次相等<br/>高度不变
    StuckDetection --> ByzantineAdjustment: needByzantineAdjustment<br/>(sync_block.cpp:562)
    ByzantineAdjustment --> SyncRunning: 获取节点 -> 检查分叉
    AtChainTop --> SyncRunning: 正常

    BehindChain --> FastSyncTry: runFastSync
    BehindChain --> NewSyncTry: 常规同步
    BehindChain --> ZeroSyncTry: 落后太多

    Note: 实际同步逻辑通过 getSyncNode 中
    discardComparisonFunc / compareReserve
    选择合适高度的节点
```

## 6. 回滚状态详细转换

```mermaid
stateDiagram-v2
    [*] --> NormalOperation: 正常出块/同步

    NormalOperation --> RollbackPending: block_helper.cpp:2100<br/>rollback_block_() 设置 rollbackBlocks

    RollbackPending --> TimeoutFilter: Process() L1408-1416<br/>过滤超时区块 (15s)

    TimeoutFilter --> InRollback: RollbackBlocks() L1233<br/>逆序遍历

    state InRollback {
        [*] --> ContractRollback: rollbackContractBlock()<br/>L1240
        ContractRollback --> BlockRollback: RollbackBlock(hash,height)<br/>L1252
        BlockRollback --> FetchCorrect: fetchRollbackBlock()<br/>获取51%共识的区块
        FetchCorrect --> DeleteBlock: DeleteBlock(dbWriter, blockHash)<br/>L1216
        DeleteBlock --> Commit: transactionCommit()<br/>L1217
    }

    InRollback --> Cleanup: ON_SCOPE_EXIT<br/>rollbackBlocks.clear() L1362

    Cleanup --> Resync: 若回滚成功<br/>SyncBlock::set_new_sync_height()
    Resync --> NormalOperation: 重新同步正确区块

    Cleanup --> NormalOperation: 无更多操作

    note right of RollbackPending
        两条回滚路径:
        A: rollback_block_() -> Process() -> RollbackBlocks()
           - 来自同步检测的增量回滚
           - 每次回滚少量区块
        B: RollBackToHeight()
           - 来自手动/命令行触发的批量回滚
           - 从顶部到目标高度全部回滚
    end note
```

## 7. 双花处理状态

```mermaid
stateDiagram-v2
    [*] --> DoubleSpendCheck: PreSaveProcess L939<br/>doubleSpendCheck()

    DoubleSpendCheck --> isDoubleSpend: 同一高度, 当前区块时间>=PBlock
    DoubleSpendCheck --> previousDoubleSpend: 当前区块高度 > PBlock高度<br/>或 同高度但时间更早
    DoubleSpendCheck --> isInvalidDoubleSpend: PBlock未找到双花

    isDoubleSpend --> DoubleSpendRecorded: checkDoubleBlooming()<br/>doubleSpendBlocks.insert()
    DoubleSpendRecorded --> [*]: 返回-7 拒绝当前区块

    previousDoubleSpend --> RollbackOldBlock: RollbackBlock(PBlock.hash)
    RollbackOldBlock --> [*]: 回滚旧区块, 接受新区块

    isInvalidDoubleSpend --> [*]: 记录到 doubleSpendBlocks

    note right of isDoubleSpend
        block_helper.cpp:853
        判定逻辑: 同高度 + 后发区块
        (blockHeight == PBlock.height() && block.time() >= PBlock.time())
    end note
```

## 8. 关键常量与阈值汇总

| 常量 | 值 | 位置 | 说明 |
|------|-----|------|------|
| SYNC_HEIGHT_TIME | 10s | sync_block.cpp:37 | 同步线程唤醒间隔 |
| SYNC_STUCK_OVERTIME_COUNT | 6 | sync_block.cpp:38 | 高度停滞触发拜占庭调整 |
| kStabilityTime | 60s | sync_block.cpp:28 | 区块稳定时间 (用于回滚判定) |
| RollBackTime | 15s | sync_block.cpp:46 | 回滚确认等待时间 |
| hashRangeSum | 100 | global.h:124 | SumHash计算区间范围 |
| sumHashRange | 1000 | global.h:125 | ThousandSumHash区间 |
| kConsensus | 3 | global.h:16 | 区块流共识签名数 |
| MIN_UNSTAKE_HEIGHT | 500 | global.h:51 | 质押节点高度分界线 |
| MIN_SYNC_QUAL_NODES | 3 | global.h:20 | 最少同步优质节点数 |
| KScalingFactor | 0.95 | sync_block.cpp:39 | 同步节点数缩放因子 |
| SUBSTR_LEN | 8 | sync_block.cpp:47 | hash比较前缀长度 |
| SEND_MAX_NUM | 10 | sync_block.cpp:2359 | 同步块数据的最大请求节点数 |
| MAX_MISSING_BLOCK_SIZE | 10 | block_helper.h:414 | 缺失区块最大缓存 |
| MAX_MISSING_UXTO_SIZE | 10 | block_helper.h:415 | 缺失UTXO最大缓存 |
| SYNC_SAVE_FAIL_TOLERANCE | 2 | block_helper.h:416 | 同步保存失败容错 |

## 9. 响应阈值汇总

| 步骤 | 阈值 | 位置 |
|------|------|------|
| FastSync SumHash 响应 | 80% | sync_block.cpp:802 |
| FastSync 拜占庭共识 | 66% | sync_block.cpp:885 |
| NewSync HashVerification 响应 | 80% | sync_block.cpp:1897 |
| NewSync 51% hash共识 | 51% | sync_block.cpp:2012 |
| FromZero 响应 | 80%/90% | sync_block.cpp:1510,1516 |
| FromZero 拜占庭共识 | 66%/80% | sync_block.cpp:1576,1580 |
| FromZero hash共识 | 66% | sync_block.cpp:1595 |
| CheckBlocks 响应 | 90% | check_blocks.cpp:144 |
| CheckBlocks 响应成功数 | 80% | check_blocks.cpp:201 |
| CheckBlocks 共识 | 90% | check_blocks.cpp:217 |
| calculateByzantineSumHash 响应 | 90% | check_blocks.cpp:315 |
| calculateByzantineSumHash 拜占庭 | 80% | check_blocks.cpp:381 |
| calculateByzantineSumHash 共识 | 85% | check_blocks.cpp:409 |
| getChainHeight 百分位 | 75% | block_helper.cpp:2166 |
| SyncNodeBasic 最少返回 | 75% | sync_block.cpp:762 |
