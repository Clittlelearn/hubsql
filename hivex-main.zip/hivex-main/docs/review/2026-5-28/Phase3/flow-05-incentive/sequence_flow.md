# MeMeChain Flow 05 -- Annual Incentive Calculation and Distribution Sequence Diagram

> All file paths relative to project root: `//wsl$/wsl-mm/home/wbl/mm/`

---

## 1. Overview Sequence

```mermaid
sequenceDiagram
    actor User as Node Operator
    participant RPC as RPC API
    participant BonusTrans as BonusTrans/FundTrans
    participant CalcBonus as ca_algorithm::CalcBonusValue
    participant Network as ca_algorithm::GetNetworkStakingRate
    participant Yearly as ca_algorithm::GetNewAnnualizedRate
    participant Abnormal as ca_algorithm::fetchAbnormalSignAddrListByPeriod
    participant EIP1559 as EIP1559FeeCalculator
    participant DB as DB Layer

    Note over DB,EIP1559: === Annualized Rate Calculation (Synchronous, on-demand trigger) ===

    CalcBonus->>Network: GetNetworkStakingRate(curTime, stakingRate)
    Network->>DB: getTotalCirculationAsOfTodayStart(curTime, totalSupply)
    Network->>DB: getLockedAmountAsOfTodayStart(curTime, totalLockedAmount)
    Note over Network: stakingRate = (totalLockedAmount / totalSupply) * 100%
    Network-->>CalcBonus: stakingRate (clamped [10%, 100%])

    CalcBonus->>Yearly: GetNewAnnualizedRate(curTime, stakingRate, annualizedRate)
    Yearly->>Yearly: weeksSinceStart = (curTime - genesisTime) / weekInMicroseconds
    Yearly->>Yearly: k = mapStakingRateToK(stakingRate)
    Note over Yearly: k = kMin + (stakingRate-minStaking) * (kMax-kMin)/(maxStaking-minStaking)
    Yearly->>Yearly: inflationRates = calculateInflationRates(k, 520, 5.0, 0.5)
    Note over Yearly: rate[w] = endRate + (startRate-endRate) * exp(-k * x)
    Yearly->>Yearly: annualizedRates = calculateAnnualizedRates(inflationRates, stakingRate)
    Note over Yearly: annualizedRate[w] = inflationRate[w] / stakingRatio
    Yearly-->>CalcBonus: annualizedRate (percentage, e.g. 5.67%)

    Note over CalcBonus: Precision conversion:
    Note over CalcBonus: annualizedRate = round(annualizedRate/100*100)/100 → DECIMAL

    Note over CalcBonus: === Abnormal Node Detection ===
    CalcBonus->>Abnormal: fetchAbnormalSignAddrListByPeriod(curTime, addr_percent, addrSignCount)
    Abnormal->>DB: getSignAddrByPeriod(period-1, signatureAddresses)
    Abnormal->>DB: getSignCountByPeriod(period-1, addr, signNumber)
    Note over Abnormal: average = allSignNumber / addrSignCount.size()
    Note over Abnormal: For each addr: if own < average → dividendRate = own/average
    Abnormal-->>CalcBonus: addr_percent (map<addr, dividendRate>)

    Note over CalcBonus: === Reward Calculation per Delegator ===
    CalcBonus->>DB: GetDelegatingAmountAndDuration(bonusAddr, curTime, ...)
    loop Each delegator
        Note over CalcBonus: baseReward = annualizedRate * delegateAmount / 365
        alt dividendRate != 0 (abnormal node)
            Note over CalcBonus: actualReward = dividendRate * baseReward
        else isQualified (normal node)
            Note over CalcBonus: actualReward = baseReward
        end
    end
    CalcBonus-->>BonusTrans: delegator_reward_allocations

    Note over BonusTrans: === Bonus Transaction (BONUS) ===
    User->>RPC: createBonus(addr, asset_type, ...)
    RPC->>BonusTrans: BonusTrans::trans()
    BonusTrans->>BonusTrans: evaluateBonusEligibility(addr, curTime)
    BonusTrans->>CalcBonus: CalcBonusValue(curTime, addr, values)
    CalcBonus-->>BonusTrans: values (per-delegator reward map)
    loop Each delegator
        Note over BonusTrans: operator_commission = reward * commissionRate + 0.5
        Note over BonusTrans: (uint64_t truncation: rounds to nearest integer)
    end
    BonusTrans->>BonusTrans: Build UTXOs, sign, broadcast

    Note over BonusTrans: === Fund Transaction (FUND) ===
    User->>RPC: createFund(addr, encoded_info)
    RPC->>BonusTrans: FundTrans::trans()
    BonusTrans->>DB: getGasAmountByPeriod(period-1, assetType, gasAmount)
    BonusTrans->>BonusTrans: CheckFundQualificationAndGetRewardAmount(addr, curTime, return_value)
    alt is_locked (has locked stake)
        Note over BonusTrans: lockedRate = return_value / totalLockedAmount
        Note over BonusTrans: reward = uint64_t(lockedRate * gasAmount * 0.5)
    end
    alt is_packaged (has packaged blocks)
        Note over BonusTrans: packageRate = times / count
        Note over BonusTrans: reward = uint64_t(packageRate * gasAmount * 0.5)
    end
    BonusTrans->>BonusTrans: Build UTXOs, sign, broadcast

    Note over EIP1559: === EIP-1559 Dynamic Gas Fee Adjustment ===
    Note over EIP1559: Triggered per contract transaction execution
    EIP1559->>EIP1559: adjustment = (actual_gas - target_gas) / (target_gas * 8.0)
    EIP1559->>EIP1559: new_fee_exact = old_fee * (1.0 + adjustment)
    alt actual_gas > target_gas (congested)
        Note over EIP1559: new_fee = ceil(new_fee_exact) -- growth rounds UP
    else actual_gas < target_gas (idle)
        Note over EIP1559: new_fee = floor(new_fee_exact) -- reduction rounds DOWN
    end
    Note over EIP1559: new_fee = max(new_fee, 0.0)
    Note over EIP1559: gasCost *= (uint64_t)new_baseFee
```

---

## 2. Annualized Rate Calculation Detail

```mermaid
sequenceDiagram
    participant Caller as CalcBonusValue
    participant Y as GetNewAnnualizedRate
    participant K as mapStakingRateToK
    participant Inf as calculateInflationRates
    participant Annual as calculateAnnualizedRates
    participant Genesis as MagicSingleton<Genesis>

    Caller->>Y: GetNewAnnualizedRate(curTime, stakingRate, &annualizedRate)

    Note over Y: Step 1: Compute weeks since launch
    Y->>Genesis: GetGenesisTime()
    Genesis-->>Y: genesisTime (microseconds)
    Note over Y: Time unit auto-detection:
    Note over Y: if genesisTime < 10^12 → convert seconds to microseconds
    Note over Y: timeDiff = curTime - genesisTime
    Note over Y: weekInMs = 7*24*60*60*1000000 = 604,800,000,000 us
    Note over Y: weeksSinceStart = timeDiff / weekInMs
    Note over Y: if weeksSinceStart >= 520 → clamp to 519

    Note over Y: Step 2: Map staking rate to decay parameter k
    Y->>K: mapStakingRateToK(stakingRate)
    Note over K: k = 1.0 + (stakingRate-10)*(20-1)/(100-10)
    Note over K: Linear interpolation: 10%→k=1, 100%→k=20
    Note over K: Throws invalid_argument if stakingRate < 10 or > 100
    K-->>Y: k value (1.0 to 20.0)

    Note over Y: Step 3: Generate 520-week inflation sequence
    Y->>Inf: calculateInflationRates(k, 520, 5.0%, 0.5%)
    Note over Inf: For w=1..520:
    Note over Inf: x = (w-1)/(520-1) -- normalized time [0,1]
    Note over Inf: rate[w] = 0.5 + (5.0-0.5)*exp(-k*x)
    Note over Inf: Exponential decay: 5%→0.5% over 10 years
    Inf-->>Y: inflationRates[520]

    Note over Y: Step 4: Convert inflation to annualized rate
    Y->>Annual: calculateAnnualizedRates(inflationRates, stakingRate)
    Note over Annual: stakingRatio = stakingRate/100.0
    Note over Annual: annualizedRate[w] = inflationRate[w] / stakingRatio
    Annual-->>Y: annualizedRates[520]

    Note over Y: Step 5: Select current week's rate
    Note over Y: annualizedRate = annualizedRates[weeksSinceStart]
    Y-->>Caller: annualizedRate (percentage value)

    Note over Caller: Critical precision conversion:
    Note over Caller: annualizedRate = round(annualizedRate/100*100)/100
    Note over Caller: 【RISK】See note in section 5 below
```

---

## 3. Fund Claim Sequence (FUND)

```mermaid
sequenceDiagram
    actor User as Node Operator
    participant RPC as createFund
    participant FundTrans as FundTrans::trans()
    participant CG as CheckFundQualification
    participant DB as DBReader

    User->>RPC: POST /createFund (addr, encoded_info)
    RPC->>FundTrans: trans()

    FundTrans->>CG: fetchAvailableAssetType(asset_map)
    CG->>DB: Query all available asset types + VOTE
    CG-->>FundTrans: asset_map

    loop Each assetType
        FundTrans->>DB: getGasAmountByPeriod(period-1, assetType, gasAmount)
        Note over DB: period = (curTime - genesisTime) / 86400 (days)
        alt gasAmount != 0
            Note over FundTrans: Accumulate fund-eligible asset types
        end
    end

    alt asset_type_amount is empty
        Note over FundTrans: ERROR: "No fund reward the day before"
    end

    FundTrans->>CG: CheckFundQualificationAndGetRewardAmount(addr, curTime, return_value)
    Note over CG: Checks: has staked, not already claimed
    alt ret == -6
        Note over FundTrans: "Already claimed fund reward"
    else ret == 0
        FundTrans->>DB: getTotalLockedAmonut(total_locked_amount)
        alt return_value > 0 AND total_locked_amount > 0
            Note over FundTrans: is_locked = true
        end
    end

    FundTrans->>FundTrans: VerifyBonusAddr(addr)
    alt is bonus addr AND packaged this period
        FundTrans->>DB: getPackagerCountByPeriod(period-1, addr, times)
        FundTrans->>DB: getBlockNumberByPeriod(period-1, count)
        alt times > 0 AND count > 0
            Note over FundTrans: is_packaged = true
        end
    end

    alt NOT is_packaged AND NOT is_locked
        Note over FundTrans: ERROR: "Not eligible to claim fund"
    end

    loop Each eligible assetType
        FundTrans->>FundTrans: createUtxoFundTransfer(utxo, param, ...)
        alt is_locked
            Note over FundTrans: rate = double(return_value)/double(total_locked_amount)
            Note over FundTrans: value = uint64_t(rate * gasAmount * 0.5)
            Note over FundTrans: 【RISK】double → uint64_t truncation
        end
        alt is_packaged
            Note over FundTrans: rate = double(times)/double(count)
            Note over FundTrans: value = uint64_t(rate * gasAmount * 0.5)
            Note over FundTrans: 【RISK】double → uint64_t truncation
        end
    end
    FundTrans->>FundTrans: Sign, set consensus, broadcast
```

---

## 4. Key Annotations

### Time Source Dependency
| Location | File | Line | Description |
|----------|------|------|-------------|
| `GetUTCTimestamp()` | `utils/time_util.cpp` | 32-36 | `gettimeofday()` -- local system clock (microseconds) |
| `GetGenesisTime()` | `common/genesis.h` | 44 | Returns the genesis block timestamp (microseconds) |
| `GetPeriod(txTime)` | `utils/time_util.cpp` | 201-204 | `(txTime - genesisTime) / 86400` -- days since genesis (seconds math) |
| `GetMorningTime(t)` | `utils/time_util.cpp` | 189-200 | Returns midnight UTC timestamp via `gmtime()` + `mktime()` |
| `weekInMicroseconds` | `ca/algorithm.cpp` | 8004 | `7*24*60*60*1000000 = 604,800,000,000` -- fits in uint64_t |

### Precision Conversion Points
| Location | File | Line | Conversion | Risk |
|----------|------|------|-------------|------|
| Percentage to decimal | `ca/algorithm.cpp` | 7835 | `round(rate/100*100)/100` | See Section 5 |
| Reward calculation | `ca/algorithm.cpp` | 7849 | `annualizedRate * amount / 365` | Double * uint64_t truncation |
| Commission | `ca/transaction/bonus.cpp` | 144,152,321 | `operator_commission = reward * rate + 0.5` → uint64_t | Truncation rounding |
| Fund lock reward | `ca/transaction/fund.cpp` | 289 | `uint64_t(rate * gasAmount * 0.5)` | Double → uint64_t loss |
| Fund package reward | `ca/transaction/fund.cpp` | 299 | `uint64_t(rate * gasAmount * 0.5)` | Double → uint64_t loss |

### Lock Acquisition Points
| Location | File | Line | Mutex | Purpose |
|----------|------|------|-------|---------|
| bonusMutex | `ca/global.h` | 29 | `std::mutex` | Bonus calculation synchronization |
| kDelegatingMutex | `ca/global.h` | 30 | `std::mutex` | Delegating operation synchronization |
| LOCK_MUTEX | `ca/global.h` | 32 | `std::mutex` | Lock operation synchronization |
| bonus_addr_mutex_ | `ca/bonus_addr_cache.h` | 47 | `std::shared_mutex` | Bonus address cache access |

---

## 5. Critical Risk Analysis

### 5.1 Annualized Rate Precision Bug (ca/algorithm.cpp:7835)

```cpp
annualizedRate = std::round(annualizedRate / 100.0 * 100.0) / 100.0;
```

**Analysis:** `x / 100.0 * 100.0` mathematically simplifies to `x` (with possible FP rounding error). The `std::round()` then rounds to the nearest integer. The final `/ 100.0` converts from percentage to decimal.

- If `annualizedRate = 5.67%`:
  - `5.67 / 100.0 * 100.0` ≈ 5.67
  - `std::round(5.67)` = 6.0
  - `6.0 / 100.0` = 0.06
  - Result: 6% instead of 5.67% (0.33% absolute error)

**Impact:** All reward calculations lose precision -- the annualized rate is always rounded to the nearest integer percentage. A claim of 100,000 tokens would receive 6,000 vs actual 5,670 (5.8% overpayment).

**Recommended fix:**
```cpp
// Option A: Round to 2 decimal places then convert to decimal
annualizedRate = std::round(annualizedRate * 100.0) / 10000.0;

// Option B: Simply convert percentage to decimal (no rounding)
annualizedRate = annualizedRate / 100.0;
```

### 5.2 Double to uint64_t Truncation (bonus.cpp:144,152)

```cpp
operator_commission = delegator.second * temp_commission_rate + 0.5;
```

`delegator.second` is `uint64_t`, multiplied by `double` `temp_commission_rate`. The `+ 0.5` is a manual rounding (bankers-round). However, the result is assigned to `uint64_t`, which truncates the fractional part. The `+ 0.5` adds half before truncation, effectively rounding to nearest integer.

**Risk:** For very large delegation amounts (> 2^53), `double` loses integer precision (IEEE 754 double has 53 bits of mantissa). With `kDecimalNum = 100,000,000`, amounts could exceed safe range.

`uint64_t` max value: 18,446,744,073,709,551,615 ≈ 1.8 × 10^19. In token units (with 8 decimals), this is 1.8 × 10^11 tokens. Since `double` has 53 bits of integer precision (≈ 9 × 10^15), if `delegator.second * temp_commission_rate` exceeds 9 × 10^15 (in raw units, or 9 × 10^7 tokens), precision is lost.

Given `kMinDelegatingAmt = 500 * 100,000,000 = 50,000,000,000` and `KInvestmentCap = 3,500,000 * 100,000,000 = 350,000,000,000,000`, individual amounts are within the safe double range.

### 5.3 Division by Zero Risk (algorithm.cpp:8084,7993)

- **Line 8084:** `if (totalSupply > 0)` -- properly guarded
- **Line 8097-8101:** Falls back to `stakingRate = 10.0` when `totalSupply == 0`
- **Line 7993:** `projectStartTime` from Genesis -- if equal to `curTime`, `timeDiff = 0`, `weeksSinceStart = 0` (no division error, just yields week 0)
- **Line 7794:** `GetMorningTime(curTime)` -- always valid timestamp
- **fund.cpp:105:** `double(return_value) / double(total_locked_amount)` -- guarded by `total_locked_amount != 0` at line 90
- **fund.cpp:127:** `double(times) / double(count)` -- guarded by `times != 0 && count != 0` at line 120

### 5.4 Integer Overflow: weekInMicroseconds (algorithm.cpp:8004)

```cpp
uint64_t weekInMicroseconds = 7ULL * 24ULL * 60ULL * 60ULL * 1000000ULL;
```
- `7*24*60*60*1,000,000 = 604,800,000,000 ≈ 6.05 × 10^11`
- `uint64_t` max: `1.84 × 10^19`
- **No overflow.** Safe.

### 5.5 GetMorningTime Potential Issue (time_util.cpp:189-200)

```cpp
uint64_t TimeUtil::GetMorningTime(time_t t) 
{
    t = t/1000000;
    struct tm * tm = gmtime(&t);
    tm->tm_hour = 0;
    tm->tm_min = 0;
    tm->tm_sec = 0;
    uint64_t zero_time = mktime(tm);
    return zero_time;
}
```

**Risk:** `mktime()` interprets the `struct tm` as LOCAL time, while `gmtime()` decomposes the timestamp as UTC. This creates a timezone-dependent offset. The midnight computed by `mktime(tm)` where `tm` was created via `gmtime()` does NOT correspond to midnight UTC -- it corresponds to when the LOCAL clock shows the UTC hours/minutes/seconds. 【需人工验证】

### 5.6 cpp_bin_float_50 Not Used in Key Calculation Paths

The typedef at `ca/algorithm.cpp:55`:
```cpp
typedef boost::multiprecision::cpp_bin_float_50 cpp_bin_float;
```
This type is declared but **not used** in `CalcBonusValue`, `GetNewAnnualizedRate`, `mapStakingRateToK`, or the reward calculation functions. All floating-point math uses native `double`. 【需人工验证】 whether this is intentional or the precision type was planned but not implemented.

### 5.7 Period Calculation Uses Parameter curTime Pass-by-Reference

`fetchAbnormalSignAddrListByPeriod(uint64_t &curTime, ...)` at algorithm.cpp:66 takes `curTime` by non-const reference, but never modifies it. The parameter unnecessarily signals that `curTime` may be modified. This is a code quality issue, not a functional bug.
