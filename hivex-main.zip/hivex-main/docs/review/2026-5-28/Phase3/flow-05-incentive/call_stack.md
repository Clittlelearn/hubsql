# MeMeChain Flow 05 -- Function Call Stack

> All file paths relative to project root: `//wsl$/wsl-mm/home/wbl/mm/`
> Line numbers as of analysis date (2026-05-26)

---

## 1. Core Call Graph

```
RPC Entry Points
├── createBonus()                 [rpc/api/post/rpc_api_bonus.cpp:15]
│   └── BonusTrans::trans()       [ca/transaction/bonus.cpp:18]
│       ├── evaluateBonusEligibility(addr, curTime)
│       ├── ca_algorithm::CalcBonusValue(curTime, addr, values)  [ca/algorithm.cpp:7743]
│       │   ├── fetchAbnormalSignAddrListByPeriod(curTime, addr_percent, addrSignCount)  [ca/algorithm.cpp:66]
│       │   │   ├── TimeUtil::GetPeriod(curTime)                          [utils/time_util.cpp:201]
│       │   │   ├── DBReader::getSignAddrByPeriod(period-1, addresses)    [db/db_api.h:491]
│       │   │   └── DBReader::getSignCountByPeriod(period-1, addr, count) [db/db_api.h:459]
│       │   ├── TimeUtil::GetMorningTime(curTime)                         [utils/time_util.cpp:189]
│       │   ├── GetDelegatingAmountAndDuration(bonusAddr, curTime, zeroTime, ...)
│       │   ├── GetNetworkStakingRate(curTime, stakingRate)              [ca/algorithm.cpp:8062]
│       │   │   ├── getTotalCirculationAsOfTodayStart(curTime, totalSupply)
│       │   │   └── getLockedAmountAsOfTodayStart(curTime, totalLockedAmount)
│       │   └── GetNewAnnualizedRate(curTime, stakingRate, annualizedRate) [ca/algorithm.cpp:7985]
│       │       ├── Genesis::GetGenesisTime()                             [common/genesis.h:44]
│       │       ├── mapStakingRateToK(stakingRate)                        [ca/algorithm.cpp:7903]
│       │       ├── calculateInflationRates(k, 520, 5.0, 0.5)             [ca/algorithm.cpp:7923]
│       │       └── calculateAnnualizedRates(inflationRates, stakingRate) [ca/algorithm.cpp:7947]
│       ├── ca_algorithm::GetCommissionPercentage(addr, rate)
│       └── createUtxoTransferTo() / makeTxInfor() / goMessage()
│
├── createFund()                   [rpc/api/post/rpc_api_fund.cpp:15]
│   └── FundTrans::trans()        [ca/transaction/fund.cpp:17]
│       ├── fetchAvailableAssetType(assetMap)
│       ├── DBReader::getGasAmountByPeriod(period-1, type, amount)        [db/db_api.h:872]
│       ├── CheckFundQualificationAndGetRewardAmount(addr, curTime, retval)
│       ├── DBReader::getTotalLockedAmonut(total_locked_amount)           [db/db_api.h:904]
│       ├── DBReader::getPackagerCountByPeriod(period-1, addr, times)     [db/db_api.h:890]
│       ├── DBReader::getBlockNumberByPeriod(period-1, count)             [db/db_api.h:475]
│       └── createUtxoFundTransfer()                                     [ca/transaction/fund.cpp:278]
│
└── Transaction Verification       [ca/algorithm.cpp]
    └── verifyTransactionRequest() [ca/algorithm.cpp]
        ├── ca_algorithm::CalcBonusValue(tx_time, owner, companyDividend) [ca/algorithm.cpp:1886]
        │   (Same call chain as above; used to verify reward amounts in bonus txs)
        └── CheckFundQualificationAndGetRewardAmount(...)                  [ca/algorithm.cpp:2366]
```

---

## 2. Detailed Call Stacks

### 2.1 GetNewAnnualizedRate

```
ca_algorithm::GetNewAnnualizedRate(curTime, stakingRate, annualizedRate)
  File: ca/algorithm.cpp, Line: 7985
  Purpose: Calculate current annualized interest rate using exponential decay model

  ├── Genesis::GetGenesisTime()
  │   File: common/genesis.h, Line: 44
  │   Returns: uint64_t (microseconds since epoch)
  │   Purpose: Get project launch timestamp
  │
  ├── [Time unit auto-detection block]
  │   File: ca/algorithm.cpp, Lines: 7997-8000
  │   Logic: if projectStartTime < 10^12 → assume seconds, convert to microseconds
  │   Note: 【RISK】If genesis time is exactly between 10^12 and 10^6*10^12, this
  │         check could fail. A genesis time in milliseconds (~1.7e12 for 2023)
  │         would NOT be detected as needing conversion.
  │
  ├── [Week calculation]
  │   File: ca/algorithm.cpp, Lines: 8003-8005
  │   timeDiff = curTime - projectStartTime
  │   weekInMicroseconds = 7 * 24 * 60 * 60 * 1000000 = 604,800,000,000
  │   weeksSinceStart = timeDiff / weekInMicroseconds
  │   Overflow check: 604,800,000,000 < 1.8e19 → SAFE
  │
  ├── [Week clamping]
  │   File: ca/algorithm.cpp, Lines: 8015-8019
  │   if weeksSinceStart >= 520 → clamp to 519
  │
  ├── mapStakingRateToK(stakingRate)
  │   File: ca/algorithm.cpp, Line: 7903
  │   Input:  stakingRate (double, 10% to 100%)
  │   Output: k (double, 1.0 to 20.0)
  │   Logic:  k = 1.0 + (stakingRate - 10.0) * (20.0 - 1.0) / (100.0 - 10.0)
  │           Linear interpolation: 10%→k=1, 100%→k=20
  │   Validation: if stakingRate < 10 || stakingRate > 100 → throw invalid_argument
  │   Note:     Higher staking rate → higher k → faster decay → lower yields
  │
  ├── calculateInflationRates(k, 520, 5.0, 0.5)
  │   File: ca/algorithm.cpp, Line: 7923
  │   Inputs:  k = decay parameter (1.0-20.0)
  │            totalWeeks = 520 (10 years)
  │            startRate = 5.0% (week 1 inflation)
  │            endRate = 0.5% (week 520 inflation)
  │   Output:  std::vector<double> of 520 weekly inflation rates
  │   Logic:   For w = 1 to 520:
  │              x = (w - 1) / (totalWeeks - 1)    // Normalized time [0, 1]
  │              rate[w] = endRate + (startRate - endRate) * exp(-k * x)
  │   Notes:   - Exponential decay from 5% to 0.5%
  │            - Higher k → steeper initial decline → faster convergence to 0.5%
  │            - totalWeeks - 1 = 519 → no division by zero (totalWeeks >= 2)
  │            - 【RISK】totalWeeks is int, not checked for < 2
  │
  ├── calculateAnnualizedRates(inflationRates, stakingRate)
  │   File: ca/algorithm.cpp, Line: 7947
  │   Inputs:  inflationRates (vector of 520 inflation rates)
  │            stakingRate (current network staking percentage)
  │   Output:  std::vector<double> of 520 annualized rates (percentage)
  │   Logic:   stakingRatio = stakingRate / 100.0
  │            annualizedRate[i] = inflationRates[i] / stakingRatio
  │   Validation: if stakingRate < 10 → clamp to 10; if > 100 → throw
  │   Notes:   - Lower staking rate → LARGER annualized rate (fewer stakers share
  │              the inflation) -- the model rewards stakers during low participation
  │            - This is the "yield amplifier" effect
  │
  └── [Final lookup]
      File: ca/algorithm.cpp, Lines: 8040-8049
      if weeksSinceStart < annualizedRates.size():
          annualizedRate = annualizedRates[weeksSinceStart]
      else:
          annualizedRate = annualizedRates.back()     // Fallback to last week
```

### 2.2 CalcBonusValue

```
ca_algorithm::CalcBonusValue(curTime, bonusAddr, values, isDisplay)
  File: ca/algorithm.cpp, Line: 7743
  Purpose: Calculate bonus (staking reward) value for a given node address

  ├── fetchAbnormalSignAddrListByPeriod(curTime, addr_percent, addrSignCount)
  │   File: ca/algorithm.cpp, Line: 66
  │   ├── TimeUtil::GetPeriod(curTime)
  │   │   File: utils/time_util.cpp, Line: 201
  │   │   Logic: (curTime/1e6 - genesisTime/1e6) / 86400  → days since genesis
  │   │   Returns: uint64_t (day index)
  │   ├── DBReader::getSignAddrByPeriod(period - 1, signatureAddresses)
  │   │   File: db/db_api.h, Line: 491
  │   │   Purpose: Get all addresses that signed blocks in the previous period
  │   ├── DBReader::getSignCountByPeriod(period - 1, addr, signNumber)
  │   │   File: db/db_api.h, Line: 459
  │   │   Purpose: Get signature count for a specific address in the period
  │   ├── [Average calculation]
  │   │   Line: 95
  │   │   average = allSignNumber / addrSignCount.size()
  │   │   【RISK】Integer division: if allSignNumber=5, size=10 → average=0
  │   │           Cast to double happens AFTER division
  │   │           Actually looking more carefully at the code:
  │   │           `double average = allSignNumber / addrSignCount.size();`
  │   │           Both operands are uint64_t, so integer division occurs first,
  │   │           then conversion to double. This truncates the average.
  │   └── [Abnormal detection]
  │       Line: 97-103
  │       if (double)addr_cnt.second >= average:  pass  (normal node)
  │       else:  addr_percent[addr] = (double)own_cnt / average  (abnormal)
  │
  ├── TimeUtil::GetMorningTime(curTime)
  │   File: utils/time_util.cpp, Line: 189-200
  │   Logic: Convert to seconds, get UTC midnight via gmtime(), compute via mktime()
  │   Returns: uint64_t (seconds since epoch)
  │   Usage:  curTime * 1000000 → back to microseconds for comparison
  │   【RISK】mktime() interprets tm as LOCAL time, but gmtime() produced UTC.
  │           See timezone issue in sequence_flow.md Section 5.5.
  │
  ├── GetDelegatingAmountAndDuration(bonusAddr, curTime, zeroTime, mpDelegatingAddr2Amount)
  │   File: ca/algorithm.cpp (definition), Line: 7797 (call site)
  │   Purpose: Get all delegating addresses, their amounts, and delegation duration
  │   Returns: multimap<delegator_addr, pair<amount, duration>>
  │
  ├── GetNetworkStakingRate(curTime, stakingRate)
  │   File: ca/algorithm.cpp, Line: 8062
  │   (See section 2.3 below)
  │
  ├── GetNewAnnualizedRate(curTime, stakingRate, annualizedRate)
  │   File: ca/algorithm.cpp, Line: 7985
  │   (See section 2.1 above)
  │
  ├── [Precision conversion]
  │   File: ca/algorithm.cpp, Line: 7835
  │   annualizedRate = std::round(annualizedRate / 100.0 * 100.0) / 100.0;
  │   Purpose: Convert percentage to decimal (e.g., 5% → 0.05)
  │   【RISK】Rounds to integer percentage, losing sub-percent precision
  │          See sequence_flow.md Section 5.1
  │
  ├── [Reward loop -- abnormal nodes]
  │   File: ca/algorithm.cpp, Lines: 7882-7889
  │   Condition: dividendRate != 0.0 (node has below-average signatures)
  │   Logic:    values[addr] = dividendRate * (annualizedRate * amount / 365)
  │   Notes:    - dividendRate ∈ (0, 1) reduces the reward proportionally
  │             - annualizedRate is now a decimal (e.g., 0.05)
  │             - amount is uint64_t (raw token units with 8 decimal places)
  │             - Result stored in uint64_t → truncation
  │
  └── [Reward loop -- normal/qualified nodes]
      File: ca/algorithm.cpp, Lines: 7891-7897
      Condition: isQualified == true (node at or above average)
      Logic:    values[addr] = annualizedRate * amount / 365
      Notes:    Same formula without the dividendRate penalty
```

### 2.3 GetNetworkStakingRate

```
ca_algorithm::GetNetworkStakingRate(curTime, stakingRate)
  File: ca/algorithm.cpp, Line: 8062
  Purpose: Calculate the current network staking rate percentage

  ├── getTotalCirculationAsOfTodayStart(curTime, totalSupply)
  │   File: ca/algorithm.cpp (definition), Line: 8070 (call site)
  │   Purpose: Get total token circulation at the START of today
  │   Note:    Uses "as of today start" to prevent intra-day manipulation
  │
  ├── getLockedAmountAsOfTodayStart(curTime, totalLockedAmount)
  │   File: ca/algorithm.cpp (definition), Line: 8077 (call site)
  │   Purpose: Get total locked (staked) token amount at the START of today
  │
  ├── [Rate calculation]
  │   File: ca/algorithm.cpp, Lines: 8084-8101
  │   if totalSupply > 0:
  │       stakingRate = (double(totalLockedAmount) / double(totalSupply)) * 100.0
  │       clamp to [10.0, 100.0]
  │   else:
  │       stakingRate = 10.0  (default / fallback)
  │
  └── [Logging]
      File: ca/algorithm.cpp, Line: 8102
      DEBUGLOG("totalSupply: {}, totalLockedAmount: {}, stakingRate: {}", ...)
```

### 2.4 mapStakingRateToK

```
ca_algorithm::mapStakingRateToK(stakingRate)
  File: ca/algorithm.cpp, Line: 7903
  Purpose: Map staking rate (10%-100%) to decay parameter k (1.0-20.0)

  ├── [Input validation]
  │   File: ca/algorithm.cpp, Lines: 7908-7912
  │   if stakingRate < 10 || stakingRate > 100:
  │       throw std::invalid_argument("质押率必须在 10% 到 100% 之间")
  │   Note: This throw propagates up through GetNewAnnualizedRate's try/catch
  │
  └── [Linear interpolation]
      File: ca/algorithm.cpp, Line: 7915
      k = 1.0 + (stakingRate - 10.0) * (20.0 - 1.0) / (100.0 - 10.0)
      Simplified: k = 1.0 + (stakingRate - 10.0) * 19.0 / 90.0
      Examples:
        stakingRate = 10%  → k = 1.0
        stakingRate = 55%  → k = 10.5
        stakingRate = 100% → k = 20.0
```

### 2.5 calculateInflationRates

```
ca_algorithm::calculateInflationRates(k, totalWeeks=520, startRate=5.0, endRate=0.5)
  File: ca/algorithm.cpp, Line: 7923
  Purpose: Generate a 520-week sequence of exponentially decaying inflation rates

  ├── [Loop: w = 1 to totalWeeks]
  │   File: ca/algorithm.cpp, Lines: 7930-7934
  │   x = (w - 1) / (totalWeeks - 1)  // Normalize time to [0, 1]
  │   rate = endRate + (startRate - endRate) * exp(-k * x)
  │
  │   Derivation:
  │     At w=1 (x=0):  rate = 0.5 + 4.5 * exp(0)    = 5.0%
  │     At w=520 (x=1): rate = 0.5 + 4.5 * exp(-k)  → depends on k
  │
  │   With k=1:   rate(520) = 0.5 + 4.5 * e^(-1)  = 0.5 + 1.655 = 2.16%
  │   With k=10:  rate(520) = 0.5 + 4.5 * e^(-10) = 0.5 + 0.0002 ≈ 0.50%
  │   With k=20:  rate(520) = 0.5 + 4.5 * e^(-20) ≈ 0.50000004%
  │
  │   【RISK】K=1.0 produces inflation that hasn't fully decayed to 0.5% by week 520.
  │           This means at low staking rates (10%), the inflation model doesn't
  │           converge within the 10-year window.
  │
  └── [Debug logging]
      Lines: 7937-7939
      Logs rate at w=1, w=520, and every 52 weeks (yearly markers)
```

### 2.6 calculateAnnualizedRates

```
ca_algorithm::calculateAnnualizedRates(inflationRates, stakingRate)
  File: ca/algorithm.cpp, Line: 7947
  Purpose: Convert weekly inflation rates to annualized yield rates

  ├── [Staking rate clamping]
  │   File: ca/algorithm.cpp, Lines: 7953-7960
  │   if stakingRate < 10 → stakingRate = 10.0
  │   if stakingRate > 100 → throw invalid_argument
  │
  ├── [Conversion]
  │   File: ca/algorithm.cpp, Lines: 7963-7971
  │   stakingRatio = stakingRate / 100.0
  │   For each inflation rate:
  │     annualizedRate = inflationRate / stakingRatio
  │
  └── [Mathematical relationship]
      annualizedRate = inflationRate / (stakingRate/100)
                      = 100 * inflationRate / stakingRate
      With stakingRate=50%:  annualizedRate = 2 * inflationRate
      With stakingRate=10%:  annualizedRate = 10 * inflationRate  (amplified!)
```

### 2.7 EIP1559FeeCalculator::calculateNewFee (Gas Adjustment)

```
EIP1559FeeCalculator::calculateNewFee(old_fee, actual_gas, target_gas)
  File: ca/fee_calculator.h, Line: 12
  Purpose: Calculate new base fee per EIP-1559 dynamic fee model

  ├── [Parameter validation]
  │   File: ca/fee_calculator.h, Lines: 16-24
  │   old_fee < 0      → throw invalid_argument
  │   actual_gas < 0   → throw invalid_argument
  │   target_gas <= 0  → throw invalid_argument
  │
  ├── [Adjustment factor]
  │   File: ca/fee_calculator.h, Line: 27
  │   adjustment_factor = (actual_gas - target_gas) / (target_gas * 8.0)
  │
  │   Example (target_gas = 500,000 via KTargetGasPrice=60000):
  │     actual_gas = 1,000,000 (2x target): adjustment = 500K / (500K*8) = +0.125
  │     actual_gas = 250,000   (0.5x target): adjustment = -250K / (500K*8) = -0.0625
  │     actual_gas = 0         (idle):        adjustment = -500K / (500K*8) = -0.125
  │
  ├── [New fee calculation]
  │   File: ca/fee_calculator.h, Line: 28
  │   new_fee_exact = old_fee * (1.0 + adjustment_factor)
  │
  │   Example with old_fee = 100:
  │     actual_gas = 1,000,000: new_fee = 100 * 1.125 = 112.5
  │     actual_gas = 250,000:   new_fee = 100 * 0.9375 = 93.75
  │
  ├── [Directional rounding]
  │   File: ca/fee_calculator.h, Lines: 33-43
  │   if actual_gas > target_gas:  new_fee = ceil(new_fee_exact)   // UP
  │   if actual_gas < target_gas:  new_fee = floor(new_fee_exact)  // DOWN
  │   if actual_gas == target_gas: new_fee = new_fee_exact         // SAME
  │   Purpose: Growth mode rounds UP (conservative), idle mode rounds DOWN (generous)
  │
  └── [Non-negative guarantee]
      File: ca/fee_calculator.h, Line: 47
      return max(new_fee, 0.0);
```

### 2.8 Integration Point: Contract Execution

```
ContractCommonInterfaceHandler (EVM execution flow)
  File: ca/contract.cpp, Line: 815 (call site)

  ├── [Retrieve previous baseFee from blockchain state]
  │   File: ca/contract.cpp, Lines: 795-810
  │   Purpose: Find latest contract transaction to get old_baseFee
  │
  ├── EIP1559FeeCalculator::calculateNewFee(old_baseFee, gasCost, KTargetGasPrice)
  │   File: ca/fee_calculator.h, Line: 12
  │   old_baseFee: string from tx info → std::stod() conversion
  │   gasCost:     total gas consumed by this contract execution
  │   KTargetGasPrice: 60000 (from ca/global.h:65)
  │
  └── [Apply new fee to gas cost]
      File: ca/contract.cpp, Line: 816
      gasCost *= (uint64_t)new_baseFee;
      Note: double * uint64_t → uint64_t truncation
```

---

## 3. DB Access Patterns

| Function | DB Call | Purpose |
|----------|---------|---------|
| `fetchAbnormalSignAddrListByPeriod` | `getSignAddrByPeriod(period-1, ...)` | Get all signers from previous day |
| `fetchAbnormalSignAddrListByPeriod` | `getSignCountByPeriod(period-1, addr, ...)` | Get per-address signature count |
| `CalcBonusValue` | `GetDelegatingAmountAndDuration(...)` | Get delegation data for bonus addr |
| `GetNetworkStakingRate` | `getTotalCirculationAsOfTodayStart(...)` | Get total supply snapshot |
| `GetNetworkStakingRate` | `getLockedAmountAsOfTodayStart(...)` | Get locked amount snapshot |
| `FundTrans::trans()` | `getGasAmountByPeriod(period-1, type, ...)` | Get gas fees collected per asset |
| `FundTrans::trans()` | `getTotalLockedAmonut(...)` | Get total network locked amount |
| `FundTrans::trans()` | `getPackagerCountByPeriod(period-1, addr, ...)` | Get node's packaging count |
| `FundTrans::trans()` | `getBlockNumberByPeriod(period-1, ...)` | Get total blocks in period |
| `BonusAddrCache::getAmount()` | `getDelegatingAddrAndAssetTypeByBonusAddr(...)` | Get delegator list |
| `BonusAddrCache::getAmount()` | `getDelegatingAddrUtxoByBonusAddr(...)` | Get delegation UTXOs |

---

## 4. Key Constants Reference

| Constant | File:Line | Value | Description |
|----------|-----------|-------|-------------|
| `kDecimalNum` | `ca/global.h:35` | 100,000,000 | Token decimal places (8) |
| `MIN_STAKE_AMOUNT` | `ca/global.h:39` | 350,000,000,000 | Min stake (3500 * 10^8) |
| `kMinDelegatingAmt` | `ca/global.h:41` | 50,000,000,000 | Min delegation (500 * 10^8) |
| `kMinKGetBonusDelegatingAmt` | `ca/global.h:40` | 50,000,000,000,000 | Min for bonus eligibility |
| `KInvestmentCap` | `ca/global.h:42` | 350,000,000,000,000 | Max investment (3.5M * 10^8) |
| `MAX_COMMISSION_RATE` | `ca/global.h:62` | 0.35 | Max node commission (35%) |
| `MIN_COMMISSION_RATE` | `ca/global.h:63` | 0.05 | Min node commission (5%) |
| `KTargetGasPrice` | `ca/global.h:65` | 60,000 | EIP-1559 target gas price |
| `CYCLE_DURATION_SECONDS` | `ca/vrf_consensus.h:16` | 10 | VRF consensus cycle |
| `LOCK_AMOUNT` | `ca/global.h:37` | 1 | Lock amount threshold |
