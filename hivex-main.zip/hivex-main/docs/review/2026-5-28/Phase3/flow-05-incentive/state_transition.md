# MeMeChain Flow 05 -- State Transition Model

> All file paths relative to project root: `//wsl$/wsl-mm/home/wbl/mm/`

---

## 1. Global System State Diagram

```mermaid
stateDiagram-v2
    [*] --> GenesisState

    state GenesisState {
        [*] --> AnnualizedRate_Initial5pct
        AnnualizedRate_Initial5pct: Annualized Rate = 5.0% (week 0)
        AnnualizedRate_Initial5pct: Inflation = 5.0%
    }

    state "Network Staking Rate" as StakingRate {
        [*] --> StakingRate_Default10pct
        StakingRate_Default10pct: default = 10% (when totalSupply=0)
        StakingRate_10to100: stakingRate = LockedAmount/TotalSupply * 100
        StakingRate_10to100: clamped to [10%, 100%]
    }

    state "Annualized Rate Lifecycle" as AnnualLifecycle {
        [*] --> Week1
        Week1: Week 0: annualizedRate = 5.0% / stakingRatio
        Week1 --> WeekN: Each week advances index
        WeekN --> WeekN: annualizedRate[w] = inflation[w] / stakingRatio
        WeekN --> Week519: Week 519 (final defined week)
        Week519 --> StableClamp: weeksSinceStart >= 520
        StableClamp: Clamped: uses week 519 value
        StableClamp: Converges to ~0.5% / stakingRatio
    }

    state "Node Signature State" as NodeSigState {
        [*] --> SigUnknown
        SigUnknown: Node has not signed in current period
        SigUnknown --> SigNormal: Signs blocks → count >= average
        SigUnknown --> SigAbnormal: Signs blocks → count < average

        SigNormal: dividendRate = N/A (full reward)
        SigAbnormal: dividendRate = own_count / average_count

        SigNormal --> SigUnknown: New period starts
        SigAbnormal --> SigUnknown: New period starts
    }

    state "Bonus Reward State" as BonusState {
        [*] --> Reward_NotClaimable
        Reward_NotClaimable: No staking delegation or not yet eligible
        Reward_NotClaimable --> Reward_Calculating: CreateBonus TX submitted
        Reward_Calculating: CalcBonusValue() running
        Reward_Calculating --> Reward_Distributed: Calculation complete
        Reward_Distributed: UTXO vout contains per-delegator rewards
        Reward_Distributed --> Reward_NotClaimable: New day begins (reset)
    }

    state "Fund Claim State" as FundState {
        [*] --> Fund_NotClaimable
        Fund_NotClaimable: No locked stake or packaged blocks
        Fund_NotClaimable --> Fund_Eligible_Locked: Has locked stake (return_value > 0)
        Fund_NotClaimable --> Fund_Eligible_Packaged: Has packaged blocks this period
        Fund_Eligible_Locked --> Fund_Claimed: createFund TX processed
        Fund_Eligible_Packaged --> Fund_Claimed: createFund TX processed
        Fund_Claimed --> Fund_NotClaimable: Already claimed (ret=-6 guard)
    }

    state "Gas Fee State (EIP-1559)" as GasState {
        [*] --> Gas_OldBaseFee
        Gas_OldBaseFee: old_fee from last contract TX baseFee
        Gas_OldBaseFee --> Gas_Adjusting: New contract TX executes
        Gas_Adjusting: adjustment = (actual-target) / (target*8)
        Gas_Adjusting --> Gas_Growing: actual > target → ceil(new_fee)
        Gas_Adjusting --> Gas_Shrinking: actual < target → floor(new_fee)
        Gas_Adjusting --> Gas_Stable: actual == target → no change
        Gas_Growing --> Gas_NewBaseFee: new_fee applied to gasCost
        Gas_Shrinking --> Gas_NewBaseFee: new_fee applied to gasCost
        Gas_Stable --> Gas_NewBaseFee: same_fee applied to gasCost
        Gas_NewBaseFee --> Gas_OldBaseFee: Becomes old_fee for next TX
    }
```

---

## 2. Detailed State Transition Definitions

### 2.1 Annualized Rate State Machine

```mermaid
stateDiagram-v2
    [*] --> Init
    Init: Calculate weeksSinceStart
    Init: k = mapStakingRateToK(stakingRate)

    Init --> BuildInflation: k ∈ [1, 20]

    state BuildInflation {
        [*] --> WeekLoop
        WeekLoop: w=1..520
        WeekLoop --> CalcRate: x = (w-1)/519
        CalcRate: rate = 0.5 + 4.5*exp(-k*x)
        CalcRate --> WeekLoop: w++
        WeekLoop --> Done: w=520 complete
        Done: inflationRates[520] ready
    }

    BuildInflation --> BuildAnnualized: inflationRates computed

    state BuildAnnualized {
        [*] --> ConvertLoop
        ConvertLoop: For each inflation rate
        ConvertLoop: annualizedRate = inflationRate / (stakingRate/100)
        ConvertLoop --> ConvertLoop
        ConvertLoop --> Complete: 520 rates ready
        Complete: annualizedRates[520] ready
    }

    BuildAnnualized --> SelectWeek: annualizedRates ready

    SelectWeek: annualizedRate = annualizedRates[weeksSinceStart]
    SelectWeek --> Clamped: if weeksSinceStart >= 520
    Clamped: annualizedRate = annualizedRates[519]

    SelectWeek --> PrecisionConvert
    Clamped --> PrecisionConvert
    PrecisionConvert: 【BUG?】round(rate/100*100)/100
    PrecisionConvert: Converts from percentage to decimal

    PrecisionConvert --> [*]: annualizedRate ready (decimal)
```

**State Variables:**
| Variable | Type | Initial Value | Transitions | File:Line |
|----------|------|---------------|-------------|-----------|
| `weeksSinceStart` | `uint64_t` | 0 | Computed each call from `(curTime - genesisTime) / 604800000000` | `ca/algorithm.cpp:8005` |
| `stakingRate` | `double` | 10.0 (fallback) | Computed from `totalLockedAmount/totalSupply*100` | `ca/algorithm.cpp:8086` |
| `k` | `double` | 1.0 (at 10% stake) | Linear interpolation `[1,20]` from `[10%,100%]` | `ca/algorithm.cpp:7915` |
| `inflationRates[520]` | `vector<double>` | Empty | Filled by exponential decay: `rate = 0.5 + 4.5*exp(-k*x)` | `ca/algorithm.cpp:7933` |
| `annualizedRates[520]` | `vector<double>` | Empty | Filled: `inflationRate / stakingRatio` | `ca/algorithm.cpp:7970` |
| `annualizedRate` (output) | `double` | N/A | Set from `annualizedRates[week]`, then precision-converted | `ca/algorithm.cpp:8042,7835` |

### 2.2 Node Signature State Machine

```mermaid
stateDiagram-v2
    [*] --> WaitingForPeriod
    WaitingForPeriod: No data for current period yet

    WaitingForPeriod --> PeriodActive: getSignAddrByPeriod(period-1) returns data

    state PeriodActive {
        [*] --> CalcAverage
        CalcAverage: average = allSignNumber / addrSignCount.size()
        Note right of CalcAverage: 【RISK】Integer division (uint64_t/uint64_t)
        Note right of CalcAverage: then cast to double. Truncation occurs.

        CalcAverage --> CheckEachAddr: For each address in the period

        state CheckEachAddr {
            [*] --> CompareWithAvg
            CompareWithAvg: own = addrSignCount[addr]

            CompareWithAvg --> NormalNode: own >= average
            CompareWithAvg --> AbnormalNode: own < average

            NormalNode: isQualified = true
            NormalNode: dividendRate not set (full reward)
            AbnormalNode: dividendRate = own / average
            AbnormalNode: 【RISK】Floating-point comparison safety:
            AbnormalNode: (double)own >= (double)average → OK
        }

        NormalNode --> PeriodDone
        AbnormalNode --> PeriodDone
        PeriodDone: addr_percent populated for abnormal nodes
        PeriodDone: addrSignCount populated for all signers
    }

    PeriodActive --> NoSigners: addrSignCount is empty

    state NoSigners {
        [*] --> NoWork
        NoWork: "No one worked the day before"
        NoWork: Returns -1 (error)
    }

    PeriodActive --> NextPeriod: New curTime triggers new GetPeriod()
    NextPeriod --> WaitingForPeriod: Reset for next day
```

**Key implementation details (ca/algorithm.cpp:66-106):**

```cpp
// Line 92: Guard against empty data
if(allSignNumber != 0 && addrSignCount.size() != 0)

// Line 95: Average calculation (CONCERN: integer division)
double average = allSignNumber / addrSignCount.size();
// If allSignNumber=5, size=10 → average=0.0 (integer 0 cast to double)
// Should be: double average = (double)allSignNumber / addrSignCount.size();

// Lines 96-103: Classification
for(auto & addr_cnt : addrSignCount) {
    if((double)(addr_cnt.second) >= average) continue;  // Normal
    addr_percent[addr_cnt.first] = ((double)addr_cnt.second / average);  // Abnormal
}
// If average=0 due to the integer division issue above:
//   - All addresses with count > 0 will pass (normal)
//   - Addresses with count = 0 would get NaN if they existed in addrSignCount
```

### 2.3 Bonus Reward State Machine

```mermaid
stateDiagram-v2
    [*] --> NotEligible
    NotEligible: Node has not staked / below MIN_STAKE_AMOUNT
    NotEligible: Delegation amount < kMinDelegatingAmt

    NotEligible --> Eligible: Staking threshold met

    state Eligible {
        [*] --> GetDelegationData
        GetDelegationData: GetDelegatingAmountAndDuration(bonusAddr, ...)
        GetDelegationData: Returns map<delegator, pair<amount, duration>>

        GetDelegationData --> CalcAnnualized: stakingRate = GetNetworkStakingRate()
        CalcAnnualized: annualizedRate = GetNewAnnualizedRate(curTime, stakingRate)
        CalcAnnualized: annualizedRate = precision convert to decimal

        CalcAnnualized --> DetectAbnormal: fetchAbnormalSignAddrListByPeriod()
        DetectAbnormal --> ClassifyNode

        state ClassifyNode {
            [*] --> Abnormal
            [*] --> Normal
            [*] --> NoSignatures

            Abnormal: dividendRate ∈ (0, 1)
            Abnormal: Reward = dividendRate * annualizedRate * amount / 365
            Normal: isQualified = true
            Normal: Reward = annualizedRate * amount / 365
            NoSignatures: Not found in addrSignCount
            NoSignatures: ERROR: "Node not qualified" → return -5
        }

        Abnormal --> ApplyCommission
        Normal --> ApplyCommission

        ApplyCommission: For each delegator:
        ApplyCommission: operator_commission = reward * commissionRate + 0.5
        ApplyCommission: delegator_award = reward - operator_commission
        Note right of ApplyCommission: +0.5 is integer-round trick before uint64_t truncation
    }

    Eligible --> TransactionBuilt: BonusTrans::trans() creates UTXOs
    TransactionBuilt --> TransactionSigned: goMessage() signs and broadcasts
    TransactionSigned --> [*]: UTXO state updated on-chain
```

### 2.4 Fund Claim State Machine

```mermaid
stateDiagram-v2
    [*] --> CheckAssets
    CheckAssets: fetchAvailableAssetType() → assetMap
    CheckAssets: For each asset: getGasAmountByPeriod(period-1, ...)

    CheckAssets --> NoGasReward: gasAmount == 0 for all assets
    NoGasReward: ERROR: "No fund reward the day before"

    CheckAssets --> HasGasReward: At least one asset has gasAmount > 0

    HasGasReward --> CheckQualification: CheckFundQualification(addr, curTime, retValue)

    state CheckQualification {
        [*] --> AlreadyClaimed
        [*] --> NotStaked
        [*] --> HasStake

        AlreadyClaimed: ret == -6
        AlreadyClaimed: ERROR: "Already claimed fund reward"

        NotStaked: ret != 0 && ret != -6
        NotStaked: Not eligible

        HasStake: ret == 0
        HasStake: return_value = locked stake amount

        HasStake --> LockCheck: getTotalLockedAmonut(totalLockedAmount)

        LockCheck --> IsLocked: return_value > 0 AND totalLockedAmount > 0
        LockCheck --> NotLocked: Either is 0

        IsLocked: is_locked = true
        IsLocked: lockedRate = return_value / totalLockedAmount
    }

    NotLocked --> PackagerCheck
    IsLocked --> PackagerCheck

    state PackagerCheck {
        [*] --> NotBonusAddr: VerifyBonusAddr(addr) fails
        [*] --> CheckCounts: is bonus addr

        CheckCounts: getPackagerCountByPeriod(period-1, addr, times)
        CheckCounts: getBlockNumberByPeriod(period-1, count)

        CheckCounts --> IsPackaged: times > 0 AND count > 0
        CheckCounts --> NotPackaged: times == 0 OR count == 0

        IsPackaged: is_packaged = true
        IsPackaged: packageRate = times / count
    }

    NotBonusAddr --> FinalCheck
    NotPackaged --> FinalCheck
    IsPackaged --> FinalCheck

    state FinalCheck {
        [*] --> NotEligible: NOT is_packaged AND NOT is_locked
        NotEligible: ERROR: "Not eligible to claim fund"

        [*] --> Eligible: is_packaged OR is_locked

        state Eligible {
            [*] --> ComputeRewards
            ComputeRewards: If is_locked: reward = uint64_t(lockedRate * gasAmount * 0.5)
            ComputeRewards: If is_packaged: reward = uint64_t(packageRate * gasAmount * 0.5)
            Note right of ComputeRewards: 【RISK】uint64_t truncation of double product
        }
    }

    Eligible --> TxBuilt: createUtxoFundTransfer() for each asset
    TxBuilt --> [*]: Sign, broadcast
```

### 2.5 EIP-1559 Gas Fee State Machine

```mermaid
stateDiagram-v2
    [*] --> ReadOldFee
    ReadOldFee: Search previous contract TX for baseFee
    ReadOldFee: old_baseFee = txInfo["baseFee"] (string)

    ReadOldFee --> ParseAndCalc: std::stod(old_baseFee)

    state ParseAndCalc {
        [*] --> Validate
        Validate: old_fee >= 0, actual_gas >= 0, target_gas > 0
        Validate --> ComputeAdj: Validation OK

        ComputeAdj: adj = (actual_gas - target_gas) / (target_gas * 8.0)
        ComputeAdj: new_fee_exact = old_fee * (1.0 + adj)

        ComputeAdj --> Congested: actual_gas > target_gas
        ComputeAdj --> Idle: actual_gas < target_gas
        ComputeAdj --> Equal: actual_gas == target_gas

        Congested: new_fee = ceil(new_fee_exact)
        Congested: Example: 100 * 1.125 = 112.5 → ceil → 113.0

        Idle: new_fee = floor(new_fee_exact)
        Idle: Example: 100 * 0.9375 = 93.75 → floor → 93.0

        Equal: new_fee = new_fee_exact (unchanged)

        Congested --> GuardNeg
        Idle --> GuardNeg
        Equal --> GuardNeg

        GuardNeg: new_fee = max(new_fee, 0.0)
        GuardNeg: Prevents negative fee
    }

    ParseAndCalc --> ApplyFee: new_baseFee = result

    ApplyFee: gasCost *= (uint64_t)new_baseFee
    ApplyFee: 【RISK】double*double → uint64_t truncation
    ApplyFee: 【RISK】For large gasCost, double precision limits apply

    ApplyFee --> [*]: New fee stored as baseFee for next contract TX
```

---

## 3. Critical State Transition Guard Conditions

### 3.1 Bonus Guard Conditions
| Condition | Guard | File:Line |
|-----------|-------|-----------|
| Not enough delegation | `amount < kMinDelegatingAmt` (50B raw) | `ca/bonus_addr_cache.cpp:26` |
| No signers in period | `addrSignCount.empty()` → return -1 | `ca/algorithm.cpp:7751` |
| Node not a signer | `bonusAddr not in addrSignCount` → return -5 | `ca/algorithm.cpp:7786-7789` |
| Already claimed (daily) | `evaluateBonusEligibility()` returns non-zero | `ca/transaction/bonus.cpp:70-74` |
| Invalid commission | `rate < 0.05 or rate > 0.35` | `ca/global.h:62-63` |
| Zero claim amount | `total_operator_commission == 0` → return -12 | `ca/transaction/bonus.cpp:190-192` |

### 3.2 Fund Guard Conditions
| Condition | Guard | File:Line |
|-----------|-------|-----------|
| No gas rewards to distribute | `asset_type_amount.empty()` → return -999 | `ca/transaction/fund.cpp:63-66` |
| Already claimed | `CheckFundQualification()` ret == -6 | `ca/transaction/fund.cpp:78-81` |
| No locked stake AND no packaging | `!is_packaged && !is_locked` → return -11 | `ca/transaction/fund.cpp:130-133` |
| Invalid address | `!isValidAddress(addr)` | `ca/transaction/fund.cpp:27-30` |

### 3.3 EIP-1559 Guard Conditions
| Condition | Guard | File:Line |
|-----------|-------|-----------|
| Negative old fee | `old_fee < 0` → throw | `ca/fee_calculator.h:16-18` |
| Negative actual gas | `actual_gas < 0` → throw | `ca/fee_calculator.h:19-21` |
| Zero target gas | `target_gas <= 0` → throw | `ca/fee_calculator.h:22-24` |
| Fee going negative | `max(new_fee, 0.0)` | `ca/fee_calculator.h:47` |

---

## 4. Numerical State Transitions (Worked Examples)

### 4.1 Low Staking Scenario (10% staking, week 1)
| Step | Variable | Value | Calculation |
|------|----------|-------|-------------|
| Input | stakingRate | 10.0% | From GetNetworkStakingRate |
| Map | k | 1.0 | 1+(10-10)*19/90 = 1.0 |
| Inflation | rate[0] | 5.0% | 0.5+4.5*exp(-1*0) = 5.0 |
| Annualized | aRate[0] | 50.0% | 5.0/0.1 = 50.0 |
| Precision | finalRate | 0.50 | round(50/100*100)/100 = 0.50 |
| Reward | per 100K del. | 50,000 | 0.50 * 10000000000000 / 365 |

### 4.2 High Staking Scenario (80% staking, week 260)
| Step | Variable | Value | Calculation |
|------|----------|-------|-------------|
| Input | stakingRate | 80.0% | From GetNetworkStakingRate |
| Map | k | 15.78 | 1+(80-10)*19/90 = 15.78 |
| Inflation | rate[259] | ~0.5% | 0.5+4.5*exp(-15.78*0.5) |
| Annualized | aRate[259] | ~0.625% | 0.5/0.8 = 0.625 |
| Precision | finalRate | 0.01 | round(0.625/100*100)/100 = 0.01 |
| 【BUG】| Expected | 0.00625 | Lost 0.00375 due to rounding |

### 4.3 EIP-1559 Congestion
| Step | Variable | Value |
|------|----------|-------|
| Input | old_fee | 100.0 |
| Input | actual_gas | 1,000,000 |
| Input | target_gas (KTargetGasPrice) | 60,000 |
| Adjustment | factor | (1M-60K)/(60K*8) = 940K/480K = 1.958 |
| New exact | new_fee_exact | 100 * (1+1.958) = 295.83 |
| Ceiling | new_fee | ceil(295.83) = 296.0 |
