# MeMeChain Flow 05 -- Asynchronous Task Flow Analysis

> All file paths relative to project root: `//wsl$/wsl-mm/home/wbl/mm/`

---

## 1. Architecture Overview: Synchronous vs Asynchronous

**Critical finding:** The incentive calculation and distribution subsystem is predominantly **synchronous** (triggered by user transactions). There is NO dedicated background timer task for annualized rate calculation or reward computation. Each reward is computed on-demand when a user submits a BONUS or FUND transaction.

However, several related subsystems operate asynchronously or periodically:

```mermaid
flowchart TB
    subgraph "User-Triggered (Synchronous)"
        A1[User submits BONUS TX] --> A2[CalcBonusValue]
        A2 --> A3[GetNetworkStakingRate]
        A3 --> A4[GetNewAnnualizedRate]
        A4 --> A5[Reward calculation]
        A5 --> A6[UTXO construction]

        B1[User submits FUND TX] --> B2[CheckFundQualification]
        B2 --> B3[Query period gas amounts]
        B3 --> B4[Compute lock/package rewards]
        B4 --> B5[UTXO construction]
    end

    subgraph "Block-Confirmation (Synchronous)"
        C1[Block arrives] --> C2[verifyTransactionRequest]
        C2 --> C3[Re-calculate CalcBonusValue]
        C3 --> C4[Verify reward amounts match]
        C4 --> C5[Accept or reject block]
    end

    subgraph "Periodic Background Tasks"
        D1[VRF Consensus] --> D2[Periodic VRF cycle: 10s]
        D2 --> D3[Signature recording in DB]
        D3 --> D4[Used by fetchAbnormalSignAddrListByPeriod]

        E1[Contract execution] --> E2[EIP1559 fee adjustment]
        E2 --> E3[Per-contract-tx: dynamic]

        F1[BonusAddrCache] --> F2[dirty flag invalidation]
        F2 --> F3[Lazy-refresh on next query]
    end

    subgraph "Database Aggregation"
        G1[Block commitment] --> G2[Write sign counts per period]
        G2 --> G3[Write gas amounts per period]
        G3 --> G4[Write block counts per period]
    end
```

---

## 2. Detailed Task Flow Analysis

### 2.1 Annualized Rate Calculation -- Synchronous, On-Demand

**Trigger:** User-initiated BONUS transaction (or transaction verification for BONUS tx)

**Flow:**
```
User Action: POST /createBonus
  └─> BonusTrans::trans()                                       [ca/transaction/bonus.cpp:18]
       └─> evaluateBonusEligibility(addr, current_time)          [check claim eligibility]
       └─> CalcBonusValue(current_time, addr, values)            [ca/algorithm.cpp:7743]
            └─> fetchAbnormalSignAddrListByPeriod(curTime, ...)  [check signature stats]
            └─> GetDelegatingAmountAndDuration(bonusAddr, ...)   [query delegations]
            └─> GetNetworkStakingRate(curTime, stakingRate)      [compute staking %]
            │    └─> getTotalCirculationAsOfTodayStart(...)      [DB query]
            │    └─> getLockedAmountAsOfTodayStart(...)          [DB query]
            └─> GetNewAnnualizedRate(curTime, stakingRate, rate) [compute yield]
                 └─> Genesis::GetGenesisTime()                   [read genesis config]
                 └─> mapStakingRateToK(stakingRate)              [linear interpolation]
                 └─> calculateInflationRates(k, 520, 5.0, 0.5)   [generate 520 rates]
                 └─> calculateAnnualizedRates(inflations, stake) [convert to yield]
```

**Performance Consideration:** `GetNewAnnualizedRate` is called synchronously for every BONUS transaction. It recomputes the entire 520-week inflation sequence each time (Lines 8026-8033 of algorithm.cpp). With 520 iterations of `std::exp()`, this is computationally wasteful if multiple bonus claims happen in the same block or short time window.

**Optimization Opportunity:** Since the inflation sequence depends only on `stakingRate` (which is a daily snapshot value), and `weeksSinceStart` (which increments slowly), the entire computation could be cached with a simple invariant:

```
Cache key: (stakingRate_rounded, weeksSinceStart)
Invalidation: When either changes
```

However, the staking rate is clamped to `[10%, 100%]` and fetched "as of today start," meaning it generally changes at most once per day. The weeks counter advances once per week (~604,800 seconds). So the 520-element vector is recomputed unnecessarily for a vast majority of calls.

**【需人工验证】** Whether the project intends to add caching for this computation.

### 2.2 Abnormal Node Detection -- Synchronous, Per-Bonus-Call

**Trigger:** `CalcBonusValue()` invocation

**Flow:**
```
CalcBonusValue()
  └─> fetchAbnormalSignAddrListByPeriod(curTime, addr_percent, addrSignCount)
       └─> TimeUtil::GetPeriod(curTime)                          [day index since genesis]
       └─> DBReader::getSignAddrByPeriod(period-1, addresses)    [all signers yesterday]
       └─> For each signer:
            └─> DBReader::getSignCountByPeriod(period-1, addr, count)
       └─> Compute average = allSignNumber / addrSignCount.size()
       └─> For each signer:
            └─> if own < average: addr_percent[addr] = own/average
```

**Data dependency:** The signature data is written to the database during block commitment, which happens asynchronously through the consensus mechanism. The `period-1` query ensures we always inspect the previous (completed) day's data.

**Timing:** This function queries all signers for the previous period. For a network with N nodes, this involves 1 query for the address list + N queries for signature counts. This is O(N) database round-trips.

**【需人工验证】** The scalability of this approach with large N (100+ signers). Each `getSignCountByPeriod` is a separate RocksDB query.

### 2.3 VRF Consensus Signature Recording -- Periodic (10-second cycle)

**Trigger:** VRF consensus mechanism

**File:** `ca/vrf_consensus.h:16` -- `CYCLE_DURATION_SECONDS = 10`

**Flow:**
```
VRFConsensusNode::Process()          [ca/vrf_consensus.h:44]
  └─> run()                          [background thread, ca/vrf_consensus.h:49]
       └─> sign(data, signature, pub) [generate VRF signature]
       └─> generateVRFStructure(...)  [create VRF consensus info]
       └─> vrfBroadcastMessage(...)   [broadcast to network]
       └─> receiveVRRequest(...)      [handle incoming VRFs]

Block commitment:
  └─> Record signer address + count for current period into DB
       └─> This data is later read by fetchAbnormalSignAddrListByPeriod()
```

**Data Flow Connection:**
```
VRF Consensus (async, ~10s)
    │
    ├── Signatures recorded per-period in DB
    │
    └──> fetchAbnormalSignAddrListByPeriod (synchronous, on-demand)
          └── Reads period-1 (previous day's) signature data
          └── Computes per-node performance metrics
          └── Results used for bonus reward adjustment
```

### 2.4 Gas Fee Adjustment -- Per-Contract-Transaction (Synchronous)

**Trigger:** Each contract execution transaction

**File:** `ca/contract.cpp:815`

**Flow:**
```
Contract execution flow:
  └─> ContractCommonInterfaceHandler (processing contract call/deploy TX)
       └─> [Search previous contract TX to find old baseFee]
            └─> Walks backward through blocks to find last contract TX
            └─> Extracts "baseFee" from txInfo JSON
            └─> Falls back to "1" if not found
       └─> EIP1559FeeCalculator::calculateNewFee(
                std::stod(old_baseFee),   // string → double
                (double)gasCost,          // actual gas used
                global::ca::KTargetGasPrice  // 60000
            )
       └─> gasCost *= (uint64_t)new_baseFee  // Apply new fee
```

**Computation cost:** The backward search for the previous contract transaction involves iterating through blocks. This is a potentially expensive operation for the first contract call in a chain.

The actual fee calculation (`calculateNewFee`) is O(1) -- a few floating-point operations and one `ceil`/`floor` call.

### 2.5 Bonus Address Cache -- Lazy Refresh

**File:** `ca/bonus_addr_cache.cpp`

**Flow:**
```
BonusAddrCache (thread-safe singleton):
  └─> State: bonus_addr_map_ protected by shared_mutex
       └─> Each entry: {dirty, amount, utxos, time}

  └─> getAmount(addr, amount):
       └─> [unique_lock on bonus_addr_mutex_]
       └─> if not dirty AND cached:
            └─> Return cached amount (FAST PATH)
       └─> if dirty OR not cached:
            └─> Clear cached utxos
            └─> Query DB: getDelegatingAddrAndAssetTypeByBonusAddr(...)
            └─> For each delegator:
                 └─> Query DB: getDelegatingAddrUtxoByBonusAddr(...)
                 └─> Query DB: getTransactionByHash(...)  [for each UTXO!]
                 └─> Parse tx → check vout.addr == kVirtualDelegatingAddr
                 └─> Accumulate amount, track time
            └─> Set dirty = false, cache result
            └─> Return amount

  └─> getTime(addr):
       └─> [shared_lock on bonus_addr_mutex_]
       └─> Return cached time (0 if not cached)

  └─> isDirty(addr, dirty=true):
       └─> [unique_lock on bonus_addr_mutex_]
       └─> Set bonus_addr_map_[addr].dirty = dirty
```

**Invalidation Pattern:** The cache must be marked dirty when delegation changes occur (new DELEGATE or UNDELEGATE transactions). This is an external trigger, not an internal timer -- the calling code must explicitly call `isDirty(addr, true)` when delegations change.

**Concurrency:** Uses `std::shared_mutex` with `shared_lock` for reads (getTime) and `unique_lock` for writes (getAmount, isDirty). Multiple concurrent readers are allowed. The `getAmount()` function uses `unique_lock` throughout (even during the cache-hit fast path check), which serializes all `getAmount` calls.

### 2.6 Fund Qualifying Data Aggregation -- Block-Triggered

**Flow:**
```
Block commitment:
  └─> SaveBlock() → writes to DB:
       ├── Gas amounts per period (for fund distribution)
       ├── Sign counts per period (for abnormal detection)
       ├── Block numbers per period (for fund packaging rate)
       └── Packager counts per period (for fund packaging rate)
```

The per-period aggregated data is written during `SaveBlock()` (algorithm.cpp:175). This is called synchronously when a new block is committed to the database. The aggregation is effectively:

```
For each committed block in period P:
  ├── Accumulate gas fees by asset type → getGasAmountByPeriod(P, ...)
  ├── Record signer address + increment count → getSignCountByPeriod(P, ...)
  ├── Increment block count → getBlockNumberByPeriod(P, ...)
  └── Increment packager count → getPackagerCountByPeriod(P, ...)
```

---

## 3. Concurrency Model

```mermaid
flowchart LR
    subgraph "Thread 1: User RPC Handler"
        T1A[createBonus] --> T1B[BonusTrans::trans]
        T1B --> T1C[CalcBonusValue]
        T1C --> T1D[DB Read]
    end

    subgraph "Thread 2: Block Verifier"
        T2A[verifyTransactionRequest] --> T2B[CalcBonusValue]
        T2B --> T2C[DB Read]
    end

    subgraph "Thread 3: VRF Consensus"
        T3A[VRFConsensusNode::Process] --> T3B[sign/broadcast]
        T3B --> T3C[DB Write: sign counts]
    end

    subgraph "Thread 4: Block Commitment"
        T4A[SaveBlock] --> T4B[DB Write: gas/block/sign counts]
    end

    subgraph "Shared State"
        S1[(RocksDB)]
        S2[BonusAddrCache<br/>shared_mutex]
        S3[bonusMutex<br/>std::mutex]
    end

    T1C -.-> S1
    T1C -.-> S2
    T2B -.-> S1
    T3C --> S1
    T4B --> S1
```

**Key Concurrency Points:**

1. **CalcBonusValue is reentrant**: Called from both RPC handler and block verification. Both are read-only with respect to the bonus calculation. No write conflicts.

2. **Database writes vs reads**: The signature/gas data for period P is written during block commitment. Bonus claims for period P query period P-1 (previous day). This creates a natural one-day lag that avoids read-write conflicts.

3. **BonusAddrCache thread safety**: Protected by `std::shared_mutex`. The `getAmount` function holds an exclusive lock for the entire duration (including DB queries during cache miss). This could block concurrent readers for extended periods if DB is slow.

4. **global::ca::bonusMutex** (ca/global.h:29): Declared as a static `std::mutex` in the header. This creates a separate mutex instance in each translation unit that includes global.h. 【需人工验证】Whether this is intentional (per-TU locking) or should be `inline`/`extern` for a single global lock.

---

## 4. Task Execution Timeline

```mermaid
gantt
    title Incentive System Task Timeline
    dateFormat X
    axisFormat %s

    section Periodic
    VRF Signature Cycle    :vrf, 0, 86400000
    Block Commitment        :block, 0, 86400000

    section On-Demand
    BONUS TX - User A      :crit, bonusa, after vrf, 1000ms
    BONUS TX - User B      :crit, bonusb, after vrf, 1000ms
    FUND TX - User C       :fundc, after vrf, 1000ms
    Contract TX (EIP1559)  :active, contract, after vrf, 1000ms

    section Verification
    Verify Block N          :verify, after block, 500ms

    section DB Aggregation
    Period aggregation      :agg, after block, 100ms
```

**Notes on timeline:**
- The VRF cycle runs every 10 seconds (CYCLE_DURATION_SECONDS)
- Block commitment happens as blocks are produced (tied to consensus, not a fixed timer)
- BONUS/FUND transactions are user-driven and can arrive at any time
- Each BONUS TX triggers a full `GetNewAnnualizedRate` computation (520 iterations)
- EIP-1559 fee adjustment happens inline during contract execution

---

## 5. Identified Asynchronous Risks

### 5.1 TOCTOU (Time-of-Check, Time-of-Use) in CalcBonusValue

**Scenario:**
1. Thread A (User): Calls CalcBonusValue → reads staking rate = 50%, annualized rate = 10%
2. Thread B (Another node): Large stake transaction commits, changing staking rate
3. Thread A: Reward computed with old staking rate → incorrect reward

**Mitigation:** The staking rate query uses "as of today start" snapshots (`getTotalCirculationAsOfTodayStart`, `getLockedAmountAsOfTodayStart`), which provides intra-day consistency. However, if the snapshot reading is not atomic, a partial snapshot could occur.

### 5.2 BonusAddrCache Staleness

**Scenario:**
1. Cache is populated for bonus address X with delegation amount 1000
2. A new DELEGATE transaction adds 500 more delegation to X
3. If the caller does not call `isDirty(X, true)`, the cache returns stale 1000

**Mitigation:** The dirty flag mechanism requires explicit invalidation by the code that processes DELEGATE/UNDELEGATE transactions. If those code paths forget to invalidate, the cache returns stale data.

### 5.3 Re-computation Inefficiency

**Scenario:** In a block containing 10 BONUS transactions (one per node), `GetNewAnnualizedRate` is called 10 times synchronously, each time recalculating the complete 520-element inflation array. This is 10 * 520 = 5,200 calls to `std::exp()`.

**Mitigation:** Not currently implemented. The computation is purely functional (same inputs → same outputs), making it an ideal candidate for memoization:

```cpp
// Potential caching (NOT currently in code):
static std::pair<double, double> cached_staking_and_week = {-1, -1};
static double cached_rate = 0.0;
if (stakingRate == cached_staking_and_week.first &&
    weeksSinceStart == cached_staking_and_week.second) {
    annualizedRate = cached_rate;  // Cache hit
    return 0;
}
```

### 5.4 Database Consistency During Bonus Calculation

The `CalcBonusValue` function performs multiple independent DB reads:
1. Signature data (fetchAbnormalSignAddrListByPeriod)
2. Delegation data (GetDelegatingAmountAndDuration)
3. Total supply (GetNetworkStakingRate → getTotalCirculationAsOfTodayStart)
4. Locked amount (GetNetworkStakingRate → getLockedAmountAsOfTodayStart)

These reads are not performed within a single database snapshot. Between reads 1 and 4, a block could commit, changing the data. However, since all queries target "previous period" or "today start" data, and period boundaries are discrete (daily), intra-day consistency should be maintained as long as the day hasn't rolled over.

---

## 6. Summary: Synchronous vs Asynchronous Classification

| Component | Execution Model | Trigger | Frequency | File:Line |
|-----------|----------------|---------|-----------|-----------|
| `GetNewAnnualizedRate` | **Synchronous** | BONUS TX / verification | Per claim | `ca/algorithm.cpp:7985` |
| `CalcBonusValue` | **Synchronous** | BONUS TX / verification | Per claim | `ca/algorithm.cpp:7743` |
| `GetNetworkStakingRate` | **Synchronous** | BONUS TX / verification | Per claim | `ca/algorithm.cpp:8062` |
| `fetchAbnormalSignAddrListByPeriod` | **Synchronous** | BONUS TX / verification | Per claim | `ca/algorithm.cpp:66` |
| `FundTrans::trans()` | **Synchronous** | FUND TX | Per claim | `ca/transaction/fund.cpp:17` |
| `EIP1559FeeCalculator::calculateNewFee` | **Synchronous** | Contract TX execution | Per contract call | `ca/fee_calculator.h:12` |
| VRF Signature Recording | **Periodic** | VRF consensus cycle (10s) | Continuous | `ca/vrf_consensus.h:16` |
| Block Commitment + DB Aggregation | **Synchronous** | New block arrival | Per block | `ca/algorithm.cpp:175` |
| Period Gas/Sign/Block Count | **Deferred** | Query time (reads committed data) | Per query | `db/db_api.h:459,475,491,872,890` |
| `BonusAddrCache` | **Lazy** | Cache miss or explicit dirty | On access | `ca/bonus_addr_cache.cpp:11` |

**Key takeaway:** The incentive system is almost entirely synchronous and user-driven. The only background tasks are:
1. VRF consensus (10-second cycle) -- which feeds signature data into the DB
2. Block commitment -- which aggregates per-period statistics

There is no background timer-based annualized rate update, no cron-like reward computation, and no periodic gas fee recalibration. Everything happens in the context of a user transaction or block processing.
