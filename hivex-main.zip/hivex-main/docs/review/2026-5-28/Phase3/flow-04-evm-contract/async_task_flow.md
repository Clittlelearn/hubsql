# 流程4: EVM 合约部署与调用 — 异步任务流转

> **可信度**: 中 — 部分机制基于代码推断，标注【需人工验证】
> **分析日期**: 2026-05-26

---

## 一、线程架构图

```
HTTP请求线程                CA/打包线程               EVM执行线程
     │                           │                       │
     ├─ CreateDeploy/Call        │                       │
     │  (构造交易, 签名)          │                       │
     │                           │                       │
     ├─ SendContractMessage ────►│                       │
     │                           ├─ VRF打包              │
     │                           ├─ BuildBlock           │
     │                           │                       │
     │                           ├─ execute_by_evmone ──►│
     │                           │  std::async            │
     │                           │                       ├─ EvmHost::call
     │                           │                       ├─ vm.execute
     │                           │                       ├─ trie.Save
     │                           │                       │
     │                           │  future.wait_for(10s) │
     │                           │◄──────────────────────┤
     │                           │                       │
     │                           ├─ transactionCommit    │
     │                           ├─ 广播区块             │
     │                           │                       │
     │                           │              [超时后] 异步线程继续执行
     │                           │                  → 资源泄漏风险
```

---

## 二、异步任务清单

### 2.1 ContractDispatcher 处理线程

| 属性 | 值 |
|------|-----|
| 启动 | `ca/ca.cpp:120` — `MagicSingleton<ContractDispatcher>::GetInstance()->Process()` |
| 类型 | 独立线程 (while循环) |
| 间隔 | 事件驱动 (新合约交易到达时唤醒) |
| 功能 | 合约交易依赖管理、分发 |

```
ContractDispatcher::Process():
  while(running):
    wait_for(new_message)
    msg = dequeue()
    if DependencyManager::CanSendTransaction(msg):
      contractTransactionRequest(msg)  // 广播到网络
    else:
      cachedTransactions.push(msg)     // 缓存等待
```

### 2.2 ContractTransactionCache 定时检查

| 属性 | 值 |
|------|-----|
| 启动 | (当前被 `#if 0` 注释, 功能迁移到ContractDispatcher) |
| 原定间隔 | 1秒 |
| 原定强制发送 | 15秒超时 |
| 状态 | **废弃/未启用** — `ca/contract_transaction_cache.cpp` 全部注释 |

```
[原设计, 当前已注释]:
_CheckCachedTransactions():  // 1秒定时器
  遍历缓存交易
  if timeInCache >= 15s:
    发布"TransactionConfirmed"→强制发送
  elif CanSendTransaction():
    发送→从缓存移除
```

### 2.3 EVM 异步执行 (std::async)

| 属性 | 值 |
|------|-----|
| 启动 | `ca/contract.cpp:94` — `std::async(std::launch::async, execute_by_evmone, ...)` |
| 超时 | `future.wait_for(std::chrono::seconds(10))` |
| 功能 | 在独立线程中执行EVM, 防止阻塞打包线程 |
| 风险 | **超时后异步线程不被kill, 继续执行但结果被丢弃** |

```
execute_by_evmone(msg):
  future = std::async(std::launch::async, [msg]() {
    return execute_by_evmone_impl(msg);
  });

  status = future.wait_for(10s);
  if status == future_status::timeout:
    return -3;  // 超时, 但async线程仍在运行!
  else:
    return future.get();
```

### 2.4 预编译缓存管理

| 属性 | 值 |
|------|-----|
| 缓存级别 | 每次EvmHost实例独立 |
| 缓存内容 | 预编译合约执行结果 |
| 缓存Key | Keccak256(输入数据) |
| 生命周期 | 随EvmHost析构释放 |
| 排除项 | identity预编译(0x04)不缓存 |

### 2.5 MPT 脏节点提交

| 属性 | 值 |
|------|-----|
| 触发时机 | `trie.Save()` 在EVM执行成功后调用 |
| 提交方式 | 遍历 `dirtyHash` 映射, 逐键写入RocksDB |
| 原子性 | 在SaveBlock的RocksDB事务内 |
| 回滚 | 如果事务回滚, MPT写入自动丢弃 |

---

## 三、异步任务时间线 (Gantt)

```
时间轴 →     T0    T+1s   T+5s   T+10s   T+15s   T+30s
            │      │      │      │       │       │
ContractDispatcher │      │      │       │       │
  ├─ 事件等待  ████████████░      │       │       │
  ├─ 依赖检查            ██░      │       │       │
  └─ 广播发送            │██      │       │       │
                         │        │       │       │
EVM执行                 │████████████████████████│
  ├─ async启动          ██        │       │       │
  ├─ vm.execute         │██████████       │       │
  ├─ future.wait(10s)   │        ███████████     │
  └─ [超时]结果丢弃     │        │       ██      │
                         │        │       │       │
MPT操作                  │        │       │       │
  ├─ CreateTrie         ██        │       │       │
  ├─ Update/Commit      │██████   │       │       │
  └─ Save→DBWrite       │      ████       │       │
                         │        │       │       │
定时器(被注释)           │        │       │       │
  ├─ 1s缓存检查         █ █ █ █ █ █ █ █  █  █
  └─ 15s强制发送        │        │       │   █   │
```

---

## 四、关键风险点

### 4.1 EVM 超时线程泄漏 (High)

**位置**: `ca/contract.cpp:94-103`
**现象**: 10秒超时后 `future.wait_for` 返回 timeout，但 `std::async` 创建的线程继续执行EVM直到完成。多次超时累积可导致大量僵尸线程。
**修复建议**: 使用可取消的线程机制 (如 `std::jthread` + `stop_token`)，或设置EVM执行硬限制。

### 4.2 UTXO 与 EVM 状态非原子 (Medium)

**位置**: `ca/transaction/contract.cpp:410` (UTXO选择) 与 `ca/contract.cpp:94` (EVM执行)
**现象**: UTXO 的 `FindUtxo` 在交易构造阶段完成，EVM执行在独立线程中。如果EVM失败，UTXO标记不会自动撤销。
**缓解**: 当前依赖 `host` 析构丢弃 MPT 修改，但 UTXO 侧的变更需要确认是否在同一事务中。

### 4.3 合约代码与MPT一致性 (Medium)

**位置**: `ca/evm/evm_host.cpp`
**现象**: 合约代码 (`EVM_CODE:{addr}`) 和 MPT 状态 (`MPT:{addr}_{hash}`) 分别存储。如果其中一个写入失败而另一个成功，会导致状态不一致。
**缓解**: 两者在同一RocksDB事务中，事务提交保证原子性。

### 4.4 MPT 哈希不兼容 (Critical)

**位置**: `mpt/trie.cpp:429`
**现象**: 使用 `SHA256(hex(RLP(node)))` 而以太坊使用 `Keccak256(rlp(RLP(node)))`。导致 MPT 根哈希无法与以太坊工具链互通。
**影响**: 无法验证合约状态的以太坊兼容性 (如跨链桥所需的存储证明)。
