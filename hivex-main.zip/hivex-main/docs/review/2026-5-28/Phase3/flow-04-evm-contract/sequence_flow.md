# 流程4: EVM 合约部署与调用 — 时序图

> **可信度**: 高 — 基于 ca/evm/、ca/contract.cpp、mpt/ 源码分析
> **分析日期**: 2026-05-26

---

## 一、合约部署 (JSON-RPC 路径)

```mermaid
sequenceDiagram
    participant Client
    participant HTTP as HTTP线程
    participant TxHelper
    participant ContractCache as ContractTxCache
    participant CA as CA打包线程
    participant DB as RocksDB
    participant EVM as EvmHost/evmone
    participant MPT as MPT Trie

    Client->>HTTP: POST CreateDeployContractTransaction
    HTTP->>HTTP: ParamHandle解析(addr/contract/data/contract_type)
    HTTP->>TxHelper: createDeploy(addr, contract, data, ...)
    TxHelper->>DB: DBReader::getUtxoHashesByAddr (UTXO选择)
    Note over TxHelper: 选择未花费UTXO支付Gas
    TxHelper->>TxHelper: EIP1559FeeCalculator::calculateNewFee
    Note over TxHelper: old_baseFee→adjustment_factor→new_baseFee(ceil/floor)
    TxHelper->>TxHelper: SigTx(签名)
    TxHelper-->>HTTP: 返回{tx_json, contract_msg_json}
    HTTP-->>Client: JSON-RPC响应(已签名交易)

    Client->>HTTP: POST SendContractMessage
    HTTP->>HTTP: 解析 contract_msg + tx
    Note over HTTP: 线程切换: HTTP→合约缓存线程
    HTTP->>ContractCache: dropCallShippingRequest(tx, msg)
    ContractCache->>ContractCache: DependencyManager::CanSendTransaction
    alt 依赖冲突
        ContractCache->>ContractCache: AddFailedTransaction(缓存)
        Note over ContractCache: 1s定时器重试 / 15s强制发送
    else 无冲突
        ContractCache->>CA: contractTransactionRequest(广播)
    end

    CA->>CA: VRF选择打包节点
    CA->>CA: BuildBlock(收集交易)
    CA->>DB: DBReadWriter(开始事务)

    CA->>DB: getContractCode(合约地址)
    Note over CA,DB: 检查是否已部署(防重复)

    CA->>EVM: EvmHost::call(CREATE)
    Note over EVM: *** 线程: 独立EVM执行线程 ***
    EVM->>EVM: recordAccountAccess(msg.recipient)
    EVM->>EVM: 自毁检查(recorded_selfdestructs)
    EVM->>EVM: 预编译优先检查(0x01-0x09)
    EVM->>MPT: CreateTrie(empty_root, contractAddr)
    Note over MPT: 初始化空MPT状态树
    EVM->>EVM: GenerateContractAddrEth(sender, nonce)
    Note over EVM: keccak256(rlp([sender, nonce]))[12:32]
    EVM->>EVM: vm.execute(EVM_CREATE)
    Note over EVM: evmone执行初始化代码

    alt EVM执行成功
        EVM->>DB: SaveContract
        Note over DB: EVM_CODE:{addr}=runtimeCode
        Note over DB: EVM_DEPLOY:{deployer}+=addr
        Note over DB: EVM_UTXO:{addr}=deploymentUtxo
        Note over DB: EVM_DEPLOYER+=deployer
        EVM->>MPT: trie.Save()
        Note over MPT: Commit→Encode→SHA256→dirtyHash→RocksDB
        EVM-->>CA: EVMC_SUCCESS
    else EVM执行失败
        EVM-->>CA: EVMC_FAILURE
        Note over CA: 不保存合约代码, MPT丢弃
    end

    CA->>DB: transactionCommit()
    Note over DB: 原子提交所有变更
    CA-->>CA: 广播新区块
```

---

## 二、合约调用 (JSON-RPC 路径)

```mermaid
sequenceDiagram
    participant Client
    participant HTTP
    participant TxHelper
    participant CA
    participant DB
    participant EVM as EvmHost/evmone
    participant MPT

    Client->>HTTP: POST CreateCallContractTransaction
    HTTP->>TxHelper: createCall(addr, deployer, deployutxo, args, contractAddr, money)
    TxHelper->>DB: DBReader::getUtxoHashes
    TxHelper->>TxHelper: EIP1559FeeCalculator
    TxHelper->>TxHelper: SigTx
    TxHelper-->>HTTP: {tx_json, contract_msg_json}
    HTTP-->>Client: 返回

    Client->>HTTP: POST SendContractMessage
    Note over HTTP: 线程切换→合约缓存→CA打包

    CA->>DB: DBReadWriter(开始事务)
    CA->>EVM: EvmHost::call(CALL)
    Note over EVM: *** 线程: 独立EVM执行线程 ***
    EVM->>DB: evm_utils::GetContractCode(contractAddr)
    DB-->>EVM: 合约字节码
    alt 代码为空
        EVM-->>CA: EVMC_FAILURE
    end

    EVM->>DB: fetchContractRootHash(contractAddr, rootHash)
    DB-->>EVM: MPT根哈希

    EVM->>MPT: CreateTrie(rootHash, contractAddr)
    Note over MPT: 从RocksDB加载MPT
    MPT->>DB: DescendKey获取RLP编码节点
    DB-->>MPT: RLP数据
    MPT->>MPT: DecodeNode→节点树

    EVM->>EVM: EvmEnvironment构建
    Note over EVM: blockTimestamp/blockNumber/chainId/gasPrice
    Note over EVM: blockPrevRandao←UTXO hash拼接 [需人工验证]

    EVM->>EVM: vm.execute(CALL)
    Note over EVM: evmone字节码执行

    alt 执行成功
        EVM->>MPT: Update(key, value)
        MPT->>MPT: Insert→Commit(SHA256)→dirtyHash
        EVM->>MPT: trie.Save()
        MPT->>DB: setMptValue(contractAddr_hash, RLP节点)
        EVM->>DB: 更新Nonce
        EVM-->>CA: EVMC_SUCCESS + output
    else 执行失败/Revert
        Note over EVM: MPT修改在host析构时丢弃
        EVM-->>CA: EVMC_FAILURE/EVMC_REVERT
    end

    CA->>DB: transactionCommit()
    CA-->>CA: 广播
```

---

## 三、ETH 兼容路径 (eth_sendRawTransaction)

```mermaid
sequenceDiagram
    participant Client as MetaMask/Hardhat
    participant HTTP
    participant EthRpc
    participant Ethereum as eth_impl
    participant TxHelper
    participant CA

    Client->>HTTP: POST /eth {"method":"eth_sendRawTransaction",...}
    HTTP->>EthRpc: eth_dispatch(json)
    EthRpc->>Ethereum: handleEthSendRawTransaction(signedTxHex)
    Ethereum->>Ethereum: RLP解码(hex→bytes)
    Note over Ethereum: 解析: nonce/gasPrice/gasLimit/to/value/data/v/r/s

    Ethereum->>Ethereum: ecrecover(RLP(tx), v, r, s)
    Note over Ethereum: 通过silkpre预编译恢复from地址
    alt 签名无效
        Ethereum-->>EthRpc: error "invalid signature"
        EthRpc-->>Client: JSON-RPC error
    end

    Ethereum->>Ethereum: 类型判断
    alt to为空 → CREATE
        Ethereum->>TxHelper: createDeploy(from, data, ...)
        Note over TxHelper: contract_type=0(EVM)
    else to为合约地址 → CALL
        Ethereum->>TxHelper: createCall(from, to, data, value, ...)
    else to为普通地址 → TX
        Ethereum->>TxHelper: createTransaction(from, to, value)
    end

    TxHelper->>TxHelper: EIP1559FeeCalculator
    Note over TxHelper: 精度转换: 10^18→10^8

    Note over Ethereum,CA: 后续流程同JSON-RPC路径
    Ethereum->>CA: SendContractMessage / SendMessage
    Ethereum-->>Client: {"result":"0x{txHash}"}
```

---

## 四、异常路径

| 异常 | 阶段 | 处理 |
|------|------|------|
| EIP1559费用超限(>120000) | RPC构造 | 拒绝交易, 返回错误 |
| UTXO不足 | TxHelper | 返回余额不足错误 |
| 合约代码为空 | EvmHost::call | EVMC_FAILURE, 事务回滚 |
| MPT根哈希获取失败 | EvmHost::call | EVMC_FAILURE |
| EVM执行超时(10s) | contract.cpp | future.wait_for返回-3, 异步线程继续执行【风险】 |
| EVM执行失败/Revert | EvmHost | MPT修改在host析构时丢弃, UTXO变更需手动回滚 |
| RocksDB写入失败 | SaveBlock | Transaction Rollback, 所有变更丢弃 |
