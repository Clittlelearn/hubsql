# 流程4: EVM 合约部署与调用 — 状态转换

> **可信度**: 高
> **分析日期**: 2026-05-26

---

## 一、EVM 执行状态机

```mermaid
stateDiagram-v2
    [*] --> IDLE: 合约交易到达
    IDLE --> LOADING_ENV: EvmEnvironment::build()
    LOADING_ENV --> LOADING_CODE: 获取合约代码
    LOADING_CODE --> CODE_EMPTY: 代码为空
    LOADING_CODE --> LOADING_MPT: fetchContractRootHash
    LOADING_MPT --> MPT_FAILED: 根哈希获取失败
    LOADING_MPT --> EXECUTING: CreateTrie + vm.execute

    CODE_EMPTY --> FAILED: EVMC_FAILURE
    MPT_FAILED --> FAILED: EVMC_FAILURE

    EXECUTING --> TIMEOUT: 10秒超时(future.wait_for)
    EXECUTING --> REVERTED: EVM REVERT
    EXECUTING --> COMMITTING: EVMC_SUCCESS
    EXECUTING --> EXCEPTION: 异常/崩溃

    COMMITTING --> UPDATING_MPT: trie.Update()
    UPDATING_MPT --> COMMIT_MPT: trie.Commit(SHA256)
    COMMIT_MPT --> SAVING_MPT: trie.Save()
    SAVING_MPT --> DONE: DBWrite完成

    TIMEOUT --> STALE_THREAD: async线程继续执行
    STALE_THREAD --> STALE_THREAD: 资源泄漏风险
    REVERTED --> ROLLBACK: host析构丢弃MPT修改
    EXCEPTION --> ROLLBACK
    FAILED --> ROLLBACK

    DONE --> [*]: 事务提交
    ROLLBACK --> [*]: 事务回滚
```

**执行状态码**:
| 状态 | 值 | 说明 |
|------|------|------|
| EVMC_SUCCESS | 0 | 执行成功 |
| EVMC_FAILURE | 1 | 通用失败 |
| EVMC_REVERT | 2 | 合约REVERT |
| EVMC_OUT_OF_GAS | 3 | Gas不足 |
| EVMC_INVALID_INSTRUCTION | 4 | 无效指令 |
| EVMC_UNDEFINED_INSTRUCTION | 5 | 未定义指令 |
| EVMC_STACK_OVERFLOW | 6 | 栈溢出 |
| EVMC_STACK_UNDERFLOW | 7 | 栈下溢 |

---

## 二、合约生命周期状态机

```mermaid
stateDiagram-v2
    [*] --> UNDEPLOYED: 初始状态

    UNDEPLOYED --> DEPLOYING: CreateDeploy请求
    DEPLOYING --> DEPLOYING_EVM: EVM执行初始化代码
    DEPLOYING_EVM --> DEPLOYED: 初始化成功
    DEPLOYING_EVM --> UNDEPLOYED: 初始化失败(回滚)

    DEPLOYED --> IDLE_DEPLOYED: 等待调用
    IDLE_DEPLOYED --> CALLING: CreateCall请求
    CALLING --> LOADING_STATE: 加载代码+MPT
    LOADING_STATE --> EXECUTING_CALL: vm.execute(CALL)
    EXECUTING_CALL --> STATE_UPDATED: 执行成功
    EXECUTING_CALL --> DEPLOYED: 执行失败/Revert

    STATE_UPDATED --> MPT_DIRTY: trie.Update()
    MPT_DIRTY --> MPT_COMMITTED: trie.Commit(SHA256)
    MPT_COMMITTED --> MPT_SAVED: trie.Save()
    MPT_SAVED --> IDLE_DEPLOYED: 等待下次调用

    DEPLOYED --> SELFDESTRUCTED: SELFDESTRUCT
    SELFDESTRUCTED --> [*]: 合约销毁
```

---

## 三、MPT 状态机

```mermaid
stateDiagram-v2
    [*] --> EMPTY_TRIE: CreateTrie(empty_root)

    EMPTY_TRIE --> LOADED: CreateTrie(existing_root)
    LOADED --> INSERTING: Update(key, value)
    INSERTING --> DIRTY: Insert返回新节点

    DIRTY --> HASHED: Commit(node)
    HASHED --> PERSISTED: Save()→DBWrite
    PERSISTED --> INSERTING: 下一次Update

    EMPTY_TRIE --> INSERTING: 首次插入
    INSERTING --> DIRTY

    note right of HASHED
        SHA256(hex(RLP(node)))
        非 Keccak256!
    end note

    note right of LOADED
        DescendKey →
        DB获取RLP →
        DecodeNode
    end note
```

**MPT 节点类型**:
| 节点 | 结构 | RLP编码 |
|------|------|---------|
| HashNode | `data: string` | `RLP(hash)` |
| ValueNode | `data: string` | `RLP(data)` |
| ShortNode | `key, val, flags` | `RLP([key, Encode(val)])` 2元素 |
| FullNode | `children[17], flags` | `RLP([c0,...,c16])` 17元素 |

**空子节点**: 编码为空字符串 `""`

---

## 四、Gas 费用状态机

```mermaid
stateDiagram-v2
    [*] --> INITIAL_FEE: baseFee = 10 (创世/无历史)

    INITIAL_FEE --> CHECK_LIMIT: 新合约交易
    CHECK_LIMIT --> REJECTED: gasCost > 120000
    CHECK_LIMIT --> LOAD_OLD_FEE: gasCost <= 120000

    LOAD_OLD_FEE --> OLD_FEE_FOUND: 链上找到fromAddr历史交易
    LOAD_OLD_FEE --> USE_INITIAL: 未找到(创世区块)

    OLD_FEE_FOUND --> CALCULATE: old_baseFee = txInfo["baseFee"]
    USE_INITIAL --> CALCULATE: old_baseFee = 10

    CALCULATE --> ADJUST_UP: gasCost > 60000
    CALCULATE --> ADJUST_DOWN: gasCost < 60000
    CALCULATE --> KEEP: gasCost == 60000

    ADJUST_UP --> CEIL: ceil(new_fee)
    ADJUST_DOWN --> FLOOR: floor(new_fee)
    KEEP --> NEW_FEE: 不变

    CEIL --> NEW_FEE
    FLOOR --> NEW_FEE

    NEW_FEE --> RECORD: 写入txInfo["baseFee"]
    RECORD --> [*]: 事务提交
    REJECTED --> [*]: 拒绝交易
```
