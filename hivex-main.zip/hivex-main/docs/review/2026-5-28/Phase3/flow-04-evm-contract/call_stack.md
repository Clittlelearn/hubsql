# 流程4: EVM 合约部署与调用 — 函数调用栈

> **可信度**: 高 — 基于源码函数签名交叉验证
> **表示法**: `函数签名` (`文件:行号`) [同步/异步]

---

## 一、合约部署调用栈 (JSON-RPC)

```
1. HTTP入口
   ├─ HttpServer::RegisterCallback("/api", api_template)
   │   └─ api/interface/http_api.cpp:278  [同步, HTTP线程]
   ├─ rpc_create_transaction::ReplaceCreateDeployContractTransaction()
   │   └─ api/interface/rpc_create_transaction.cpp  [同步]
   │
2. 交易构造
   ├─ mmc::rpc::createDeploy(addr, contract, data, contract_type, ...)
   │   └─ rpc/api/post/rpc_api_deployContract.cpp  [同步]
   ├─ EIP1559FeeCalculator::calculateNewFee(old_baseFee, gasCost, KTargetGasPrice)
   │   └─ ca/fee_calculator.h:27  [同步, double浮点]
   │      ├─ adjustment_factor = (gasCost - KTargetGasPrice) / (KTargetGasPrice * 8.0)
   │      ├─ new_fee = old_baseFee * (1.0 + adjustment_factor)
   │      └─ new_fee = ceil/floor/保持 → max(new_fee, 0.0)
   │
   ├─ TxHelper::createDeployTransaction(addr, contract, data, asset_type, ...)
   │   └─ ca/txhelper.cpp  [同步]
   │      ├─ FindUtxo(addr, asset_type, amount)  // UTXO选择
   │      │   └─ ca/transaction/utxo_core.cpp  [同步, DBReader]
   │      ├─ GenerateGas(utxo, gasSize)  // Gas估算
   │      │   └─ ca/transaction/utxo_core.cpp
   │      ├─ 构造CTransaction (type=DEPLOY)
   │      └─ SigTx(tx, addr)  // ECDSA签名
   │         └─ ca/ca.cpp:161
   │
3. 发送与缓存
   ├─ SendContractMessage RPC
   │   └─ rpc/api/post/rpc_api_postContractMsg.cpp  [同步]
   ├─ dropCallShippingRequest(tx, msg)
   │   └─ ca/contract.cpp  [同步→异步]
   │      ├─ DependencyManager::CanSendTransaction(msg)
   │      │   └─ ca/dispatchtx.cpp  [检查依赖冲突]
   │      ├─ [冲突] ContractTransactionCache::AddFailedTransaction
   │      │   └─ ca/contract_transaction_cache.cpp (大部分#if 0注释)
   │      └─ [无冲突] contractTransactionRequest(tx, msg)
   │         └─ 广播到P2P网络
   │
4. 打包与执行
   ├─ VRFConsensusNode::Process() [异步, CA线程]
   │   └─ ca/vrf_consensus.cpp
   ├─ BuildBlock() [异步, 打包线程]
   │   └─ ca/block_helper.cpp
   ├─ handleBlock() → SaveBlock()
   │   └─ ca/block_helper.cpp:PreSaveProcess
   │
   ├─ execute_by_evmone(contract_msg)  ** [异步, 独立线程]
   │   └─ ca/contract.cpp:94
   │      ├─ std::async(std::launch::async, ...)
   │      ├─ future.wait_for(10s timeout)
   │      │
   │      ├─ EvmHost::call(msg)
   │      │   └─ ca/evm/evm_host.cpp:约150行  [异步, EVM线程]
   │      │      ├─ recordAccountAccess(msg.recipient)
   │      │      ├─ 自毁检查 recorded_selfdestructs
   │      │      ├─ 价值转移 getContractTransfer
   │      │      │
   │      │      ├─ [DEPLOY分支]
   │      │      │   ├─ nonceCache++
   │      │      │   ├─ GenerateContractAddrEth(fromAddr, nonce)
   │      │      │   │   └─ utils/contract_utils.cpp:73-89
   │      │      │   │      ├─ senderBytes = HexToBytes(addr)
   │      │      │   │      ├─ rlpData = RLP([senderBytes, nonce])
   │      │      │   │      ├─ hash = Keccak256(rlpData)
   │      │      │   │      └─ contractAddr = hash[12:32]
   │      │      │   ├─ createContract(msg, amount, fromAddr, contractAddr)
   │      │      │   └─ SaveContract(contractAddr, runtimeCode, deployer)
   │      │      │      └─ ca/evm/evm_manager.cpp
   │      │      │         ├─ setContractCode(addr, code)    → EVM_CODE:{addr}
   │      │      │         ├─ setContractDeployUtxo(addr, utxo) → EVM_UTXO:{addr}
   │      │      │         ├─ setContractDeployer(deployer, addr) → EVM_DEPLOY:{deployer}
   │      │      │         └─ addDeployerAddress(deployer)   → EVM_DEPLOYER
   │      │      │
   │      │      ├─ [CALL分支]
   │      │      │   ├─ evm_utils::GetContractCode(addr)
   │      │      │   │   └─ db/db_api.cpp:EVM_CODE前缀查询
   │      │      │   ├─ fetchContractRootHash(addr, rootHash, storage)
   │      │      │   │   └─ db/db_api.cpp:MPT根哈希查询
   │      │      │   ├─ CreateTrie(rootHash, addr, contractDataStorage)
   │      │      │   │   └─ mpt/trie.cpp:44
   │      │      │   │      ├─ ResolveHash(HashNode{rootHash})
   │      │      │   │      ├─ DescendKey→DB获取RLP数据
   │      │      │   │      └─ DecodeNode→节点树构建
   │      │      │   └─ EvmEnvironment::build(block_info)
   │      │      │      └─ ca/evm/evmEnvironment.cpp:297
   │      │      │         ├─ blockTimestamp = calculateBlockTimestamp(3)
   │      │      │         ├─ blockPrevRandao = UTXO hash拼接
   │      │      │         ├─ block_gas_limit = INT64_MAX
   │      │      │         └─ message.gas = signedBalance  // 用户全部VOTE余额
   │      │      │
   │      │      ├─ 预编译优先: evmone::state::call_precompile(MAX_REVISION, msg)
   │      │      │   └─ contract/precompiles.cpp
   │      │      │
   │      │      └─ vm.execute(*this, MAX_REVISION, msg, code, code_size)
   │      │         └─ evmone (外部静态库)
   │      │
   │      ├─ [成功] trie.Save()
   │      │   └─ mpt/trie.cpp
   │      │      ├─ Commit(n) → 计算SHA256哈希 → dirtyHash映射
   │      │      └─ Save() → 遍历dirtyHash → DBWrite
   │      │         └─ db/db_api.cpp:setMptValueByMptKey
   │      │
   │      └─ [失败] host析构 → MPT修改丢弃
   │
   └─ DBReadWriter::transactionCommit()
      └─ db/rocksdb_read_write.cpp  [同步, 原子提交]
```

---

## 二、ETH 兼容路径调用栈

```
1. HTTP入口
   ├─ HttpServer::RegisterCallback("/eth", eth_dispatch)
   │   └─ api/interface/http_api.cpp  [同步, HTTP线程]
   │
2. ETH分发
   ├─ eth_dispatch(json)
   │   └─ rpc/eth/eth_rpc.cpp  [同步]
   │      ├─ JSON解析 → method提取
   │      └─ 方法路由:
   │
   ├─ handleEthSendRawTransaction(signedTxHex)
   │   └─ rpc/eth/eth_impl.cpp:约40行  [同步]
   │      ├─ HexToBytes(signedTxHex)
   │      ├─ RLP解码 → 提取nonce/gasPrice/gasLimit/to/value/data/v/r/s
   │      │   └─ mpt/rlp.cpp
   │      ├─ ecrecover(RLP(tx), v, r, s) → 恢复from地址
   │      │   └─ contract/precompiles_silkpre.cpp (silkpre预编译)
   │      ├─ [to为空] → TxHelper::createDeployTransaction(...)
   │      ├─ [to=合约] → TxHelper::createCallTransaction(...)
   │      ├─ [to=普通] → TxHelper::createTransaction(...)
   │      │
   │      ├─ EIP1559FeeCalculator
   │      │   └─ ca/fee_calculator.h
   │      ├─ 精度转换: value_10^18 → value_10^8
   │      │   └─ rpc/eth/eth_impl.cpp:scale_down
   │      │
   │      └─ SendContractMessage / SendMessage
   │         └─ 后续流程同JSON-RPC路径
```

---

## 三、MPT 状态树操作调用栈

```
1. 创建/加载 Trie
   ├─ CreateTrie(rootHash, contractAddr, contractDataStorage)
   │   └─ mpt/trie.cpp:44
   │      ├─ HashNode{rootHash} → ResolveHash
   │      ├─ DescendKey(contractAddr, hash_hex, value)
   │      │   └─ db/db_api.cpp:读取 MPT:{contractAddr}_{hash}
   │      └─ DecodeNode(RLP bytes) → ShortNode/FullNode/ValueNode
   │         └─ mpt/rlp.cpp:RLP解码
   │
2. 插入/更新
   ├─ Trie::Insert(n, prefix, key, value)
   │   └─ mpt/trie.cpp
   │      └─ 递归下降 → 到达叶子 → 创建/更新ValueNode
   ├─ Trie::Update(key, value) → Insert(root, {}, key, value)
   │
3. 提交与持久化
   ├─ Trie::Commit(n)
   │   └─ mpt/trie.cpp
   │      ├─ Encode(n) → RLP序列化
   │      │   └─ RLP([key, Encode(value)]) // ShortNode
   │      │   └─ RLP([c0, c1, ..., c16])  // FullNode
   │      ├─ Getsha256Hash(hex(RLP字节))  ← ** SHA256非Keccak256 **
   │      │   └─ utils/sha256.cpp:585
   │      └─ 脏节点→dirtyHash映射
   │
   └─ Trie::Save()
      └─ mpt/trie.cpp
         └─ 遍历dirtyHash → DBWrite
            └─ db/db_api.cpp:setMptValueByMptKey
               └─ Key: MPT:{contractAddr}_{hash} → Value: RLP hex
```

---

## 四、EIP-1559 Gas 计算调用栈

```
EIP1559FeeCalculator::calculateNewFee(old_baseFee, gasCost, target)
  └─ ca/fee_calculator.h:12-27  [同步]
     ├─ adjustment_factor = (gasCost - KTargetGasPrice) / (KTargetGasPrice * 8.0)
     │   // KTargetGasPrice = 60000, 除数为480000.0
     ├─ new_fee_exact = old_baseFee * (1.0 + adjustment_factor)
     ├─ [gasCost > target] → ceil(new_fee_exact)
     ├─ [gasCost < target] → floor(new_fee_exact)
     ├─ [gasCost == target] → new_fee_exact
     └─ max(new_baseFee, 0.0)

调用位置:
  ├─ ca/contract.cpp:VerifyContractBaseFee(fromAddr, gasCost)
  │   ├─ 限额检查: gasCost > KTargetGasPrice * 2 (=120000) → 拒绝
  │   ├─ 查找fromAddr最后一笔合约交易的baseFee → old_baseFee
  │   │   └─ 遍历链顶向下, 提取txInfo["baseFee"]
  │   ├─ [未找到] old_baseFee = INITIAL_BASE_FEE = 10
  │   ├─ calculateNewFee(old_baseFee, gasCost, KTargetGasPrice)
  │   └─ gasCost *= new_baseFee  // 计算最终Gas费用
  └─ 写入新交易的txInfo["baseFee"]
```
