# 节点启动与数据库恢复流程 -- 异步任务流转

## 1. 异步任务全景时序

```mermaid
sequenceDiagram
    autonumber

    participant Entry as entry.cpp:main()
    participant Config as Config::_Check线程
    participant CA as CaInit异步任务
    participant Net as NetInit异步任务
    participant SyncBlock as SyncBlock线程
    participant Heartbeat as 心跳定时器

    Entry->>Entry: main() 启动 entry.cpp:5

    Note over Entry: === 阶段A: Config构造时启动后台线程 ===

    Entry->>Config: InitConfig() -> MagicSingleton<Config>
    Note over Config: Config::Config() 构造函数中<br/>common/config.h:87<br/>_thread = std::thread(_Check)
    activate Config
    Config-->>Config: _Check() 后台循环<br/>common/config.cpp:647
    Note over Config: 循环: sleep 3600秒 -> GetAllServerAddress()

    Note over Entry: === 阶段B: InitRocksDb 完成后 ===

    Note over Entry: CaInit() && NetInit()<br/>main/main.cpp:79

    Note over CA: === CaInit 启动的异步任务 (ca/ca.cpp:98-127) ===

    rect rgb(200, 230, 255)
        Note over CA: StartTimerTask() ca/ca.cpp:113

        CA->>CA: BLOCK_POOL_TIMER_INTERVAL.AsyncLoop(100ms)<br/>ca/ca.cpp:75
        activate CA
        Note over CA: 任务池定时器, 定期调用<br/>BlockHelper::Process()<br/>检测是否有新区块需要打包

        CA->>CA: SEEK_BLOCK_TIMER.AsyncLoop(3000ms)<br/>ca/ca.cpp:78
        activate CA
        Note over CA: 每3秒探测未同步的区块<br/>BlockHelper::SeekBlockThreadObject()

        CA->>CA: BlockHelper::SeekBlockThreadObject() (立即)<br/>ca/ca.cpp:81
        Note over CA: 首次立即执行一次区块探测

        CA->>SyncBlock: SyncBlock::ThreadStart()<br/>ca/ca.cpp:84
        activate SyncBlock
        Note over SyncBlock: 创建 _syncThread 后台线程<br/>ca/sync_block.cpp:184<br/>循环: syncThreadRunning=true时<br/>检测chainHeight vs peer height<br/>落后 -> 请求 SyncNodeReq -> 写入DB

        CA->>CA: CheckBlocks::StartTimer()<br/>ca/ca.cpp:85
        Note over CA: 验证已接收区块的一致性

        CA->>CA: failedTransactionCache::_StartTimer()<br/>ca/ca.cpp:87
        Note over CA: 定期清理失败交易缓存

        CA->>CA: BlockStorage 单例创建<br/>ca/ca.cpp:91
        Note over CA: 区块存储管理后台任务

        CA->>CA: doubleSpendCache 单例创建<br/>ca/ca.cpp:93
        Note over CA: 双花检测缓存管理
    end

    CA->>CA: CheckNtpTime()<br/>ca/ca.cpp:116
    Note over CA: 同步: NTP vs 本地时间<br/>(不阻塞, 仅校验差值 <= 1秒)

    rect rgb(230, 255, 230)
        Note over CA: 启动核心异步处理 (ca/ca.cpp:118-122)

        CA->>CA: TransactionCache::Process()<br/>ca/ca.cpp:118
        activate CA
        Note over CA: 交易缓存处理循环<br/>从缓存中提取待处理交易

        CA->>CA: ContractDispatcher::Process()<br/>ca/ca.cpp:120
        activate CA
        Note over CA: 合约调度处理循环<br/>分配合约执行任务

        CA->>CA: VRFConsensusNode::Process()<br/>ca/ca.cpp:122
        activate CA
        Note over CA: VRF共识节点处理循环<br/>参与共识算法
    end

    Note over Net: === NetInit 启动的异步任务 (net/interface.h:13-46) ===

    rect rgb(255, 230, 255)
        Note over Net: InitializeNetwork() net/api.cpp:404

        Net->>Net: WorkThreads::Start()<br/>net/api.cpp:474
        activate Net
        Note over Net: 启动工作线程池<br/>用于并行处理网络消息

        Net->>Net: EpollMode::EPOL_MODE_START()<br/>net/api.cpp:477
        activate Net
        Note over Net: epoll 事件循环线程<br/>监听 TCP 连接<br/>接收/分发网络消息

        Net->>Net: PeerNode::initNodeListRefreshThread()<br/>net/api.cpp:480
        activate Net
        Note over Net: 节点列表刷新线程<br/>连接 config.json 中的 server 种子<br/>每60秒刷新一次节点列表

        Net->>Net: PeerNode::nodelistSwitchThread()<br/>net/api.cpp:483
        activate Net
        Note over Net: 节点交换线程<br/>与已连接节点交换节点列表

        Net->>Heartbeat: g_heartTimer.AsyncLoop()<br/>net/api.cpp:486
        activate Heartbeat
        Note over Heartbeat: 心跳定时器<br/>定期发送 PingReq<br/>检测节点存活
    end

    Note over Entry: === 正常运行 ===
    Note over Config,CA,SyncBlock,Net,Heartbeat: 所有异步任务并行运行

    Note over Entry: === 信号触发的清理 ===

    Entry->>Entry: SIGINT/SIGTERM 信号<br/>graceful_exit_handler() utils/init.cpp:221
    Note over Entry: unlink(PID文件)<br/>SystemErrorHandler(sig)<br/>_exit(128+sig)

    Note over Entry: === 正常退出清理 ===
```

## 2. 清理时的异步线程停止顺序 (CaCleanup)

```mermaid
sequenceDiagram
    autonumber

    participant Caller as CleanUp() main:276
    participant CaCleanup as CaCleanup() ca:137

    Caller->>CaCleanup: CaCleanup()

    Note over CaCleanup: 第1步: 停止定时器 (ca/ca.cpp:140-142)

    CaCleanup->>CaCleanup: CaEndTimerTaskV2() ca:140
    Note over CaCleanup: DATABASE_TIMER.Cancel()<br/>BLOCK_POOL_TIMER_INTERVAL.Cancel()<br/>SEEK_BLOCK_TIMER.Cancel()

    CaCleanup->>CaCleanup: g_heartTimer.Cancel() ca:142
    Note over CaCleanup: 停止心跳定时器

    Note over CaCleanup: 第2步: 停止缓存服务 (ca/ca.cpp:144-156)

    CaCleanup->>CaCleanup: failedTransactionCache::StopTimer() ca:144
    CaCleanup->>CaCleanup: BlockHelper::stopSaveBlock() ca:146
    CaCleanup->>CaCleanup: Benchmark::Clear() ca:148
    CaCleanup->>CaCleanup: TransactionCache::Stop() ca:150
    CaCleanup->>CaCleanup: BlockStorage::StopTimer() ca:154
    CaCleanup->>CaCleanup: doubleSpendCache::StopTimer() ca:156

    Note over CaCleanup: 第3步: 停止同步线程 (ca/ca.cpp:152)

    CaCleanup->>CaCleanup: SyncBlock::ThreadStop() ca:152
    Note over CaCleanup: syncThreadRunning = false<br/>等待 _syncThread 自然退出循环

    Note over CaCleanup: 第4步: 停止网络层 (ca/ca.cpp:158-166)

    CaCleanup->>CaCleanup: EpollMode::EpollStop() ca:158
    CaCleanup->>CaCleanup: BlockHttpCallbackHandler::Stop() ca:160
    CaCleanup->>CaCleanup: PeerNode::stopNodesSwap() ca:162
    CaCleanup->>CaCleanup: CheckBlocks::StopTimer() ca:164
    CaCleanup->>CaCleanup: VRF::StopTimer() ca:166

    Note over CaCleanup: 第5步: 等待全部线程退出 (ca/ca.cpp:169)

    CaCleanup->>CaCleanup: sleep(5) ca:169
    Note over CaCleanup: 等待5秒让所有线程自然退出

    CaCleanup-->>Caller: clean finish
```

**清理顺序分析:**
1. 先停定时器 (Cancel) -- 防止新的周期任务触发
2. 再停业务缓存 (StopTimer/Stop) -- 停止缓存处理
3. 停同步线程 (ThreadStop: 设置 flag=false, 线程检测后自然退出循环)
4. 停网络层 (EpollStop) -- 断开所有连接
5. sleep(5) -- 等待所有线程退出 (无显式 join)

## 3. 异步任务详细清单

### 3.1 Config::_Check 后台配置监控

| 属性 | 值 |
|------|-----|
| 启动时机 | Config 构造函数 `common/config.h:87` |
| 运行线程 | 独立 `std::thread` |
| 循环间隔 | 1800 x 2秒 = 3600秒 (1小时) `common/config.cpp:651` |
| 停止方式 | `_exitThread=true` -> `thread.join()` (Config析构) |
| 安全性 | 写 config.json 无锁保护, 与 `InitFile/Save` 等操作可能竞争【需人工验证】 |
| 功能 | 定期将已连接节点列表合并写入 config.json 的 server 字段 |

### 3.2 CaInit 启动的异步任务

| 任务 | 启动位置 | 类型 | 间隔 | 功能 |
|------|---------|------|------|------|
| BlockHelper::Process() | `ca/ca.cpp:75` | CTimer异步循环 | 100ms | 检测是否有待打包交易, 生成新区块 |
| BlockHelper::SeekBlockThreadObject() | `ca/ca.cpp:78` | CTimer异步循环 | 3s | 探测缺失区块高度 |
| BlockHelper::SeekBlockThreadObject() (立即) | `ca/ca.cpp:81` | 即时调用 | -- | 首次立即执行探测 |
| SyncBlock::ThreadStart() | `ca/ca.cpp:84` | 独立线程 | 轮询 10s~自适应 | 区块同步: 检测高度差, 请求/接收/写入区块 |
| CheckBlocks::StartTimer() | `ca/ca.cpp:85` | CTimer | -- | 验证已接收区块完整性 |
| failedTransactionCache::_StartTimer() | `ca/ca.cpp:87` | CTimer | -- | 清理过期失败交易 |
| TransactionCache::Process() | `ca/ca.cpp:118` | 独立线程 | -- | 交易预处理与缓存管理 |
| ContractDispatcher::Process() | `ca/ca.cpp:120` | 独立线程 | -- | EVM合约调度与执行 |
| VRFConsensusNode::Process() | `ca/ca.cpp:122` | 独立线程 | -- | VRF共识参与 |

### 3.3 NetInit 启动的异步任务

| 任务 | 启动位置 | 类型 | 功能 |
|------|---------|------|------|
| WorkThreads::Start() | `net/api.cpp:474` | 线程池 | 并行处理网络消息 |
| EpollMode::EPOL_MODE_START() | `net/api.cpp:477` | epoll事件循环 | TCP监听 + 接收/分发消息 |
| initNodeListRefreshThread() | `net/api.cpp:480` | 独立线程 | 连接种子节点, 定期刷新节点列表 |
| nodelistSwitchThread() | `net/api.cpp:483` | 独立线程 | 与对等节点交换节点列表 |
| g_heartTimer.AsyncLoop() | `net/api.cpp:486` | CTimer | 心跳: DealHeart() 定期检测存活 |

## 4. 信号处理异步路径

```
信号产生 (SIGINT/SIGTERM/SIGABRT/SIGSEGV/SIGFPE/SIGILL/SIGQUIT)
  |
  v
graceful_exit_handler(sig)                         utils/init.cpp:221
  |
  +-> tcsetattr() 恢复终端设置 (如已保存)            utils/init.cpp:224-227
  |
  +-> unlink(GetPidFilePath())                       utils/init.cpp:231
  |     删除 /tmp/moonmesh.pid
  |
  +-> SystemErrorHandler(sig)                        include/logging.cpp:74
  |     +-> signal(sig, SIG_DFL) 恢复默认信号处理
  |     +-> backtrace() 获取调用栈
  |     +-> CRITICALLOG 记录错误栈
  |     +-> raise(sig) 重新抛出信号
  |
  +-> _exit(128 + sig)                              utils/init.cpp:235
        (直接退出, 不执行 atexit/析构)
```

**注意**: 信号处理路径使用 `_exit(128+sig)`, 而不是 `exit()`. 这意味着:
- 不会调用 `atexit()` 注册的函数
- 不会调用全局/静态对象的析构函数
- RocksDB 的 WAL 不会被 flush, 可能导致未提交数据丢失【需人工验证】
- **不会调用 CaCleanup()**, 所以 CA 相关线程的清理不会发生
- `at_quick_exit(RemovePidFile)` 在本路径无效 (quick_exit 走不同路径)

## 5. 关键发现与风险点

### 5.1 CaInit && NetInit 短路求值风险
`main/main.cpp:79`: `return CaInit() && NetInit();`
- 若 CaInit() 返回 true, NetInit() 返回 false: Init() 返回 false
- `init_check()` 中 `Init()` 失败 -> `initFail = true` -> `CleanUp()` -> `CaCleanup()`
- 此路径下 CaCleanup 会正确清理
- **但若两个都成功**: 正常路径
- **若 CaInit 成功但 NetInit 内部部分失败**: NetInit 始终返回 true (见 `net/interface.h:45`), 所以此场景实际上不会出现

### 5.2 CleanUp 中 sleep(5) 的充分性
`ca/ca.cpp:169`: `sleep(5)` 用于等待线程退出.
- SyncBlock::ThreadStop() 仅设置 `syncThreadRunning=false`, 不 join 线程
- 各定时器 Cancel() 是异步的
- 若线程在 sleep(5) 期间未完成退出, 后续进程退出可能导致资源泄漏
- 【需人工验证】SyncBlock 线程的检查周期为 10 秒 (`SYNC_HEIGHT_TIME`), 5 秒可能不够一轮检查完成

### 5.3 Config::_Check 热加载安全性
- `_Check()` 运行在独立线程 (`common/config.cpp:647-660`)
- `GetAllServerAddress()` 写 config.json 时使用 `std::filesystem::remove + std::ofstream` (`common/config.cpp:640-642`)
- 与 `InitFile` 等其他写操作无互斥锁保护
- 多个读取操作 (`_Parse`, `_Filter`, `_Verify`) 也无锁保护
- 【需人工验证】并发读写 config.json 可能导致数据竞争

### 5.4 CheckNtpTime 失败不阻止启动
`ca/ca.cpp:116`: `CheckNtpTime()` 返回值被忽略
- CaInit 总是返回 true (除非上述某个异步 Process 调用在返回前抛异常)
- 即使 NTP 时间差 > 1秒, 节点也正常启动
- 设计意图: NTP 是建议性校验, 不是强依赖

### 5.5 DB损坏处理
`db/rocksdb.cpp:17-18`: `BackgroundErrorListener::OnBackgroundError` 直接 `exit(-1)`
- 无自动备份/无自动恢复
- 无人工干预路径

---

**说明:**
- 所有源码行号引用基于项目路径 `//wsl$/wsl-mm/home/wbl/mm/`
- 【需人工验证】标注表示基于代码静态分析的推断
- CTimer 是项目自定义的定时器实现, 内部使用单线程 + 条件变量
