# 节点启动与数据库恢复流程 -- 时序图

## 1. 正常启动完整时序

```mermaid
sequenceDiagram
    autonumber

    participant Entry as entry.cpp:main()
    participant Init as utils/init.cpp
    participant Cmdline as utils/cmdline.cpp
    participant Main as main/main.cpp
    participant Config as common/config.cpp
    participant Genesis as common/genesis.cpp
    participant Log as include/logging.cpp
    participant Account as utils/account_manager.cpp
    participant DB as db/rocksdb.cpp
    participant DBAPI as db/db_api.cpp
    participant GB as utils/genesis_block.cpp
    participant CA as ca/ca.cpp
    participant Sync as ca/sync_block.cpp
    participant NetHdr as net/interface.h
    participant NetAPI as net/api.cpp
    participant PeerNode as net/peer_node.cpp
    participant ECDH as net/key_exchange.cpp

    %% === 阶段0: 进程启动 + 信号处理 ===
    Entry->>Init: init_signal_handlers()<br/>entry.cpp:9
    Init->>Init: InitPidFile()<br/>utils/init.cpp:191
    Note over Init: PID文件锁 (O_CREAT|O_EXCL)<br/>文件路径: /tmp/moonmesh.pid<br/>检测已有进程，防重入
    Init->>Init: sigaction(SIGINT/SIGTERM/SIGABRT...)<br/>utils/init.cpp:255-268
    Note over Init: 注册 graceful_exit_handler<br/>信号触发 -> unlink PID文件 -> SystemErrorHandler -> _exit(128+sig)
    Init->>Init: setenv("TZ","Universal") / tzset()<br/>utils/init.cpp:270-271

    %% === 阶段1: 命令行解析 ===
    Entry->>Cmdline: parse_cmdline_args(argc, argv)<br/>entry.cpp:14
    Note over Cmdline: 解析子命令: "menu/m" | "daemon/d" | "gen/g" | "set/s" | "test" | "help"
    Cmdline->>Main: cmdline::menu() -> init_check()<br/>utils/cmdline.cpp:83

    %% === 阶段2: Init() ===
    Main->>Main: init_check() -> Init()<br/>main/main.cpp:282-301

    %% 2.1 随机数种子
    Main->>Main: srand(TimeUtil::GetUTCTimestamp())<br/>main/main.cpp:37

    %% 2.2 InitConfig
    Main->>Config: InitConfig() -> MagicSingleton(Config)<br/>main/main.cpp:41-46
    Note over Config: Config::Config(bool& flag)<br/>common/config.h:90-95
    Config->>Config: InitFile()<br/>common/config.cpp:45
    alt config.json 存在
        Config->>Config: 读取 -> _Parse(json)
        Config->>Config: _Filter() 端口/IP/日志格式校验
        Config->>Config: _Verify() 名称/Logo正则
    else config.json 不存在
        Config->>Config: 创建默认 config.json (kConfigJson内嵌)<br/>common/config.cpp:77-87
        Config->>Config: 解析默认配置
    end
    Config->>Config: 启动后台 _Check 线程<br/>config.h:87 (构造函数内)
    Note over Config: _Check线程: 每3600秒刷新一次server列表到config.json

    %% 2.3 InitGenesis
    Main->>Genesis: InitGenesis() -> MagicSingleton(Genesis)<br/>main/main.cpp:48-53
    alt genesis.json 存在
        Genesis->>Genesis: TryLoadFromFile()<br/>common/genesis.cpp:267-293
        Note over Genesis: 校验: genesis/network/network.type/network.name
    else 文件不存在
        Genesis->>Genesis: CreateDefaultData(Dev)<br/>common/genesis.cpp:187-210
        Genesis->>Genesis: Save() 写入默认genesis.json
    end

    %% 2.4 InitLog
    Main->>Log: InitLog()<br/>main/main.cpp:56-61
    Note over Log: 从Config获取 log.path/console/level<br/>LogInit(.)

    %% 2.5 InitAccount
    Main->>Account: InitAccount()<br/>main/main.cpp:64-69
    Note over Account: AccountManager::Initialize()<br/>utils/account_manager.cpp:744-819
    Account->>Account: 确保 keystore 目录存在
    Account->>Account: _scanKeystoreDirectory() 扫描 .json 文件
    alt keystore目录为空
        Account->>Account: 返回 EMPTY_KEYSTORE
        Main->>Account: CreateInitialAccount()<br/>main/main.cpp:117
        Account->>Account: Account(true) 生成 secp256k1密钥对
        Account->>Account: 用户设置密码 -> SavePrivateKeyToKeystoreFile()
    else keystore目录非空
        Account->>Account: loadExistingAccounts()
        Note over Account: 逐个解锁keystore文件<br/>最多密码重试3次<br/>Dev模式支持单密码批量解锁<br/>大账户量(>10)支持多线程
        Account->>Account: 设置默认账户: genesis.initAccountAddr 或首个
    end

    %% 2.6 InitRocksDb
    Main->>DBAPI: InitRocksDb() -> DBInit("./data.db")<br/>main/main.cpp:72-77
    DBAPI->>DB: RocksDB::initDB()<br/>db/rocksdb.cpp:40-65
    Note over DB: options.create_if_missing = true<br/>TransactionDB::Open()<br/>注册 BackgroundErrorListener (OnBackgroundError -> exit(-1))

    alt 数据库为空 (首次启动)
        DBAPI->>DBAPI: getBlockTop() 失败<br/>main/main.cpp:165-166
        Main->>GB: GenesisBlock::GenerateGenesisBlock(block)<br/>main/main.cpp:172
        GB->>GB: block.set_time(GenesisTime)<br/>block.set_version(kCurrentBlockVersion)<br/>prevhash = 0000..(64零)
        GB->>GB: CreateGenesisTransaction(tx)<br/>utils/genesis_block.cpp:59
        Note over GB: tx.type = GENESIS<br/>tx.identity = initAccountAddr<br/>utxos: MM(0) + Vote(0)
        GB->>GB: 计算 merkle root + block hash (SHA256)
        GB-->>Main: block 生成成功
        Main->>DBAPI: 写入: blockHash<->blockHeight + blockTop=0<br/>main/main.cpp:195-198
        Main->>DBAPI: 遍历 utxos: setUtxoHashesByAddr + setBalanceByAddr<br/>main/main.cpp:200-222
        Main->>DBAPI: setTransactionByHash + setBlockHashByTransactionHash<br/>main/main.cpp:224-225
    else 数据库已有数据 (恢复启动)
        DBAPI->>DBAPI: getBlockTop() 成功
        Note over DBAPI: 跳过创世区块生成, 直接到 setInitVer
    end
    DBAPI->>DBAPI: setInitVer(mm::GetVersion())<br/>main/main.cpp:227
    DBAPI->>DBAPI: transactionCommit()<br/>main/main.cpp:228

    %% === 阶段3: Check() 创世区块一致性校验 ===
    Main->>Main: Check()<br/>main/main.cpp:290
    Main->>DBAPI: getBlockHashByBlockHeight(0) 获取DB中创世hash
    Main->>DBAPI: getBlockByBlockHash(hash) 获取DB中创世block
    Main->>GB: GenesisBlock::GenerateGenesisBlock()<br/>重新计算期望创世区块
    Main->>Main: 比较 expectedBlock.hash() == dbHash
    alt hash一致
        Main->>Main: Check() 返回 true
    else hash不一致
        Main->>Main: Check() 返回 false
        Main->>Main: initFail = true -> CleanUp()
    end

    %% === 阶段4: CaInit + NetInit ===
    Main->>Main: CaInit() && NetInit()<br/>main/main.cpp:79

    par CaInit
        CA->>CA: RegisterInterface()<br/>ca/interface.cpp:1792
        Note over CA: 注册17个业务回调:<br/>GetBlockReq/GetBalanceReq/GetNodeInfoReq/<br/>GetStakeListReq/GetDelegateListReq...<br/>ConfirmTransactionReq/CheckVinReq...
        CA->>CA: RegisterCallback()<br/>ca/ca.cpp:2514 -> net_register_callback()
        alt RPC已启用
            CA->>CA: subscribeToHttpCallbacks()
        end
        CA->>CA: StartTimerTask()<br/>ca/ca.cpp:72-96
        Note over CA: 启动: BLOCK_POOL_TIMER(100ms)<br/>SEEK_BLOCK_TIMER(3s)<br/>SyncBlock::ThreadStart()<br/>CheckBlocks::StartTimer()<br/>failedTransactionCache::_StartTimer()
        CA->>CA: CheckNtpTime()<br/>ca/ca.cpp:2679-2701
        Note over CA: 比较 NTP时间 vs 本地UTC<br/>差值 <= 1秒 -> 通过, 否则打印警告但不阻止启动
        CA->>CA: TransactionCache::Process()
        CA->>CA: ContractDispatcher::Process()
        CA->>CA: VRFConsensusNode::Process()
    and NetInit
        NetHdr->>NetHdr: TaskPool::initializeTaskPool()<br/>net/interface.h:16
        NetHdr->>NetHdr: 注册20+ Protobuf回调<br/>net/interface.h:18-42
        Note over NetHdr: RegisterNodeReq/Ack<br/>SyncNodeReq/Ack<br/>CheckTxReq/Ack<br/>GetUtxoHashReq/Ack<br/>PingReq/PongReq<br/>KeyExchangeReq/Res<br/>EchoReq/Ack...
        NetHdr->>NetHdr: registerBroadcastCallback(BuildBlockBroadcastMsg)
        NetHdr->>NetAPI: InitializeNetwork()<br/>net/api.cpp:404
        NetAPI->>NetAPI: SIGPIPE信号屏蔽<br/>net/api.cpp:407-420
        alt IP未配置
            NetAPI->>NetAPI: GetLocalHostIp() 获取内网IP
        end
        NetAPI->>NetAPI: 设置 self_id/self_identity/self_height<br/>net/api.cpp:456-458
        NetAPI->>NetAPI: 设置监听IP/端口<br/>net/api.cpp:460-463
        NetAPI->>NetAPI: WorkThreads::Start()<br/>net/api.cpp:474
        NetAPI->>NetAPI: EpollMode::EPOL_MODE_START()<br/>net/api.cpp:477
        Note over NetAPI: epoll网络事件循环启动
        NetAPI->>NetAPI: initNodeListRefreshThread()<br/>net/api.cpp:480
        Note over NetAPI: 连接种子节点(读取config.json server列表)
        NetAPI->>NetAPI: nodelistSwitchThread()<br/>net/api.cpp:483
        NetAPI->>NetAPI: g_heartTimer.AsyncLoop()<br/>net/api.cpp:486
        Note over NetAPI: 心跳定时器 (DealHeart)
    end

    %% === 阶段5: 节点注册 & ECDH密钥交换 & 区块同步 ===
    Note over PeerNode: 连接到种子节点后自动触发
    PeerNode->>PeerNode: 发送 RegisterNodeReq<br/>(含节点ID/高度/签名)
    PeerNode->>PeerNode: 接收 RegisterNodeAck
    PeerNode->>ECDH: KeyExchangeRequest 发送EC公钥
    ECDH->>ECDH: 计算共享密钥(ECDH)<br/>net/key_exchange.cpp
    ECDH->>ECDH: 推导AES密钥
    Note over ECDH: 后续通信使用AES-GCM加密

    Note over Sync: SyncBlock线程自动运行<br/>ca/sync_block.cpp:175
    Sync->>Sync: 检测 chainHeight < peer height
    alt 落后 > kStabilityTime(60s)
        Sync->>Sync: 启动同步循环
        Sync->>NetHdr: SyncNodeReq 请求区块
        Sync->>NetHdr: SyncNodeAck 接收区块
        Sync->>DBAPI: 逐块写入数据库
    end
    Note over Sync: 同步完成 -> syncThreadRunning继续监视

    %% === 阶段6: 正常运行 ===
    Main->>Main: init_check() 返回 0
    Cmdline->>Cmdline: Menu() 进入交互控制台
```

## 2. 异常启动路径: DB损坏 -> 重建 -> 从零同步

```mermaid
sequenceDiagram
    autonumber

    participant Main as main/main.cpp
    participant DB as db/rocksdb.cpp

    Main->>DB: DBInit("./data.db")
    DB->>DB: TransactionDB::Open() 失败
    Note over DB: 可能原因: SST文件损坏 / WAL损坏 / MANIFEST丢失
    DB-->>Main: initDB失败 -> InitRocksDb 返回 -1
    Main->>Main: Init() 返回 false
    Main->>Main: init_check() -> initFail = true
    Main->>Main: CleanUp()
    Main-->>Cmdline: 返回 -1 -> 进程退出
    Note over Cmdline: 【需人工验证】当前实现:<br/>DB损坏直接导致启动失败,<br/>无自动重建逻辑。<br/>用户需手动删除 data.db/ 后重启。
```

## 3. 升级路径: 版本不一致检测

```mermaid
sequenceDiagram
    autonumber

    participant Main as main/main.cpp
    participant DB as DB API

    Note over Main: 升级路径分析
    Main->>DB: InitRocksDb()
    DB->>DB: 最后 setInitVer(mm::GetVersion())
    Note over DB: 每次启动都写入当前版本号

    Note over Main: Check() 中:
    Main->>DB: 读取 DB 中创世区块 hash
    Main->>Main: 重新生成期望创世区块 hash
    alt hash 不一致
        Note over Main: 版本/配置变更导致创世区块hash变化
        Main->>Main: Check() 返回 false -> 启动失败<br/>main/main.cpp:270
        Note over Main: 【需人工验证】当前无数据库迁移逻辑<br/>仅提示"The current version data is inconsistent<br/>with the new version!"
    end
```

## 4. 初始化顺序依赖与失败回退

| 步骤 | 依赖项 | 失败时已分配资源 | 是否清理 | 清理方式 |
|------|--------|-----------------|---------|---------|
| srand | TimeUtil单例 | TimeUtil | 是 | 单例析构 |
| InitConfig | 文件系统 | Config单例, _Check后台线程 | 是 | Config析构: _exitThread=true, thread.join() |
| InitGenesis | 文件系统 | Genesis单例 | 是 | 单例析构 |
| InitLog | Config | Log单例 | 否 | **无显式清理** |
| InitAccount | 文件系统 | AccountManager单例 | 否 | **无显式清理** |
| InitRocksDb | Config,Genesis,Account | RocksDB单例, 数据库handle | 否 | **无显式清理,仅依赖析构函数** |
| Init() 失败 | -- | 全部以上资源 | 是 | initFail=true -> CleanUp() -> CaCleanup() |
| Check() 失败 | InitRocksDb | 全部 Init 资源 + CA线程 + 网络 | 是 | CleanUp() -> CaCleanup() |
| CaInit 失败 | InitRocksDb | InitRocksDb已初始化 | 否 | **CaInit && NetInit短路,CaCleanup不会被调用** |
| NetInit 失败 | CaInit | CA线程已启动, 数据库已初始化 | 否 | **同上,CaInit和NetInit同时失败才CleanUp** |

**关键风险**: `CaInit() && NetInit()` 使用了短路求值。若 CaInit 成功但 NetInit 失败，已启动的 CA 线程不会被停止，因为 CleanUp() 不在该路径被调用。`init_check()` 仅在 `Init()` 或 `Check()` 失败时才调用 `CleanUp()`。见 `main/main.cpp:282-301`。

---

**说明:**
- 所有文件路径均为项目内相对路径, 绝对前缀为 `//wsl$/wsl-mm/home/wbl/mm/`
- 【需人工验证】标注表示基于代码静态分析的推断, 实际运行时行为可能与分析有差异
