# 节点启动与数据库恢复流程 -- 函数调用栈

## 1. 入口调用栈 (entry -> cmdline -> init_check)

```
main()                                    entry.cpp:5
  |
  +-> init_signal_handlers()              entry.cpp:9, utils/init.cpp:239
  |     |
  |     +-> InitPidFile()                 utils/init.cpp:191
  |     |     +-> CreatePidFile()         utils/init.cpp:72
  |     |           +-> open()            O_WRONLY|O_CREAT|O_EXCL, 0644
  |     |           +-> WritePidIntoFd()  utils/init.cpp:49
  |     |           +-> flock()           LOCK_EX|LOCK_NB
  |     |     (重复检测: kill(existing_pid,0), 进程ID<1000判定)
  |     +-> at_quick_exit(RemovePidFile)  utils/init.cpp:246
  |     +-> sigaction() for SIGINT/SIGTERM/SIGABRT/...  utils/init.cpp:255-268
  |           handler: graceful_exit_handler()           utils/init.cpp:221
  |                     +-> tcsetattr() 恢复终端设置
  |                     +-> unlink(PID文件)
  |                     +-> SystemErrorHandler(sig)     include/logging.cpp:74
  |                     +-> _exit(128+sig)
  |
  +-> parse_cmdline_args(argc, argv)     entry.cpp:14, utils/cmdline.cpp:22
        |
        +-> cmdline::menu()              utils/cmdline.cpp:81
        |     +-> init_check()           utils/cmdline.cpp:83 -> main/main.cpp:282
        |     +-> Menu()                 main/menu.cpp:67 (交互控制台循环)
        |
        +-> cmdline::daemon()            utils/cmdline.cpp:92
              +-> init_check()           utils/cmdline.cpp:94
              +-> startDaemon()          utils/daemon.h
```

## 2. init_check() -> Init() 完整调用栈 (main/main.cpp:282-301)

```
init_check()                                     main/main.cpp:282
  |
  +-> Init()                                     main/main.cpp:34
        |
        +-> srand(TimeUtil::GetUTCTimestamp())   main/main.cpp:37
        |
        +-> InitConfig()                         main/main.cpp:41-46
        |     +-> MagicSingleton<Config>::GetInstance(flag)  common/config.h:90
        |           Config::Config(bool& flag)
        |             +-> InitFile()              common/config.cpp:45
        |             |     +-> std::filesystem::absolute(kConfigFilename)
        |             |     +-> std::ifstream(kConfigFilename)
        |             |     +-> (文件存在) _Parse(tmpJson)      common/config.cpp:104
        |             |     |     +-> 解析 ip/httpCallback/httpPort/rpc
        |             |     |     +-> 解析 enableHttps/httpsPort/sslCertPath...
        |             |     |     +-> 解析 info.name/info.logo/log.*
        |             |     |     +-> 读取 server[] 种子节点列表
        |             |     |     +-> execute_based_on_global_options()   common/config.cpp:780
        |             |     |           +-> Get_RequestIp()  公网IP获取  common/config.cpp:703
        |             |     |     +-> SetIP(_ip)             common/config.cpp:248
        |             |     +-> (文件不存在) 创建默认 config.json     common/config.cpp:77-87
        |             |     +-> _Filter()            common/config.cpp:305
        |             |     |     +-> FilterIp(_ip)
        |             |     |     +-> FILTER_SERVER_PORT(_serverPort)
        |             |     |     +-> filter_http_port(_httpPort)
        |             |     |     +-> filter_server_ip(每个种子节点)
        |             |     |     +-> FilterLog(_log)
        |             |     |     +-> handleFilterHttpCallback(_httpCallback)
        |             |     +-> _Verify()            common/config.cpp:290
        |             |           +-> Dverify(_info.name)   长度+正则校验
        |             |           +-> Dverify(_info.logo)   URL正则校验
        |             +-> _thread = std::thread(_Check)  common/config.h:87
        |                    _Check()               common/config.cpp:647-660
        |                      +-> sleep_for(3600秒) 循环
        |                      +-> GetAllServerAddress()     common/config.cpp:612
        |                            +-> 获取PeerNode中nodelist
        |                            +-> 合并sentinelNode + 已连接节点
        |                            +-> 写回 config.json
        |
        +-> InitGenesis()                            main/main.cpp:48-53
        |     +-> MagicSingleton<Genesis>::GetInstance()  common/genesis.cpp:7
        |           Genesis::Genesis()
        |             +-> TryLoadFromFile(DEFAULT_PATH)    common/genesis.cpp:267
        |             |     +-> std::ifstream(path)
        |             |     +-> json::parse
        |             |     +-> 结构校验: contains("genesis"/"network"/"type"/"name")
        |             +-> (加载失败) CreateDefaultData()   common/genesis.cpp:187
        |             |     +-> 构建 dev/test/primary 默认json
        |             |     +-> Dev: initAccountAddr=755Ccf...
        |             |     +-> Primary: initAccountAddr=De8AB...
        |             +-> Save()                     common/genesis.cpp:38
        |
        +-> InitLog()                                main/main.cpp:56-61
        |     +-> Config::GetLog(log)               common/config.cpp:477
        |     +-> Log::LogInit(path, console, level)  include/logging.cpp
        |
        +-> InitAccount()                            main/main.cpp:64-69
        |     +-> AccountManager::Initialize()        utils/account_manager.cpp:744
        |           +-> EnsureDirectoryExists(KEYSTORE_PATH)
        |           +-> _scanKeystoreDirectory()      utils/account_manager.cpp:822
        |           |     +-> opendir(KEYSTORE_PATH)
        |           |     +-> 过滤 .json 文件
        |           +-> (EMPTY_KEYSTORE) -> main.cpp:117 CreateInitialAccount()
        |           |     AccountManager::CreateInitialAccount()  account_manager.cpp:1374
        |           |       +-> _createInitialAccountImpl()      account_manager.cpp:1378
        |           |             +-> Account(true)              生成 secp256k1密钥对
        |           |             |     +-> generatePkey()       account_manager.cpp:405
        |           |             |           +-> EVP_PKEY_CTX_new_id(EVP_PKEY_EC)
        |           |             |           +-> EVP_PKEY_CTX_set_ec_paramgen_curve_nid(NID_secp256k1)
        |           |             |           +-> EVP_PKEY_keygen()
        |           |             |           +-> generatePublicString()
        |           |             |           +-> generatePrivateString()
        |           |             |           +-> _GenerateAddr() = keccak256(pubKey) 后40位
        |           |             +-> AddAccount(account)
        |           |             +-> SetDefaultAccount(address)
        |           |             +-> GetPasswordFromUser()     交互式输入密码
        |           |             +-> SavePrivateKeyToKeystoreFile()
        |           |                   +-> KeystoreManager::EncryptPrivateKey()
        |           |                   +-> ofstream 写入 .json 文件
        |           +-> (有其他文件) loadExistingAccounts()     account_manager.cpp:863
        |                 +-> Dev模式: 批量密码解锁
        |                 |     +-> load_account_from_key_store()
        |                 |     |     +-> KeystoreManager::DecryptPrivateKey()
        |                 |     |     +-> HexPrivateKeyToPkey()
        |                 |     |     +-> GenerateAddr()
        |                 |     |     +-> AddAccount()
        |                 +-> 非Dev模式: 逐个密码解锁 (最多3次重试)
        |                 +-> UnlockAccountsBatchMode() (大账户量>10)
        |                       +-> TaskPool::commitWorkTask() 多线程解锁
        |           +-> 设置 _defaultAddress = initAccountAddr(优先) 或首个
        |           +-> 一致性检查: keystore文件 vs _accountList
        |
        +-> InitRocksDb()                            main/main.cpp:157-235
              +-> DBInit("./data.db")                main/main.cpp:159 -> db/db_api.cpp:83
              |     +-> RocksDB::setDBPath("./data.db")  db/rocksdb.cpp:35
              |     +-> RocksDB::initDB(retStatus)       db/rocksdb.cpp:40
              |           +-> rocksdb::Options::create_if_missing = true
              |           +-> options.IncreaseParallelism()
              |           +-> options.OptimizeLevelStyleCompaction()
              |           +-> 注册 BackgroundErrorListener   db/rocksdb.cpp:7-19
              |           |     OnBackgroundError() -> exit(-1)
              |           +-> rocksdb::TransactionDB::Open() db/rocksdb.cpp:54
              |
              +-> DBReadWriter::getBlockTop(top)      main/main.cpp:164-166
              |     (DBReader继承自RocksDB单例)
              |
              +-> (top获取失败 = 首次启动) 生成创世区块
              |     +-> GenesisBlock::GenerateGenesisBlock(block)  utils/genesis_block.cpp:14
              |     |     +-> block.set_time(GenesisTime)            from genesis.json
              |     |     +-> block.set_version(kCurrentBlockVersion)
              |     |     +-> block.set_prevhash(0000...64零)
              |     |     +-> block.set_height(0)
              |     |     +-> CreateGenesisTransaction(tx)           genesis_block.cpp:59
              |     |     |     +-> tx.set_version(CURRENT_TRANSACTION_VERSION)
              |     |     |     +-> tx.set_time(genesisTime)
              |     |     |     +-> tx.set_n(0)
              |     |     |     +-> tx.set_identity(initAccountAddr)
              |     |     |     +-> tx.set_type(GENESIS)
              |     |     |     +-> 循环: MM(0) + Vote(0) UTXO
              |     |     |     |     populateUtxoData()             genesis_block.cpp:112
              |     |     |     |       +-> utxo->set_assettype()
              |     |     |     |       +-> utxo->add_owner(addr)
              |     |     |     |       +-> vin->add_prevout() (hash=0000, n=0)
              |     |     |     |       +-> vout->set_value(balance * kDecimalNum)
              |     |     |     |       +-> vout->set_addr(addr)
              |     |     |     +-> tx.set_hash(Getsha256Hash(tx.SerializeAsString()))
              |     |     +-> block.set_data(json(name, type))
              |     |     +-> block.set_merkleroot(calculateBlockMerkle(block))
              |     |     +-> block.set_hash(Getsha256Hash(block.SerializeAsString()))
              |     |
              |     +-> dbReadWriter.setBlockHeightByBlockHash()   main/main.cpp:195
              |     +-> dbReadWriter.setBlockHashByBlockHeight()   main/main.cpp:196
              |     +-> dbReadWriter.setBlockByBlockHash()         main/main.cpp:197
              |     +-> dbReadWriter.setBlockTop(0)                main/main.cpp:198
              |     +-> UTXO遍历写入:                              main/main.cpp:200-222
              |     |     +-> setUtxoHashesByAddr(addr, assetType, txHash)
              |     |     +-> setUtxoValueByUtxoHashes(txHash, addr, assetType, value)
              |     |     +-> setBalanceByAddr(addr, assetType, value)
              |     +-> dbReadWriter.setTransactionByHash()        main/main.cpp:224
              |     +-> dbReadWriter.setBlockHashByTransactionHash()  main/main.cpp:225
              |
              +-> dbReadWriter.setInitVer(mm::GetVersion())        main/main.cpp:227
              +-> dbReadWriter.transactionCommit()                 main/main.cpp:228
              |     (失败返回 -8)
```

## 3. Check() 创世区块校验调用栈 (main/main.cpp:238-274)

```
Check()                                               main/main.cpp:238
  |
  +-> DBReader::getBlockHashByBlockHeight(0)          main/main.cpp:244
  |     (获取 DB 中高度0的区块hash)
  |
  +-> DBReader::getBlockByBlockHash(hash)             main/main.cpp:250
  |     (获取 DB 中创世区块原始数据)
  |
  +-> dbBlock.ParseFromString(blockRaw)               main/main.cpp:257
  |
  +-> GenesisBlock::GenerateGenesisBlock(expectedBlock)  main/main.cpp:261
  |     (重新生成期望的创世区块, 同InitRocksDb中的逻辑)
  |
  +-> expectedBlock.hash() 对比 dbHash                main/main.cpp:267
        |
        +-> (不一致) 输出警告, 返回 false               main/main.cpp:269-270
        +-> (一致) 返回 true                           main/main.cpp:273
```

## 4. CaInit() 调用栈 (ca/ca.cpp:98-127)

```
CaInit()                                              ca/ca.cpp:98
  |
  +-> RegisterInterface()                             ca/ca.cpp:100 -> ca/interface.cpp:1792
  |     +-> registerCallback<GetBlockReq>             ca/interface.cpp:1794
  |     +-> registerCallback<GetBalanceReq>           ca/interface.cpp:1795
  |     +-> registerCallback<GetNodeInfoReq>          ca/interface.cpp:1796
  |     +-> registerCallback<GetStakeListReq>         ca/interface.cpp:1797
  |     +-> registerCallback<GetDelegateListReq>      ca/interface.cpp:1798
  |     +-> registerCallback<GetUtxoReq>              ca/interface.cpp:1799
  |     +-> registerCallback<GetAllDelegateAddressReq> ca/interface.cpp:1800
  |     +-> registerCallback<GetAllStakeNodeListReq>  ca/interface.cpp:1801
  |     +-> registerCallback<GetSignCountListReq>     ca/interface.cpp:1802
  |     +-> registerCallback<GetHeightReq>            ca/interface.cpp:1803
  |     +-> registerCallback<GetBonusListReq>         ca/interface.cpp:1804
  |     +-> registerCallback<GetSDKReq>               ca/interface.cpp:1805
  |     +-> registerCallback<ConfirmTransactionReq>   ca/interface.cpp:1806
  |     +-> registerCallback<CheckVinReq>             ca/interface.cpp:1807
  |     +-> registerCallback<CheckVinAck>             ca/interface.cpp:1808
  |     +-> registerCallback<GetRestDelegateAmountReq> ca/interface.cpp:1809
  |     +-> registerCallback<BlockStatus>             ca/interface.cpp:1810
  |     +-> registerCallback<CheckContractPreHashReq> ca/interface.cpp:1812
  |
  +-> RegisterCallback()                             ca/ca.cpp:103
  |     +-> net_register_callback()                   ca/ca.cpp:2516
  |
  +-> [条件: Config::GetRpc() == true]
  |     subscribeToHttpCallbacks()                    ca/ca.cpp:109
  |
  +-> StartTimerTask()                                ca/ca.cpp:113
  |     +-> BLOCK_POOL_TIMER_INTERVAL.AsyncLoop(100ms)    ca/ca.cpp:75
  |     |     BlockHelper::Process()
  |     +-> SEEK_BLOCK_TIMER.AsyncLoop(3000ms)            ca/ca.cpp:78
  |     |     BlockHelper::SeekBlockThreadObject()
  |     +-> BlockHelper::SeekBlockThreadObject()    (立即)  ca/ca.cpp:81
  |     +-> SyncBlock::ThreadStart()                      ca/ca.cpp:84
  |     |     (创建 _syncThread 后台线程)
  |     +-> CheckBlocks::StartTimer()                     ca/ca.cpp:85
  |     +-> failedTransactionCache::_StartTimer()          ca/ca.cpp:87
  |     +-> BlockStorage 单例创建                          ca/ca.cpp:91
  |     +-> doubleSpendCache 单例创建                      ca/ca.cpp:93
  |
  +-> CheckNtpTime()                                ca/ca.cpp:116
  |     +-> TimeUtil::GetNtpTimestamp()              ca/ca.cpp:2682
  |     |     (随机选择阿里云/腾讯云NTP服务器, 最多重试3次)
  |     +-> TimeUtil::GetUTCTimestamp()              ca/ca.cpp:2683
  |     +-> abs(NTP - UTC) 与 1000000us(1秒) 比较    ca/ca.cpp:2690
  |     |     差值<=1s: 返回 0  (打印成功但不阻止)
  |     |     差值>1s:  返回 -1 (打印警告但不阻止)
  |
  +-> TransactionCache::Process()                    ca/ca.cpp:118
  +-> ContractDispatcher::Process()                  ca/ca.cpp:120
  +-> VRFConsensusNode::Process()                    ca/ca.cpp:122
  +-> std::filesystem::create_directory(CONTRACT_PATH) ca/ca.cpp:124
```

## 5. NetInit() 调用栈 (net/interface.h:13-46)

```
NetInit()                                            net/interface.h:13
  |
  +-> TaskPool::initializeTaskPool()                 net/interface.h:16
  |
  +-> ProtobufDispatcher::NetRegisterCallback<t>()   net/interface.h:18-42
  |     +-> RegisterNodeReq     -> handleRegisterNodeRequest()
  |     +-> RegisterNodeAck     -> handleRegisterNodeAcknowledgment()
  |     +-> SyncNodeReq         -> handleSyncNodeRequest()
  |     +-> SyncNodeAck         -> handleSyncNodeAcknowledgment()
  |     +-> CheckTxReq          -> handleCheckTransactionRequest()
  |     +-> CheckTxAck          -> handleCheckTransactionAck()
  |     +-> GetUtxoHashReq      -> handleGetTxUtxoHashRequest()
  |     +-> GetUtxoHashAck      -> handleGetTxUtxoHashAcknowledgment()
  |     +-> PrintMsgReq         -> processPrintMessageRequest()
  |     +-> PingReq             -> HandlePingReq()
  |     +-> PongReq             -> handle_pong_request()
  |     +-> EchoReq             -> HandleEchoReq()
  |     +-> EchoAck             -> handleEchoAcknowledge()
  |     +-> TestNetAck          -> networkTestAcknowledge()
  |     +-> TestNetReq          -> networkTestRequest()
  |     +-> NodeHeightChangedReq-> processNodeHeightChangeRequest()
  |     +-> NodeAddrChangedReq  -> handleNodeAddressChangeRequest()
  |     +-> KeyExchangeRequest  -> handleKeyExchangeRequest()
  |     +-> KeyExchangeResponse -> handleKeyExchangeAcknowledgment()
  |
  +-> registerBroadcastCallback<BuildBlockBroadcastMsg>(HandleBroadcastMsg)  net/interface.h:42
  |
  +-> net_com::InitializeNetwork()                   net/interface.h:44 -> net/api.cpp:404
        +-> SIGPIPE信号屏蔽                          net/api.cpp:407-420
        +-> (IP为空) IpPort::GetLocalHostIp()         net/api.cpp:422-431
        +-> Config::SetIP(localhost_ip)               net/api.cpp:430
        +-> 校验IP非局域网 (IsLan检查)                net/api.cpp:442-446
        +-> GetDefaultAccount(acc)                    net/api.cpp:451
        +-> PeerNode::SetSelfId(acc.GetAddr())         net/api.cpp:456
        +-> PeerNode::SetSelfIdentity(acc.GetPubStr()) net/api.cpp:457
        +-> PeerNode::SetSelfHeight()                  net/api.cpp:458
        +-> 配置监听: IpNum / Port / PublicIP / PublicPort  net/api.cpp:460-463
        +-> PeerNode::SetSelfName / set_user_logo     net/api.cpp:468-469
        +-> PeerNode::SetSelfVer(mm::GetVersion())     net/api.cpp:471
        +-> WorkThreads::Start()                      net/api.cpp:474
        +-> EpollMode::EPOL_MODE_START()              net/api.cpp:477
        |     (epoll 事件循环线程启动)
        +-> PeerNode::initNodeListRefreshThread()     net/api.cpp:480
        |     (连接 config.json 中 server 列表种子节点)
        +-> PeerNode::nodelistSwitchThread()          net/api.cpp:483
        |     (节点列表交换线程)
        +-> g_heartTimer.AsyncLoop()                  net/api.cpp:486
              (心跳定时器 -> net_com::DealHeart)
```

## 6. CleanUp() 调用栈 (main/main.cpp:276-280 / ca/ca.cpp:137-171)

```
CleanUp()                                            main/main.cpp:276
  |
  +-> CaCleanup()                                    ca/ca.cpp:137
        +-> CaEndTimerTaskV2()                       ca/ca.cpp:140
        |     +-> DATABASE_TIMER.Cancel()            ca/ca.cpp:131
        |     +-> BLOCK_POOL_TIMER_INTERVAL.Cancel() ca/ca.cpp:132
        |     +-> SEEK_BLOCK_TIMER.Cancel()          ca/ca.cpp:133
        |
        +-> g_heartTimer.Cancel()                    ca/ca.cpp:142
        +-> failedTransactionCache::StopTimer()      ca/ca.cpp:144
        +-> BlockHelper::stopSaveBlock()             ca/ca.cpp:146
        +-> Benchmark::Clear()                       ca/ca.cpp:148
        +-> TransactionCache::Stop()                 ca/ca.cpp:150
        +-> SyncBlock::ThreadStop()                  ca/ca.cpp:152
        |     (syncThreadRunning = false)
        +-> BlockStorage::StopTimer()                ca/ca.cpp:154
        +-> doubleSpendCache::StopTimer()            ca/ca.cpp:156
        +-> EpollMode::EpollStop()                   ca/ca.cpp:158
        |     (停止网络事件循环)
        +-> BlockHttpCallbackHandler::Stop()         ca/ca.cpp:160
        +-> PeerNode::stopNodesSwap()                ca/ca.cpp:162
        +-> CheckBlocks::StopTimer()                 ca/ca.cpp:164
        +-> VRF::StopTimer()                         ca/ca.cpp:166
        +-> sleep(5)                                 ca/ca.cpp:169
              (等待5秒让所有线程安全退出)
```

---

**说明:**
- `main/main.cpp:228` transactionCommit 失败返回 -8. 分析发现 -5,-6,-7 未在代码中使用.【需人工验证】
- `ca/ca.cpp:116` CheckNtpTime 返回值在 CaInit 中被忽略, 即使NTP校验失败也不阻止启动.
- `main/main.cpp:79` `CaInit() && NetInit()` 短路求值可能导致部分资源未清理.
