# 节点启动与数据库恢复流程 -- 状态转换

## 1. 节点全局状态机

```mermaid
stateDiagram-v2
    [*] --> 进程启动 : main() entry.cpp:5

    进程启动 --> 信号处理初始化 : init_signal_handlers() entry.cpp:9

    信号处理初始化 --> 命令行解析 : SIGINT/SIGTERM等注册完成 utils/init.cpp:239
    信号处理初始化 --> 启动失败 : PID文件冲突 (已有进程)

    命令行解析 --> 启动中 : cmdline::menu/daemon utils/cmdline.cpp:83

    启动中 --> 启动失败 : Init() 返回 false main/main.cpp:285
    启动中 --> 一致性校验失败 : Check() 返回 false main/main.cpp:291
    启动中 --> 正在运行 : init_check() 返回 0 main/main.cpp:300

    一致性校验失败 --> 关闭中 : CleanUp() main/main.cpp:297
    启动失败 --> 关闭中 : CleanUp() main/main.cpp:297

    正在运行 --> 收到信号 : SIGINT/SIGTERM/SIGABRT utils/init.cpp:221
    收到信号 --> 已停止 : graceful_exit_handler -> _exit(128+sig) utils/init.cpp:235

    关闭中 --> 已停止 : 正常退出 / CaCleanup() 完成

    state 启动中 {
        [*] --> 初始化随机数种子 : srand() main.cpp:37
        初始化随机数种子 --> 加载配置文件 : InitConfig() main.cpp:41
        加载配置文件 --> 加载创世配置 : InitGenesis() main.cpp:48
        加载创世配置 --> 初始化日志 : InitLog() main.cpp:56
        初始化日志 --> 初始化账户 : InitAccount() main.cpp:64
        初始化账户 --> 初始化数据库 : InitRocksDb() main.cpp:72
        初始化数据库 --> CA初始化 : CaInit() main.cpp:79
        CA初始化 --> 网络初始化 : NetInit() main.cpp:79
    }

    state 关闭中 {
        [*] --> 停止定时器 : CaEndTimerTaskV2() ca.cpp:140
        停止定时器 --> 停止缓存 : TransactionCache/BlockStorage/双花缓存
        停止缓存 --> 停止同步 : SyncBlock::ThreadStop() ca.cpp:152
        停止同步 --> 停止网络 : EpollMode::EpollStop() ca.cpp:158
        停止网络 --> 等待退出 : sleep(5) ca.cpp:169
    }
```

## 2. 数据库状态机

```mermaid
stateDiagram-v2
    [*] --> 数据库不存在 : 首次启动

    数据库不存在 --> 打开数据库 : DBInit("./data.db")<br/>db/rocksdb.cpp:83
    打开数据库 --> 数据库已创建 : rocksdb::TransactionDB::Open()<br/>create_if_missing=true<br/>db/rocksdb.cpp:54

    数据库已创建 --> 读取区块顶 : getBlockTop(top)<br/>main/main.cpp:164
    读取区块顶 --> 无创世区块 : getBlockTop 返回非 SUCCESS

    无创世区块 --> 生成创世区块 : GenesisBlock::GenerateGenesisBlock()<br/>utils/genesis_block.cpp:14

    生成创世区块 --> 写入创世数据 : 写入 blockHash/height/utxos/balances<br/>main/main.cpp:195-225

    写入创世数据 --> 写入版本号 : setInitVer(mm::GetVersion())<br/>main/main.cpp:227

    写入版本号 --> 提交事务 : transactionCommit()<br/>main/main.cpp:228

    提交事务 --> 数据库就绪 : 数据库完全就绪

    数据库就绪 --> [*]

    %% 恢复启动路径
    数据库已存在 --> 打开数据库 : DBInit()<br/>(已有 data.db/)

    打开数据库 --> 读取区块顶_恢复 : getBlockTop(top) 成功

    读取区块顶_恢复 --> 写入版本号_恢复 : setInitVer(mm::GetVersion())

    写入版本号_恢复 --> 提交事务_恢复 : transactionCommit()

    提交事务_恢复 --> 数据库就绪 : 跳过创世生成

    %% 数据库损坏
    数据库已存在 --> 启动失败 : initDB() 返回失败<br/>db/rocksdb.cpp:61

    启动失败 --> [*] : 进程退出<br/>【需人工验证】无自动修复

    %% Check() 校验
    数据库就绪 --> 读取DB创世块 : getBlockHashByBlockHeight(0)<br/>main/main.cpp:244

    读取DB创世块 --> 重新生成创世块 : GenesisBlock::GenerateGenesisBlock()<br/>main/main.cpp:261

    重新生成创世块 --> 哈希一致 : hash 匹配

    哈希一致 --> 校验通过 : Check() 返回 true

    重新生成创世块 --> 哈希不一致 : hash 不匹配<br/>main/main.cpp:267-270

    哈希不一致 --> 启动失败 : Check() 返回 false<br/>CleanUp() -> 退出
```

## 3. 账户状态机

```mermaid
stateDiagram-v2
    [*] --> 未初始化 : 进程启动

    未初始化 --> 扫描密钥库 : AccountManager::Initialize()<br/>utils/account_manager.cpp:744

    扫描密钥库 --> 空密钥库 : _scanKeystoreDirectory()<br/>返回 keystoreFiles.empty() == true<br/>account_manager.cpp:762

    扫描密钥库 --> 有密钥文件 : keystoreFiles 非空

    空密钥库 --> 创建新账户 : main.cpp:117<br/>AccountManager::CreateInitialAccount()

    创建新账户 --> 生成密钥对 : Account(true)<br/>secp256k1 ECDSA<br/>account_manager.cpp:405

    生成密钥对 --> 用户设密码 : GetPasswordFromUser()<br/>account_manager.cpp:1397

    用户设密码 --> 保存密钥文件 : SavePrivateKeyToKeystoreFile()<br/>account_manager.cpp:1428

    保存密钥文件 --> 账户已就绪 : SetDefaultAccount(address)

    有密钥文件 --> 交互式解锁 : loadExistingAccounts()<br/>account_manager.cpp:863

    state 交互式解锁 {
        [*] --> Dev模式判断 : Genesis::GetNetworkType()<br/>account_manager.cpp:883

        Dev模式判断 --> 单密码批量解锁 : Dev模式 + 用户选择
        Dev模式判断 --> 逐个密码解锁 : 非Dev或用户拒绝共享密码

        单密码批量解锁 --> 密码验证 : load_account_from_key_store()<br/>最多3次重试

        逐个密码解锁 --> 逐个密码验证 : 每个文件最多3次重试<br/>account_manager.cpp:1186

        密码验证 --> 解析私钥 : HexPrivateKeyToPkey()<br/>keccak256生成地址
        解析私钥 --> 添加到列表 : AddAccount(account)

        逐个密码验证 --> 解析私钥_individual
        解析私钥_individual --> 添加到列表_individual : AddAccount(account)
    }

    交互式解锁 --> 设置默认账户 : 默认=initAccountAddr 或 首个

    设置默认账户 --> 一致性检查 : keystore文件 vs _accountList<br/>account_manager.cpp:796-809

    一致性检查 --> 账户已就绪 : 一致<br/>或 FATAL_ERROR (不一致)

    账户已就绪 --> [*]
```

## 4. 网络状态机

```mermaid
stateDiagram-v2
    [*] --> 离线 : 进程启动

    离线 --> 初始化任务池 : TaskPool::initializeTaskPool()<br/>net/interface.h:16

    初始化任务池 --> 注册协议回调 : 20+ Protobuf回调注册<br/>net/interface.h:18-42

    注册协议回调 --> 网络层初始化 : InitializeNetwork()<br/>net/api.cpp:404

    网络层初始化 --> 获取IP地址 : Config::GetIP() or GetLocalHostIp()<br/>net/api.cpp:422-431

    获取IP地址 --> IP校验失败 : IsLan(IP) 为 true<br/>net/api.cpp:442-446

    IP校验失败 --> 离线 : 【需人工验证】返回 false<br/>NetInit() 失败

    获取IP地址 --> 配置节点身份 : SetSelfId/SetSelfIdentity/SetSelfHeight<br/>net/api.cpp:456-458

    配置节点身份 --> 配置监听端口 : set_self_ip_listen + configureSelfPort<br/>net/api.cpp:460-463

    配置监听端口 --> 启动工作线程池 : WorkThreads::Start()<br/>net/api.cpp:474

    启动工作线程池 --> 监听端口 : EpollMode::EPOL_MODE_START()<br/>net/api.cpp:477

    监听端口 --> 连接种子节点 : initNodeListRefreshThread()<br/>net/api.cpp:480

    连接种子节点 --> ECDH握手 : KeyExchangeRequest/Response<br/>net/key_exchange.cpp:276-286

    ECDH握手 --> 已注册 : 与种子节点完成密钥交换

    已注册 --> 同步节点列表 : nodelistSwitchThread()<br/>net/api.cpp:483

    同步节点列表 --> 已连接 : 心跳启动<br/>g_heartTimer.AsyncLoop()<br/>net/api.cpp:486

    state ECDH握手 {
        [*] --> 生成EC密钥对 : 本地生成 secp256k1 密钥对
        生成EC密钥对 --> 发送公钥 : KeyExchangeRequest<br/>(ec_pub_key_65bytes + salt_32bytes)
        发送公钥 --> 接收对方公钥 : KeyExchangeResponse
        接收对方公钥 --> 计算共享密钥 : ECDH: 本地私钥 x 对方公钥
        计算共享密钥 --> 派生AES密钥 : AES-GCM 加密密钥
        派生AES密钥 --> 验证Token : HMAC-SHA256 Token验证
        验证Token --> [*] : 握手完成
    }

    已连接 --> 区块同步 : SyncBlock线程检测高度落后
    区块同步 --> 区块同步 : 循环 请求/接收/写入 区块

    已连接 --> 离线 : EpollMode::EpollStop()<br/>ca/ca.cpp:158 CleanUp时调用
```

## 5. 配置热加载后台线程状态

```mermaid
stateDiagram-v2
    [*] --> 运行中 : Config 构造函数启动 _Check 线程<br/>common/config.h:87

    运行中 --> 等待中 : sleep 3600秒<br/>common/config.cpp:651-653

    等待中 --> 刷新节点列表 : GetAllServerAddress()<br/>common/config.cpp:656

    刷新节点列表 --> 等待中 : 循环直到 _exitThread=true

    等待中 --> 已停止 : _exitThread=true<br/>Config 析构: join()
```

---

**说明:**
- 所有源码行号引用基于项目路径 `//wsl$/wsl-mm/home/wbl/mm/`
- 状态转换中"数据库已存在"路径意味着该路径下已有 `data.db/` 目录及其 RocksDB 数据文件
- CheckNtpTime 在 ca/ca.cpp:2679-2701 中定义了返回 -1 的失败路径, 但 CaInit() 在 ca/ca.cpp:116 调用后不检查其返回值, 所以 NTP 失败不会影响节点启动
