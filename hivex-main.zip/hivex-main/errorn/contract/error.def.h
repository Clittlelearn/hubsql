#pragma once
#define CONTRACT_ERROR\
     EXP_ERROR(NOT_FOUND_ACCOUNT,"not found account")\
     EXP_ERROR(INVALID_EVM_BTYEPCODE,"invalid byte code")\
     EXP_ERROR(EVM_PREVRANDA_FAIL,"prevranda fail")\
     EXP_ERROR(EVM_UNKONW_BAD_ERROR,"EVM_UNKONW_BAD_ERROR")\
     EXP_ERROR(EVM_BLOCK_NUM_ERROR,"block num error")\
     EXP_ERROR(EVM_DEPLOY_FAIL,"call deploy fail")\
     EXP_ERROR(EVM_CALL_FAIL,"call deploy fail")\
     EXP_ERROR(EVM_MAKE_TRNAS_FAIL,"make evm trans fail")\
     EXP_ERROR(EVM_ASSERT_MAP_ERROR,"assert map error")\
     EXP_ERROR(EVM_INVALID_CONTRACT_TYPE,"invalid contract tyep")\
     EXP_ERROR(EVM_FAIL_ADD_CONTRACT_CACHE,"fail add contract cache")\
     EXP_ERROR(EVM_ADD_IN_CONTRACT_DEPENDENC," add  in contract dependece")\
     EXP_ERROR(EVM_ADDR_GEN_FAIL,"addr gen fail")\
     EXP_ERROR(PENDING_UTXO_WAIT,"confirmed balance is temporarily reserved by pending transactions")\
