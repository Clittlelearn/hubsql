#pragma once
#define RPC_PARSE_ERROR \
    EXP_ERROR(PARSE_JSON_FAIL, "parse json fail") \
    EXP_ERROR(MISSING_JSON_FIELD, "Missing field") \
    EXP_ERROR(FIELD_TYPE_ERROR, "field type error") \
    EXP_ERROR(EMPTY_JSON, "empty json") \
    EXP_ERROR(FIELD_EMPTY, "field empty") \
    EXP_ERROR(API_VERSION_ERROR, "api version should be 2.0") \
    EXP_ERROR(NOT_FOUND_PARAM, "not found param") \
    EXP_ERROR(NOT_FOUND_METHOD, "not found method") \
    EXP_ERROR(LOGIC_NOT_DEF, "LOGIC_NOT_DEF") \
    EXP_ERROR(SERIALIZE_FAIL, "serializer fail") \
    EXP_ERROR(TX_CONFIRMATION_FAIL, "Confirmation Transaction fail")\
    