#pragma once
#define GLOBAL_ERROR \
     EXP_ERROR(INVALID_ADDR, "invalid addr") \
     EXP_ERROR(INVALID_ASSET_TYPE, "invalid asset type") \
     EXP_ERROR(INVALID_HASH, "invalid hash") \
     EXP_ERROR(GET_TIME_FAIL, "get time fail") \
     EXP_ERROR(INVALID_VALUE, "invalid amount") \
     EXP_ERROR(INFO_IS_TOO_BIG, "info is too big")\
     EXP_ERROR(INVALID_AMOUNT, "invalid amount")\

