#pragma once

#define CA_ERRORS \
    EXP_ERROR(THE_PUMPING_RATIO_IS_WRONG, "the pumping ratio is wrong") \
    EXP_ERROR(ASSET_NOT_EXIST, "Asset type does not exist") \
    EXP_ERROR(PROPOSAL_NOT_EXIST, "Proposal does not exist") \
    EXP_ERROR(INSUFFICIENT_ASSET_TYPE, "Insufficient asset types") \
    EXP_ERROR(NOT_FIND_UTXO_BY_HASH, "not found utxo by hash") \
    EXP_ERROR(FAILED_TO_GET_BALANCE, "get balance failed") \
    EXP_ERROR(FAILED_TO_GET_BLOCK, "get block failed") \
    EXP_ERROR(FAILED_TO_GET_BLOCK_HASH, "get block hash failed") \
    EXP_ERROR(BALANCE_IS_INSUFFICIENT, "The balance is insufficient") \
    EXP_ERROR(ACCOUNT_HAS_STAKED, "account has staked") \
    EXP_ERROR(GET_TRANSACTION_FAILED, "Get transaction failed") \
    EXP_ERROR(THE_STAKE_AMOUNT_IS_INSUFFICIENT, "The stake amount is insufficient") \
    EXP_ERROR(SIGN_VIN_FAIL, "sign vin fail") \
    EXP_ERROR(SIGN_UTXO_FAIL, "sign utxo fail") \
    EXP_ERROR(GET_SIGN_COUNT_FAIL, "get sign count fail") \
    EXP_ERROR(GAS_IS_ZERO, "gas is zero") \
    EXP_ERROR(GET_GAS_VALUE_FAIL, "Get gas value failed") \
    EXP_ERROR(GEN_GAS_UTXO_FAIL, "gen gas utxo fail") \
    EXP_ERROR(FAILED_TO_PICK_A_PACKAGER, "Failed to pick a packager") \
    EXP_ERROR(FAILED_TO_GET_NONCE, "Failed to get nonce") \
    EXP_ERROR(FAILED_TO_GET_HEIGHT, "Failed to get height") \
    EXP_ERROR(FAILED_TO_GET_UTXO_HEIGHT, "failed to get utxo height") \
    EXP_ERROR(FIND_UTXO_FAIL, "Find utxo fail") \
    EXP_ERROR(NOT_A_VALID_CONTRACT, "Not a valid contract") \
    EXP_ERROR(GET_TOP_FAIL, "get top fail") \
    EXP_ERROR(PRE_RANDAO, "pre randao fail") \
    EXP_ERROR(CREATE_CONTRACT_ADDR_FAIL, "create contract addr fail") \
    EXP_ERROR(GET_CHAIN_ID_FAIL, "get chain id fail") \
    EXP_ERROR(CONTRACT_NONCE_FAIL, "contract nonce fail") \
    EXP_ERROR(CREATE_EVMONE_FAIL, "create evmone fail") \
    EXP_ERROR(EVM_TIMEOUT, "evm timeout") \
    EXP_ERROR(EVMONE_EXEC_FAIL, "evmone exec fail") \
    EXP_ERROR(GEN_VIN_FAIL, "gen vin fail") \
    EXP_ERROR(GAS_ASSET_TYPE_NOT_MATCH, "gas asset type not match") \
    EXP_ERROR(CHECK_ADDR_ASSET_TYPE_HEIGHT_FAIL, "check addr asset type height fail") \
    EXP_ERROR(TO_ADDR_EMPTY, "to addr empty") \
    EXP_ERROR(NOT_QUALIFIED_FOR_UNDELEGATION, "FromAddr is not qualified to undelegating!") \
    EXP_ERROR(DELEGATING_AMOUNT_EXCEED_THE_LIMIT, "Delegating amount exceeds the limit!") \
    EXP_ERROR(UNKNOWN_DELEGATE_TYPE, "Unknown delegate type!") \
    EXP_ERROR(GET_DELEGATING_ADDRESS_FAILED, "Get delegating addresses asset type failed!") \
    EXP_ERROR(NOT_QUALIFIED_FOR_BONUS, "Not allowed to bonus!") \
    EXP_ERROR(FIRST_BONUS_ERROR, "First choose params error!") \
    EXP_ERROR(NOT_QUALIFIED_TO_UNSTAKE, "not qualified to unstake") \
    EXP_ERROR(NOT_QUALIFIED_TO_UNLOCK, "not qualified to unlock") \
    EXP_ERROR(GET_LOCK_ADDRESS_FAILED, "Get lock address failed") \
    EXP_ERROR(UNKNOWN_LOCK_TYPE, "Unknown lock type") \
    EXP_ERROR(GET_CLAIMED_AMOUNT_BY_THE_DELEGATOR, "Obtain the amount claimed by the delegator") \
    EXP_ERROR(GET_UNAVAILABLE_ASSET, "Get available asset fail") \
    EXP_ERROR(ASSET_TYPE_IS_TOO_MUCH, "Asset type is too much") \
    EXP_ERROR(GET_GAS_AMOUNT_BY_TIME_TYPE_FAILED, "Get gas amount by time type") \
    EXP_ERROR(NO_FUND_REWARD_THE_DAY_BEFORE, "There was no fund reward the day before!") \
    EXP_ERROR(HAVE_CLAIMED_THE_FUND_REWARD, "Have already claimed the fund reward!") \
    EXP_ERROR(CHECK_INELIGIBILITY_FOR_RECEIVING_FUND, "Checking eligibility for receiving fund") \
    EXP_ERROR(VOTE_INFO_CHECK_FAIL, "vote info check fail") \
    EXP_ERROR(LESS_THAN_MIN_LOCK_AMOUNT, "less than min lock amount") \
    EXP_ERROR(CHECK_GAS_ASSET_FAILED, "check gas asset isn't qualified") \
    EXP_ERROR(DOUBLE_SPEED, "double speed") \
    EXP_ERROR(GET_TX_UTXO_FAIL, "get tx utxo fail") \
    EXP_ERROR(GET_APPROVE_ADDRESS_FAILED, "get approve address failed") \
    EXP_ERROR(GET_AGAINST_ADDRESS_FAILED, "get against address failed") \
    EXP_ERROR(GET_VOTE_HASH_FAILED, "get vote hash failed") \
    EXP_ERROR(PROTO_PARSE_FAIL, "proto parse fail") \
    EXP_ERROR(GET_ADDR_ERROR, "get address error") \
    EXP_ERROR(TX_TYPE_ERROR, "Transaction type is wrong") \
    EXP_ERROR(GET_DEPLOYER_ERROR, "Get deployer error") \
    EXP_ERROR(GET_CONTRACT_ADDRESS_ERROR, "Get contract address error") \
    EXP_ERROR(FAILED_TO_GET_STAKING_RATE, "Failed to get staking rate") \
    EXP_ERROR(FAILED_TO_GET_ANNUALIZED_RATE, "Failed to get annualized rate") \
    EXP_ERROR(FAILED_TO_GET_ASSET_TYPE, "Failed to get asset type")
  

