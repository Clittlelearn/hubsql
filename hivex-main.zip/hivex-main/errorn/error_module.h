#pragma once
#include "utils/uerror/ecode.h"
#include "errorn/ca/error.def.h"
#include "errorn/contract/error.def.h"
#include "errorn/global/error.def.h"
#include "errorn/rpc/error.def.h"
enum ERROR_MOUDLE {
    CA,
    RPC_API,
    NET,
    CONTRACT,
    MEMALL
};


#define EXP_ERROR(a,b) b,
   ERROR_MESSAGE_MACRO_DF(MEM,GLOBAL_ERROR RPC_PARSE_ERROR CONTRACT_ERROR CA_ERRORS);
#undef EXP_ERROR

#define EXP_ERROR(a,b) a,
    ERROR_ENUM_MACRO_DF(MEM,ERROR_MOUDLE,MEMALL,GLOBAL_ERROR RPC_PARSE_ERROR CONTRACT_ERROR CA_ERRORS);
#undef EXP_ERROR


ERROR_SERIALIZER_MACRO_DF(MEM)