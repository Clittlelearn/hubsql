#[[
  CMake module for building cpp-libp2p as a dependency of OpenHive
  
  cpp-libp2p (Quadrivium/libp2p) is a C++20 implementation of the libp2p
  networking stack. This module handles:
  1. Configuring cpp-libp2p as a sub-build
  2. Building it using its own CMake (Hunter or vcpkg)
  3. Exporting the library targets for linking
  
  Usage:
    include(BuildLibp2p)
    target_link_libraries(${PROJECT_NAME} PRIVATE libp2p::libp2p)
#]]

# ============================================================================
# Configuration
# ============================================================================

set(LIBP2P_SOURCE_DIR "${CMAKE_SOURCE_DIR}/deps/cpp-libp2p" CACHE PATH 
    "Path to cpp-libp2p source directory")

set(LIBP2P_BUILD_DIR "${CMAKE_BINARY_DIR}/libp2p-build" CACHE PATH
    "Build directory for cpp-libp2p")

# ============================================================================
# Option A: ExternalProject (build cpp-libp2p as separate project)
# This is the recommended approach since cpp-libp2p has its own complex
# dependency management (Hunter/vcpkg).
# ============================================================================

include(ExternalProject)

# Detect if we should build libp2p or use a pre-built one
option(LIBP2P_USE_PREBUILT "Use pre-built libp2p" OFF)

if(LIBP2P_USE_PREBUILT)
    # ---- Pre-built libp2p ----
    message(STATUS "Using pre-built cpp-libp2p")
    
    find_path(LIBP2P_INCLUDE_DIR 
        NAMES libp2p/libp2p.hpp
        PATHS /usr/local/include ${CMAKE_SOURCE_DIR}/deps_build/libp2p/include
    )
    
    find_library(LIBP2P_LIBRARY
        NAMES libp2p.a libp2p
        PATHS /usr/local/lib ${CMAKE_SOURCE_DIR}/deps_build/libp2p/lib
    )
    
    if(NOT LIBP2P_INCLUDE_DIR OR NOT LIBP2P_LIBRARY)
        message(FATAL_ERROR 
            "LIBP2P_USE_PREBUILT=ON but libp2p not found.\n"
            "  LIBP2P_INCLUDE_DIR: ${LIBP2P_INCLUDE_DIR}\n"
            "  LIBP2P_LIBRARY: ${LIBP2P_LIBRARY}\n"
            "Set LIBP2P_USE_PREBUILT=OFF to build from source, or install libp2p.")
    endif()
    
    add_library(libp2p_lib STATIC IMPORTED)
    set_property(TARGET libp2p_lib PROPERTY IMPORTED_LOCATION ${LIBP2P_LIBRARY})
    set(LIBP2P_INCLUDE_DIRS ${LIBP2P_INCLUDE_DIR})
    set(LIBP2P_LIBRARIES libp2p_lib)
    
else()
    # ---- Build from source ----
    message(STATUS "Building cpp-libp2p from source: ${LIBP2P_SOURCE_DIR}")

    # ---- Use vcpkg instead of Hunter for dependency management ----
    # vcpkg has better China mirror support (Tsinghua mirror)
    set(VCPKG_ROOT "${CMAKE_SOURCE_DIR}/deps/vcpkg")
    set(VCPKG_TOOLCHAIN "${VCPKG_ROOT}/scripts/buildsystems/vcpkg.cmake")
    
    if(NOT EXISTS "${VCPKG_TOOLCHAIN}")
        message(FATAL_ERROR "vcpkg not found at ${VCPKG_ROOT}. "
                "Please run: git clone https://github.com/microsoft/vcpkg.git ${VCPKG_ROOT}"
                " && cd ${VCPKG_ROOT} && bash bootstrap-vcpkg.sh")
    endif()
    
    message(STATUS "Using vcpkg at: ${VCPKG_ROOT}")
    
    # cpp-libp2p requires C++20 and vcpkg for dependencies
    set(LIBP2P_CMAKE_ARGS
        -DCMAKE_TOOLCHAIN_FILE=${VCPKG_TOOLCHAIN}
        -DVCPKG_TARGET_TRIPLET=x64-linux
        -DCMAKE_CXX_STANDARD=20
        -DCMAKE_CXX_STANDARD_REQUIRED=ON
        -DCMAKE_BUILD_TYPE=${CMAKE_BUILD_TYPE}
        -DCMAKE_INSTALL_PREFIX=${LIBP2P_BUILD_DIR}/install
        -DCMAKE_INSTALL_LIBDIR=lib
        -DTESTING=OFF          # Don't build tests
        -DEXAMPLES=OFF         # Don't build examples
        -DCLANG_FORMAT=OFF
        -DCLANG_TIDY=OFF
        -DCOVERAGE=OFF
        -DASAN=OFF
        -DLSAN=OFF
        -DMSAN=OFF
        -DTSAN=OFF
        -DUBSAN=OFF
        -DEXPOSE_MOCKS=OFF
        -DMETRICS_ENABLED=OFF
        -DSQLITE_ENABLED=OFF
    )
    
    # Pass through compiler settings
    if(CMAKE_CXX_COMPILER)
        list(APPEND LIBP2P_CMAKE_ARGS 
            -DCMAKE_CXX_COMPILER=${CMAKE_CXX_COMPILER})
    endif()
    
    # Set vcpkg mirror for China (Tsinghua) - passed via environment
    set(ENV{X_VCPKG_ASSET_SOURCES} "x-azurl,https://mirrors.tuna.tsinghua.edu.cn/vcpkg/")
    
    ExternalProject_Add(
        libp2p_external
        
        SOURCE_DIR ${LIBP2P_SOURCE_DIR}
        BINARY_DIR ${LIBP2P_BUILD_DIR}
        
        # Use system cmake (not the self-built one without SSL)
        CMAKE_COMMAND /usr/bin/cmake
        
        CMAKE_ARGS ${LIBP2P_CMAKE_ARGS}
        
        # Build and install
        BUILD_COMMAND /usr/bin/cmake --build ${LIBP2P_BUILD_DIR} --target install
        INSTALL_COMMAND ""
        
        # Don't download - source is already in deps/
        DOWNLOAD_COMMAND ""
        UPDATE_COMMAND ""
        PATCH_COMMAND ""
        
        # Logging
        LOG_DOWNLOAD ON
        LOG_UPDATE ON
        LOG_CONFIGURE ON
        LOG_BUILD ON
        LOG_INSTALL ON
    )
    
    # After building, set up the import
    set(LIBP2P_INCLUDE_DIRS ${LIBP2P_BUILD_DIR}/install/include)
    
    # Collect all libp2p .a files for linking
    file(GLOB LIBP2P_LIB_FILES "${LIBP2P_BUILD_DIR}/install/lib/*.a")
    
    # Create a single imported library from all libp2p .a files
    add_library(libp2p_lib STATIC IMPORTED)
    add_dependencies(libp2p_lib libp2p_external)
    set_property(TARGET libp2p_lib PROPERTY 
        IMPORTED_LOCATION ${LIBP2P_BUILD_DIR}/install/lib/libp2p.a)
    # Add all other libp2p libraries as dependencies
    set_property(TARGET libp2p_lib APPEND PROPERTY
        INTERFACE_LINK_LIBRARIES ${LIBP2P_LIB_FILES})
    
    set(LIBP2P_LIBRARIES libp2p_lib)
    
    # Add vcpkg installed lib directory to linker search path
    link_directories(${LIBP2P_BUILD_DIR}/vcpkg_installed/x64-linux/lib)
endif()

# ============================================================================
# Option B: add_subdirectory (simpler but may conflict with parent project)
# Uncomment if cpp-libp2p builds cleanly as a subdirectory
# ============================================================================

# set(LIBP2P_PREV_INSTALL ${CMAKE_INSTALL_PREFIX})
# add_subdirectory(${LIBP2P_SOURCE_DIR} ${LIBP2P_BUILD_DIR})
# set(CMAKE_INSTALL_PREFIX ${LIBP2P_PREV_INSTALL})
# set(LIBP2P_INCLUDE_DIRS ${LIBP2P_SOURCE_DIR}/include)
# set(LIBP2P_LIBRARIES libp2p)

# ============================================================================
# Export convenience target
# ============================================================================

# Create an interface target that provides includes + libraries
add_library(libp2p_integration INTERFACE)
target_include_directories(libp2p_integration INTERFACE ${LIBP2P_INCLUDE_DIRS})
target_link_libraries(libp2p_integration INTERFACE ${LIBP2P_LIBRARIES})

message(STATUS "cpp-libp2p integration configured:")
message(STATUS "  Includes: ${LIBP2P_INCLUDE_DIRS}")
message(STATUS "  Libraries: ${LIBP2P_LIBRARIES}")
